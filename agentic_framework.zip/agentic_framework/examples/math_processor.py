"""
Mathematical expression processor using the agentic framework.

This example demonstrates how to build a concrete application using the
agentic framework with mathematical expression processing capabilities.
"""

import re
import asyncio
from typing import Dict, Any, List
from datetime import datetime, timezone

from agentic_framework import (
    AgenticPipelineController, 
    AgentContext, 
    DecisionPoint, 
    Option, 
    Decision,
    get_logger,
    timing,
    retry,
    memory_managed,
    cache_result
)
from agentic_framework.tools import CalcTool, PowerTool, SafeDevTool, TrigonometryTool, StatisticsTool
from agentic_framework.tools.advanced_math_tools import (
    AdvancedTrigonometryTool, StatisticalAnalysisTool, LinearAlgebraTool, 
    CalculusTool, NumberTheoryTool, CombinatoricsTool
)
from agentic_framework.core.data_structures import Event


class MathPipelineController(AgenticPipelineController):
    """Mathematical expression processor using agentic framework."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Math-specific components
        self.math_tools = self._create_math_tools()
        self.expression_patterns = self._create_expression_patterns()
        self.logger = get_logger(f"MathProcessor.{self.agent_id}")
        
        # Register math tools
        self._register_math_tools()
    
    def _create_math_tools(self) -> Dict[str, Any]:
        """Create mathematical tools using functional approach."""
        return {
            'calc': CalcTool(),
            'power': PowerTool(),
            'function': SafeDevTool(),
            'trigonometry': TrigonometryTool(),
            'statistics': StatisticsTool(),
            'advanced_trig': AdvancedTrigonometryTool(),
            'statistical_analysis': StatisticalAnalysisTool(),
            'linear_algebra': LinearAlgebraTool(),
            'calculus': CalculusTool(),
            'number_theory': NumberTheoryTool(),
            'combinatorics': CombinatoricsTool()
        }
    
    def _create_expression_patterns(self) -> Dict[str, Any]:
        """Create expression patterns using functional composition with dictionary comprehensions."""
        # Pattern definitions for functional compilation
        patterns = {
            'power': r'\d+(?:\.\d+)?\s*\*\*\s*\d+(?:\.\d+)?|\d+(?:\.\d+)?\s*\^\s*\d+(?:\.\d+)?',  # Power: ** or ^
            'arithmetic': r'\d+(?:\.\d+)?\s*//\s*\d+(?:\.\d+)?|\d+(?:\.\d+)?\s*[+\-]\s*\d+(?:\.\d+)?|\d+(?:\.\d+)?\s*/\s*\d+(?:\.\d+)?|\d+(?:\.\d+)?\s*\*\s*\d+(?:\.\d+)?(?!\*)|\d+(?:\.\d+)?\s*%\s*\d+(?:\.\d+)?',  # Arithmetic
            'trigonometry': r'(?:sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|degrees|radians)\s*\(\s*[\d.,\s]+\s*\)',  # Trig functions
            'statistics': r'(?:mean|median|mode|stdev|variance|min|max|sum|count|range)\s*\(\s*\[[\d.,\s]+\]\s*\)',  # Stats functions
            'function': r'\w+\s*\(\s*[\d.,\s]+\s*\)'  # General function calls
        }
        
        # Use dictionary comprehension for functional pattern compilation
        return {name: re.compile(pattern) for name, pattern in patterns.items()}
    
    def _register_math_tools(self):
        """Register mathematical tools with the framework."""
        from agentic_framework.tools.registry import ToolRegistry
        
        # Register tools with the framework's tool registry using functional approach
        registry = ToolRegistry()
        register_tool = lambda name_tool: (
            registry.register(name_tool[0], name_tool[1]),
            self.logger.debug(f"Registered tool: {name_tool[0]}", tool='registry')
        )
        list(map(register_tool, self.math_tools.items()))
    
    @timing(threshold_warning=3.0, threshold_critical=8.0)
    @retry(config_key='retry_config')
    @memory_managed(config_key='memory_config')
    @cache_result(config_key='cache_config')
    async def _perceive_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Perceive mathematical expressions with optional LLM integration."""
        
        self.logger.info("Starting perception stage", tool='perceiver', trace_id=trace_id)
        
        # Decision point: Choose perception strategy
        decision_point = DecisionPoint(
            id="math_perception_strategy",
            description="Choose perception strategy for mathematical expressions",
            type="strategy_selection"
        )
        
        options = [
            Option(id="regex_based", description="Use regex patterns for expression parsing"),
            Option(id="llm_assisted", description="Use LLM for complex expression understanding", requires_llm=True),
            Option(id="hybrid", description="Combine regex and LLM approaches", requires_llm=True)
        ]
        
        # Filter options based on LLM availability
        available_options = [opt for opt in options if not opt.requires_llm or self.has_llm]
        
        # Use decision engine to choose strategy
        if hasattr(self, 'decision_engine') and self.decision_engine:
            decision = await self.decision_engine.make_decision(decision_point, available_options, context)
            chosen_option = next(opt for opt in available_options if opt.id == decision.chosen_option_id)
        else:
            # Fallback: use regex-based approach
            chosen_option = available_options[0]  # regex_based
        
        # Store context reference for filtered expression tracking
        self._current_context = context
        
        # Execute perception strategy functionally
        expressions = await self._perceive_with_regex(context.input_data)
        
        # Get filtered expressions from context
        filtered_expressions = context.metadata.get('filtered_expressions', [])
        
        result = {
            'expressions': expressions,
            'filtered_expressions': filtered_expressions,
            'strategy_used': chosen_option.id,
            'total_found': len(expressions),
            'total_filtered': len(filtered_expressions)
        }
        
        # Count total matches vs valid expressions for reporting using functional approach
        total_matches = sum(
            len(pattern.findall(context.input_data))
            for pattern in self.expression_patterns.values()
        )
        
        filtered_count = total_matches - len(expressions)
        
        if filtered_count > 0:
            self.logger.debug(f"Perception filtered out {filtered_count} duplicate/invalid expressions", tool='perceiver')
            self.logger.info(f"Perception complete: {len(expressions)} valid expressions found (filtered {filtered_count} duplicates)", 
                            tool='perceiver', strategy=chosen_option.id)
        else:
            self.logger.info(f"Perception complete: {len(expressions)} expressions found", 
                            tool='perceiver', strategy=chosen_option.id)
        
        return context.with_stage_result('perceive', result).with_decision({
            'stage': 'perceive',
            'decision': chosen_option.id,
            'reasoning': "Selected regex-based approach for reliable parsing",
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
    
    async def _perceive_with_regex(self, input_data: str) -> List[Dict[str, Any]]:
        """Perceive expressions using regex patterns with validation."""
        expressions = []
        filtered_expressions = []  # Track filtered expressions for reporting
        found_expressions = set()  # Track found expressions to avoid duplicates
        
        # Validate input
        if not input_data or not isinstance(input_data, str):
            self.logger.warning("Invalid input data for perception", tool='perceiver')
            return expressions
        
        # First, find all potential mathematical expressions (broader pattern)
        potential_expr_pattern = re.compile(r'\b\d+\s*[+\-*/%^()]+\s*\d+\b|\b\d+\s*\*\*\s*\d+\b|\b\w+\s*\([^)]+\)')
        potential_expressions = potential_expr_pattern.findall(input_data)
        
        # Process patterns in order of specificity using functional approach
        def process_pattern(pattern_item):
            pattern_name, pattern = pattern_item
            try:
                matches = pattern.findall(input_data)
                
                # Process matches functionally
                def process_match(match):
                    if match in found_expressions:
                        return None
                    
                    if self._validate_expression(match, pattern_name):
                        found_expressions.add(match)
                        return {
                            'original': match,
                            'type': pattern_name,
                            'confidence': self._calculate_confidence(match, pattern_name),
                            'method': 'regex',
                            'complexity': self._assess_expression_complexity(match),
                            'is_valid': True
                        }
                    else:
                        return {
                            'original': match,
                            'type': pattern_name,
                            'reason': 'validation_failed',
                            'error': f"Invalid syntax in expression: {match}",
                            'is_valid': False
                        }
                
                processed_matches = list(filter(None, map(process_match, matches)))
                
                # Log filtered expressions
                list(map(
                    lambda m: self.logger.debug(f"Invalid expression filtered out: {m['original']}", tool='perceiver'),
                    filter(lambda m: not m.get('is_valid', True), processed_matches)
                ))
                
                return processed_matches
            except Exception as e:
                self.logger.error(f"Error processing pattern {pattern_name}: {e}", tool='perceiver')
                return []
        
        # Process all patterns and separate valid from invalid
        all_results = [result for pattern_results in map(process_pattern, self.expression_patterns.items()) 
                      for result in pattern_results]
        
        expressions.extend([r for r in all_results if r.get('is_valid', True)])
        filtered_expressions.extend([r for r in all_results if not r.get('is_valid', True)])
        
        # Check for potential expressions that weren't matched using functional filtering
        unmatched_expressions = filter(
            lambda potential: potential not in found_expressions and 
                            not any(potential == f['original'] for f in filtered_expressions),
            potential_expressions
        )
        
        # Process unmatched expressions functionally
        create_unmatched_entry = lambda potential: {
            'original': potential,
            'type': 'unknown',
            'reason': 'no_pattern_match',
            'error': f"Invalid mathematical expression syntax: {potential}"
        }
        
        unmatched_entries = list(map(create_unmatched_entry, unmatched_expressions))
        filtered_expressions.extend(unmatched_entries)
        
        # Log unrecognized expressions
        list(map(
            lambda potential: self.logger.warning(f"Unrecognized mathematical expression: {potential}", tool='perceiver'),
            unmatched_expressions
        ))
        
        # Store filtered expressions in context for later reporting
        if hasattr(self, '_current_context') and self._current_context:
            self._current_context.metadata['filtered_expressions'] = filtered_expressions
        
        self.logger.debug(f"Perceived {len(expressions)} valid expressions", tool='perceiver')
        return expressions
    
    def _validate_expression(self, expression: str, expr_type: str) -> bool:
        """Validate that an expression is properly formed using functional pipeline."""
        from functools import partial
        
        # Create validation pipeline
        validators = [
            self._validate_not_empty,
            self._validate_balanced_parentheses,
            partial(self._validate_by_type, expr_type=expr_type)
        ]
        
        try:
            return all(validator(expression) for validator in validators)
        except Exception as e:
            self.logger.error(f"Expression validation error for '{expression}': {e}", tool='perceiver')
            return False
    
    def _validate_not_empty(self, expression: str) -> bool:
        """Validate expression is not empty."""
        if not expression or not expression.strip():
            self.logger.debug("Expression validation failed: empty expression", tool='perceiver')
            return False
        return True
    
    def _validate_balanced_parentheses(self, expression: str) -> bool:
        """Validate parentheses are balanced."""
        if expression.count('(') != expression.count(')'):
            self.logger.debug(f"Expression validation failed: unbalanced parentheses in '{expression}'", tool='perceiver')
            return False
        return True
    
    def _validate_by_type(self, expression: str, expr_type: str) -> bool:
        """Validate expression based on its type using functional mapping."""
        validators = {
            'arithmetic': self._validate_arithmetic_expression,
            'power': self._validate_power_expression,
            'function': self._validate_function_expression
        }
        
        validator = validators.get(expr_type, lambda x: True)
        return validator(expression)
    
    def _validate_arithmetic_expression(self, expression: str) -> bool:
        """Validate arithmetic expression using functional approach."""
        # Check valid characters
        if not re.match(r'^[\d\s+\-*/%().]+$', expression):
            self.logger.debug(f"Expression validation failed: invalid characters in '{expression}'", tool='perceiver')
            return False
        
        # Invalid operator patterns
        invalid_patterns = [
            r'\*/', r'/\*', r'\+\+', r'--', r'\*\*\*', r'///', r'%%',
            r'[+\-*/%]{3,}', r'^[+\-*/%]', r'[+\-*/%]$'
        ]
        
        clean_expr = expression.replace(' ', '')
        
        # Use any() with generator expression for short-circuit evaluation
        if any(re.search(pattern, clean_expr) for pattern in invalid_patterns):
            self.logger.warning(f"Expression validation failed: invalid operator pattern in '{expression}'", tool='perceiver')
            return False
        
        return True
    
    def _validate_power_expression(self, expression: str) -> bool:
        """Validate power expression using functional approach."""
        power_operators = ['**', '^']
        if not any(op in expression for op in power_operators):
            self.logger.debug(f"Expression validation failed: no power operator in '{expression}'", tool='perceiver')
            return False
        return True
    
    def _validate_function_expression(self, expression: str) -> bool:
        """Validate function expression using functional approach."""
        if not (expression.count('(') == 1 and expression.endswith(')')):
            self.logger.debug(f"Expression validation failed: invalid function format in '{expression}'", tool='perceiver')
            return False
        return True
    
    def _calculate_confidence(self, expression: str, expr_type: str) -> float:
        """Calculate confidence score using functional mapping approach."""
        base_confidence = 0.9
        
        # Confidence adjustments based on complexity using functional mapping
        adjustments = {
            'simple': 0.05,
            'complex': -0.1,
            'medium': 0.0
        }
        
        complexity = self._assess_expression_complexity(expression)
        adjustment = adjustments.get(complexity, 0.0)
        
        return max(0.5, min(1.0, base_confidence + adjustment))
    
    def _assess_expression_complexity(self, expression: str) -> str:
        """Assess the complexity of an expression using functional thresholds."""
        clean_expr = expression.replace(' ', '')
        length = len(clean_expr)
        
        # Complexity thresholds using functional approach
        thresholds = [(5, 'simple'), (15, 'medium'), (float('inf'), 'complex')]
        
        return next(complexity for threshold, complexity in thresholds if length <= threshold)  
  
    async def _plan_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Plan the execution of mathematical expressions."""
        
        self.logger.info("Starting planning stage", tool='planner', trace_id=trace_id)
        
        perceive_result = context.get_stage_result('perceive', {})
        expressions = perceive_result.get('expressions', [])
        
        # Create execution plan using functional approach
        create_plan_item = lambda i_expr: {
            'id': f"expr_{i_expr[0]}",
            'expression': i_expr[1]['original'],
            'type': i_expr[1]['type'],
            'tool': self._select_tool_for_expression(i_expr[1]),
            'priority': 1.0,
            'estimated_time': 0.1
        }
        
        execution_plan = list(map(create_plan_item, enumerate(expressions)))
        
        result = {
            'execution_plan': execution_plan,
            'total_expressions': len(expressions),
            'estimated_total_time': sum(item['estimated_time'] for item in execution_plan)
        }
        
        self.logger.info(f"Planning complete: {len(execution_plan)} expressions planned", 
                        tool='planner')
        
        return context.with_stage_result('plan', result)
    
    async def _reason_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Reason about the execution strategy."""
        
        self.logger.info("Starting reasoning stage", tool='reasoner', trace_id=trace_id)
        
        plan_result = context.get_stage_result('plan', {})
        execution_plan = plan_result.get('execution_plan', [])
        
        # Analyze execution plan and optimize using functional approach
        optimize_item = lambda item: {
            **item,
            'batch_eligible': item['type'] == 'arithmetic'
        }
        
        optimized_plan = list(map(optimize_item, execution_plan))
        
        result = {
            'optimized_plan': optimized_plan,
            'optimization_applied': True,
            'reasoning': "Grouped arithmetic operations for batch processing"
        }
        
        self.logger.info("Reasoning complete: execution plan optimized", tool='reasoner')
        
        return context.with_stage_result('reason', result)
    
    async def _act_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Execute the mathematical expressions with parallel processing support."""
        
        self.logger.info("Starting action stage", tool='actor', trace_id=trace_id)
        
        reason_result = context.get_stage_result('reason', {})
        optimized_plan = reason_result.get('optimized_plan', [])
        
        # Emit action start event
        await self.event_system.emit_event(Event(
            type='action_stage_started',
            source='math_processor',
            data={
                'total_expressions': len(optimized_plan),
                'trace_id': trace_id,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
        ))
        
        # Group expressions for potential parallel execution
        batch_eligible = [item for item in optimized_plan if item.get('batch_eligible', False)]
        sequential_items = [item for item in optimized_plan if not item.get('batch_eligible', False)]
        
        execution_results = []
        
        # Execute batch-eligible items in parallel
        if batch_eligible:
            self.logger.info(f"Executing {len(batch_eligible)} expressions in parallel", tool='actor')
            batch_tasks = [self._execute_expression_with_context(item, trace_id) for item in batch_eligible]
            batch_results = await asyncio.gather(*batch_tasks, return_exceptions=True)
            
            # Process batch results using functional mapping
            def create_result_entry(item, result):
                base_entry = {
                    'id': item['id'],
                    'expression': item['expression'],
                    'tool_used': item['tool'],
                    'execution_mode': 'parallel'
                }
                
                if isinstance(result, Exception):
                    return {**base_entry, 'error': str(result), 'success': False}
                else:
                    return {**base_entry, 'result': result, 'success': True}
            
            batch_execution_results = [
                create_result_entry(item, result) 
                for item, result in zip(batch_eligible, batch_results)
            ]
            execution_results.extend(batch_execution_results)
        
        # Execute sequential items using functional approach with safe execution
        async def execute_sequential_item(item):
            try:
                result = await self._execute_expression(item)
                self.logger.debug(f"Executed {item['expression']} = {result}", tool='actor')
                return {
                    'id': item['id'],
                    'expression': item['expression'],
                    'result': result,
                    'success': True,
                    'tool_used': item['tool'],
                    'execution_mode': 'sequential'
                }
            except Exception as e:
                self.logger.error(f"Failed to execute {item['expression']}: {e}", tool='actor')
                return {
                    'id': item['id'],
                    'expression': item['expression'],
                    'error': str(e),
                    'success': False,
                    'tool_used': item['tool'],
                    'execution_mode': 'sequential'
                }
        
        # Process sequential items functionally
        sequential_results = [await execute_sequential_item(item) for item in sequential_items]
        execution_results.extend(sequential_results)
        
        result = {
            'execution_results': execution_results,
            'total_executed': len(execution_results),
            'successful': sum(1 for r in execution_results if r['success']),
            'failed': sum(1 for r in execution_results if not r['success']),
            'parallel_executed': len(batch_eligible),
            'sequential_executed': len(sequential_items)
        }
        
        self.logger.info(f"Action complete: {result['successful']}/{result['total_executed']} successful", 
                        tool='actor')
        
        return context.with_stage_result('act', result)
    
    async def _execute_expression_with_context(self, plan_item: Dict[str, Any], trace_id: str) -> Any:
        """Execute expression with additional context for parallel execution."""
        try:
            return await self._execute_expression(plan_item)
        except Exception as e:
            self.logger.error(f"Parallel execution failed for {plan_item['expression']}: {e}", 
                            tool='actor', trace_id=trace_id)
            raise
    
    async def _review_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Review the execution results."""
        
        self.logger.info("Starting review stage", tool='reviewer', trace_id=trace_id)
        
        act_result = context.get_stage_result('act', {})
        execution_results = act_result.get('execution_results', [])
        
        # Review results
        review_summary = {
            'total_expressions': len(execution_results),
            'successful_executions': sum(1 for r in execution_results if r['success']),
            'failed_executions': sum(1 for r in execution_results if not r['success']),
            'success_rate': 0.0,
            'quality_score': 0.0
        }
        
        # Calculate rates using functional approach with safe division
        total_expressions = review_summary['total_expressions']
        success_rate = (review_summary['successful_executions'] / total_expressions 
                       if total_expressions > 0 else 0.0)
        
        review_summary.update({
            'success_rate': success_rate,
            'quality_score': success_rate * 100
        })
        
        # Identify issues and categorize errors
        issues = []
        error_categories = {
            'syntax_errors': 0,
            'division_by_zero': 0,
            'invalid_operators': 0,
            'tool_failures': 0,
            'other_errors': 0
        }
        
        # Process failed results using functional approach
        failed_results = list(filter(lambda result: not result['success'], execution_results))
        
        def process_failed_result(result):
            error_msg = result.get('error', 'Unknown error')
            category, recommendation, category_key = self._categorize_error_functional(error_msg)
            
            # Update error categories count
            error_categories[category_key] += 1
            
            # Log the error for better visibility
            self.logger.error(f"Expression failed: {result['expression']} - {error_msg}", tool='reviewer')
            
            return {
                'expression': result['expression'],
                'error': error_msg,
                'category': category,
                'recommendation': recommendation
            }
        
        issues.extend(map(process_failed_result, failed_results))
        
        result = {
            'review_summary': review_summary,
            'issues_identified': issues,
            'error_categories': error_categories,
            'overall_quality': next(
                quality for threshold, quality in [(0.8, 'good'), (0.0, 'needs_improvement')]
                if review_summary['success_rate'] >= threshold
            )
        }
        
        self.logger.info(f"Review complete: {review_summary['success_rate']:.1%} success rate", 
                        tool='reviewer')
        
        return context.with_stage_result('review', result)
    
    def _categorize_error_functional(self, error_msg: str) -> tuple[str, str, str]:
        """Categorize error using functional mapping approach."""
        # Error categorization mapping with keywords, category, recommendation, and key
        error_categories_map = [
            ('invalid operator pattern', 'Invalid Operator Pattern', 
             'Fix operator syntax (e.g., avoid */ or /*, use single operators)', 'invalid_operators'),
            ('division by zero', 'Division by Zero', 
             'Ensure divisor is not zero', 'division_by_zero'),
            ('tool', 'Tool Failure', 
             'Check tool compatibility and parameters', 'tool_failures'),
            ('invalid', 'Syntax Error', 
             'Check expression syntax and format', 'syntax_errors'),
            ('format', 'Syntax Error', 
             'Check expression syntax and format', 'syntax_errors')
        ]
        
        error_lower = error_msg.lower()
        
        # Use next() with generator expression for efficient lookup
        category_info = next(
            ((category, recommendation, key) for keyword, category, recommendation, key in error_categories_map
             if keyword in error_lower),
            ('Other Error', 'Review expression and try alternative format', 'other_errors')
        )
        
        return category_info
    
    async def _learn_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Learn from the execution experience with enhanced analytics."""
        
        self.logger.info("Starting learning stage", tool='learner', trace_id=trace_id)
        
        # Gather data from all stages
        review_result = context.get_stage_result('review', {})
        act_result = context.get_stage_result('act', {})
        plan_result = context.get_stage_result('plan', {})
        
        review_summary = review_result.get('review_summary', {})
        execution_results = act_result.get('execution_results', [])
        
        # Analyze performance patterns
        performance_analysis = self._analyze_performance_patterns(execution_results)
        tool_performance = self._analyze_tool_performance(execution_results)
        expression_complexity = self._analyze_expression_complexity(execution_results)
        
        # Generate learning insights
        learning_insights = {
            'performance_metrics': {
                'success_rate': review_summary.get('success_rate', 0),
                'total_processed': review_summary.get('total_expressions', 0),
                'parallel_efficiency': performance_analysis.get('parallel_efficiency', 0),
                'avg_execution_time': performance_analysis.get('avg_execution_time', 0)
            },
            'tool_performance': tool_performance,
            'expression_patterns': expression_complexity,
            'patterns_identified': performance_analysis.get('patterns', []),
            'recommendations': []
        }
        
        # Generate intelligent recommendations
        recommendations = self._generate_recommendations(learning_insights, context)
        learning_insights['recommendations'] = recommendations
        
        # Update internal knowledge (if we had a knowledge base)
        knowledge_updates = {
            'tool_success_rates': tool_performance,
            'expression_difficulty_mapping': expression_complexity,
            'optimization_opportunities': recommendations
        }
        
        result = {
            'learning_insights': learning_insights,
            'knowledge_updates': knowledge_updates,
            'knowledge_updated': True,
            'next_iteration_improvements': recommendations,
            'learning_confidence': self._calculate_learning_confidence(learning_insights)
        }
        
        self.logger.info(f"Learning complete: {len(recommendations)} insights captured", 
                        tool='learner')
        
        return context.with_stage_result('learn', result)
    
    def _analyze_performance_patterns(self, execution_results: List[Dict]) -> Dict[str, Any]:
        """Analyze performance patterns from execution results."""
        if not execution_results:
            return {'patterns': [], 'parallel_efficiency': 0, 'avg_execution_time': 0}
        
        parallel_results = [r for r in execution_results if r.get('execution_mode') == 'parallel']
        sequential_results = [r for r in execution_results if r.get('execution_mode') == 'sequential']
        
        patterns = []
        # Add patterns using functional conditional expression
        patterns.extend([
            "Parallel execution preferred for this workload"
            for _ in [None] if len(parallel_results) > len(sequential_results)
        ])
        
        # Analyze success by type using functional grouping and reduce
        from functools import reduce
        from collections import defaultdict
        
        def group_by_type(acc, result):
            expr_type = result.get('type', 'unknown')
            
            # Initialize type stats using functional approach
            acc.setdefault(expr_type, {'total': 0, 'successful': 0})
            
            # Update stats functionally
            acc[expr_type]['total'] += 1
            acc[expr_type]['successful'] += result['success']
            
            return acc
        
        success_by_type = reduce(group_by_type, execution_results, {})
        
        # Generate patterns using functional filtering and mapping
        low_success_types = filter(
            lambda item: ((lambda total, successful: successful / total if total > 0 else 0)(
                item[1]['total'], item[1]['successful']
            )) < 0.8,
            success_by_type.items()
        )
        
        patterns.extend([
            f"Low success rate for {expr_type} expressions: {stats['successful'] / stats['total']:.1%}"
            for expr_type, stats in low_success_types
        ])
        
        return {
            'patterns': patterns,
            'parallel_efficiency': (lambda total, parallel: parallel / total if total > 0 else 0)(
                len(execution_results), len(parallel_results)
            ),
            'avg_execution_time': 0.1,  # Would calculate from actual timing data
            'success_by_type': success_by_type
        }
    
    def _analyze_tool_performance(self, execution_results: List[Dict]) -> Dict[str, Dict]:
        """Analyze performance of different tools."""
        tool_stats = {}
        
        # Process results using functional grouping and reduce
        from functools import reduce
        from collections import defaultdict
        
        def accumulate_tool_stats(stats, result):
            tool = result.get('tool_used', 'unknown')
            
            # Initialize tool stats if not present using functional approach
            stats.setdefault(tool, {'total': 0, 'successful': 0, 'errors': []})
            
            # Update stats functionally
            stats[tool]['total'] += 1
            stats[tool]['successful'] += result['success']
            
            # Add error if not successful using functional conditional
            [stats[tool]['errors'].append(result.get('error', 'Unknown error'))
             for _ in [None] if not result['success']]
            
            return stats
        
        tool_stats = reduce(accumulate_tool_stats, execution_results, {})
        
        # Calculate success rates using functional mapping
        def calculate_success_rate(stats):
            stats['success_rate'] = (lambda total, successful: successful / total if total > 0 else 0)(
                stats['total'], stats['successful']
            )
            stats['common_errors'] = list(set(stats['errors'][:3]))  # Top 3 unique errors
            return stats
        
        tool_stats = {tool: calculate_success_rate(stats) for tool, stats in tool_stats.items()}
        
        return tool_stats
    
    def _analyze_expression_complexity(self, execution_results: List[Dict]) -> Dict[str, Any]:
        """Analyze complexity patterns in expressions."""
        complexity_analysis = {
            'simple_expressions': 0,
            'complex_expressions': 0,
            'function_calls': 0,
            'power_operations': 0
        }
        
        # Analyze complexity using functional predicates and filters
        expressions = [result.get('expression', '') for result in execution_results]
        
        # Define predicates for different expression types
        is_arithmetic = lambda expr: any(op in expr for op in ['+', '-', '*', '/'])
        is_simple = lambda expr: len(expr.replace(' ', '')) < 10
        is_function = lambda expr: '(' in expr and ')' in expr
        is_power = lambda expr: '**' in expr or '^' in expr
        
        # Use functional filtering and counting
        arithmetic_exprs = list(filter(is_arithmetic, expressions))
        complexity_analysis.update({
            'simple_expressions': len(list(filter(is_simple, arithmetic_exprs))),
            'complex_expressions': len(list(filter(lambda x: not is_simple(x), arithmetic_exprs))),
            'function_calls': len(list(filter(is_function, expressions))),
            'power_operations': len(list(filter(is_power, expressions)))
        })
        
        return complexity_analysis
    
    def _generate_recommendations(self, insights: Dict, context: AgentContext) -> List[str]:
        """Generate intelligent recommendations based on learning insights."""
        recommendations = []
        
        performance = insights['performance_metrics']
        tool_perf = insights['tool_performance']
        
        # Performance-based recommendations using functional predicates
        performance_rules = [
            (lambda p: p['success_rate'] < 0.8, "Consider improving expression parsing accuracy"),
            (lambda p: p['total_processed'] > 10, "Large batch detected - parallel processing is beneficial")
        ]
        
        recommendations.extend([
            message for predicate, message in performance_rules
            if predicate(performance)
        ])
        
        # Tool-specific recommendations using functional filtering and mapping
        low_performing_tools = filter(
            lambda item: item[1]['success_rate'] < 0.7,
            tool_perf.items()
        )
        
        recommendations.extend([
            f"Tool '{tool}' has low success rate ({stats['success_rate']:.1%}) - consider alternative"
            for tool, stats in low_performing_tools
        ])
        
        # Pattern-based recommendations
        patterns = insights.get('patterns_identified', [])
        if any('parallel' in pattern.lower() for pattern in patterns):
            recommendations.append("Optimize for parallel execution in future runs")
        
        return recommendations
    
    def _calculate_learning_confidence(self, insights: Dict) -> float:
        """Calculate confidence in learning insights based on data quality."""
        total_processed = insights['performance_metrics']['total_processed']
        
        # Use functional thresholds for confidence calculation
        confidence_thresholds = [(10, 0.9), (5, 0.7), (1, 0.5), (0, 0.1)]
        
        return next(confidence for threshold, confidence in confidence_thresholds 
                   if total_processed >= threshold)
    
    def _select_tool_for_expression(self, expr: Dict[str, Any]) -> str:
        """Select appropriate tool for expression type using functional mapping."""
        expr_type = expr.get('type', 'unknown')
        expr_text = expr.get('original', '')
        
        # Tool selection mapping with conditional logic
        tool_mapping = {
            'power': 'power',
            'trigonometry': 'trigonometry',
            'statistics': 'statistics',
            'function': 'function',
            'arithmetic': 'direct' if '//' in expr_text else 'calc'
        }
        
        return tool_mapping.get(expr_type, 'calc')
    
    async def _execute_expression(self, plan_item: Dict[str, Any]) -> Any:
        """Execute a single mathematical expression using registered tools."""
        expression = plan_item['expression']
        tool_name = plan_item['tool']
        expr_type = plan_item['type']
        
        # Try to use registered tools first
        if tool_name in self.math_tools:
            tool = self.math_tools[tool_name]
            try:
                # Convert expression to tool parameters
                params = self._expression_to_params(expression, expr_type)
                
                # Handle different tool parameter patterns using functional approach
                if tool_name == 'trigonometry' and 'function_name' in params and 'value' in params:
                    return await tool.execute(params['function_name'], params['value'])
                elif tool_name == 'statistics' and 'function_name' in params and 'data' in params:
                    return await tool.execute(params['function_name'], params['data'])
                elif tool_name == 'function' and 'function_name' in params and 'args' in params:
                    return await tool.execute(params['function_name'], *params['args'])
                elif 'operation' in params:
                    # Arithmetic and power operations
                    if 'left' in params and 'right' in params:
                        return await tool.execute(params['operation'], params['left'], params['right'])
                    elif 'base' in params and 'exponent' in params:
                        return await tool.execute(params['operation'], params['base'], params['exponent'])
                else:
                    # Try direct execution with expression
                    return await tool.execute(expression)
            except Exception as e:
                self.logger.warning(f"Tool {tool_name} failed, falling back to direct execution: {e}")
        
        # Fallback to direct execution using functional mapping
        execution_mapping = {
            'arithmetic': self._execute_arithmetic,
            'power': self._execute_power,
            'trigonometry': self._execute_trigonometry,
            'statistics': self._execute_statistics,
            'function': self._execute_function
        }
        
        # Use functional approach with get() and default error handling
        try:
            executor = execution_mapping[expr_type]
            return await executor(expression)
        except KeyError:
            raise ValueError(f"Unknown expression type: {expr_type}")
    
    def _expression_to_params(self, expression: str, expr_type: str) -> Dict[str, Any]:
        """Convert expression string to tool parameters using functional decomposition."""
        # Parameter conversion mapping
        converters = {
            'arithmetic': self._parse_arithmetic_params,
            'power': self._parse_power_params,
            'trigonometry': self._parse_trigonometry_params,
            'statistics': self._parse_statistics_params,
            'function': self._parse_function_params
        }
        
        converter = converters.get(expr_type, lambda x: {'expression': x})
        return converter(expression.replace(' ', ''))
    
    def _parse_arithmetic_params(self, expression: str) -> Dict[str, Any]:
        """Parse arithmetic expression parameters using functional approach."""
        # Operator precedence: floor division first, then others
        operators = ['//', '+', '-', '*', '/', '%']
        
        # Use functional approach with next() for operator detection
        try:
            op = next(op for op in operators if op in expression)
            parts = expression.split(op, 1)  # Split only on first occurrence
            return {
                'operation': op,
                'left': float(parts[0]),
                'right': float(parts[1])
            }
        except StopIteration:
            pass  # No operator found
        
        return {'expression': expression}
    
    def _parse_power_params(self, expression: str) -> Dict[str, Any]:
        """Parse power expression parameters using functional mapping."""
        power_ops = {'**': '**', '^': '^'}
        
        # Use functional approach with next() for power operator detection
        try:
            op, operation = next((op, operation) for op, operation in power_ops.items() if op in expression)
            parts = expression.split(op, 1)
            return {
                'operation': operation,
                'base': float(parts[0]),
                'exponent': float(parts[1])
            }
        except StopIteration:
            pass  # No power operator found
        
        return {'expression': expression}
    
    def _parse_function_params(self, expression: str) -> Dict[str, Any]:
        """Parse function expression parameters using functional approach."""
        # Extract function name and arguments
        if '(' not in expression or not expression.endswith(')'):
            return {'expression': expression}
        
        func_name = expression.split('(')[0]
        args_str = expression[len(func_name)+1:-1]
        args = [float(x.strip()) for x in args_str.split(',') if x.strip()]
        
        return {
            'function_name': func_name,
            'args': args
        }
    
    def _parse_trigonometry_params(self, expression: str) -> Dict[str, Any]:
        """Parse trigonometry expression parameters using functional approach."""
        import re
        
        # Extract function name and value
        match = re.match(r'(\w+)\s*\(\s*([\d.,\s]+)\s*\)', expression)
        if not match:
            return {'expression': expression}
        
        func_name = match.group(1)
        value_str = match.group(2).strip()
        
        try:
            value = float(value_str)
            return {
                'function_name': func_name,
                'value': value
            }
        except ValueError:
            return {'expression': expression}
    
    def _parse_statistics_params(self, expression: str) -> Dict[str, Any]:
        """Parse statistics expression parameters using functional approach."""
        import re
        
        # Extract function name and data array
        match = re.match(r'(\w+)\s*\(\s*\[([\d.,\s]+)\]\s*\)', expression)
        if not match:
            return {'expression': expression}
        
        func_name = match.group(1)
        data_str = match.group(2).strip()
        
        try:
            data = [float(x.strip()) for x in data_str.split(',') if x.strip()]
            return {
                'function_name': func_name,
                'data': data
            }
        except ValueError:
            return {'expression': expression}
    
    async def _execute_arithmetic(self, expression: str) -> float:
        """Execute arithmetic expression using functional operator-based approach."""
        from operator import add, sub, mul, truediv, floordiv, mod
        
        # Operator mapping for O(1) lookup instead of O(n) if-else chain
        arithmetic_operators = {
            '//': floordiv,
            '+': add,
            '-': sub,
            '*': mul,
            '/': truediv,
            '%': mod
        }
        
        original_expression = expression
        clean_expr = expression.replace(' ', '')
        
        try:
            # Use functional approach with next() and generator for operator lookup
            try:
                op_symbol, op_func = next(
                    (op_symbol, op_func) for op_symbol, op_func in arithmetic_operators.items()
                    if op_symbol in clean_expr
                )
                parts = clean_expr.split(op_symbol, 1)
                if len(parts) != 2:
                    raise ValueError(f"Invalid {op_symbol} format: {original_expression}")
                
                left, right = map(float, parts)
                return op_func(left, right)
            except StopIteration:
                # No operator found, try to parse as number
                return float(clean_expr)
            
        except ValueError as e:
            if "could not convert string to float" in str(e):
                raise ValueError(f"Invalid number format in expression: {original_expression}")
            raise
        except ZeroDivisionError:
            raise ValueError(f"Division by zero in expression: {original_expression}")
        except Exception as e:
            raise ValueError(f"Failed to execute arithmetic expression '{original_expression}': {e}")
    
    async def _execute_power(self, expression: str) -> float:
        """Execute power expression using functional operator mapping."""
        from operator import pow
        
        clean_expr = expression.replace(' ', '')
        power_operators = ['**', '^']
        
        # Use functional approach with next() for power operator detection
        try:
            op = next(op for op in power_operators if op in clean_expr)
            parts = clean_expr.split(op, 1)
            base, exponent = map(float, parts)
            return pow(base, exponent)
        except StopIteration:
            pass  # No power operator found
        
        return float(clean_expr)
    
    async def _execute_function(self, expression: str) -> float:
        """Execute function expression using functional registry with higher-order functions."""
        from functools import reduce
        from operator import mul, mod
        
        # Function registry using higher-order functions and lambdas
        math_functions = {
            'add': sum,
            'mul': lambda args: reduce(mul, args, 1),
            'mod': lambda args: mod(*args) if len(args) >= 2 else self._raise_mod_error()
        }
        
        # Extract function name and arguments using functional parsing
        if '(' not in expression or not expression.endswith(')'):
            raise ValueError(f"Invalid function format: {expression}")
        
        func_name = expression.split('(')[0]
        args_str = expression[len(func_name)+1:-1]
        args = [float(x.strip()) for x in args_str.split(',') if x.strip()]
        
        # Use functional mapping for function execution
        if func_name not in math_functions:
            raise ValueError(f"Unknown function: {func_name}")
        
        return math_functions[func_name](args)
    
    def _raise_mod_error(self):
        """Helper function for modulo error handling."""
        raise ValueError("mod function requires at least 2 arguments")
    
    async def _execute_trigonometry(self, expression: str) -> float:
        """Execute trigonometric expression using functional approach."""
        import re
        
        # Parse trigonometric function call
        match = re.match(r'(\w+)\s*\(\s*([\d.,\s]+)\s*\)', expression)
        if not match:
            raise ValueError(f"Invalid trigonometric expression format: {expression}")
        
        func_name = match.group(1)
        value_str = match.group(2).strip()
        
        try:
            value = float(value_str)
            
            # Use the trigonometry tool directly
            trig_tool = self.math_tools.get('trigonometry')
            if trig_tool:
                return await trig_tool.execute(func_name, value)
            else:
                # Fallback to math module
                import math
                trig_functions = {
                    'sin': math.sin, 'cos': math.cos, 'tan': math.tan,
                    'asin': math.asin, 'acos': math.acos, 'atan': math.atan,
                    'sinh': math.sinh, 'cosh': math.cosh, 'tanh': math.tanh,
                    'degrees': math.degrees, 'radians': math.radians
                }
                
                if func_name not in trig_functions:
                    raise ValueError(f"Unknown trigonometric function: {func_name}")
                
                return trig_functions[func_name](value)
                
        except ValueError as e:
            raise ValueError(f"Error in trigonometric calculation: {e}")
    
    async def _execute_statistics(self, expression: str) -> float:
        """Execute statistical expression using functional approach."""
        import re
        import ast
        
        # Parse statistical function call with array
        match = re.match(r'(\w+)\s*\(\s*\[([\d.,\s]+)\]\s*\)', expression)
        if not match:
            raise ValueError(f"Invalid statistical expression format: {expression}")
        
        func_name = match.group(1)
        data_str = match.group(2).strip()
        
        try:
            # Parse the data array
            data = [float(x.strip()) for x in data_str.split(',') if x.strip()]
            
            if not data:
                raise ValueError("Data array cannot be empty")
            
            # Use the statistics tool directly
            stats_tool = self.math_tools.get('statistics')
            if stats_tool:
                return await stats_tool.execute(func_name, data)
            else:
                # Fallback to statistics module
                import statistics
                stats_functions = {
                    'mean': statistics.mean,
                    'median': statistics.median,
                    'stdev': statistics.stdev,
                    'variance': statistics.variance,
                    'min': min,
                    'max': max,
                    'sum': sum,
                    'count': len
                }
                
                if func_name not in stats_functions:
                    raise ValueError(f"Unknown statistical function: {func_name}")
                
                return stats_functions[func_name](data)
                
        except ValueError as e:
            raise ValueError(f"Error in statistical calculation: {e}")


# Example usage
async def main():
    """Example usage of the mathematical expression processor."""
    
    # Create math processor
    math_processor = MathPipelineController(
        timeout=30,
        debug=True,
        agent_id='math_processor_example'
    )
    
    # Get logger for main function
    main_logger = get_logger("MathProcessor.Main")
    
    # Process mathematical expressions
    test_inputs = [
        "Calculate 2+3, 5*7, 10//4, 8%3, 5*/2 and 10/2",
        "Compute 2^8, 3**4",
        "Evaluate add(5,6,7), mul(2,3,4)",
        "Calculate sin(1.57), cos(0), tan(0.785)",
        "Find mean([1,2,3,4,5]), median([1,2,3,4,5]), max([1,2,3,4,5])"
    ]
    
    # Process test inputs using functional approach
    async def process_test_input(i_input):
        i, math_input = i_input
        main_logger.info(f"--- Processing Example {i+1} ---")
        main_logger.info(f"Input: {math_input}")
        
        try:
            result = await math_processor.execute(math_input)
            
            main_logger.info("✅ Processing successful!")
            main_logger.debug(f"Results: {result.get('results', {})}")
            
            # Show execution summary using functional approach
            results = result.get('results', {})
            act_result = results.get('act', {})
            review_result = results.get('review', {})
            perceive_result = results.get('perceive', {})
            
            main_logger.info("Expression Results:")
            
            # Show successful and failed executions functionally
            execution_results = act_result.get('execution_results', [])
            
            # Log successful results
            successful_results = filter(lambda r: r['success'], execution_results)
            list(map(
                lambda r: main_logger.info(f"  ✅ {r['expression']} = {r['result']}"),
                successful_results
            ))
            
            # Log failed results
            failed_results = filter(lambda r: not r['success'], execution_results)
            list(map(
                lambda r: main_logger.error(f"  ❌ {r['expression']} = ERROR: {r['error']}"),
                failed_results
            ))
            
            # Show filtered expressions functionally
            filtered_expressions = perceive_result.get('filtered_expressions', []) if perceive_result else []
            list(map(
                lambda f: main_logger.error(f"  ❌ {f['original']} = ERROR: {f['error']}"),
                filtered_expressions
            ))
            
            # Show review issues functionally
            issues = review_result.get('issues_identified', []) if review_result else []
            if issues:
                main_logger.warning(f"Found {len(issues)} expression errors:")
                list(map(
                    lambda issue: main_logger.warning(f"  - {issue['expression']}: {issue['category']} - {issue['recommendation']}"),
                    issues
                ))
            
        except Exception as e:
            main_logger.error(f"❌ Processing failed: {e}")
    
    # Process all test inputs sequentially (to maintain order in logs)
    for item in enumerate(test_inputs):
        await process_test_input(item)


if __name__ == "__main__":
    asyncio.run(main())