"""
Text processing pipeline using the agentic framework.

This example demonstrates how to build a text analysis and processing pipeline
with natural language processing capabilities, sentiment analysis, and text transformations.
"""

import re
import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime
from collections import Counter
import string

from agentic_framework import (
    AgenticPipelineController, 
    AgentContext, 
    DecisionPoint, 
    Option, 
    Decision,
    get_logger,
    timing,
    retry,
    memory_managed,
    cache_result
)
from agentic_framework.core.data_structures import Event


class TextPipelineController(AgenticPipelineController):
    """Text processing pipeline using agentic framework."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Text-specific components
        self.text_tools = self._create_text_tools()
        self.analysis_patterns = self._create_analysis_patterns()
        self.logger = get_logger(f"TextProcessor.{self.agent_id}")
        
        # Register text processing tools
        self._register_text_tools()
    
    def _create_text_tools(self) -> Dict[str, Any]:
        """Create text processing tools."""
        from agentic_framework.tools.text_processing_tools import (
            SentimentAnalyzerTool,
            TextTokenizerTool,
            TextStructureAnalyzerTool,
            EntityExtractorTool,
            TextTransformerTool
        )
        
        return {
            'sentiment': SentimentAnalyzerTool(),
            'tokenizer': TextTokenizerTool(),
            'transformer': TextTransformerTool(),
            'analyzer': TextStructureAnalyzerTool(),
            'extractor': EntityExtractorTool()
        }
    
    def _create_analysis_patterns(self) -> Dict[str, Any]:
        """Create text analysis patterns."""
        patterns = {
            'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'phone': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'url': r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w*))?)?',
            'hashtag': r'#\w+',
            'mention': r'@\w+',
            'currency': r'\$\d+(?:\.\d{2})?',
            'date': r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b',
            'time': r'\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|am|pm)?\b'
        }
        
        return {name: re.compile(pattern) for name, pattern in patterns.items()}
    
    def _register_text_tools(self):
        """Register text processing tools with the framework."""
        try:
            from agentic_framework.tools.registry import ToolRegistry
            
            registry = ToolRegistry()
            for name, tool in self.text_tools.items():
                # Only register if tool has the required protocol methods
                if hasattr(tool, 'metadata') and hasattr(tool, 'execute'):
                    registry.register(name, tool)
                    self.logger.debug(f"Registered text tool: {name}", tool='registry')
        except Exception as e:
            # Registry registration is optional - tools can still work without it
            self.logger.warning(f"Could not register tools with registry: {e}", tool='registry')
    
    @timing(threshold_warning=2.0, threshold_critical=5.0)
    @retry(config_key='retry_config')
    @memory_managed(config_key='memory_config')
    @cache_result(config_key='cache_config')
    async def _perceive_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Perceive and analyze text content."""
        
        self.logger.info("Starting text perception stage", tool='perceiver', trace_id=trace_id)
        
        # Decision point: Choose text analysis strategy
        decision_point = DecisionPoint(
            id="text_analysis_strategy",
            description="Choose text analysis strategy",
            type="strategy_selection"
        )
        
        options = [
            Option(id="basic_analysis", description="Basic text analysis with patterns"),
            Option(id="nlp_analysis", description="Advanced NLP analysis", requires_llm=True),
            Option(id="hybrid_analysis", description="Combined basic and NLP analysis", requires_llm=True)
        ]
        
        # Filter options based on capabilities
        available_options = [opt for opt in options if not opt.requires_llm or self.has_llm]
        chosen_option = available_options[0]  # Use basic analysis as default
        
        # Analyze text content
        text_content = context.input_data
        analysis_result = await self._analyze_text_content(text_content)
        
        result = {
            'text_analysis': analysis_result,
            'strategy_used': chosen_option.id,
            'content_length': len(text_content),
            'word_count': len(text_content.split()),
            'sentence_count': len([s for s in text_content.split('.') if s.strip()])
        }
        
        self.logger.info(f"Text perception complete: {result['word_count']} words analyzed", 
                        tool='perceiver', strategy=chosen_option.id)
        
        return context.with_stage_result('perceive', result)
    
    async def _analyze_text_content(self, text: str) -> Dict[str, Any]:
        """Analyze text content using various techniques."""
        analysis = {
            'entities': {},
            'patterns': {},
            'statistics': {},
            'structure': {}
        }
        
        # Extract entities using patterns
        for pattern_name, pattern in self.analysis_patterns.items():
            matches = pattern.findall(text)
            if matches:
                analysis['entities'][pattern_name] = matches
        
        # Basic text statistics
        words = text.split()
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        
        analysis['statistics'] = {
            'character_count': len(text),
            'word_count': len(words),
            'sentence_count': len(sentences),
            'paragraph_count': len(paragraphs),
            'avg_word_length': sum(len(word) for word in words) / len(words) if words else 0,
            'avg_sentence_length': len(words) / len(sentences) if sentences else 0
        }
        
        # Text structure analysis
        analysis['structure'] = {
            'has_title': self._detect_title(text),
            'has_headers': self._detect_headers(text),
            'has_lists': self._detect_lists(text),
            'has_code': self._detect_code_blocks(text),
            'language_indicators': self._detect_language_indicators(text)
        }
        
        # Word frequency analysis
        word_freq = Counter(word.lower().strip(string.punctuation) for word in words)
        analysis['patterns']['word_frequency'] = dict(word_freq.most_common(10))
        
        return analysis
    
    def _detect_title(self, text: str) -> bool:
        """Detect if text has a title structure."""
        lines = text.split('\n')
        if not lines:
            return False
        
        first_line = lines[0].strip()
        return (len(first_line) < 100 and 
                not first_line.endswith('.') and 
                len(first_line.split()) <= 10)
    
    def _detect_headers(self, text: str) -> bool:
        """Detect if text has header structures."""
        header_patterns = [
            r'^#{1,6}\s+.+$',  # Markdown headers
            r'^.+\n[=-]+$',    # Underlined headers
            r'^\d+\.\s+.+$'    # Numbered headers
        ]
        
        return any(re.search(pattern, text, re.MULTILINE) for pattern in header_patterns)
    
    def _detect_lists(self, text: str) -> bool:
        """Detect if text contains list structures."""
        list_patterns = [
            r'^\s*[-*+]\s+.+$',     # Bullet lists
            r'^\s*\d+\.\s+.+$',     # Numbered lists
            r'^\s*[a-zA-Z]\.\s+.+$' # Lettered lists
        ]
        
        return any(re.search(pattern, text, re.MULTILINE) for pattern in list_patterns)
    
    def _detect_code_blocks(self, text: str) -> bool:
        """Detect if text contains code blocks."""
        code_patterns = [
            r'```[\s\S]*?```',      # Markdown code blocks
            r'`[^`]+`',             # Inline code
            r'^\s{4,}.+$',          # Indented code
            r'<code>[\s\S]*?</code>' # HTML code tags
        ]
        
        return any(re.search(pattern, text, re.MULTILINE) for pattern in code_patterns)
    
    def _detect_language_indicators(self, text: str) -> List[str]:
        """Detect programming language indicators in text."""
        language_keywords = {
            'python': ['def ', 'import ', 'class ', 'if __name__', 'print('],
            'javascript': ['function ', 'const ', 'let ', 'var ', 'console.log'],
            'java': ['public class', 'public static void', 'System.out'],
            'html': ['<html>', '<div>', '<span>', '<!DOCTYPE'],
            'css': ['{', '}', 'color:', 'font-size:', 'margin:'],
            'sql': ['SELECT ', 'FROM ', 'WHERE ', 'INSERT ', 'UPDATE ']
        }
        
        detected_languages = []
        text_lower = text.lower()
        
        for language, keywords in language_keywords.items():
            if any(keyword.lower() in text_lower for keyword in keywords):
                detected_languages.append(language)
        
        return detected_languages
    
    async def _plan_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Plan text processing operations."""
        
        self.logger.info("Starting text planning stage", tool='planner', trace_id=trace_id)
        
        perceive_result = context.get_stage_result('perceive', {})
        text_analysis = perceive_result.get('text_analysis', {})
        
        # Create processing plan based on analysis
        processing_plan = []
        
        # Always include basic analysis
        processing_plan.append({
            'id': 'basic_analysis',
            'operation': 'analyze_structure',
            'tool': 'analyzer',
            'priority': 1.0,
            'estimated_time': 0.1
        })
        
        # Add sentiment analysis if text seems like natural language
        word_count = perceive_result.get('word_count', 0)
        if word_count > 10:
            processing_plan.append({
                'id': 'sentiment_analysis',
                'operation': 'analyze_sentiment',
                'tool': 'sentiment',
                'priority': 0.8,
                'estimated_time': 0.2
            })
        
        # Add entity extraction if entities were found
        entities = text_analysis.get('entities', {})
        if entities:
            processing_plan.append({
                'id': 'entity_extraction',
                'operation': 'extract_entities',
                'tool': 'extractor',
                'priority': 0.9,
                'estimated_time': 0.15
            })
        
        # Add tokenization for detailed analysis
        processing_plan.append({
            'id': 'tokenization',
            'operation': 'tokenize_text',
            'tool': 'tokenizer',
            'priority': 0.7,
            'estimated_time': 0.1
        })
        
        result = {
            'processing_plan': processing_plan,
            'total_operations': len(processing_plan),
            'estimated_total_time': sum(item['estimated_time'] for item in processing_plan)
        }
        
        self.logger.info(f"Text planning complete: {len(processing_plan)} operations planned", 
                        tool='planner')
        
        return context.with_stage_result('plan', result)
    
    async def _reason_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Reason about text processing strategy."""
        
        self.logger.info("Starting text reasoning stage", tool='reasoner', trace_id=trace_id)
        
        plan_result = context.get_stage_result('plan', {})
        processing_plan = plan_result.get('processing_plan', [])
        
        # Optimize processing plan
        optimized_plan = []
        for item in processing_plan:
            optimized_item = {
                **item,
                'parallel_eligible': item['operation'] in ['analyze_sentiment', 'extract_entities', 'tokenize_text']
            }
            optimized_plan.append(optimized_item)
        
        result = {
            'optimized_plan': optimized_plan,
            'optimization_applied': True,
            'reasoning': "Grouped independent text operations for parallel processing"
        }
        
        self.logger.info("Text reasoning complete: processing plan optimized", tool='reasoner')
        
        return context.with_stage_result('reason', result)
    
    async def _act_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Execute text processing operations."""
        
        self.logger.info("Starting text action stage", tool='actor', trace_id=trace_id)
        
        reason_result = context.get_stage_result('reason', {})
        optimized_plan = reason_result.get('optimized_plan', [])
        
        # Execute text processing operations
        processing_results = []
        text_content = context.input_data
        
        for item in optimized_plan:
            try:
                result = await self._execute_text_operation(item, text_content)
                processing_results.append({
                    'id': item['id'],
                    'operation': item['operation'],
                    'result': result,
                    'success': True,
                    'tool_used': item['tool']
                })
                self.logger.debug(f"Executed {item['operation']}", tool='actor')
                
            except Exception as e:
                processing_results.append({
                    'id': item['id'],
                    'operation': item['operation'],
                    'error': str(e),
                    'success': False,
                    'tool_used': item['tool']
                })
                self.logger.error(f"Failed to execute {item['operation']}: {e}", tool='actor')
        
        result = {
            'processing_results': processing_results,
            'total_processed': len(processing_results),
            'successful': sum(1 for r in processing_results if r['success']),
            'failed': sum(1 for r in processing_results if not r['success'])
        }
        
        self.logger.info(f"Text action complete: {result['successful']}/{result['total_processed']} successful", 
                        tool='actor')
        
        return context.with_stage_result('act', result)
    
    async def _execute_text_operation(self, operation_item: Dict[str, Any], text_content: str) -> Any:
        """Execute a specific text processing operation."""
        operation = operation_item['operation']
        tool_name = operation_item['tool']
        
        if operation == 'analyze_structure':
            return await self.text_tools['analyzer'].execute(text_content)
        elif operation == 'analyze_sentiment':
            return await self.text_tools['sentiment'].execute(text_content)
        elif operation == 'extract_entities':
            return await self.text_tools['extractor'].execute(text_content)
        elif operation == 'tokenize_text':
            return await self.text_tools['tokenizer'].execute(text_content)
        else:
            raise ValueError(f"Unknown text operation: {operation}")
    
    async def _review_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Review text processing results."""
        
        self.logger.info("Starting text review stage", tool='reviewer', trace_id=trace_id)
        
        act_result = context.get_stage_result('act', {})
        processing_results = act_result.get('processing_results', [])
        
        # Review results
        review_summary = {
            'total_operations': len(processing_results),
            'successful_operations': sum(1 for r in processing_results if r['success']),
            'failed_operations': sum(1 for r in processing_results if not r['success']),
            'success_rate': 0.0,
            'quality_score': 0.0
        }
        
        if review_summary['total_operations'] > 0:
            review_summary['success_rate'] = (review_summary['successful_operations'] / 
                                            review_summary['total_operations'])
            review_summary['quality_score'] = review_summary['success_rate'] * 100
        
        # Compile comprehensive analysis
        comprehensive_analysis = self._compile_text_analysis(processing_results)
        
        result = {
            'review_summary': review_summary,
            'comprehensive_analysis': comprehensive_analysis,
            'overall_quality': 'good' if review_summary['success_rate'] >= 0.8 else 'needs_improvement'
        }
        
        self.logger.info(f"Text review complete: {review_summary['success_rate']:.1%} success rate", 
                        tool='reviewer')
        
        return context.with_stage_result('review', result)
    
    def _compile_text_analysis(self, processing_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Compile comprehensive text analysis from all processing results."""
        analysis = {
            'structure_analysis': {},
            'sentiment_analysis': {},
            'entity_analysis': {},
            'token_analysis': {}
        }
        
        for result in processing_results:
            if not result['success']:
                continue
                
            operation = result['operation']
            data = result['result']
            
            if operation == 'analyze_structure':
                analysis['structure_analysis'] = data
            elif operation == 'analyze_sentiment':
                analysis['sentiment_analysis'] = data
            elif operation == 'extract_entities':
                analysis['entity_analysis'] = data
            elif operation == 'tokenize_text':
                analysis['token_analysis'] = data
        
        return analysis
    
    async def _learn_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Learn from text processing experience."""
        
        self.logger.info("Starting text learning stage", tool='learner', trace_id=trace_id)
        
        # Gather insights from processing
        review_result = context.get_stage_result('review', {})
        comprehensive_analysis = review_result.get('comprehensive_analysis', {})
        
        # Generate learning insights
        learning_insights = {
            'text_characteristics': self._analyze_text_characteristics(comprehensive_analysis),
            'processing_effectiveness': self._analyze_processing_effectiveness(context),
            'optimization_opportunities': self._identify_optimization_opportunities(context),
            'recommendations': []
        }
        
        # Generate recommendations
        recommendations = self._generate_text_recommendations(learning_insights)
        learning_insights['recommendations'] = recommendations
        
        result = {
            'learning_insights': learning_insights,
            'knowledge_updated': True,
            'next_iteration_improvements': recommendations
        }
        
        self.logger.info(f"Text learning complete: {len(recommendations)} insights captured", 
                        tool='learner')
        
        return context.with_stage_result('learn', result)
    
    def _analyze_text_characteristics(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze characteristics of the processed text."""
        characteristics = {
            'text_type': 'unknown',
            'complexity_level': 'medium',
            'primary_content': 'mixed',
            'structure_quality': 'good'
        }
        
        structure = analysis.get('structure_analysis', {})
        if structure:
            # Determine text type based on structure
            if structure.get('has_code', False):
                characteristics['text_type'] = 'technical_documentation'
            elif structure.get('has_headers', False) and structure.get('has_lists', False):
                characteristics['text_type'] = 'structured_document'
            elif len(structure.get('language_indicators', [])) > 0:
                characteristics['text_type'] = 'code_documentation'
            else:
                characteristics['text_type'] = 'natural_language'
        
        return characteristics
    
    def _analyze_processing_effectiveness(self, context: AgentContext) -> Dict[str, Any]:
        """Analyze how effective the text processing was."""
        act_result = context.get_stage_result('act', {})
        processing_results = act_result.get('processing_results', [])
        
        effectiveness = {
            'overall_success_rate': 0.0,
            'tool_performance': {},
            'operation_performance': {}
        }
        
        if processing_results:
            successful = sum(1 for r in processing_results if r['success'])
            effectiveness['overall_success_rate'] = successful / len(processing_results)
            
            # Analyze tool performance
            tool_stats = {}
            for result in processing_results:
                tool = result['tool_used']
                if tool not in tool_stats:
                    tool_stats[tool] = {'total': 0, 'successful': 0}
                
                tool_stats[tool]['total'] += 1
                if result['success']:
                    tool_stats[tool]['successful'] += 1
            
            effectiveness['tool_performance'] = {
                tool: stats['successful'] / stats['total']
                for tool, stats in tool_stats.items()
            }
        
        return effectiveness
    
    def _identify_optimization_opportunities(self, context: AgentContext) -> List[str]:
        """Identify opportunities for optimization."""
        opportunities = []
        
        perceive_result = context.get_stage_result('perceive', {})
        word_count = perceive_result.get('word_count', 0)
        
        if word_count > 1000:
            opportunities.append("Consider chunking large texts for better processing")
        
        act_result = context.get_stage_result('act', {})
        processing_results = act_result.get('processing_results', [])
        
        failed_operations = [r for r in processing_results if not r['success']]
        if failed_operations:
            opportunities.append("Improve error handling for failed text operations")
        
        return opportunities
    
    def _generate_text_recommendations(self, insights: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on learning insights."""
        recommendations = []
        
        text_chars = insights.get('text_characteristics', {})
        text_type = text_chars.get('text_type', 'unknown')
        
        if text_type == 'technical_documentation':
            recommendations.append("Add specialized code analysis tools for better technical text processing")
        elif text_type == 'natural_language':
            recommendations.append("Consider adding advanced NLP tools for better language understanding")
        
        effectiveness = insights.get('processing_effectiveness', {})
        success_rate = effectiveness.get('overall_success_rate', 0)
        
        if success_rate < 0.8:
            recommendations.append("Improve tool reliability and error handling")
        
        opportunities = insights.get('optimization_opportunities', [])
        recommendations.extend(opportunities)
        
        return recommendations

