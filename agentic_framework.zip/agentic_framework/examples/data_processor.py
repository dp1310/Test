"""
Data analysis pipeline using the agentic framework.

This example demonstrates how to build a data processing and analysis pipeline
with statistical analysis, data validation, and insights generation.
"""

import asyncio
import json
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
from collections import Counter
import statistics

from agentic_framework import (
    AgenticPipelineController, 
    AgentContext, 
    DecisionPoint, 
    Option, 
    Decision,
    get_logger,
    timing,
    retry,
    memory_managed,
    cache_result
)
from agentic_framework.core.data_structures import Event


class DataPipelineController(AgenticPipelineController):
    """Data analysis pipeline using agentic framework."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Data-specific components
        self.data_tools = self._create_data_tools()
        self.validation_rules = self._create_validation_rules()
        self.logger = get_logger(f"DataProcessor.{self.agent_id}")
        
        # Register data processing tools
        self._register_data_tools()
    
    def _create_data_tools(self) -> Dict[str, Any]:
        """Create data processing tools."""
        from agentic_framework.tools.data_processing_tools import (
            DataValidatorTool,
            DataAnalyzerTool,
            DataTransformerTool,
            DataInsightsGeneratorTool,
            DataParserTool
        )
        
        return {
            'validator': DataValidatorTool(),
            'analyzer': DataAnalyzerTool(),
            'transformer': DataTransformerTool(),
            'parser': DataParserTool(),
            'insights': DataInsightsGeneratorTool()
        }
    
    def _create_validation_rules(self) -> Dict[str, Any]:
        """Create data validation rules."""
        return {
            'numeric': {
                'type_check': lambda x: isinstance(x, (int, float)),
                'range_check': lambda x, min_val=None, max_val=None: (
                    (min_val is None or x >= min_val) and 
                    (max_val is None or x <= max_val)
                ),
                'not_null': lambda x: x is not None
            },
            'string': {
                'type_check': lambda x: isinstance(x, str),
                'length_check': lambda x, min_len=0, max_len=None: (
                    len(x) >= min_len and (max_len is None or len(x) <= max_len)
                ),
                'not_empty': lambda x: bool(x.strip()) if isinstance(x, str) else False
            },
            'list': {
                'type_check': lambda x: isinstance(x, list),
                'length_check': lambda x, min_len=0, max_len=None: (
                    len(x) >= min_len and (max_len is None or len(x) <= max_len)
                ),
                'not_empty': lambda x: len(x) > 0
            }
        }
    
    def _register_data_tools(self):
        """Register data processing tools with the framework."""
        try:
            from agentic_framework.tools.registry import ToolRegistry
            
            registry = ToolRegistry()
            for name, tool in self.data_tools.items():
                # Only register if tool has the required protocol methods
                if hasattr(tool, 'metadata') and hasattr(tool, 'execute'):
                    registry.register(name, tool)
                    self.logger.debug(f"Registered data tool: {name}", tool='registry')
        except Exception as e:
            # Registry registration is optional - tools can still work without it
            self.logger.warning(f"Could not register tools with registry: {e}", tool='registry')
    
    @timing(threshold_warning=3.0, threshold_critical=10.0)
    @retry(config_key='retry_config')
    @memory_managed(config_key='memory_config')
    @cache_result(config_key='cache_config')
    async def _perceive_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Perceive and understand data structure and content."""
        
        self.logger.info("Starting data perception stage", tool='perceiver', trace_id=trace_id)
        
        # Parse input data
        data_content = await self._parse_input_data(context.input_data)
        
        # Analyze data structure
        structure_analysis = await self._analyze_data_structure(data_content)
        
        # Detect data types and patterns
        type_analysis = await self._analyze_data_types(data_content)
        
        result = {
            'parsed_data': data_content,
            'structure_analysis': structure_analysis,
            'type_analysis': type_analysis,
            'data_size': self._calculate_data_size(data_content),
            'data_quality_preview': await self._preview_data_quality(data_content)
        }
        
        self.logger.info(f"Data perception complete: {result['data_size']['total_records']} records analyzed", 
                        tool='perceiver')
        
        return context.with_stage_result('perceive', result)
    
    async def _parse_input_data(self, input_data: Any) -> Any:
        """Parse input data into a structured format."""
        if isinstance(input_data, str):
            # Try to parse as JSON
            try:
                return json.loads(input_data)
            except json.JSONDecodeError:
                # Try to parse as CSV-like data
                lines = input_data.strip().split('\n')
                if len(lines) > 1:
                    headers = [h.strip() for h in lines[0].split(',')]
                    data = []
                    for line in lines[1:]:
                        values = [v.strip() for v in line.split(',')]
                        if len(values) == len(headers):
                            row = dict(zip(headers, values))
                            # Try to convert numeric values
                            for key, value in row.items():
                                try:
                                    if '.' in value:
                                        row[key] = float(value)
                                    else:
                                        row[key] = int(value)
                                except ValueError:
                                    pass  # Keep as string
                            data.append(row)
                    return data
                else:
                    return {'raw_text': input_data}
        
        return input_data
    
    async def _analyze_data_structure(self, data: Any) -> Dict[str, Any]:
        """Analyze the structure of the data."""
        structure = {
            'data_type': type(data).__name__,
            'is_tabular': False,
            'is_hierarchical': False,
            'is_time_series': False,
            'schema': {}
        }
        
        if isinstance(data, list):
            if data and isinstance(data[0], dict):
                structure['is_tabular'] = True
                # Analyze schema from first few records
                sample_size = min(10, len(data))
                all_keys = set()
                for record in data[:sample_size]:
                    all_keys.update(record.keys())
                
                structure['schema'] = {
                    'columns': list(all_keys),
                    'column_count': len(all_keys),
                    'record_count': len(data)
                }
                
                # Check for time series indicators
                time_indicators = ['date', 'time', 'timestamp', 'created_at', 'updated_at']
                has_time_column = any(
                    any(indicator in col.lower() for indicator in time_indicators)
                    for col in all_keys
                )
                structure['is_time_series'] = has_time_column
        
        elif isinstance(data, dict):
            structure['is_hierarchical'] = True
            structure['schema'] = {
                'keys': list(data.keys()),
                'key_count': len(data),
                'nested_levels': self._calculate_nesting_depth(data)
            }
        
        return structure
    
    def _calculate_nesting_depth(self, obj: Any, current_depth: int = 0) -> int:
        """Calculate the maximum nesting depth of a dictionary or list."""
        if isinstance(obj, dict):
            if not obj:
                return current_depth
            return max(self._calculate_nesting_depth(value, current_depth + 1) 
                      for value in obj.values())
        elif isinstance(obj, list):
            if not obj:
                return current_depth
            return max(self._calculate_nesting_depth(item, current_depth + 1) 
                      for item in obj)
        else:
            return current_depth
    
    async def _analyze_data_types(self, data: Any) -> Dict[str, Any]:
        """Analyze data types and patterns in the data."""
        type_analysis = {
            'column_types': {},
            'data_patterns': {},
            'missing_values': {},
            'unique_values': {}
        }
        
        if isinstance(data, list) and data and isinstance(data[0], dict):
            # Tabular data analysis
            columns = data[0].keys()
            
            for column in columns:
                values = [record.get(column) for record in data]
                
                # Analyze types
                type_counts = Counter(type(v).__name__ for v in values if v is not None)
                dominant_type = type_counts.most_common(1)[0][0] if type_counts else 'NoneType'
                
                # Count missing values
                missing_count = sum(1 for v in values if v is None or v == '')
                
                # Count unique values
                unique_count = len(set(v for v in values if v is not None))
                
                type_analysis['column_types'][column] = {
                    'dominant_type': dominant_type,
                    'type_distribution': dict(type_counts),
                    'missing_count': missing_count,
                    'missing_percentage': (missing_count / len(values)) * 100,
                    'unique_count': unique_count,
                    'uniqueness_percentage': (unique_count / len(values)) * 100 if values else 0
                }
                
                # Analyze numeric columns
                if dominant_type in ['int', 'float']:
                    numeric_values = [v for v in values if isinstance(v, (int, float))]
                    if numeric_values:
                        type_analysis['column_types'][column].update({
                            'min_value': min(numeric_values),
                            'max_value': max(numeric_values),
                            'mean_value': statistics.mean(numeric_values),
                            'median_value': statistics.median(numeric_values),
                            'std_deviation': statistics.stdev(numeric_values) if len(numeric_values) > 1 else 0
                        })
        
        return type_analysis
    
    def _calculate_data_size(self, data: Any) -> Dict[str, int]:
        """Calculate various size metrics for the data."""
        size_info = {
            'total_records': 0,
            'total_fields': 0,
            'memory_estimate': 0
        }
        
        if isinstance(data, list):
            size_info['total_records'] = len(data)
            if data and isinstance(data[0], dict):
                size_info['total_fields'] = len(data[0]) * len(data)
        elif isinstance(data, dict):
            size_info['total_records'] = 1
            size_info['total_fields'] = len(data)
        
        # Rough memory estimate (in bytes)
        size_info['memory_estimate'] = len(str(data).encode('utf-8'))
        
        return size_info
    
    async def _preview_data_quality(self, data: Any) -> Dict[str, Any]:
        """Preview data quality issues."""
        quality_preview = {
            'completeness_score': 100.0,
            'consistency_issues': [],
            'potential_outliers': [],
            'data_quality_score': 100.0
        }
        
        if isinstance(data, list) and data and isinstance(data[0], dict):
            total_cells = 0
            missing_cells = 0
            
            for record in data:
                for key, value in record.items():
                    total_cells += 1
                    if value is None or value == '':
                        missing_cells += 1
            
            if total_cells > 0:
                quality_preview['completeness_score'] = ((total_cells - missing_cells) / total_cells) * 100
                quality_preview['data_quality_score'] = quality_preview['completeness_score']
        
        return quality_preview
    
    async def _plan_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Plan data processing operations."""
        
        self.logger.info("Starting data planning stage", tool='planner', trace_id=trace_id)
        
        perceive_result = context.get_stage_result('perceive', {})
        structure_analysis = perceive_result.get('structure_analysis', {})
        type_analysis = perceive_result.get('type_analysis', {})
        
        # Create processing plan based on data characteristics
        processing_plan = []
        
        # Always include data validation
        processing_plan.append({
            'id': 'data_validation',
            'operation': 'validate_data',
            'tool': 'validator',
            'priority': 1.0,
            'estimated_time': 0.2
        })
        
        # Add statistical analysis for tabular data
        if structure_analysis.get('is_tabular', False):
            processing_plan.append({
                'id': 'statistical_analysis',
                'operation': 'analyze_statistics',
                'tool': 'analyzer',
                'priority': 0.9,
                'estimated_time': 0.3
            })
        
        # Add data transformation if needed
        quality_preview = perceive_result.get('data_quality_preview', {})
        if quality_preview.get('completeness_score', 100) < 90:
            processing_plan.append({
                'id': 'data_cleaning',
                'operation': 'clean_data',
                'tool': 'transformer',
                'priority': 0.8,
                'estimated_time': 0.4
            })
        
        # Add insights generation
        processing_plan.append({
            'id': 'insights_generation',
            'operation': 'generate_insights',
            'tool': 'insights',
            'priority': 0.7,
            'estimated_time': 0.3
        })
        
        result = {
            'processing_plan': processing_plan,
            'total_operations': len(processing_plan),
            'estimated_total_time': sum(item['estimated_time'] for item in processing_plan)
        }
        
        self.logger.info(f"Data planning complete: {len(processing_plan)} operations planned", 
                        tool='planner')
        
        return context.with_stage_result('plan', result)
    
    async def _reason_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Reason about data processing strategy."""
        
        self.logger.info("Starting data reasoning stage", tool='reasoner', trace_id=trace_id)
        
        plan_result = context.get_stage_result('plan', {})
        processing_plan = plan_result.get('processing_plan', [])
        
        # Optimize processing plan
        optimized_plan = []
        for item in processing_plan:
            optimized_item = {
                **item,
                'parallel_eligible': item['operation'] in ['analyze_statistics', 'generate_insights']
            }
            optimized_plan.append(optimized_item)
        
        result = {
            'optimized_plan': optimized_plan,
            'optimization_applied': True,
            'reasoning': "Sequenced validation and cleaning before analysis and insights"
        }
        
        self.logger.info("Data reasoning complete: processing plan optimized", tool='reasoner')
        
        return context.with_stage_result('reason', result)
    
    async def _act_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Execute data processing operations."""
        
        self.logger.info("Starting data action stage", tool='actor', trace_id=trace_id)
        
        reason_result = context.get_stage_result('reason', {})
        optimized_plan = reason_result.get('optimized_plan', [])
        perceive_result = context.get_stage_result('perceive', {})
        parsed_data = perceive_result.get('parsed_data')
        
        # Execute data processing operations
        processing_results = []
        current_data = parsed_data
        
        for item in optimized_plan:
            try:
                result = await self._execute_data_operation(item, current_data, context)
                
                # Update current_data if operation transforms it
                if item['operation'] == 'clean_data' and result.get('cleaned_data'):
                    current_data = result['cleaned_data']
                
                processing_results.append({
                    'id': item['id'],
                    'operation': item['operation'],
                    'result': result,
                    'success': True,
                    'tool_used': item['tool']
                })
                self.logger.debug(f"Executed {item['operation']}", tool='actor')
                
            except Exception as e:
                processing_results.append({
                    'id': item['id'],
                    'operation': item['operation'],
                    'error': str(e),
                    'success': False,
                    'tool_used': item['tool']
                })
                self.logger.error(f"Failed to execute {item['operation']}: {e}", tool='actor')
        
        result = {
            'processing_results': processing_results,
            'total_processed': len(processing_results),
            'successful': sum(1 for r in processing_results if r['success']),
            'failed': sum(1 for r in processing_results if not r['success']),
            'final_data': current_data
        }
        
        self.logger.info(f"Data action complete: {result['successful']}/{result['total_processed']} successful", 
                        tool='actor')
        
        return context.with_stage_result('act', result)
    
    async def _execute_data_operation(self, operation_item: Dict[str, Any], data: Any, context: AgentContext) -> Any:
        """Execute a specific data processing operation."""
        operation = operation_item['operation']
        tool_name = operation_item['tool']
        
        if operation == 'validate_data':
            return await self.data_tools['validator'].execute(data)
        elif operation == 'analyze_statistics':
            return await self.data_tools['analyzer'].execute(data)
        elif operation == 'clean_data':
            return await self.data_tools['transformer'].execute(data)
        elif operation == 'generate_insights':
            # Pass context for more comprehensive insights
            return await self.data_tools['insights'].execute(data, context=context)
        else:
            raise ValueError(f"Unknown data operation: {operation}")
    
    async def _review_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Review data processing results."""
        
        self.logger.info("Starting data review stage", tool='reviewer', trace_id=trace_id)
        
        act_result = context.get_stage_result('act', {})
        processing_results = act_result.get('processing_results', [])
        
        # Review results
        review_summary = {
            'total_operations': len(processing_results),
            'successful_operations': sum(1 for r in processing_results if r['success']),
            'failed_operations': sum(1 for r in processing_results if not r['success']),
            'success_rate': 0.0,
            'data_quality_improvement': 0.0
        }
        
        if review_summary['total_operations'] > 0:
            review_summary['success_rate'] = (review_summary['successful_operations'] / 
                                            review_summary['total_operations'])
        
        # Compile comprehensive analysis
        comprehensive_analysis = self._compile_data_analysis(processing_results)
        
        result = {
            'review_summary': review_summary,
            'comprehensive_analysis': comprehensive_analysis,
            'overall_quality': 'good' if review_summary['success_rate'] >= 0.8 else 'needs_improvement'
        }
        
        self.logger.info(f"Data review complete: {review_summary['success_rate']:.1%} success rate", 
                        tool='reviewer')
        
        return context.with_stage_result('review', result)
    
    def _compile_data_analysis(self, processing_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Compile comprehensive data analysis from all processing results."""
        analysis = {
            'validation_results': {},
            'statistical_analysis': {},
            'data_cleaning_results': {},
            'insights': {}
        }
        
        for result in processing_results:
            if not result['success']:
                continue
                
            operation = result['operation']
            data = result['result']
            
            if operation == 'validate_data':
                analysis['validation_results'] = data
            elif operation == 'analyze_statistics':
                analysis['statistical_analysis'] = data
            elif operation == 'clean_data':
                analysis['data_cleaning_results'] = data
            elif operation == 'generate_insights':
                analysis['insights'] = data
        
        return analysis
    
    async def _learn_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """Learn from data processing experience."""
        
        self.logger.info("Starting data learning stage", tool='learner', trace_id=trace_id)
        
        # Gather insights from processing
        review_result = context.get_stage_result('review', {})
        comprehensive_analysis = review_result.get('comprehensive_analysis', {})
        
        # Generate learning insights
        learning_insights = {
            'data_characteristics': self._analyze_data_characteristics(comprehensive_analysis),
            'processing_effectiveness': self._analyze_processing_effectiveness(context),
            'quality_improvements': self._analyze_quality_improvements(comprehensive_analysis),
            'recommendations': []
        }
        
        # Generate recommendations
        recommendations = self._generate_data_recommendations(learning_insights)
        learning_insights['recommendations'] = recommendations
        
        result = {
            'learning_insights': learning_insights,
            'knowledge_updated': True,
            'next_iteration_improvements': recommendations
        }
        
        self.logger.info(f"Data learning complete: {len(recommendations)} insights captured", 
                        tool='learner')
        
        return context.with_stage_result('learn', result)
    
    def _analyze_data_characteristics(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze characteristics of the processed data."""
        characteristics = {
            'data_complexity': 'medium',
            'data_quality': 'good',
            'primary_data_type': 'mixed',
            'processing_difficulty': 'medium'
        }
        
        validation_results = analysis.get('validation_results', {})
        if validation_results:
            overall_validity = validation_results.get('overall_validity_score', 50)
            if overall_validity >= 80:
                characteristics['data_quality'] = 'high'
            elif overall_validity >= 60:
                characteristics['data_quality'] = 'medium'
            else:
                characteristics['data_quality'] = 'low'
        
        return characteristics
    
    def _analyze_processing_effectiveness(self, context: AgentContext) -> Dict[str, Any]:
        """Analyze how effective the data processing was."""
        act_result = context.get_stage_result('act', {})
        processing_results = act_result.get('processing_results', [])
        
        effectiveness = {
            'overall_success_rate': 0.0,
            'tool_performance': {},
            'operation_performance': {}
        }
        
        if processing_results:
            successful = sum(1 for r in processing_results if r['success'])
            effectiveness['overall_success_rate'] = successful / len(processing_results)
            
            # Analyze tool performance
            tool_stats = {}
            for result in processing_results:
                tool = result['tool_used']
                if tool not in tool_stats:
                    tool_stats[tool] = {'total': 0, 'successful': 0}
                
                tool_stats[tool]['total'] += 1
                if result['success']:
                    tool_stats[tool]['successful'] += 1
            
            effectiveness['tool_performance'] = {
                tool: stats['successful'] / stats['total']
                for tool, stats in tool_stats.items()
            }
        
        return effectiveness
    
    def _analyze_quality_improvements(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze data quality improvements made during processing."""
        improvements = {
            'validation_improvements': 0,
            'cleaning_improvements': 0,
            'overall_improvement': 0
        }
        
        cleaning_results = analysis.get('data_cleaning_results', {})
        if cleaning_results:
            improvements['cleaning_improvements'] = cleaning_results.get('improvement_score', 0)
        
        validation_results = analysis.get('validation_results', {})
        if validation_results:
            improvements['validation_improvements'] = validation_results.get('overall_validity_score', 0)
        
        improvements['overall_improvement'] = (
            improvements['validation_improvements'] + improvements['cleaning_improvements']
        ) / 2
        
        return improvements
    
    def _generate_data_recommendations(self, insights: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on learning insights."""
        recommendations = []
        
        data_chars = insights.get('data_characteristics', {})
        data_quality = data_chars.get('data_quality', 'medium')
        
        if data_quality == 'low':
            recommendations.append("Implement more robust data validation and cleaning procedures")
        
        effectiveness = insights.get('processing_effectiveness', {})
        success_rate = effectiveness.get('overall_success_rate', 0)
        
        if success_rate < 0.8:
            recommendations.append("Improve error handling and tool reliability")
        
        quality_improvements = insights.get('quality_improvements', {})
        overall_improvement = quality_improvements.get('overall_improvement', 0)
        
        if overall_improvement < 50:
            recommendations.append("Consider additional data preprocessing steps")
        
        return recommendations

