"""
Configuration management system with YAML and environment variable support.

This module provides a comprehensive configuration management system that supports
YAML files, environment variable overrides, and configuration validation with
extensive logging and error handling capabilities.

Key Features:
    - YAML configuration file loading with validation
    - Environment variable overrides with automatic type conversion
    - Nested configuration access using dot notation
    - Comprehensive logging for debugging and monitoring
    - Robust error handling with detailed error messages
    - Automatic path resolution for framework configuration files

Example:
    Basic usage:
        >>> config_manager = ConfigurationManager("config.yaml")
        >>> timeout = config_manager.get("timeout", 30)
        >>> config_manager.set("debug", True)
    
    Environment variable overrides:
        >>> os.environ["AGENTIC_TIMEOUT"] = "120"
        >>> config_manager = ConfigurationManager("config.yaml")
        >>> # timeout will be 120 from environment variable
    
    Framework configuration:
        >>> config_path = get_framework_config_path("framework_config.yaml")
        >>> config_manager = initialize_config(config_path)

Author: Agentic Framework Team
Version: 1.0.0
"""

import os
import yaml
import logging
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass, field
from pathlib import Path

# Initialize module logger
logger = logging.getLogger(__name__)


@dataclass
class ConfigurationManager:
    """
    Comprehensive configuration management system for the Agentic Framework.
    
    This class handles loading YAML configuration files, applying environment variable
    overrides, and providing a unified interface for accessing configuration values
    throughout the framework.
    
    Attributes:
        config_file (Optional[str]): Path to the YAML configuration file to load.
            If None, only environment variables will be used for configuration.
        config (Dict[str, Any]): Internal dictionary storing all configuration values.
            Automatically populated from YAML file and environment variables.
        env_prefix (str): Prefix for environment variables that override config values.
            Default is "AGENTIC_" (e.g., AGENTIC_TIMEOUT, AGENTIC_DEBUG).
    
    Environment Variable Mappings:
        The following environment variables are automatically mapped to config paths:
        - AGENTIC_TIMEOUT -> timeout
        - AGENTIC_DEBUG -> debug
        - AGENTIC_AGENT_ID -> agent_id
        - AGENTIC_MAX_ROLLBACK_ATTEMPTS -> max_rollback_attempts
        - AGENTIC_MAX_WORKERS -> scalability_config.max_workers
        - AGENTIC_BATCH_SIZE -> scalability_config.batch_size
        - AGENTIC_MEMORY_WARNING_THRESHOLD -> memory_config.warning_threshold
        - AGENTIC_MEMORY_CRITICAL_THRESHOLD -> memory_config.critical_threshold
        - AGENTIC_MIN_WORKERS -> concurrency_config.min_workers
        - AGENTIC_SCALE_FACTOR -> concurrency_config.scale_factor
    
    Example:
        >>> # Load configuration from file with environment overrides
        >>> config = ConfigurationManager("framework_config.yaml")
        >>> 
        >>> # Access configuration values
        >>> timeout = config.get("timeout", 30)
        >>> debug_mode = config.get("debug", False)
        >>> 
        >>> # Set configuration values programmatically
        >>> config.set("custom_setting", "value")
        >>> config.update({"batch_size": 100, "workers": 5})
    """
    
    config_file: Optional[str] = None
    config: Dict[str, Any] = field(default_factory=dict)
    env_prefix: str = "AGENTIC_"
    
    def __post_init__(self):
        """
        Initialize configuration after object creation.
        
        This method is automatically called after the dataclass is instantiated.
        It performs the following initialization steps:
        1. Load configuration from YAML file if specified
        2. Apply environment variable overrides
        3. Log the initialization process for debugging
        
        Raises:
            FileNotFoundError: If the specified config file doesn't exist
            ValueError: If the YAML file contains invalid syntax
        """
        logger.info(f"Initializing ConfigurationManager with prefix '{self.env_prefix}'")
        
        # Load configuration from file if specified
        if self.config_file:
            logger.info(f"Loading configuration from file: {self.config_file}")
            self.load_config(self.config_file)
        else:
            logger.info("No configuration file specified, using environment variables only")
        
        # Apply environment variable overrides
        logger.debug("Applying environment variable overrides")
        self._apply_env_overrides()
        
        logger.info(f"Configuration initialization complete. Loaded {len(self.config)} top-level keys")
    
    def load_config(self, config_file: str) -> None:
        """
        Load configuration from a YAML file with comprehensive error handling.
        
        This method loads and parses a YAML configuration file, replacing any
        existing configuration. The file is validated for proper YAML syntax
        and the loading process is logged for debugging purposes.
        
        Args:
            config_file (str): Path to the YAML configuration file to load.
                Can be absolute or relative path.
        
        Raises:
            FileNotFoundError: If the specified configuration file doesn't exist.
            ValueError: If the YAML file contains invalid syntax or cannot be parsed.
            PermissionError: If the file cannot be read due to permission issues.
        
        Example:
            >>> config_manager = ConfigurationManager()
            >>> config_manager.load_config("./config/framework_config.yaml")
        """
        config_path = Path(config_file)
        logger.debug(f"Attempting to load configuration from: {config_path.absolute()}")
        
        # Validate file existence
        if not config_path.exists():
            error_msg = f"Configuration file not found: {config_file}"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)
        
        # Validate file is readable
        if not config_path.is_file():
            error_msg = f"Configuration path is not a file: {config_file}"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        try:
            # Load and parse YAML file
            logger.debug(f"Reading YAML file: {config_path}")
            with open(config_path, 'r', encoding='utf-8') as f:
                loaded_config = yaml.safe_load(f)
                
            # Handle empty or None YAML files
            self.config = loaded_config or {}
            
            logger.info(f"Successfully loaded configuration from {config_file}")
            logger.debug(f"Configuration contains {len(self.config)} top-level keys: {list(self.config.keys())}")
            
        except yaml.YAMLError as e:
            error_msg = f"Invalid YAML syntax in configuration file {config_file}: {e}"
            logger.error(error_msg)
            raise ValueError(error_msg)
        except PermissionError as e:
            error_msg = f"Permission denied reading configuration file {config_file}: {e}"
            logger.error(error_msg)
            raise
        except Exception as e:
            error_msg = f"Unexpected error loading configuration file {config_file}: {e}"
            logger.error(error_msg)
            raise ValueError(error_msg)
    
    def _apply_env_overrides(self) -> None:
        """
        Apply environment variable overrides to configuration values.
        
        This method scans for environment variables with the configured prefix
        and automatically overrides corresponding configuration values. Environment
        variables take precedence over YAML file values, allowing for runtime
        configuration without modifying files.
        
        The method performs automatic type conversion for environment variable
        values (string -> bool/int/float) and supports nested configuration
        paths using dot notation.
        
        Environment Variable Mapping:
            Each environment variable is mapped to a specific configuration path:
            - {prefix}TIMEOUT -> timeout
            - {prefix}DEBUG -> debug
            - {prefix}AGENT_ID -> agent_id
            - {prefix}MAX_ROLLBACK_ATTEMPTS -> max_rollback_attempts
            - {prefix}MAX_WORKERS -> scalability_config.max_workers
            - {prefix}BATCH_SIZE -> scalability_config.batch_size
            - {prefix}MEMORY_WARNING_THRESHOLD -> memory_config.warning_threshold
            - {prefix}MEMORY_CRITICAL_THRESHOLD -> memory_config.critical_threshold
            - {prefix}MIN_WORKERS -> concurrency_config.min_workers
            - {prefix}SCALE_FACTOR -> concurrency_config.scale_factor
        
        Note:
            This is a private method called automatically during initialization.
            Environment variables are only applied if they exist and have non-empty values.
        """
        logger.debug(f"Scanning for environment variables with prefix: {self.env_prefix}")
        
        # Define mapping of environment variables to configuration paths
        env_mappings = {
            f"{self.env_prefix}TIMEOUT": "timeout",
            f"{self.env_prefix}DEBUG": "debug", 
            f"{self.env_prefix}AGENT_ID": "agent_id",
            f"{self.env_prefix}MAX_ROLLBACK_ATTEMPTS": "max_rollback_attempts",
            f"{self.env_prefix}MAX_WORKERS": "scalability_config.max_workers",
            f"{self.env_prefix}BATCH_SIZE": "scalability_config.batch_size",
            f"{self.env_prefix}MEMORY_WARNING_THRESHOLD": "memory_config.warning_threshold",
            f"{self.env_prefix}MEMORY_CRITICAL_THRESHOLD": "memory_config.critical_threshold",
            f"{self.env_prefix}MIN_WORKERS": "concurrency_config.min_workers",
            f"{self.env_prefix}SCALE_FACTOR": "concurrency_config.scale_factor"
        }
        
        applied_overrides = []
        
        # Process each environment variable mapping
        for env_var, config_path in env_mappings.items():
            env_value = os.getenv(env_var)
            
            if env_value is not None:
                # Convert string value to appropriate type
                converted_value = self._convert_env_value(env_value)
                
                # Apply the override to configuration
                self._set_nested_config(config_path, converted_value)
                
                # Track applied overrides for logging
                applied_overrides.append(f"{env_var}={env_value} -> {config_path}={converted_value}")
                logger.debug(f"Applied environment override: {env_var}={env_value} -> {config_path}={converted_value}")
        
        if applied_overrides:
            logger.info(f"Applied {len(applied_overrides)} environment variable overrides")
        else:
            logger.debug("No environment variable overrides found")
    
    def _set_nested_config(self, path: str, value: Any) -> None:
        """
        Set nested configuration value using dot notation path.
        
        This method allows setting deeply nested configuration values using
        a dot-separated path string. It automatically creates intermediate
        dictionary structures if they don't exist.
        
        Args:
            path (str): Dot-separated path to the configuration key.
                Examples: "timeout", "memory_config.warning_threshold", 
                         "scalability_config.max_workers"
            value (Any): The value to set at the specified path.
                Can be any JSON-serializable type (str, int, float, bool, dict, list).
        
        Example:
            >>> config_manager._set_nested_config("database.host", "localhost")
            >>> config_manager._set_nested_config("database.port", 5432)
            >>> config_manager._set_nested_config("features.enabled", True)
        
        Note:
            This is a private method used internally for environment variable
            overrides and programmatic configuration updates.
        """
        logger.debug(f"Setting nested config: {path} = {value}")
        
        # Split the path into individual keys
        keys = path.split('.')
        current = self.config
        
        # Navigate to the parent of the target key, creating intermediate dicts as needed
        for key in keys[:-1]:
            if key not in current:
                logger.debug(f"Creating intermediate config section: {key}")
                current[key] = {}
            elif not isinstance(current[key], dict):
                # Handle case where intermediate path exists but isn't a dict
                logger.warning(f"Overwriting non-dict value at path '{key}' to create nested structure")
                current[key] = {}
            current = current[key]
        
        # Set the final value
        final_key = keys[-1]
        old_value = current.get(final_key, "<not set>")
        current[final_key] = value
        
        logger.debug(f"Updated config '{path}': {old_value} -> {value}")
    
    def _convert_env_value(self, value: str) -> Union[str, int, float, bool]:
        """
        Convert environment variable string to appropriate Python type.
        
        This method performs intelligent type conversion for environment variable
        values, which are always strings by default. It attempts to convert to
        the most appropriate type in the following order:
        1. Boolean (for 'true'/'false' strings, case-insensitive)
        2. Integer (for numeric strings without decimal points)
        3. Float (for numeric strings with decimal points)
        4. String (fallback for all other values)
        
        Args:
            value (str): The environment variable value as a string.
        
        Returns:
            Union[str, int, float, bool]: The converted value in the most
                appropriate Python type.
        
        Examples:
            >>> config_manager._convert_env_value("true")
            True
            >>> config_manager._convert_env_value("42")
            42
            >>> config_manager._convert_env_value("3.14")
            3.14
            >>> config_manager._convert_env_value("hello")
            'hello'
        
        Note:
            This is a private method used internally for environment variable
            processing. The conversion is conservative and will return a string
            if the value cannot be safely converted to another type.
        """
        logger.debug(f"Converting environment value: '{value}'")
        
        # Handle empty or whitespace-only values
        if not value or not value.strip():
            logger.debug("Empty value, returning empty string")
            return ""
        
        # Normalize the value for processing
        normalized_value = value.strip()
        
        # Boolean conversion (case-insensitive)
        if normalized_value.lower() in ('true', 'false'):
            result = normalized_value.lower() == 'true'
            logger.debug(f"Converted to boolean: {result}")
            return result
        
        # Integer conversion
        try:
            result = int(normalized_value)
            logger.debug(f"Converted to integer: {result}")
            return result
        except ValueError:
            pass
        
        # Float conversion
        try:
            result = float(normalized_value)
            logger.debug(f"Converted to float: {result}")
            return result
        except ValueError:
            pass
        
        # Return as string (fallback)
        logger.debug(f"Keeping as string: '{normalized_value}'")
        return normalized_value
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value with dot notation support and comprehensive logging.
        
        This method retrieves configuration values using dot-separated paths,
        allowing access to deeply nested configuration structures. If the
        requested key doesn't exist, the default value is returned.
        
        Args:
            key (str): Dot-separated path to the configuration value.
                Examples: "timeout", "memory_config.warning_threshold",
                         "scalability_config.max_workers"
            default (Any, optional): Default value to return if the key
                doesn't exist. Defaults to None.
        
        Returns:
            Any: The configuration value at the specified path, or the
                default value if the path doesn't exist.
        
        Examples:
            >>> timeout = config_manager.get("timeout", 30)
            >>> warning_threshold = config_manager.get("memory_config.warning_threshold", 0.8)
            >>> custom_setting = config_manager.get("nonexistent.key", "default_value")
        
        Note:
            This method is safe to use with non-existent keys and will not
            raise exceptions. It logs access attempts for debugging purposes.
        """
        logger.debug(f"Getting configuration value for key: '{key}'")
        
        # Split the key into individual path components
        keys = key.split('.')
        current = self.config
        
        try:
            # Navigate through the nested structure
            for i, k in enumerate(keys):
                if not isinstance(current, dict):
                    logger.debug(f"Path '{'.'.join(keys[:i])}' is not a dictionary, cannot access '{k}'")
                    return default
                current = current[k]
            
            logger.debug(f"Successfully retrieved value for '{key}': {current}")
            return current
            
        except (KeyError, TypeError) as e:
            logger.debug(f"Key '{key}' not found in configuration, returning default: {default}")
            return default
    
    def set(self, key: str, value: Any) -> None:
        """
        Set configuration value with dot notation support and logging.
        
        This method allows setting configuration values using dot-separated
        paths, automatically creating intermediate dictionary structures
        as needed. The operation is logged for debugging and audit purposes.
        
        Args:
            key (str): Dot-separated path to the configuration key.
                Examples: "timeout", "memory_config.warning_threshold",
                         "custom_settings.feature_enabled"
            value (Any): The value to set at the specified path.
                Can be any JSON-serializable type.
        
        Examples:
            >>> config_manager.set("timeout", 60)
            >>> config_manager.set("memory_config.warning_threshold", 0.8)
            >>> config_manager.set("custom_settings.debug_mode", True)
        
        Note:
            This method will create intermediate dictionary structures
            if they don't exist, allowing you to set deeply nested values
            even if the parent structure hasn't been defined yet.
        """
        logger.info(f"Setting configuration value: '{key}' = {value}")
        self._set_nested_config(key, value)
    
    def update(self, updates: Dict[str, Any]) -> None:
        """
        Update configuration with multiple key-value pairs.
        
        This method allows batch updating of configuration values using
        a dictionary. Each key-value pair is processed using the same
        dot notation support as the set() method.
        
        Args:
            updates (Dict[str, Any]): Dictionary of configuration updates
                where keys are dot-separated paths and values are the
                new configuration values.
        
        Examples:
            >>> updates = {
            ...     "timeout": 120,
            ...     "memory_config.warning_threshold": 0.9,
            ...     "debug": True
            ... }
            >>> config_manager.update(updates)
        
        Note:
            This method processes updates sequentially and logs each
            individual update operation. If any update fails, subsequent
            updates will still be processed.
        """
        logger.info(f"Updating configuration with {len(updates)} values")
        
        for key, value in updates.items():
            try:
                self.set(key, value)
            except Exception as e:
                logger.error(f"Failed to update configuration key '{key}': {e}")
                # Continue processing other updates even if one fails
        
        logger.info("Configuration update completed")
    
    def has_key(self, key: str) -> bool:
        """
        Check if a configuration key exists using dot notation.
        
        This method checks whether a specific configuration key exists
        without retrieving its value, which is useful for conditional
        logic based on configuration presence.
        
        Args:
            key (str): Dot-separated path to check for existence.
        
        Returns:
            bool: True if the key exists, False otherwise.
        
        Examples:
            >>> if config_manager.has_key("database.host"):
            ...     host = config_manager.get("database.host")
            >>> 
            >>> if not config_manager.has_key("optional_feature.enabled"):
            ...     config_manager.set("optional_feature.enabled", False)
        """
        logger.debug(f"Checking existence of key: '{key}'")
        
        keys = key.split('.')
        current = self.config
        
        try:
            for k in keys:
                if not isinstance(current, dict) or k not in current:
                    logger.debug(f"Key '{key}' does not exist")
                    return False
                current = current[k]
            
            logger.debug(f"Key '{key}' exists")
            return True
            
        except (KeyError, TypeError):
            logger.debug(f"Key '{key}' does not exist")
            return False
    
    def get_all_keys(self, prefix: str = "") -> List[str]:
        """
        Get all configuration keys with optional prefix filtering.
        
        This method returns a list of all configuration keys in dot notation
        format, optionally filtered by a prefix. Useful for debugging and
        configuration introspection.
        
        Args:
            prefix (str, optional): Only return keys that start with this prefix.
                Defaults to "" (return all keys).
        
        Returns:
            List[str]: List of configuration keys in dot notation format.
        
        Examples:
            >>> # Get all configuration keys
            >>> all_keys = config_manager.get_all_keys()
            >>> 
            >>> # Get only memory-related configuration keys
            >>> memory_keys = config_manager.get_all_keys("memory_config")
        """
        logger.debug(f"Getting all configuration keys with prefix: '{prefix}'")
        
        def _flatten_dict(d: Dict[str, Any], parent_key: str = "") -> List[str]:
            """Recursively flatten nested dictionary to dot notation keys."""
            keys = []
            for key, value in d.items():
                full_key = f"{parent_key}.{key}" if parent_key else key
                
                if isinstance(value, dict):
                    keys.extend(_flatten_dict(value, full_key))
                else:
                    keys.append(full_key)
            
            return keys
        
        all_keys = _flatten_dict(self.config)
        
        # Filter by prefix if specified
        if prefix:
            filtered_keys = [key for key in all_keys if key.startswith(prefix)]
            logger.debug(f"Found {len(filtered_keys)} keys with prefix '{prefix}'")
            return filtered_keys
        
        logger.debug(f"Found {len(all_keys)} total configuration keys")
        return all_keys
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Get a copy of the entire configuration as a dictionary.
        
        This method returns a deep copy of the internal configuration
        dictionary, allowing safe inspection and manipulation without
        affecting the original configuration.
        
        Returns:
            Dict[str, Any]: Deep copy of the configuration dictionary.
        
        Example:
            >>> config_dict = config_manager.to_dict()
            >>> print(f"Configuration has {len(config_dict)} sections")
        """
        import copy
        logger.debug("Creating copy of configuration dictionary")
        return copy.deepcopy(self.config)
    
    def reload_config(self) -> None:
        """
        Reload configuration from the original file and reapply environment overrides.
        
        This method reloads the configuration from the original YAML file
        (if one was specified) and reapplies all environment variable overrides.
        Useful for picking up configuration changes without restarting the application.
        
        Raises:
            ValueError: If no config file was originally specified.
            FileNotFoundError: If the original config file no longer exists.
        
        Example:
            >>> config_manager.reload_config()  # Reload from original file
        """
        if not self.config_file:
            error_msg = "Cannot reload configuration: no config file was specified during initialization"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        logger.info(f"Reloading configuration from: {self.config_file}")
        
        # Clear existing configuration
        self.config.clear()
        
        # Reload from file and reapply environment overrides
        self.load_config(self.config_file)
        self._apply_env_overrides()
        
        logger.info("Configuration reloaded successfully")


def initialize_config(config_file: Optional[str] = None) -> ConfigurationManager:
    """
    Initialize a ConfigurationManager instance with optional configuration file.
    
    This is a convenience function for creating and initializing a ConfigurationManager
    instance. It provides a clean interface for framework initialization and handles
    the common use case of loading configuration from a file.
    
    Args:
        config_file (Optional[str], optional): Path to the YAML configuration file
            to load. If None, the configuration manager will only use environment
            variables for configuration. Defaults to None.
    
    Returns:
        ConfigurationManager: A fully initialized configuration manager instance
            with configuration loaded from the specified file (if provided) and
            environment variable overrides applied.
    
    Raises:
        FileNotFoundError: If the specified config file doesn't exist.
        ValueError: If the config file contains invalid YAML syntax.
    
    Examples:
        >>> # Initialize with configuration file
        >>> config = initialize_config("config/framework_config.yaml")
        >>> 
        >>> # Initialize with environment variables only
        >>> config = initialize_config()
        >>> 
        >>> # Use with framework configuration
        >>> config_path = get_framework_config_path()
        >>> config = initialize_config(config_path)
    
    Note:
        This function is the recommended way to create ConfigurationManager
        instances in application code, as it provides consistent initialization
        and error handling.
    """
    logger.info(f"Initializing configuration manager with file: {config_file or 'None (env vars only)'}")
    
    try:
        config_manager = ConfigurationManager(config_file=config_file)
        logger.info("Configuration manager initialized successfully")
        return config_manager
    except Exception as e:
        logger.error(f"Failed to initialize configuration manager: {e}")
        raise


def get_framework_config_path(config_name: str = "framework_config.yaml") -> str:
    """
    Get the absolute path to a configuration file within the framework's yaml directory.
    
    This utility function constructs the full path to configuration files stored
    in the framework's yaml directory. It automatically resolves the path relative
    to the current module location, ensuring consistent access to framework
    configuration files regardless of the calling context.
    
    Args:
        config_name (str, optional): Name of the configuration file to locate.
            Should include the .yaml extension. Defaults to "framework_config.yaml".
    
    Returns:
        str: Absolute path to the specified configuration file within the
            framework's yaml directory.
    
    Examples:
        >>> # Get path to default framework configuration
        >>> config_path = get_framework_config_path()
        >>> # Returns: "/path/to/agentic_framework/config/yaml/framework_config.yaml"
        >>> 
        >>> # Get path to specific configuration file
        >>> rollback_config = get_framework_config_path("rollback_config.yaml")
        >>> error_config = get_framework_config_path("error_handling_config.yaml")
    
    Available Configuration Files:
        - framework_config.yaml: Main framework configuration
        - rollback_config.yaml: Rollback and recovery strategies
        - scalability_config.yaml: Scaling and performance settings
        - error_handling_config.yaml: Error handling and retry policies
    
    Note:
        This function only constructs the path - it does not verify that the
        file exists. Use with initialize_config() or ConfigurationManager.load_config()
        to actually load the configuration file.
    """
    logger.debug(f"Resolving framework config path for: {config_name}")
    
    # Get the directory where this module is located
    current_dir = Path(__file__).parent
    
    # Construct path to yaml subdirectory
    yaml_dir = current_dir / "yaml"
    config_path = yaml_dir / config_name
    
    # Convert to absolute path string
    absolute_path = str(config_path.resolve())
    
    logger.debug(f"Resolved config path: {absolute_path}")
    
    # Log warning if file doesn't exist (but don't raise error)
    if not config_path.exists():
        logger.warning(f"Configuration file does not exist: {absolute_path}")
    
    return absolute_path