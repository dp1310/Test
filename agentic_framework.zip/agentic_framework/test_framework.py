"""
Simple test to verify the agentic framework implementation with proper logging.

This module tests the complete framework functionality using proper logging
instead of print statements for better debugging and monitoring.
"""

import asyncio
import sys
import os

# Add the parent directory to Python path to access agentic_framework as a package
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agentic_framework.examples.math_processor import MathPipelineController
from agentic_framework.core.logger import get_logger, LogConfig, LogTheme

# Configure enhanced logging with emoji and colors
log_config = LogConfig(
    level="INFO",
    theme=LogTheme.TECH,
    show_emoji=True,
    color_enabled=True,
    show_timestamp=True,
    show_level=True
)

# Initialize enhanced test logger
test_logger = get_logger("test_framework", log_config)


async def test_basic_functionality():
    """Test basic framework functionality with enhanced logging."""
    
    test_logger.info("Testing Agentic Framework Basic Functionality", tool="validation")
    test_logger.info("=" * 50, tool="validation")
    
    try:
        # Create math processor
        test_logger.info("Initializing math pipeline controller", tool="processor")
        processor = MathPipelineController(
            timeout=30,
            debug=True,
            agent_id='test_processor'
        )
        
        test_logger.info("Framework initialized successfully", tool="validation")
        
        # Test simple mathematical expression
        test_input = "Calculate 2+3, 5^7,  2-3 and 10/0, add(2,8), mod(8,3), 10//4, 5*/2"
        test_logger.info(f"Testing mathematical expressions", tool="tool")
        test_logger.debug(f"Input: {test_input}", tool="tool")
        
        test_logger.info("Executing pipeline", tool="processor")
        result = await processor.execute(test_input)
        
        test_logger.info("Pipeline execution completed successfully", tool="validation")
        test_logger.info(f"Result keys: {list(result.keys())}", tool="validation")
        
        # Check if all stages completed
        if 'results' in result:
            stages = result['results'].keys()
            test_logger.info(f"Completed stages: {list(stages)}", tool="performance")
            
            # Show some results
            test_logger.info("Mathematical expression results:", tool="tool")
            
            # Show successful and failed executions
            if 'act' in result['results']:
                act_result = result['results']['act']
                if 'execution_results' in act_result:
                    for expr_result in act_result['execution_results']:
                        if expr_result['success']:
                            test_logger.info(f"{expr_result['expression']} = {expr_result['result']}", tool="validation")
                        else:
                            test_logger.error(f"{expr_result['expression']} = ERROR: {expr_result['error']}", tool="error")
            
            # Show filtered expressions as errors
            if 'perceive' in result['results']:
                perceive_result = result['results']['perceive']
                if 'filtered_expressions' in perceive_result:
                    filtered = perceive_result['filtered_expressions']
                    for filtered_expr in filtered:
                        test_logger.error(f"{filtered_expr['original']} = ERROR: {filtered_expr['error']}", tool="error")
        
        test_logger.info("All tests passed! Framework is working correctly", tool="validation")
        return True
        
    except Exception as e:
        test_logger.error(f"Test failed with error: {e}", tool="error")
        import traceback
        test_logger.error("Full traceback:", tool="error")
        test_logger.error(traceback.format_exc(), tool="error")
        return False


async def main():
    """Run the test with enhanced logging."""
    test_logger.info("Starting framework functionality tests", tool="validation")
    
    success = await test_basic_functionality()
    
    if success:
        test_logger.info("Framework test completed successfully!", tool="validation")
        test_logger.info("The agentic framework is ready for use!", tool="validation")
    else:
        test_logger.error("Framework test failed!", tool="error")
        test_logger.error("Please check the implementation for issues.", tool="error")


if __name__ == "__main__":
    asyncio.run(main())