"""
Configurable rollback system with YAML-based strategies.

This module provides a comprehensive rollback system that can rollback to
specific stages, restart from beginning, or use adaptive strategies based
on error patterns and performance metrics.
"""

from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass
from enum import Enum
import time

from ..core.context import AgentContext


class RollbackStrategy(Enum):
    """Available rollback strategies."""
    ROLLBACK_TO_SPECIFIC_STAGE = "rollback_to_specific_stage"
    ROLLBACK_ONE_STAGE = "rollback_one_stage"
    RESTART_FROM_BEGINNING = "restart_from_beginning"
    ADAPTIVE_ROLLBACK = "adaptive_rollback"
    ROLLBACK_TO_LAST_SUCCESS = "rollback_to_last_success"


@dataclass
class RollbackConfig:
    """Configuration for rollback behavior."""
    strategy: RollbackStrategy
    target_stage: Optional[str] = None
    preserve_context: bool = True
    adjust_parameters: bool = False
    resource_threshold: float = 0.8
    timeout_multiplier: float = 1.5


class RollbackController:
    """Configurable rollback system with YAML-based strategies."""
    
    def __init__(self, config: Dict[str, Any], stage_order: List[str]):
        self.config = config
        self.stage_order = stage_order
        self.rollback_strategies = self._load_rollback_strategies()
        self.rollback_history: List[Dict[str, Any]] = []
        self.max_rollback_attempts = config.get('max_rollback_attempts', 3)
        
        # Strategy implementations
        self.strategy_implementations = {
            RollbackStrategy.ROLLBACK_TO_SPECIFIC_STAGE: self._rollback_to_specific_stage,
            RollbackStrategy.ROLLBACK_ONE_STAGE: self._rollback_one_stage,
            RollbackStrategy.RESTART_FROM_BEGINNING: self._restart_from_beginning,
            RollbackStrategy.ADAPTIVE_ROLLBACK: self._adaptive_rollback,
            RollbackStrategy.ROLLBACK_TO_LAST_SUCCESS: self._rollback_to_last_success
        }
    
    def _load_rollback_strategies(self) -> Dict[str, RollbackConfig]:
        """Load rollback strategies from configuration."""
        strategies = {}
        
        rollback_config = self.config.get('rollback_strategies', {})
        
        for error_type, strategy_config in rollback_config.items():
            strategy_enum = RollbackStrategy(strategy_config['strategy'])
            
            strategies[error_type] = RollbackConfig(
                strategy=strategy_enum,
                target_stage=strategy_config.get('target_stage'),
                preserve_context=strategy_config.get('preserve_context', True),
                adjust_parameters=strategy_config.get('adjust_parameters', False),
                resource_threshold=strategy_config.get('resource_threshold', 0.8),
                timeout_multiplier=strategy_config.get('timeout_multiplier', 1.5)
            )
        
        return strategies
    
    async def handle_error(self, error: Exception, context: AgentContext) -> Optional[Dict[str, Any]]:
        """Handle error and determine if rollback should occur."""
        
        error_type = self._classify_error(error)
        rollback_config = self.rollback_strategies.get(error_type)
        
        if not rollback_config:
            # No specific strategy for this error type
            return None
        
        # Check rollback attempt limits
        current_attempts = len([r for r in self.rollback_history if r['trace_id'] == context.trace_id])
        if current_attempts >= self.max_rollback_attempts:
            return None
        
        # Attempt rollback
        return await self.rollback(error, context, rollback_config)
    
    async def rollback(self, 
                      error: Exception, 
                      context: AgentContext, 
                      rollback_config: Optional[RollbackConfig] = None) -> Optional[AgentContext]:
        """Execute rollback based on configuration."""
        
        if not rollback_config:
            # Use default rollback strategy
            rollback_config = RollbackConfig(
                strategy=RollbackStrategy.ROLLBACK_ONE_STAGE,
                preserve_context=True,
                adjust_parameters=False
            )
        
        rollback_start_time = time.time()
        
        try:
            # Get strategy implementation
            strategy_func = self.strategy_implementations.get(rollback_config.strategy)
            if not strategy_func:
                return None
            
            # Execute rollback strategy
            rollback_context = await strategy_func(error, context, rollback_config)
            
            # Record rollback attempt
            rollback_time = time.time() - rollback_start_time
            self._record_rollback_attempt(error, context, rollback_config, rollback_time, success=True)
            
            return rollback_context
            
        except Exception as rollback_error:
            # Rollback itself failed
            rollback_time = time.time() - rollback_start_time
            self._record_rollback_attempt(error, context, rollback_config, rollback_time, success=False)
            
            return None 
   
    async def _rollback_to_specific_stage(self, 
                                        error: Exception, 
                                        context: AgentContext, 
                                        config: RollbackConfig) -> Optional[AgentContext]:
        """Rollback to a specific stage."""
        
        target_stage = config.target_stage
        if not target_stage or target_stage not in self.stage_order:
            return None
        
        # Find target stage index
        target_index = self.stage_order.index(target_stage)
        
        # Create new context with stages after target removed
        new_stage_results = {}
        for stage, result in context.stage_results.items():
            stage_index = self.stage_order.index(stage) if stage in self.stage_order else -1
            if stage_index <= target_index:
                new_stage_results[stage] = result
        
        # Create rollback context
        rollback_context = AgentContext(
            input_data=context.input_data,
            stage_results=new_stage_results,
            decisions=context.decisions if config.preserve_context else [],
            trace_id=context.trace_id,
            agent_id=context.agent_id,
            timeout=int(context.timeout * config.timeout_multiplier) if config.adjust_parameters else context.timeout,
            constraints=context.constraints,
            configuration=context.configuration,
            performance_metrics=context.performance_metrics,
            event_system=context.event_system
        )
        
        return rollback_context
    
    async def _rollback_one_stage(self, 
                                error: Exception, 
                                context: AgentContext, 
                                config: RollbackConfig) -> Optional[AgentContext]:
        """Rollback one stage."""
        
        if not context.stage_results:
            return None
        
        # Get last completed stage
        completed_stages = list(context.stage_results.keys())
        if not completed_stages:
            return None
        
        # Remove last stage
        last_stage = completed_stages[-1]
        new_stage_results = {k: v for k, v in context.stage_results.items() if k != last_stage}
        
        # Create rollback context
        rollback_context = AgentContext(
            input_data=context.input_data,
            stage_results=new_stage_results,
            decisions=context.decisions if config.preserve_context else [],
            trace_id=context.trace_id,
            agent_id=context.agent_id,
            timeout=int(context.timeout * config.timeout_multiplier) if config.adjust_parameters else context.timeout,
            constraints=context.constraints,
            configuration=context.configuration,
            performance_metrics=context.performance_metrics,
            event_system=context.event_system
        )
        
        return rollback_context
    
    async def _restart_from_beginning(self, 
                                    error: Exception, 
                                    context: AgentContext, 
                                    config: RollbackConfig) -> Optional[AgentContext]:
        """Restart from the beginning."""
        
        # Create fresh context
        rollback_context = AgentContext(
            input_data=context.input_data,
            stage_results={},
            decisions=[] if not config.preserve_context else context.decisions,
            trace_id=context.trace_id,
            agent_id=context.agent_id,
            timeout=int(context.timeout * config.timeout_multiplier) if config.adjust_parameters else context.timeout,
            constraints=context.constraints,
            configuration=context.configuration,
            performance_metrics={},
            event_system=context.event_system
        )
        
        return rollback_context
    
    async def _adaptive_rollback(self, 
                               error: Exception, 
                               context: AgentContext, 
                               config: RollbackConfig) -> Optional[AgentContext]:
        """Adaptive rollback based on error patterns and performance."""
        
        # Analyze error and context to determine best rollback strategy
        error_severity = self._assess_error_severity(error, context)
        performance_indicators = context.performance_metrics
        
        # Determine adaptive strategy
        if error_severity > 0.8:
            # High severity - restart from beginning
            return await self._restart_from_beginning(error, context, config)
        elif error_severity > 0.5:
            # Medium severity - rollback to specific stage based on performance
            worst_performing_stage = self._find_worst_performing_stage(performance_indicators)
            if worst_performing_stage:
                adaptive_config = RollbackConfig(
                    strategy=RollbackStrategy.ROLLBACK_TO_SPECIFIC_STAGE,
                    target_stage=worst_performing_stage,
                    preserve_context=config.preserve_context,
                    adjust_parameters=config.adjust_parameters
                )
                return await self._rollback_to_specific_stage(error, context, adaptive_config)
        
        # Low severity - rollback one stage
        return await self._rollback_one_stage(error, context, config)
    
    async def _rollback_to_last_success(self, 
                                      error: Exception, 
                                      context: AgentContext, 
                                      config: RollbackConfig) -> Optional[AgentContext]:
        """Rollback to last successful stage based on performance metrics."""
        
        # Find last stage with good performance metrics
        performance_metrics = context.performance_metrics
        
        last_successful_stage = None
        for stage in reversed(self.stage_order):
            if stage in context.stage_results:
                stage_metrics = performance_metrics.get(f'{stage}_metrics', {})
                success_rate = stage_metrics.get('success_rate', 0)
                
                if success_rate > 0.8:  # 80% success rate threshold
                    last_successful_stage = stage
                    break
        
        if last_successful_stage:
            adaptive_config = RollbackConfig(
                strategy=RollbackStrategy.ROLLBACK_TO_SPECIFIC_STAGE,
                target_stage=last_successful_stage,
                preserve_context=config.preserve_context,
                adjust_parameters=config.adjust_parameters
            )
            return await self._rollback_to_specific_stage(error, context, adaptive_config)
        
        # Fallback to restart if no successful stage found
        return await self._restart_from_beginning(error, context, config)
    
    def _classify_error(self, error: Exception) -> str:
        """Classify error type for strategy selection."""
        error_name = error.__class__.__name__
        error_message = str(error).lower()
        
        # Define error classification patterns
        error_patterns = {
            'timeout_error': ['timeout', 'timeouterror'],
            'network_error': ['connection', 'network', 'dns'],
            'resource_error': ['memory', 'resource', 'disk'],
            'validation_error': ['validation', 'schema', 'data'],
            'llm_error': ['llm', 'api', 'ratelimit'],
            'context_corruption': ['context', 'corruption', 'state']
        }
        
        for error_type, patterns in error_patterns.items():
            if any(pattern in error_name.lower() or pattern in error_message for pattern in patterns):
                return error_type
        
        return 'unknown_error'
    
    def _assess_error_severity(self, error: Exception, context: AgentContext) -> float:
        """Assess error severity for adaptive rollback."""
        severity = 0.5  # Base severity
        
        # Factor in error type
        error_type = self._classify_error(error)
        severity_weights = {
            'timeout_error': 0.3,
            'network_error': 0.4,
            'resource_error': 0.8,
            'validation_error': 0.2,
            'llm_error': 0.5,
            'context_corruption': 0.9
        }
        
        severity += severity_weights.get(error_type, 0.3)
        
        # Factor in stage completion
        completion_ratio = len(context.stage_results) / len(self.stage_order)
        severity += (1 - completion_ratio) * 0.2  # Higher severity if error occurred early
        
        return min(severity, 1.0)
    
    def _find_worst_performing_stage(self, performance_metrics: Dict[str, Any]) -> Optional[str]:
        """Find the worst performing stage based on metrics."""
        worst_stage = None
        worst_performance = float('inf')
        
        for stage in self.stage_order:
            stage_metrics = performance_metrics.get(f'{stage}_metrics', {})
            execution_time = stage_metrics.get('execution_time', 0)
            error_rate = stage_metrics.get('error_rate', 0)
            
            # Calculate performance score (lower is worse)
            performance_score = execution_time + (error_rate * 10)
            
            if performance_score < worst_performance:
                worst_performance = performance_score
                worst_stage = stage
        
        return worst_stage
    
    def _record_rollback_attempt(self, 
                               error: Exception, 
                               context: AgentContext, 
                               config: RollbackConfig, 
                               execution_time: float, 
                               success: bool) -> None:
        """Record rollback attempt for analysis."""
        
        rollback_record = {
            'timestamp': time.time(),
            'trace_id': context.trace_id,
            'error_type': self._classify_error(error),
            'error_message': str(error),
            'strategy': config.strategy.value,
            'target_stage': config.target_stage,
            'execution_time': execution_time,
            'success': success,
            'context_preserved': config.preserve_context,
            'parameters_adjusted': config.adjust_parameters
        }
        
        self.rollback_history.append(rollback_record)
        
        # Keep only recent history
        max_history = 1000
        if len(self.rollback_history) > max_history:
            self.rollback_history = self.rollback_history[-max_history:]
    
    def get_rollback_statistics(self) -> Dict[str, Any]:
        """Get rollback statistics for monitoring."""
        if not self.rollback_history:
            return {'total_rollbacks': 0}
        
        total_rollbacks = len(self.rollback_history)
        successful_rollbacks = sum(1 for r in self.rollback_history if r['success'])
        
        # Group by error type
        error_type_stats = {}
        for record in self.rollback_history:
            error_type = record['error_type']
            if error_type not in error_type_stats:
                error_type_stats[error_type] = {'count': 0, 'success_rate': 0}
            error_type_stats[error_type]['count'] += 1
        
        # Calculate success rates
        for error_type in error_type_stats:
            type_records = [r for r in self.rollback_history if r['error_type'] == error_type]
            successful = sum(1 for r in type_records if r['success'])
            error_type_stats[error_type]['success_rate'] = successful / len(type_records)
        
        return {
            'total_rollbacks': total_rollbacks,
            'success_rate': successful_rollbacks / total_rollbacks,
            'error_type_breakdown': error_type_stats,
            'avg_execution_time': sum(r['execution_time'] for r in self.rollback_history) / total_rollbacks
        }