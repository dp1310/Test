"""
Data processing tools for the agentic framework.

This module provides comprehensive data processing tools following functional
programming principles with immutable data structures and pure functions.
"""

import json
import statistics
from typing import Dict, Any, List, Optional, Callable, Union, Tuple
from collections import Counter
from functools import reduce, partial
from dataclasses import dataclass, field

from ..core.protocols import ToolProtocol, ToolMetadata, ToolExecutionMode


@dataclass(frozen=True)
class DataStructureAnalysis:
    """Immutable result container for data structure analysis."""
    data_type: str
    is_tabular: bool
    is_hierarchical: bool
    is_time_series: bool
    schema: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ValidationResult:
    """Immutable result container for data validation."""
    is_valid: bool
    validation_errors: List[str]
    validation_warnings: List[str]
    overall_validity_score: float
    field_validations: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class StatisticalAnalysis:
    """Immutable result container for statistical analysis."""
    summary_statistics: Dict[str, Dict[str, float]]
    correlations: Dict[str, Any] = field(default_factory=dict)
    distributions: Dict[str, Any] = field(default_factory=dict)
    outliers: Dict[str, List[float]] = field(default_factory=dict)


@dataclass(frozen=True)
class CleaningResult:
    """Immutable result container for data cleaning."""
    cleaned_data: Any
    transformations_applied: List[str]
    records_modified: int
    improvement_score: float


@dataclass(frozen=True)
class InsightsResult:
    """Immutable result container for insights generation."""
    key_findings: List[str]
    recommendations: List[str]
    data_patterns: List[str]
    quality_assessment: Dict[str, Any] = field(default_factory=dict)


# Pure functions for data parsing
def parse_json_data(input_data: str) -> Union[Dict, List, None]:
    """Parse JSON data safely (pure function)."""
    try:
        return json.loads(input_data)
    except json.JSONDecodeError:
        return None


def parse_csv_data(input_data: str) -> List[Dict[str, Any]]:
    """Parse CSV-like data (pure function)."""
    lines = input_data.strip().split('\n')
    if len(lines) <= 1:
        return []
    
    headers = [h.strip() for h in lines[0].split(',')]
    
    def parse_row(line: str) -> Optional[Dict[str, Any]]:
        values = [v.strip() for v in line.split(',')]
        if len(values) != len(headers):
            return None
        
        row = dict(zip(headers, values))
        
        # Convert numeric values using functional approach
        def try_convert_numeric(value: str) -> Union[int, float, str]:
            try:
                return float(value) if '.' in value else int(value)
            except ValueError:
                return value
        
        return {key: try_convert_numeric(value) for key, value in row.items()}
    
    parsed_rows = [parse_row(line) for line in lines[1:]]
    return [row for row in parsed_rows if row is not None]


def parse_input_data(input_data: Any) -> Any:
    """Parse input data into structured format (pure function)."""
    if not isinstance(input_data, str):
        return input_data
    
    # Try JSON first
    json_result = parse_json_data(input_data)
    if json_result is not None:
        return json_result
    
    # Try CSV
    csv_result = parse_csv_data(input_data)
    if csv_result:
        return csv_result
    
    # Return as raw text
    return {'raw_text': input_data}


# Pure functions for data structure analysis
def analyze_data_structure(data: Any) -> DataStructureAnalysis:
    """Analyze data structure (pure function)."""
    data_type = type(data).__name__
    
    if isinstance(data, list) and data and isinstance(data[0], dict):
        # Tabular data analysis
        sample_size = min(10, len(data))
        all_keys = reduce(
            lambda acc, record: acc.union(record.keys()),
            data[:sample_size],
            set()
        )
        
        # Check for time series indicators
        time_indicators = ['date', 'time', 'timestamp', 'created_at', 'updated_at']
        has_time_column = any(
            any(indicator in col.lower() for indicator in time_indicators)
            for col in all_keys
        )
        
        return DataStructureAnalysis(
            data_type=data_type,
            is_tabular=True,
            is_hierarchical=False,
            is_time_series=has_time_column,
            schema={
                'columns': list(all_keys),
                'column_count': len(all_keys),
                'record_count': len(data)
            }
        )
    
    elif isinstance(data, dict):
        return DataStructureAnalysis(
            data_type=data_type,
            is_tabular=False,
            is_hierarchical=True,
            is_time_series=False,
            schema={
                'keys': list(data.keys()),
                'key_count': len(data),
                'nested_levels': calculate_nesting_depth(data)
            }
        )
    
    else:
        return DataStructureAnalysis(
            data_type=data_type,
            is_tabular=False,
            is_hierarchical=False,
            is_time_series=False
        )


def calculate_nesting_depth(obj: Any, current_depth: int = 0) -> int:
    """Calculate nesting depth recursively (pure function)."""
    if isinstance(obj, dict):
        if not obj:
            return current_depth
        return max(
            calculate_nesting_depth(value, current_depth + 1)
            for value in obj.values()
        )
    elif isinstance(obj, list):
        if not obj:
            return current_depth
        return max(
            calculate_nesting_depth(item, current_depth + 1)
            for item in obj
        )
    else:
        return current_depth


# Pure functions for data type analysis
def analyze_column_types(data: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Analyze column types in tabular data (pure function)."""
    if not data or not isinstance(data[0], dict):
        return {}
    
    columns = data[0].keys()
    
    def analyze_column(column: str) -> Dict[str, Any]:
        values = [record.get(column) for record in data]
        
        # Type analysis
        type_counts = Counter(type(v).__name__ for v in values if v is not None)
        dominant_type = type_counts.most_common(1)[0][0] if type_counts else 'NoneType'
        
        # Missing values
        missing_count = sum(1 for v in values if v is None or v == '')
        
        # Unique values
        unique_count = len(set(v for v in values if v is not None))
        
        analysis = {
            'dominant_type': dominant_type,
            'type_distribution': dict(type_counts),
            'missing_count': missing_count,
            'missing_percentage': (missing_count / len(values)) * 100,
            'unique_count': unique_count,
            'uniqueness_percentage': (unique_count / len(values)) * 100 if values else 0
        }
        
        # Numeric analysis
        if dominant_type in ['int', 'float']:
            numeric_values = [v for v in values if isinstance(v, (int, float))]
            if numeric_values:
                analysis.update({
                    'min_value': min(numeric_values),
                    'max_value': max(numeric_values),
                    'mean_value': statistics.mean(numeric_values),
                    'median_value': statistics.median(numeric_values),
                    'std_deviation': statistics.stdev(numeric_values) if len(numeric_values) > 1 else 0
                })
        
        return analysis
    
    return {column: analyze_column(column) for column in columns}


def calculate_data_size(data: Any) -> Dict[str, int]:
    """Calculate data size metrics (pure function)."""
    if isinstance(data, list):
        total_records = len(data)
        total_fields = len(data[0]) * len(data) if data and isinstance(data[0], dict) else 0
    elif isinstance(data, dict):
        total_records = 1
        total_fields = len(data)
    else:
        total_records = 0
        total_fields = 0
    
    memory_estimate = len(str(data).encode('utf-8'))
    
    return {
        'total_records': total_records,
        'total_fields': total_fields,
        'memory_estimate': memory_estimate
    }


# Pure functions for data validation
def validate_tabular_data(data: List[Dict[str, Any]]) -> ValidationResult:
    """Validate tabular data (pure function)."""
    validation_errors = []
    validation_warnings = []
    
    # Process all fields functionally
    def process_field(i_record_field):
        i, record, field, value = i_record_field
        
        if value is None:
            return {'warning': f"Null value in record {i}, field '{field}'", 'valid': False}
        elif isinstance(value, str) and not value.strip():
            return {'warning': f"Empty string in record {i}, field '{field}'", 'valid': False}
        else:
            return {'valid': True}
    
    # Create field tuples for processing
    field_data = [
        (i, record, field, value)
        for i, record in enumerate(data)
        for field, value in record.items()
    ]
    
    # Process all fields
    field_results = list(map(process_field, field_data))
    
    # Extract warnings and count valid fields
    validation_warnings.extend([r['warning'] for r in field_results if 'warning' in r])
    total_fields = len(field_results)
    valid_fields = sum(1 for r in field_results if r['valid'])
    
    validity_score = (valid_fields / total_fields) * 100 if total_fields > 0 else 100.0
    
    return ValidationResult(
        is_valid=len(validation_errors) == 0,
        validation_errors=validation_errors,
        validation_warnings=validation_warnings,
        overall_validity_score=validity_score
    )


def validate_data_quality(data: Any) -> Dict[str, Any]:
    """Validate data quality (pure function)."""
    if isinstance(data, list) and data and isinstance(data[0], dict):
        total_cells = sum(len(record) for record in data)
        missing_cells = sum(
            1 for record in data
            for value in record.values()
            if value is None or value == ''
        )
        
        completeness_score = ((total_cells - missing_cells) / total_cells) * 100 if total_cells > 0 else 100.0
        
        return {
            'completeness_score': completeness_score,
            'consistency_issues': [],
            'potential_outliers': [],
            'data_quality_score': completeness_score
        }
    
    return {
        'completeness_score': 100.0,
        'consistency_issues': [],
        'potential_outliers': [],
        'data_quality_score': 100.0
    }


# Pure functions for statistical analysis
def calculate_summary_statistics(data: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
    """Calculate summary statistics for numeric columns (pure function)."""
    if not data or not isinstance(data[0], dict):
        return {}
    
    # Identify numeric columns
    numeric_columns = {}
    for record in data:
        for field, value in record.items():
            if isinstance(value, (int, float)):
                if field not in numeric_columns:
                    numeric_columns[field] = []
                numeric_columns[field].append(value)
    
    def calculate_column_stats(values: List[float]) -> Dict[str, float]:
        if not values:
            return {}
        
        return {
            'count': len(values),
            'mean': statistics.mean(values),
            'median': statistics.median(values),
            'min': min(values),
            'max': max(values),
            'std_dev': statistics.stdev(values) if len(values) > 1 else 0,
            'variance': statistics.variance(values) if len(values) > 1 else 0
        }
    
    return {column: calculate_column_stats(values) for column, values in numeric_columns.items()}


def detect_outliers(data: List[Dict[str, Any]]) -> Dict[str, List[float]]:
    """Detect outliers using 2-sigma rule (pure function)."""
    if not data or not isinstance(data[0], dict):
        return {}
    
    # Get numeric columns
    numeric_columns = {}
    for record in data:
        for field, value in record.items():
            if isinstance(value, (int, float)):
                if field not in numeric_columns:
                    numeric_columns[field] = []
                numeric_columns[field].append(value)
    
    def find_outliers(values: List[float]) -> List[float]:
        if len(values) <= 1:
            return []
        
        mean_val = statistics.mean(values)
        std_val = statistics.stdev(values)
        
        return [v for v in values if abs(v - mean_val) > 2 * std_val]
    
    outliers = {column: find_outliers(values) for column, values in numeric_columns.items()}
    return {k: v for k, v in outliers.items() if v}


# Pure functions for data cleaning
def clean_tabular_data(data: List[Dict[str, Any]]) -> CleaningResult:
    """Clean tabular data (pure function)."""
    def clean_record(record: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
        cleaned_record = {}
        record_modified = False
        
        for field, value in record.items():
            if isinstance(value, str):
                cleaned_value = value.strip()
                if cleaned_value != value:
                    record_modified = True
                cleaned_record[field] = cleaned_value if cleaned_value else None
            else:
                cleaned_record[field] = value
        
        return cleaned_record, record_modified
    
    cleaned_results = [clean_record(record) for record in data]
    cleaned_data = [result[0] for result in cleaned_results]
    records_modified = sum(1 for result in cleaned_results if result[1])
    
    improvement_score = ((len(data) - records_modified) / len(data)) * 100 if data else 100.0
    
    return CleaningResult(
        cleaned_data=cleaned_data,
        transformations_applied=['trim_whitespace', 'handle_empty_strings'],
        records_modified=records_modified,
        improvement_score=improvement_score
    )


# Pure functions for insights generation
def generate_data_insights(data: Any) -> InsightsResult:
    """Generate insights from data (pure function)."""
    if not isinstance(data, list) or not data or not isinstance(data[0], dict):
        return InsightsResult(
            key_findings=[],
            recommendations=[],
            data_patterns=[],
            quality_assessment={}
        )
    
    key_findings = [f"Dataset contains {len(data)} records"]
    recommendations = []
    data_patterns = []
    
    # Analyze field completeness
    field_completeness = {}
    for field in data[0].keys():
        non_null_count = sum(1 for record in data if record.get(field) is not None)
        completeness = (non_null_count / len(data)) * 100
        field_completeness[field] = completeness
        
        if completeness < 50:
            recommendations.append(f"Field '{field}' has low completeness ({completeness:.1f}%)")
    
    # Identify field types
    numeric_fields = []
    categorical_fields = []
    
    for field in data[0].keys():
        sample_values = [record.get(field) for record in data[:10] if record.get(field) is not None]
        if sample_values and all(isinstance(v, (int, float)) for v in sample_values):
            numeric_fields.append(field)
        else:
            categorical_fields.append(field)
    
    if numeric_fields:
        data_patterns.append(f"Numeric fields identified: {', '.join(numeric_fields)}")
    if categorical_fields:
        data_patterns.append(f"Categorical fields identified: {', '.join(categorical_fields)}")
    
    return InsightsResult(
        key_findings=key_findings,
        recommendations=recommendations,
        data_patterns=data_patterns,
        quality_assessment={'field_completeness': field_completeness}
    )


# Tool implementations using ToolProtocol
class DataValidatorTool(ToolProtocol):
    """Data validation tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Validates data quality and structure",
            input_schema={"data": {"type": ["array", "object"]}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=60,
            resource_requirements={"memory_mb": 100, "cpu_cores": 1},
            version="1.0.0",
            tags=["validation", "data", "quality"]
        )
    
    async def execute(self, data: Any, **kwargs) -> Dict[str, Any]:
        """Execute data validation."""
        if isinstance(data, list) and data and isinstance(data[0], dict):
            result = validate_tabular_data(data)
            return {
                'is_valid': result.is_valid,
                'validation_errors': result.validation_errors,
                'validation_warnings': result.validation_warnings,
                'overall_validity_score': result.overall_validity_score,
                'field_validations': result.field_validations
            }
        else:
            return {
                'is_valid': True,
                'validation_errors': [],
                'validation_warnings': [],
                'overall_validity_score': 100.0,
                'field_validations': {}
            }
    
    def should_skip(self, context) -> bool:
        return False
    
    async def on_success(self, result: Any, context) -> None:
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        return {
            'is_valid': False,
            'validation_errors': [str(error)],
            'validation_warnings': [],
            'overall_validity_score': 0.0,
            'field_validations': {}
        }


class DataAnalyzerTool(ToolProtocol):
    """Statistical data analysis tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Performs statistical analysis on data",
            input_schema={"data": {"type": ["array", "object"]}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=120,
            resource_requirements={"memory_mb": 200, "cpu_cores": 1},
            version="1.0.0",
            tags=["statistics", "data", "analysis"]
        )
    
    async def execute(self, data: Any, **kwargs) -> Dict[str, Any]:
        """Execute statistical analysis."""
        if isinstance(data, list) and data and isinstance(data[0], dict):
            summary_stats = calculate_summary_statistics(data)
            outliers = detect_outliers(data)
            
            return {
                'summary_statistics': summary_stats,
                'correlations': {},  # Could be extended
                'distributions': {},  # Could be extended
                'outliers': outliers
            }
        else:
            return {
                'summary_statistics': {},
                'correlations': {},
                'distributions': {},
                'outliers': {}
            }
    
    def should_skip(self, context) -> bool:
        return False
    
    async def on_success(self, result: Any, context) -> None:
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        return {
            'summary_statistics': {},
            'correlations': {},
            'distributions': {},
            'outliers': {},
            'error': str(error)
        }


class DataTransformerTool(ToolProtocol):
    """Data transformation and cleaning tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Cleans and transforms data",
            input_schema={"data": {"type": ["array", "object"]}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=120,
            resource_requirements={"memory_mb": 150, "cpu_cores": 1},
            version="1.0.0",
            tags=["transformation", "data", "cleaning"]
        )
    
    async def execute(self, data: Any, **kwargs) -> Dict[str, Any]:
        """Execute data cleaning and transformation."""
        if isinstance(data, list) and data and isinstance(data[0], dict):
            result = clean_tabular_data(data)
            return {
                'cleaned_data': result.cleaned_data,
                'transformations_applied': result.transformations_applied,
                'records_modified': result.records_modified,
                'improvement_score': result.improvement_score
            }
        else:
            return {
                'cleaned_data': data,
                'transformations_applied': [],
                'records_modified': 0,
                'improvement_score': 100.0
            }
    
    def should_skip(self, context) -> bool:
        return False
    
    async def on_success(self, result: Any, context) -> None:
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        return {
            'cleaned_data': None,
            'transformations_applied': [],
            'records_modified': 0,
            'improvement_score': 0.0,
            'error': str(error)
        }


class DataInsightsGeneratorTool(ToolProtocol):
    """Data insights generation tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Generates insights and recommendations from data analysis",
            input_schema={"data": {"type": ["array", "object"]}, "context": {"type": "object"}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=90,
            resource_requirements={"memory_mb": 120, "cpu_cores": 1},
            version="1.0.0",
            tags=["insights", "data", "recommendations"]
        )
    
    async def execute(self, data: Any, context=None, **kwargs) -> Dict[str, Any]:
        """Execute insights generation."""
        result = generate_data_insights(data)
        return {
            'key_findings': result.key_findings,
            'recommendations': result.recommendations,
            'data_patterns': result.data_patterns,
            'quality_assessment': result.quality_assessment
        }
    
    def should_skip(self, context) -> bool:
        return False
    
    async def on_success(self, result: Any, context) -> None:
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        return {
            'key_findings': [],
            'recommendations': [],
            'data_patterns': [],
            'quality_assessment': {},
            'error': str(error)
        }


class DataParserTool(ToolProtocol):
    """Data parsing tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Parses various data formats into structured data",
            input_schema={"input_data": {"type": ["string", "array", "object"]}},
            output_schema={"type": ["array", "object"]},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=60,
            resource_requirements={"memory_mb": 80, "cpu_cores": 1},
            version="1.0.0",
            tags=["parsing", "data", "formats"]
        )
    
    async def execute(self, input_data: Any, **kwargs) -> Any:
        """Execute data parsing."""
        return parse_input_data(input_data)
    
    def should_skip(self, context) -> bool:
        return False
    
    async def on_success(self, result: Any, context) -> None:
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        return {'error': str(error), 'raw_data': None}


class ComprehensiveDataAnalyzerTool(ToolProtocol):
    """Comprehensive data analysis tool combining all analyses."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Performs comprehensive data analysis including all data processing features",
            input_schema={"data": {"type": ["string", "array", "object"]}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=180,
            resource_requirements={"memory_mb": 300, "cpu_cores": 1},
            version="1.0.0",
            tags=["comprehensive", "data", "analysis"]
        )
    
    async def execute(self, data: Any, **kwargs) -> Dict[str, Any]:
        """Execute comprehensive data analysis."""
        # Parse data first
        parsed_data = parse_input_data(data)
        
        # Perform all analyses using functional composition
        analyses = [
            ('structure_analysis', lambda: analyze_data_structure(parsed_data).__dict__),
            ('data_size', lambda: calculate_data_size(parsed_data)),
            ('data_quality', lambda: validate_data_quality(parsed_data)),
            ('validation', lambda: validate_tabular_data(parsed_data).__dict__ if isinstance(parsed_data, list) and parsed_data and isinstance(parsed_data[0], dict) else {}),
            ('statistical_analysis', lambda: calculate_summary_statistics(parsed_data) if isinstance(parsed_data, list) and parsed_data and isinstance(parsed_data[0], dict) else {}),
            ('outliers', lambda: detect_outliers(parsed_data) if isinstance(parsed_data, list) and parsed_data and isinstance(parsed_data[0], dict) else {}),
            ('column_types', lambda: analyze_column_types(parsed_data) if isinstance(parsed_data, list) and parsed_data and isinstance(parsed_data[0], dict) else {}),
            ('insights', lambda: generate_data_insights(parsed_data).__dict__)
        ]
        
        # Execute all analyses and combine results
        results = {'parsed_data': parsed_data}
        for name, analysis_func in analyses:
            try:
                results[name] = analysis_func()
            except Exception as e:
                results[name] = {'error': str(e)}
        
        return results
    
    def should_skip(self, context) -> bool:
        return False
    
    async def on_success(self, result: Any, context) -> None:
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        return {'error': str(error), 'analysis_failed': True}