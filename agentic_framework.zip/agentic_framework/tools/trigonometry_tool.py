"""
Trigonometry tool for mathematical operations.

This tool provides trigonometric functions like sin, cos, tan, etc.
"""

import math
from typing import Any, Dict


class TrigonometryTool:
    """Tool for trigonometric calculations."""
    
    def __init__(self):
        self.name = "trigonometry"
        self.description = "Performs trigonometric calculations (sin, cos, tan, etc.)"
        self.version = "1.0.0"
        
        # Add metadata for compatibility
        from agentic_framework.core.protocols import ToolMetadata, ToolExecutionMode
        self.metadata = ToolMetadata(
            purpose="Trigonometric calculations",
            input_schema={
                "function_name": {"type": "string"},
                "value": {"type": "number"}
            },
            output_schema={"type": "number"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 1, "cpu_cores": 0.1},
            timeout=5
        )
        
        # Trigonometric function mapping
        self.trig_functions = {
            'sin': math.sin,
            'cos': math.cos,
            'tan': math.tan,
            'asin': math.asin,
            'acos': math.acos,
            'atan': math.atan,
            'sinh': math.sinh,
            'cosh': math.cosh,
            'tanh': math.tanh,
            'degrees': math.degrees,
            'radians': math.radians
        }
    
    async def execute(self, function_name: str, value: float, **kwargs) -> float:
        """
        Execute trigonometric function.
        
        Args:
            function_name: Name of the trigonometric function
            value: Input value for the function
            **kwargs: Additional parameters
            
        Returns:
            Result of the trigonometric calculation
            
        Raises:
            ValueError: If function is unknown or input is invalid
        """
        if function_name not in self.trig_functions:
            available_functions = ', '.join(self.trig_functions.keys())
            raise ValueError(f"Unknown trigonometric function: {function_name}. Available: {available_functions}")
        
        try:
            func = self.trig_functions[function_name]
            result = func(value)
            
            # Handle special cases
            if math.isnan(result):
                raise ValueError(f"Result is NaN for {function_name}({value})")
            if math.isinf(result):
                raise ValueError(f"Result is infinite for {function_name}({value})")
                
            return result
            
        except (ValueError, OverflowError) as e:
            raise ValueError(f"Error calculating {function_name}({value}): {e}")
        except Exception as e:
            raise ValueError(f"Unexpected error in trigonometric calculation: {e}")
    
    def get_supported_functions(self) -> list:
        """Get list of supported trigonometric functions."""
        return list(self.trig_functions.keys())
    
    def validate_input(self, function_name: str, value: float) -> bool:
        """
        Validate input for trigonometric functions.
        
        Args:
            function_name: Name of the function
            value: Input value
            
        Returns:
            True if input is valid
        """
        # Domain restrictions for inverse functions
        if function_name in ['asin', 'acos'] and not (-1 <= value <= 1):
            return False
        
        # Check for tan domain restrictions (avoid π/2 + nπ)
        if function_name == 'tan':
            # Check if value is close to π/2 + nπ
            normalized = (value + math.pi/2) % math.pi
            if abs(normalized) < 1e-10 or abs(normalized - math.pi) < 1e-10:
                return False
        
        return True