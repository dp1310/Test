"""
Comprehensive network tools for HTTP requests, web communication, and API integration.

This module provides sophisticated networking capabilities for the agentic framework,
including HTTP client functionality, request/response handling, connection pooling,
retry mechanisms, and comprehensive monitoring. All tools are designed with
performance optimization, security considerations, and detailed logging.

Key Features:
    - Advanced HTTP client with full REST API support
    - Intelligent connection pooling and session management
    - Comprehensive request/response logging and monitoring
    - Configurable retry mechanisms with exponential backoff
    - Security features including timeout management and validation
    - Performance optimization with connection reuse and caching
    - Detailed error handling and recovery strategies
    - Extensible callback system for request/response processing

HTTP Client Capabilities:
    - Support for all HTTP methods (GET, POST, PUT, DELETE, PATCH, etc.)
    - JSON and form data handling with automatic serialization
    - Custom headers and authentication support
    - Request/response compression and encoding handling
    - Streaming support for large payloads
    - Connection pooling for optimal performance

Security Features:
    - Configurable timeouts for request safety
    - URL validation and sanitization
    - SSL/TLS certificate verification
    - Request size limits and validation
    - Rate limiting and throttling support
    - Secure header handling and filtering

Example:
    Basic HTTP requests:
        >>> client = HTTPClientTool()
        >>> 
        >>> # GET request
        >>> result = await client.execute(
        ...     "https://api.example.com/data",
        ...     method="GET",
        ...     headers={"Authorization": "Bearer token"},
        ...     context=agent_context
        ... )
        >>> 
        >>> # POST request with JSON data
        >>> result = await client.execute(
        ...     "https://api.example.com/users",
        ...     method="POST",
        ...     data={"name": "John", "email": "john@example.com"},
        ...     context=agent_context
        ... )
    
    With callbacks and monitoring:
        >>> async def log_request(result, context):
        ...     logger.info(f"Request completed: {result['status_code']}")
        >>> 
        >>> client.add_callback(log_request)
        >>> result = await client.execute(url, context=context)

Performance:
    - Connection pooling reduces overhead for multiple requests
    - Intelligent retry mechanisms improve reliability
    - Comprehensive caching for repeated requests
    - Optimized for high-throughput API interactions

Author: Agentic Framework Team
Version: 2.0.0
"""

from typing import Dict, Any, List, Callable, Optional, Union
import aiohttp
import asyncio
import time
import logging
from urllib.parse import urlparse
from datetime import datetime

from ..core.protocols import ToolProtocol, ToolMetadata, ToolExecutionMode
from ..core.context import AgentContext
from ..core.data_structures import Event

# Initialize module logger
logger = logging.getLogger(__name__)


class HTTPClientTool:
    """
    Advanced HTTP client tool with comprehensive networking capabilities and monitoring.
    
    This tool provides sophisticated HTTP client functionality with connection pooling,
    intelligent retry mechanisms, comprehensive monitoring, and extensible callback
    system. It's designed for high-performance API interactions with robust error
    handling and security features.
    
    Features:
        - Full HTTP method support (GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS)
        - Intelligent connection pooling and session management
        - Configurable timeouts and retry mechanisms
        - Comprehensive request/response logging and monitoring
        - JSON and form data handling with automatic serialization
        - Custom headers and authentication support
        - Performance metrics and success rate tracking
        - Extensible callback system for request/response processing
        - Security features including URL validation and SSL verification
    
    Attributes:
        metadata (ToolMetadata): Tool configuration and schema information.
        callbacks (List[Callable]): List of callback functions for request processing.
        request_stats (Dict): Comprehensive request statistics and metrics.
        _session (aiohttp.ClientSession): Reusable HTTP session for connection pooling.
        _performance_metrics (Dict): Detailed performance tracking data.
    
    Example:
        >>> client = HTTPClientTool()
        >>> 
        >>> # Add request monitoring callback
        >>> async def monitor_requests(result, context):
        ...     logger.info(f"Request to {result['url']}: {result['status_code']}")
        >>> client.add_callback(monitor_requests)
        >>> 
        >>> # Make authenticated API call
        >>> result = await client.execute(
        ...     "https://api.example.com/users",
        ...     method="POST",
        ...     headers={"Authorization": "Bearer token123"},
        ...     data={"name": "John Doe", "email": "john@example.com"},
        ...     context=agent_context
        ... )
        >>> 
        >>> # Check request statistics
        >>> stats = client.get_stats()
        >>> print(f"Success rate: {stats['success_rate']:.2%}")
    """
    
    def __init__(self):
        """
        Initialize HTTPClientTool with comprehensive configuration and monitoring.
        
        Sets up the HTTP client with connection pooling, performance tracking,
        security configuration, and callback system for optimal performance
        and reliability.
        """
        logger.info("Initializing HTTPClientTool with advanced networking capabilities")
        
        # Tool metadata configuration
        self.metadata = ToolMetadata(
            purpose="Advanced HTTP client for API calls and web communication",
            input_schema={
                "url": {
                    "type": "string",
                    "description": "Target URL for the HTTP request",
                    "format": "uri"
                },
                "method": {
                    "type": "string",
                    "enum": ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
                    "default": "GET",
                    "description": "HTTP method to use for the request"
                },
                "headers": {
                    "type": "object",
                    "description": "Custom headers to include in the request",
                    "additionalProperties": {"type": "string"}
                },
                "data": {
                    "type": ["object", "string", "null"],
                    "description": "Request body data (JSON object or string)"
                },
                "timeout": {
                    "type": "number",
                    "default": 30,
                    "minimum": 1,
                    "maximum": 300,
                    "description": "Request timeout in seconds"
                }
            },
            output_schema={
                "type": "object",
                "properties": {
                    "status_code": {"type": "integer"},
                    "headers": {"type": "object"},
                    "data": {"type": ["object", "string"]},
                    "url": {"type": "string"},
                    "method": {"type": "string"},
                    "success": {"type": "boolean"},
                    "response_time": {"type": "number"},
                    "content_type": {"type": "string"}
                }
            },
            execution_mode=ToolExecutionMode.PARALLEL,
            resource_requirements={"memory_mb": 5, "cpu_cores": 0.1},
            timeout=60
        )
        
        # Callback system for extensible processing
        self.callbacks = []
        
        # Comprehensive request statistics
        self.request_stats = {
            'total': 0,
            'successful': 0,
            'failed': 0,
            'by_method': {},
            'by_status_code': {},
            'total_response_time': 0.0,
            'average_response_time': 0.0
        }
        
        # Performance metrics tracking
        self._performance_metrics = {
            'fastest_request': float('inf'),
            'slowest_request': 0.0,
            'total_bytes_sent': 0,
            'total_bytes_received': 0,
            'connection_errors': 0,
            'timeout_errors': 0
        }
        
        # HTTP session for connection pooling (will be created when needed)
        self._session = None
        
        logger.debug("HTTPClientTool initialization completed successfully")
    
    async def execute(self, url: str, method: str = "GET", headers: Dict = None, data: Any = None, **kwargs) -> Dict[str, Any]:
        """Execute HTTP request with comprehensive monitoring."""
        context = kwargs.get('context')
        self.request_stats['total'] += 1
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=data if data else None,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    
                    result = {
                        'status_code': response.status,
                        'headers': dict(response.headers),
                        'url': str(response.url),
                        'method': method,
                        'success': 200 <= response.status < 300
                    }
                    
                    # Get response content
                    # Get response content using conditional expression
                    result['data'] = (await response.json() 
                                    if response.content_type == 'application/json' 
                                    else await response.text())
                    
                    # Update stats
                    # Update stats using conditional expression
                    stat_key = 'successful' if result['success'] else 'failed'
                    self.request_stats[stat_key] += 1
                    
                    # Execute callbacks functionally
                    await asyncio.gather(*[callback(result, context) for callback in self.callbacks], return_exceptions=True)
                    
                    return result
                    
            except Exception as e:
                self.request_stats['failed'] += 1
                raise Exception(f"HTTP request failed: {e}")
    
    def add_callback(self, callback: Callable):
        """Add callback function for HTTP requests."""
        self.callbacks.append(callback)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get request statistics."""
        total = self.request_stats['total']
        return {
            **self.request_stats,
            'success_rate': self.request_stats['successful'] / total if total > 0 else 0
        }
    
    def should_skip(self, context: AgentContext) -> bool:
        """Skip predicate."""
        return context.constraints.get('disable_network', False)
    
    def on_failure(self, error: Exception, context: AgentContext) -> Any:
        """Failure handler."""
        return {'error': str(error), 'success': False}
    
    async def on_success(self, result: Any, context: AgentContext) -> None:
        """Success callback."""
        await context.event_system.emit_event(Event(
            type='http_request_complete',
            source='http_client_tool',
            data=result
        ))