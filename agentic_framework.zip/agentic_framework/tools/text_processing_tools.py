"""
Text processing tools for the agentic framework.

This module provides a comprehensive set of text processing tools following functional
programming principles with immutable data structures and pure functions.
"""

import re
import string
from typing import Dict, Any, List, Optional, Callable, Tuple
from collections import Counter
from functools import reduce, partial
from dataclasses import dataclass, field

from ..core.protocols import ToolProtocol, ToolMetadata, ToolExecutionMode


@dataclass(frozen=True)
class TextAnalysisResult:
    """Immutable result container for text analysis."""
    entities: Dict[str, List[str]] = field(default_factory=dict)
    patterns: Dict[str, Any] = field(default_factory=dict)
    statistics: Dict[str, Any] = field(default_factory=dict)
    structure: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SentimentResult:
    """Immutable result container for sentiment analysis."""
    sentiment: str
    confidence: float
    positive_words: int
    negative_words: int
    total_words: int


@dataclass(frozen=True)
class TokenizationResult:
    """Immutable result container for tokenization."""
    sentences: List[str]
    words: List[str]
    clean_words: List[str]
    unique_words: int
    character_counts: Dict[str, int]
    sentence_count: int
    word_count: int
    avg_word_length: float


@dataclass(frozen=True)
class StructureResult:
    """Immutable result container for structure analysis."""
    line_count: int
    paragraph_count: int
    empty_lines: int
    avg_line_length: float
    max_line_length: int
    min_line_length: int
    avg_paragraph_length: Optional[float] = None
    max_paragraph_length: Optional[int] = None
    min_paragraph_length: Optional[int] = None


# Pure functions for text analysis patterns
def create_analysis_patterns() -> Dict[str, re.Pattern]:
    """Create compiled regex patterns for text analysis."""
    patterns = {
        'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        'phone': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
        'url': r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w*))?)?',
        'hashtag': r'#\w+',
        'mention': r'@\w+',
        'currency': r'\$\d+(?:\.\d{2})?',
        'date': r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b',
        'time': r'\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM|am|pm)?\b'
    }
    return {name: re.compile(pattern) for name, pattern in patterns.items()}


# Pure functions for text processing
def extract_entities_by_pattern(text: str, patterns: Dict[str, re.Pattern]) -> Dict[str, List[str]]:
    """Extract entities using regex patterns (pure function)."""
    extract_matches = lambda pattern: pattern.findall(text)
    entity_matches = {name: extract_matches(pattern) for name, pattern in patterns.items()}
    return {k: v for k, v in entity_matches.items() if v}


def calculate_text_statistics(text: str) -> Dict[str, Any]:
    """Calculate basic text statistics (pure function)."""
    words = text.split()
    sentences = list(filter(str.strip, text.split('.')))
    paragraphs = list(filter(str.strip, text.split('\n\n')))
    
    safe_divide = lambda a, b: a / b if b > 0 else 0
    
    return {
        'character_count': len(text),
        'word_count': len(words),
        'sentence_count': len(sentences),
        'paragraph_count': len(paragraphs),
        'avg_word_length': safe_divide(sum(map(len, words)), len(words)),
        'avg_sentence_length': safe_divide(len(words), len(sentences))
    }


def detect_text_features(text: str) -> Dict[str, Any]:
    """Detect various text features (pure function)."""
    lines = text.split('\n')
    
    # Feature detection functions
    has_title = lambda: (
        bool(lines) and 
        len(lines[0].strip()) < 100 and 
        not lines[0].strip().endswith('.') and 
        len(lines[0].split()) <= 10
    )
    
    header_patterns = [
        r'^#{1,6}\s+.+$',  # Markdown headers
        r'^.+\n[=-]+$',    # Underlined headers
        r'^\d+\.\s+.+$'    # Numbered headers
    ]
    has_headers = lambda: any(re.search(pattern, text, re.MULTILINE) for pattern in header_patterns)
    
    list_patterns = [
        r'^\s*[-*+]\s+.+$',     # Bullet lists
        r'^\s*\d+\.\s+.+$',     # Numbered lists
        r'^\s*[a-zA-Z]\.\s+.+$' # Lettered lists
    ]
    has_lists = lambda: any(re.search(pattern, text, re.MULTILINE) for pattern in list_patterns)
    
    code_patterns = [
        r'```[\s\S]*?```',      # Markdown code blocks
        r'`[^`]+`',             # Inline code
        r'^\s{4,}.+$',          # Indented code
        r'<code>[\s\S]*?</code>' # HTML code tags
    ]
    has_code = lambda: any(re.search(pattern, text, re.MULTILINE) for pattern in code_patterns)
    
    return {
        'has_title': has_title(),
        'has_headers': has_headers(),
        'has_lists': has_lists(),
        'has_code': has_code(),
        'language_indicators': detect_language_indicators(text)
    }


def detect_language_indicators(text: str) -> List[str]:
    """Detect programming language indicators (pure function)."""
    language_keywords = {
        'python': ['def ', 'import ', 'class ', 'if __name__', 'print('],
        'javascript': ['function ', 'const ', 'let ', 'var ', 'console.log'],
        'java': ['public class', 'public static void', 'System.out'],
        'html': ['<html>', '<div>', '<span>', '<!DOCTYPE'],
        'css': ['{', '}', 'color:', 'font-size:', 'margin:'],
        'sql': ['SELECT ', 'FROM ', 'WHERE ', 'INSERT ', 'UPDATE ']
    }
    
    text_lower = text.lower()
    has_keywords = lambda lang_keywords: any(keyword.lower() in text_lower for keyword in lang_keywords)
    
    return [lang for lang, keywords in language_keywords.items() if has_keywords(keywords)]


def calculate_word_frequency(text: str, top_n: int = 10) -> Dict[str, int]:
    """Calculate word frequency (pure function)."""
    words = text.split()
    clean_word = lambda word: word.lower().strip(string.punctuation)
    clean_words = list(filter(None, map(clean_word, words)))
    word_freq = Counter(clean_words)
    return dict(word_freq.most_common(top_n))


# Sentiment analysis functions
def get_sentiment_words() -> Tuple[set, set]:
    """Get positive and negative sentiment word sets."""
    positive_words = {
        'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 
        'love', 'like', 'happy', 'joy', 'pleased', 'satisfied', 'awesome',
        'brilliant', 'outstanding', 'superb', 'magnificent', 'perfect'
    }
    negative_words = {
        'bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike', 
        'sad', 'angry', 'disappointed', 'frustrated', 'annoyed', 'poor',
        'dreadful', 'disgusting', 'appalling', 'atrocious', 'abysmal'
    }
    return positive_words, negative_words


def analyze_sentiment_scores(text: str) -> SentimentResult:
    """Analyze sentiment using word-based approach (pure function)."""
    positive_words, negative_words = get_sentiment_words()
    words = text.lower().split()
    
    clean_word = lambda word: word.strip(string.punctuation)
    clean_words = list(map(clean_word, words))
    
    positive_count = sum(1 for word in clean_words if word in positive_words)
    negative_count = sum(1 for word in clean_words if word in negative_words)
    total_sentiment_words = positive_count + negative_count
    
    if total_sentiment_words == 0:
        return SentimentResult('neutral', 0.5, positive_count, negative_count, len(words))
    elif positive_count > negative_count:
        confidence = positive_count / total_sentiment_words
        return SentimentResult('positive', confidence, positive_count, negative_count, len(words))
    elif negative_count > positive_count:
        confidence = negative_count / total_sentiment_words
        return SentimentResult('negative', confidence, positive_count, negative_count, len(words))
    else:
        return SentimentResult('neutral', 0.5, positive_count, negative_count, len(words))


# Tokenization functions
def tokenize_text_content(text: str) -> TokenizationResult:
    """Tokenize text into components (pure function)."""
    sentences = list(filter(str.strip, text.split('.')))
    words = text.split()
    
    clean_word = lambda word: word.strip(string.punctuation).lower()
    clean_words = list(filter(None, map(clean_word, words)))
    
    char_counts = {
        'letters': sum(1 for c in text if c.isalpha()),
        'digits': sum(1 for c in text if c.isdigit()),
        'spaces': sum(1 for c in text if c.isspace()),
        'punctuation': sum(1 for c in text if c in string.punctuation)
    }
    
    avg_word_length = sum(map(len, clean_words)) / len(clean_words) if clean_words else 0
    
    return TokenizationResult(
        sentences=sentences,
        words=words,
        clean_words=clean_words,
        unique_words=len(set(clean_words)),
        character_counts=char_counts,
        sentence_count=len(sentences),
        word_count=len(words),
        avg_word_length=avg_word_length
    )


# Structure analysis functions
def analyze_text_structure(text: str) -> StructureResult:
    """Analyze text structure (pure function)."""
    lines = text.split('\n')
    paragraphs = list(filter(str.strip, text.split('\n\n')))
    
    non_empty_lines = list(filter(str.strip, lines))
    
    structure = StructureResult(
        line_count=len(lines),
        paragraph_count=len(paragraphs),
        empty_lines=len(lines) - len(non_empty_lines),
        avg_line_length=sum(map(len, lines)) / len(lines) if lines else 0,
        max_line_length=max(map(len, lines)) if lines else 0,
        min_line_length=min(map(len, non_empty_lines)) if non_empty_lines else 0
    )
    
    if paragraphs:
        para_lengths = [len(p.split()) for p in paragraphs]
        structure_dict = structure.__dict__.copy()
        structure_dict.update({
            'avg_paragraph_length': sum(para_lengths) / len(para_lengths),
            'max_paragraph_length': max(para_lengths),
            'min_paragraph_length': min(para_lengths)
        })
        return StructureResult(**structure_dict)
    
    return structure


# Text transformation functions
def transform_text(text: str, transformation: str) -> str:
    """Transform text according to transformation type (pure function)."""
    transformations = {
        'uppercase': lambda t: t.upper(),
        'lowercase': lambda t: t.lower(),
        'title_case': lambda t: t.title(),
        'reverse': lambda t: t[::-1],
        'remove_punctuation': lambda t: ''.join(c for c in t if c not in string.punctuation),
        'remove_extra_spaces': lambda t: ' '.join(t.split()),
        'extract_words': lambda t: ' '.join(re.findall(r'\b\w+\b', t))
    }
    
    transform_func = transformations.get(transformation, lambda t: t)
    return transform_func(text)


# Tool implementations using ToolProtocol
class SentimentAnalyzerTool(ToolProtocol):
    """Sentiment analysis tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Analyzes sentiment of text using word-based approach",
            input_schema={"text": {"type": "string"}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=30,
            resource_requirements={"memory_mb": 50, "cpu_cores": 1},
            version="1.0.0",
            tags=["sentiment", "text", "analysis"]
        )
    
    async def execute(self, text: str, **kwargs) -> Dict[str, Any]:
        """Execute sentiment analysis."""
        if not isinstance(text, str):
            return self.on_failure(ValueError("Input must be a string"), None)
        
        result = analyze_sentiment_scores(text)
        return {
            'sentiment': result.sentiment,
            'confidence': round(result.confidence, 3),
            'positive_words': result.positive_words,
            'negative_words': result.negative_words,
            'total_words': result.total_words
        }
    
    def should_skip(self, context) -> bool:
        """Check if tool should be skipped."""
        return False
    
    async def on_success(self, result: Any, context) -> None:
        """Handle successful execution."""
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        """Handle execution failure."""
        return {
            'sentiment': 'neutral',
            'confidence': 0.0,
            'positive_words': 0,
            'negative_words': 0,
            'total_words': 0,
            'error': str(error)
        }


class TextTokenizerTool(ToolProtocol):
    """Text tokenization tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Tokenizes text into sentences, words, and characters",
            input_schema={"text": {"type": "string"}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=30,
            resource_requirements={"memory_mb": 100, "cpu_cores": 1},
            version="1.0.0",
            tags=["tokenization", "text", "processing"]
        )
    
    async def execute(self, text: str, **kwargs) -> Dict[str, Any]:
        """Execute text tokenization."""
        if not isinstance(text, str):
            return self.on_failure(ValueError("Input must be a string"), None)
        
        result = tokenize_text_content(text)
        return {
            'sentences': result.sentences,
            'words': result.words,
            'clean_words': result.clean_words,
            'unique_words': result.unique_words,
            'character_counts': result.character_counts,
            'sentence_count': result.sentence_count,
            'word_count': result.word_count,
            'avg_word_length': result.avg_word_length
        }
    
    def should_skip(self, context) -> bool:
        """Check if tool should be skipped."""
        return False
    
    async def on_success(self, result: Any, context) -> None:
        """Handle successful execution."""
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        """Handle execution failure."""
        return {
            'sentences': [],
            'words': [],
            'clean_words': [],
            'unique_words': 0,
            'character_counts': {},
            'sentence_count': 0,
            'word_count': 0,
            'avg_word_length': 0.0,
            'error': str(error)
        }


class TextStructureAnalyzerTool(ToolProtocol):
    """Text structure analysis tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Analyzes text structure including lines, paragraphs, and formatting",
            input_schema={"text": {"type": "string"}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=30,
            resource_requirements={"memory_mb": 75, "cpu_cores": 1},
            version="1.0.0",
            tags=["structure", "text", "analysis"]
        )
    
    async def execute(self, text: str, **kwargs) -> Dict[str, Any]:
        """Execute structure analysis."""
        result = analyze_text_structure(text)
        return result.__dict__
    
    def should_skip(self, context) -> bool:
        """Check if tool should be skipped."""
        return False
    
    async def on_success(self, result: Any, context) -> None:
        """Handle successful execution."""
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        """Handle execution failure."""
        return {
            'line_count': 0,
            'paragraph_count': 0,
            'empty_lines': 0,
            'avg_line_length': 0.0,
            'max_line_length': 0,
            'min_line_length': 0,
            'error': str(error)
        }


class EntityExtractorTool(ToolProtocol):
    """Entity extraction tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Extracts entities like emails, phones, URLs from text",
            input_schema={"text": {"type": "string"}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=30,
            resource_requirements={"memory_mb": 60, "cpu_cores": 1},
            version="1.0.0",
            tags=["entity", "extraction", "text"]
        )
        self.patterns = create_analysis_patterns()
    
    async def execute(self, text: str, **kwargs) -> Dict[str, List[str]]:
        """Execute entity extraction."""
        return extract_entities_by_pattern(text, self.patterns)
    
    def should_skip(self, context) -> bool:
        """Check if tool should be skipped."""
        return False
    
    async def on_success(self, result: Any, context) -> None:
        """Handle successful execution."""
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        """Handle execution failure."""
        return {'error': str(error)}


class TextTransformerTool(ToolProtocol):
    """Text transformation tool following ToolProtocol."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Transforms text using various transformation methods",
            input_schema={"text": {"type": "string"}, "transformation": {"type": "string"}},
            output_schema={"type": "string"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=30,
            resource_requirements={"memory_mb": 40, "cpu_cores": 1},
            version="1.0.0",
            tags=["transformation", "text", "processing"]
        )
    
    async def execute(self, text: str, transformation: str = 'lowercase', **kwargs) -> str:
        """Execute text transformation."""
        return transform_text(text, transformation)
    
    def should_skip(self, context) -> bool:
        """Check if tool should be skipped."""
        return False
    
    async def on_success(self, result: Any, context) -> None:
        """Handle successful execution."""
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        """Handle execution failure."""
        return f"Transformation failed: {error}"


class ComprehensiveTextAnalyzerTool(ToolProtocol):
    """Comprehensive text analysis tool combining all analyses."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Performs comprehensive text analysis including all text processing features",
            input_schema={"text": {"type": "string"}},
            output_schema={"type": "object"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            timeout=60,
            resource_requirements={"memory_mb": 200, "cpu_cores": 1},
            version="1.0.0",
            tags=["comprehensive", "text", "analysis"]
        )
        self.patterns = create_analysis_patterns()
    
    async def execute(self, text: str, **kwargs) -> Dict[str, Any]:
        """Execute comprehensive text analysis."""
        # Use functional composition to combine all analyses
        analyses = [
            ('entities', lambda: extract_entities_by_pattern(text, self.patterns)),
            ('statistics', lambda: calculate_text_statistics(text)),
            ('structure_features', lambda: detect_text_features(text)),
            ('structure_analysis', lambda: analyze_text_structure(text).__dict__),
            ('sentiment', lambda: analyze_sentiment_scores(text).__dict__),
            ('tokenization', lambda: tokenize_text_content(text).__dict__),
            ('word_frequency', lambda: calculate_word_frequency(text))
        ]
        
        # Execute all analyses and combine results functionally
        def safe_execute_analysis(name_func):
            name, analysis_func = name_func
            try:
                return name, analysis_func()
            except Exception as e:
                return name, {'error': str(e)}
        
        results = dict(map(safe_execute_analysis, analyses))
        
        return results
    
    def should_skip(self, context) -> bool:
        """Check if tool should be skipped."""
        return False
    
    async def on_success(self, result: Any, context) -> None:
        """Handle successful execution."""
        pass
    
    def on_failure(self, error: Exception, context) -> Any:
        """Handle execution failure."""
        return {'error': str(error), 'analysis_failed': True}