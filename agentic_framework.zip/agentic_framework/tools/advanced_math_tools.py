"""
Advanced mathematical tools for the agentic framework.

This module provides enhanced mathematical capabilities including:
- Advanced trigonometry functions
- Statistical analysis tools
- Linear algebra operations
- Calculus operations
- Number theory functions
"""

import math
import statistics
import re
from typing import List, Dict, Any, Union, Optional, Tuple
from functools import reduce
import operator

# No base class needed - tools are standalone classes


class AdvancedTrigonometryTool:
    """Advanced trigonometry operations beyond basic sin/cos/tan."""
    
    def __init__(self):
        self.name = "advanced_trigonometry"
        self.description = "Advanced trigonometric functions including hyperbolic, inverse, and conversions"
        
        # Add metadata for compatibility
        from agentic_framework.core.protocols import ToolMetadata, ToolExecutionMode
        self.metadata = ToolMetadata(
            purpose="Advanced trigonometric calculations",
            input_schema={"expression": {"type": "string"}},
            output_schema={"type": "number"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 1, "cpu_cores": 0.1},
            timeout=5
        )
    
    def _parse_function_call(self, expression: str) -> Optional[Tuple[str, List[float]]]:
        """Parse function call expression into function name and arguments."""
        # Match function_name(arg1, arg2, ...)
        match = re.match(r'(\w+)\s*\(\s*(.*?)\s*\)', expression.strip())
        if not match:
            return None
        
        func_name = match.group(1)
        args_str = match.group(2)
        
        if not args_str.strip():
            return func_name, []
        
        # Parse arguments functionally
        try:
            args = [float(arg.strip()) for arg in args_str.split(',') if arg.strip()]
            return func_name, args
        except ValueError:
            return None
    
    async def execute(self, expression: str) -> Union[float, str]:
        """Execute advanced trigonometric operations."""
        try:
            # Parse function and arguments
            func_match = self._parse_function_call(expression)
            if not func_match:
                return f"Invalid function format: {expression}"
            
            func_name, args = func_match
            
            # Advanced trigonometric functions
            advanced_trig_functions = {
                'sinh': math.sinh,
                'cosh': math.cosh,
                'tanh': math.tanh,
                'asinh': math.asinh,
                'acosh': math.acosh,
                'atanh': math.atanh,
                'sec': lambda x: 1 / math.cos(x),
                'csc': lambda x: 1 / math.sin(x),
                'cot': lambda x: 1 / math.tan(x),
                'asec': lambda x: math.acos(1 / x),
                'acsc': lambda x: math.asin(1 / x),
                'acot': lambda x: math.atan(1 / x),
                'deg2rad': math.radians,
                'rad2deg': math.degrees,
                'sinc': lambda x: math.sin(x) / x if x != 0 else 1.0
            }
            
            if func_name in advanced_trig_functions:
                if len(args) != 1:
                    return f"Function {func_name} requires exactly 1 argument"
                
                result = advanced_trig_functions[func_name](args[0])
                return round(result, 10)
            
            return f"Unknown advanced trigonometric function: {func_name}"
            
        except Exception as e:
            return f"Error in advanced trigonometry: {str(e)}"


class StatisticalAnalysisTool:
    """Enhanced statistical analysis operations."""
    
    def __init__(self):
        self.name = "statistical_analysis"
        self.description = "Advanced statistical functions including distributions and hypothesis testing"
        
        # Add metadata for compatibility
        from agentic_framework.core.protocols import ToolMetadata, ToolExecutionMode
        self.metadata = ToolMetadata(
            purpose="Advanced statistical analysis",
            input_schema={"expression": {"type": "string"}},
            output_schema={"type": ["number", "object"]},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 2, "cpu_cores": 0.2},
            timeout=10
        )
    
    def _parse_function_call(self, expression: str) -> Optional[Tuple[str, List[float]]]:
        """Parse function call expression into function name and arguments."""
        match = re.match(r'(\w+)\s*\(\s*(.*?)\s*\)', expression.strip())
        if not match:
            return None
        
        func_name = match.group(1)
        args_str = match.group(2)
        
        if not args_str.strip():
            return func_name, []
        
        try:
            # Parse arguments functionally
            args = [float(arg.strip()) for arg in args_str.split(',') if arg.strip()]
            return func_name, args
        except ValueError:
            return None
    
    async def execute(self, expression: str) -> Union[float, str, Dict[str, float]]:
        """Execute statistical analysis operations."""
        try:
            func_match = self._parse_function_call(expression)
            if not func_match:
                return f"Invalid function format: {expression}"
            
            func_name, args = func_match
            
            # Statistical functions
            if func_name == 'describe':
                if len(args) < 2:
                    return "describe() requires at least 2 values"
                
                return {
                    'count': len(args),
                    'mean': statistics.mean(args),
                    'median': statistics.median(args),
                    'mode': statistics.mode(args) if len(set(args)) < len(args) else None,
                    'stdev': statistics.stdev(args) if len(args) > 1 else 0,
                    'variance': statistics.variance(args) if len(args) > 1 else 0,
                    'min': min(args),
                    'max': max(args),
                    'range': max(args) - min(args),
                    'q1': statistics.quantiles(args, n=4)[0] if len(args) >= 4 else None,
                    'q3': statistics.quantiles(args, n=4)[2] if len(args) >= 4 else None
                }
            
            elif func_name == 'correlation':
                if len(args) % 2 != 0 or len(args) < 4:
                    return "correlation() requires pairs of values (even number, min 4)"
                
                mid = len(args) // 2
                x_values = args[:mid]
                y_values = args[mid:]
                
                # Pearson correlation coefficient
                n = len(x_values)
                sum_x = sum(x_values)
                sum_y = sum(y_values)
                sum_xy = sum(x * y for x, y in zip(x_values, y_values))
                sum_x2 = sum(x * x for x in x_values)
                sum_y2 = sum(y * y for y in y_values)
                
                numerator = n * sum_xy - sum_x * sum_y
                denominator = math.sqrt((n * sum_x2 - sum_x**2) * (n * sum_y2 - sum_y**2))
                
                if denominator == 0:
                    return "Cannot calculate correlation: zero variance"
                
                return round(numerator / denominator, 6)
            
            elif func_name == 'zscore':
                if len(args) < 2:
                    return "zscore() requires value and dataset"
                
                value = args[0]
                dataset = args[1:]
                mean_val = statistics.mean(dataset)
                stdev_val = statistics.stdev(dataset) if len(dataset) > 1 else 1
                
                return round((value - mean_val) / stdev_val, 6)
            
            elif func_name == 'percentile':
                if len(args) < 2:
                    return "percentile() requires percentile value and dataset"
                
                percentile = args[0]
                dataset = sorted(args[1:])
                
                if not (0 <= percentile <= 100):
                    return "Percentile must be between 0 and 100"
                
                index = (percentile / 100) * (len(dataset) - 1)
                lower = int(index)
                upper = min(lower + 1, len(dataset) - 1)
                weight = index - lower
                
                return dataset[lower] * (1 - weight) + dataset[upper] * weight
            
            return f"Unknown statistical function: {func_name}"
            
        except Exception as e:
            return f"Error in statistical analysis: {str(e)}"


class LinearAlgebraTool:
    """Basic linear algebra operations."""
    
    def __init__(self):
        self.name = "linear_algebra"
        self.description = "Basic linear algebra operations for vectors and matrices"
        
        # Add metadata for compatibility
        from agentic_framework.core.protocols import ToolMetadata, ToolExecutionMode
        self.metadata = ToolMetadata(
            purpose="Linear algebra operations",
            input_schema={"expression": {"type": "string"}},
            output_schema={"type": ["number", "array"]},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 3, "cpu_cores": 0.2},
            timeout=10
        )
    
    def _parse_function_call(self, expression: str) -> Optional[Tuple[str, List[float]]]:
        """Parse function call expression into function name and arguments."""
        match = re.match(r'(\w+)\s*\(\s*(.*?)\s*\)', expression.strip())
        if not match:
            return None
        
        func_name = match.group(1)
        args_str = match.group(2)
        
        if not args_str.strip():
            return func_name, []
        
        try:
            # Parse arguments functionally
            args = [float(arg.strip()) for arg in args_str.split(',') if arg.strip()]
            return func_name, args
        except ValueError:
            return None
    
    async def execute(self, expression: str) -> Union[float, List[float], str]:
        """Execute linear algebra operations."""
        try:
            func_match = self._parse_function_call(expression)
            if not func_match:
                return f"Invalid function format: {expression}"
            
            func_name, args = func_match
            
            if func_name == 'dot_product':
                if len(args) % 2 != 0 or len(args) < 4:
                    return "dot_product() requires two vectors of equal length"
                
                mid = len(args) // 2
                vector1 = args[:mid]
                vector2 = args[mid:]
                
                if len(vector1) != len(vector2):
                    return "Vectors must have equal length for dot product"
                
                return sum(a * b for a, b in zip(vector1, vector2))
            
            elif func_name == 'magnitude':
                if len(args) < 1:
                    return "magnitude() requires at least one component"
                
                return math.sqrt(sum(x * x for x in args))
            
            elif func_name == 'normalize':
                if len(args) < 1:
                    return "normalize() requires at least one component"
                
                mag = math.sqrt(sum(x * x for x in args))
                if mag == 0:
                    return "Cannot normalize zero vector"
                
                return [x / mag for x in args]
            
            elif func_name == 'cross_product':
                if len(args) != 6:
                    return "cross_product() requires two 3D vectors (6 components)"
                
                a = args[:3]
                b = args[3:]
                
                return [
                    a[1] * b[2] - a[2] * b[1],
                    a[2] * b[0] - a[0] * b[2],
                    a[0] * b[1] - a[1] * b[0]
                ]
            
            return f"Unknown linear algebra function: {func_name}"
            
        except Exception as e:
            return f"Error in linear algebra: {str(e)}"


class CalculusTool:
    """Basic calculus operations using numerical methods."""
    
    def __init__(self):
        self.name = "calculus"
        self.description = "Basic calculus operations including derivatives and integrals"
        
        # Add metadata for compatibility
        from agentic_framework.core.protocols import ToolMetadata, ToolExecutionMode
        self.metadata = ToolMetadata(
            purpose="Calculus operations",
            input_schema={"expression": {"type": "string"}},
            output_schema={"type": "number"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 2, "cpu_cores": 0.3},
            timeout=15
        )
    
    def _parse_function_call(self, expression: str) -> Optional[Tuple[str, List[float]]]:
        """Parse function call expression into function name and arguments."""
        match = re.match(r'(\w+)\s*\(\s*(.*?)\s*\)', expression.strip())
        if not match:
            return None
        
        func_name = match.group(1)
        args_str = match.group(2)
        
        if not args_str.strip():
            return func_name, []
        
        try:
            # Parse arguments functionally
            args = [float(arg.strip()) for arg in args_str.split(',') if arg.strip()]
            return func_name, args
        except ValueError:
            return None
    
    async def execute(self, expression: str) -> Union[float, str]:
        """Execute calculus operations."""
        try:
            func_match = self._parse_function_call(expression)
            if not func_match:
                return f"Invalid function format: {expression}"
            
            func_name, args = func_match
            
            if func_name == 'derivative':
                # Simple numerical derivative: f'(x) ≈ (f(x+h) - f(x-h)) / (2h)
                if len(args) < 2:
                    return "derivative() requires function type and x value"
                
                func_type = int(args[0])  # 1=x^2, 2=sin(x), 3=exp(x), etc.
                x = args[1]
                h = args[2] if len(args) > 2 else 1e-8
                
                def f(val):
                    if func_type == 1:  # x^2
                        return val * val
                    elif func_type == 2:  # sin(x)
                        return math.sin(val)
                    elif func_type == 3:  # exp(x)
                        return math.exp(val)
                    elif func_type == 4:  # ln(x)
                        return math.log(val) if val > 0 else float('nan')
                    else:
                        return val  # linear function
                
                derivative = (f(x + h) - f(x - h)) / (2 * h)
                return round(derivative, 8)
            
            elif func_name == 'integral':
                # Simple numerical integration using trapezoidal rule
                if len(args) < 4:
                    return "integral() requires function type, start, end, and steps"
                
                func_type = int(args[0])
                start = args[1]
                end = args[2]
                steps = int(args[3])
                
                def f(val):
                    if func_type == 1:  # x^2
                        return val * val
                    elif func_type == 2:  # sin(x)
                        return math.sin(val)
                    elif func_type == 3:  # exp(x)
                        return math.exp(val)
                    elif func_type == 4:  # ln(x)
                        return math.log(val) if val > 0 else 0
                    else:
                        return val  # linear function
                
                h = (end - start) / steps
                integral = (f(start) + f(end)) / 2
                
                # Calculate integral functionally
                integral += sum(f(start + i * h) for i in range(1, steps))
                
                integral *= h
                return round(integral, 8)
            
            return f"Unknown calculus function: {func_name}"
            
        except Exception as e:
            return f"Error in calculus: {str(e)}"


class NumberTheoryTool:
    """Number theory and discrete mathematics operations."""
    
    def __init__(self):
        self.name = "number_theory"
        self.description = "Number theory functions including primes, GCD, LCM, and factorization"
        
        # Add metadata for compatibility
        from agentic_framework.core.protocols import ToolMetadata, ToolExecutionMode
        self.metadata = ToolMetadata(
            purpose="Number theory operations",
            input_schema={"expression": {"type": "string"}},
            output_schema={"type": ["integer", "boolean", "array"]},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 2, "cpu_cores": 0.2},
            timeout=10
        )
    
    def _parse_function_call(self, expression: str) -> Optional[Tuple[str, List[float]]]:
        """Parse function call expression into function name and arguments."""
        match = re.match(r'(\w+)\s*\(\s*(.*?)\s*\)', expression.strip())
        if not match:
            return None
        
        func_name = match.group(1)
        args_str = match.group(2)
        
        if not args_str.strip():
            return func_name, []
        
        try:
            # Parse arguments functionally
            args = [float(arg.strip()) for arg in args_str.split(',') if arg.strip()]
            return func_name, args
        except ValueError:
            return None
    
    async def execute(self, expression: str) -> Union[int, List[int], bool, str]:
        """Execute number theory operations."""
        try:
            func_match = self._parse_function_call(expression)
            if not func_match:
                return f"Invalid function format: {expression}"
            
            func_name, args = func_match
            
            # Convert to integers
            int_args = [int(arg) for arg in args]
            
            if func_name == 'gcd':
                if len(int_args) < 2:
                    return "gcd() requires at least 2 numbers"
                
                return reduce(math.gcd, int_args)
            
            elif func_name == 'lcm':
                if len(int_args) < 2:
                    return "lcm() requires at least 2 numbers"
                
                def lcm_two(a, b):
                    return abs(a * b) // math.gcd(a, b)
                
                return reduce(lcm_two, int_args)
            
            elif func_name == 'is_prime':
                if len(int_args) != 1:
                    return "is_prime() requires exactly 1 number"
                
                n = int_args[0]
                if n < 2:
                    return False
                if n == 2:
                    return True
                if n % 2 == 0:
                    return False
                
                # Check primality functionally
                return not any(n % i == 0 for i in range(3, int(math.sqrt(n)) + 1, 2))
                return True
            
            elif func_name == 'prime_factors':
                if len(int_args) != 1:
                    return "prime_factors() requires exactly 1 number"
                
                n = int_args[0]
                factors = []
                d = 2
                
                while d * d <= n:
                    while n % d == 0:
                        factors.append(d)
                        n //= d
                    d += 1
                
                if n > 1:
                    factors.append(n)
                
                return factors
            
            elif func_name == 'fibonacci':
                if len(int_args) != 1:
                    return "fibonacci() requires exactly 1 number"
                
                n = int_args[0]
                if n < 0:
                    return "Fibonacci sequence requires non-negative number"
                if n <= 1:
                    return n
                
                a, b = 0, 1
                # Generate fibonacci sequence functionally
                from functools import reduce
                def fib_step(acc, _):
                    return acc[1], acc[0] + acc[1]
                
                a, b = reduce(fib_step, range(2, n + 1), (0, 1))
                
                return b
            
            elif func_name == 'factorial':
                if len(int_args) != 1:
                    return "factorial() requires exactly 1 number"
                
                n = int_args[0]
                if n < 0:
                    return "Factorial requires non-negative number"
                
                return math.factorial(n)
            
            return f"Unknown number theory function: {func_name}"
            
        except Exception as e:
            return f"Error in number theory: {str(e)}"


class CombinatoricsTool:
    """Combinatorics and probability operations."""
    
    def __init__(self):
        self.name = "combinatorics"
        self.description = "Combinatorics functions including permutations, combinations, and probability"
        
        # Add metadata for compatibility
        from agentic_framework.core.protocols import ToolMetadata, ToolExecutionMode
        self.metadata = ToolMetadata(
            purpose="Combinatorics operations",
            input_schema={"expression": {"type": "string"}},
            output_schema={"type": ["integer", "number"]},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 2, "cpu_cores": 0.2},
            timeout=10
        )
    
    def _parse_function_call(self, expression: str) -> Optional[Tuple[str, List[float]]]:
        """Parse function call expression into function name and arguments."""
        match = re.match(r'(\w+)\s*\(\s*(.*?)\s*\)', expression.strip())
        if not match:
            return None
        
        func_name = match.group(1)
        args_str = match.group(2)
        
        if not args_str.strip():
            return func_name, []
        
        try:
            # Parse arguments functionally
            args = [float(arg.strip()) for arg in args_str.split(',') if arg.strip()]
            return func_name, args
        except ValueError:
            return None
    
    async def execute(self, expression: str) -> Union[int, float, str]:
        """Execute combinatorics operations."""
        try:
            func_match = self._parse_function_call(expression)
            if not func_match:
                return f"Invalid function format: {expression}"
            
            func_name, args = func_match
            
            # Convert to appropriate types
            if func_name in ['permutation', 'combination', 'binomial']:
                int_args = [int(arg) for arg in args]
            else:
                int_args = args
            
            if func_name == 'permutation':
                if len(int_args) != 2:
                    return "permutation() requires exactly 2 numbers (n, r)"
                
                n, r = int_args
                if r > n or r < 0 or n < 0:
                    return "Invalid permutation parameters"
                
                return math.factorial(n) // math.factorial(n - r)
            
            elif func_name == 'combination':
                if len(int_args) != 2:
                    return "combination() requires exactly 2 numbers (n, r)"
                
                n, r = int_args
                if r > n or r < 0 or n < 0:
                    return "Invalid combination parameters"
                
                return math.factorial(n) // (math.factorial(r) * math.factorial(n - r))
            
            elif func_name == 'binomial':
                if len(int_args) != 3:
                    return "binomial() requires exactly 3 numbers (n, k, p)"
                
                n, k = int_args[:2]
                p = float(args[2])
                
                if not (0 <= p <= 1):
                    return "Probability must be between 0 and 1"
                
                # Binomial probability: C(n,k) * p^k * (1-p)^(n-k)
                combination = math.factorial(n) // (math.factorial(k) * math.factorial(n - k))
                probability = combination * (p ** k) * ((1 - p) ** (n - k))
                
                return round(probability, 8)
            
            return f"Unknown combinatorics function: {func_name}"
            
        except Exception as e:
            return f"Error in combinatorics: {str(e)}"