"""
Safe development tool for function calls with functional programming.
"""

from typing import Dict, Any, List
from functools import reduce
from operator import mul

from ..core.protocols import ToolProtocol, ToolMetadata, ToolExecutionMode
from ..core.context import AgentContext
from ..core.data_structures import Event


class SafeDevTool:
    """Safe development tool for function calls."""
    
    def __init__(self):
        self.metadata = ToolMetadata(
            purpose="Safe function call execution",
            input_schema={
                "function_name": {"type": "string"},
                "args": {"type": "array", "items": {"type": "number"}}
            },
            output_schema={"type": "number"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 2, "cpu_cores": 0.1},
            timeout=5
        )
        
        # Functional approach: functions as pure operations
        self._functions = {
            'add': lambda args: sum(args),
            'sub': lambda args: args[0] - sum(args[1:]) if args else 0,
            'mul': lambda args: reduce(mul, args, 1),
            'div': lambda args: self._safe_divide_args(args),
            'pow': lambda args: args[0] ** args[1] if len(args) >= 2 else 0,
            'mod': lambda args: self._safe_modulo_args(args)
        }
        
        # Validation predicates
        self._validators = {
            'div': lambda args: len(args) >= 2 and args[1] != 0,
            'pow': lambda args: len(args) >= 2,
            'mod': lambda args: len(args) >= 2 and args[1] != 0,
            'sub': lambda args: len(args) >= 1
        }
    
    async def execute(self, function_name: str, *args, **kwargs) -> float:
        """Execute function call using functional approach."""
        func_name = function_name.lower()
        
        # Functional validation
        validator = self._validators.get(func_name, lambda args: True)
        if not validator(args):
            raise ValueError(f"Invalid arguments for {function_name}: {args}")
        
        # Functional execution
        func = self._functions.get(func_name)
        if not func:
            raise ValueError(f"Unknown function: {function_name}")
        
        return func(args)
    
    def should_skip(self, context: AgentContext) -> bool:
        """Skip if function calls are disabled."""
        return context.constraints.get('disable_functions', False)
    
    def on_failure(self, error: Exception, context: AgentContext) -> Any:
        """Return appropriate default values."""
        return 0.0  # Safe default for mathematical operations
    
    async def on_success(self, result: Any, context: AgentContext) -> None:
        """Track function usage statistics."""
        await context.event_system.emit_event(Event(
            type='function_executed',
            source='safe_dev_tool',
            data={'result': result, 'functions_available': len(self._functions)}
        ))
    
    @staticmethod
    def _safe_divide_args(args):
        """Safe division for argument list."""
        if len(args) >= 2 and args[1] != 0:
            return args[0] / args[1]
        return float('inf')
    
    @staticmethod
    def _safe_modulo_args(args):
        """Safe modulo for argument list."""
        if len(args) >= 2 and args[1] != 0:
            return args[0] % args[1]
        return float('nan')