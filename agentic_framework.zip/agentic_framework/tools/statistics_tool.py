"""
Statistics tool for mathematical operations.

This tool provides statistical functions like mean, median, std dev, etc.
"""

import math
import statistics
from typing import Any, Dict, List, Union


class StatisticsTool:
    """Tool for statistical calculations."""
    
    def __init__(self):
        self.name = "statistics"
        self.description = "Performs statistical calculations (mean, median, std dev, etc.)"
        self.version = "1.0.0"
        
        # Add metadata for compatibility
        from agentic_framework.core.protocols import ToolMetadata, ToolExecutionMode
        self.metadata = ToolMetadata(
            purpose="Statistical calculations",
            input_schema={
                "function_name": {"type": "string"},
                "data": {"type": "array", "items": {"type": "number"}}
            },
            output_schema={"type": "number"},
            execution_mode=ToolExecutionMode.SEQUENTIAL,
            resource_requirements={"memory_mb": 2, "cpu_cores": 0.1},
            timeout=10
        )
        
        # Statistical function mapping
        self.stats_functions = {
            'mean': statistics.mean,
            'median': statistics.median,
            'mode': statistics.mode,
            'stdev': statistics.stdev,
            'variance': statistics.variance,
            'pstdev': statistics.pstdev,
            'pvariance': statistics.pvariance,
            'harmonic_mean': statistics.harmonic_mean,
            'geometric_mean': statistics.geometric_mean,
            'min': min,
            'max': max,
            'sum': sum,
            'count': len,
            'range': lambda data: max(data) - min(data)
        }
    
    async def execute(self, function_name: str, data: List[Union[int, float]], **kwargs) -> Union[float, int]:
        """
        Execute statistical function.
        
        Args:
            function_name: Name of the statistical function
            data: List of numerical data
            **kwargs: Additional parameters
            
        Returns:
            Result of the statistical calculation
            
        Raises:
            ValueError: If function is unknown or data is invalid
        """
        if function_name not in self.stats_functions:
            available_functions = ', '.join(self.stats_functions.keys())
            raise ValueError(f"Unknown statistical function: {function_name}. Available: {available_functions}")
        
        if not data:
            raise ValueError("Data list cannot be empty")
        
        # Validate data types functionally
        if not all(isinstance(x, (int, float)) for x in data):
            raise ValueError("All data points must be numbers")
        
        try:
            func = self.stats_functions[function_name]
            result = func(data)
            
            # Handle special cases
            if isinstance(result, float):
                if math.isnan(result):
                    raise ValueError(f"Result is NaN for {function_name}")
                if math.isinf(result):
                    raise ValueError(f"Result is infinite for {function_name}")
            
            return result
            
        except statistics.StatisticsError as e:
            raise ValueError(f"Statistics error for {function_name}: {e}")
        except (ValueError, ZeroDivisionError) as e:
            raise ValueError(f"Error calculating {function_name}: {e}")
        except Exception as e:
            raise ValueError(f"Unexpected error in statistical calculation: {e}")
    
    async def execute_percentile(self, data: List[Union[int, float]], percentile: float) -> float:
        """
        Calculate percentile of data.
        
        Args:
            data: List of numerical data
            percentile: Percentile to calculate (0-100)
            
        Returns:
            Percentile value
        """
        if not 0 <= percentile <= 100:
            raise ValueError("Percentile must be between 0 and 100")
        
        if not data:
            raise ValueError("Data list cannot be empty")
        
        sorted_data = sorted(data)
        n = len(sorted_data)
        
        if percentile == 0:
            return sorted_data[0]
        if percentile == 100:
            return sorted_data[-1]
        
        # Calculate percentile using linear interpolation
        index = (percentile / 100) * (n - 1)
        lower_index = int(index)
        upper_index = min(lower_index + 1, n - 1)
        
        if lower_index == upper_index:
            return sorted_data[lower_index]
        
        # Linear interpolation
        weight = index - lower_index
        return sorted_data[lower_index] * (1 - weight) + sorted_data[upper_index] * weight
    
    async def execute_correlation(self, x_data: List[Union[int, float]], 
                                y_data: List[Union[int, float]]) -> float:
        """
        Calculate Pearson correlation coefficient.
        
        Args:
            x_data: First dataset
            y_data: Second dataset
            
        Returns:
            Correlation coefficient (-1 to 1)
        """
        if len(x_data) != len(y_data):
            raise ValueError("Both datasets must have the same length")
        
        if len(x_data) < 2:
            raise ValueError("Need at least 2 data points for correlation")
        
        try:
            return statistics.correlation(x_data, y_data)
        except Exception as e:
            raise ValueError(f"Error calculating correlation: {e}")
    
    def get_supported_functions(self) -> list:
        """Get list of supported statistical functions."""
        return list(self.stats_functions.keys()) + ['percentile', 'correlation']
    
    def validate_data(self, data: List[Union[int, float]]) -> bool:
        """
        Validate input data for statistical functions.
        
        Args:
            data: Input data list
            
        Returns:
            True if data is valid
        """
        if not data:
            return False
        
        # Validate data types functionally
        if not all(isinstance(x, (int, float)) for x in data):
            return False
        
        # Check for all NaN or infinite values functionally
        float_values = filter(lambda x: isinstance(x, float), data)
        if all(math.isnan(x) or math.isinf(x) for x in float_values):
            return False
        
        return True