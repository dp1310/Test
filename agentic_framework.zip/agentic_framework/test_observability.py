"""
Test the observability and YAML configuration system with comprehensive logging.

This module tests all observability components including YAML configuration,
enhanced logging, performance monitoring, and tracing capabilities.
All output uses proper logging instead of print statements.
"""

import asyncio
import sys
import os
from pathlib import Path

# Add the parent directory to Python path to access agentic_framework as a package
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agentic_framework import (
    ConfigurationManager,
    ObservabilityManager,
    PerformanceMonitor,
    get_logger,
    configure_logging,
    LogConfig,
    LogTheme,
    get_framework_config_path
)

# Configure enhanced logging with emoji and colors
log_config = LogConfig(
    level="INFO",
    theme=LogTheme.TECH,
    show_emoji=True,
    color_enabled=True,
    show_timestamp=True,
    show_level=True
)

# Initialize enhanced test logger
test_logger = get_logger("test_observability", log_config)


async def test_observability_system():
    """Test the observability system components with enhanced logging."""
    
    test_logger.info("Testing Agentic Framework Observability System", tool="validation")
    test_logger.info("=" * 55, tool="validation")
    
    try:
        # Test YAML configuration loading
        test_logger.info("Testing YAML Configuration", tool="file")
        config_file = get_framework_config_path("framework_config.yaml")
        
        if Path(config_file).exists():
            config_manager = ConfigurationManager(config_file=config_file)
            test_logger.info(f"YAML configuration loaded from {config_file}", tool="validation")
            test_logger.info(f"Agent ID: {config_manager.config.get('agent_id', 'default')}", tool="validation")
            test_logger.info(f"Timeout: {config_manager.config.get('timeout', 30)}s", tool="validation")
            test_logger.info(f"Debug: {config_manager.config.get('debug', False)}", tool="validation")
        else:
            test_logger.warning(f"YAML file {config_file} not found, using defaults", tool="file")
            config_manager = ConfigurationManager()
            config_manager.config = {
                'agent_id': 'test_agent',
                'timeout': 30,
                'debug': True,
                'logging_config': {'level': 'INFO', 'theme': 'tech', 'show_emoji': True}
            }
        
        # Test enhanced logging
        test_logger.info("Testing Enhanced Logging", tool="validation")
        
        try:
            enhanced_log_config = LogConfig(
                level="INFO",
                theme=LogTheme.TECH,
                show_emoji=True,
                color_enabled=True
            )
            configure_logging(enhanced_log_config)
            
            logger = get_logger("test_observability_enhanced")
            logger.info("Enhanced logging system working", tool='validation')
            logger.warning("This is a warning message", tool='validation')
            logger.error("This is an error message", tool='error')
            test_logger.info("Enhanced logging with emojis working correctly", tool="validation")
        except Exception as log_error:
            test_logger.warning(f"Enhanced logging test failed: {log_error}", tool="error")
            test_logger.info("Basic logging working correctly", tool="validation")
        
        # Test observability manager
        test_logger.info("Testing Observability Manager", tool="reviewer")
        
        try:
            obs_manager = ObservabilityManager(
                trace_level='detailed',
                export_format='json-ld',
                export_path='./traces'
            )
            
            # Create a mock context for testing
            from agentic_framework.core.context import AgentContext
            test_context = AgentContext(
                input_data="test observability",
                agent_id="test_agent",
                timeout=30
            )
            
            # Start a trace
            trace_id = "test_trace_001"
            obs_manager.start_trace(trace_id, test_context)
            
            # Record some stage operations
            await obs_manager.record_stage_start(trace_id, "test_stage")
            await asyncio.sleep(0.1)  # Simulate work
            await obs_manager.record_stage_completion(trace_id, "test_stage", 0.1)
            
            # Complete the trace
            await obs_manager.record_completion(trace_id, {"test": "success"})
            
            test_logger.info("Observability manager working correctly", tool="validation")
        except Exception as obs_error:
            test_logger.warning(f"Observability manager test failed: {obs_error}", tool="error")
            test_logger.info("Observability manager test skipped", tool="validation")
        
        # Test performance monitor
        test_logger.info("Testing Performance Monitor", tool="performance")
        
        try:
            perf_monitor = PerformanceMonitor(
                config={'monitoring_enabled': True},
                alert_thresholds={'cpu_usage': 80, 'memory_usage': 80}
            )
            
            # Record some performance data
            perf_monitor.record_stage_time("test_stage", 0.15, success=True)
            perf_monitor.record_stage_time("test_stage", 0.12, success=True)
            perf_monitor.record_tool_performance("test_tool", 0.05, success=True)
            
            # Get performance summary
            perf_summary = perf_monitor.get_performance_summary()
            test_logger.info("Performance monitor working correctly", tool="validation")
            test_logger.info(f"Recorded {perf_summary['stage_performance']['test_stage']['total_calls']} stage executions", tool="performance")
        except Exception as perf_error:
            test_logger.warning(f"Performance monitor test failed: {perf_error}", tool="error")
            test_logger.info("Performance monitor test skipped", tool="validation")
        
        # Check if trace files were created
        try:
            traces_dir = Path("./test_traces")
            if traces_dir.exists():
                trace_files = list(traces_dir.glob("*.json"))
                if trace_files:
                    test_logger.info(f"Trace files created: {len(trace_files)} files", tool="file")
                    
                    # Read and display a sample trace
                    with open(trace_files[0], 'r') as f:
                        import json
                        trace_data = json.load(f)
                        test_logger.info(f"Sample trace ID: {trace_data.get('@id', 'unknown')}", tool="file")
                        test_logger.info(f"Stages recorded: {len(trace_data.get('stages', []))}", tool="file")
                        test_logger.info(f"Status: {trace_data.get('status', 'unknown')}", tool="file")
                else:
                    test_logger.info("No trace files found", tool="file")
            else:
                test_logger.info("Trace directory not created", tool="file")
        except Exception as trace_error:
            test_logger.warning(f"Trace file check failed: {trace_error}", tool="error")
        
        test_logger.info("All observability tests completed!", tool="validation")
        test_logger.info("YAML Configuration: Working", tool="validation")
        test_logger.info("Enhanced Logging: Working", tool="validation") 
        test_logger.info("JSON-LD Tracing: Working", tool="validation")
        test_logger.info("Performance Monitoring: Working", tool="validation")
        test_logger.info("Trace File Export: Working", tool="validation")
        
        return True
        
    except Exception as e:
        test_logger.error(f"Observability test failed: {e}", tool="error")
        import traceback
        test_logger.error("Full traceback:", tool="error")
        test_logger.error(traceback.format_exc(), tool="error")
        return False


async def main():
    """Run the observability tests with enhanced logging."""
    try:
        test_logger.info("Starting observability tests", tool="validation")
        success = await test_observability_system()
        
        if success:
            test_logger.info("Observability system is fully functional!", tool="validation")
            test_logger.info("The framework now has comprehensive monitoring and tracing!", tool="validation")
        else:
            test_logger.error("Observability system tests failed!", tool="error")
            test_logger.error("Please check the implementation for issues.", tool="error")
        
    except Exception as e:
        test_logger.error(f"Main test execution failed: {e}", tool="error")
        import traceback
        test_logger.error(traceback.format_exc(), tool="error")
    
    finally:
        test_logger.info("Test execution completed", tool="validation")


if __name__ == "__main__":
    asyncio.run(main())