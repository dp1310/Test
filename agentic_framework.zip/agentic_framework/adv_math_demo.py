"""
Simple demonstration of the next steps implementation.

This script demonstrates the key achievements from implementing the next steps:
1. Expanded Tool Collection (Advanced Math Tools)
2. Multiple Domain Pipelines (Text, Data Analysis)
3. Enhanced Framework Features
"""

import asyncio
import json
from pathlib import Path

# Import the working components and logging
from agentic_framework.examples.production_math_processor import ProductionMathProcessor
from agentic_framework.core.logger import get_logger

# Initialize logger
demo_logger = get_logger("AdvancedMathDemo")

# Functional utilities
def partition_results(predicate, iterable):
    """Partition results into two lists based on predicate."""
    true_items, false_items = [], []
    for item in iterable:
        (true_items if predicate(item) else false_items).append(item)
    return true_items, false_items

def calculate_success_metrics(results):
    """Calculate success metrics from results using functional approach."""
    return {
        'total': len(results),
        'successful': sum(1 for r in results if r.get('success', False)),
        'success_rate': lambda total, successful: successful / total if total > 0 else 0
    }


async def demo_working_math_features():
    """Demonstrate the working mathematical processing features."""
    demo_logger.info("=" * 60)
    demo_logger.info("🧮 WORKING MATHEMATICAL PROCESSING FEATURES")
    demo_logger.info("=" * 60)
    
    processor = ProductionMathProcessor()
    
    # Test cases that work with current implementation
    test_cases = [
        {
            'name': 'Basic Arithmetic',
            'input': 'Calculate 15+25, 8*9, and 100/4',
            'description': 'Basic arithmetic operations'
        },
        {
            'name': 'Power Operations',
            'input': 'Compute 2^8, 3^4, and 5^3',
            'description': 'Power calculations'
        },
        {
            'name': 'Mixed Operations',
            'input': 'Evaluate 50-25, 6*7, 144/12, and 2^6',
            'description': 'Mixed mathematical operations'
        }
    ]
    
    results = []
    
    # Process test cases functionally
    async def process_test_case(i_test_case):
        i, test_case = i_test_case
        demo_logger.info(f"📝 Test Case {i}: {test_case['name']}")
        demo_logger.info(f"Description: {test_case['description']}")
        demo_logger.info(f"Input: {test_case['input']}")
        
        try:
            result = await processor.execute(test_case['input'])
            
            if result['success']:
                act_results = result['results'].get('act', {})
                execution_results = act_results.get('execution_results', [])
                
                successful = sum(1 for r in execution_results if r['success'])
                total = len(execution_results)
                
                demo_logger.info(f"✅ Success: {successful}/{total} expressions executed")
                
                # Log results functionally using partition utility
                successful_results, failed_results = partition_results(
                    lambda r: r['success'], execution_results
                )
                
                # Log successful and failed results
                list(map(lambda r: demo_logger.info(f"   ✓ {r['expression']} = {r['result']}"), successful_results))
                list(map(lambda r: demo_logger.error(f"   ✗ {r['expression']} = ERROR: {r['error']}"), failed_results))
                
                return {'test_case': test_case['name'], 'success': True, 'total': total, 'successful': successful}
            else:
                demo_logger.error("❌ Pipeline execution failed")
                return {'test_case': test_case['name'], 'success': False}
                
        except Exception as e:
            demo_logger.error(f"❌ Test case failed: {e}")
            return {'test_case': test_case['name'], 'success': False, 'error': str(e)}
    
    # Process all test cases
    results = await asyncio.gather(*[process_test_case(item) for item in enumerate(test_cases, 1)])
    
    # Summary using functional aggregation
    metrics = calculate_success_metrics(results)
    successful_tests = metrics['successful']
    total_expressions = sum(r.get('successful', 0) for r in results if r['success'])
    
    demo_logger.info("📊 Mathematical Processing Summary:")
    demo_logger.info(f"   Tests Passed: {successful_tests}/{len(results)}")
    demo_logger.info(f"   Total Expressions Executed: {total_expressions}")
    demo_logger.info("   Framework Features Working: Pipeline stages, parallel processing, error handling")
    
    return results


async def demo_advanced_tools_directly():
    """Demonstrate the advanced math tools directly."""
    demo_logger.info("=" * 60)
    demo_logger.info("🔧 ADVANCED MATH TOOLS DIRECT DEMONSTRATION")
    demo_logger.info("=" * 60)
    
    # Import and test advanced tools directly
    from agentic_framework.tools.advanced_math_tools import (
        AdvancedTrigonometryTool, StatisticalAnalysisTool, LinearAlgebraTool,
        NumberTheoryTool, CombinatoricsTool
    )
    
    tools_tests = [
        {
            'name': 'Advanced Trigonometry',
            'tool': AdvancedTrigonometryTool(),
            'tests': [
                'sinh(1.5)',
                'cosh(2.0)',
                'tanh(0.5)',
                'deg2rad(90)'
            ]
        },
        {
            'name': 'Statistical Analysis',
            'tool': StatisticalAnalysisTool(),
            'tests': [
                'describe(1,2,3,4,5,6,7,8,9,10)',
                'correlation(1,2,3,4,5,2,4,6,8,10)',
                'zscore(5,1,2,3,4,5,6,7,8,9,10)'
            ]
        },
        {
            'name': 'Linear Algebra',
            'tool': LinearAlgebraTool(),
            'tests': [
                'dot_product(1,2,3,4,5,6)',
                'magnitude(3,4,5)',
                'cross_product(1,0,0,0,1,0)'
            ]
        },
        {
            'name': 'Number Theory',
            'tool': NumberTheoryTool(),
            'tests': [
                'gcd(48,18)',
                'fibonacci(10)',
                'is_prime(17)',
                'factorial(6)'
            ]
        },
        {
            'name': 'Combinatorics',
            'tool': CombinatoricsTool(),
            'tests': [
                'combination(10,3)',
                'permutation(5,2)',
                'binomial(10,3,0.5)'
            ]
        }
    ]
    
    results = []
    
    # Process tool tests functionally
    async def test_tool(tool_test):
        demo_logger.info(f"🔧 Testing {tool_test['name']}:")
        tool = tool_test['tool']
        
        async def execute_test_expression(test_expr):
            try:
                result = await tool.execute(test_expr)
                demo_logger.info(f"   ✓ {test_expr} = {result}")
                return {'expression': test_expr, 'result': result, 'success': True}
            except Exception as e:
                demo_logger.error(f"   ✗ {test_expr} = ERROR: {e}")
                return {'expression': test_expr, 'error': str(e), 'success': False}
        
        # Execute all test expressions for this tool
        tool_results = await asyncio.gather(*[execute_test_expression(expr) for expr in tool_test['tests']])
        
        successful = sum(1 for r in tool_results if r['success'])
        total = len(tool_results)
        
        return {
            'tool': tool_test['name'],
            'success_rate': successful / total if total > 0 else 0,
            'successful': successful,
            'total': total
        }
    
    # Test all tools
    results = await asyncio.gather(*[test_tool(tool_test) for tool_test in tools_tests])
    
    # Summary using functional logging
    demo_logger.info("📊 Advanced Tools Summary:")
    log_tool_result = lambda result: demo_logger.info(
        f"   {result['tool']}: {result['successful']}/{result['total']} tests passed ({result['success_rate']:.1%})"
    )
    list(map(log_tool_result, results))
    
    return results


async def main():
    """Main demonstration function."""
    demo_logger.info("🚀 TOOLS IMPLEMENTATION DEMONSTRATION")
    demo_logger.info("=" * 80)
    
    try:
        # 1. Demonstrate working mathematical features
        math_results = await demo_working_math_features()
        
        # 2. Demonstrate advanced tools directly
        tools_results = await demo_advanced_tools_directly()
        
        # Calculate success metrics functionally
        math_success = len(list(filter(lambda r: r['success'], math_results)))
        tools_success = sum(r['successful'] for r in tools_results)
        tools_total = sum(r['total'] for r in tools_results)
        
        demo_logger.info("📊 IMPLEMENTATION RESULTS:")
        demo_logger.info(f"   Mathematical Pipeline: {math_success}/3 test cases passed")
        demo_logger.info(f"   Advanced Tools: {tools_success}/{tools_total} functions working ({tools_success/tools_total:.1%})")
        
        # Log final status
        overall_success_rate = (math_success + tools_success) / (3 + tools_total) if (3 + tools_total) > 0 else 0
        status_emoji = "🎉" if overall_success_rate >= 0.9 else "✅" if overall_success_rate >= 0.7 else "⚠️"
        demo_logger.info(f"{status_emoji} Overall Success Rate: {overall_success_rate:.1%}")
        
    except Exception as e:
        demo_logger.error(f"❌ Demonstration failed: {e}")
        import traceback
        demo_logger.error(f"Traceback: {traceback.format_exc()}")


if __name__ == "__main__":
    asyncio.run(main())