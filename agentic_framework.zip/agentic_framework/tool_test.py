#!/usr/bin/env python3
"""
Final test of refactored tools and examples.

This test demonstrates the functionality of the newly refactored text and data
processing tools, showing both individual tool usage and full pipeline execution.
"""

import asyncio
import logging
from agentic_framework import get_logger

# Configure logging for the test
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(name)s | %(message)s',
    datefmt='%H:%M:%S'
)

logger = get_logger("ToolsTest")

async def test_examples():
    """Test both updated examples."""
    logger.info("🧪 Testing Updated Examples")
    logger.info("=" * 40)
    
    # Test text processor
    try:
        from agentic_framework.examples.text_processor import TextPipelineController
        
        controller = TextPipelineController(agent_id='test_text')
        result = await controller.execute('This is amazing! Contact us at test@example.com')
        
        logger.info(f"✅ Text Processor: Success={result['success']}, Time={result['execution_time']:.3f}s")
        
    except Exception as e:
        logger.error(f"❌ Text Processor failed: {e}")
    
    # Test data processor
    try:
        from agentic_framework.examples.data_processor import DataPipelineController
        
        controller = DataPipelineController(agent_id='test_data')
        sample_data = "name,age,score\nAlice,25,85.5\nBob,30,92.0"
        result = await controller.execute(sample_data)
        
        logger.info(f"✅ Data Processor: Success={result['success']}, Time={result['execution_time']:.3f}s")
        
    except Exception as e:
        logger.error(f"❌ Data Processor failed: {e}")

async def test_individual_tools():
    """Test individual tools directly."""
    logger.info("🔧 Testing Individual Tools")
    logger.info("=" * 40)
    
    # Test text tools
    try:
        from agentic_framework.tools.text_processing_tools import (
            SentimentAnalyzerTool, EntityExtractorTool, TextTokenizerTool
        )
        
        # Sentiment analysis
        sentiment_tool = SentimentAnalyzerTool()
        result = await sentiment_tool.execute("I love this amazing product!")
        logger.info(f"✅ Sentiment Tool: {result['sentiment']} ({result['confidence']:.2f})")
        
        # Entity extraction
        entity_tool = EntityExtractorTool()
        result = await entity_tool.execute("Contact us at support@example.com or call 555-1234")
        entities_found = sum(len(v) for v in result.values() if isinstance(v, list))
        logger.info(f"✅ Entity Tool: {entities_found} entities found")
        
        # Tokenization
        tokenizer_tool = TextTokenizerTool()
        result = await tokenizer_tool.execute("Hello world! This is a test.")
        logger.info(f"✅ Tokenizer Tool: {result['word_count']} words, {result['sentence_count']} sentences")
        
    except Exception as e:
        logger.error(f"❌ Text tools failed: {e}")
    
    # Test data tools
    try:
        from agentic_framework.tools.data_processing_tools import (
            DataParserTool, DataValidatorTool, DataAnalyzerTool
        )
        
        # Data parsing
        parser_tool = DataParserTool()
        sample_csv = "name,age,score\nAlice,25,85.5\nBob,30,92.0"
        result = await parser_tool.execute(sample_csv)
        logger.info(f"✅ Parser Tool: Parsed {len(result)} records")
        
        # Data validation
        validator_tool = DataValidatorTool()
        result = await validator_tool.execute([{"name": "Alice", "age": 25}, {"name": "Bob", "age": 30}])
        logger.info(f"✅ Validator Tool: {result['overall_validity_score']:.1f}% valid")
        
        # Statistical analysis
        analyzer_tool = DataAnalyzerTool()
        sample_data = [{"name": "Alice", "score": 85.5}, {"name": "Bob", "score": 92.0}]
        result = await analyzer_tool.execute(sample_data)
        stats_count = len(result['summary_statistics'])
        logger.info(f"✅ Analyzer Tool: {stats_count} numeric columns analyzed")
        
    except Exception as e:
        logger.error(f"❌ Data tools failed: {e}")

async def test_comprehensive_tools():
    """Test comprehensive analysis tools."""
    logger.info("🔍 Testing Comprehensive Tools")
    logger.info("=" * 40)
    
    # Comprehensive text analysis
    try:
        from agentic_framework.tools.text_processing_tools import ComprehensiveTextAnalyzerTool
        
        comprehensive_text = ComprehensiveTextAnalyzerTool()
        sample_text = """
        Welcome to our AI system! This is fantastic technology.
        
        Contact us at support@example.com or visit https://example.com
        Call us at 555-123-4567 for assistance.
        
        #AI #Technology #Innovation
        """
        
        result = await comprehensive_text.execute(sample_text)
        
        # Count successful analyses
        successful_analyses = sum(1 for v in result.values() if not (isinstance(v, dict) and 'error' in v))
        logger.info(f"✅ Comprehensive Text Tool: {successful_analyses} analyses completed")
        
        # Show sentiment if available
        if 'sentiment' in result and 'sentiment' in result['sentiment']:
            sentiment_data = result['sentiment']
            logger.info(f"   📊 Sentiment: {sentiment_data['sentiment']} ({sentiment_data['confidence']:.2f})")
        
        # Show entities if available
        if 'entities' in result and result['entities']:
            entity_count = sum(len(v) for v in result['entities'].values() if isinstance(v, list))
            logger.info(f"   🔍 Entities: {entity_count} found")
        
    except Exception as e:
        logger.error(f"❌ Comprehensive text tool failed: {e}")
    
    # Comprehensive data analysis
    try:
        from agentic_framework.tools.data_processing_tools import ComprehensiveDataAnalyzerTool
        
        comprehensive_data = ComprehensiveDataAnalyzerTool()
        sample_csv = """employee_id,name,age,salary,department
1001,Alice Johnson,25,75000.50,Engineering
1002,Bob Smith,30,82000.00,Marketing
1003,Charlie Brown,28,68000.75,Engineering"""
        
        result = await comprehensive_data.execute(sample_csv)
        
        # Show parsed data info
        if 'parsed_data' in result:
            parsed = result['parsed_data']
            if isinstance(parsed, list):
                logger.info(f"✅ Comprehensive Data Tool: {len(parsed)} records analyzed")
            else:
                logger.info(f"✅ Comprehensive Data Tool: {type(parsed).__name__} data processed")
        
        # Show structure analysis
        if 'structure_analysis' in result:
            structure = result['structure_analysis']
            if 'is_tabular' in structure:
                logger.info(f"   📊 Structure: Tabular={structure['is_tabular']}")
        
        # Show insights
        if 'insights' in result and 'key_findings' in result['insights']:
            findings_count = len(result['insights']['key_findings'])
            logger.info(f"   💡 Insights: {findings_count} key findings")
        
    except Exception as e:
        logger.error(f"❌ Comprehensive data tool failed: {e}")

async def test_functional_programming_features():
    """Demonstrate functional programming features."""
    logger.info("🔗 Testing Functional Programming Features")
    logger.info("=" * 40)
    
    try:
        # Import pure functions directly
        from agentic_framework.tools.text_processing_tools import (
            analyze_sentiment_scores, tokenize_text_content, extract_entities_by_pattern, create_analysis_patterns
        )
        from agentic_framework.tools.data_processing_tools import (
            parse_csv_data, calculate_summary_statistics, validate_tabular_data
        )
        
        # Test pure text functions
        text = "I love this amazing product! Contact me at test@example.com"
        
        # Pure sentiment analysis
        sentiment_result = analyze_sentiment_scores(text)
        logger.info(f"✅ Pure Sentiment Function: {sentiment_result.sentiment} ({sentiment_result.confidence:.2f})")
        
        # Pure tokenization
        token_result = tokenize_text_content(text)
        logger.info(f"✅ Pure Tokenizer Function: {token_result.word_count} words")
        
        # Pure entity extraction
        patterns = create_analysis_patterns()
        entities = extract_entities_by_pattern(text, patterns)
        entity_count = sum(len(v) for v in entities.values())
        logger.info(f"✅ Pure Entity Function: {entity_count} entities")
        
        # Test pure data functions
        csv_text = "name,age,score\nAlice,25,85.5\nBob,30,92.0"
        
        # Pure CSV parsing
        parsed_data = parse_csv_data(csv_text)
        logger.info(f"✅ Pure Parser Function: {len(parsed_data)} records")
        
        # Pure statistical analysis
        stats = calculate_summary_statistics(parsed_data)
        logger.info(f"✅ Pure Stats Function: {len(stats)} numeric columns")
        
        # Pure validation
        validation = validate_tabular_data(parsed_data)
        logger.info(f"✅ Pure Validation Function: {validation.overall_validity_score:.1f}% valid")
        
        logger.info("   🎯 All functions are pure (no side effects, deterministic)")
        
    except Exception as e:
        logger.error(f"❌ Functional programming test failed: {e}")

async def main():
    """Run all tests."""
    logger.info("🚀 AGENTIC FRAMEWORK TOOLS TEST SUITE")
    logger.info("=" * 50)
    
    await test_examples()
    await test_individual_tools()
    await test_comprehensive_tools()
    await test_functional_programming_features()
    
    logger.info("=" * 50)
    logger.info("✅ All tests completed successfully!")

if __name__ == "__main__":
    asyncio.run(main())