# Installation Guide

This guide provides detailed instructions for installing and setting up the Agentic Framework.

## System Requirements

### Python Version
- **Python 3.8 or higher** (recommended: Python 3.10+)
- **Operating System**: Windows, macOS, Linux

### Hardware Requirements
- **Minimum**: 2GB RAM, 1GB disk space
- **Recommended**: 8GB RAM, 5GB disk space (for full feature set)

## Installation Methods

### 1. Basic Installation (Recommended)

```bash
# Install from PyPI (when available)
pip install agentic-framework

# Or install from source
git clone https://github.com/agentic-framework/agentic-framework.git
cd agentic-framework
pip install -e .
```

### 2. Development Installation

```bash
# Clone the repository
git clone https://github.com/agentic-framework/agentic-framework.git
cd agentic-framework

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode with dev dependencies
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install
```

### 3. Feature-Specific Installation

```bash
# Mathematical and scientific computing
pip install agentic-framework[math]

# Machine learning capabilities
pip install agentic-framework[ml]

# Natural language processing
pip install agentic-framework[nlp]

# Data processing tools
pip install agentic-framework[data]

# Database connectivity
pip install agentic-framework[database]

# Web and API integration
pip install agentic-framework[web]

# All optional features
pip install agentic-framework[all]

# Multiple feature sets
pip install agentic-framework[math,data,nlp]
```

### 4. Docker Installation

```bash
# Pull the official image (when available)
docker pull agentic-framework:latest

# Or build from source
git clone https://github.com/agentic-framework/agentic-framework.git
cd agentic-framework
docker build -t agentic-framework .

# Run container
docker run -it agentic-framework
```

## Verification

### Quick Test
```bash
# Test basic installation
python -c "from agentic_framework.examples.math_processor import MathPipelineController; print('✅ Installation successful!')"

# Run built-in demo
agentic-demo

# Test mathematical processing
agentic-math "Calculate 2+3, 5*7"
```

### Comprehensive Test
```bash
# Run the test suite
pytest

# Run specific test categories
pytest tests/test_math_processor.py
pytest tests/test_data_processor.py
pytest tests/test_text_processor.py

# Run with coverage
pytest --cov=agentic_framework
```

## Configuration

### Environment Variables
```bash
# Set configuration via environment variables
export AGENTIC_TIMEOUT=60
export AGENTIC_DEBUG=true
export AGENTIC_LOGGING_CONFIG__LEVEL=INFO
```

### Configuration File
Create `config.yaml`:
```yaml
timeout: 60
debug: true
agent_id: 'my_agent'

logging_config:
  level: 'INFO'
  theme: 'tech'
  show_emoji: true
  color_enabled: true

performance_config:
  warning_threshold: 3.0
  critical_threshold: 8.0
  monitoring_enabled: true
```

## Troubleshooting

### Common Issues

#### Import Errors
```bash
# Ensure Python path is correct
export PYTHONPATH="${PYTHONPATH}:$(pwd)"

# Or add to your script
import sys
sys.path.append('.')
```

#### Missing Dependencies
```bash
# Install missing optional dependencies
pip install numpy scipy pandas

# Or install specific feature set
pip install agentic-framework[math,data]
```

#### Permission Issues (Linux/macOS)
```bash
# Use user installation
pip install --user agentic-framework

# Or fix permissions
sudo chown -R $USER:$USER ~/.local/
```

#### Windows-Specific Issues
```powershell
# Use PowerShell as administrator
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Install with Windows-specific options
pip install agentic-framework --user --no-warn-script-location
```

### Performance Issues

#### Memory Optimization
```python
# Configure memory management
memory_config = {
    'cleanup_threshold': 0.7,
    'warning_threshold': 0.8,
    'critical_threshold': 0.9
}
```

#### Parallel Processing
```python
# Enable parallel processing for better performance
processor = MathPipelineController(
    timeout=60,
    debug=False,  # Disable debug for better performance
    config={'parallel_processing': True}
)
```

## IDE Setup

### Visual Studio Code
Install recommended extensions:
- Python
- Pylance
- Black Formatter
- isort
- MyPy Type Checker

### PyCharm
Configure:
1. Set Python interpreter to your virtual environment
2. Enable type checking
3. Configure code style (Black + isort)

### Jupyter Notebook
```bash
# Install Jupyter support
pip install agentic-framework[jupyter]

# Start Jupyter
jupyter lab
```

## Next Steps

1. **Read the Documentation**: Check out the [API Reference](docs/api/)
2. **Try Examples**: Explore the [examples](examples/) directory
3. **Join the Community**: Visit our [GitHub Discussions](https://github.com/agentic-framework/agentic-framework/discussions)
4. **Contribute**: See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines

## Getting Help

- **Documentation**: https://agentic-framework.readthedocs.io
- **Issues**: https://github.com/agentic-framework/agentic-framework/issues
- **Discussions**: https://github.com/agentic-framework/agentic-framework/discussions
- **Email**: team@agentic-framework.dev

## Version Information

Check your installation:
```python
import agentic_framework
print(f"Agentic Framework version: {agentic_framework.__version__}")
```

For the latest version information, see [CHANGELOG.md](CHANGELOG.md).