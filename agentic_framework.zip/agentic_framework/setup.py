#!/usr/bin/env python3
"""
Setup script for the Agentic Framework.

This script provides installation configuration for the agentic framework,
including core dependencies, optional feature sets, and development tools.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# Read requirements
def read_requirements(filename):
    """Read requirements from file, filtering out comments and empty lines."""
    requirements_file = Path(__file__).parent / filename
    if not requirements_file.exists():
        return []
    
    with open(requirements_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # Filter out comments, empty lines, and -r references
    requirements = []
    for line in lines:
        line = line.strip()
        if line and not line.startswith('#') and not line.startswith('-r'):
            requirements.append(line)
    
    return requirements

# Core requirements (minimal dependencies)
install_requires = [
    "pyyaml>=6.0.1",
    "colorama>=0.4.6",
    "aiohttp>=3.8.5",
]

# Optional feature sets
extras_require = {
    # Mathematical and Scientific Computing
    'math': [
        'numpy>=1.24.0',
        'scipy>=1.10.0',
        'sympy>=1.12',
        'matplotlib>=3.7.0',
    ],
    
    # Machine Learning and AI
    'ml': [
        'scikit-learn>=1.3.0',
        'torch>=2.0.0',
        'transformers>=4.30.0',
        'sentence-transformers>=2.2.0',
    ],
    
    # Natural Language Processing
    'nlp': [
        'nltk>=3.8',
        'spacy>=3.5.0',
        'textblob>=0.17.1',
        'langdetect>=1.0.9',
    ],
    
    # Data Processing
    'data': [
        'pandas>=2.0.0',
        'polars>=0.18.0',
        'pyarrow>=12.0.0',
        'openpyxl>=3.1.0',
    ],
    
    # Database Support
    'database': [
        'sqlalchemy>=2.0.0',
        'asyncpg>=0.28.0',
        'aiosqlite>=0.19.0',
        'redis>=4.6.0',
    ],
    
    # Web and API Integration
    'web': [
        'httpx>=0.24.0',
        'fastapi>=0.100.0',
        'websockets>=11.0.0',
    ],
    
    # Monitoring and Observability
    'monitoring': [
        'prometheus-client>=0.17.0',
        'structlog>=23.1.0',
        'sentry-sdk>=1.29.0',
    ],
    
    # Development Tools
    'dev': [
        'pytest>=7.4.0',
        'pytest-asyncio>=0.21.0',
        'pytest-cov>=4.1.0',
        'black>=23.7.0',
        'mypy>=1.5.0',
        'flake8>=6.0.0',
    ],
    
    # All optional dependencies
    'all': [
        # This will be populated programmatically
    ]
}

# Populate 'all' with all other extras
all_extras = []
for key, deps in extras_require.items():
    if key != 'all':
        all_extras.extend(deps)
extras_require['all'] = list(set(all_extras))

setup(
    name="agentic-framework",
    version="1.0.0",
    author="Agentic Framework Team",
    author_email="team@agentic-framework.dev",
    description="A powerful, production-ready framework for building intelligent agent systems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/agentic-framework/agentic-framework",
    project_urls={
        "Bug Tracker": "https://github.com/agentic-framework/agentic-framework/issues",
        "Documentation": "https://agentic-framework.readthedocs.io",
        "Source Code": "https://github.com/agentic-framework/agentic-framework",
    },
    
    # Package configuration
    packages=find_packages(exclude=["tests*", "docs*", "examples*"]),
    include_package_data=True,
    package_data={
        "agentic_framework": [
            "config/*.yaml",
            "templates/*.json",
            "schemas/*.json",
        ],
    },
    
    # Dependencies
    python_requires=">=3.8",
    install_requires=install_requires,
    extras_require=extras_require,
    
    # Entry points for CLI tools
    entry_points={
        "console_scripts": [
            "agentic=agentic_framework.cli:main",
            "agentic-demo=agentic_framework.examples.demo:main",
            "agentic-math=agentic_framework.examples.math_processor:main",
            "agentic-data=agentic_framework.examples.data_processor:main",
            "agentic-text=agentic_framework.examples.text_processor:main",
        ],
    },
    
    # Classifiers for PyPI
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Distributed Computing",
        "Typing :: Typed",
    ],
    
    # Keywords for discoverability
    keywords=[
        "agent", "framework", "pipeline", "ai", "ml", "nlp", 
        "data-processing", "functional-programming", "async", 
        "observability", "production-ready"
    ],
    
    # Additional metadata
    zip_safe=False,
    platforms=["any"],
    
    # Test configuration
    test_suite="tests",
    tests_require=extras_require['dev'],
)