"""
Simple test for core framework components without Prefect server.

This module tests core framework functionality using proper logging
instead of print statements for better debugging and monitoring.
"""

import sys
import os

# Add the parent directory to Python path to access agentic_framework as a package
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agentic_framework.core.context import AgentContext
from agentic_framework.core.events import EventSystem
from agentic_framework.tools.math_tools import CalcTool
from agentic_framework.core.logger import get_logger, LogConfig, LogTheme

# Configure enhanced logging with emoji and colors
log_config = LogConfig(
    level="DEBUG",
    theme=LogTheme.TECH,
    show_emoji=True,
    color_enabled=True,
    show_timestamp=True,
    show_level=True
)

# Initialize enhanced test logger
test_logger = get_logger("simple_test", log_config)


def test_logging_showcase():
    """Showcase all available log levels and tool emojis."""
    
    test_logger.info("🎨 Enhanced Logging Showcase", tool="validation")
    test_logger.info("=" * 60, tool="validation")
    
    # Test all log levels
    test_logger.info("Testing all log levels:", tool="validation")
    test_logger.debug("Debug level message - detailed debugging info", tool="validation")
    test_logger.info("Info level message - general information", tool="validation")
    test_logger.warning("Warning level message - recoverable issues", tool="validation")
    test_logger.error("Error level message - error conditions", tool="validation")
    test_logger.critical("Critical level message - system failures", tool="validation")
    
    test_logger.info("-" * 40, tool="validation")
    
    # Test all available tool emojis
    test_logger.info("Testing all tool emojis:", tool="validation")
    test_logger.info("Core processing components", tool="processor")
    test_logger.info("Data perception and input processing", tool="perceiver")
    test_logger.info("Planning and strategy components", tool="planner")
    test_logger.info("Reasoning and decision-making logic", tool="reasoner")
    test_logger.info("Action execution and tool utilization", tool="actor")
    test_logger.info("Review and validation processes", tool="reviewer")
    test_logger.info("Learning and adaptation mechanisms", tool="learner")
    test_logger.info("General tool operations", tool="tool")
    test_logger.info("Performance monitoring", tool="performance")
    test_logger.info("Memory management", tool="memory")
    test_logger.info("Cache operations", tool="cache")
    test_logger.info("Retry mechanisms", tool="retry")
    test_logger.info("Network operations", tool="network")
    test_logger.info("File operations", tool="file")
    test_logger.info("Validation processes", tool="validation")
    test_logger.info("Error handling", tool="error")
    test_logger.info("Decision making", tool="decision")
    test_logger.info("Event processing", tool="event")
    
    test_logger.info("=" * 60, tool="validation")


def test_core_components():
    """Test core framework components using synchronous logging."""
    
    test_logger.info("Testing Agentic Framework Core Components", tool="validation")
    test_logger.info("=" * 50, tool="validation")
    
    try:
        # Test 1: Enhanced logging
        test_logger.info("Testing enhanced logging system", tool="validation")
        test_logger.info("Enhanced logging working correctly", tool="validation")
        
        # Test 2: Context management
        test_logger.info("Testing context management", tool="processor")
        try:
            context = AgentContext(
                input_data="test input",
                agent_id="test_agent",
                timeout=30
            )
            
            # Test immutable updates
            updated_context = context.with_stage_result("test_stage", {"result": "success"})
            assert updated_context.has_stage_result("test_stage")
            assert updated_context.get_stage_result("test_stage")["result"] == "success"
            test_logger.info("Context management working correctly", tool="processor")
        except Exception as e:
            test_logger.error(f"Context management test failed: {e}", tool="error")
            return False
        
        # Test 3: Event system (basic test without async processing)
        test_logger.info("Testing event system", tool="event")
        try:
            event_system = EventSystem()
            test_logger.info("Event system initialized correctly", tool="event")
        except Exception as e:
            test_logger.warning(f"Event system test failed: {e}", tool="event")
            test_logger.info("Event system test skipped", tool="event")
        
        # Test 4: Mathematical tools (simplified)
        test_logger.info("Testing mathematical tools", tool="tool")
        try:
            calc_tool = CalcTool()
            test_logger.info("Mathematical tools initialized correctly", tool="tool")
        except Exception as e:
            test_logger.error(f"Mathematical tools test failed: {e}", tool="error")
            return False
        
        test_logger.info("All core component tests passed!", tool="validation")
        test_logger.info("Framework core functionality is working correctly!", tool="validation")
        return True
        
    except Exception as e:
        test_logger.error(f"Test failed with error: {e}", tool="error")
        import traceback
        test_logger.error("Full traceback:", tool="error")
        test_logger.error(traceback.format_exc(), tool="error")
        return False


def main():
    """Run the core component tests with enhanced logging."""
    test_logger.info("Starting comprehensive framework tests", tool="validation")
    
    try:
        # First showcase all logging capabilities
        test_logging_showcase()
        
        test_logger.info("", tool="validation")  # Empty line for separation
        
        # Then run core component tests
        success = test_core_components()
        
        if success:
            test_logger.info("Core framework components are ready!", tool="validation")
            test_logger.info("You can now build applications using the agentic framework!", tool="validation")
        else:
            test_logger.error("Core component tests failed!", tool="error")
            test_logger.error("Please check the implementation for issues.", tool="error")
            
    except Exception as e:
        test_logger.error(f"Test execution failed: {e}", tool="error")
        import traceback
        test_logger.error(f"Full traceback: {traceback.format_exc()}", tool="error")
    finally:
        test_logger.info("All tests completed", tool="validation")


if __name__ == "__main__":
    main()