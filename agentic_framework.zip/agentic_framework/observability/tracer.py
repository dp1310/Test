"""
JSON-LD tracing system for comprehensive observability.

This module provides structured tracing with JSON-LD format for explainable
decision making and comprehensive workflow observability.
"""

import json
import time
import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path

from ..core.context import AgentContext
from ..core.data_structures import Decision, DecisionPoint


class JSONLDTracer:
    """JSON-LD tracer for comprehensive observability."""
    
    def __init__(self, 
                 output_format: str = 'json-ld',
                 trace_level: str = 'detailed',
                 export_path: str = './traces'):
        self.output_format = output_format
        self.trace_level = trace_level
        self.export_path = Path(export_path)
        self.export_path.mkdir(exist_ok=True)
        
        # Active traces
        self.active_traces: Dict[str, Dict[str, Any]] = {}
        self.completed_traces: List[Dict[str, Any]] = []
        
        # Metrics
        self.metrics = {
            'traces_started': 0,
            'traces_completed': 0,
            'decisions_recorded': 0,
            'errors_recorded': 0
        }
    
    def start_trace(self, trace_id: str, context: AgentContext) -> None:
        """Start a new trace for workflow execution."""
        self.metrics['traces_started'] += 1
        
        trace_data = {
            '@context': {
                '@vocab': 'https://agentic-framework.org/vocab/',
                'trace': 'https://agentic-framework.org/trace/',
                'agent': 'https://agentic-framework.org/agent/',
                'decision': 'https://agentic-framework.org/decision/'
            },
            '@type': 'WorkflowTrace',
            '@id': f'trace:{trace_id}',
            'startTime': datetime.utcnow().isoformat(),
            'agent': {
                '@type': 'Agent',
                '@id': f'agent:{context.agent_id}',
                'agentId': context.agent_id,
                'timeout': context.timeout,
                'constraints': context.constraints,
                'configuration': context.configuration
            },
            'input': {
                '@type': 'Input',
                'data': context.input_data,
                'timestamp': datetime.utcnow().isoformat()
            },
            'stages': [],
            'decisions': [],
            'events': [],
            'errors': [],
            'performance': {
                'startTime': time.time(),
                'stageMetrics': {},
                'resourceUsage': {}
            }
        }
        
        self.active_traces[trace_id] = trace_data
    
    async def record_stage_start(self, trace_id: str, stage: str) -> None:
        """Record the start of a pipeline stage."""
        if trace_id not in self.active_traces:
            return
        
        trace = self.active_traces[trace_id]
        stage_data = {
            '@type': 'StageExecution',
            '@id': f'stage:{stage}',
            'stageName': stage,
            'startTime': datetime.utcnow().isoformat(),
            'startTimestamp': time.time(),
            'status': 'started'
        }
        
        trace['stages'].append(stage_data)
    
    async def record_stage_completion(self, trace_id: str, stage: str, execution_time: float) -> None:
        """Record successful stage completion."""
        if trace_id not in self.active_traces:
            return
        
        trace = self.active_traces[trace_id]
        
        # Find the stage and update it
        for stage_data in trace['stages']:
            if stage_data['stageName'] == stage and stage_data['status'] == 'started':
                stage_data.update({
                    'endTime': datetime.utcnow().isoformat(),
                    'executionTime': execution_time,
                    'status': 'completed'
                })
                
                # Add performance metrics
                trace['performance']['stageMetrics'][stage] = {
                    'executionTime': execution_time,
                    'status': 'success'
                }
                break
    
    async def record_stage_error(self, trace_id: str, stage: str, error: Exception, execution_time: float) -> None:
        """Record stage error."""
        if trace_id not in self.active_traces:
            return
        
        trace = self.active_traces[trace_id]
        
        # Find the stage and update it
        for stage_data in trace['stages']:
            if stage_data['stageName'] == stage and stage_data['status'] == 'started':
                stage_data.update({
                    'endTime': datetime.utcnow().isoformat(),
                    'executionTime': execution_time,
                    'status': 'failed',
                    'error': {
                        '@type': 'Error',
                        'errorType': error.__class__.__name__,
                        'message': str(error),
                        'timestamp': datetime.utcnow().isoformat()
                    }
                })
                break
        
        # Add to errors list
        error_data = {
            '@type': 'StageError',
            'stage': stage,
            'errorType': error.__class__.__name__,
            'message': str(error),
            'timestamp': datetime.utcnow().isoformat(),
            'executionTime': execution_time
        }
        
        trace['errors'].append(error_data)
        self.metrics['errors_recorded'] += 1
    
    async def record_stage_timeout(self, trace_id: str, stage: str, execution_time: float) -> None:
        """Record stage timeout."""
        if trace_id not in self.active_traces:
            return
        
        trace = self.active_traces[trace_id]
        
        # Find the stage and update it
        for stage_data in trace['stages']:
            if stage_data['stageName'] == stage and stage_data['status'] == 'started':
                stage_data.update({
                    'endTime': datetime.utcnow().isoformat(),
                    'executionTime': execution_time,
                    'status': 'timeout'
                })
                break
        
        # Add timeout error
        timeout_error = {
            '@type': 'TimeoutError',
            'stage': stage,
            'executionTime': execution_time,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        trace['errors'].append(timeout_error)
        self.metrics['errors_recorded'] += 1
    
    async def record_decision(self, trace_id: str, decision: Decision, decision_point: DecisionPoint) -> None:
        """Record decision making with full reasoning."""
        if trace_id not in self.active_traces:
            return
        
        trace = self.active_traces[trace_id]
        
        decision_data = {
            '@type': 'Decision',
            '@id': f'decision:{decision_point.id}',
            'decisionPoint': {
                '@type': 'DecisionPoint',
                'id': decision_point.id,
                'description': decision_point.description,
                'type': decision_point.type,
                'constraints': decision_point.constraints
            },
            'chosenOption': {
                '@type': 'Option',
                'id': decision.chosen_option.id,
                'description': decision.chosen_option.description,
                'estimatedCost': decision.chosen_option.estimated_cost,
                'riskLevel': decision.chosen_option.risk_level,
                'requiresLLM': decision.chosen_option.requires_llm
            },
            'confidence': decision.confidence,
            'reasoning': decision.reasoning,
            'decisionTime': decision.decision_time,
            'timestamp': datetime.utcnow().isoformat(),
            'alternativesConsidered': [
                {
                    '@type': 'Option',
                    'id': alt.id,
                    'description': alt.description,
                    'estimatedCost': alt.estimated_cost,
                    'riskLevel': alt.risk_level
                }
                for alt in decision.alternatives_considered
            ],
            'contextUsed': decision.context_used
        }
        
        trace['decisions'].append(decision_data)
        self.metrics['decisions_recorded'] += 1
    
    async def record_event(self, trace_id: str, event_type: str, event_data: Dict[str, Any]) -> None:
        """Record framework events."""
        if trace_id not in self.active_traces:
            return
        
        trace = self.active_traces[trace_id]
        
        event_record = {
            '@type': 'Event',
            'eventType': event_type,
            'timestamp': datetime.utcnow().isoformat(),
            'data': event_data
        }
        
        trace['events'].append(event_record)
    
    async def record_completion(self, trace_id: str, result: Dict[str, Any]) -> None:
        """Record successful workflow completion."""
        if trace_id not in self.active_traces:
            return
        
        trace = self.active_traces[trace_id]
        
        # Complete the trace
        end_time = time.time()
        trace.update({
            'endTime': datetime.utcnow().isoformat(),
            'status': 'completed',
            'result': result,
            'performance': {
                **trace['performance'],
                'endTime': end_time,
                'totalExecutionTime': end_time - trace['performance']['startTime']
            }
        })
        
        # Move to completed traces
        self.completed_traces.append(trace)
        del self.active_traces[trace_id]
        
        # Export trace
        await self._export_trace(trace)
        
        self.metrics['traces_completed'] += 1
    
    async def record_error(self, trace_id: str, error: Exception, context_data: Dict[str, Any]) -> None:
        """Record workflow error."""
        if trace_id not in self.active_traces:
            return
        
        trace = self.active_traces[trace_id]
        
        # Complete the trace with error
        end_time = time.time()
        trace.update({
            'endTime': datetime.utcnow().isoformat(),
            'status': 'failed',
            'finalError': {
                '@type': 'WorkflowError',
                'errorType': error.__class__.__name__,
                'message': str(error),
                'timestamp': datetime.utcnow().isoformat(),
                'context': context_data
            },
            'performance': {
                **trace['performance'],
                'endTime': end_time,
                'totalExecutionTime': end_time - trace['performance']['startTime']
            }
        })
        
        # Move to completed traces
        self.completed_traces.append(trace)
        del self.active_traces[trace_id]
        
        # Export trace
        await self._export_trace(trace)
        
        self.metrics['errors_recorded'] += 1
    
    async def _export_trace(self, trace: Dict[str, Any]) -> None:
        """Export trace to file."""
        trace_id = trace['@id'].replace('trace:', '')
        filename = f"trace_{trace_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
        filepath = self.export_path / filename
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(trace, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Failed to export trace {trace_id}: {e}")
    
    def get_trace_summary(self, trace_id: str) -> Optional[Dict[str, Any]]:
        """Get summary of a trace."""
        # Check active traces
        if trace_id in self.active_traces:
            trace = self.active_traces[trace_id]
            return self._create_trace_summary(trace, 'active')
        
        # Check completed traces
        for trace in self.completed_traces:
            if trace['@id'] == f'trace:{trace_id}':
                return self._create_trace_summary(trace, 'completed')
        
        return None
    
    def _create_trace_summary(self, trace: Dict[str, Any], status: str) -> Dict[str, Any]:
        """Create trace summary."""
        return {
            'traceId': trace['@id'],
            'status': status,
            'agentId': trace['agent']['agentId'],
            'startTime': trace['startTime'],
            'endTime': trace.get('endTime'),
            'stagesCompleted': len([s for s in trace['stages'] if s['status'] == 'completed']),
            'totalStages': len(trace['stages']),
            'decisionsCount': len(trace['decisions']),
            'eventsCount': len(trace['events']),
            'errorsCount': len(trace['errors']),
            'executionTime': trace.get('performance', {}).get('totalExecutionTime')
        }
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get observability metrics."""
        return {
            **self.metrics,
            'active_traces': len(self.active_traces),
            'completed_traces': len(self.completed_traces)
        }


class ObservabilityManager:
    """Main observability manager coordinating all observability components."""
    
    def __init__(self, 
                 trace_level: str = 'detailed',
                 export_format: str = 'json-ld',
                 export_path: str = './traces'):
        self.tracer = JSONLDTracer(
            output_format=export_format,
            trace_level=trace_level,
            export_path=export_path
        )
        
        # Performance monitoring
        self.performance_data: Dict[str, List[float]] = {}
        self.resource_usage: Dict[str, Any] = {}
    
    def start_trace(self, trace_id: str, context: AgentContext) -> None:
        """Start observability for a workflow execution."""
        self.tracer.start_trace(trace_id, context)
    
    async def record_stage_start(self, trace_id: str, stage: str) -> None:
        """Record stage start."""
        await self.tracer.record_stage_start(trace_id, stage)
    
    async def record_stage_completion(self, trace_id: str, stage: str, execution_time: float) -> None:
        """Record stage completion."""
        await self.tracer.record_stage_completion(trace_id, stage, execution_time)
        
        # Track performance
        if stage not in self.performance_data:
            self.performance_data[stage] = []
        self.performance_data[stage].append(execution_time)
    
    async def record_stage_error(self, trace_id: str, stage: str, error: Exception, execution_time: float) -> None:
        """Record stage error."""
        await self.tracer.record_stage_error(trace_id, stage, error, execution_time)
    
    async def record_stage_timeout(self, trace_id: str, stage: str, execution_time: float) -> None:
        """Record stage timeout."""
        await self.tracer.record_stage_timeout(trace_id, stage, execution_time)
    
    async def record_decision(self, trace_id: str, decision: Decision, decision_point: DecisionPoint) -> None:
        """Record decision with full context."""
        await self.tracer.record_decision(trace_id, decision, decision_point)
    
    async def record_completion(self, trace_id: str, result: Dict[str, Any]) -> None:
        """Record successful completion."""
        await self.tracer.record_completion(trace_id, result)
    
    async def record_error(self, trace_id: str, error: Exception, context_data: Dict[str, Any]) -> None:
        """Record workflow error."""
        await self.tracer.record_error(trace_id, error, context_data)
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary across all traces."""
        summary = {}
        
        for stage, times in self.performance_data.items():
            if times:
                summary[stage] = {
                    'avg_time': sum(times) / len(times),
                    'min_time': min(times),
                    'max_time': max(times),
                    'total_executions': len(times)
                }
        
        return summary
    
    def get_observability_metrics(self) -> Dict[str, Any]:
        """Get comprehensive observability metrics."""
        return {
            'tracer_metrics': self.tracer.get_metrics(),
            'performance_summary': self.get_performance_summary(),
            'resource_usage': self.resource_usage
        }