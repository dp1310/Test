"""
Performance monitoring system with metrics collection and alerting.

This module provides comprehensive performance monitoring, metrics collection,
and intelligent alerting for the agentic framework.
"""

import time
import asyncio
import psutil
from typing import Dict, Any, List, Optional, Callable
from collections import deque, defaultdict
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class PerformanceAlert:
    """Performance alert data structure."""
    alert_type: str
    metric_name: str
    current_value: float
    threshold: float
    timestamp: float
    severity: str  # low, medium, high, critical
    message: str
    recommendations: List[str] = field(default_factory=list)


class PerformanceMonitor:
    """Comprehensive performance monitoring system."""
    
    def __init__(self, 
                 config: Dict[str, Any],
                 history_size: int = 1000,
                 sampling_interval: float = 1.0,
                 alert_thresholds: Dict[str, float] = None):
        self.config = config
        self.history_size = history_size
        self.sampling_interval = sampling_interval
        self.alert_thresholds = alert_thresholds or {}
        
        # Performance data
        self.metrics_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=history_size))
        self.stage_performance: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            'total_time': 0.0,
            'total_calls': 0,
            'avg_time': 0.0,
            'min_time': float('inf'),
            'max_time': 0.0,
            'success_count': 0,
            'error_count': 0
        })
        
        # Tool performance tracking
        self.tool_performance: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            'total_executions': 0,
            'successful_executions': 0,
            'failed_executions': 0,
            'total_execution_time': 0.0,
            'avg_execution_time': 0.0,
            'resource_usage': {'memory_mb': 0, 'cpu_percent': 0}
        })
        
        # Decision performance
        self.decision_performance: Dict[str, List[float]] = defaultdict(list)
        
        # System metrics
        self.system_metrics = {
            'cpu_usage': deque(maxlen=history_size),
            'memory_usage': deque(maxlen=history_size),
            'disk_usage': deque(maxlen=history_size),
            'network_io': deque(maxlen=history_size)
        }
        
        # Alerts
        self.active_alerts: List[PerformanceAlert] = []
        self.alert_callbacks: List[Callable] = []
        
        # Monitoring control
        self.monitoring_task: Optional[asyncio.Task] = None
        self.is_monitoring = False
        
        # Performance recommendations
        self.recommendations_engine = PerformanceRecommendationsEngine()
    
    async def start_monitoring(self) -> None:
        """Start performance monitoring."""
        if self.is_monitoring:
            return
        
        self.is_monitoring = True
        self.monitoring_task = asyncio.create_task(self._monitoring_loop())
    
    async def stop_monitoring(self) -> None:
        """Stop performance monitoring."""
        self.is_monitoring = False
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
    
    async def _monitoring_loop(self) -> None:
        """Main monitoring loop."""
        while self.is_monitoring:
            try:
                await self._collect_system_metrics()
                await self._check_alert_conditions()
                await asyncio.sleep(self.sampling_interval)
            except Exception as e:
                # Log error but continue monitoring
                print(f"Monitoring error: {e}")
                await asyncio.sleep(self.sampling_interval)
    
    async def _collect_system_metrics(self) -> None:
        """Collect system performance metrics."""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=None)
            self.system_metrics['cpu_usage'].append({
                'timestamp': time.time(),
                'value': cpu_percent
            })
            
            # Memory usage
            memory = psutil.virtual_memory()
            self.system_metrics['memory_usage'].append({
                'timestamp': time.time(),
                'value': memory.percent,
                'available_mb': memory.available / (1024 * 1024)
            })
            
            # Disk usage
            disk = psutil.disk_usage('/')
            self.system_metrics['disk_usage'].append({
                'timestamp': time.time(),
                'value': (disk.used / disk.total) * 100
            })
            
        except Exception as e:
            # Handle cases where psutil is not available
            pass
    
    def record_stage_time(self, stage: str, execution_time: float, success: bool = True) -> None:
        """Record stage execution time."""
        stage_data = self.stage_performance[stage]
        
        stage_data['total_calls'] += 1
        stage_data['total_time'] += execution_time
        stage_data['avg_time'] = stage_data['total_time'] / stage_data['total_calls']
        
        if execution_time < stage_data['min_time']:
            stage_data['min_time'] = execution_time
        if execution_time > stage_data['max_time']:
            stage_data['max_time'] = execution_time
        
        if success:
            stage_data['success_count'] += 1
        else:
            stage_data['error_count'] += 1
        
        # Add to metrics history
        self.metrics_history[f'{stage}_execution_time'].append({
            'timestamp': time.time(),
            'value': execution_time,
            'success': success
        })
    
    def record_tool_performance(self, tool_name: str, execution_time: float, success: bool = True, resource_usage: Dict[str, Any] = None) -> None:
        """Record tool performance metrics."""
        tool_data = self.tool_performance[tool_name]
        
        tool_data['total_executions'] += 1
        tool_data['total_execution_time'] += execution_time
        tool_data['avg_execution_time'] = tool_data['total_execution_time'] / tool_data['total_executions']
        
        if success:
            tool_data['successful_executions'] += 1
        else:
            tool_data['failed_executions'] += 1
        
        if resource_usage:
            tool_data['resource_usage'].update(resource_usage)
        
        # Add to metrics history
        self.metrics_history[f'{tool_name}_execution_time'].append({
            'timestamp': time.time(),
            'value': execution_time,
            'success': success
        })
    
    def record_decision_metrics(self, decision_point_id: str, confidence: float, decision_time: float) -> None:
        """Record decision-making performance."""
        self.decision_performance[decision_point_id].append({
            'confidence': confidence,
            'decision_time': decision_time,
            'timestamp': time.time()
        })
        
        # Keep only recent decisions
        if len(self.decision_performance[decision_point_id]) > 100:
            self.decision_performance[decision_point_id] = self.decision_performance[decision_point_id][-100:]
    
    async def start_operation_monitoring(self, operation_name: str) -> None:
        """Start monitoring a specific operation."""
        self.metrics_history[f'{operation_name}_start'].append({
            'timestamp': time.time(),
            'operation': operation_name
        })
    
    async def stop_operation_monitoring(self, operation_name: str, metrics: Dict[str, Any]) -> None:
        """Stop monitoring a specific operation."""
        self.metrics_history[f'{operation_name}_complete'].append({
            'timestamp': time.time(),
            'operation': operation_name,
            'metrics': metrics
        })
    
    async def _check_alert_conditions(self) -> None:
        """Check for alert conditions and trigger alerts."""
        current_time = time.time()
        
        # Check system metrics
        if self.system_metrics['cpu_usage']:
            latest_cpu = self.system_metrics['cpu_usage'][-1]['value']
            if latest_cpu > self.alert_thresholds.get('cpu_usage', 80):
                await self._trigger_alert(
                    'high_cpu_usage',
                    'cpu_usage',
                    latest_cpu,
                    self.alert_thresholds.get('cpu_usage', 80),
                    'high',
                    f"High CPU usage detected: {latest_cpu:.1f}%",
                    ["Consider reducing concurrent operations", "Check for CPU-intensive tasks"]
                )
        
        if self.system_metrics['memory_usage']:
            latest_memory = self.system_metrics['memory_usage'][-1]['value']
            if latest_memory > self.alert_thresholds.get('memory_usage', 80):
                await self._trigger_alert(
                    'high_memory_usage',
                    'memory_usage',
                    latest_memory,
                    self.alert_thresholds.get('memory_usage', 80),
                    'high',
                    f"High memory usage detected: {latest_memory:.1f}%",
                    ["Trigger garbage collection", "Clear caches", "Reduce batch sizes"]
                )
        
        # Check stage performance
        for stage, data in self.stage_performance.items():
            if data['total_calls'] > 0:
                error_rate = data['error_count'] / data['total_calls']
                if error_rate > self.alert_thresholds.get('error_rate', 0.1):
                    await self._trigger_alert(
                        'high_error_rate',
                        f'{stage}_error_rate',
                        error_rate,
                        self.alert_thresholds.get('error_rate', 0.1),
                        'medium',
                        f"High error rate in {stage}: {error_rate:.1%}",
                        [f"Review {stage} implementation", "Check input validation", "Add error handling"]
                    )
    
    async def _trigger_alert(self, alert_type: str, metric_name: str, current_value: float, 
                           threshold: float, severity: str, message: str, recommendations: List[str]) -> None:
        """Trigger a performance alert."""
        
        # Check if we already have an active alert of this type
        existing_alert = next((alert for alert in self.active_alerts 
                             if alert.alert_type == alert_type and alert.metric_name == metric_name), None)
        
        if existing_alert:
            # Update existing alert
            existing_alert.current_value = current_value
            existing_alert.timestamp = time.time()
        else:
            # Create new alert
            alert = PerformanceAlert(
                alert_type=alert_type,
                metric_name=metric_name,
                current_value=current_value,
                threshold=threshold,
                timestamp=time.time(),
                severity=severity,
                message=message,
                recommendations=recommendations
            )
            
            self.active_alerts.append(alert)
            
            # Notify alert callbacks
            for callback in self.alert_callbacks:
                try:
                    await callback(alert)
                except Exception as e:
                    print(f"Alert callback error: {e}")
    
    def add_alert_callback(self, callback: Callable) -> None:
        """Add callback for performance alerts."""
        self.alert_callbacks.append(callback)
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get comprehensive performance summary."""
        return {
            'stage_performance': dict(self.stage_performance),
            'tool_performance': dict(self.tool_performance),
            'system_metrics': {
                'current_cpu': self.system_metrics['cpu_usage'][-1]['value'] if self.system_metrics['cpu_usage'] else 0,
                'current_memory': self.system_metrics['memory_usage'][-1]['value'] if self.system_metrics['memory_usage'] else 0,
                'available_memory_mb': self.system_metrics['memory_usage'][-1].get('available_mb', 0) if self.system_metrics['memory_usage'] else 0
            },
            'active_alerts': len(self.active_alerts),
            'total_metrics_collected': sum(len(history) for history in self.metrics_history.values())
        }
    
    def get_recommendations(self) -> List[str]:
        """Get performance optimization recommendations."""
        return self.recommendations_engine.generate_recommendations(
            self.stage_performance,
            self.tool_performance,
            self.active_alerts
        )
    
    def clear_alerts(self) -> None:
        """Clear all active alerts."""
        self.active_alerts.clear()


class PerformanceRecommendationsEngine:
    """Engine for generating performance optimization recommendations."""
    
    def generate_recommendations(self, 
                               stage_performance: Dict[str, Dict[str, Any]],
                               tool_performance: Dict[str, Dict[str, Any]],
                               active_alerts: List[PerformanceAlert]) -> List[str]:
        """Generate performance recommendations based on collected data."""
        recommendations = []
        
        # Analyze stage performance
        for stage, data in stage_performance.items():
            if data['total_calls'] > 10:  # Only analyze stages with sufficient data
                error_rate = data['error_count'] / data['total_calls']
                avg_time = data['avg_time']
                
                if error_rate > 0.1:
                    recommendations.append(f"High error rate in {stage} ({error_rate:.1%}) - review error handling")
                
                if avg_time > 5.0:
                    recommendations.append(f"Slow {stage} stage ({avg_time:.1f}s avg) - consider optimization")
        
        # Analyze tool performance
        for tool, data in tool_performance.items():
            if data['total_executions'] > 5:
                success_rate = data['successful_executions'] / data['total_executions']
                avg_time = data['avg_execution_time']
                
                if success_rate < 0.9:
                    recommendations.append(f"Low success rate for {tool} ({success_rate:.1%}) - check tool implementation")
                
                if avg_time > 2.0:
                    recommendations.append(f"Slow {tool} execution ({avg_time:.1f}s avg) - consider caching or optimization")
        
        # Analyze alerts
        for alert in active_alerts:
            if alert.severity in ['high', 'critical']:
                recommendations.extend(alert.recommendations)
        
        return list(set(recommendations))  # Remove duplicates