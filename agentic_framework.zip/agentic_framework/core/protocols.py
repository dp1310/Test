"""
Core protocol definitions and interfaces for the agentic framework.

This module defines the fundamental protocols, interfaces, and data structures
that all framework components must implement to ensure proper integration,
type safety, and functionality. It provides the contract layer that enables
loose coupling while maintaining strong type guarantees.

Key Features:
    - Protocol-based interfaces for maximum flexibility and testability
    - Comprehensive metadata structures for tool and component configuration
    - Execution mode definitions for concurrency and resource management
    - Type-safe interfaces with full generic support
    - Extensible design patterns for custom implementations
    - Comprehensive logging and monitoring integration
    - Resource management and timeout specifications

Protocol Architecture:
    The framework uses Python's Protocol system to define interfaces that
    components must implement. This provides:
    - Duck typing with static type checking
    - Flexible implementation without inheritance constraints
    - Clear contracts for component integration
    - Easy testing with mock implementations
    - Runtime validation capabilities

Core Protocols:
    - ToolProtocol: Interface for all executable tools
    - LLMProvider: Interface for language model providers
    - EventHandler: Interface for event processing components
    - DecisionEngine: Interface for decision-making components

Metadata Structures:
    - ToolMetadata: Comprehensive tool configuration and requirements
    - ExecutionMode: Concurrency and execution strategy definitions
    - ResourceRequirements: Memory, CPU, and timeout specifications

Example:
    Implementing a custom tool:
        >>> class CustomTool:
        ...     def __init__(self):
        ...         self.metadata = ToolMetadata(
        ...             purpose="Custom processing",
        ...             input_schema={"data": {"type": "string"}},
        ...             output_schema={"type": "object"},
        ...             execution_mode=ToolExecutionMode.SEQUENTIAL
        ...         )
        ...     
        ...     async def execute(self, data: str) -> Dict[str, Any]:
        ...         return {"processed": data.upper()}
    
    Using protocols for type checking:
        >>> def register_tool(tool: ToolProtocol) -> None:
        ...     # Type checker ensures tool implements required methods
        ...     pass

Author: Agentic Framework Team
Version: 2.0.0
"""

from typing import Protocol, Dict, Any, List, Optional, Callable, AsyncIterator, Union
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
import time
import logging

# Initialize module logger
logger = logging.getLogger(__name__)


class ToolExecutionMode(Enum):
    """
    Enumeration of tool execution modes for concurrency and resource management.
    
    This enum defines the different execution strategies available for tools
    within the agentic framework. Each mode has specific implications for
    resource usage, performance, and concurrency behavior.
    
    Execution Modes:
        SEQUENTIAL: Tools execute one after another in strict order.
            - Lowest resource usage
            - Predictable execution order
            - No concurrency conflicts
            - Best for resource-constrained environments
        
        PARALLEL: Tools execute concurrently when possible.
            - Higher throughput for independent operations
            - Requires careful resource management
            - May have race conditions if not properly designed
            - Best for I/O-bound operations
        
        BATCH: Tools process multiple inputs in batches.
            - Optimized for bulk operations
            - Better resource utilization for similar operations
            - Reduced overhead for repeated operations
            - Best for data processing pipelines
    
    Usage:
        >>> metadata = ToolMetadata(
        ...     purpose="Data processor",
        ...     execution_mode=ToolExecutionMode.PARALLEL
        ... )
        >>> 
        >>> # Check execution mode
        >>> if metadata.execution_mode == ToolExecutionMode.SEQUENTIAL:
        ...     # Handle sequential execution
        ...     pass
    
    Note:
        The execution mode is a hint to the framework's execution engine.
        The actual execution behavior may be influenced by system resources,
        configuration settings, and runtime constraints.
    """
    
    SEQUENTIAL = "sequential"  # Execute tools one after another
    PARALLEL = "parallel"      # Execute tools concurrently when possible
    BATCH = "batch"           # Execute tools in batches for efficiency
    
    def __str__(self) -> str:
        """Return human-readable string representation."""
        return self.value
    
    @classmethod
    def from_string(cls, mode_str: str) -> 'ToolExecutionMode':
        """
        Create ToolExecutionMode from string with validation.
        
        Args:
            mode_str (str): String representation of execution mode.
        
        Returns:
            ToolExecutionMode: Corresponding enum value.
        
        Raises:
            ValueError: If mode_str is not a valid execution mode.
        """
        try:
            return cls(mode_str.lower())
        except ValueError:
            valid_modes = [mode.value for mode in cls]
            raise ValueError(f"Invalid execution mode '{mode_str}'. Valid modes: {valid_modes}")


@dataclass
class ToolMetadata:
    """
    Comprehensive metadata structure for tool configuration and requirements.
    
    This dataclass provides a complete specification for tool capabilities,
    requirements, and behavior within the agentic framework. It enables
    the framework to make intelligent decisions about tool execution,
    resource allocation, and error handling.
    
    The metadata serves multiple purposes:
    - Tool discovery and registration
    - Resource planning and allocation
    - Execution strategy determination
    - Input/output validation
    - Performance monitoring and optimization
    - Error handling and retry logic
    
    Attributes:
        purpose (str): Human-readable description of what the tool does.
        input_schema (Dict[str, Any]): JSON Schema defining expected inputs.
        output_schema (Dict[str, Any]): JSON Schema defining expected outputs.
        execution_mode (ToolExecutionMode): How the tool should be executed.
        resource_requirements (Dict[str, Any]): Resource needs (memory, CPU, etc.).
        timeout (int): Maximum execution time in seconds.
        retry_config (Dict[str, Any]): Retry strategy configuration.
        tags (List[str]): Categorization tags for tool discovery.
        version (str): Tool version for compatibility checking.
        dependencies (List[str]): Required dependencies or other tools.
        
    Example:
        >>> metadata = ToolMetadata(
        ...     purpose="Calculate mathematical expressions",
        ...     input_schema={
        ...         "expression": {"type": "string", "pattern": r"^[0-9+\-*/\s()]+$"}
        ...     },
        ...     output_schema={"type": "number"},
        ...     execution_mode=ToolExecutionMode.SEQUENTIAL,
        ...     resource_requirements={"memory_mb": 10, "cpu_cores": 0.1},
        ...     timeout=30,
        ...     retry_config={"max_attempts": 3, "backoff_factor": 2.0},
        ...     tags=["math", "calculator", "arithmetic"]
        ... )
    
    Validation:
        The metadata is validated during tool registration to ensure:
        - Required fields are present and valid
        - Schemas are well-formed JSON Schema documents
        - Resource requirements are reasonable
        - Timeout values are positive
        - Dependencies can be resolved
    """
    
    # Core identification and description
    purpose: str
    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    execution_mode: ToolExecutionMode
    
    # Resource and performance configuration
    resource_requirements: Dict[str, Any] = field(default_factory=dict)
    timeout: int = 30
    retry_config: Dict[str, Any] = field(default_factory=dict)
    
    # Metadata and categorization
    tags: List[str] = field(default_factory=list)
    version: str = "1.0.0"
    dependencies: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """
        Post-initialization validation and logging.
        
        Validates the metadata configuration and logs the tool registration
        for debugging and monitoring purposes.
        
        Raises:
            ValueError: If required fields are missing or invalid.
        """
        logger.debug(f"Initializing ToolMetadata for purpose: {self.purpose}")
        
        # Validate required fields
        if not self.purpose or not isinstance(self.purpose, str):
            raise ValueError("Tool purpose must be a non-empty string")
        
        if not isinstance(self.input_schema, dict):
            raise ValueError("Input schema must be a dictionary")
        
        if not isinstance(self.output_schema, dict):
            raise ValueError("Output schema must be a dictionary")
        
        if self.timeout <= 0:
            raise ValueError("Timeout must be positive")
        
        # Set default resource requirements if not specified
        if not self.resource_requirements:
            self.resource_requirements = {
                "memory_mb": 50,      # Default 50MB memory
                "cpu_cores": 0.1,     # Default 10% CPU
                "disk_mb": 10         # Default 10MB disk
            }
            logger.debug("Applied default resource requirements")
        
        # Set default retry configuration if not specified
        if not self.retry_config:
            self.retry_config = {
                "max_attempts": 3,
                "backoff_factor": 1.5,
                "retry_exceptions": ["TimeoutError", "ConnectionError"]
            }
            logger.debug("Applied default retry configuration")
        
        logger.debug(f"ToolMetadata initialized: mode={self.execution_mode}, timeout={self.timeout}s")
    
    def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """
        Validate input data against the input schema.
        
        Args:
            input_data (Dict[str, Any]): Input data to validate.
        
        Returns:
            bool: True if input is valid, False otherwise.
        
        Note:
            This is a basic validation. For production use, consider
            using a full JSON Schema validator like jsonschema library.
        """
        logger.debug(f"Validating input data for tool: {self.purpose}")
        
        # Basic validation - check required fields exist
        # In production, use proper JSON Schema validation
        try:
            # This is a simplified validation
            # Real implementation should use jsonschema library
            return True
        except Exception as e:
            logger.warning(f"Input validation failed: {e}")
            return False
    
    def get_resource_estimate(self) -> Dict[str, float]:
        """
        Get estimated resource usage for planning purposes.
        
        Returns:
            Dict[str, float]: Resource estimates including memory, CPU, and disk.
        """
        return {
            "memory_mb": self.resource_requirements.get("memory_mb", 50),
            "cpu_cores": self.resource_requirements.get("cpu_cores", 0.1),
            "disk_mb": self.resource_requirements.get("disk_mb", 10),
            "network_mbps": self.resource_requirements.get("network_mbps", 0)
        }


class ToolProtocol(Protocol):
    """
    Protocol defining the interface for all executable tools in the framework.
    
    This protocol establishes the contract that all tools must implement to
    integrate with the agentic framework. It ensures consistent behavior,
    proper error handling, and comprehensive monitoring across all tools.
    
    The protocol supports:
    - Asynchronous execution for non-blocking operations
    - Conditional execution based on context
    - Comprehensive error handling and recovery
    - Success callbacks for monitoring and chaining
    - Metadata-driven configuration and validation
    
    Required Attributes:
        metadata (ToolMetadata): Complete tool configuration and requirements.
    
    Required Methods:
        execute: Main tool execution logic
        should_skip: Conditional execution predicate
        on_failure: Error handling and recovery
        on_success: Success callback for monitoring
    
    Example Implementation:
        >>> class ExampleTool:
        ...     def __init__(self):
        ...         self.metadata = ToolMetadata(
        ...             purpose="Example tool",
        ...             input_schema={"data": {"type": "string"}},
        ...             output_schema={"type": "string"},
        ...             execution_mode=ToolExecutionMode.SEQUENTIAL
        ...         )
        ...     
        ...     async def execute(self, data: str) -> str:
        ...         return f"Processed: {data}"
        ...     
        ...     def should_skip(self, context: AgentContext) -> bool:
        ...         return False  # Always execute
        ...     
        ...     def on_failure(self, error: Exception, context: AgentContext) -> Any:
        ...         return {"error": str(error), "status": "failed"}
        ...     
        ...     async def on_success(self, result: Any, context: AgentContext) -> None:
        ...         logger.info(f"Tool succeeded with result: {result}")
    
    Type Safety:
        This protocol enables static type checking while maintaining flexibility.
        Tools can be implemented as classes, functions, or any callable that
        satisfies the protocol interface.
    """
    
    metadata: ToolMetadata
    
    async def execute(self, *args, **kwargs) -> Any:
        """
        Execute the tool with given parameters and return the result.
        
        This is the main entry point for tool execution. It should contain
        the core logic of the tool and handle all necessary processing.
        The method is async to support non-blocking operations.
        
        Args:
            *args: Positional arguments for tool execution.
            **kwargs: Keyword arguments for tool execution.
        
        Returns:
            Any: Tool execution result. Type should match output_schema.
        
        Raises:
            Exception: Any exception during execution will be caught by
                the framework and passed to on_failure method.
        
        Note:
            The execute method should be idempotent when possible and
            should validate inputs according to the metadata schema.
        """
        ...
    
    def should_skip(self, context: 'AgentContext') -> bool:
        """
        Determine whether tool execution should be skipped based on context.
        
        This predicate function allows tools to implement conditional execution
        logic based on the current agent context, constraints, or system state.
        It enables intelligent tool selection and resource optimization.
        
        Args:
            context (AgentContext): Current execution context with state and constraints.
        
        Returns:
            bool: True if tool execution should be skipped, False otherwise.
        
        Example:
            >>> def should_skip(self, context: AgentContext) -> bool:
            ...     # Skip if insufficient memory
            ...     memory_limit = context.constraints.get('memory_limit', 1000)
            ...     required_memory = self.metadata.resource_requirements.get('memory_mb', 0)
            ...     return required_memory > memory_limit
        
        Note:
            This method should be fast and side-effect free as it may be
            called multiple times during execution planning.
        """
        ...
    
    def on_failure(self, error: Exception, context: 'AgentContext') -> Any:
        """
        Handle tool execution failure and provide fallback result.
        
        This method is called when tool execution fails, allowing the tool
        to provide graceful degradation, error recovery, or meaningful
        fallback values. It enables resilient pipeline execution.
        
        Args:
            error (Exception): The exception that caused the failure.
            context (AgentContext): Current execution context for error handling.
        
        Returns:
            Any: Fallback result or error information. Should be meaningful
                for downstream processing or debugging.
        
        Example:
            >>> def on_failure(self, error: Exception, context: AgentContext) -> Any:
            ...     logger.error(f"Tool failed: {error}")
            ...     return {
            ...         "error": str(error),
            ...         "error_type": type(error).__name__,
            ...         "status": "failed",
            ...         "fallback_value": None
            ...     }
        
        Note:
            This method should not raise exceptions as it's part of the
            error handling mechanism. Log errors appropriately.
        """
        ...
    
    async def on_success(self, result: Any, context: 'AgentContext') -> None:
        """
        Handle successful tool execution for monitoring and chaining.
        
        This callback is invoked after successful tool execution, allowing
        for result logging, metrics collection, event emission, or triggering
        of downstream processes. It's essential for observability.
        
        Args:
            result (Any): The successful execution result.
            context (AgentContext): Current execution context for callback processing.
        
        Returns:
            None: This method should not return a value.
        
        Example:
            >>> async def on_success(self, result: Any, context: AgentContext) -> None:
            ...     # Log success
            ...     logger.info(f"Tool executed successfully: {result}")
            ...     
            ...     # Emit event for monitoring
            ...     if context.event_system:
            ...         await context.event_system.emit_event(Event(
            ...             type='tool_success',
            ...             source=self.__class__.__name__,
            ...             data={'result': result}
            ...         ))
        
        Note:
            This method should be fast and should not perform heavy operations
            that could slow down the pipeline execution.
        """
        ...


class LLMProvider(Protocol):
    """
    Protocol for Large Language Model providers in the agentic framework.
    
    This protocol defines the interface for integrating various LLM providers
    (OpenAI, Anthropic, local models, etc.) into the framework. It ensures
    consistent behavior and enables provider switching without code changes.
    
    The protocol supports:
    - Asynchronous completion for non-blocking operations
    - Structured response format for consistent processing
    - Provider availability checking for fallback scenarios
    - Extensible parameter passing for provider-specific options
    - Error handling and timeout management
    
    Example Implementation:
        >>> class OpenAIProvider:
        ...     async def complete(self, prompt: str, **kwargs) -> Dict[str, Any]:
        ...         # Call OpenAI API
        ...         response = await openai_client.complete(prompt, **kwargs)
        ...         return {
        ...             "text": response.text,
        ...             "tokens_used": response.usage.total_tokens,
        ...             "model": response.model,
        ...             "finish_reason": response.finish_reason
        ...         }
        ...     
        ...     def is_available(self) -> bool:
        ...         return self.api_key is not None and self.client.is_healthy()
    
    Response Format:
        The complete method should return a dictionary with:
        - text (str): The generated completion text
        - tokens_used (int): Number of tokens consumed
        - model (str): Model identifier used for completion
        - finish_reason (str): Reason completion ended (length, stop, etc.)
        - metadata (Dict): Additional provider-specific information
    """
    
    async def complete(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Generate completion for the given prompt with provider-specific options.
        
        This method sends a prompt to the LLM provider and returns a structured
        response containing the completion text and metadata. It should handle
        provider-specific authentication, rate limiting, and error conditions.
        
        Args:
            prompt (str): The input prompt for completion generation.
            **kwargs: Provider-specific parameters such as:
                - max_tokens (int): Maximum tokens to generate
                - temperature (float): Sampling temperature (0.0-1.0)
                - top_p (float): Nucleus sampling parameter
                - stop (List[str]): Stop sequences
                - model (str): Specific model to use
        
        Returns:
            Dict[str, Any]: Structured response containing:
                - text (str): Generated completion text
                - tokens_used (int): Total tokens consumed
                - model (str): Model identifier used
                - finish_reason (str): Completion termination reason
                - metadata (Dict): Additional provider information
        
        Raises:
            Exception: Provider-specific exceptions for API errors, rate limits,
                authentication failures, or network issues.
        
        Example:
            >>> provider = OpenAIProvider()
            >>> result = await provider.complete(
            ...     "Explain quantum computing",
            ...     max_tokens=100,
            ...     temperature=0.7
            ... )
            >>> print(result["text"])
        """
        ...
    
    def is_available(self) -> bool:
        """
        Check if the LLM provider is currently available for use.
        
        This method performs a quick health check to determine if the provider
        can handle requests. It should check authentication, network connectivity,
        and service status without making expensive API calls.
        
        Returns:
            bool: True if provider is available and ready, False otherwise.
        
        Example:
            >>> provider = OpenAIProvider()
            >>> if provider.is_available():
            ...     result = await provider.complete("Hello world")
            ... else:
            ...     # Use fallback provider or deterministic response
            ...     result = {"text": "Provider unavailable", "tokens_used": 0}
        
        Note:
            This method should be fast and lightweight as it may be called
            frequently for provider selection and health monitoring.
        """
        ...


class EventHandler(Protocol):
    """
    Protocol for event handlers in the reactive event system.
    
    This protocol defines the interface for components that process events
    within the framework's event-driven architecture. It enables loose
    coupling between event producers and consumers while maintaining
    type safety and consistent behavior.
    
    The protocol supports:
    - Selective event handling based on event properties
    - Asynchronous processing for non-blocking event handling
    - Type-safe event processing with structured data
    - Error handling and recovery mechanisms
    - Performance monitoring and metrics collection
    
    Example Implementation:
        >>> class LoggingHandler:
        ...     def should_handle(self, event: Event) -> bool:
        ...         return event.type.startswith('log_')
        ...     
        ...     async def handle(self, event: Event) -> Any:
        ...         logger.info(f"Event: {event.type} - {event.data}")
        ...         return {"logged": True, "timestamp": time.time()}
    
    Event Processing:
        Handlers are called in priority order and can:
        - Filter events based on type, source, or data content
        - Transform event data before processing
        - Emit new events as part of processing
        - Update system state or external services
        - Collect metrics and performance data
    """
    
    def should_handle(self, event: 'Event') -> bool:
        """
        Determine if this handler should process the given event.
        
        This predicate function allows handlers to selectively process events
        based on event type, source, data content, or any other criteria.
        It enables efficient event routing and processing.
        
        Args:
            event (Event): The event to evaluate for handling.
        
        Returns:
            bool: True if this handler should process the event, False otherwise.
        
        Example:
            >>> def should_handle(self, event: Event) -> bool:
            ...     # Handle only error events from specific sources
            ...     return (event.type == 'error' and 
            ...             event.source in ['pipeline', 'tool_executor'])
        
        Note:
            This method should be fast and side-effect free as it's called
            for every event to determine handler eligibility.
        """
        ...
    
    async def handle(self, event: 'Event') -> Any:
        """
        Process the event and return any result or status information.
        
        This method contains the main event processing logic. It should
        handle the event appropriately based on its type and data, and
        may perform side effects like logging, state updates, or API calls.
        
        Args:
            event (Event): The event to process.
        
        Returns:
            Any: Processing result, status information, or None.
                The return value may be used for monitoring or chaining.
        
        Raises:
            Exception: Any exception during processing. The event system
                will handle exceptions appropriately based on configuration.
        
        Example:
            >>> async def handle(self, event: Event) -> Any:
            ...     if event.type == 'user_action':
            ...         # Process user action
            ...         result = await self.process_user_action(event.data)
            ...         return {"processed": True, "result": result}
            ...     return None
        
        Note:
            This method should be idempotent when possible and should
            handle errors gracefully to avoid disrupting event processing.
        """
        ...


class DecisionEngine(Protocol):
    """
    Protocol for decision-making engines in the agentic framework.
    
    This protocol defines the interface for components that make strategic
    decisions during pipeline execution. Decision engines analyze context,
    evaluate options, and provide recommendations for action selection.
    
    The protocol supports:
    - Context-aware decision making
    - Multiple decision strategies and algorithms
    - Confidence scoring and uncertainty handling
    - Decision audit trails and explainability
    - Performance monitoring and optimization
    
    Example Implementation:
        >>> class RuleBasedDecisionEngine:
        ...     async def make_decision(self, context: AgentContext, options: List[Dict]) -> Dict[str, Any]:
        ...         # Evaluate options using rules
        ...         best_option = max(options, key=lambda opt: self.score_option(opt, context))
        ...         return {
        ...             "choice": best_option,
        ...             "confidence": 0.85,
        ...             "reasoning": "Selected based on resource efficiency"
        ...         }
        ...     
        ...     def get_decision_history(self) -> List[Dict[str, Any]]:
        ...         return self.decision_log
    """
    
    async def make_decision(self, context: 'AgentContext', options: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Make a decision based on context and available options.
        
        This method analyzes the current context and evaluates available options
        to make an informed decision. It should return the chosen option along
        with confidence scores and reasoning for audit and debugging purposes.
        
        Args:
            context (AgentContext): Current execution context with state and constraints.
            options (List[Dict[str, Any]]): Available options to choose from.
        
        Returns:
            Dict[str, Any]: Decision result containing:
                - choice (Dict): The selected option
                - confidence (float): Confidence score (0.0-1.0)
                - reasoning (str): Human-readable explanation
                - alternatives (List): Other considered options
                - metadata (Dict): Additional decision information
        
        Example:
            >>> engine = RuleBasedDecisionEngine()
            >>> options = [
            ...     {"action": "retry", "cost": 0.1, "success_rate": 0.8},
            ...     {"action": "fallback", "cost": 0.05, "success_rate": 0.9}
            ... ]
            >>> decision = await engine.make_decision(context, options)
            >>> print(f"Chose: {decision['choice']['action']}")
        """
        ...
    
    def get_decision_history(self) -> List[Dict[str, Any]]:
        """
        Get the history of decisions made by this engine.
        
        Returns:
            List[Dict[str, Any]]: Chronological list of decisions with
                timestamps, contexts, and outcomes for analysis.
        """
        ...