"""
Immutable context management using functional programming principles.

This module provides comprehensive thread-safe context management for the agentic
framework using Python's contextvars with immutable data structures and functional
programming patterns. It ensures state consistency across concurrent executions
while maintaining full traceability and rollback capabilities.

Key Features:
    - Immutable context objects using dataclasses with frozen=True
    - Thread-safe context management with Python's contextvars
    - Functional programming patterns for state transformations
    - Comprehensive context evolution tracking and history
    - Rollback capabilities for error recovery scenarios
    - JSON serialization/deserialization for persistence
    - Performance metrics tracking and decision logging
    - Event system integration for real-time monitoring

Architecture:
    The context system follows functional programming principles where each
    state change creates a new immutable context object. This ensures:
    - No accidental state mutations
    - Full audit trail of context changes
    - Safe concurrent access across threads
    - Reliable rollback and recovery mechanisms

Context Evolution:
    Each context transformation creates a new immutable instance while
    preserving the complete history. This enables:
    - Time-travel debugging capabilities
    - Rollback to any previous state
    - Performance analysis across execution stages
    - Decision audit trails for compliance

Example:
    Basic usage:
        >>> context = AgentContext(input_data="Process this")
        >>> updated_context = context.with_stage_result("perceive", {"data": "parsed"})
        >>> manager = ContextManager()
        >>> manager.set_context(updated_context)
    
    Functional transformations:
        >>> # Chain multiple transformations
        >>> final_context = (context
        ...     .with_stage_result("perceive", perception_data)
        ...     .with_decision({"action": "analyze"})
        ...     .with_performance_metric("stage_time", 1.5))

Author: Agentic Framework Team
Version: 2.0.0
"""

from contextvars import ContextVar
from typing import Dict, Any, Optional, List, Callable, Union
from dataclasses import dataclass, field, replace
from datetime import datetime
import json
import uuid
import logging
import copy

# Initialize module logger
logger = logging.getLogger(__name__)

# Context variables for thread-safe state management
# This enables safe concurrent access across multiple threads/tasks
current_context: ContextVar['AgentContext'] = ContextVar('current_context')


@dataclass(frozen=True)
class AgentContext:
    """
    Immutable agent context using functional programming principles.
    
    This class represents the complete execution state of an agentic pipeline
    at any point in time. It uses immutable data structures to ensure thread
    safety and enable reliable rollback mechanisms. All state changes create
    new context instances, preserving the complete execution history.
    
    The context follows functional programming principles where transformations
    are pure functions that return new instances rather than modifying existing
    state. This design ensures consistency, traceability, and safe concurrent access.
    
    Attributes:
        input_data (str): The original input data for processing.
        stage_results (Dict[str, Any]): Results from each completed pipeline stage.
        decisions (List[Dict[str, Any]]): Chronological list of decisions made.
        trace_id (str): Unique identifier for this execution trace.
        agent_id (str): Identifier of the agent executing this context.
        timeout (int): Maximum execution time in seconds.
        constraints (Dict[str, Any]): Execution constraints and limitations.
        configuration (Dict[str, Any]): Runtime configuration parameters.
        performance_metrics (Dict[str, Any]): Performance tracking data.
        event_system (Optional[EventSystem]): Reference to event system (not serialized).
        metadata (Dict[str, Any]): Additional metadata for context enrichment.
    
    Immutability:
        All fields are immutable after creation. Use the with_* methods to create
        new instances with updated values. This ensures thread safety and enables
        reliable rollback capabilities.
    
    Example:
        >>> # Create initial context
        >>> context = AgentContext(
        ...     input_data="Calculate 2+2",
        ...     agent_id="math_processor",
        ...     timeout=60
        ... )
        >>> 
        >>> # Add stage result (creates new instance)
        >>> updated_context = context.with_stage_result("perceive", {
        ...     "parsed_expression": "2+2",
        ...     "operation": "addition"
        ... })
        >>> 
        >>> # Chain multiple transformations
        >>> final_context = (updated_context
        ...     .with_decision({"strategy": "direct_calculation"})
        ...     .with_performance_metric("parse_time", 0.1))
    """
    
    # Core execution data
    input_data: str
    stage_results: Dict[str, Any] = field(default_factory=dict)
    decisions: List[Dict[str, Any]] = field(default_factory=list)
    
    # Execution metadata and identification
    trace_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str = "default_agent"
    timeout: int = 30
    
    # Execution constraints and configuration
    constraints: Dict[str, Any] = field(default_factory=dict)
    configuration: Dict[str, Any] = field(default_factory=dict)
    
    # Performance and monitoring data
    performance_metrics: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # System references (excluded from serialization and comparison)
    event_system: Optional['EventSystem'] = field(default=None, compare=False)
    
    def __post_init__(self):
        """
        Post-initialization logging and validation.
        
        This method is called after the dataclass is initialized to perform
        logging and basic validation of the context state.
        """
        logger.debug(f"Created AgentContext with trace_id: {self.trace_id}")
        logger.debug(f"Agent ID: {self.agent_id}, Timeout: {self.timeout}s")
        
        # Validate critical fields
        if not self.input_data:
            logger.warning("AgentContext created with empty input_data")
        
        if self.timeout <= 0:
            logger.warning(f"AgentContext created with invalid timeout: {self.timeout}")
        
        logger.debug(f"Context initialized with {len(self.stage_results)} stage results")
    
    def with_stage_result(self, stage: str, result: Any) -> 'AgentContext':
        """
        Create new context with stage result using immutable update pattern.
        
        This method creates a new AgentContext instance with the specified stage
        result added to the stage_results dictionary. The original context
        remains unchanged, following functional programming principles.
        
        Args:
            stage (str): Name of the pipeline stage (e.g., 'perceive', 'plan', 'reason').
            result (Any): Result data from the stage execution. Can be any serializable type.
        
        Returns:
            AgentContext: New immutable context instance with the stage result added.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> updated = context.with_stage_result("perceive", {
            ...     "parsed_data": {"type": "text", "content": "test"},
            ...     "confidence": 0.95
            ... })
            >>> print(len(updated.stage_results))  # 1
            >>> print(len(context.stage_results))   # 0 (original unchanged)
        
        Note:
            If the stage already exists in stage_results, its value will be replaced
            in the new context instance.
        """
        logger.debug(f"Adding stage result for '{stage}' to context {self.trace_id}")
        
        # Create new stage_results dictionary with the added result
        new_stage_results = {**self.stage_results, stage: result}
        
        # Log the update for debugging
        result_size = len(str(result)) if result is not None else 0
        logger.debug(f"Stage '{stage}' result size: {result_size} characters")
        
        # Create and return new immutable context
        new_context = replace(self, stage_results=new_stage_results)
        logger.debug(f"Context now has {len(new_context.stage_results)} stage results")
        
        return new_context
    
    def with_decision(self, decision: Dict[str, Any]) -> 'AgentContext':
        """
        Create new context with decision appended using immutable update pattern.
        
        This method creates a new AgentContext instance with the specified decision
        appended to the decisions list. Decisions are stored chronologically to
        maintain a complete audit trail of the decision-making process.
        
        Args:
            decision (Dict[str, Any]): Decision data containing decision details.
                Should include keys like 'type', 'rationale', 'timestamp', etc.
        
        Returns:
            AgentContext: New immutable context instance with the decision appended.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> decision = {
            ...     "type": "strategy_selection",
            ...     "choice": "direct_approach",
            ...     "rationale": "Most efficient for simple tasks",
            ...     "confidence": 0.9,
            ...     "timestamp": datetime.now().isoformat()
            ... }
            >>> updated = context.with_decision(decision)
            >>> print(len(updated.decisions))  # 1
        
        Note:
            Decisions are appended to maintain chronological order. Each decision
            should include a timestamp for proper audit trail maintenance.
        """
        logger.debug(f"Adding decision to context {self.trace_id}")
        
        # Validate decision structure
        if not isinstance(decision, dict):
            logger.warning(f"Decision should be a dictionary, got {type(decision)}")
        
        # Add timestamp if not present
        if 'timestamp' not in decision:
            decision = {**decision, 'timestamp': datetime.now().isoformat()}
            logger.debug("Added timestamp to decision")
        
        # Create new decisions list with the appended decision
        new_decisions = [*self.decisions, decision]
        
        # Log the update
        logger.debug(f"Decision type: {decision.get('type', 'unknown')}")
        logger.debug(f"Context now has {len(new_decisions)} decisions")
        
        # Create and return new immutable context
        return replace(self, decisions=new_decisions)
    
    def with_constraint(self, key: str, value: Any) -> 'AgentContext':
        """
        Create new context with constraint added using immutable update pattern.
        
        This method creates a new AgentContext instance with the specified constraint
        added to the constraints dictionary. Constraints define execution limitations
        and requirements that must be respected during pipeline execution.
        
        Args:
            key (str): Constraint identifier (e.g., 'max_memory', 'timeout', 'resources').
            value (Any): Constraint value. Should be serializable for persistence.
        
        Returns:
            AgentContext: New immutable context instance with the constraint added.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> constrained = (context
            ...     .with_constraint("max_memory", "1GB")
            ...     .with_constraint("timeout", 120)
            ...     .with_constraint("allowed_tools", ["calculator", "text_parser"]))
        
        Note:
            If the constraint key already exists, its value will be replaced
            in the new context instance.
        """
        logger.debug(f"Adding constraint '{key}' to context {self.trace_id}")
        
        # Validate constraint key
        if not key or not isinstance(key, str):
            logger.warning(f"Constraint key should be a non-empty string, got: {key}")
        
        # Create new constraints dictionary with the added constraint
        new_constraints = {**self.constraints, key: value}
        
        # Log the update
        logger.debug(f"Constraint '{key}' = {value}")
        logger.debug(f"Context now has {len(new_constraints)} constraints")
        
        # Create and return new immutable context
        return replace(self, constraints=new_constraints)
    
    def with_performance_metric(self, key: str, value: Any) -> 'AgentContext':
        """
        Create new context with performance metric added using immutable update pattern.
        
        This method creates a new AgentContext instance with the specified performance
        metric added to the performance_metrics dictionary. Metrics track execution
        performance for optimization and monitoring purposes.
        
        Args:
            key (str): Metric identifier (e.g., 'stage_time', 'memory_usage', 'accuracy').
            value (Any): Metric value. Should be numeric for analysis purposes.
        
        Returns:
            AgentContext: New immutable context instance with the metric added.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> timed = (context
            ...     .with_performance_metric("parse_time", 0.15)
            ...     .with_performance_metric("memory_peak", 45.2)
            ...     .with_performance_metric("accuracy_score", 0.94))
        
        Note:
            Performance metrics are typically numeric values used for analysis.
            If the metric key already exists, its value will be replaced.
        """
        logger.debug(f"Adding performance metric '{key}' to context {self.trace_id}")
        
        # Validate metric key
        if not key or not isinstance(key, str):
            logger.warning(f"Metric key should be a non-empty string, got: {key}")
        
        # Log metric value type for analysis
        if isinstance(value, (int, float)):
            logger.debug(f"Numeric metric '{key}' = {value}")
        else:
            logger.debug(f"Non-numeric metric '{key}' = {value} (type: {type(value).__name__})")
        
        # Create new performance_metrics dictionary with the added metric
        new_metrics = {**self.performance_metrics, key: value}
        
        # Log the update
        logger.debug(f"Context now has {len(new_metrics)} performance metrics")
        
        # Create and return new immutable context
        return replace(self, performance_metrics=new_metrics)
    
    def get_stage_result(self, stage: str, default: Any = None) -> Any:
        """
        Get stage result with functional approach and comprehensive logging.
        
        This method retrieves the result for a specific pipeline stage using
        a functional approach with safe default handling. It provides detailed
        logging for debugging and monitoring purposes.
        
        Args:
            stage (str): Name of the pipeline stage to retrieve.
            default (Any, optional): Default value if stage result doesn't exist.
        
        Returns:
            Any: The stage result if it exists, otherwise the default value.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> context = context.with_stage_result("perceive", {"data": "parsed"})
            >>> result = context.get_stage_result("perceive")
            >>> missing = context.get_stage_result("nonexistent", "not_found")
        """
        logger.debug(f"Retrieving stage result for '{stage}' from context {self.trace_id}")
        
        result = self.stage_results.get(stage, default)
        
        if stage in self.stage_results:
            logger.debug(f"Found stage result for '{stage}'")
        else:
            logger.debug(f"Stage '{stage}' not found, returning default: {default}")
        
        return result
    
    def has_stage_result(self, stage: str) -> bool:
        """
        Check if stage has result using functional predicate with logging.
        
        This method checks whether a specific pipeline stage has completed
        and stored its result in the context. Uses functional predicate
        pattern for clean, readable code.
        
        Args:
            stage (str): Name of the pipeline stage to check.
        
        Returns:
            bool: True if the stage has a result, False otherwise.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> context = context.with_stage_result("perceive", {"data": "parsed"})
            >>> print(context.has_stage_result("perceive"))  # True
            >>> print(context.has_stage_result("plan"))      # False
        """
        logger.debug(f"Checking if stage '{stage}' has result in context {self.trace_id}")
        
        has_result = stage in self.stage_results
        
        logger.debug(f"Stage '{stage}' has result: {has_result}")
        return has_result
    
    def get_last_decision(self) -> Optional[Dict[str, Any]]:
        """
        Get last decision using functional approach with safe handling.
        
        This method retrieves the most recent decision from the chronological
        decision list. Returns None if no decisions have been made yet.
        
        Returns:
            Optional[Dict[str, Any]]: The last decision if any exist, None otherwise.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> context = context.with_decision({"type": "first", "choice": "A"})
            >>> context = context.with_decision({"type": "second", "choice": "B"})
            >>> last = context.get_last_decision()
            >>> print(last["type"])  # "second"
        """
        logger.debug(f"Retrieving last decision from context {self.trace_id}")
        
        if self.decisions:
            last_decision = self.decisions[-1]
            logger.debug(f"Found last decision of type: {last_decision.get('type', 'unknown')}")
            return last_decision
        else:
            logger.debug("No decisions found in context")
            return None
    
    def filter_decisions(self, predicate: Callable[[Dict[str, Any]], bool]) -> List[Dict[str, Any]]:
        """
        Filter decisions using functional approach with comprehensive logging.
        
        This method filters the decision list using a predicate function,
        following functional programming patterns for clean, composable code.
        
        Args:
            predicate (Callable): Function that takes a decision dict and returns bool.
        
        Returns:
            List[Dict[str, Any]]: List of decisions that match the predicate.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> context = context.with_decision({"type": "strategy", "confidence": 0.9})
            >>> context = context.with_decision({"type": "action", "confidence": 0.7})
            >>> 
            >>> # Filter high-confidence decisions
            >>> high_conf = context.filter_decisions(lambda d: d.get("confidence", 0) > 0.8)
            >>> print(len(high_conf))  # 1
        """
        logger.debug(f"Filtering decisions in context {self.trace_id}")
        
        try:
            filtered_decisions = list(filter(predicate, self.decisions))
            logger.debug(f"Filtered {len(self.decisions)} decisions to {len(filtered_decisions)}")
            return filtered_decisions
        except Exception as e:
            logger.error(f"Error filtering decisions: {e}")
            return []
    
    def map_stage_results(self, mapper: Callable[[str, Any], Any]) -> Dict[str, Any]:
        """
        Map stage results using functional approach with error handling.
        
        This method transforms stage results using a mapper function,
        following functional programming patterns for data transformation.
        
        Args:
            mapper (Callable): Function that takes (stage_name, result) and returns transformed value.
        
        Returns:
            Dict[str, Any]: Dictionary with transformed stage results.
        
        Example:
            >>> context = AgentContext(input_data="test")
            >>> context = context.with_stage_result("perceive", {"items": [1, 2, 3]})
            >>> 
            >>> # Transform results to include counts
            >>> transformed = context.map_stage_results(
            ...     lambda stage, result: {"original": result, "count": len(result.get("items", []))}
            ... )
        """
        logger.debug(f"Mapping stage results in context {self.trace_id}")
        
        try:
            mapped_results = {
                stage: mapper(stage, result) 
                for stage, result in self.stage_results.items()
            }
            logger.debug(f"Successfully mapped {len(self.stage_results)} stage results")
            return mapped_results
        except Exception as e:
            logger.error(f"Error mapping stage results: {e}")
            return {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'input_data': self.input_data,
            'stage_results': self.stage_results,
            'decisions': self.decisions,
            'trace_id': self.trace_id,
            'agent_id': self.agent_id,
            'timeout': self.timeout,
            'constraints': self.constraints,
            'configuration': self.configuration,
            'performance_metrics': self.performance_metrics
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], event_system: Optional['EventSystem'] = None) -> 'AgentContext':
        """Create context from dictionary."""
        return cls(
            input_data=data['input_data'],
            stage_results=data.get('stage_results', {}),
            decisions=data.get('decisions', []),
            trace_id=data.get('trace_id', str(uuid.uuid4())),
            agent_id=data.get('agent_id', 'default_agent'),
            timeout=data.get('timeout', 30),
            constraints=data.get('constraints', {}),
            configuration=data.get('configuration', {}),
            performance_metrics=data.get('performance_metrics', {}),
            event_system=event_system
        )
    
    def serialize(self) -> str:
        """Serialize context to JSON."""
        return json.dumps(self.to_dict(), default=str)
    
    @classmethod
    def deserialize(cls, json_str: str, event_system: Optional['EventSystem'] = None) -> 'AgentContext':
        """Deserialize context from JSON."""
        data = json.loads(json_str)
        return cls.from_dict(data, event_system)


class ContextManager:
    """
    Manages context evolution, persistence, and rollback capabilities.
    
    This class provides comprehensive context management including thread-safe
    context storage, evolution tracking, history management, and rollback
    capabilities. It maintains a complete audit trail of context changes
    for debugging, monitoring, and recovery purposes.
    
    Features:
        - Thread-safe context management using contextvars
        - Complete context evolution history with configurable retention
        - Rollback capabilities to any previous stage or state
        - Memory-efficient history management with automatic cleanup
        - Comprehensive logging for debugging and monitoring
        - Functional programming patterns for reliable operations
    
    Attributes:
        context_history (List[AgentContext]): Complete history of context changes.
        max_history_size (int): Maximum number of contexts to retain in history.
    
    Example:
        >>> manager = ContextManager()
        >>> context = AgentContext(input_data="test")
        >>> manager.set_context(context)
        >>> 
        >>> # Update context and track evolution
        >>> updated = context.with_stage_result("perceive", {"data": "parsed"})
        >>> manager.set_context(updated)
        >>> 
        >>> # Get evolution history
        >>> evolution = manager.get_context_evolution(context.trace_id)
        >>> print(len(evolution))  # 2
    """
    
    def __init__(self, max_history_size: int = 1000):
        """
        Initialize ContextManager with configurable history management.
        
        Args:
            max_history_size (int): Maximum number of contexts to retain.
                Older contexts are automatically removed when limit is exceeded.
        """
        self.context_history: List[AgentContext] = []
        self.max_history_size = max_history_size
        
        logger.info(f"ContextManager initialized with max_history_size: {max_history_size}")
    
    def set_context(self, context: AgentContext) -> None:
        """
        Set current context in thread-safe context variable with history tracking.
        
        This method updates the current context for the executing thread/task
        and adds the context to the evolution history for audit and rollback
        purposes. The operation is thread-safe and maintains consistency.
        
        Args:
            context (AgentContext): The context to set as current.
        
        Example:
            >>> manager = ContextManager()
            >>> context = AgentContext(input_data="test")
            >>> manager.set_context(context)
        
        Note:
            This method automatically manages history size and performs
            cleanup when the maximum history size is exceeded.
        """
        logger.debug(f"Setting context {context.trace_id} as current")
        
        # Set context in thread-safe context variable
        current_context.set(context)
        
        # Add to history for evolution tracking
        self._add_to_history(context)
        
        logger.debug(f"Context {context.trace_id} set successfully")
    
    def get_context(self) -> Optional[AgentContext]:
        """
        Get current context from thread-safe context variable.
        
        This method retrieves the current context for the executing thread/task.
        Returns None if no context has been set for the current execution context.
        
        Returns:
            Optional[AgentContext]: Current context if set, None otherwise.
        
        Example:
            >>> manager = ContextManager()
            >>> context = manager.get_context()  # None initially
            >>> 
            >>> manager.set_context(AgentContext(input_data="test"))
            >>> context = manager.get_context()  # Returns the set context
        """
        logger.debug("Retrieving current context")
        
        try:
            context = current_context.get()
            logger.debug(f"Retrieved context {context.trace_id}")
            return context
        except LookupError:
            logger.debug("No context set for current execution")
            return None
    
    def clear_context(self) -> None:
        """
        Clear the current context from the context variable.
        
        This method removes the current context from the thread-safe context
        variable, effectively clearing the execution state. The context history
        is preserved for audit and rollback purposes.
        """
        logger.debug("Clearing current context")
        
        try:
            # Get current context for logging before clearing
            context = current_context.get()
            logger.debug(f"Clearing context {context.trace_id}")
        except LookupError:
            logger.debug("No context to clear")
        
        # Clear the context variable (this may raise LookupError if no context is set)
        try:
            current_context.set(None)
        except Exception as e:
            logger.warning(f"Error clearing context: {e}")
    
    def _add_to_history(self, context: AgentContext) -> None:
        """
        Add context to history with intelligent size management and cleanup.
        
        This method adds the context to the evolution history and performs
        automatic cleanup when the maximum history size is exceeded. It
        maintains the most recent contexts while discarding older ones.
        
        Args:
            context (AgentContext): Context to add to history.
        """
        logger.debug(f"Adding context {context.trace_id} to history")
        
        # Add context to history
        self.context_history.append(context)
        
        # Perform cleanup if history size exceeds maximum
        if len(self.context_history) > self.max_history_size:
            # Keep only the most recent contexts
            old_size = len(self.context_history)
            self.context_history = self.context_history[-self.max_history_size:]
            removed_count = old_size - len(self.context_history)
            
            logger.debug(f"History cleanup: removed {removed_count} old contexts")
        
        logger.debug(f"Context history size: {len(self.context_history)}")
    
    def get_context_evolution(self, trace_id: str) -> List[AgentContext]:
        """
        Get complete context evolution for a specific trace using functional filtering.
        
        This method retrieves all context instances for a specific trace ID,
        providing a complete evolution history for debugging and analysis.
        
        Args:
            trace_id (str): Unique trace identifier to filter by.
        
        Returns:
            List[AgentContext]: Chronological list of contexts for the trace.
        
        Example:
            >>> manager = ContextManager()
            >>> context = AgentContext(input_data="test")
            >>> manager.set_context(context)
            >>> 
            >>> updated = context.with_stage_result("perceive", {"data": "parsed"})
            >>> manager.set_context(updated)
            >>> 
            >>> evolution = manager.get_context_evolution(context.trace_id)
            >>> print(len(evolution))  # 2
        """
        logger.debug(f"Getting context evolution for trace_id: {trace_id}")
        
        # Use functional filtering to find all contexts for the trace
        evolution = [ctx for ctx in self.context_history if ctx.trace_id == trace_id]
        
        logger.debug(f"Found {len(evolution)} contexts in evolution for trace {trace_id}")
        return evolution
    
    def rollback_to_stage(self, trace_id: str, target_stage: str) -> Optional[AgentContext]:
        """
        Rollback context to a specific stage using functional approach.
        
        This method finds and returns a context from before the specified stage
        was executed, enabling rollback to a previous execution state. Uses
        functional programming patterns for reliable rollback operations.
        
        Args:
            trace_id (str): Unique trace identifier for the execution.
            target_stage (str): Stage to roll back to (context before this stage).
        
        Returns:
            Optional[AgentContext]: Context from before target stage, or None if not found.
        
        Example:
            >>> manager = ContextManager()
            >>> # ... execute pipeline stages ...
            >>> 
            >>> # Rollback to before 'reason' stage
            >>> rollback_context = manager.rollback_to_stage(trace_id, "reason")
            >>> if rollback_context:
            ...     manager.set_context(rollback_context)
        """
        logger.info(f"Rolling back to stage '{target_stage}' for trace {trace_id}")
        
        # Get complete evolution history for the trace
        evolution = self.get_context_evolution(trace_id)
        
        if not evolution:
            logger.warning(f"No context evolution found for trace {trace_id}")
            return None
        
        # Find context before target stage using functional approach
        # Search in reverse chronological order for most recent valid state
        target_context = next(
            (ctx for ctx in reversed(evolution) 
             if target_stage not in ctx.stage_results),
            None
        )
        
        if target_context:
            logger.info(f"Found rollback context with {len(target_context.stage_results)} completed stages")
            return target_context
        else:
            logger.warning(f"No suitable rollback context found for stage '{target_stage}'")
            return None
    
    def get_history_stats(self) -> Dict[str, Any]:
        """
        Get comprehensive statistics about the context history.
        
        Returns:
            Dict[str, Any]: Statistics including total contexts, unique traces,
                memory usage estimates, and other relevant metrics.
        """
        logger.debug("Calculating context history statistics")
        
        unique_traces = len(set(ctx.trace_id for ctx in self.context_history))
        
        stats = {
            'total_contexts': len(self.context_history),
            'unique_traces': unique_traces,
            'max_history_size': self.max_history_size,
            'memory_usage_estimate': len(self.context_history) * 1024,  # Rough estimate
            'oldest_context': self.context_history[0].trace_id if self.context_history else None,
            'newest_context': self.context_history[-1].trace_id if self.context_history else None
        }
        
        logger.debug(f"History stats: {stats}")
        return stats