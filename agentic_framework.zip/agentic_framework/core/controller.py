"""
Main framework controller integrating all components with Prefect workflows.

This module provides the AgenticPipelineController that serves as the central orchestrator
for the agentic framework. It integrates Prefect flows with agentic capabilities,
providing a robust pipeline execution system with comprehensive observability,
error handling, rollback capabilities, and performance monitoring.

Key Features:
    - Prefect-based workflow orchestration with async execution
    - Six-stage agentic pipeline (perceive, plan, reason, act, review, learn)
    - Comprehensive observability and tracing with JSON-LD export
    - Automatic rollback and recovery mechanisms
    - Real-time performance monitoring and alerting
    - Event-driven architecture with pub/sub messaging
    - Context management with dependency injection
    - Configurable timeouts and resource management
    - Enterprise-grade error handling and logging

Pipeline Stages:
    1. Perceive: Data ingestion and environmental awareness
    2. Plan: Strategic planning and goal decomposition
    3. Reason: Logical reasoning and decision making
    4. Act: Action execution and tool utilization
    5. Review: Result validation and quality assessment
    6. Learn: Knowledge extraction and model updates

Architecture:
    The controller follows a modular architecture with clear separation of concerns:
    - Core execution logic with Prefect integration
    - Pluggable LLM providers and decision engines
    - Event system for loose coupling and observability
    - Context management for state consistency
    - Performance monitoring for optimization insights

Example:
    Basic usage:
        >>> controller = AgenticPipelineController(
        ...     timeout=60,
        ...     debug=True,
        ...     agent_id="math_processor"
        ... )
        >>> result = await controller.execute("Calculate 2+2")
    
    Advanced usage with custom components:
        >>> controller = AgenticPipelineController(
        ...     llm_provider=custom_llm,
        ...     decision_engine=custom_engine,
        ...     config={"max_rollback_attempts": 5}
        ... )

Author: Agentic Framework Team
Version: 2.0.0
"""

from prefect import flow, task
from typing import Dict, Any, Optional, List, Callable, Union
import asyncio
import time
import logging
from datetime import datetime

from .context import AgentContext, ContextManager
from .events import EventSystem
from .data_structures import Event
from ..config.manager import ConfigurationManager
from ..observability.tracer import ObservabilityManager
from ..observability.performance import PerformanceMonitor

# Initialize module logger
logger = logging.getLogger(__name__)


class AgenticPipelineController:
    """
    Central orchestrator for the agentic framework pipeline execution.
    
    This class serves as the main entry point for executing agentic workflows,
    integrating all framework components including Prefect flows, observability,
    performance monitoring, event systems, and rollback mechanisms.
    
    The controller implements a six-stage pipeline architecture that can be
    extended and customized for specific use cases. Each stage is executed
    with comprehensive monitoring, error handling, and recovery capabilities.
    
    Attributes:
        timeout (int): Maximum execution time per pipeline run in seconds.
        debug (bool): Enable debug mode for detailed logging and tracing.
        agent_id (str): Unique identifier for this agent instance.
        config (Dict[str, Any]): Configuration dictionary for framework settings.
        llm_provider: Language model provider for AI-powered operations.
        has_llm (bool): Whether an LLM provider is available and functional.
        event_system (EventSystem): Event system for pub/sub messaging.
        observability (ObservabilityManager): Observability and tracing manager.
        performance_monitor (PerformanceMonitor): Performance monitoring system.
        context_manager (ContextManager): Context state management.
        pipeline_stages (List[str]): Ordered list of pipeline stage names.
    
    Pipeline Stages:
        - perceive: Environmental awareness and data ingestion
        - plan: Strategic planning and goal decomposition  
        - reason: Logical reasoning and decision making
        - act: Action execution and tool utilization
        - review: Result validation and quality assessment
        - learn: Knowledge extraction and model updates
    
    Example:
        >>> # Basic initialization
        >>> controller = AgenticPipelineController(
        ...     timeout=60,
        ...     debug=True,
        ...     agent_id="data_processor"
        ... )
        >>> 
        >>> # Execute pipeline
        >>> result = await controller.execute("Process this data")
        >>> 
        >>> # Advanced initialization with custom components
        >>> controller = AgenticPipelineController(
        ...     llm_provider=OpenAIProvider(),
        ...     event_system=CustomEventSystem(),
        ...     config={"max_rollback_attempts": 5}
        ... )
    """
    
    def __init__(self,
                 timeout: int = 30,
                 debug: bool = False,
                 agent_id: str = "default_agent",
                 llm_provider: Optional['LLMProvider'] = None,
                 decision_engine: Optional['DecisionEngine'] = None,
                 event_system: Optional[EventSystem] = None,
                 observability: Optional['ObservabilityManager'] = None,
                 config: Optional[Dict[str, Any]] = None):
        """
        Initialize the AgenticPipelineController with comprehensive component setup.
        
        This initialization method sets up all core framework components with
        proper dependency injection, configuration management, and logging.
        Components are initialized in dependency order to ensure proper startup.
        
        Args:
            timeout (int): Maximum execution time per pipeline run in seconds.
                Default is 30 seconds. Should be adjusted based on expected workload.
            debug (bool): Enable debug mode for detailed logging and tracing.
                When True, enables verbose logging and extended trace information.
            agent_id (str): Unique identifier for this agent instance.
                Used for tracing, logging, and multi-agent coordination.
            llm_provider (Optional[LLMProvider]): Language model provider instance.
                If None, deterministic fallbacks will be used for AI operations.
            decision_engine (Optional[DecisionEngine]): Decision making engine.
                If None, a default rule-based engine will be instantiated.
            event_system (Optional[EventSystem]): Event system for messaging.
                If None, a default event system will be created with standard config.
            observability (Optional[ObservabilityManager]): Observability manager.
                If None, a default manager will be created with JSON-LD tracing.
            config (Optional[Dict[str, Any]]): Configuration dictionary.
                Overrides default settings for all framework components.
        
        Raises:
            ValueError: If invalid configuration values are provided.
            RuntimeError: If required dependencies cannot be initialized.
        """
        logger.info(f"Initializing AgenticPipelineController with agent_id: {agent_id}")
        
        # Core configuration with validation
        self.timeout = max(1, timeout)  # Ensure minimum 1 second timeout
        self.debug = debug
        self.agent_id = agent_id
        self.config = config or {}
        
        logger.debug(f"Controller configuration: timeout={self.timeout}s, debug={self.debug}")
        
        # Core components initialization
        self.llm_provider = llm_provider
        self.has_llm = llm_provider is not None and llm_provider.is_available()
        
        # Log LLM availability using conditional expression
        (logger.info(f"LLM provider available: {type(llm_provider).__name__}")
         if self.has_llm
         else logger.warning("No LLM provider available, using deterministic fallbacks"))
        
        # Initialize event system with dependency injection
        event_queue_size = self.config.get('event_queue_size', 10000)
        event_history_size = self.config.get('event_history_size', 1000)
        
        self.event_system = event_system or EventSystem(
            max_queue_size=event_queue_size,
            max_history_size=event_history_size
        )
        logger.debug(f"Event system initialized: queue_size={event_queue_size}, history_size={event_history_size}")
        
        # Initialize observability system
        obs_config = self.config.get('observability_config', {})
        self.observability = observability or ObservabilityManager(
            trace_level=obs_config.get('trace_level', 'detailed'),
            export_format=obs_config.get('export_format', 'json-ld'),
            export_path=obs_config.get('export_path', './traces')
        )
        logger.debug(f"Observability initialized: trace_level={obs_config.get('trace_level', 'detailed')}")
        
        # Initialize performance monitoring
        perf_config = self.config.get('performance_config', {})
        alert_thresholds = self.config.get('alert_thresholds', {})
        
        self.performance_monitor = PerformanceMonitor(
            config=perf_config,
            alert_thresholds=alert_thresholds
        )
        logger.debug("Performance monitor initialized")
        
        # Initialize context management
        self.context_manager = ContextManager()
        logger.debug("Context manager initialized")
        
        # Define pipeline stages in execution order
        self.pipeline_stages = [
            'perceive', 'plan', 'reason', 'act', 'review', 'learn'
        ]
        logger.info(f"Pipeline stages configured: {', '.join(self.pipeline_stages)}")
        
        logger.info("AgenticPipelineController initialization completed successfully")
    
    @flow(name="agentic_pipeline_execution")
    async def execute(self, input_data: str, **kwargs) -> Dict[str, Any]:
        """
        Main execution flow using Prefect with comprehensive monitoring and error handling.
        
        This method orchestrates the complete agentic pipeline execution, including
        context initialization, observability setup, performance monitoring, and
        graceful error handling with automatic rollback capabilities.
        
        The execution follows these phases:
        1. Context initialization and validation
        2. Observability and monitoring setup
        3. Pipeline execution with rollback support
        4. Result validation and completion recording
        5. Cleanup and resource management
        
        Args:
            input_data (str): The input data to process through the pipeline.
                This is the primary data that will be transformed through each stage.
            **kwargs: Additional execution parameters including:
                - constraints (Dict): Execution constraints and limitations
                - priority (int): Execution priority level (1-10)
                - metadata (Dict): Additional metadata for tracing
                - custom_config (Dict): Runtime configuration overrides
        
        Returns:
            Dict[str, Any]: Comprehensive execution results containing:
                - success (bool): Whether execution completed successfully
                - results (Dict): Results from each pipeline stage
                - decisions (List): Decision points and outcomes
                - performance_metrics (Dict): Execution performance data
                - trace_id (str): Unique trace identifier for debugging
                - execution_time (float): Total execution time in seconds
                - stage_times (Dict): Individual stage execution times
        
        Raises:
            ValueError: If input_data is invalid or constraints are malformed
            TimeoutError: If execution exceeds the configured timeout
            RuntimeError: If critical system components fail during execution
            Exception: For any other execution errors (with full context preserved)
        
        Example:
            >>> # Basic execution
            >>> result = await controller.execute("Process this data")
            >>> 
            >>> # Execution with constraints
            >>> result = await controller.execute(
            ...     "Complex task",
            ...     constraints={"max_memory": "1GB", "timeout": 120},
            ...     priority=8
            ... )
            >>> 
            >>> # Check results
            >>> if result['success']:
            ...     print(f"Completed in {result['execution_time']:.2f}s")
            ...     print(f"Trace ID: {result['trace_id']}")
        
        Note:
            This method is decorated with @flow to integrate with Prefect workflows.
            All execution is fully traced and can be monitored through the Prefect UI.
        """
        execution_start_time = time.time()
        logger.info(f"Starting pipeline execution for agent {self.agent_id}")
        logger.debug(f"Input data length: {len(input_data)} characters")
        
        # Validate input data
        if not input_data or not isinstance(input_data, str):
            error_msg = "Input data must be a non-empty string"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        # Extract and validate execution parameters
        constraints = kwargs.get('constraints', {})
        priority = kwargs.get('priority', 5)
        metadata = kwargs.get('metadata', {})
        custom_config = kwargs.get('custom_config', {})
        
        logger.debug(f"Execution parameters: constraints={len(constraints)}, priority={priority}")
        
        # Create initial context with comprehensive initialization
        context = AgentContext(
            input_data=input_data,
            agent_id=self.agent_id,
            timeout=self.timeout,
            constraints=constraints,
            configuration={**self.config, **custom_config},  # Merge configs
            event_system=self.event_system
        )
        
        # Add metadata to context
        if metadata:
            context.metadata.update(metadata)
        
        logger.info(f"Created execution context with trace_id: {context.trace_id}")
        
        # Set context in context manager for global access
        self.context_manager.set_context(context)
        
        # Start observability tracing
        logger.debug("Starting observability tracing")
        self.observability.start_trace(context.trace_id, context)
        
        # Start event processing system
        logger.debug("Starting event processing")
        await self.event_system.start_processing()
        
        # Start performance monitoring
        logger.debug("Starting performance monitoring")
        await self.performance_monitor.start_monitoring()
        
        # Emit pipeline start event
        await self.event_system.emit_event(Event(
            type='pipeline_started',
            source='pipeline_controller',
            data={
                'agent_id': self.agent_id,
                'trace_id': context.trace_id,
                'input_length': len(input_data),
                'priority': priority,
                'timestamp': datetime.now().isoformat()
            }
        ))
        
        try:
            logger.info("Executing pipeline with rollback support")
            
            # Execute pipeline with comprehensive rollback support
            result = await self._execute_pipeline_with_rollback(context)
            
            # Calculate total execution time
            execution_time = time.time() - execution_start_time
            result['execution_time'] = execution_time
            
            # Record successful completion in observability
            await self.observability.record_completion(context.trace_id, result)
            
            # Emit pipeline completion event
            await self.event_system.emit_event(Event(
                type='pipeline_completed',
                source='pipeline_controller',
                data={
                    'trace_id': context.trace_id,
                    'execution_time': execution_time,
                    'success': True,
                    'stages_completed': len(result.get('results', {})),
                    'timestamp': datetime.now().isoformat()
                }
            ))
            
            logger.info(f"Pipeline execution completed successfully in {execution_time:.2f}s")
            return result
            
        except Exception as e:
            # Calculate execution time for error reporting
            execution_time = time.time() - execution_start_time
            
            logger.error(f"Pipeline execution failed after {execution_time:.2f}s: {e}")
            
            # Record error in observability with full context
            await self.observability.record_error(context.trace_id, e, context.to_dict())
            
            # Emit pipeline error event
            await self.event_system.emit_event(Event(
                type='pipeline_error',
                source='pipeline_controller',
                data={
                    'error': str(e),
                    'error_type': type(e).__name__,
                    'trace_id': context.trace_id,
                    'execution_time': execution_time,
                    'agent_id': self.agent_id,
                    'timestamp': datetime.now().isoformat()
                }
            ))
            
            # Re-raise with preserved context
            raise
            
        finally:
            # Comprehensive cleanup with error handling
            logger.debug("Starting cleanup operations")
            
            try:
                # Stop event processing
                await self.event_system.stop_processing()
                logger.debug("Event processing stopped")
            except Exception as e:
                logger.warning(f"Error stopping event processing: {e}")
            
            try:
                # Stop performance monitoring
                await self.performance_monitor.stop_monitoring()
                logger.debug("Performance monitoring stopped")
            except Exception as e:
                logger.warning(f"Error stopping performance monitoring: {e}")
            
            # Clear context from context manager
            try:
                self.context_manager.clear_context()
                logger.debug("Context cleared")
            except Exception as e:
                logger.warning(f"Error clearing context: {e}")
            
            logger.debug("Cleanup operations completed")  
  
    async def _execute_pipeline_with_rollback(self, context: AgentContext) -> Dict[str, Any]:
        """
        Execute pipeline with comprehensive rollback and recovery capabilities.
        
        This method implements the core pipeline execution logic with sophisticated
        rollback mechanisms. It attempts to execute all pipeline stages in sequence,
        and if any stage fails, it can roll back to previous stages and retry with
        adjusted parameters or alternative strategies.
        
        Args:
            context (AgentContext): The execution context containing all pipeline state.
        
        Returns:
            Dict[str, Any]: Comprehensive execution results including success status,
                stage results, decisions, performance metrics, and rollback information.
        
        Raises:
            Exception: If pipeline fails after exhausting all rollback attempts.
        """
        logger.debug("Starting pipeline execution with rollback support")
        
        current_context = context
        rollback_attempts = 0
        max_rollback_attempts = self.config.get('max_rollback_attempts', 3)
        
        logger.info(f"Maximum rollback attempts configured: {max_rollback_attempts}")
        
        while rollback_attempts <= max_rollback_attempts:
            attempt_start_time = time.time()
            logger.debug(f"Pipeline execution attempt {rollback_attempts + 1}/{max_rollback_attempts + 1}")
            
            try:
                # Execute pipeline stages sequentially using functional approach
                async def execute_stage_if_needed(ctx, stage):
                    # Skip stages that are already completed (for rollback scenarios)
                    if ctx.has_stage_result(stage):
                        logger.debug(f"Stage {stage} already completed, skipping")
                        return ctx
                    
                    logger.info(f"Executing stage: {stage}")
                    
                    # Execute stage with comprehensive monitoring
                    updated_context = await self._execute_stage(stage, ctx)
                    
                    # Update context in context manager for global access
                    self.context_manager.set_context(updated_context)
                    return updated_context
                
                # Execute stages sequentially using functional reduce pattern
                from functools import reduce
                
                async def async_reduce(func, iterable, initial):
                    result = initial
                    for item in iterable:
                        result = await func(result, item)
                    return result
                
                current_context = await async_reduce(execute_stage_if_needed, self.pipeline_stages, current_context)
                
                # All stages completed successfully
                execution_time = time.time() - attempt_start_time
                logger.info(f"Pipeline execution completed successfully in {execution_time:.2f}s")
                
                return {
                    'success': True,
                    'results': current_context.stage_results,
                    'decisions': current_context.decisions,
                    'performance_metrics': current_context.performance_metrics,
                    'trace_id': current_context.trace_id,
                    'rollback_attempts': rollback_attempts
                }
                
            except Exception as e:
                rollback_attempts += 1
                execution_time = time.time() - attempt_start_time
                
                logger.warning(f"Pipeline execution attempt {rollback_attempts} failed: {e}")
                
                if rollback_attempts > max_rollback_attempts:
                    error_msg = f"Pipeline failed after {max_rollback_attempts} rollback attempts: {e}"
                    logger.error(error_msg)
                    raise Exception(error_msg)
                
                logger.info(f"Attempting rollback (attempt {rollback_attempts}/{max_rollback_attempts})")
                
                # Implement rollback strategy
                if current_context.stage_results:
                    last_stage = list(current_context.stage_results.keys())[-1]
                    logger.debug(f"Rolling back stage: {last_stage}")
                    
                    new_stage_results = {k: v for k, v in current_context.stage_results.items() if k != last_stage}
                    current_context = AgentContext(
                        input_data=current_context.input_data,
                        stage_results=new_stage_results,
                        decisions=current_context.decisions,
                        trace_id=current_context.trace_id,
                        agent_id=current_context.agent_id,
                        timeout=current_context.timeout,
                        constraints=current_context.constraints,
                        configuration=current_context.configuration,
                        performance_metrics=current_context.performance_metrics,
                        event_system=current_context.event_system
                    )
                    continue
                else:
                    raise Exception(f"Rollback failed: {e}")
    
    async def _execute_stage(self, stage: str, context: AgentContext) -> AgentContext:
        """
        Execute a single pipeline stage with comprehensive monitoring and error handling.
        
        This method orchestrates the execution of individual pipeline stages,
        providing timeout management, performance monitoring, observability tracking,
        and detailed error handling. Each stage execution is fully traced and
        monitored for performance optimization and debugging purposes.
        
        Args:
            stage (str): Name of the pipeline stage to execute.
                Must be one of: perceive, plan, reason, act, review, learn
            context (AgentContext): Current execution context containing all state.
        
        Returns:
            AgentContext: Updated context with stage results and performance metrics.
        
        Raises:
            Exception: If stage implementation is not found or execution fails.
            asyncio.TimeoutError: If stage execution exceeds timeout limits.
        
        Note:
            Each stage gets 80% of the total pipeline timeout to ensure
            time remains for cleanup and error handling operations.
        """
        stage_start_time = time.time()
        trace_id = context.trace_id
        
        logger.info(f"Starting execution of stage: {stage}")
        logger.debug(f"Stage timeout: {context.timeout * 0.8:.2f}s")
        
        try:
            # Record stage start in observability system
            await self.observability.record_stage_start(trace_id, stage)
            
            # Emit stage start event for monitoring
            await self.event_system.emit_event(Event(
                type='stage_started',
                source=f'{stage}_stage',
                data={
                    'stage': stage,
                    'trace_id': trace_id,
                    'agent_id': context.agent_id,
                    'timestamp': datetime.now().isoformat()
                }
            ))
            
            # Get stage implementation method
            stage_func = getattr(self, f'_{stage}_stage', None)
            if not stage_func:
                error_msg = f"Stage implementation not found: {stage}"
                logger.error(error_msg)
                raise Exception(error_msg)
            
            logger.debug(f"Found stage implementation: _{stage}_stage")
            
            # Execute stage with timeout protection
            # Use 80% of total timeout per stage to allow for cleanup
            stage_timeout = context.timeout * 0.8
            
            logger.debug(f"Executing stage {stage} with timeout {stage_timeout:.2f}s")
            stage_result_context = await asyncio.wait_for(
                stage_func(context, trace_id),
                timeout=stage_timeout
            )
            
            # Calculate stage execution time
            stage_time = time.time() - stage_start_time
            
            logger.info(f"Stage {stage} completed successfully in {stage_time:.2f}s")
            
            # Record successful completion in observability
            await self.observability.record_stage_completion(trace_id, stage, stage_time)
            
            # Record performance metrics
            self.performance_monitor.record_stage_time(stage, stage_time, success=True)
            
            # Get result keys for monitoring (safely handle missing results)
            stage_results = stage_result_context.stage_results.get(stage, {})
            result_keys = list(stage_results.keys()) if isinstance(stage_results, dict) else []
            
            # Emit stage completion event
            await self.event_system.emit_event(Event(
                type='stage_completed',
                source=f'{stage}_stage',
                data={
                    'stage': stage,
                    'execution_time': stage_time,
                    'result_keys': result_keys,
                    'trace_id': trace_id,
                    'success': True,
                    'timestamp': datetime.now().isoformat()
                }
            ))
            
            logger.debug(f"Stage {stage} produced {len(result_keys)} result keys")
            return stage_result_context
            
        except asyncio.TimeoutError:
            stage_time = time.time() - stage_start_time
            
            logger.error(f"Stage {stage} timed out after {stage_time:.2f}s")
            
            # Record timeout in observability
            await self.observability.record_stage_timeout(trace_id, stage, stage_time)
            self.performance_monitor.record_stage_time(stage, stage_time, success=False)
            
            # Emit timeout event
            await self.event_system.emit_event(Event(
                type='stage_timeout',
                source=f'{stage}_stage',
                data={
                    'stage': stage,
                    'execution_time': stage_time,
                    'timeout_limit': context.timeout * 0.8,
                    'trace_id': trace_id,
                    'timestamp': datetime.now().isoformat()
                }
            ))
            
            raise Exception(f"Stage {stage} timed out after {stage_time:.2f}s")
        
        except Exception as e:
            stage_time = time.time() - stage_start_time
            
            logger.error(f"Stage {stage} failed after {stage_time:.2f}s: {e}")
            
            # Record error in observability with full context
            await self.observability.record_stage_error(trace_id, stage, e, stage_time)
            self.performance_monitor.record_stage_time(stage, stage_time, success=False)
            
            # Emit error event with detailed information
            await self.event_system.emit_event(Event(
                type='stage_error',
                source=f'{stage}_stage',
                data={
                    'stage': stage,
                    'error': str(e),
                    'error_type': type(e).__name__,
                    'execution_time': stage_time,
                    'trace_id': trace_id,
                    'timestamp': datetime.now().isoformat()
                }
            ))
            
            # Re-raise with preserved context
            raise
    
    # Abstract stage methods to be implemented by subclasses
    
    async def _perceive_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """
        Perceive stage: Environmental awareness and data ingestion.
        
        This stage is responsible for gathering and processing input data,
        understanding the current environment, and preparing the context
        for subsequent planning and reasoning stages.
        
        Typical responsibilities:
        - Parse and validate input data
        - Gather environmental context and constraints
        - Identify available resources and tools
        - Establish baseline understanding of the problem space
        - Prepare structured data for downstream processing
        
        Args:
            context (AgentContext): Current execution context with input data.
            trace_id (str): Unique identifier for tracing this execution.
        
        Returns:
            AgentContext: Updated context with perception results in stage_results['perceive'].
        
        Raises:
            NotImplementedError: This method must be implemented by subclasses.
        
        Example Implementation:
            >>> async def _perceive_stage(self, context, trace_id):
            ...     # Parse input data
            ...     parsed_data = self.parse_input(context.input_data)
            ...     
            ...     # Gather environmental context
            ...     env_context = await self.gather_environment()
            ...     
            ...     # Update context with perception results
            ...     context.add_stage_result('perceive', {
            ...         'parsed_data': parsed_data,
            ...         'environment': env_context,
            ...         'available_tools': self.get_available_tools()
            ...     })
            ...     return context
        """
        logger.error("Perceive stage not implemented - this is an abstract method")
        raise NotImplementedError("Perceive stage must be implemented by subclass")
    
    async def _plan_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """
        Plan stage: Strategic planning and goal decomposition.
        
        This stage takes the perceived information and creates a strategic
        plan for achieving the desired outcomes. It breaks down complex
        goals into manageable sub-tasks and determines the optimal approach.
        
        Typical responsibilities:
        - Analyze perceived data and identify objectives
        - Decompose complex goals into sub-tasks
        - Determine optimal execution strategy
        - Identify required resources and dependencies
        - Create contingency plans for potential failures
        - Establish success criteria and validation methods
        
        Args:
            context (AgentContext): Context with perception results from previous stage.
            trace_id (str): Unique identifier for tracing this execution.
        
        Returns:
            AgentContext: Updated context with planning results in stage_results['plan'].
        
        Raises:
            NotImplementedError: This method must be implemented by subclasses.
        
        Example Implementation:
            >>> async def _plan_stage(self, context, trace_id):
            ...     perception = context.stage_results['perceive']
            ...     
            ...     # Analyze objectives
            ...     objectives = self.analyze_objectives(perception['parsed_data'])
            ...     
            ...     # Create execution plan
            ...     plan = await self.create_execution_plan(objectives)
            ...     
            ...     context.add_stage_result('plan', {
            ...         'objectives': objectives,
            ...         'execution_plan': plan,
            ...         'success_criteria': self.define_success_criteria(objectives)
            ...     })
            ...     return context
        """
        logger.error("Plan stage not implemented - this is an abstract method")
        raise NotImplementedError("Plan stage must be implemented by subclass")
    
    async def _reason_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """
        Reason stage: Logical reasoning and decision making.
        
        This stage applies logical reasoning to the plan, making informed
        decisions about how to proceed. It evaluates options, considers
        constraints, and determines the best course of action.
        
        Typical responsibilities:
        - Evaluate planning options and alternatives
        - Apply logical reasoning to decision points
        - Consider constraints and resource limitations
        - Assess risks and potential outcomes
        - Make informed decisions about execution approach
        - Prepare detailed instructions for the action stage
        
        Args:
            context (AgentContext): Context with perception and planning results.
            trace_id (str): Unique identifier for tracing this execution.
        
        Returns:
            AgentContext: Updated context with reasoning results in stage_results['reason'].
        
        Raises:
            NotImplementedError: This method must be implemented by subclasses.
        
        Example Implementation:
            >>> async def _reason_stage(self, context, trace_id):
            ...     plan = context.stage_results['plan']
            ...     
            ...     # Evaluate execution options
            ...     options = self.evaluate_options(plan['execution_plan'])
            ...     
            ...     # Make decisions based on reasoning
            ...     decisions = await self.make_decisions(options, context.constraints)
            ...     
            ...     context.add_stage_result('reason', {
            ...         'evaluated_options': options,
            ...         'decisions': decisions,
            ...         'reasoning_chain': self.get_reasoning_chain()
            ...     })
            ...     return context
        """
        logger.error("Reason stage not implemented - this is an abstract method")
        raise NotImplementedError("Reason stage must be implemented by subclass")
    
    async def _act_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """
        Act stage: Action execution and tool utilization.
        
        This stage executes the planned actions based on the reasoning
        decisions. It interacts with tools, performs computations, and
        carries out the concrete steps needed to achieve the objectives.
        
        Typical responsibilities:
        - Execute planned actions in the determined sequence
        - Utilize available tools and resources effectively
        - Handle action failures and implement fallback strategies
        - Monitor action progress and adjust as needed
        - Collect results and evidence of action outcomes
        - Maintain state consistency during execution
        
        Args:
            context (AgentContext): Context with perception, planning, and reasoning results.
            trace_id (str): Unique identifier for tracing this execution.
        
        Returns:
            AgentContext: Updated context with action results in stage_results['act'].
        
        Raises:
            NotImplementedError: This method must be implemented by subclasses.
        
        Example Implementation:
            >>> async def _act_stage(self, context, trace_id):
            ...     decisions = context.stage_results['reason']['decisions']
            ...     
            ...     # Execute planned actions
            ...     results = []
            ...     for action in decisions['action_sequence']:
            ...         result = await self.execute_action(action)
            ...         results.append(result)
            ...     
            ...     context.add_stage_result('act', {
            ...         'action_results': results,
            ...         'execution_log': self.get_execution_log(),
            ...         'final_state': self.get_current_state()
            ...     })
            ...     return context
        """
        logger.error("Act stage not implemented - this is an abstract method")
        raise NotImplementedError("Act stage must be implemented by subclass")
    
    async def _review_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """
        Review stage: Result validation and quality assessment.
        
        This stage evaluates the outcomes of the action stage, validates
        results against success criteria, and determines whether the
        objectives have been successfully achieved.
        
        Typical responsibilities:
        - Validate action results against success criteria
        - Assess quality and completeness of outcomes
        - Identify any errors or inconsistencies
        - Determine if objectives have been met
        - Prepare feedback for learning and improvement
        - Generate final result summaries and reports
        
        Args:
            context (AgentContext): Context with results from all previous stages.
            trace_id (str): Unique identifier for tracing this execution.
        
        Returns:
            AgentContext: Updated context with review results in stage_results['review'].
        
        Raises:
            NotImplementedError: This method must be implemented by subclasses.
        
        Example Implementation:
            >>> async def _review_stage(self, context, trace_id):
            ...     action_results = context.stage_results['act']['action_results']
            ...     success_criteria = context.stage_results['plan']['success_criteria']
            ...     
            ...     # Validate results
            ...     validation = self.validate_results(action_results, success_criteria)
            ...     
            ...     # Assess quality
            ...     quality_assessment = self.assess_quality(action_results)
            ...     
            ...     context.add_stage_result('review', {
            ...         'validation_results': validation,
            ...         'quality_assessment': quality_assessment,
            ...         'objectives_met': validation['success'],
            ...         'final_report': self.generate_report(context)
            ...     })
            ...     return context
        """
        logger.error("Review stage not implemented - this is an abstract method")
        raise NotImplementedError("Review stage must be implemented by subclass")
    
    async def _learn_stage(self, context: AgentContext, trace_id: str) -> AgentContext:
        """
        Learn stage: Knowledge extraction and model updates.
        
        This stage extracts learnings from the execution process, updates
        internal models and knowledge bases, and prepares insights for
        future executions to improve performance over time.
        
        Typical responsibilities:
        - Extract patterns and insights from execution data
        - Update internal knowledge bases and models
        - Identify successful strategies and failure modes
        - Generate recommendations for future improvements
        - Store learnings for future reference and reuse
        - Update performance baselines and expectations
        
        Args:
            context (AgentContext): Context with complete execution history and results.
            trace_id (str): Unique identifier for tracing this execution.
        
        Returns:
            AgentContext: Updated context with learning results in stage_results['learn'].
        
        Raises:
            NotImplementedError: This method must be implemented by subclasses.
        
        Example Implementation:
            >>> async def _learn_stage(self, context, trace_id):
            ...     # Extract execution patterns
            ...     patterns = self.extract_patterns(context.stage_results)
            ...     
            ...     # Update knowledge base
            ...     knowledge_updates = await self.update_knowledge(patterns)
            ...     
            ...     # Generate insights
            ...     insights = self.generate_insights(context)
            ...     
            ...     context.add_stage_result('learn', {
            ...         'extracted_patterns': patterns,
            ...         'knowledge_updates': knowledge_updates,
            ...         'insights': insights,
            ...         'performance_metrics': context.performance_metrics
            ...     })
            ...     return context
        """
        logger.error("Learn stage not implemented - this is an abstract method")
        raise NotImplementedError("Learn stage must be implemented by subclass")