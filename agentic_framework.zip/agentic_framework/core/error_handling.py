"""
Comprehensive error handling system with configurable strategies and intelligent recovery.

This module provides a sophisticated error handling framework for the agentic system,
featuring intelligent error classification, configurable recovery strategies, circuit
breaker patterns, and comprehensive monitoring. It enables robust error recovery
while maintaining system stability and performance.

Key Features:
    - Intelligent error classification based on type and message patterns
    - Configurable recovery strategies for different error categories
    - Circuit breaker patterns for preventing cascade failures
    - Exponential backoff with jitter for retry mechanisms
    - Resource cleanup and recovery procedures
    - Comprehensive error tracking and analytics
    - Fallback mechanisms for graceful degradation
    - Performance monitoring and optimization

Error Categories:
    - Timeout Errors: Network timeouts, operation timeouts, connection timeouts
    - Network Errors: Connection failures, DNS errors, network unavailability
    - Resource Errors: Memory exhaustion, disk full, resource limits exceeded
    - Validation Errors: Schema validation, data format errors, type mismatches
    - Authentication Errors: Permission denied, unauthorized access, token expiry
    - LLM Errors: API rate limits, model unavailability, quota exceeded
    - Context Corruption: State inconsistency, data corruption, invalid context

Recovery Strategies:
    - Retry with Backoff: Exponential backoff with configurable parameters
    - Circuit Breaker: Prevent cascade failures with automatic recovery
    - Cleanup and Retry: Resource cleanup followed by operation retry
    - Fallback to Default: Use default values when operations fail
    - Deterministic Fallback: Switch to deterministic behavior when AI fails

Example:
    Basic usage:
        >>> error_handler = ErrorHandlingStrategy(config)
        >>> try:
        ...     result = await risky_operation()
        ... except Exception as e:
        ...     recovery_result = await error_handler.handle_error(e, context)
    
    Custom configuration:
        >>> config = {
        ...     'timeout_errors': {'max_attempts': 5, 'backoff_factor': 1.5},
        ...     'network_errors': {'circuit_breaker_threshold': 5}
        ... }
        >>> handler = ErrorHandlingStrategy(config)

Author: Agentic Framework Team
Version: 2.0.0
"""

from typing import Dict, Any, List, Optional, Callable, Union
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import time
import logging
from datetime import datetime

from .context import AgentContext

# Initialize module logger
logger = logging.getLogger(__name__)


class ErrorCategory(Enum):
    """
    Enumeration of error categories for intelligent error classification.
    
    This enum defines the different categories of errors that the system can
    encounter and handle. Each category has specific recovery strategies and
    handling patterns optimized for that type of error.
    
    Categories:
        TIMEOUT_ERROR: Operations that exceed time limits
            - Network timeouts, operation timeouts, connection timeouts
            - Recovery: Retry with increased timeout, exponential backoff
        
        NETWORK_ERROR: Network connectivity and communication issues
            - Connection failures, DNS errors, network unavailability
            - Recovery: Circuit breaker, retry with backoff, fallback endpoints
        
        RESOURCE_ERROR: System resource exhaustion or limits
            - Memory exhaustion, disk full, CPU limits, file handle limits
            - Recovery: Cleanup resources, reduce load, graceful degradation
        
        VALIDATION_ERROR: Data validation and format issues
            - Schema validation failures, type mismatches, invalid data
            - Recovery: Use default values, data sanitization, format conversion
        
        AUTHENTICATION_ERROR: Security and access control issues
            - Permission denied, unauthorized access, expired tokens
            - Recovery: Token refresh, credential rotation, fallback auth
        
        LLM_ERROR: Language model and AI service issues
            - API rate limits, model unavailability, quota exceeded
            - Recovery: Fallback to deterministic behavior, queue requests
        
        CONTEXT_CORRUPTION: State and data consistency issues
            - State inconsistency, data corruption, invalid context
            - Recovery: Context reconstruction, rollback to known good state
        
        UNKNOWN_ERROR: Unclassified or unexpected errors
            - Novel errors, system errors, unexpected exceptions
            - Recovery: Default error handling, logging, graceful failure
    
    Usage:
        >>> category = ErrorCategory.TIMEOUT_ERROR
        >>> if category == ErrorCategory.TIMEOUT_ERROR:
        ...     # Apply timeout-specific recovery strategy
        ...     pass
    """
    
    TIMEOUT_ERROR = "timeout_error"
    NETWORK_ERROR = "network_error"
    RESOURCE_ERROR = "resource_error"
    VALIDATION_ERROR = "validation_error"
    AUTHENTICATION_ERROR = "authentication_error"
    LLM_ERROR = "llm_error"
    CONTEXT_CORRUPTION = "context_corruption"
    UNKNOWN_ERROR = "unknown_error"
    
    def __str__(self) -> str:
        """Return human-readable string representation."""
        return self.value.replace('_', ' ').title()
    
    @classmethod
    def from_exception(cls, exception: Exception) -> 'ErrorCategory':
        """
        Classify exception into appropriate error category.
        
        Args:
            exception (Exception): The exception to classify.
        
        Returns:
            ErrorCategory: The most appropriate category for the exception.
        """
        exception_name = exception.__class__.__name__.lower()
        exception_message = str(exception).lower()
        
        # Timeout errors
        if any(keyword in exception_name for keyword in ['timeout', 'time']):
            return cls.TIMEOUT_ERROR
        
        # Network errors
        if any(keyword in exception_name for keyword in ['connection', 'network', 'dns', 'http']):
            return cls.NETWORK_ERROR
        
        # Resource errors
        if any(keyword in exception_name for keyword in ['memory', 'resource', 'disk', 'limit']):
            return cls.RESOURCE_ERROR
        
        # Validation errors
        if any(keyword in exception_name for keyword in ['validation', 'schema', 'value', 'type']):
            return cls.VALIDATION_ERROR
        
        # Authentication errors
        if any(keyword in exception_name for keyword in ['auth', 'permission', 'unauthorized', 'forbidden']):
            return cls.AUTHENTICATION_ERROR
        
        # LLM errors
        if any(keyword in exception_name for keyword in ['llm', 'api', 'rate', 'quota']):
            return cls.LLM_ERROR
        
        # Default to unknown
        return cls.UNKNOWN_ERROR


@dataclass
class RecoveryStrategy:
    """
    Configuration for error recovery strategies with comprehensive options.
    
    This dataclass defines the configuration parameters for different error
    recovery strategies. Each strategy can be customized with specific
    parameters to optimize recovery behavior for different error types.
    
    Attributes:
        strategy (str): Name of the recovery strategy to use.
        max_attempts (int): Maximum number of recovery attempts before giving up.
        backoff_factor (float): Exponential backoff multiplier for retry delays.
        increase_timeout (bool): Whether to increase timeout on retries.
        circuit_breaker_threshold (int): Number of failures before opening circuit breaker.
        cleanup_actions (List[str]): List of cleanup actions to perform before retry.
        use_default_values (bool): Whether to use default values on validation errors.
        log_validation_errors (bool): Whether to log validation errors for debugging.
        disable_llm_temporarily (bool): Whether to temporarily disable LLM on errors.
        fallback_duration (int): Duration in seconds for temporary fallbacks.
        jitter (bool): Whether to add random jitter to retry delays.
        timeout_multiplier (float): Multiplier for timeout increases on retries.
        
    Example:
        >>> strategy = RecoveryStrategy(
        ...     strategy="retry_with_backoff",
        ...     max_attempts=5,
        ...     backoff_factor=1.5,
        ...     jitter=True
        ... )
    """
    
    strategy: str
    max_attempts: int = 3
    backoff_factor: float = 2.0
    increase_timeout: bool = False
    circuit_breaker_threshold: int = 3
    cleanup_actions: List[str] = field(default_factory=list)
    use_default_values: bool = False
    log_validation_errors: bool = True
    disable_llm_temporarily: bool = False
    fallback_duration: int = 300
    jitter: bool = True
    timeout_multiplier: float = 1.5
    
    def __post_init__(self):
        """Validate configuration parameters after initialization."""
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be at least 1")
        
        if self.backoff_factor < 1.0:
            raise ValueError("backoff_factor must be at least 1.0")
        
        if self.circuit_breaker_threshold < 1:
            raise ValueError("circuit_breaker_threshold must be at least 1")
        
        if self.fallback_duration < 0:
            raise ValueError("fallback_duration must be non-negative")
        
        logger.debug(f"Initialized RecoveryStrategy: {self.strategy} with {self.max_attempts} max attempts")


class ErrorHandlingStrategy:
    """
    Comprehensive error handling system with intelligent recovery strategies.
    
    This class provides sophisticated error handling capabilities including
    intelligent error classification, configurable recovery strategies, circuit
    breaker patterns, and comprehensive monitoring. It enables robust error
    recovery while maintaining system stability and performance.
    
    The system supports multiple recovery strategies:
    - Retry with exponential backoff and jitter
    - Circuit breaker patterns for cascade failure prevention
    - Resource cleanup and recovery procedures
    - Fallback to default values or deterministic behavior
    - Temporary service disabling for problematic components
    
    Attributes:
        config (Dict[str, Any]): Configuration dictionary for error handling.
        error_patterns (Dict[str, List[str]]): Patterns for error classification.
        recovery_strategies (Dict[str, RecoveryStrategy]): Recovery strategy configurations.
        circuit_breakers (Dict[str, Dict]): Circuit breaker state tracking.
        error_history (List[Dict]): Historical error data for analysis.
        
    Example:
        >>> config = {
        ...     'timeout_errors': {'max_attempts': 5, 'backoff_factor': 1.5},
        ...     'network_errors': {'circuit_breaker_threshold': 3}
        ... }
        >>> handler = ErrorHandlingStrategy(config)
        >>> 
        >>> try:
        ...     result = await risky_operation()
        ... except Exception as e:
        ...     recovery = await handler.handle_error(e, context)
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize ErrorHandlingStrategy with comprehensive configuration.
        
        Args:
            config (Dict[str, Any]): Configuration dictionary containing error
                handling parameters, recovery strategies, and thresholds.
        
        Raises:
            ValueError: If configuration is invalid or missing required parameters.
        """
        logger.info("Initializing ErrorHandlingStrategy with comprehensive error recovery")
        
        self.config = config or {}
        
        # Load error classification patterns
        self.error_patterns = self._load_error_patterns()
        logger.debug(f"Loaded {len(self.error_patterns)} error pattern categories")
        
        # Load recovery strategies
        self.recovery_strategies = self._load_recovery_strategies()
        logger.debug(f"Loaded {len(self.recovery_strategies)} recovery strategies")
        
        # Initialize circuit breaker tracking
        self.circuit_breakers = {}
        
        # Initialize error history for analytics
        self.error_history = []
        
        # Performance metrics
        self._total_errors = 0
        self._successful_recoveries = 0
        self._failed_recoveries = 0
        
        logger.info("ErrorHandlingStrategy initialization completed successfully")
    
    def _load_error_patterns(self) -> Dict[str, List[str]]:
        """Load error patterns from configuration."""
        return {
            'timeout_errors': ['TimeoutError', 'asyncio.TimeoutError', 'ConnectionTimeout'],
            'network_errors': ['ConnectionError', 'NetworkError', 'DNSError'],
            'resource_errors': ['MemoryError', 'ResourceExhausted', 'DiskFull'],
            'validation_errors': ['ValidationError', 'SchemaError', 'DataError'],
            'authentication_errors': ['AuthenticationError', 'PermissionError', 'Unauthorized'],
            'llm_errors': ['LLMError', 'APIError', 'RateLimitError']
        }
    
    def _load_recovery_strategies(self) -> Dict[str, RecoveryStrategy]:
        """Load recovery strategies from configuration."""
        return {
            'timeout_errors': RecoveryStrategy(
                strategy='retry_with_backoff',
                max_attempts=3,
                backoff_factor=2.0,
                increase_timeout=True
            ),
            'network_errors': RecoveryStrategy(
                strategy='retry_with_circuit_breaker',
                max_attempts=5,
                circuit_breaker_threshold=3
            ),
            'resource_errors': RecoveryStrategy(
                strategy='cleanup_and_retry',
                cleanup_actions=['gc_collect', 'clear_cache', 'reduce_workers'],
                max_attempts=2
            ),
            'validation_errors': RecoveryStrategy(
                strategy='fallback_to_default',
                use_default_values=True,
                log_validation_errors=True
            ),
            'llm_errors': RecoveryStrategy(
                strategy='fallback_to_deterministic',
                disable_llm_temporarily=True,
                fallback_duration=300
            )
        }
    
    async def handle_error(self, error: Exception, context: AgentContext) -> Any:
        """
        Handle error using intelligent classification and recovery strategies.
        
        This method is the main entry point for error handling. It classifies
        the error, selects an appropriate recovery strategy, and attempts
        recovery while tracking metrics and maintaining system stability.
        
        Args:
            error (Exception): The exception that occurred during execution.
            context (AgentContext): Current execution context for recovery decisions.
        
        Returns:
            Any: Recovery result or re-raises the exception if recovery fails.
        
        Raises:
            Exception: Original or new exception if all recovery attempts fail.
        
        Example:
            >>> try:
            ...     result = await risky_operation()
            ... except Exception as e:
            ...     recovery_result = await handler.handle_error(e, context)
            ...     if recovery_result.get('recovered'):
            ...         logger.info("Successfully recovered from error")
        """
        error_start_time = time.time()
        self._total_errors += 1
        
        logger.warning(f"Handling error: {type(error).__name__}: {error}")
        logger.debug(f"Error context: trace_id={context.trace_id}, agent_id={context.agent_id}")
        
        try:
            # Classify the error to determine appropriate strategy
            error_category = self._classify_error(error)
            logger.debug(f"Classified error as: {error_category}")
            
            # Get recovery strategy configuration
            strategy_config = self.recovery_strategies.get(error_category.value)
            
            if not strategy_config:
                logger.warning(f"No specific strategy found for {error_category}, using default handling")
                return await self._default_error_handling(error, context)
            
            strategy_name = strategy_config.strategy
            logger.info(f"Applying recovery strategy: {strategy_name}")
            
            # Execute appropriate recovery strategy
            if strategy_name == 'retry_with_backoff':
                result = await self._retry_with_backoff(error, context, strategy_config)
            elif strategy_name == 'retry_with_circuit_breaker':
                result = await self._retry_with_circuit_breaker(error, context, strategy_config)
            elif strategy_name == 'cleanup_and_retry':
                result = await self._cleanup_and_retry(error, context, strategy_config)
            elif strategy_name == 'fallback_to_default':
                result = await self._fallback_to_default(error, context, strategy_config)
            elif strategy_name == 'fallback_to_deterministic':
                result = await self._fallback_to_deterministic(error, context, strategy_config)
            else:
                logger.warning(f"Unknown strategy: {strategy_name}, using default handling")
                result = await self._default_error_handling(error, context)
            
            # Record successful recovery
            recovery_time = time.time() - error_start_time
            self._successful_recoveries += 1
            
            logger.info(f"Error recovery successful in {recovery_time:.3f}s using {strategy_name}")
            return result
            
        except Exception as recovery_error:
            # Record failed recovery
            recovery_time = time.time() - error_start_time
            self._failed_recoveries += 1
            
            logger.error(f"Error recovery failed after {recovery_time:.3f}s: {recovery_error}")
            
            # Record error in history for analysis
            self._record_error_history(error, context, recovery_error, recovery_time)
            
            # Re-raise the recovery error or original error
            raise recovery_error
    
    def _classify_error(self, error: Exception) -> ErrorCategory:
        """
        Classify error into appropriate category using pattern matching.
        
        This method analyzes the error type and message to determine the most
        appropriate error category, enabling targeted recovery strategies.
        
        Args:
            error (Exception): The exception to classify.
        
        Returns:
            ErrorCategory: The classified error category.
        """
        error_name = error.__class__.__name__
        error_message = str(error).lower()
        
        logger.debug(f"Classifying error: {error_name} - {error_message[:100]}")
        
        # Check each error category pattern
        for error_category, patterns in self.error_patterns.items():
            if any(pattern.lower() in error_name.lower() or pattern.lower() in error_message 
                   for pattern in patterns):
                logger.debug(f"Error classified as: {error_category}")
                return ErrorCategory(error_category)
        
        logger.debug("Error classified as: UNKNOWN_ERROR")
        return ErrorCategory.UNKNOWN_ERROR
    
    async def _retry_with_backoff(self, error: Exception, context: AgentContext, strategy: RecoveryStrategy) -> Any:
        """Retry with exponential backoff."""
        for attempt in range(strategy.max_attempts):
            if attempt > 0:
                delay = strategy.backoff_factor ** (attempt - 1)
                await asyncio.sleep(delay)
            
            try:
                # This would need to be implemented by the calling code
                # For now, return a recovery indicator
                return {'recovered': True, 'strategy': 'retry_with_backoff', 'attempts': attempt + 1}
            except Exception as e:
                if attempt == strategy.max_attempts - 1:
                    raise e
                continue
        
        raise error
    
    async def _retry_with_circuit_breaker(self, error: Exception, context: AgentContext, strategy: RecoveryStrategy) -> Any:
        """Retry with circuit breaker pattern."""
        error_key = f"{error.__class__.__name__}_{context.trace_id}"
        
        # Check circuit breaker
        if self._is_circuit_breaker_open(error_key, strategy):
            raise Exception(f"Circuit breaker open for {error.__class__.__name__}")
        
        try:
            # Attempt recovery
            result = {'recovered': True, 'strategy': 'retry_with_circuit_breaker'}
            self._reset_circuit_breaker(error_key)
            return result
        except Exception as e:
            self._increment_circuit_breaker(error_key)
            raise e
    
    async def _cleanup_and_retry(self, error: Exception, context: AgentContext, strategy: RecoveryStrategy) -> Any:
        """Cleanup resources and retry."""
        # Perform cleanup actions
        if strategy.cleanup_actions:
            for action in strategy.cleanup_actions:
                await self._perform_cleanup_action(action)
        
        # Retry after cleanup
        return {'recovered': True, 'strategy': 'cleanup_and_retry', 'cleanup_performed': True}
    
    async def _fallback_to_default(self, error: Exception, context: AgentContext, strategy: RecoveryStrategy) -> Any:
        """Fallback to default values."""
        if strategy.log_validation_errors:
            # Log the validation error
            pass
        
        if strategy.use_default_values:
            return {'recovered': True, 'strategy': 'fallback_to_default', 'used_defaults': True}
        
        raise error
    
    async def _fallback_to_deterministic(self, error: Exception, context: AgentContext, strategy: RecoveryStrategy) -> Any:
        """Fallback to deterministic behavior."""
        if strategy.disable_llm_temporarily:
            # Temporarily disable LLM
            pass
        
        return {'recovered': True, 'strategy': 'fallback_to_deterministic', 'llm_disabled': True}
    
    async def _default_error_handling(self, error: Exception, context: AgentContext) -> Any:
        """Default error handling when no specific strategy is available."""
        # Record error
        self.error_history.append({
            'error': str(error),
            'error_type': error.__class__.__name__,
            'timestamp': time.time(),
            'trace_id': context.trace_id
        })
        
        # Re-raise the error
        raise error
    
    def _is_circuit_breaker_open(self, error_key: str, strategy: RecoveryStrategy) -> bool:
        """Check if circuit breaker is open."""
        if error_key not in self.circuit_breakers:
            return False
        
        breaker_info = self.circuit_breakers[error_key]
        return breaker_info['failure_count'] >= strategy.circuit_breaker_threshold
    
    def _increment_circuit_breaker(self, error_key: str) -> None:
        """Increment circuit breaker failure count."""
        if error_key not in self.circuit_breakers:
            self.circuit_breakers[error_key] = {'failure_count': 0, 'last_failure': time.time()}
        
        self.circuit_breakers[error_key]['failure_count'] += 1
        self.circuit_breakers[error_key]['last_failure'] = time.time()
    
    def _reset_circuit_breaker(self, error_key: str) -> None:
        """Reset circuit breaker on successful recovery."""
        if error_key in self.circuit_breakers:
            del self.circuit_breakers[error_key]
    
    async def _perform_cleanup_action(self, action: str) -> None:
        """Perform cleanup action."""
        if action == 'gc_collect':
            import gc
            gc.collect()
        elif action == 'clear_cache':
            # Clear various caches
            pass
        elif action == 'reduce_workers':
            # Reduce worker count
            pass
    
    def get_error_statistics(self) -> Dict[str, Any]:
        """Get error handling statistics."""
        if not self.error_history:
            return {'total_errors': 0}
        
        error_counts = {}
        for error_record in self.error_history:
            error_type = error_record['error_type']
            error_counts[error_type] = error_counts.get(error_type, 0) + 1
        
        return {
            'total_errors': len(self.error_history),
            'error_breakdown': error_counts,
            'circuit_breakers_active': len(self.circuit_breakers),
            'recent_errors': self.error_history[-10:],  # Last 10 errors
            'successful_recoveries': self._successful_recoveries,
            'failed_recoveries': self._failed_recoveries,
            'recovery_rate': self._successful_recoveries / max(1, self._total_errors)
        }
    
    def _record_error_history(self, original_error: Exception, context: AgentContext, 
                             recovery_error: Exception, recovery_time: float) -> None:
        """
        Record error details in history for analysis and monitoring.
        
        Args:
            original_error (Exception): The original error that occurred.
            context (AgentContext): Execution context when error occurred.
            recovery_error (Exception): Error during recovery attempt.
            recovery_time (float): Time spent attempting recovery.
        """
        error_record = {
            'original_error': str(original_error),
            'original_error_type': original_error.__class__.__name__,
            'recovery_error': str(recovery_error),
            'recovery_error_type': recovery_error.__class__.__name__,
            'recovery_time': recovery_time,
            'timestamp': datetime.now().isoformat(),
            'trace_id': context.trace_id,
            'agent_id': context.agent_id
        }
        
        self.error_history.append(error_record)
        
        # Limit history size for memory management
        max_history = 1000
        if len(self.error_history) > max_history:
            self.error_history = self.error_history[-max_history:]
        
        logger.debug(f"Recorded error in history: {error_record['original_error_type']}")