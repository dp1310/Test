"""
Core data structures for the agentic framework.

This module defines the fundamental data structures used throughout the framework
for events, decisions, and other core concepts.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
import time
import uuid


@dataclass
class Event:
    """Framework event structure."""
    type: str
    source: str
    data: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    trace_id: Optional[str] = None
    correlation_id: Optional[str] = None


@dataclass
class DecisionPoint:
    """Decision point in workflow execution."""
    id: str
    description: str
    type: str
    constraints: Dict[str, Any] = field(default_factory=dict)
    context_requirements: List[str] = field(default_factory=list)


@dataclass
class Option:
    """Decision option with metadata."""
    id: str
    description: str
    estimated_cost: float = 1.0
    risk_level: str = "medium"
    expected_outcome: str = ""
    requires_llm: bool = False
    constraints: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Decision:
    """Decision result with reasoning."""
    chosen_option: Option
    confidence: float
    reasoning: str
    alternatives_considered: List[Option]
    decision_time: float
    context_used: Dict[str, Any]