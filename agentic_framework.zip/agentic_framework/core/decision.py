"""
Intelligent decision engine with LLM integration and comprehensive fallback strategies.

This module provides a sophisticated decision-making system for the agentic framework
that combines AI-powered decision making with robust deterministic fallbacks. It
enables intelligent choice selection across various scenarios while maintaining
reliability and performance through caching, learning, and comprehensive monitoring.

Key Features:
    - LLM-powered intelligent decision making with structured prompts
    - Multiple fallback strategies for reliability (heuristic, rule-based, performance-based)
    - Decision caching for performance optimization
    - Historical performance tracking and learning
    - Comprehensive constraint satisfaction checking
    - Functional programming patterns for composable decision logic
    - Detailed logging and monitoring for debugging and optimization
    - Graceful degradation under resource constraints

Decision Strategies:
    1. LLM-Based: Uses language models for context-aware intelligent decisions
    2. Heuristic: Functional composition of scoring functions for option evaluation
    3. Rule-Based: Predefined rules with constraint satisfaction
    4. Performance-Based: Historical data analysis for optimal choice selection
    5. Random: Ultimate fallback for system resilience

Architecture:
    The decision engine follows a layered approach:
    - Primary: LLM-based decisions for optimal intelligence
    - Secondary: Deterministic fallbacks for reliability
    - Tertiary: Performance tracking for continuous improvement
    - Caching: Decision memoization for efficiency
    - Monitoring: Comprehensive logging and metrics

Example:
    Basic usage:
        >>> engine = DecisionEngine(llm_provider=openai_provider)
        >>> decision_point = DecisionPoint(
        ...     id="strategy_selection",
        ...     type="execution_strategy",
        ...     description="Choose execution approach"
        ... )
        >>> options = [
        ...     Option(id="parallel", description="Parallel execution"),
        ...     Option(id="sequential", description="Sequential execution")
        ... ]
        >>> decision = await engine.make_decision(decision_point, context, options)
        >>> print(f"Chose: {decision.chosen_option.id} (confidence: {decision.confidence})")

Performance:
    - Decision caching reduces repeated computation overhead
    - Fallback strategies ensure sub-second response times
    - Historical tracking enables continuous optimization
    - Memory-efficient with configurable cache limits

Author: Agentic Framework Team
Version: 2.0.0
"""

from typing import Dict, Any, List, Optional, Callable, Union
import asyncio
import time
import json
import logging
from functools import reduce
from datetime import datetime

from .data_structures import DecisionPoint, Option, Decision
from .context import AgentContext
from .protocols import LLMProvider

# Initialize module logger
logger = logging.getLogger(__name__)


class DecisionEngine:
    """
    Intelligent decision engine with LLM integration and comprehensive fallback strategies.
    
    This class provides sophisticated decision-making capabilities for the agentic
    framework, combining AI-powered intelligence with robust deterministic fallbacks.
    It maintains decision history, performance tracking, and caching for optimal
    performance and reliability.
    
    The engine supports multiple decision strategies in priority order:
    1. LLM-based decisions for maximum intelligence and context awareness
    2. Heuristic decisions using functional composition of scoring functions
    3. Rule-based decisions with constraint satisfaction
    4. Performance-based decisions using historical data analysis
    5. Random decisions as ultimate fallback for system resilience
    
    Features:
        - Intelligent caching with configurable size limits
        - Performance tracking and learning from decision outcomes
        - Comprehensive constraint satisfaction checking
        - Graceful degradation under resource limitations
        - Detailed logging and monitoring for debugging
        - Functional programming patterns for composable logic
    
    Attributes:
        llm_provider (Optional[LLMProvider]): Language model provider for AI decisions.
        fallback_strategies (List[str]): Ordered list of fallback strategy names.
        decision_cache (Dict[str, Decision]): Cache for decision memoization.
        cache_size (int): Maximum number of cached decisions.
        decision_history (List[Decision]): Complete history of decisions made.
        performance_tracking (Dict[str, List[float]]): Performance metrics by decision type.
        fallback_implementations (Dict[str, Callable]): Strategy implementation mapping.
    
    Example:
        >>> # Initialize with LLM provider
        >>> engine = DecisionEngine(
        ...     llm_provider=openai_provider,
        ...     fallback_strategies=['heuristic', 'rule_based', 'performance_based'],
        ...     cache_size=2000
        ... )
        >>> 
        >>> # Make a decision
        >>> decision = await engine.make_decision(decision_point, context, options)
        >>> 
        >>> # Check decision quality
        >>> if decision.confidence > 0.8:
        ...     logger.info(f"High confidence decision: {decision.reasoning}")
    """
    
    def __init__(self, 
                 llm_provider: Optional[LLMProvider] = None,
                 fallback_strategies: List[str] = None,
                 cache_size: int = 1000):
        """
        Initialize DecisionEngine with comprehensive configuration and monitoring.
        
        Args:
            llm_provider (Optional[LLMProvider]): Language model provider for AI decisions.
                If None, only deterministic fallback strategies will be used.
            fallback_strategies (List[str], optional): Ordered list of fallback strategies.
                Default is ['heuristic', 'rule_based', 'random'] for balanced performance.
            cache_size (int): Maximum number of decisions to cache for performance.
                Larger values improve performance but use more memory.
        
        Raises:
            ValueError: If cache_size is not positive or fallback_strategies contains invalid names.
        """
        logger.info("Initializing DecisionEngine with comprehensive decision-making capabilities")
        
        # Validate inputs
        if cache_size <= 0:
            raise ValueError("cache_size must be positive")
        
        # Core configuration
        self.llm_provider = llm_provider
        self.fallback_strategies = fallback_strategies or ['heuristic', 'rule_based', 'random']
        self.cache_size = cache_size
        
        # Log configuration
        if self.llm_provider:
            logger.info(f"LLM provider available: {type(self.llm_provider).__name__}")
        else:
            logger.info("No LLM provider - using deterministic strategies only")
        
        logger.debug(f"Fallback strategies: {', '.join(self.fallback_strategies)}")
        logger.debug(f"Decision cache size: {cache_size}")
        
        # Decision caching for performance optimization
        self.decision_cache: Dict[str, Decision] = {}
        
        # Decision history and learning infrastructure
        self.decision_history: List[Decision] = []
        self.performance_tracking: Dict[str, List[float]] = {}
        
        # Performance metrics
        self._decision_count = 0
        self._cache_hits = 0
        self._llm_decisions = 0
        self._fallback_decisions = 0
        
        # Fallback strategy implementations
        self.fallback_implementations = {
            'heuristic': self._heuristic_decision,
            'rule_based': self._rule_based_decision,
            'random': self._random_decision,
            'performance_based': self._performance_based_decision
        }
        
        # Validate fallback strategies
        invalid_strategies = set(self.fallback_strategies) - set(self.fallback_implementations.keys())
        if invalid_strategies:
            logger.warning(f"Invalid fallback strategies will be ignored: {invalid_strategies}")
            self.fallback_strategies = [s for s in self.fallback_strategies if s in self.fallback_implementations]
        
        logger.info("DecisionEngine initialization completed successfully")
    
    async def make_decision(self, 
                          decision_point: DecisionPoint, 
                          context: AgentContext, 
                          options: List[Option]) -> Decision:
        """
        Make intelligent decision using LLM or fallback strategies with comprehensive monitoring.
        
        This method orchestrates the complete decision-making process, including cache
        checking, strategy selection, performance tracking, and error handling. It
        ensures reliable decision making while optimizing for performance and learning.
        
        Decision Process:
        1. Check decision cache for previously computed results
        2. Attempt LLM-based decision if provider is available
        3. Fall back to deterministic strategies if LLM fails
        4. Cache successful decisions for future use
        5. Track performance metrics for continuous improvement
        
        Args:
            decision_point (DecisionPoint): The decision context and requirements.
            context (AgentContext): Current execution context with state and constraints.
            options (List[Option]): Available options to choose from.
        
        Returns:
            Decision: Comprehensive decision result with chosen option, confidence,
                reasoning, and metadata for audit and debugging purposes.
        
        Raises:
            ValueError: If options list is empty or decision_point is invalid.
            Exception: Re-raises any unhandled exceptions after attempting fallbacks.
        
        Example:
            >>> decision_point = DecisionPoint(
            ...     id="execution_strategy",
            ...     type="performance_optimization",
            ...     description="Choose between parallel and sequential execution"
            ... )
            >>> options = [
            ...     Option(id="parallel", estimated_cost=0.5, risk_level="medium"),
            ...     Option(id="sequential", estimated_cost=0.8, risk_level="low")
            ... ]
            >>> decision = await engine.make_decision(decision_point, context, options)
            >>> logger.info(f"Decision: {decision.chosen_option.id} (confidence: {decision.confidence})")
        
        Performance:
            - Cache hits provide sub-millisecond response times
            - LLM decisions typically complete in 1-3 seconds
            - Fallback decisions complete in under 100ms
            - All decisions are tracked for performance analysis
        """
        decision_start_time = time.time()
        self._decision_count += 1
        
        logger.info(f"Making decision for point '{decision_point.id}' with {len(options)} options")
        logger.debug(f"Decision type: {decision_point.type}, Description: {decision_point.description}")
        
        # Input validation
        if not options:
            error_msg = f"No options provided for decision point '{decision_point.id}'"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        if not decision_point.id:
            error_msg = "Decision point must have a valid ID"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        # Check decision cache first for performance optimization
        cache_key = self._generate_cache_key(decision_point, context, options)
        if cache_key in self.decision_cache:
            self._cache_hits += 1
            cached_decision = self.decision_cache[cache_key]
            
            logger.debug(f"Cache hit for decision '{decision_point.id}' (total hits: {self._cache_hits})")
            
            # Return cached decision with updated timestamp
            return Decision(
                chosen_option=cached_decision.chosen_option,
                confidence=cached_decision.confidence,
                reasoning=f"Cached: {cached_decision.reasoning}",
                alternatives_considered=cached_decision.alternatives_considered,
                decision_time=time.time(),
                context_used=cached_decision.context_used
            )
        
        logger.debug(f"No cache hit for decision '{decision_point.id}', proceeding with fresh decision")
        
        try:
            # Attempt LLM-based decision first if provider is available
            if self.llm_provider and self.llm_provider.is_available():
                logger.debug("Attempting LLM-based decision")
                decision = await self._llm_decision(decision_point, context, options)
                self._llm_decisions += 1
                logger.info(f"LLM decision completed: {decision.chosen_option.id} (confidence: {decision.confidence:.2f})")
            else:
                logger.debug("LLM provider unavailable, using fallback strategies")
                decision = await self._fallback_decision(decision_point, context, options)
                self._fallback_decisions += 1
                logger.info(f"Fallback decision completed: {decision.chosen_option.id} (confidence: {decision.confidence:.2f})")
            
            # Cache successful decision for future use
            self._cache_decision(cache_key, decision)
            
            # Track decision performance for learning
            self._track_decision_performance(decision_point.id, decision)
            
            # Add to decision history for audit trail
            self.decision_history.append(decision)
            
            # Log performance metrics
            decision_time = time.time() - decision_start_time
            logger.debug(f"Decision completed in {decision_time:.3f}s")
            logger.debug(f"Decision reasoning: {decision.reasoning}")
            
            return decision
            
        except Exception as e:
            decision_time = time.time() - decision_start_time
            logger.error(f"Primary decision strategy failed after {decision_time:.3f}s: {e}")
            
            # Attempt fallback decision on any error
            try:
                logger.warning("Attempting fallback decision due to primary strategy failure")
                fallback_decision = await self._fallback_decision(decision_point, context, options)
                self._fallback_decisions += 1
                
                # Cache fallback decision
                self._cache_decision(cache_key, fallback_decision)
                
                # Track fallback performance
                self._track_decision_performance(decision_point.id, fallback_decision)
                
                # Add to history
                self.decision_history.append(fallback_decision)
                
                logger.info(f"Fallback decision successful: {fallback_decision.chosen_option.id}")
                return fallback_decision
                
            except Exception as fallback_error:
                total_time = time.time() - decision_start_time
                logger.error(f"All decision strategies failed after {total_time:.3f}s")
                logger.error(f"Primary error: {e}")
                logger.error(f"Fallback error: {fallback_error}")
                
                # Re-raise the original exception with context
                raise Exception(f"Decision making failed for '{decision_point.id}': {e}") from e    

    async def _llm_decision(self, 
                           decision_point: DecisionPoint, 
                           context: AgentContext, 
                           options: List[Option]) -> Decision:
        """Make decision using LLM."""
        
        # Prepare structured prompt
        prompt = self._create_decision_prompt(decision_point, context, options)
        
        try:
            response = await self.llm_provider.complete(
                prompt=prompt,
                max_tokens=1000,
                temperature=0.1
            )
            
            # Parse LLM response
            decision_data = self._parse_llm_decision(response, options)
            
            return Decision(
                chosen_option=decision_data['chosen_option'],
                confidence=decision_data['confidence'],
                reasoning=decision_data['reasoning'],
                alternatives_considered=options,
                decision_time=time.time(),
                context_used=self._extract_decision_context(context)
            )
            
        except Exception as e:
            raise Exception(f"LLM decision failed: {e}")
    
    async def _fallback_decision(self, 
                               decision_point: DecisionPoint, 
                               context: AgentContext, 
                               options: List[Option]) -> Decision:
        """Make decision using fallback strategies."""
        
        for strategy in self.fallback_strategies:
            try:
                fallback_func = self.fallback_implementations.get(strategy)
                if fallback_func:
                    return await fallback_func(decision_point, context, options)
            except Exception:
                continue
        
        # Ultimate fallback - return first option
        return Decision(
            chosen_option=options[0],
            confidence=0.1,
            reasoning="Ultimate fallback - selected first available option",
            alternatives_considered=options,
            decision_time=time.time(),
            context_used={}
        )
    
    async def _heuristic_decision(self, 
                                decision_point: DecisionPoint, 
                                context: AgentContext, 
                                options: List[Option]) -> Decision:
        """Heuristic-based decision using functional approach."""
        
        # Score options using functional composition
        scoring_functions = [
            lambda opt: 1.0 / max(opt.estimated_cost, 0.1),  # Lower cost is better
            lambda opt: {'low': 1.0, 'medium': 0.7, 'high': 0.3}.get(opt.risk_level, 0.5),
            lambda opt: 1.0 if not opt.requires_llm or self.llm_provider else 0.5
        ]
        
        def score_option(option: Option) -> float:
            scores = [func(option) for func in scoring_functions]
            return sum(scores) / len(scores)
        
        # Score all options
        scored_options = [(option, score_option(option)) for option in options]
        
        # Select best option
        best_option, best_score = max(scored_options, key=lambda x: x[1])
        
        return Decision(
            chosen_option=best_option,
            confidence=min(best_score, 0.9),
            reasoning=f"Heuristic selection based on cost, risk, and availability (score: {best_score:.2f})",
            alternatives_considered=options,
            decision_time=time.time(),
            context_used=self._extract_decision_context(context)
        )
    
    async def _rule_based_decision(self, 
                                 decision_point: DecisionPoint, 
                                 context: AgentContext, 
                                 options: List[Option]) -> Decision:
        """Rule-based decision using predefined rules."""
        
        # Define rules as functions
        rules = [
            # Rule 1: Prefer options that don't require LLM if LLM unavailable
            lambda opts: [opt for opt in opts if not opt.requires_llm] if not self.llm_provider else opts,
            
            # Rule 2: Filter by constraints
            lambda opts: [opt for opt in opts if self._satisfies_constraints(opt, context)],
            
            # Rule 3: Prefer low-risk options under resource constraints
            lambda opts: [opt for opt in opts if opt.risk_level == 'low'] if context.constraints.get('resource_limited') else opts
        ]
        
        # Apply rules sequentially using functional composition
        filtered_options = reduce(lambda opts, rule: rule(opts), rules, options)
        
        if not filtered_options:
            filtered_options = options  # Fallback to all options
        
        # Select first option after rule filtering
        chosen_option = filtered_options[0]
        
        return Decision(
            chosen_option=chosen_option,
            confidence=0.8,
            reasoning=f"Rule-based selection from {len(filtered_options)} filtered options",
            alternatives_considered=options,
            decision_time=time.time(),
            context_used=self._extract_decision_context(context)
        )
    
    async def _performance_based_decision(self, 
                                        decision_point: DecisionPoint, 
                                        context: AgentContext, 
                                        options: List[Option]) -> Decision:
        """Performance-based decision using historical data."""
        
        # Get performance history for each option
        option_performance = {}
        for option in options:
            performance_key = f"{decision_point.id}_{option.id}"
            performance_history = self.performance_tracking.get(performance_key, [])
            
            if performance_history:
                # Calculate average performance
                avg_performance = sum(performance_history) / len(performance_history)
                option_performance[option.id] = avg_performance
            else:
                # No history - use estimated cost as proxy
                option_performance[option.id] = 1.0 / max(option.estimated_cost, 0.1)
        
        # Select option with best performance
        best_option_id = max(option_performance.keys(), key=lambda k: option_performance[k])
        best_option = next(opt for opt in options if opt.id == best_option_id)
        
        return Decision(
            chosen_option=best_option,
            confidence=0.7,
            reasoning=f"Performance-based selection (avg performance: {option_performance[best_option_id]:.2f})",
            alternatives_considered=options,
            decision_time=time.time(),
            context_used=self._extract_decision_context(context)
        )
    
    async def _random_decision(self, 
                             decision_point: DecisionPoint, 
                             context: AgentContext, 
                             options: List[Option]) -> Decision:
        """Random decision as ultimate fallback."""
        import random
        
        chosen_option = random.choice(options)
        
        return Decision(
            chosen_option=chosen_option,
            confidence=0.3,
            reasoning="Random selection as fallback strategy",
            alternatives_considered=options,
            decision_time=time.time(),
            context_used={}
        )
    
    def _create_decision_prompt(self, 
                              decision_point: DecisionPoint, 
                              context: AgentContext, 
                              options: List[Option]) -> str:
        """Create structured prompt for LLM decision making."""
        
        context_summary = {
            'stage_results': context.stage_results,
            'recent_decisions': context.decisions[-3:],  # Last 3 decisions
            'constraints': context.constraints,
            'performance_metrics': context.performance_metrics
        }
        
        options_summary = [
            {
                'id': opt.id,
                'description': opt.description,
                'cost': opt.estimated_cost,
                'risk': opt.risk_level,
                'outcome': opt.expected_outcome
            }
            for opt in options
        ]
        
        prompt = f"""
        You are an intelligent decision engine. Make the best decision for the following scenario:
        
        Decision Point: {decision_point.description}
        Type: {decision_point.type}
        Constraints: {json.dumps(decision_point.constraints, indent=2)}
        
        Current Context:
        {json.dumps(context_summary, indent=2)}
        
        Available Options:
        {json.dumps(options_summary, indent=2)}
        
        Please respond with a JSON object containing:
        {{
            "chosen_option_id": "option_id",
            "confidence": 0.0-1.0,
            "reasoning": "detailed explanation of why this option was chosen"
        }}
        """
        
        return prompt
    
    def _parse_llm_decision(self, response: Dict[str, Any], options: List[Option]) -> Dict[str, Any]:
        """Parse LLM response into decision data."""
        try:
            content = response.get('content', '{}')
            
            # Extract JSON from response
            import re
            json_match = re.search(r'\{.*\}', content, re.DOTALL)
            if json_match:
                decision_json = json.loads(json_match.group())
            else:
                raise ValueError("No JSON found in LLM response")
            
            # Find chosen option
            chosen_option_id = decision_json.get('chosen_option_id')
            chosen_option = next((opt for opt in options if opt.id == chosen_option_id), options[0])
            
            return {
                'chosen_option': chosen_option,
                'confidence': min(max(decision_json.get('confidence', 0.5), 0.0), 1.0),
                'reasoning': decision_json.get('reasoning', 'LLM decision without detailed reasoning')
            }
            
        except Exception as e:
            # Fallback parsing
            return {
                'chosen_option': options[0],
                'confidence': 0.4,
                'reasoning': f"LLM response parsing failed: {e}"
            }
    
    def _satisfies_constraints(self, option: Option, context: AgentContext) -> bool:
        """Check if option satisfies context constraints."""
        constraints = context.constraints
        
        # Check resource constraints
        if constraints.get('memory_limit', float('inf')) < option.estimated_cost * 10:
            return False
        
        # Check time constraints
        if constraints.get('max_execution_time', float('inf')) < option.estimated_cost:
            return False
        
        # Check LLM availability
        if option.requires_llm and not self.llm_provider:
            return False
        
        return True
    
    def _extract_decision_context(self, context: AgentContext) -> Dict[str, Any]:
        """Extract relevant context for decision tracking."""
        return {
            'stage_count': len(context.stage_results),
            'decision_count': len(context.decisions),
            'has_constraints': bool(context.constraints),
            'performance_indicators': list(context.performance_metrics.keys())
        }
    
    def _generate_cache_key(self, 
                          decision_point: DecisionPoint, 
                          context: AgentContext, 
                          options: List[Option]) -> str:
        """Generate cache key for decision."""
        key_components = [
            decision_point.id,
            decision_point.type,
            str(sorted(opt.id for opt in options)),
            str(sorted(context.constraints.items())),
            str(len(context.stage_results))
        ]
        return str(hash(tuple(key_components)))
    
    def _cache_decision(self, cache_key: str, decision: Decision) -> None:
        """Cache decision with size management."""
        self.decision_cache[cache_key] = decision
        
        # Manage cache size
        if len(self.decision_cache) > self.cache_size:
            # Remove oldest entries (simple FIFO)
            oldest_keys = list(self.decision_cache.keys())[:-self.cache_size//2]
            for key in oldest_keys:
                del self.decision_cache[key]
    
    def _track_decision_performance(self, decision_point_id: str, decision: Decision) -> None:
        """Track decision performance for learning."""
        performance_key = f"{decision_point_id}_{decision.chosen_option.id}"
        
        # Use confidence as performance indicator for now
        # In real implementation, this would be updated based on actual outcomes
        performance_score = decision.confidence
        
        if performance_key not in self.performance_tracking:
            self.performance_tracking[performance_key] = []
        
        self.performance_tracking[performance_key].append(performance_score)
        
        # Keep only recent performance data
        max_history = 100
        if len(self.performance_tracking[performance_key]) > max_history:
            self.performance_tracking[performance_key] = self.performance_tracking[performance_key][-max_history:]