"""
Agentic Framework - A reactive, event-driven system built on Prefect Core.

This framework enables intelligent workflow orchestration through runtime decision-making
and adaptive execution strategies with optional LLM integration and deterministic fallbacks.
"""

from .core.controller import AgenticPipelineController
from .core.context import AgentContext, ContextManager
from .core.events import EventSystem, Event, BaseEventHandler
from .core.decision import DecisionEngine
from .core.data_structures import DecisionPoint, Option, Decision
from .core.protocols import ToolProtocol, LLMProvider, EventHandler
from .core.decorators import timing, retry, memory_managed, cache_result
from .core.logger import get_logger, configure_logging, LogConfig, LogTheme
from .tools.registry import ToolRegistry
from .rollback.controller import RollbackController
from .config.manager import ConfigurationManager, initialize_config, get_framework_config_path
from .observability.tracer import ObservabilityManager, JSONLDTracer
from .observability.performance import PerformanceMonitor

__version__ = "0.1.0"
__author__ = "Agentic Framework Team"

__all__ = [
    # Core components
    "AgenticPipelineController",
    "AgentContext", 
    "ContextManager",
    "EventSystem",
    "Event",
    "BaseEventHandler", 
    "DecisionEngine",
    "DecisionPoint",
    "Option",
    "Decision",
    
    # Protocols
    "ToolProtocol",
    "LLMProvider", 
    "EventHandler",
    
    # Decorators
    "timing",
    "retry", 
    "memory_managed",
    "cache_result",
    
    # Logging
    "get_logger",
    "configure_logging",
    "LogConfig",
    "LogTheme",
    
    # Tools and utilities
    "ToolRegistry",
    "RollbackController",
    
    # Configuration
    "ConfigurationManager",
    "initialize_config",
    "get_framework_config_path",
    
    # Observability
    "ObservabilityManager",
    "JSONLDTracer",
    "PerformanceMonitor"
]