"""Anthropic Claude LLM tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional
from ..base import ToolError
from .base import BaseLLMTool, _handle_unexpected_response_format

logger = logging.getLogger(__name__)


# Pure functions for Anthropic operations
def _create_anthropic_params(model: str, prompt: str, max_tokens: int, 
                           temperature: float, system_prompt: Optional[str] = None, **kwargs) -> Dict[str, Any]:
    """Create API parameters for Anthropic request."""
    params = {
        "model": model,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "messages": [{"role": "user", "content": prompt}]
    }
    
    if system_prompt:
        params["system"] = system_prompt
    
    params.update(kwargs)
    return params


def _extract_anthropic_response(response: Any) -> tuple:
    """Extract content and metadata from Anthropic response."""
    if hasattr(response, 'content'):
        # Real API response
        content = response.content[0].text
        usage = {
            "prompt_tokens": response.usage.input_tokens,
            "completion_tokens": response.usage.output_tokens,
            "total_tokens": response.usage.input_tokens + response.usage.output_tokens
        }
        stop_reason = response.stop_reason
    elif isinstance(response, dict) and 'content' in response:
        # Mock dictionary response
        content = response['content'][0]['text']
        usage = response.get('usage', {})
        stop_reason = response.get('stop_reason')
    else:
        raise _handle_unexpected_response_format(type(response))
    
    return content, usage, stop_reason


async def _process_anthropic_stream(client, params: Dict[str, Any]) -> str:
    """Process streaming response from Anthropic."""
    response_text = ""
    async with client.messages.stream(**params) as stream:
        async for text in stream.text_stream:
            response_text += text
    return response_text


class AnthropicTool(BaseLLMTool):
    """Anthropic Claude tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        # Set default model if not provided
        if not self.model:
            self.model = 'claude-3-sonnet'
        
    async def execute(self, prompt: str, system_prompt: str = None,
                     max_tokens: int = None, temperature: float = None,
                     stream: bool = False, **kwargs):
        """Execute Anthropic API call with functional approach."""
        try:
            # Import Anthropic client
            try:
                from anthropic import AsyncAnthropic
            except ImportError:
                raise ToolError("Anthropic library not installed. Run: pip install anthropic", self.name)
            
            # Initialize client
            client = AsyncAnthropic(api_key=self.api_key)
            
            # Get standardized parameters
            request_max_tokens, request_temperature = self._get_request_params(max_tokens, temperature)
            
            # Prepare request using pure functions
            params = _create_anthropic_params(
                self.model, prompt, request_max_tokens, request_temperature,
                system_prompt, **kwargs
            )
            
            # Make API call
            if stream:
                response_text = await _process_anthropic_stream(client, params)
                return self._create_success_result(response_text, stream=True)
            else:
                response = await client.messages.create(**params)
                content, usage, stop_reason = _extract_anthropic_response(response)
                return self._create_success_result(content, usage, stop_reason)
            
        except Exception as e:
            return self._create_error_result(e, "Anthropic")