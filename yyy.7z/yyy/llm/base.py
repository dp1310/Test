"""Base LLM tool with functional programming principles."""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from ..base import Tool, ToolResult, ToolStatus, ToolError

logger = logging.getLogger(__name__)


# Pure functions for LLM operations
def _validate_llm_config(api_key: str, model: str) -> bool:
    """Validate basic LLM configuration."""
    return bool(api_key and model)


def _create_base_schema(name: str, max_tokens: int, temperature: float) -> Dict[str, Any]:
    """Create base LLM tool schema."""
    return {
        "name": name,
        "description": f"LLM tool for {name}",
        "parameters": {
            "prompt": {
                "type": "string",
                "description": "The prompt to send to the LLM",
                "required": True
            },
            "system_prompt": {
                "type": "string", 
                "description": "System prompt for context",
                "required": False
            },
            "max_tokens": {
                "type": "integer",
                "description": "Maximum tokens to generate",
                "default": max_tokens
            },
            "temperature": {
                "type": "number",
                "description": "Sampling temperature (0-2)",
                "default": temperature
            },
            "stream": {
                "type": "boolean",
                "description": "Whether to stream the response",
                "default": False
            }
        },
        "required": ["prompt"],
        "examples": [
            {
                "prompt": "Explain quantum computing in simple terms",
                "max_tokens": 200,
                "temperature": 0.7
            }
        ]
    }


def _create_common_result_data(content: str, model: str, usage: Dict = None, 
                              finish_reason: str = None, stream: bool = False) -> Dict[str, Any]:
    """Create standardized result data for LLM responses."""
    result_data = {
        "content": content,
        "response": content,  # Keep both for backward compatibility
        "model": model
    }
    
    if stream:
        result_data.update({"stream": True, "streamed": True})
    else:
        result_data.update({
            "usage": usage or {},
            "finish_reason": finish_reason
        })
    
    return result_data


def _extract_content_from_api_chunk(chunk) -> Optional[str]:
    """Extract content from API response chunk (common pattern)."""
    if not (hasattr(chunk, 'choices') and chunk.choices):
        return None
    
    choice = chunk.choices[0]
    if not hasattr(choice, 'delta'):
        return None
    
    delta = choice.delta
    return delta.content if hasattr(delta, 'content') and delta.content else None


def _extract_content_from_dict_chunk(chunk: Dict) -> Optional[str]:
    """Extract content from dictionary chunk (common pattern)."""
    choices = chunk.get('choices', [])
    if not choices:
        return None
    
    delta = choices[0].get('delta', {})
    return delta.get('content') if delta.get('content') else None


def _extract_chunk_content(chunk) -> Optional[str]:
    """Extract content from streaming chunk using dispatch pattern."""
    if hasattr(chunk, 'choices'):
        return _extract_content_from_api_chunk(chunk)
    elif isinstance(chunk, dict):
        return _extract_content_from_dict_chunk(chunk)
    return None


def _extract_common_response(response: Any) -> tuple:
    """Extract content and metadata from common LLM response format (OpenAI/Mistral style)."""
    if hasattr(response, 'choices'):
        # Real API response
        content = response.choices[0].message.content
        usage = {
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens
        }
        finish_reason = response.choices[0].finish_reason
    elif isinstance(response, dict) and 'choices' in response:
        # Mock dictionary response
        content = response['choices'][0]['message']['content']
        usage = response.get('usage', {})
        finish_reason = response['choices'][0].get('finish_reason')
    else:
        raise _handle_unexpected_response_format(type(response))
    
    return content, usage, finish_reason


def _handle_unexpected_response_format(response_type: type) -> ValueError:
    """Create standardized error for unexpected response formats."""
    return ValueError(f"Unexpected response format: {response_type}")


def _handle_llm_error(error: Exception, tool_name: str, provider: str) -> ToolResult:
    """Create standardized error result for LLM tools."""
    error_msg = f"{provider} API error: {error}"
    logger.error(error_msg)
    return ToolResult(
        tool_name=tool_name,
        status=ToolStatus.ERROR,
        error=ToolError(error_msg, tool_name, error)
    )


class BaseLLMTool(Tool, ABC):
    """Base class for LLM tools with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.api_key = config.get('api_key')
        self.model = config.get('model')
        self.max_tokens = config.get('max_tokens', 1000)
        self.temperature = config.get('temperature', 0.7)
        self.top_p = config.get('top_p', 1.0)
        
    def validate_config(self) -> bool:
        """Validate LLM configuration using pure function."""
        if not _validate_llm_config(self.api_key, self.model):
            logger.error(f"Invalid configuration for {self.name}: missing API key or model")
            return False
        return True
    
    def get_schema(self) -> Dict[str, Any]:
        """Get LLM tool schema using pure function."""
        return _create_base_schema(self.name, self.max_tokens, self.temperature)
    
    def _get_request_params(self, max_tokens: Optional[int], temperature: Optional[float]) -> tuple:
        """Get standardized request parameters."""
        return (
            max_tokens or self.max_tokens,
            temperature if temperature is not None else self.temperature
        )
    
    def _create_success_result(self, content: str, usage: Dict = None, 
                              finish_reason: str = None, stream: bool = False) -> ToolResult:
        """Create standardized success result."""
        result_data = _create_common_result_data(content, self.model, usage, finish_reason, stream)
        return ToolResult(
            tool_name=self.name,
            status=ToolStatus.SUCCESS,
            data=result_data
        )
    
    def _create_error_result(self, error: Exception, provider: str) -> ToolResult:
        """Create standardized error result."""
        return _handle_llm_error(error, self.name, provider)
    
    @abstractmethod
    async def execute(self, **kwargs):
        """Execute the LLM tool."""
        pass