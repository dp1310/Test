"""
Load testing scenarios using Locust.

Simulates realistic user behavior for performance testing.
"""

from locust import HttpUser, task, between
import json
import random


class CMPUser(HttpUser):
    """Simulated CMP Framework user."""
    
    wait_time = between(1, 3)  # Wait 1-3 seconds between tasks
    
    def on_start(self):
        """Called when user starts."""
        # Authenticate (if auth is enabled)
        # For now, we'll skip auth or use a test token
        self.tenant_id = f"tenant-{random.randint(1, 10)}"
        self.context_ids = []
    
    @task(3)
    def create_context(self):
        """Create a new context."""
        data = {
            "data": {
                "user_id": f"user-{random.randint(1, 1000)}",
                "action": random.choice(["login", "purchase", "view", "search"]),
                "timestamp": "2024-01-01T00:00:00Z"
            },
            "schema": "user_event"
        }
        
        response = self.client.post(
            "/api/v1/contexts",
            json=data,
            headers={"X-Tenant-ID": self.tenant_id}
        )
        
        if response.status_code == 201:
            context_id = response.json().get("id")
            if context_id:
                self.context_ids.append(context_id)
    
    @task(5)
    def get_context(self):
        """Get an existing context."""
        if not self.context_ids:
            return
        
        context_id = random.choice(self.context_ids)
        self.client.get(
            f"/api/v1/contexts/{context_id}",
            headers={"X-Tenant-ID": self.tenant_id}
        )
    
    @task(2)
    def list_contexts(self):
        """List contexts."""
        self.client.get(
            "/api/v1/contexts",
            params={"limit": 10},
            headers={"X-Tenant-ID": self.tenant_id}
        )
    
    @task(1)
    def update_context(self):
        """Update a context."""
        if not self.context_ids:
            return
        
        context_id = random.choice(self.context_ids)
        data = {
            "data": {
                "updated": True,
                "update_count": random.randint(1, 10)
            }
        }
        
        self.client.put(
            f"/api/v1/contexts/{context_id}",
            json=data,
            headers={"X-Tenant-ID": self.tenant_id}
        )
    
    @task(1)
    def health_check(self):
        """Check health endpoint."""
        self.client.get("/health/ready")


class HighLoadUser(HttpUser):
    """High-load stress testing user."""
    
    wait_time = between(0.1, 0.5)  # Minimal wait time
    
    @task
    def rapid_context_creation(self):
        """Rapidly create contexts."""
        data = {
            "data": {"test": "data", "value": random.randint(1, 1000)},
            "schema": "test_schema"
        }
        
        self.client.post("/api/v1/contexts", json=data)
