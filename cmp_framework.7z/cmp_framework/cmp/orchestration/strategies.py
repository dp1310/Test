"""
Orchestration strategies using Strategy pattern.
"""

from abc import ABC, abstractmethod
from typing import AsyncIterator, Any
import asyncio

from cmp.core.models import Context


class Agent(ABC):
    """Base agent interface"""
    
    def __init__(self, agent_id: str):
        """
        Initialize agent.
        
        Args:
            agent_id: Unique identifier for the agent
        """
        self.agent_id = agent_id
    
    @abstractmethod
    async def process(self, context: Context) -> Context:
        """Process context and return new context"""
        pass


class OrchestrationStrategy(ABC):
    """Abstract strategy for orchestration patterns"""
    
    @abstractmethod
    async def execute(
        self,
        context: Context,
        agents: list[Agent],
        policy: dict[str, Any]
    ) -> AsyncIterator[Context]:
        """
        Execute orchestration strategy.
        
        Args:
            context: Initial context
            agents: List of agents to execute
            policy: Policy configuration
            
        Yields:
            Context after each step
        """
        pass


class ChainingStrategy(OrchestrationStrategy):
    """Sequential context chaining strategy"""
    
    async def execute(
        self,
        context: Context,
        agents: list[Agent],
        policy: dict[str, Any]
    ) -> AsyncIterator[Context]:
        """
        Execute agents sequentially, passing context between them.
        
        Each agent's output becomes the next agent's input.
        """
        current_context = context
        
        for i, agent in enumerate(agents):
            # Process with agent
            current_context = await agent.process(current_context)
            
            # Yield intermediate result
            yield current_context
            
            # Check max steps from policy
            max_steps = policy.get("max_steps", 100)
            if i + 1 >= max_steps:
                break


class FanOutFanInStrategy(OrchestrationStrategy):
    """Parallel processing with aggregation strategy"""
    
    async def execute(
        self,
        context: Context,
        agents: list[Agent],
        policy: dict[str, Any]
    ) -> AsyncIterator[Context]:
        """
        Execute agents in parallel and aggregate results.
        
        All agents process the same input context concurrently,
        then results are aggregated.
        """
        # Fan-out: Execute all agents in parallel
        tasks = [agent.process(context) for agent in agents]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out exceptions
        valid_results = [r for r in results if isinstance(r, Context)]
        
        if not valid_results:
            # If all failed, return original context
            yield context
            return
        
        # Fan-in: Aggregate results
        aggregated_data = {}
        for i, result_context in enumerate(valid_results):
            # Merge data from all contexts
            aggregated_data.update(result_context.data)
        
        # Create aggregated context
        aggregated_context = context.with_data(**aggregated_data)
        yield aggregated_context


class EvolutionStrategy(OrchestrationStrategy):
    """Progressive context evolution strategy"""
    
    async def execute(
        self,
        context: Context,
        agents: list[Agent],
        policy: dict[str, Any]
    ) -> AsyncIterator[Context]:
        """
        Progressively enrich context through multiple passes.
        
        Each agent adds to the context without replacing previous data.
        """
        evolved_context = context
        
        for agent in agents:
            # Process and merge results
            result_context = await agent.process(evolved_context)
            
            # Merge new data with existing (evolution)
            merged_data = {**evolved_context.data, **result_context.data}
            evolved_context = evolved_context.with_data(**merged_data)
            
            # Yield evolved state
            yield evolved_context
