"""
Conditional workflow pattern.

Enables if/else logic in workflow execution based on context data.
"""

from typing import Callable, Any, Optional
from cmp.core.models import Context
from cmp.sdk.agent import Agent


class ConditionalWorkflow:
    """
    Conditional workflow with if/else branching.
    
    Example:
        >>> workflow = ConditionalWorkflow()
        >>> workflow.when(lambda ctx: ctx.data["amount"] > 1000) \\
        ...     .then(high_value_agent) \\
        ...     .otherwise(standard_agent)
        >>> 
        >>> result = await workflow.execute(context)
    """
    
    def __init__(self):
        """Initialize conditional workflow."""
        self._condition: Optional[Callable[[Context], bool]] = None
        self._then_agent: Optional[Agent] = None
        self._else_agent: Optional[Agent] = None
    
    def when(self, condition: Callable[[Context], bool]) -> "ConditionalWorkflow":
        """
        Set condition for branching.
        
        Args:
            condition: Function that takes Context and returns bool
            
        Returns:
            Self for chaining
        """
        self._condition = condition
        return self
    
    def then(self, agent: Agent) -> "ConditionalWorkflow":
        """
        Set agent to execute if condition is True.
        
        Args:
            agent: Agent to execute
            
        Returns:
            Self for chaining
        """
        self._then_agent = agent
        return self
    
    def otherwise(self, agent: Agent) -> "ConditionalWorkflow":
        """
        Set agent to execute if condition is False.
        
        Args:
            agent: Agent to execute
            
        Returns:
            Self for chaining
        """
        self._else_agent = agent
        return self
    
    async def execute(self, context: Context) -> Context:
        """
        Execute conditional workflow.
        
        Args:
            context: Input context
            
        Returns:
            Result context from executed branch
        """
        if not self._condition:
            raise ValueError("Condition not set. Use .when() to set condition.")
        
        if not self._then_agent:
            raise ValueError("Then agent not set. Use .then() to set agent.")
        
        # Evaluate condition
        should_execute_then = self._condition(context)
        
        if should_execute_then:
            # Execute then branch
            return await self._then_agent.process(context)
        elif self._else_agent:
            # Execute else branch
            return await self._else_agent.process(context)
        else:
            # No else branch, return original context
            return context


class SwitchWorkflow:
    """
    Switch/case workflow pattern.
    
    Example:
        >>> workflow = SwitchWorkflow(lambda ctx: ctx.data["type"])
        >>> workflow.case("A", agent_a) \\
        ...     .case("B", agent_b) \\
        ...     .default(default_agent)
        >>> 
        >>> result = await workflow.execute(context)
    """
    
    def __init__(self, selector: Callable[[Context], Any]):
        """
        Initialize switch workflow.
        
        Args:
            selector: Function to extract value for switching
        """
        self._selector = selector
        self._cases: dict[Any, Agent] = {}
        self._default: Optional[Agent] = None
    
    def case(self, value: Any, agent: Agent) -> "SwitchWorkflow":
        """
        Add a case branch.
        
        Args:
            value: Value to match
            agent: Agent to execute for this case
            
        Returns:
            Self for chaining
        """
        self._cases[value] = agent
        return self
    
    def default(self, agent: Agent) -> "SwitchWorkflow":
        """
        Set default agent for unmatched cases.
        
        Args:
            agent: Default agent
            
        Returns:
            Self for chaining
        """
        self._default = agent
        return self
    
    async def execute(self, context: Context) -> Context:
        """
        Execute switch workflow.
        
        Args:
            context: Input context
            
        Returns:
            Result context from matched case
        """
        # Get switch value
        value = self._selector(context)
        
        # Find matching case
        if value in self._cases:
            agent = self._cases[value]
            return await agent.process(context)
        elif self._default:
            return await self._default.process(context)
        else:
            # No match and no default
            return context
