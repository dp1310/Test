"""
Retry pattern with exponential backoff and circuit breaker.
"""

import asyncio
from typing import Callable, Optional
from datetime import datetime, timedelta, timezone
from enum import Enum
from cmp.core.models import Context


class CircuitState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if recovered


class RetryPolicy:
    """
    Retry policy with exponential backoff.
    
    Example:
        >>> policy = RetryPolicy(max_attempts=3, base_delay=1.0, max_delay=10.0)
        >>> result = await policy.execute(risky_function, context)
    """
    
    def __init__(
        self,
        max_attempts: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0
    ):
        """
        Initialize retry policy.
        
        Args:
            max_attempts: Maximum retry attempts
            base_delay: Initial delay in seconds
            max_delay: Maximum delay in seconds
            exponential_base: Base for exponential backoff
        """
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
    
    async def execute(
        self,
        func: Callable[[Context], Context],
        context: Context
    ) -> Context:
        """
        Execute function with retry logic.
        
        Args:
            func: Function to execute
            context: Input context
            
        Returns:
            Result context
            
        Raises:
            Exception: If all retries exhausted
        """
        last_exception = None
        
        for attempt in range(self.max_attempts):
            try:
                return await func(context)
            except Exception as e:
                last_exception = e
                
                if attempt < self.max_attempts - 1:
                    # Calculate delay with exponential backoff
                    delay = min(
                        self.base_delay * (self.exponential_base ** attempt),
                        self.max_delay
                    )
                    
                    print(f"Attempt {attempt + 1} failed: {e}. Retrying in {delay}s...")
                    await asyncio.sleep(delay)
        
        # All retries exhausted
        raise last_exception


class CircuitBreaker:
    """
    Circuit breaker pattern to prevent cascading failures.
    
    Example:
        >>> breaker = CircuitBreaker(failure_threshold=5, timeout=60.0)
        >>> result = await breaker.call(unreliable_service, context)
    """
    
    def __init__(
        self,
        failure_threshold: int = 5,
        timeout: float = 60.0,
        half_open_attempts: int = 1
    ):
        """
        Initialize circuit breaker.
        
        Args:
            failure_threshold: Failures before opening circuit
            timeout: Seconds before attempting recovery
            half_open_attempts: Attempts in half-open state
        """
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.half_open_attempts = half_open_attempts
        
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.half_open_successes = 0
    
    async def call(
        self,
        func: Callable[[Context], Context],
        context: Context
    ) -> Context:
        """
        Execute function through circuit breaker.
        
        Args:
            func: Function to execute
            context: Input context
            
        Returns:
            Result context
            
        Raises:
            Exception: If circuit is open or function fails
        """
        # Check if we should transition from OPEN to HALF_OPEN
        if self.state == CircuitState.OPEN:
            if self._should_attempt_reset():
                self.state = CircuitState.HALF_OPEN
                self.half_open_successes = 0
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = await func(context)
            self._on_success()
            return result
        
        except Exception as e:
            self._on_failure()
            raise e
    
    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset."""
        if self.last_failure_time is None:
            return False
        
        elapsed = (datetime.now(timezone.utc) - self.last_failure_time).total_seconds()
        return elapsed >= self.timeout
    
    def _on_success(self):
        """Handle successful call."""
        if self.state == CircuitState.HALF_OPEN:
            self.half_open_successes += 1
            if self.half_open_successes >= self.half_open_attempts:
                # Recovered, close circuit
                self.state = CircuitState.CLOSED
                self.failure_count = 0
        elif self.state == CircuitState.CLOSED:
            # Reset failure count on success
            self.failure_count = 0
    
    def _on_failure(self):
        """Handle failed call."""
        self.failure_count += 1
        self.last_failure_time = datetime.now(timezone.utc)
        
        if self.state == CircuitState.HALF_OPEN:
            # Failed during recovery, reopen circuit
            self.state = CircuitState.OPEN
        elif self.failure_count >= self.failure_threshold:
            # Too many failures, open circuit
            self.state = CircuitState.OPEN


class RetryWithCircuitBreaker:
    """
    Combined retry policy with circuit breaker.
    
    Example:
        >>> policy = RetryWithCircuitBreaker(
        ...     max_attempts=3,
        ...     failure_threshold=5
        ... )
        >>> result = await policy.execute(func, context)
    """
    
    def __init__(
        self,
        max_attempts: int = 3,
        base_delay: float = 1.0,
        failure_threshold: int = 5,
        circuit_timeout: float = 60.0
    ):
        """Initialize combined policy."""
        self.retry = RetryPolicy(max_attempts=max_attempts, base_delay=base_delay)
        self.circuit_breaker = CircuitBreaker(
            failure_threshold=failure_threshold,
            timeout=circuit_timeout
        )
    
    async def execute(
        self,
        func: Callable[[Context], Context],
        context: Context
    ) -> Context:
        """Execute with retry and circuit breaker."""
        return await self.retry.execute(
            lambda ctx: self.circuit_breaker.call(func, ctx),
            context
        )
