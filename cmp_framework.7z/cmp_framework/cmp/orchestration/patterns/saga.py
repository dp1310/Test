"""
Saga pattern for distributed transactions with compensation.

Implements the Saga pattern for managing distributed transactions
with automatic rollback via compensation actions.
"""

from typing import Callable, Any, Optional, List
from dataclasses import dataclass
from cmp.core.models import Context
from cmp.core.result import Result, Ok, Err


@dataclass
class SagaStep:
    """A step in a saga with action and compensation."""
    
    name: str
    action: Callable[[Context], Context]
    compensate: Optional[Callable[[Context], Context]] = None


class SagaWorkflow:
    """
    Saga pattern implementation for distributed transactions.
    
    Features:
    - Sequential step execution
    - Automatic compensation on failure
    - Rollback in reverse order
    
    Example:
        >>> saga = SagaWorkflow()
        >>> saga.step(reserve_inventory, compensate=release_inventory) \\
        ...     .step(charge_payment, compensate=refund_payment) \\
        ...     .step(ship_order, compensate=cancel_shipment)
        >>> 
        >>> result = await saga.execute(context)
        >>> if result.is_err():
        ...     print("Transaction failed and rolled back")
    """
    
    def __init__(self):
        """Initialize saga workflow."""
        self._steps: List[SagaStep] = []
    
    def step(
        self,
        action: Callable[[Context], Context],
        compensate: Optional[Callable[[Context], Context]] = None,
        name: Optional[str] = None
    ) -> "SagaWorkflow":
        """
        Add a step to the saga.
        
        Args:
            action: Forward action to execute
            compensate: Compensation action for rollback
            name: Optional step name
            
        Returns:
            Self for chaining
        """
        step_name = name or f"step_{len(self._steps) + 1}"
        self._steps.append(SagaStep(
            name=step_name,
            action=action,
            compensate=compensate
        ))
        return self
    
    async def execute(self, context: Context) -> Result[Context, str]:
        """
        Execute saga workflow.
        
        Args:
            context: Input context
            
        Returns:
            Result with final context or error message
        """
        executed_steps: List[SagaStep] = []
        current_context = context
        
        try:
            # Execute steps forward
            for step in self._steps:
                try:
                    current_context = await step.action(current_context)
                    executed_steps.append(step)
                except Exception as e:
                    # Step failed, trigger compensation
                    await self._compensate(executed_steps, current_context)
                    return Err(f"Saga failed at step '{step.name}': {str(e)}")
            
            # All steps succeeded
            return Ok(current_context)
        
        except Exception as e:
            # Unexpected error, compensate
            await self._compensate(executed_steps, current_context)
            return Err(f"Saga failed with unexpected error: {str(e)}")
    
    async def _compensate(self, executed_steps: List[SagaStep], context: Context):
        """
        Execute compensation actions in reverse order.
        
        Args:
            executed_steps: Steps that were successfully executed
            context: Current context
        """
        # Compensate in reverse order
        for step in reversed(executed_steps):
            if step.compensate:
                try:
                    context = await step.compensate(context)
                except Exception as e:
                    # Log compensation failure but continue
                    print(f"Compensation failed for step '{step.name}': {e}")


class TwoPhaseCommit:
    """
    Two-phase commit pattern.
    
    Simpler than Saga - all steps must prepare before any commit.
    """
    
    def __init__(self):
        """Initialize two-phase commit."""
        self._steps: List[dict] = []
    
    def add_participant(
        self,
        prepare: Callable[[Context], bool],
        commit: Callable[[Context], Context],
        abort: Callable[[Context], None],
        name: Optional[str] = None
    ) -> "TwoPhaseCommit":
        """
        Add a participant to the transaction.
        
        Args:
            prepare: Prepare phase (returns True if ready)
            commit: Commit phase
            abort: Abort phase
            name: Optional participant name
            
        Returns:
            Self for chaining
        """
        self._steps.append({
            "name": name or f"participant_{len(self._steps) + 1}",
            "prepare": prepare,
            "commit": commit,
            "abort": abort
        })
        return self
    
    async def execute(self, context: Context) -> Result[Context, str]:
        """
        Execute two-phase commit.
        
        Args:
            context: Input context
            
        Returns:
            Result with final context or error
        """
        # Phase 1: Prepare
        for step in self._steps:
            try:
                can_commit = await step["prepare"](context)
                if not can_commit:
                    # Abort all
                    await self._abort_all(context)
                    return Err(f"Participant '{step['name']}' failed to prepare")
            except Exception as e:
                await self._abort_all(context)
                return Err(f"Prepare failed for '{step['name']}': {str(e)}")
        
        # Phase 2: Commit
        current_context = context
        try:
            for step in self._steps:
                current_context = await step["commit"](current_context)
            
            return Ok(current_context)
        
        except Exception as e:
            # Commit failed - this is problematic in 2PC
            return Err(f"Commit failed: {str(e)}")
    
    async def _abort_all(self, context: Context):
        """Abort all participants."""
        for step in self._steps:
            try:
                await step["abort"](context)
            except Exception as e:
                print(f"Abort failed for '{step['name']}': {e}")
