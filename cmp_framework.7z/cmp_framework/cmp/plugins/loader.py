"""
Plugin loader and discovery.
"""

import importlib
import inspect
from pathlib import Path
from typing import List, Type, Optional
from .base import Plugin


class PluginLoader:
    """
    Plugin loader with discovery and dynamic loading.
    
    Example:
        >>> loader = PluginLoader()
        >>> plugins = await loader.discover_plugins("./plugins")
        >>> plugin = await loader.load_plugin("custom-storage")
    """
    
    def __init__(self):
        """Initialize plugin loader."""
        self._discovered_plugins: dict[str, Type[Plugin]] = {}
    
    async def discover_plugins(self, plugin_dir: str) -> List[str]:
        """
        Discover plugins in directory.
        
        Args:
            plugin_dir: Directory to search for plugins
            
        Returns:
            List of discovered plugin names
        """
        plugin_path = Path(plugin_dir)
        if not plugin_path.exists():
            return []
        
        discovered = []
        
        # Scan Python files
        for file_path in plugin_path.glob("*.py"):
            if file_path.name.startswith("_"):
                continue
            
            try:
                # Import module
                module_name = file_path.stem
                spec = importlib.util.spec_from_file_location(module_name, file_path)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    # Find Plugin subclasses
                    for name, obj in inspect.getmembers(module):
                        if (inspect.isclass(obj) and 
                            issubclass(obj, Plugin) and 
                            obj is not Plugin):
                            plugin_name = obj.name
                            self._discovered_plugins[plugin_name] = obj
                            discovered.append(plugin_name)
            
            except Exception as e:
                print(f"Failed to load plugin from {file_path}: {e}")
        
        return discovered
    
    async def load_plugin(self, plugin_name: str) -> Optional[Plugin]:
        """
        Load a plugin by name.
        
        Args:
            plugin_name: Name of plugin to load
            
        Returns:
            Plugin instance or None if not found
        """
        if plugin_name not in self._discovered_plugins:
            return None
        
        plugin_class = self._discovered_plugins[plugin_name]
        plugin = plugin_class()
        
        # Initialize plugin
        plugin.on_init()
        
        return plugin
    
    def list_discovered(self) -> List[str]:
        """List all discovered plugins."""
        return list(self._discovered_plugins.keys())
