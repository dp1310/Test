"""
Plugin base class and lifecycle management.
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class PluginMetadata:
    """Plugin metadata."""
    
    name: str
    version: str
    description: str
    author: str
    dependencies: list[str]


class Plugin(ABC):
    """
    Base class for CMP Framework plugins.
    
    Plugins can extend the framework with custom functionality.
    
    Example:
        >>> class CustomStoragePlugin(Plugin):
        ...     name = "custom-storage"
        ...     version = "1.0.0"
        ...     
        ...     def on_init(self):
        ...         print("Plugin initialized")
        ...     
        ...     def on_start(self):
        ...         print("Plugin started")
        ...     
        ...     @hook("context.before_create")
        ...     async def validate_context(self, context):
        ...         # Custom validation
        ...         pass
    """
    
    # Plugin metadata (override in subclass)
    name: str = "unnamed-plugin"
    version: str = "0.1.0"
    description: str = ""
    author: str = ""
    dependencies: list[str] = []
    
    def __init__(self):
        """Initialize plugin."""
        self._enabled = False
        self._config: Dict[str, Any] = {}
    
    @abstractmethod
    def on_init(self):
        """
        Called when plugin is initialized.
        
        Use this to set up plugin state.
        """
        pass
    
    def on_start(self):
        """
        Called when plugin is started.
        
        Use this to start plugin services.
        """
        pass
    
    def on_stop(self):
        """
        Called when plugin is stopped.
        
        Use this to clean up resources.
        """
        pass
    
    def configure(self, config: Dict[str, Any]):
        """
        Configure plugin.
        
        Args:
            config: Configuration dictionary
        """
        self._config = config
    
    def get_metadata(self) -> PluginMetadata:
        """Get plugin metadata."""
        return PluginMetadata(
            name=self.name,
            version=self.version,
            description=self.description,
            author=self.author,
            dependencies=self.dependencies
        )
    
    @property
    def enabled(self) -> bool:
        """Check if plugin is enabled."""
        return self._enabled
    
    def enable(self):
        """Enable plugin."""
        self._enabled = True
    
    def disable(self):
        """Disable plugin."""
        self._enabled = False


def hook(event_name: str):
    """
    Decorator to mark a method as a hook.
    
    Args:
        event_name: Name of the event to hook into
        
    Example:
        >>> @hook("context.before_create")
        >>> async def validate_context(self, context):
        ...     # Validation logic
        ...     pass
    """
    def decorator(func):
        func._hook_event = event_name
        return func
    return decorator
