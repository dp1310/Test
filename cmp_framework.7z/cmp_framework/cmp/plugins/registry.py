"""
Plugin registry and management.
"""

from typing import Dict, List, Optional
from .base import Plugin
from .loader import PluginLoader


class PluginRegistry:
    """
    Central registry for managing plugins.
    
    Example:
        >>> registry = PluginRegistry()
        >>> await registry.discover("./plugins")
        >>> await registry.load_all()
        >>> await registry.start_all()
    """
    
    def __init__(self):
        """Initialize plugin registry."""
        self._loader = PluginLoader()
        self._plugins: Dict[str, Plugin] = {}
        self._hooks: Dict[str, List[callable]] = {}
    
    async def discover(self, plugin_dir: str) -> List[str]:
        """
        Discover plugins in directory.
        
        Args:
            plugin_dir: Directory to search
            
        Returns:
            List of discovered plugin names
        """
        return await self._loader.discover_plugins(plugin_dir)
    
    async def load(self, plugin_name: str) -> bool:
        """
        Load a specific plugin.
        
        Args:
            plugin_name: Name of plugin to load
            
        Returns:
            True if loaded successfully
        """
        plugin = await self._loader.load_plugin(plugin_name)
        if plugin:
            self._plugins[plugin_name] = plugin
            self._register_hooks(plugin)
            return True
        return False
    
    async def load_all(self) -> int:
        """
        Load all discovered plugins.
        
        Returns:
            Number of plugins loaded
        """
        discovered = self._loader.list_discovered()
        loaded = 0
        
        for plugin_name in discovered:
            if await self.load(plugin_name):
                loaded += 1
        
        return loaded
    
    async def start(self, plugin_name: str):
        """Start a specific plugin."""
        if plugin_name in self._plugins:
            plugin = self._plugins[plugin_name]
            plugin.on_start()
            plugin.enable()
    
    async def start_all(self):
        """Start all loaded plugins."""
        for plugin_name in self._plugins:
            await self.start(plugin_name)
    
    async def stop(self, plugin_name: str):
        """Stop a specific plugin."""
        if plugin_name in self._plugins:
            plugin = self._plugins[plugin_name]
            plugin.on_stop()
            plugin.disable()
    
    async def stop_all(self):
        """Stop all plugins."""
        for plugin_name in self._plugins:
            await self.stop(plugin_name)
    
    def get_plugin(self, plugin_name: str) -> Optional[Plugin]:
        """Get a plugin by name."""
        return self._plugins.get(plugin_name)
    
    def list_plugins(self) -> List[str]:
        """List all loaded plugins."""
        return list(self._plugins.keys())
    
    def _register_hooks(self, plugin: Plugin):
        """Register plugin hooks."""
        import inspect
        
        # Find methods with _hook_event attribute
        for name, method in inspect.getmembers(plugin, predicate=inspect.ismethod):
            if hasattr(method, '_hook_event'):
                event_name = method._hook_event
                if event_name not in self._hooks:
                    self._hooks[event_name] = []
                self._hooks[event_name].append(method)
    
    async def trigger_hook(self, event_name: str, *args, **kwargs):
        """
        Trigger all hooks for an event.
        
        Args:
            event_name: Name of event
            *args: Positional arguments for hooks
            **kwargs: Keyword arguments for hooks
        """
        if event_name in self._hooks:
            for hook in self._hooks[event_name]:
                try:
                    await hook(*args, **kwargs)
                except Exception as e:
                    print(f"Hook {hook.__name__} failed: {e}")


# Global plugin registry
_registry: Optional[PluginRegistry] = None


def get_plugin_registry() -> PluginRegistry:
    """Get global plugin registry."""
    global _registry
    if _registry is None:
        _registry = PluginRegistry()
    return _registry
