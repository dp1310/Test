"""Plugin system for CMP Framework."""

from .base import Plugin, PluginMetadata, hook
from .loader import PluginLoader
from .registry import PluginRegistry, get_plugin_registry

__all__ = [
    "Plugin",
    "PluginMetadata",
    "hook",
    "PluginLoader",
    "PluginRegistry",
    "get_plugin_registry",
]
