"""
Structured logging for CMP Framework.

Provides JSON-formatted logging with context propagation and sensitive data masking.
"""

import logging
import sys
from typing import Any, Optional
from contextvars import ContextVar
from datetime import datetime
import json
from enum import Enum

# Context variables for request/workflow tracking
context_id_var: ContextVar[Optional[str]] = ContextVar("context_id", default=None)
workflow_id_var: ContextVar[Optional[str]] = ContextVar("workflow_id", default=None)
tenant_id_var: ContextVar[Optional[str]] = ContextVar("tenant_id", default=None)
request_id_var: ContextVar[Optional[str]] = ContextVar("request_id", default=None)


class LogLevel(str, Enum):
    """Log levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class SensitiveDataMasker:
    """Mask sensitive data in log messages."""
    
    SENSITIVE_KEYS = {
        "password", "secret", "token", "api_key", "apikey",
        "authorization", "auth", "jwt", "private_key", "privatekey"
    }
    
    @classmethod
    def mask_dict(cls, data: dict[str, Any]) -> dict[str, Any]:
        """Recursively mask sensitive keys in dictionary."""
        masked = {}
        for key, value in data.items():
            key_lower = key.lower()
            
            # Check if key is sensitive
            if any(sensitive in key_lower for sensitive in cls.SENSITIVE_KEYS):
                masked[key] = "***MASKED***"
            elif isinstance(value, dict):
                masked[key] = cls.mask_dict(value)
            elif isinstance(value, list):
                masked[key] = [
                    cls.mask_dict(item) if isinstance(item, dict) else item
                    for item in value
                ]
            else:
                masked[key] = value
        
        return masked


class JSONFormatter(logging.Formatter):
    """JSON log formatter with context propagation."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        # Base log entry
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        
        # Add context variables if present
        context_id = context_id_var.get()
        if context_id:
            log_entry["context_id"] = context_id
        
        workflow_id = workflow_id_var.get()
        if workflow_id:
            log_entry["workflow_id"] = workflow_id
        
        tenant_id = tenant_id_var.get()
        if tenant_id:
            log_entry["tenant_id"] = tenant_id
        
        request_id = request_id_var.get()
        if request_id:
            log_entry["request_id"] = request_id
        
        # Add extra fields from record
        if hasattr(record, "extra"):
            extra = record.extra
            if isinstance(extra, dict):
                # Mask sensitive data
                extra = SensitiveDataMasker.mask_dict(extra)
                log_entry["extra"] = extra
        
        # Add exception info if present
        if record.exc_info:
            log_entry["exception"] = {
                "type": record.exc_info[0].__name__ if record.exc_info[0] else None,
                "message": str(record.exc_info[1]) if record.exc_info[1] else None,
                "traceback": self.formatException(record.exc_info)
            }
        
        # Add source location
        log_entry["source"] = {
            "file": record.pathname,
            "line": record.lineno,
            "function": record.funcName
        }
        
        return json.dumps(log_entry)


class TextFormatter(logging.Formatter):
    """Human-readable text formatter with colors (for development)."""
    
    COLORS = {
        "DEBUG": "\033[36m",      # Cyan
        "INFO": "\033[32m",       # Green
        "WARNING": "\033[33m",    # Yellow
        "ERROR": "\033[31m",      # Red
        "CRITICAL": "\033[35m",   # Magenta
        "RESET": "\033[0m"
    }
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as colored text."""
        color = self.COLORS.get(record.levelname, self.COLORS["RESET"])
        reset = self.COLORS["RESET"]
        
        # Build context string
        context_parts = []
        
        context_id = context_id_var.get()
        if context_id:
            context_parts.append(f"ctx={context_id[:8]}")
        
        workflow_id = workflow_id_var.get()
        if workflow_id:
            context_parts.append(f"wf={workflow_id[:8]}")
        
        tenant_id = tenant_id_var.get()
        if tenant_id:
            context_parts.append(f"tenant={tenant_id}")
        
        context_str = f"[{' '.join(context_parts)}] " if context_parts else ""
        
        # Format message
        timestamp = datetime.utcnow().strftime("%H:%M:%S.%f")[:-3]
        message = f"{color}{timestamp}{reset} {color}{record.levelname:8}{reset} {context_str}{record.name}: {record.getMessage()}"
        
        # Add exception if present
        if record.exc_info:
            message += f"\n{self.formatException(record.exc_info)}"
        
        return message


class StructuredLogger:
    """
    Structured logger with context propagation.
    
    Example:
        >>> logger = get_logger(__name__)
        >>> logger.info("User logged in", user_id="123", action="login")
        >>> 
        >>> # With context
        >>> set_context(context_id="ctx-123", tenant_id="acme")
        >>> logger.info("Processing context")
        >>> clear_context()
    """
    
    def __init__(self, name: str, logger: logging.Logger):
        """Initialize structured logger."""
        self.name = name
        self._logger = logger
    
    def _log(self, level: int, message: str, **kwargs):
        """Internal log method with extra fields."""
        # Create a log record with extra fields
        extra_dict = kwargs
        
        # Use LogRecord's extra mechanism
        self._logger.log(level, message, extra={"extra": extra_dict})
    
    def debug(self, message: str, **kwargs):
        """Log debug message."""
        self._log(logging.DEBUG, message, **kwargs)
    
    def info(self, message: str, **kwargs):
        """Log info message."""
        self._log(logging.INFO, message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        """Log warning message."""
        self._log(logging.WARNING, message, **kwargs)
    
    def error(self, message: str, **kwargs):
        """Log error message."""
        self._log(logging.ERROR, message, **kwargs)
    
    def critical(self, message: str, **kwargs):
        """Log critical message."""
        self._log(logging.CRITICAL, message, **kwargs)
    
    def exception(self, message: str, **kwargs):
        """Log exception with traceback."""
        self._logger.exception(message, extra={"extra": kwargs})


# Global logger configuration
_configured = False


def configure_logging(
    level: str = "INFO",
    format_type: str = "json",
    output_file: Optional[str] = None
):
    """
    Configure global logging settings.
    
    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format_type: Format type ("json" or "text")
        output_file: Optional file path for log output
        
    Example:
        >>> configure_logging(level="DEBUG", format_type="text")
        >>> configure_logging(level="INFO", format_type="json", output_file="app.log")
    """
    global _configured
    
    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper()))
    
    # Remove existing handlers
    root_logger.handlers.clear()
    
    # Create formatter
    if format_type == "json":
        formatter = JSONFormatter()
    else:
        formatter = TextFormatter()
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # File handler if specified
    if output_file:
        file_handler = logging.FileHandler(output_file)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
    
    _configured = True


def get_logger(name: str) -> StructuredLogger:
    """
    Get a structured logger instance.
    
    Args:
        name: Logger name (typically __name__)
        
    Returns:
        StructuredLogger instance
        
    Example:
        >>> logger = get_logger(__name__)
        >>> logger.info("Application started", version="1.0.0")
    """
    # Ensure logging is configured
    global _configured
    if not _configured:
        configure_logging()
    
    python_logger = logging.getLogger(name)
    return StructuredLogger(name, python_logger)


def set_context(
    context_id: Optional[str] = None,
    workflow_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    request_id: Optional[str] = None
):
    """
    Set context variables for log correlation.
    
    Args:
        context_id: Context ID
        workflow_id: Workflow ID
        tenant_id: Tenant ID
        request_id: Request ID
        
    Example:
        >>> set_context(context_id="ctx-123", tenant_id="acme")
        >>> logger.info("Processing")  # Will include context_id and tenant_id
        >>> clear_context()
    """
    if context_id is not None:
        context_id_var.set(context_id)
    if workflow_id is not None:
        workflow_id_var.set(workflow_id)
    if tenant_id is not None:
        tenant_id_var.set(tenant_id)
    if request_id is not None:
        request_id_var.set(request_id)


def clear_context():
    """
    Clear all context variables.
    
    Example:
        >>> set_context(context_id="ctx-123")
        >>> logger.info("With context")
        >>> clear_context()
        >>> logger.info("Without context")
    """
    context_id_var.set(None)
    workflow_id_var.set(None)
    tenant_id_var.set(None)
    request_id_var.set(None)


def get_current_context() -> dict[str, Optional[str]]:
    """
    Get current context variables.
    
    Returns:
        Dictionary with current context values
        
    Example:
        >>> set_context(context_id="ctx-123", tenant_id="acme")
        >>> context = get_current_context()
        >>> print(context)
        {'context_id': 'ctx-123', 'workflow_id': None, 'tenant_id': 'acme', 'request_id': None}
    """
    return {
        "context_id": context_id_var.get(),
        "workflow_id": workflow_id_var.get(),
        "tenant_id": tenant_id_var.get(),
        "request_id": request_id_var.get()
    }
