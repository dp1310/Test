"""Monitoring module for CMP Framework."""

# Metrics (existing)
from cmp.monitoring.metrics import (
    MetricsCollector,
    Metrics,
    MetricsTimer,
    get_metrics_collector
)

# Structured Logging
from cmp.monitoring.structured_logging import (
    configure_logging,
    get_logger,
    set_context,
    clear_context,
    get_current_context,
    LogLevel,
    StructuredLogger,
)

# Health Checks
from cmp.monitoring.health_checks import (
    HealthCheck,
    HealthStatus,
    HealthCheckResult,
    SystemHealth,
    check_service_url,
)

# Distributed Tracing (optional dependency)
try:
    from cmp.monitoring.tracing import (
        configure_tracing,
        get_tracer,
        trace_function,
        trace_workflow,
        trace_agent,
        TracingContext,
        add_span_attribute,
        add_span_event,
        get_current_span,
        inject_trace_context,
        extract_trace_context,
        shutdown_tracing,
    )
    TRACING_AVAILABLE = True
except ImportError:
    TRACING_AVAILABLE = False
    # Provide no-op implementations
    configure_tracing = lambda *args, **kwargs: None
    get_tracer = lambda: None
    trace_function = lambda *args, **kwargs: (lambda f: f)
    trace_workflow = lambda *args, **kwargs: (lambda f: f)
    trace_agent = lambda *args, **kwargs: (lambda f: f)
    TracingContext = None
    add_span_attribute = lambda *args, **kwargs: None
    add_span_event = lambda *args, **kwargs: None
    get_current_span = lambda: None
    inject_trace_context = lambda *args, **kwargs: None
    extract_trace_context = lambda *args, **kwargs: None
    shutdown_tracing = lambda: None

# Profiling
from cmp.monitoring.profiling import (
    CPUProfiler,
    MemoryProfiler,
    ProfileResult,
    profile_cpu,
    profile_memory,
    profile_async_function,
)

__all__ = [
    # Metrics
    "MetricsCollector",
    "Metrics",
    "MetricsTimer",
    "get_metrics_collector",
    # Logging
    "configure_logging",
    "get_logger",
    "set_context",
    "clear_context",
    "get_current_context",
    "LogLevel",
    "StructuredLogger",
    # Health Checks
    "HealthCheck",
    "HealthStatus",
    "HealthCheckResult",
    "SystemHealth",
    "check_service_url",
    # Tracing
    "configure_tracing",
    "get_tracer",
    "trace_function",
    "trace_workflow",
    "trace_agent",
    "TracingContext",
    "add_span_attribute",
    "add_span_event",
    "get_current_span",
    "inject_trace_context",
    "extract_trace_context",
    "shutdown_tracing",
    # Profiling
    "CPUProfiler",
    "MemoryProfiler",
    "ProfileResult",
    "profile_cpu",
    "profile_memory",
    "profile_async_function",
]
