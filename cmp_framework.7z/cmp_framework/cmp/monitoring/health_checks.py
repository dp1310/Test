"""
Health check endpoints for CMP Framework.

Provides liveness and readiness probes for Kubernetes/Docker deployments.
"""

from typing import Optional, Callable, Awaitable
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
import asyncio
import psutil
import aiohttp

from ..core.result import Result, Ok, Err
from ..core.exceptions import CMPError


class HealthStatus(str, Enum):
    """Health check status."""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DEGRADED = "degraded"


class CheckError(CMPError):
    """Health check error."""
    pass


@dataclass(frozen=True)
class HealthCheckResult:
    """Result of a health check."""
    
    name: str
    status: HealthStatus
    message: str
    timestamp: str
    duration_ms: float
    metadata: dict = None
    
    def __post_init__(self):
        if self.metadata is None:
            object.__setattr__(self, 'metadata', {})


@dataclass(frozen=True)
class SystemHealth:
    """Overall system health status."""
    
    status: HealthStatus
    checks: list[HealthCheckResult]
    timestamp: str
    uptime_seconds: float
    
    @property
    def is_healthy(self) -> bool:
        """Check if system is healthy."""
        return self.status == HealthStatus.HEALTHY
    
    @property
    def is_ready(self) -> bool:
        """Check if system is ready to accept traffic."""
        # Ready if healthy or degraded (but not unhealthy)
        return self.status in (HealthStatus.HEALTHY, HealthStatus.DEGRADED)


class HealthCheck:
    """
    Health check system for monitoring service health.
    
    Provides:
    - Liveness probes (is the process running?)
    - Readiness probes (can it accept traffic?)
    - Detailed health status
    - Custom health checks
    
    Example:
        >>> health = HealthCheck()
        >>> 
        >>> # Add custom check
        >>> async def check_database():
        ...     # Check database connection
        ...     return HealthCheckResult(
        ...         name="database",
        ...         status=HealthStatus.HEALTHY,
        ...         message="Connected",
        ...         timestamp=datetime.now(timezone.utc).isoformat(),
        ...         duration_ms=5.0
        ...     )
        >>> 
        >>> health.add_check("database", check_database)
        >>> 
        >>> # Get health status
        >>> status = await health.get_health()
        >>> print(status.is_healthy)
    """
    
    def __init__(self):
        """Initialize health check system."""
        self._checks: dict[str, Callable[[], Awaitable[HealthCheckResult]]] = {}
        self._start_time = datetime.now(timezone.utc)
        
        # Add default checks
        self.add_check("process", self._check_process)
        self.add_check("memory", self._check_memory)
        self.add_check("cpu", self._check_cpu)
    
    def add_check(
        self,
        name: str,
        check_func: Callable[[], Awaitable[HealthCheckResult]]
    ):
        """
        Add a custom health check.
        
        Args:
            name: Check name
            check_func: Async function that returns HealthCheckResult
            
        Example:
            >>> async def check_redis():
            ...     try:
            ...         await redis.ping()
            ...         return HealthCheckResult(
            ...             name="redis",
            ...             status=HealthStatus.HEALTHY,
            ...             message="Connected",
            ...             timestamp=datetime.now(timezone.utc).isoformat(),
            ...             duration_ms=2.0
            ...         )
            ...     except Exception as e:
            ...         return HealthCheckResult(
            ...             name="redis",
            ...             status=HealthStatus.UNHEALTHY,
            ...             message=str(e),
            ...             timestamp=datetime.now(timezone.utc).isoformat(),
            ...             duration_ms=0.0
            ...         )
            >>> 
            >>> health.add_check("redis", check_redis)
        """
        self._checks[name] = check_func
    
    def remove_check(self, name: str):
        """Remove a health check."""
        self._checks.pop(name, None)
    
    async def _check_process(self) -> HealthCheckResult:
        """Check if process is running."""
        start = datetime.now(timezone.utc)
        
        try:
            process = psutil.Process()
            status = process.status()
            
            duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
            
            return HealthCheckResult(
                name="process",
                status=HealthStatus.HEALTHY,
                message=f"Process running (status: {status})",
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=duration,
                metadata={"pid": process.pid, "status": status}
            )
        except Exception as e:
            duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
            return HealthCheckResult(
                name="process",
                status=HealthStatus.UNHEALTHY,
                message=f"Process check failed: {e}",
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=duration
            )
    
    async def _check_memory(self) -> HealthCheckResult:
        """Check memory usage."""
        start = datetime.now(timezone.utc)
        
        try:
            process = psutil.Process()
            memory_info = process.memory_info()
            memory_percent = process.memory_percent()
            
            duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
            
            # Determine status based on memory usage
            if memory_percent > 90:
                status = HealthStatus.UNHEALTHY
                message = f"High memory usage: {memory_percent:.1f}%"
            elif memory_percent > 75:
                status = HealthStatus.DEGRADED
                message = f"Elevated memory usage: {memory_percent:.1f}%"
            else:
                status = HealthStatus.HEALTHY
                message = f"Memory usage: {memory_percent:.1f}%"
            
            return HealthCheckResult(
                name="memory",
                status=status,
                message=message,
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=duration,
                metadata={
                    "rss_mb": memory_info.rss / 1024 / 1024,
                    "vms_mb": memory_info.vms / 1024 / 1024,
                    "percent": memory_percent
                }
            )
        except Exception as e:
            duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
            return HealthCheckResult(
                name="memory",
                status=HealthStatus.UNHEALTHY,
                message=f"Memory check failed: {e}",
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=duration
            )
    
    async def _check_cpu(self) -> HealthCheckResult:
        """Check CPU usage."""
        start = datetime.now(timezone.utc)
        
        try:
            process = psutil.Process()
            cpu_percent = process.cpu_percent(interval=0.1)
            
            duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
            
            # Determine status based on CPU usage
            if cpu_percent > 90:
                status = HealthStatus.DEGRADED
                message = f"High CPU usage: {cpu_percent:.1f}%"
            else:
                status = HealthStatus.HEALTHY
                message = f"CPU usage: {cpu_percent:.1f}%"
            
            return HealthCheckResult(
                name="cpu",
                status=status,
                message=message,
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=duration,
                metadata={"percent": cpu_percent}
            )
        except Exception as e:
            duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
            return HealthCheckResult(
                name="cpu",
                status=HealthStatus.UNHEALTHY,
                message=f"CPU check failed: {e}",
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=duration
            )
    
    async def get_health(self) -> SystemHealth:
        """
        Get overall system health.
        
        Returns:
            SystemHealth with all check results
            
        Example:
            >>> health = HealthCheck()
            >>> status = await health.get_health()
            >>> print(f"Status: {status.status}")
            >>> print(f"Healthy: {status.is_healthy}")
            >>> for check in status.checks:
            ...     print(f"  {check.name}: {check.status}")
        """
        # Run all checks concurrently
        check_tasks = [check_func() for check_func in self._checks.values()]
        results = await asyncio.gather(*check_tasks, return_exceptions=True)
        
        # Convert exceptions to unhealthy results
        check_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                check_name = list(self._checks.keys())[i]
                check_results.append(
                    HealthCheckResult(
                        name=check_name,
                        status=HealthStatus.UNHEALTHY,
                        message=f"Check failed: {result}",
                        timestamp=datetime.now(timezone.utc).isoformat(),
                        duration_ms=0.0
                    )
                )
            else:
                check_results.append(result)
        
        # Determine overall status
        statuses = [check.status for check in check_results]
        
        if any(s == HealthStatus.UNHEALTHY for s in statuses):
            overall_status = HealthStatus.UNHEALTHY
        elif any(s == HealthStatus.DEGRADED for s in statuses):
            overall_status = HealthStatus.DEGRADED
        else:
            overall_status = HealthStatus.HEALTHY
        
        # Calculate uptime
        uptime = (datetime.now(timezone.utc) - self._start_time).total_seconds()
        
        return SystemHealth(
            status=overall_status,
            checks=check_results,
            timestamp=datetime.now(timezone.utc).isoformat(),
            uptime_seconds=uptime
        )
    
    async def is_live(self) -> bool:
        """
        Liveness probe - is the process running?
        
        Returns:
            True if process is alive
            
        Example:
            >>> health = HealthCheck()
            >>> is_alive = await health.is_live()
            >>> print(f"Process alive: {is_alive}")
        """
        try:
            result = await self._check_process()
            return result.status == HealthStatus.HEALTHY
        except Exception:
            return False
    
    async def is_ready(self) -> bool:
        """
        Readiness probe - can the service accept traffic?
        
        Returns:
            True if service is ready
            
        Example:
            >>> health = HealthCheck()
            >>> is_ready = await health.is_ready()
            >>> print(f"Service ready: {is_ready}")
        """
        status = await self.get_health()
        return status.is_ready


async def check_service_url(
    name: str,
    url: str,
    timeout: float = 5.0
) -> HealthCheckResult:
    """
    Check if a service URL is accessible.
    
    Args:
        name: Service name
        url: Service URL
        timeout: Request timeout in seconds
        
    Returns:
        HealthCheckResult
        
    Example:
        >>> result = await check_service_url("opa", "http://localhost:8181/health")
        >>> print(f"OPA status: {result.status}")
    """
    start = datetime.now(timezone.utc)
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as response:
                duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
                
                if response.status == 200:
                    return HealthCheckResult(
                        name=name,
                        status=HealthStatus.HEALTHY,
                        message=f"Service accessible (HTTP {response.status})",
                        timestamp=datetime.now(timezone.utc).isoformat(),
                        duration_ms=duration,
                        metadata={"url": url, "status_code": response.status}
                    )
                else:
                    return HealthCheckResult(
                        name=name,
                        status=HealthStatus.DEGRADED,
                        message=f"Service returned HTTP {response.status}",
                        timestamp=datetime.now(timezone.utc).isoformat(),
                        duration_ms=duration,
                        metadata={"url": url, "status_code": response.status}
                    )
    except asyncio.TimeoutError:
        duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
        return HealthCheckResult(
            name=name,
            status=HealthStatus.UNHEALTHY,
            message=f"Service timeout after {timeout}s",
            timestamp=datetime.now(timezone.utc).isoformat(),
            duration_ms=duration,
            metadata={"url": url}
        )
    except Exception as e:
        duration = (datetime.now(timezone.utc) - start).total_seconds() * 1000
        return HealthCheckResult(
            name=name,
            status=HealthStatus.UNHEALTHY,
            message=f"Service unreachable: {e}",
            timestamp=datetime.now(timezone.utc).isoformat(),
            duration_ms=duration,
            metadata={"url": url, "error": str(e)}
        )
