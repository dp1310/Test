"""
Performance profiling utilities for CMP Framework.

Provides CPU and memory profiling for identifying bottlenecks.
"""

from typing import Optional, Callable
from functools import wraps
import cProfile
import pstats
import io
import tracemalloc
from datetime import datetime
from dataclasses import dataclass
import asyncio


@dataclass(frozen=True)
class ProfileResult:
    """Profiling result."""
    
    function_name: str
    duration_seconds: float
    cpu_stats: Optional[str] = None
    memory_stats: Optional[dict] = None
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            object.__setattr__(self, 'timestamp', datetime.utcnow().isoformat())


class CPUProfiler:
    """
    CPU profiler using cProfile.
    
    Example:
        >>> profiler = CPUProfiler()
        >>> with profiler:
        ...     # Code to profile
        ...     expensive_operation()
        >>> 
        >>> stats = profiler.get_stats()
        >>> print(stats)
    """
    
    def __init__(self):
        """Initialize CPU profiler."""
        self.profiler = cProfile.Profile()
        self._stats: Optional[pstats.Stats] = None
    
    def __enter__(self):
        """Start profiling."""
        self.profiler.enable()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Stop profiling."""
        self.profiler.disable()
        self._stats = pstats.Stats(self.profiler)
    
    def get_stats(self, sort_by: str = "cumulative", limit: int = 20) -> str:
        """
        Get profiling statistics.
        
        Args:
            sort_by: Sort key ("cumulative", "time", "calls")
            limit: Number of entries to show
            
        Returns:
            Formatted statistics string
        """
        if self._stats is None:
            return "No profiling data available"
        
        stream = io.StringIO()
        stats = pstats.Stats(self.profiler, stream=stream)
        stats.sort_stats(sort_by)
        stats.print_stats(limit)
        
        return stream.getvalue()
    
    def save_stats(self, filename: str):
        """
        Save profiling stats to file.
        
        Args:
            filename: Output filename
        """
        if self._stats:
            self.profiler.dump_stats(filename)


class MemoryProfiler:
    """
    Memory profiler using tracemalloc.
    
    Example:
        >>> profiler = MemoryProfiler()
        >>> with profiler:
        ...     # Code to profile
        ...     data = [i for i in range(1000000)]
        >>> 
        >>> stats = profiler.get_stats()
        >>> print(f"Peak memory: {stats['peak_mb']:.2f} MB")
    """
    
    def __init__(self):
        """Initialize memory profiler."""
        self._snapshot_before: Optional[tracemalloc.Snapshot] = None
        self._snapshot_after: Optional[tracemalloc.Snapshot] = None
        self._peak_memory: int = 0
    
    def __enter__(self):
        """Start memory profiling."""
        tracemalloc.start()
        self._snapshot_before = tracemalloc.take_snapshot()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Stop memory profiling."""
        self._snapshot_after = tracemalloc.take_snapshot()
        _, self._peak_memory = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    
    def get_stats(self, top_n: int = 10) -> dict:
        """
        Get memory profiling statistics.
        
        Args:
            top_n: Number of top allocations to include
            
        Returns:
            Dictionary with memory statistics
        """
        if not self._snapshot_after or not self._snapshot_before:
            return {"error": "No profiling data available"}
        
        # Calculate differences
        top_stats = self._snapshot_after.compare_to(
            self._snapshot_before, 'lineno'
        )
        
        # Get top allocations
        top_allocations = []
        for stat in top_stats[:top_n]:
            top_allocations.append({
                "file": stat.traceback.format()[0] if stat.traceback else "unknown",
                "size_mb": stat.size_diff / 1024 / 1024,
                "count": stat.count_diff
            })
        
        return {
            "peak_mb": self._peak_memory / 1024 / 1024,
            "top_allocations": top_allocations
        }


def profile_cpu(sort_by: str = "cumulative", limit: int = 20):
    """
    Decorator to profile CPU usage of a function.
    
    Args:
        sort_by: Sort key for stats
        limit: Number of entries to show
        
    Example:
        >>> @profile_cpu()
        ... def expensive_function():
        ...     # Function is automatically profiled
        ...     return sum(range(1000000))
    """
    def decorator(func: Callable):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            profiler = CPUProfiler()
            with profiler:
                result = await func(*args, **kwargs)
            
            stats = profiler.get_stats(sort_by=sort_by, limit=limit)
            print(f"\n=== CPU Profile for {func.__name__} ===")
            print(stats)
            
            return result
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            profiler = CPUProfiler()
            with profiler:
                result = func(*args, **kwargs)
            
            stats = profiler.get_stats(sort_by=sort_by, limit=limit)
            print(f"\n=== CPU Profile for {func.__name__} ===")
            print(stats)
            
            return result
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


def profile_memory(top_n: int = 10):
    """
    Decorator to profile memory usage of a function.
    
    Args:
        top_n: Number of top allocations to show
        
    Example:
        >>> @profile_memory(top_n=5)
        ... def memory_intensive():
        ...     # Function is automatically profiled
        ...     return [i for i in range(1000000)]
    """
    def decorator(func: Callable):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            profiler = MemoryProfiler()
            with profiler:
                result = await func(*args, **kwargs)
            
            stats = profiler.get_stats(top_n=top_n)
            print(f"\n=== Memory Profile for {func.__name__} ===")
            print(f"Peak memory: {stats.get('peak_mb', 0):.2f} MB")
            print("\nTop allocations:")
            for alloc in stats.get('top_allocations', []):
                print(f"  {alloc['file']}: {alloc['size_mb']:.2f} MB ({alloc['count']} objects)")
            
            return result
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            profiler = MemoryProfiler()
            with profiler:
                result = func(*args, **kwargs)
            
            stats = profiler.get_stats(top_n=top_n)
            print(f"\n=== Memory Profile for {func.__name__} ===")
            print(f"Peak memory: {stats.get('peak_mb', 0):.2f} MB")
            print("\nTop allocations:")
            for alloc in stats.get('top_allocations', []):
                print(f"  {alloc['file']}: {alloc['size_mb']:.2f} MB ({alloc['count']} objects)")
            
            return result
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


async def profile_async_function(
    func: Callable,
    *args,
    profile_cpu_enabled: bool = True,
    profile_memory_enabled: bool = True,
    **kwargs
) -> ProfileResult:
    """
    Profile an async function with both CPU and memory profiling.
    
    Args:
        func: Function to profile
        *args: Function arguments
        profile_cpu_enabled: Enable CPU profiling
        profile_memory_enabled: Enable memory profiling
        **kwargs: Function keyword arguments
        
    Returns:
        ProfileResult with profiling data
        
    Example:
        >>> async def my_function(x, y):
        ...     return x + y
        >>> 
        >>> result = await profile_async_function(my_function, 10, 20)
        >>> print(f"Duration: {result.duration_seconds}s")
    """
    start_time = datetime.utcnow()
    
    cpu_stats = None
    memory_stats = None
    
    # CPU profiling
    if profile_cpu_enabled:
        cpu_profiler = CPUProfiler()
        cpu_profiler.__enter__()
    
    # Memory profiling
    if profile_memory_enabled:
        memory_profiler = MemoryProfiler()
        memory_profiler.__enter__()
    
    try:
        # Execute function
        result = await func(*args, **kwargs)
        
        # Stop profiling
        if profile_cpu_enabled:
            cpu_profiler.__exit__(None, None, None)
            cpu_stats = cpu_profiler.get_stats()
        
        if profile_memory_enabled:
            memory_profiler.__exit__(None, None, None)
            memory_stats = memory_profiler.get_stats()
        
        duration = (datetime.utcnow() - start_time).total_seconds()
        
        return ProfileResult(
            function_name=func.__name__,
            duration_seconds=duration,
            cpu_stats=cpu_stats,
            memory_stats=memory_stats
        )
    
    except Exception as e:
        # Stop profiling on error
        if profile_cpu_enabled:
            cpu_profiler.__exit__(type(e), e, e.__traceback__)
        if profile_memory_enabled:
            memory_profiler.__exit__(type(e), e, e.__traceback__)
        raise
