"""
Monitoring and metrics for CMP framework.
"""

from typing import Dict, Optional
from datetime import datetime
from dataclasses import dataclass, field
import time


@dataclass
class Metrics:
    """Container for framework metrics"""
    
    # Context operations
    contexts_created: int = 0
    contexts_retrieved: int = 0
    contexts_updated: int = 0
    contexts_deleted: int = 0
    
    # Workflow operations
    workflows_executed: int = 0
    workflow_steps_completed: int = 0
    
    # Errors
    errors_total: int = 0
    policy_violations: int = 0
    
    # Performance
    avg_context_create_time_ms: float = 0.0
    avg_workflow_execution_time_ms: float = 0.0
    
    # Timestamps
    last_updated: datetime = field(default_factory=datetime.utcnow)


class MetricsCollector:
    """
    Collects and tracks metrics for the CMP framework.
    
    Provides Prometheus-style metrics collection.
    """
    
    def __init__(self):
        self._metrics = Metrics()
        self._operation_times: Dict[str, list[float]] = {}
    
    def record_context_created(self, duration_ms: Optional[float] = None) -> None:
        """Record context creation"""
        self._metrics.contexts_created += 1
        if duration_ms:
            self._record_operation_time("context_create", duration_ms)
            self._update_avg_create_time()
        self._metrics.last_updated = datetime.utcnow()
    
    def record_context_retrieved(self) -> None:
        """Record context retrieval"""
        self._metrics.contexts_retrieved += 1
        self._metrics.last_updated = datetime.utcnow()
    
    def record_context_updated(self) -> None:
        """Record context update"""
        self._metrics.contexts_updated += 1
        self._metrics.last_updated = datetime.utcnow()
    
    def record_context_deleted(self) -> None:
        """Record context deletion"""
        self._metrics.contexts_deleted += 1
        self._metrics.last_updated = datetime.utcnow()
    
    def record_workflow_executed(self, duration_ms: Optional[float] = None) -> None:
        """Record workflow execution"""
        self._metrics.workflows_executed += 1
        if duration_ms:
            self._record_operation_time("workflow_execute", duration_ms)
            self._update_avg_workflow_time()
        self._metrics.last_updated = datetime.utcnow()
    
    def record_workflow_step(self) -> None:
        """Record workflow step completion"""
        self._metrics.workflow_steps_completed += 1
        self._metrics.last_updated = datetime.utcnow()
    
    def record_error(self) -> None:
        """Record error"""
        self._metrics.errors_total += 1
        self._metrics.last_updated = datetime.utcnow()
    
    def record_policy_violation(self) -> None:
        """Record policy violation"""
        self._metrics.policy_violations += 1
        self._metrics.errors_total += 1
        self._metrics.last_updated = datetime.utcnow()
    
    def get_metrics(self) -> Metrics:
        """Get current metrics snapshot"""
        return self._metrics
    
    def reset(self) -> None:
        """Reset all metrics"""
        self._metrics = Metrics()
        self._operation_times.clear()
    
    def _record_operation_time(self, operation: str, duration_ms: float) -> None:
        """Record operation timing"""
        if operation not in self._operation_times:
            self._operation_times[operation] = []
        self._operation_times[operation].append(duration_ms)
        
        # Keep only last 100 measurements
        if len(self._operation_times[operation]) > 100:
            self._operation_times[operation] = self._operation_times[operation][-100:]
    
    def _update_avg_create_time(self) -> None:
        """Update average context creation time"""
        times = self._operation_times.get("context_create", [])
        if times:
            self._metrics.avg_context_create_time_ms = sum(times) / len(times)
    
    def _update_avg_workflow_time(self) -> None:
        """Update average workflow execution time"""
        times = self._operation_times.get("workflow_execute", [])
        if times:
            self._metrics.avg_workflow_execution_time_ms = sum(times) / len(times)
    
    def to_prometheus(self) -> str:
        """
        Export metrics in Prometheus format.
        
        Returns:
            Prometheus-formatted metrics string
        """
        lines = [
            "# HELP cmp_contexts_created_total Total contexts created",
            "# TYPE cmp_contexts_created_total counter",
            f"cmp_contexts_created_total {self._metrics.contexts_created}",
            "",
            "# HELP cmp_contexts_retrieved_total Total contexts retrieved",
            "# TYPE cmp_contexts_retrieved_total counter",
            f"cmp_contexts_retrieved_total {self._metrics.contexts_retrieved}",
            "",
            "# HELP cmp_workflows_executed_total Total workflows executed",
            "# TYPE cmp_workflows_executed_total counter",
            f"cmp_workflows_executed_total {self._metrics.workflows_executed}",
            "",
            "# HELP cmp_errors_total Total errors",
            "# TYPE cmp_errors_total counter",
            f"cmp_errors_total {self._metrics.errors_total}",
            "",
            "# HELP cmp_context_create_duration_ms Average context creation time",
            "# TYPE cmp_context_create_duration_ms gauge",
            f"cmp_context_create_duration_ms {self._metrics.avg_context_create_time_ms}",
        ]
        return "\n".join(lines)


# Global metrics collector instance
_metrics_collector: Optional[MetricsCollector] = None


def get_metrics_collector() -> MetricsCollector:
    """Get global metrics collector instance"""
    global _metrics_collector
    if _metrics_collector is None:
        _metrics_collector = MetricsCollector()
    return _metrics_collector


class MetricsTimer:
    """Context manager for timing operations"""
    
    def __init__(self, operation: str):
        self.operation = operation
        self.start_time = 0.0
        self.duration_ms = 0.0
    
    def __enter__(self):
        self.start_time = time.time()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.duration_ms = (time.time() - self.start_time) * 1000
        return False
