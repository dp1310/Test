"""
Distributed tracing with OpenTelemetry for CMP Framework.

Provides automatic span creation, context propagation, and integration with
Jaeger/Zipkin/Tempo for workflow visibility.
"""

from typing import Optional, Any, Callable
from functools import wraps
from contextvars import ContextVar
import asyncio

# Try to import OpenTelemetry, but make it optional
try:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.exporter.jaeger.thrift import JaegerExporter
    from opentelemetry.sdk.resources import Resource, SERVICE_NAME
    from opentelemetry.trace import Status, StatusCode, Span
    from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
    TRACING_AVAILABLE = True
except ImportError:
    TRACING_AVAILABLE = False
    # Create stub types for when OpenTelemetry is not available
    trace = None
    TracerProvider = None
    Span = None

# Context variable for current span
current_span_var: ContextVar[Optional[Any]] = ContextVar("current_span", default=None)

# Global tracer
_tracer: Optional[Any] = None
_tracer_provider: Optional[Any] = None


def configure_tracing(
    service_name: str = "cmp-framework",
    jaeger_endpoint: Optional[str] = None,
    enabled: bool = True
):
    """
    Configure OpenTelemetry tracing.
    
    Args:
        service_name: Service name for tracing
        jaeger_endpoint: Jaeger collector endpoint (e.g., "http://localhost:14268/api/traces")
        enabled: Enable tracing
        
    Example:
        >>> configure_tracing(
        ...     service_name="cmp-framework",
        ...     jaeger_endpoint="http://localhost:14268/api/traces",
        ...     enabled=True
        ... )
    """
    global _tracer, _tracer_provider
    
    if not TRACING_AVAILABLE:
        # OpenTelemetry not installed, skip configuration
        return
    
    if not enabled:
        _tracer = trace.get_tracer(__name__)
        return
    
    # Create resource with service name
    resource = Resource(attributes={
        SERVICE_NAME: service_name
    })
    
    # Create tracer provider
    _tracer_provider = TracerProvider(resource=resource)
    
    # Add Jaeger exporter if endpoint provided
    if jaeger_endpoint:
        jaeger_exporter = JaegerExporter(
            collector_endpoint=jaeger_endpoint,
        )
        span_processor = BatchSpanProcessor(jaeger_exporter)
        _tracer_provider.add_span_processor(span_processor)
    
    # Set global tracer provider
def trace_function(
    span_name: Optional[str] = None,
    attributes: Optional[dict[str, Any]] = None
):
    """
    Decorator to trace a function.
    
    Args:
        span_name: Custom span name (defaults to function name)
        attributes: Additional span attributes
        
    Example:
        >>> @trace_function(span_name="process_context", attributes={"version": "1.0"})
        ... async def process(ctx):
        ...     # Function is automatically traced
        ...     return ctx
    """
    def decorator(func: Callable):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            tracer = get_tracer()
            name = span_name or func.__name__
            
            with tracer.start_as_current_span(name) as span:
                # Add attributes
                if attributes:
                    for key, value in attributes.items():
                        span.set_attribute(key, str(value))
                
                # Add function info
                span.set_attribute("function.name", func.__name__)
                span.set_attribute("function.module", func.__module__)
                
                # Store span in context
                current_span_var.set(span)
                
                try:
                    result = await func(*args, **kwargs)
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    raise
                finally:
                    current_span_var.set(None)
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            tracer = get_tracer()
            name = span_name or func.__name__
            
            with tracer.start_as_current_span(name) as span:
                # Add attributes
                if attributes:
                    for key, value in attributes.items():
                        span.set_attribute(key, str(value))
                
                # Add function info
                span.set_attribute("function.name", func.__name__)
                span.set_attribute("function.module", func.__module__)
                
                # Store span in context
                current_span_var.set(span)
                
                try:
                    result = func(*args, **kwargs)
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    raise
                finally:
                    current_span_var.set(None)
        
        # Return appropriate wrapper based on function type
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


def trace_workflow(workflow_name: str):
    """
    Decorator to trace a workflow execution.
    
    Args:
        workflow_name: Workflow name
        
    Example:
        >>> @trace_workflow("enrichment_workflow")
        ... async def execute_workflow(ctx):
        ...     # Workflow is automatically traced
        ...     return ctx
    """
    return trace_function(
        span_name=f"workflow.{workflow_name}",
        attributes={"workflow.name": workflow_name}
    )


def trace_agent(agent_id: str):
    """
    Decorator to trace an agent execution.
    
    Args:
        agent_id: Agent identifier
        
    Example:
        >>> @trace_agent("enrichment_agent")
        ... async def process(self, ctx):
        ...     # Agent processing is automatically traced
        ...     return ctx
    """
    return trace_function(
        span_name=f"agent.{agent_id}",
        attributes={"agent.id": agent_id}
    )


class TracingContext:
    """
    Context manager for manual span creation.
    
    Example:
        >>> async with TracingContext("custom_operation") as span:
        ...     span.set_attribute("custom_key", "custom_value")
        ...     # Do work
        ...     span.add_event("Processing started")
    """
    
    def __init__(
        self,
        span_name: str,
        attributes: Optional[dict[str, Any]] = None
    ):
        """
        Initialize tracing context.
        
        Args:
            span_name: Span name
            attributes: Optional span attributes
        """
        self.span_name = span_name
        self.attributes = attributes or {}
        self.span: Optional[Span] = None
    
    async def __aenter__(self) -> Span:
        """Enter async context."""
        tracer = get_tracer()
        self.span = tracer.start_span(self.span_name)
        
        # Add attributes
        for key, value in self.attributes.items():
            self.span.set_attribute(key, str(value))
        
        # Store in context
        current_span_var.set(self.span)
        
        return self.span
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit async context."""
        if self.span:
            if exc_type:
                self.span.set_status(Status(StatusCode.ERROR, str(exc_val)))
                self.span.record_exception(exc_val)
            else:
                self.span.set_status(Status(StatusCode.OK))
            
            self.span.end()
            current_span_var.set(None)
    
    def __enter__(self) -> Span:
        """Enter sync context."""
        tracer = get_tracer()
        self.span = tracer.start_span(self.span_name)
        
        # Add attributes
        for key, value in self.attributes.items():
            self.span.set_attribute(key, str(value))
        
        # Store in context
        current_span_var.set(self.span)
        
        return self.span
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit sync context."""
        if self.span:
            if exc_type:
                self.span.set_status(Status(StatusCode.ERROR, str(exc_val)))
                self.span.record_exception(exc_val)
            else:
                self.span.set_status(Status(StatusCode.OK))
            
            self.span.end()
            current_span_var.set(None)


def add_span_attribute(key: str, value: Any):
    """
    Add attribute to current span.
    
    Args:
        key: Attribute key
        value: Attribute value
        
    Example:
        >>> @trace_function()
        ... async def process(ctx_id):
        ...     add_span_attribute("context.id", ctx_id)
        ...     # Process context
    """
    span = current_span_var.get()
    if span:
        span.set_attribute(key, str(value))


def add_span_event(name: str, attributes: Optional[dict[str, Any]] = None):
    """
    Add event to current span.
    
    Args:
        name: Event name
        attributes: Optional event attributes
        
    Example:
        >>> @trace_function()
        ... async def process(ctx):
        ...     add_span_event("validation_started")
        ...     # Validate
        ...     add_span_event("validation_completed", {"valid": True})
    """
    span = current_span_var.get()
    if span:
        span.add_event(name, attributes=attributes or {})


def get_current_span() -> Optional[Span]:
    """
    Get the current active span.
    
    Returns:
        Current span or None
    """
    return current_span_var.get()


def inject_trace_context(carrier: dict[str, str]):
    """
    Inject trace context into carrier for propagation.
    
    Args:
        carrier: Dictionary to inject context into
        
    Example:
        >>> headers = {}
        >>> inject_trace_context(headers)
        >>> # headers now contains traceparent header
        >>> async with aiohttp.ClientSession() as session:
        ...     await session.get(url, headers=headers)
    """
    propagator = TraceContextTextMapPropagator()
    propagator.inject(carrier)


def extract_trace_context(carrier: dict[str, str]):
    """
    Extract trace context from carrier.
    
    Args:
        carrier: Dictionary containing trace context
        
    Example:
        >>> # In API handler
        >>> headers = request.headers
        >>> extract_trace_context(headers)
        >>> # Trace context is now active
    """
    propagator = TraceContextTextMapPropagator()
    return propagator.extract(carrier)


async def shutdown_tracing():
    """
    Shutdown tracing and flush remaining spans.
    
    Example:
        >>> # On application shutdown
        >>> await shutdown_tracing()
    """
    global _tracer_provider
    if _tracer_provider:
        _tracer_provider.shutdown()
