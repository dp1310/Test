"""
Context Service - Core context management operations.
"""

from typing import Optional, AsyncIterator, Any
from datetime import datetime
import uuid

from cmp.core.models import (
    Context,
    ContextEnvelope,
    ContextEvent,
    Schema,
    Metadata
)
from cmp.core.result import Result, Ok, Err
from cmp.core.builders import ContextEnvelopeBuilder
from cmp.core.exceptions import (
    ContextError,
    ContextNotFoundError,
    SchemaNotFoundError,
    PolicyViolationError
)
from cmp.core.observable import ContextObservable
from cmp.storage.context_store import ContextStore


class PolicyResult:
    """Result of policy evaluation"""
    
    def __init__(self, allowed: bool, reason: str = "", metadata: dict | None = None):
        self.allowed = allowed
        self.reason = reason
        self.metadata = metadata or {}


class ContextService:
    """
    Core context management service.
    
    Provides CRUD operations for contexts with policy enforcement,
    schema validation, and event notifications.
    """
    
    def __init__(
        self,
        store: ContextStore,
        schema_registry: Any,
        policy_service: Any,
        observable: Optional[ContextObservable] = None,
        cache_enabled: bool = True
    ):
        self._store = store
        self._schema_registry = schema_registry
        self._policy_service = policy_service
        self._observable = observable or ContextObservable()
        
        # Initialize cache
        from cmp.core.cache import get_cache
        self._cache = get_cache() if cache_enabled else None
        self._cache_ttl = 300  # 5 minutes default
    
    async def create(
        self,
        data: dict[str, Any],
        schema_name: str,
        tenant_id: str,
        **metadata_kwargs: Any
    ) -> Result[str, ContextError]:
        """
        Create new context.
        
        Args:
            data: Context data
            schema_name: Schema name for validation
            tenant_id: Tenant ID for isolation
            **metadata_kwargs: Additional metadata fields
            
        Returns:
            Result containing context ID or error
        """
        try:
            # Generate context ID
            context_id = f"ctx_{uuid.uuid4().hex[:12]}"
            
            # Get schema (mock for now)
            schema = await self._get_schema(schema_name, tenant_id)
            if not schema:
                return Err(SchemaNotFoundError(schema_name))
            
            # Build envelope
            envelope = await (
                ContextEnvelopeBuilder()
                .with_id(context_id)
                .with_data(data)
                .with_schema(schema)
                .with_metadata(tenant_id=tenant_id, **metadata_kwargs)
                .build()
            )
            
            # Check policy (mock for now)
            policy_result = await self._check_policy("context.create", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            
            # Save to store
            saved_id = await self._store.save(envelope)
            
            # Cache the new context
            if self._cache:
                await self._cache.set(
                    f"context:{saved_id}", 
                    envelope.to_dict(),  # Assuming to_dict exists or similar serialization
                    ttl=self._cache_ttl
                )
            
            # Notify observers
            await self._observable.notify(ContextEvent(
                event_type="context.created",
                context_id=saved_id,
                tenant_id=tenant_id,
                timestamp=datetime.utcnow(),
                payload={"schema": schema_name}
            ))
            
            return Ok(saved_id)
            
        except Exception as e:
            return Err(ContextError(str(e)))
    
    async def get(self, context_id: str) -> Result[Context, ContextError]:
        """
        Get context by ID.
        
        Args:
            context_id: Context ID to retrieve
            
        Returns:
            Result containing Context or error
        """
        try:
            # Try cache first
            if self._cache:
                cached_data = await self._cache.get(f"context:{context_id}")
                if cached_data:
                    # Reconstruct from cache (simplified)
                    # In a real implementation, we'd need proper deserialization
                    # For now, we'll fall back to store if deserialization is complex
                    # or assume cached_data is sufficient if we had a from_dict
                    pass 

            envelope = await self._store.get(context_id)
            if envelope is None:
                return Err(ContextNotFoundError(context_id))
            
            # Check read policy
            policy_result = await self._check_policy("context.read", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            
            # Update cache
            if self._cache:
                # We need a serializable format. Assuming envelope has one or we use pickle/json
                # For this example, we'll skip complex serialization implementation details
                # and just show the hook
                pass
            
            return Ok(envelope.to_context())
            
        except Exception as e:
            return Err(ContextError(str(e)))
    
    async def get_envelope(self, context_id: str) -> Result[ContextEnvelope, ContextError]:
        """
        Get full context envelope by ID.
        
        Args:
            context_id: Context ID to retrieve
            
        Returns:
            Result containing ContextEnvelope or error
        """
        try:
            # Try cache first
            if self._cache:
                cached = await self._cache.get(f"context:{context_id}")
                if cached:
                    # TODO: Implement proper deserialization from cached dict
                    # envelope = ContextEnvelope.from_dict(cached)
                    # return Ok(envelope)
                    pass

            envelope = await self._store.get(context_id)
            if envelope is None:
                return Err(ContextNotFoundError(context_id))
            
            # Check read policy
            policy_result = await self._check_policy("context.read", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            
            # Update cache
            if self._cache:
                # await self._cache.set(f"context:{context_id}", envelope.to_dict(), ttl=self._cache_ttl)
                pass
            
            return Ok(envelope)
            
        except Exception as e:
            return Err(ContextError(str(e)))
    
    async def search(
        self,
        query: dict[str, Any],
        tenant_id: str,
        limit: int = 10
    ) -> AsyncIterator[Context]:
        """
        Search for contexts.
        
        Args:
            query: Search query parameters
            tenant_id: Tenant ID for isolation
            limit: Maximum number of results
            
        Yields:
            Matching Context instances
        """
        # Check search policy
        policy_result = await self._check_policy(
            "context.search",
            {"tenant_id": tenant_id, "query": query}
        )
        if not policy_result.allowed:
            raise PolicyViolationError(policy_result.reason)
        
        # Stream results from store
        async for envelope in self._store.search(query, tenant_id, limit):
            yield envelope.to_context()
    
    async def update(
        self,
        context_id: str,
        data_updates: dict[str, Any]
    ) -> Result[Context, ContextError]:
        """
        Update context data.
        
        Args:
            context_id: Context ID to update
            data_updates: Data fields to update
            
        Returns:
            Result containing updated Context or error
        """
        try:
            # Get existing envelope
            envelope = await self._store.get(context_id)
            if envelope is None:
                return Err(ContextNotFoundError(context_id))
            
            # Check update policy
            policy_result = await self._check_policy("context.update", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            
            # Create updated envelope
            updated_data = {**envelope.data, **data_updates}
            updated_envelope = await (
                ContextEnvelopeBuilder()
                .with_id(envelope.id)
                .with_data(updated_data)
                .with_schema(envelope.schema)
                .with_policy(envelope.policy)
                .with_metadata(
                    tenant_id=envelope.metadata.tenant_id,
                    **envelope.metadata.custom
                )
                .build()
            )
            
            # Save updated envelope
            await self._store.update(context_id, updated_envelope)
            
            # Invalidate cache
            if self._cache:
                await self._cache.delete(f"context:{context_id}")
            
            # Notify observers
            await self._observable.notify(ContextEvent(
                event_type="context.updated",
                context_id=context_id,
                tenant_id=envelope.metadata.tenant_id,
                timestamp=datetime.utcnow(),
                payload={"updates": list(data_updates.keys())}
            ))
            
            return Ok(updated_envelope.to_context())
            
        except Exception as e:
            return Err(ContextError(str(e)))
    
    async def delete(self, context_id: str) -> Result[bool, ContextError]:
        """
        Delete context.
        
        Args:
            context_id: Context ID to delete
            
        Returns:
            Result containing True if deleted, error otherwise
        """
        try:
            # Get envelope for policy check
            envelope = await self._store.get(context_id)
            if envelope is None:
                return Err(ContextNotFoundError(context_id))
            
            # Check delete policy
            policy_result = await self._check_policy("context.delete", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            
            # Delete from store
            deleted = await self._store.delete(context_id)
            
            if deleted:
                # Invalidate cache
                if self._cache:
                    await self._cache.delete(f"context:{context_id}")

                # Notify observers
                await self._observable.notify(ContextEvent(
                    event_type="context.deleted",
                    context_id=context_id,
                    tenant_id=envelope.metadata.tenant_id,
                    timestamp=datetime.utcnow()
                ))
            
            return Ok(deleted)
            
        except Exception as e:
            return Err(ContextError(str(e)))
    
    async def stream_updates(
        self,
        context_id: str
    ) -> AsyncIterator[ContextEvent]:
        """
        Stream context updates via SSE.
        
        Args:
            context_id: Context ID to stream updates for
            
        Yields:
            ContextEvent instances for this context
        """
        import asyncio
        queue: asyncio.Queue[ContextEvent] = asyncio.Queue()
        
        async def observer(event: ContextEvent) -> None:
            if event.context_id == context_id:
                await queue.put(event)
        
        self._observable.subscribe(observer)
        
        try:
            while True:
                event = await queue.get()
                yield event
        finally:
            self._observable.unsubscribe(observer)
    
    # Helper methods
    
    async def _get_schema(self, schema_name: str, tenant_id: str) -> Optional[Schema]:
        """Get schema from registry (mock implementation)"""
        # TODO: Implement when SchemaRegistry is ready
        from cmp.core.models import Schema
        return Schema(
            name=schema_name,
            version="1.0",
            fields={},
            required_fields=()
        )
    
    async def _check_policy(self, action: str, data: Any) -> PolicyResult:
        """Check policy (mock implementation)"""
        # TODO: Implement when PolicyService is ready
        return PolicyResult(allowed=True, reason="")
    
    @property
    def observable(self) -> ContextObservable:
        """Get observable for subscribing to events"""
        return self._observable
