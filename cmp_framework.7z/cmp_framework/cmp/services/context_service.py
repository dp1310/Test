"""
Context Service - Core context management operations.
"""

from typing import Optional, AsyncIterator, Any
from datetime import datetime, timezone
import uuid

from cmp.core.models import (
    Context,
    ContextEnvelope,
    ContextEvent,
    Schema,
    Metadata,
)
from cmp.core.result import Result, Ok, Err
from cmp.core.builders import ContextEnvelopeBuilder
from cmp.core.exceptions import (
    ContextError,
    ContextNotFoundError,
    SchemaNotFoundError,
    PolicyViolationError,
)
from cmp.core.observable import ContextObservable
from cmp.storage.context_store import ContextStore
from cachetools import TTLCache
from cmp.monitoring.metrics import get_metrics_collector


class PolicyResult:
    """Result of policy evaluation"""

    def __init__(self, allowed: bool, reason: str = "", metadata: dict | None = None):
        self.allowed = allowed
        self.reason = reason
        self.metadata = metadata or {}


class ContextService:
    """Core context management service.

    Provides CRUD operations for contexts with policy enforcement,
    schema validation, and event notifications.
    """

    def __init__(
        self,
        store: ContextStore,
        schema_registry: Any,
        policy_service: Any,
        observable: Optional[ContextObservable] = None,
        cache_enabled: bool = True,
    ):
        self._store = store
        self._schema_registry = schema_registry
        self._policy_service = policy_service
        self._observable = observable or ContextObservable()
        if cache_enabled:
            self._cache: TTLCache = TTLCache(maxsize=1000, ttl=300)
        else:
            self._cache = None

    # ---------- Core Operations ----------
    async def create(
        self,
        data: dict[str, Any],
        schema_name: str,
        tenant_id: str,
        **metadata_kwargs: Any,
    ) -> Result[str, ContextError]:
        """Create a new context and record a metric."""
        try:
            context_id = f"ctx_{uuid.uuid4().hex[:12]}"
            # Mock schema retrieval
            schema = await self._get_schema(schema_name, tenant_id)
            if not schema:
                return Err(SchemaNotFoundError(schema_name))
            envelope = await (
                ContextEnvelopeBuilder()
                .with_id(context_id)
                .with_data(data)
                .with_schema(schema)
                .with_metadata(tenant_id=tenant_id, **metadata_kwargs)
                .build()
            )
            # Mock policy check
            policy_result = await self._check_policy("context.create", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            saved_id = await self._store.save(envelope)
            await self._observable.notify(
                ContextEvent(
                    event_type="context.created",
                    context_id=saved_id,
                    tenant_id=tenant_id,
                    timestamp=datetime.now(timezone.utc),
                    payload={"schema": schema_name},
                )
            )
            # Record metric
            get_metrics_collector().record_context_created()
            return Ok(saved_id)
        except Exception as e:
            return Err(ContextError(str(e)))

    async def get(self, context_id: str) -> Result[Context, ContextError]:
        """Retrieve a context by ID."""
        try:
            if self._cache:
                cached = await self._cache.get(f"context:{context_id}")
                if cached:
                    # Simplified: fall back to store
                    pass
            envelope = await self._store.get(context_id)
            if envelope is None:
                return Err(ContextNotFoundError(context_id))
            policy_result = await self._check_policy("context.read", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            if self._cache:
                # Placeholder for caching logic
                pass
            return Ok(envelope.to_context())
        except Exception as e:
            return Err(ContextError(str(e)))

    async def get_envelope(self, context_id: str) -> Result[ContextEnvelope, ContextError]:
        """Retrieve the full envelope for a context."""
        try:
            if self._cache:
                cached = await self._cache.get(f"context:{context_id}")
                if cached:
                    pass
            envelope = await self._store.get(context_id)
            if envelope is None:
                return Err(ContextNotFoundError(context_id))
            policy_result = await self._check_policy("context.read", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            if self._cache:
                pass
            return Ok(envelope)
        except Exception as e:
            return Err(ContextError(str(e)))

    async def list(self, limit: int = 10, tenant_id: str = "default") -> Result[list[Context], ContextError]:
        """List contexts with a limit."""
        try:
            envelopes = await self._store.list_all(tenant_id, limit)
            contexts = [envelope.to_context() for envelope in envelopes]
            return Ok(contexts)
        except Exception as e:
            return Err(ContextError(str(e)))

    async def search(
        self,
        query: dict[str, Any],
        tenant_id: str,
        limit: int = 10,
    ) -> AsyncIterator[Context]:
        """Search for contexts matching a query."""
        policy_result = await self._check_policy(
            "context.search", {"tenant_id": tenant_id, "query": query}
        )
        if not policy_result.allowed:
            raise PolicyViolationError(policy_result.reason)
        async for envelope in self._store.search(query, tenant_id, limit):
            yield envelope.to_context()

    async def update(
        self,
        context_id: str,
        data_updates: dict[str, Any],
    ) -> Result[Context, ContextError]:
        """Update an existing context."""
        try:
            envelope = await self._store.get(context_id)
            if envelope is None:
                return Err(ContextNotFoundError(context_id))
            policy_result = await self._check_policy("context.update", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            updated_data = {**envelope.data, **data_updates}
            updated_envelope = await (
                ContextEnvelopeBuilder()
                .with_id(envelope.id)
                .with_data(updated_data)
                .with_schema(envelope.schema)
                .with_policy(envelope.policy)
                .with_metadata(
                    tenant_id=envelope.metadata.tenant_id,
                    **envelope.metadata.custom,
                )
                .build()
            )
            await self._store.update(context_id, updated_envelope)
            if self._cache:
                await self._cache.delete(f"context:{context_id}")
            await self._observable.notify(
                ContextEvent(
                    event_type="context.updated",
                    context_id=context_id,
                    tenant_id=envelope.metadata.tenant_id,
                    timestamp=datetime.now(timezone.utc),
                    payload={"updates": list(data_updates.keys())},
                )
            )
            return Ok(updated_envelope.to_context())
        except Exception as e:
            return Err(ContextError(str(e)))

    async def delete(self, context_id: str) -> Result[bool, ContextError]:
        """Delete a context."""
        try:
            envelope = await self._store.get(context_id)
            if envelope is None:
                return Err(ContextNotFoundError(context_id))
            policy_result = await self._check_policy("context.delete", envelope)
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            deleted = await self._store.delete(context_id)
            if deleted and self._cache:
                await self._cache.delete(f"context:{context_id}")
            if deleted:
                await self._observable.notify(
                    ContextEvent(
                        event_type="context.deleted",
                        context_id=context_id,
                        tenant_id=envelope.metadata.tenant_id,
                        timestamp=datetime.now(timezone.utc),
                    )
                )
            return Ok(deleted)
        except Exception as e:
            return Err(ContextError(str(e)))

    # ---------- Streaming ----------
    async def stream_updates(self, context_id: str) -> AsyncIterator[ContextEvent]:
        """Stream updates for a specific context via SSE-like iterator."""
        import asyncio
        queue: asyncio.Queue[ContextEvent] = asyncio.Queue()

        async def observer(event: ContextEvent) -> None:
            if event.context_id == context_id:
                await queue.put(event)

        self._observable.subscribe(observer)
        try:
            while True:
                event = await queue.get()
                yield event
        finally:
            self._observable.unsubscribe(observer)

    # ---------- Helpers ----------
    async def _get_schema(self, schema_name: str, tenant_id: str) -> Optional[Schema]:
        """Mock schema retrieval (placeholder)."""
        # In a real implementation this would query a SchemaRegistry
        return Schema(
            name=schema_name,
            version="1.0",
            fields={},
            required_fields=(),
        )

    async def _check_policy(self, action: str, data: Any) -> PolicyResult:
        """Placeholder policy check – always allow in tests."""
        return PolicyResult(allowed=True)

    @property
    def observable(self) -> ContextObservable:
        """Expose the observable for external subscription."""
        return self._observable
