"""
Policy Service - OPA integration for policy evaluation.
"""

import aiohttp
from typing import Any, Optional
from dataclasses import dataclass


@dataclass(frozen=True)
class PolicyResult:
    """Result of policy evaluation"""
    allowed: bool
    reason: str = ""
    metadata: dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            object.__setattr__(self, 'metadata', {})


class PolicyService:
    """
    OPA policy evaluation service.
    
    Integrates with Open Policy Agent for policy-driven governance
    and orchestration decisions.
    """
    
    def __init__(self, opa_url: str):
        """
        Initialize PolicyService.
        
        Args:
            opa_url: Base URL for OPA server (e.g., "http://opa:8181")
        """
        self._opa_url = opa_url.rstrip('/')
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        """Async context manager entry"""
        self._session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self._session:
            await self._session.close()
    
    async def evaluate(
        self,
        policy_path: str,
        input_data: Any
    ) -> PolicyResult:
        """
        Evaluate policy via OPA.
        
        Args:
            policy_path: Policy path (e.g., "context.create")
            input_data: Input data for policy evaluation
            
        Returns:
            PolicyResult with decision
        """
        if not self._session:
            self._session = aiohttp.ClientSession()
        
        # Convert policy path to OPA data path
        # "context.create" -> "/v1/data/context/create"
        opa_path = f"/v1/data/{policy_path.replace('.', '/')}"
        url = f"{self._opa_url}{opa_path}"
        
        try:
            async with self._session.post(
                url,
                json={"input": input_data},
                timeout=aiohttp.ClientTimeout(total=5.0)
            ) as resp:
                if resp.status != 200:
                    return PolicyResult(
                        allowed=False,
                        reason=f"OPA request failed: {resp.status}"
                    )
                
                result = await resp.json()
                decision = result.get("result", {})
                
                return PolicyResult(
                    allowed=decision.get("allow", False),
                    reason=decision.get("reason", ""),
                    metadata=decision.get("metadata", {})
                )
                
        except aiohttp.ClientError as e:
            return PolicyResult(
                allowed=False,
                reason=f"OPA connection error: {str(e)}"
            )
        except Exception as e:
            return PolicyResult(
                allowed=False,
                reason=f"Policy evaluation error: {str(e)}"
            )
    
    async def get_workflow_policy(self, workflow_name: str) -> dict[str, Any]:
        """
        Get workflow orchestration policy.
        
        Args:
            workflow_name: Name of the workflow
            
        Returns:
            Workflow configuration from policy
        """
        result = await self.evaluate(
            f"workflows.{workflow_name}",
            {}
        )
        return result.metadata.get("workflow_config", {})
    
    async def close(self):
        """Close HTTP session"""
        if self._session:
            await self._session.close()
            self._session = None


class MockPolicyService:
    """Mock policy service for testing (always allows)"""
    
    async def evaluate(self, policy_path: str, input_data: Any) -> PolicyResult:
        """Always allow"""
        return PolicyResult(allowed=True, reason="Mock policy - always allow")
    
    async def get_workflow_policy(self, workflow_name: str) -> dict[str, Any]:
        """Return default workflow config"""
        return {
            "strategy": "chaining",
            "max_steps": 10,
            "timeout_seconds": 300
        }
    
    async def close(self):
        """No-op for mock"""
        pass
