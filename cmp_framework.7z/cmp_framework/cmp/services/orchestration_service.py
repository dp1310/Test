"""
Orchestration Service - Policy-driven workflow execution.
"""

from typing import AsyncIterator, Optional
from cmp.core.models import Context
from cmp.orchestration.strategies import (
    Agent,
    OrchestrationStrategy,
    ChainingStrategy,
    FanOutFanInStrategy,
    EvolutionStrategy
)
from cmp.services.policy_service import PolicyService


class OrchestrationService:
    """
    Policy-driven orchestration service.
    
    Executes workflows using strategy pattern, with orchestration
    logic defined in OPA policies rather than hardcoded.
    """
    
    def __init__(
        self,
        policy_service: PolicyService,
        strategies: Optional[dict[str, OrchestrationStrategy]] = None
    ):
        """
        Initialize OrchestrationService.
        
        Args:
            policy_service: PolicyService for workflow policies
            strategies: Optional dict of strategy name -> strategy instance
        """
        self._policy_service = policy_service
        
        # Default strategies
        self._strategies: dict[str, OrchestrationStrategy] = strategies or {
            "chaining": ChainingStrategy(),
            "fan_out_fan_in": FanOutFanInStrategy(),
            "evolution": EvolutionStrategy()
        }
    
    def register_strategy(self, name: str, strategy: OrchestrationStrategy) -> None:
        """
        Register a custom orchestration strategy.
        
        Args:
            name: Strategy name
            strategy: Strategy implementation
        """
        self._strategies[name] = strategy
    
    async def execute_workflow(
        self,
        workflow_name: str,
        context: Context,
        agents: list[Agent]
    ) -> AsyncIterator[Context]:
        """
        Execute orchestration workflow.
        
        Args:
            workflow_name: Name of workflow (for policy lookup)
            context: Initial context
            agents: List of agents to execute
            
        Yields:
            Context after each orchestration step
        """
        # Get workflow policy
        policy = await self._policy_service.get_workflow_policy(workflow_name)
        
        # Determine strategy from policy
        strategy_name = policy.get("strategy", "chaining")
        strategy = self._strategies.get(strategy_name)
        
        if not strategy:
            raise ValueError(f"Unknown orchestration strategy: {strategy_name}")
        
        # Execute strategy
        async for result_context in strategy.execute(context, agents, policy):
            yield result_context
