"""
Storage layer interfaces and implementations.
"""

from abc import ABC, abstractmethod
from typing import Optional, AsyncIterator
from cmp.core.models import ContextEnvelope, Context


class ContextStore(ABC):
    """Abstract interface for context storage"""
    
    @abstractmethod
    async def save(self, envelope: ContextEnvelope) -> str:
        """
        Save context envelope and return context ID.
        
        Args:
            envelope: ContextEnvelope to save
            
        Returns:
            Context ID
        """
        pass
    
    @abstractmethod
    async def get(self, context_id: str) -> Optional[ContextEnvelope]:
        """
        Get context envelope by ID.
        
        Args:
            context_id: Context ID to retrieve
            
        Returns:
            ContextEnvelope if found, None otherwise
        """
        pass
    
    @abstractmethod
    async def search(
        self,
        query: dict,
        tenant_id: str,
        limit: int = 10
    ) -> AsyncIterator[ContextEnvelope]:
        """
        Search for contexts matching query.
        
        Args:
            query: Search query parameters
            tenant_id: Tenant ID for isolation
            limit: Maximum number of results
            
        Yields:
            Matching ContextEnvelope instances
        """
        pass
    
    @abstractmethod
    async def delete(self, context_id: str) -> bool:
        """
        Delete context by ID.
        
        Args:
            context_id: Context ID to delete
            
        Returns:
            True if deleted, False if not found
        """
        pass
    
    @abstractmethod
    async def update(self, context_id: str, envelope: ContextEnvelope) -> bool:
        """
        Update existing context.
        
        Args:
            context_id: Context ID to update
            envelope: New ContextEnvelope
            
        Returns:
            True if updated, False if not found
        """
        pass


class InMemoryContextStore(ContextStore):
    """In-memory implementation for testing"""
    
    def __init__(self):
        self._store: dict[str, ContextEnvelope] = {}
    
    async def save(self, envelope: ContextEnvelope) -> str:
        """Save context envelope"""
        self._store[envelope.id] = envelope
        return envelope.id
    
    async def get(self, context_id: str) -> Optional[ContextEnvelope]:
        """Get context envelope by ID"""
        return self._store.get(context_id)
    
    async def search(
        self,
        query: dict,
        tenant_id: str,
        limit: int = 10
    ) -> AsyncIterator[ContextEnvelope]:
        """Search for contexts"""
        count = 0
        for envelope in self._store.values():
            if envelope.metadata.tenant_id == tenant_id and count < limit:
                # Simple matching - can be enhanced
                matches = all(
                    envelope.data.get(k) == v
                    for k, v in query.items()
                )
                if matches:
                    yield envelope
                    count += 1
    
    async def delete(self, context_id: str) -> bool:
        """Delete context"""
        if context_id in self._store:
            del self._store[context_id]
            return True
        return False
    
    async def update(self, context_id: str, envelope: ContextEnvelope) -> bool:
        """Update context"""
        if context_id in self._store:
            self._store[context_id] = envelope
            return True
        return False
