"""
API routers for CMP Framework.

REST API endpoints for contexts, workflows, registries, and health checks.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from pydantic import BaseModel
from typing import Optional, List
import asyncio

from cmp import CMP
from cmp.monitoring import HealthCheck
from cmp.monitoring.metrics import get_metrics_collector
from fastapi.responses import PlainTextResponse
from .auth import get_current_user, User, require_scope


def _get_cmp(request: Request) -> CMP:
    """Helper to get CMP instance from app state."""
    return request.app.state.cmp


# ============================================================================
# Models
# ============================================================================

class ContextCreate(BaseModel):
    """Context creation request."""
    data: dict
    schema: Optional[str] = None
    metadata: Optional[dict] = None


class ContextUpdate(BaseModel):
    """Context update request."""
    data: dict


class ContextResponse(BaseModel):
    """Context response."""
    id: str
    data: dict
    schema: Optional[str] = None
    created_at: str
    updated_at: str
    version: int


class WorkflowExecute(BaseModel):
    """Workflow execution request."""
    context_id: str
    workflow_name: str


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    uptime_seconds: float
    checks: List[dict]


# ============================================================================
# Health Router
# ============================================================================

health_router = APIRouter()


@health_router.get("/live")
async def liveness():
    """Liveness probe - is the service running?"""
    health = HealthCheck()
    is_alive = await health.is_live()
    
    if not is_alive:
        raise HTTPException(status_code=503, detail="Service not alive")
    
    return {"status": "alive"}


@health_router.get("/ready")
async def readiness():
    """Readiness probe - can the service accept traffic?"""
    health = HealthCheck()
    is_ready = await health.is_ready()
    
    if not is_ready:
        raise HTTPException(status_code=503, detail="Service not ready")
    
    return {"status": "ready"}


@health_router.get("/", response_model=HealthResponse)
async def health_status():
    """Detailed health status."""
    health = HealthCheck()
    status = await health.get_health()
    
    return {
        "status": status.status.value,
        "uptime_seconds": status.uptime_seconds,
        "checks": [
            {
                "name": check.name,
                "status": check.status.value,
                "message": check.message,
                "duration_ms": check.duration_ms
            }
            for check in status.checks
        ]
    }


@health_router.get("/metrics", response_class=PlainTextResponse)
async def metrics():
    """Expose Prometheus metrics."""
    collector = get_metrics_collector()
    return collector.to_prometheus()


# ============================================================================
# Context Router
# ============================================================================

context_router = APIRouter()


@context_router.post("/", response_model=ContextResponse, status_code=status.HTTP_201_CREATED)
async def create_context(
    request: Request,
    context_data: ContextCreate,
    user: User = Depends(require_scope("context:write"))
):
    """Create a new context."""
    try:
        cmp = _get_cmp(request)
        
        builder = cmp.context().with_data(context_data.data)
        
        if context_data.schema:
            builder = builder.with_schema(context_data.schema)
        
        if context_data.metadata:
            for key, value in context_data.metadata.items():
                builder = builder.with_metadata(**{key: value})
        
        context_id = await builder.create()
        
        # Get the created context
        result = await cmp.services.get_service('context_service').get(context_id)
        if result.is_err():
            raise HTTPException(status_code=500, detail="Failed to retrieve created context")
        
        ctx = result.unwrap()
        
        return {
            "id": ctx.id,
            "data": ctx.data,
            "schema": ctx.schema,
            "created_at": ctx.created_at.isoformat(),
            "updated_at": ctx.updated_at.isoformat(),
            "version": ctx.version
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@context_router.get("/{context_id}", response_model=ContextResponse)
async def get_context(
    request: Request,
    context_id: str,
    user: User = Depends(require_scope("context:read"))
):
    """Get a context by ID."""
    try:
        cmp = _get_cmp(request)
        result = await cmp.services.get_service('context_service').get(context_id)
        
        if result.is_err():
            raise HTTPException(status_code=404, detail="Context not found")
        
        ctx = result.unwrap()
        
        return {
            "id": ctx.id,
            "data": ctx.data,
            "schema": ctx.schema,
            "created_at": ctx.created_at.isoformat(),
            "updated_at": ctx.updated_at.isoformat(),
            "version": ctx.version
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@context_router.get("/", response_model=List[ContextResponse])
async def list_contexts(
    request: Request,
    limit: int = Query(10, ge=1, le=100),
    schema: Optional[str] = None,
    user: User = Depends(require_scope("context:read"))
):
    """List contexts."""
    try:
        cmp = _get_cmp(request)
        result = await cmp.services.get_service('context_service').list(limit=limit, tenant_id=user.tenant_id)
        
        if result.is_err():
            raise HTTPException(status_code=500, detail="Failed to list contexts")
        
        contexts = result.unwrap()
        
        # Filter by schema if specified
        if schema:
            contexts = [ctx for ctx in contexts if ctx.schema == schema]
        
        return [
            {
                "id": ctx.id,
                "data": ctx.data,
                "schema": ctx.schema,
                "created_at": ctx.created_at.isoformat(),
                "updated_at": ctx.updated_at.isoformat(),
                "version": ctx.version
            }
            for ctx in contexts[:limit]
        ]
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@context_router.put("/{context_id}", response_model=ContextResponse)
async def update_context(
    request: Request,
    context_id: str,
    context_data: ContextUpdate,
    user: User = Depends(require_scope("context:write"))
):
    """Update a context."""
    try:
        cmp = _get_cmp(request)
        result = await cmp.services.get_service('context_service').update(
            context_id,
            context_data.data
        )
        
        if result.is_err():
            raise HTTPException(status_code=404, detail="Context not found")
        
        ctx = result.unwrap()
        
        return {
            "id": ctx.id,
            "data": ctx.data,
            "schema": ctx.schema,
            "created_at": ctx.created_at.isoformat(),
            "updated_at": ctx.updated_at.isoformat(),
            "version": ctx.version
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@context_router.delete("/{context_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_context(
    request: Request,
    context_id: str,
    user: User = Depends(require_scope("context:write"))
):
    """Delete a context."""
    try:
        cmp = _get_cmp(request)
        result = await cmp.services.get_service('context_service').delete(context_id)
        
        if result.is_err():
            raise HTTPException(status_code=404, detail="Context not found")
        
        return None
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# Workflow Router
# ============================================================================

workflow_router = APIRouter()


@workflow_router.post("/execute")
async def execute_workflow(
    request: Request,
    workflow_data: WorkflowExecute,
    user: User = Depends(require_scope("workflow:execute"))
):
    """Execute a workflow."""
    try:
        cmp = _get_cmp(request)
        
        results = []
        async for result in cmp.workflow(workflow_data.workflow_name).with_context(workflow_data.context_id).execute():
            results.append({
                "id": result.id,
                "data": result.data
            })
        
        return {
            "workflow": workflow_data.workflow_name,
            "context_id": workflow_data.context_id,
            "steps": len(results),
            "results": results
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# Registry Router
# ============================================================================

registry_router = APIRouter()


@registry_router.get("/schemas")
async def list_schemas(
    user: User = Depends(require_scope("registry:read"))
):
    """List registered schemas."""
    from cmp.registries import SchemaRegistry, create_backend
    
    try:
        backend = create_backend("file", base_path="./data/registries")
        registry = SchemaRegistry(backend=backend)
        result = await registry.list_schemas()
        await registry.close()
        
        if result.is_err():
            raise HTTPException(status_code=500, detail="Failed to list schemas")
        
        schemas = result.unwrap()
        
        return {
            "schemas": [
                {
                    "schema_id": schema.schema_id,
                    "version": schema.version,
                    "description": schema.description,
                    "deprecated": schema.deprecated
                }
                for schema in schemas
            ]
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@registry_router.get("/policies")
async def list_policies(
    user: User = Depends(require_scope("registry:read"))
):
    """List registered policies."""
    from cmp.registries import PolicyRegistry, create_backend
    
    try:
        backend = create_backend("file", base_path="./data/registries")
        registry = PolicyRegistry(backend=backend)
        result = await registry.list_policies()
        await registry.close()
        
        if result.is_err():
            raise HTTPException(status_code=500, detail="Failed to list policies")
        
        policies = result.unwrap()
        
        return {
            "policies": [
                {
                    "policy_id": policy.policy_id,
                    "version": policy.version,
                    "description": policy.description,
                    "deployed": policy.deployed
                }
                for policy in policies
            ]
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
