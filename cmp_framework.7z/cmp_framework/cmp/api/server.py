"""
CMP Framework API Server.

FastAPI-based REST API for CMP Framework operations.
"""

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import uvicorn

from cmp.config import get_config, CMPConfig
from cmp.monitoring import configure_logging, configure_tracing, HealthCheck
from cmp import CMP

from .routers import context_router, workflow_router, registry_router, health_router
from .middleware import RateLimitMiddleware, LoggingMiddleware
from .auth import get_current_user


# Lifespan context manager for startup/shutdown
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handle startup and shutdown events."""
    # Startup
    config = get_config()
    
    # Configure monitoring
    configure_logging(
        level=config.monitoring.log_level,
        format_type="json" if config.environment == "production" else "text"
    )
    
    if config.monitoring.tracing_enabled:
        configure_tracing(
            service_name="cmp-api",
            jaeger_endpoint=config.monitoring.jaeger_endpoint,
            enabled=True
        )
    
    print(f"🚀 CMP API Server starting (environment: {config.environment})")
    yield
    
    # Shutdown
    print("👋 CMP API Server shutting down")


# Create FastAPI app
def create_app(config: CMPConfig = None) -> FastAPI:
    """Create and configure FastAPI application."""
    if config is None:
        config = get_config()
    
    app = FastAPI(
        title="CMP Framework API",
        description="Context Management Plane - REST API for managing contexts, workflows, and registries",
        version="0.1.0",
        docs_url="/docs" if config.api.enable_docs else None,
        redoc_url="/redoc" if config.api.enable_docs else None,
        lifespan=lifespan
    )
    
    # Store CMP instance in app state for sharing across endpoints
    app.state.cmp = CMP(tenant_id="default")
    
    # CORS middleware
    if config.api.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=config.api.cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    
    # Custom middleware
    app.add_middleware(LoggingMiddleware)
    
    if config.api.rate_limit_enabled:
        app.add_middleware(
            RateLimitMiddleware,
            requests_per_minute=config.api.rate_limit_per_minute
        )
    
    # Include routers
    app.include_router(health_router, prefix="/health", tags=["health"])
    app.include_router(context_router, prefix="/api/v1/contexts", tags=["contexts"])
    app.include_router(workflow_router, prefix="/api/v1/workflows", tags=["workflows"])
    app.include_router(registry_router, prefix="/api/v1/registry", tags=["registry"])
    
    # GraphQL endpoint (optional)
    if getattr(config.api, 'enable_graphql', True):
        from .graphql import add_graphql_route
        add_graphql_route(app, path="/graphql")
    
    # Root endpoint
    @app.get("/")
    async def root():
        """API root endpoint."""
        return {
            "name": "CMP Framework API",
            "version": "0.1.0",
            "status": "running",
            "docs": "/docs" if config.api.enable_docs else None
        }
    
    # Global exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request, exc):
        """Handle uncaught exceptions."""
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "Internal server error", "error": str(exc)}
        )
    
    return app


# Create app instance
app = create_app()


def run_server(
    host: str = "0.0.0.0",
    port: int = 8000,
    reload: bool = False,
    workers: int = 1
):
    """Run the API server."""
    uvicorn.run(
        "cmp.api.server:app",
        host=host,
        port=port,
        reload=reload,
        workers=workers,
        log_level="info"
    )


if __name__ == "__main__":
    config = get_config()
    run_server(
        host=config.api.host,
        port=config.api.port,
        workers=config.api.workers
    )
