"""GraphQL API integration for FastAPI."""

from fastapi import FastAPI
from strawberry.fastapi import GraphQLRouter
from .schema import schema


def add_graphql_route(app: FastAPI, path: str = "/graphql"):
    """
    Add GraphQL route to FastAPI application.
    
    Args:
        app: FastAPI application instance
        path: GraphQL endpoint path
    """
    graphql_app = GraphQLRouter(schema)
    app.include_router(graphql_app, prefix=path)
