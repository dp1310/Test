"""
GraphQL schema definitions for CMP Framework.

Provides GraphQL types for Context, Workflow, and Registry operations.
"""

import strawberry
from typing import Optional, List, Any
from datetime import datetime, timezone
import json


def _get_cmp(info: strawberry.Info):
    """Get the CMP instance from the app state."""
    # During tests or if info.context is not available, we might need a fallback
    # but in FastAPI/Strawberry integration, info.context is the FastAPI request
    if hasattr(info.context, "app"):
        return info.context.app.state.cmp
    
    # Fallback for direct schema usage/tests (should be initialized by the caller)
    from cmp import CMP
    if not hasattr(Query, "_test_cmp"):
        Query._test_cmp = CMP(tenant_id="default")
    return Query._test_cmp


@strawberry.type
class Context:
    """GraphQL Context type."""
    
    id: str
    data: strawberry.scalars.JSON
    schema: Optional[str]
    created_at: datetime
    updated_at: datetime
    version: int
    tenant_id: str


@strawberry.type
class WorkflowResult:
    """GraphQL Workflow execution result."""
    
    id: str
    workflow_name: str
    context_id: str
    status: str
    steps_completed: int
    results: List[strawberry.scalars.JSON]


@strawberry.type
class SchemaInfo:
    """GraphQL Schema information."""
    
    schema_id: str
    version: str
    description: str
    deprecated: bool


@strawberry.type
class PolicyInfo:
    """GraphQL Policy information."""
    
    policy_id: str
    version: str
    description: str
    deployed: bool


@strawberry.input
class ContextInput:
    """Input type for creating contexts."""
    
    data: strawberry.scalars.JSON
    schema: Optional[str] = None
    tenant_id: str = "default"


@strawberry.input
class ContextUpdateInput:
    """Input type for updating contexts."""
    
    data: strawberry.scalars.JSON


@strawberry.input
class WorkflowExecuteInput:
    """Input type for executing workflows."""
    
    workflow_name: str
    context_id: str
    tenant_id: str = "default"


@strawberry.type
class Query:
    """GraphQL Query root."""
    
    @strawberry.field
    async def context(
        self,
        id: str,
        tenant_id: str = "default",
        info: strawberry.Info = None
    ) -> Optional[Context]:
        """Get a context by ID."""
        cmp = _get_cmp(info)
        result = await cmp.services.get_service('context_service').get(id)
        
        if result.is_err():
            return None
        
        ctx = result.unwrap()
        
        return Context(
            id=ctx.id,
            data=ctx.data,
            schema=getattr(ctx, 'schema', None),
            created_at=getattr(ctx, 'created_at', datetime.now(timezone.utc)),
            updated_at=getattr(ctx, 'updated_at', datetime.now(timezone.utc)),
            version=getattr(ctx, 'version', 1),
            tenant_id=tenant_id
        )
    
    @strawberry.field
    async def contexts(
        self,
        limit: int = 10,
        tenant_id: str = "default",
        info: strawberry.Info = None
    ) -> List[Context]:
        """List contexts."""
        cmp = _get_cmp(info)
        result = await cmp.services.get_service('context_service').list(limit=limit, tenant_id=tenant_id)
        
        if result.is_err():
            return []
        
        contexts = result.unwrap()
        
        return [
            Context(
                id=ctx.id,
                data=ctx.data,
                schema=getattr(ctx, 'schema', None),
                created_at=getattr(ctx, 'created_at', datetime.now(timezone.utc)),
                updated_at=getattr(ctx, 'updated_at', datetime.now(timezone.utc)),
                version=getattr(ctx, 'version', 1),
                tenant_id=tenant_id
            )
            for ctx in contexts[:limit]
        ]
    
    @strawberry.field
    async def schemas(self, info: strawberry.Info) -> List[SchemaInfo]:
        """List registered schemas."""
        from cmp.registries import SchemaRegistry, create_backend
        
        backend = create_backend("file", base_path="./data/registries")
        registry = SchemaRegistry(backend=backend)
        result = await registry.list_schemas()
        await registry.close()
        
        if result.is_err():
            return []
        
        schemas = result.unwrap()
        
        return [
            SchemaInfo(
                schema_id=schema.schema_id,
                version=schema.version,
                description=schema.description,
                deprecated=schema.deprecated
            )
            for schema in schemas
        ]
    
    @strawberry.field
    async def policies(self, info: strawberry.Info) -> List[PolicyInfo]:
        """List registered policies."""
        from cmp.registries import PolicyRegistry, create_backend
        
        backend = create_backend("file", base_path="./data/registries")
        registry = PolicyRegistry(backend=backend)
        result = await registry.list_policies()
        await registry.close()
        
        if result.is_err():
            return []
        
        policies = result.unwrap()
        
        return [
            PolicyInfo(
                policy_id=policy.policy_id,
                version=policy.version,
                description=policy.description,
                deployed=policy.deployed
            )
            for policy in policies
        ]


@strawberry.type
class Mutation:
    """GraphQL Mutation root."""
    
    @strawberry.mutation
    async def create_context(
        self,
        input: ContextInput,
        info: strawberry.Info
    ) -> Context:
        """Create a new context."""
        cmp = _get_cmp(info)
        
        builder = cmp.context().with_data(input.data)
        
        if input.schema:
            builder = builder.with_schema(input.schema)
        
        context_id = await builder.create()
        
        # Get the created context
        result = await cmp.services.get_service('context_service').get(context_id)
        ctx = result.unwrap()
        
        # Defensive check
        import logging
        if not hasattr(ctx, 'schema'):
            logging.error(f"FATAL: ctx object of type {type(ctx)} is missing 'schema' attribute!")
            logging.error(f"Attributes: {dir(ctx)}")
        
        return Context(
            id=ctx.id,
            data=ctx.data,
            schema=getattr(ctx, 'schema', None),
            created_at=getattr(ctx, 'created_at', datetime.now(timezone.utc)),
            updated_at=getattr(ctx, 'updated_at', datetime.now(timezone.utc)),
            version=getattr(ctx, 'version', 1),
            tenant_id=input.tenant_id
        )
    
    @strawberry.mutation
    async def update_context(
        self,
        id: str,
        input: ContextUpdateInput,
        tenant_id: str,
        info: strawberry.Info = None
    ) -> Optional[Context]:
        """Update a context."""
        cmp = _get_cmp(info)
        result = await cmp.services.get_service('context_service').update(
            id,
            input.data
        )
        
        if result.is_err():
            return None
        
        ctx = result.unwrap()
        
        return Context(
            id=ctx.id,
            data=ctx.data,
            schema=getattr(ctx, 'schema', None),
            created_at=getattr(ctx, 'created_at', datetime.now(timezone.utc)),
            updated_at=getattr(ctx, 'updated_at', datetime.now(timezone.utc)),
            version=getattr(ctx, 'version', 1),
            tenant_id=tenant_id
        )
    
    @strawberry.mutation
    async def delete_context(
        self,
        id: str,
        tenant_id: str,
        info: strawberry.Info = None
    ) -> bool:
        """Delete a context."""
        cmp = _get_cmp(info)
        result = await cmp.services.get_service('context_service').delete(id)
        
        return result.is_ok() and result.unwrap()
    
    @strawberry.mutation
    async def execute_workflow(
        self,
        input: WorkflowExecuteInput,
        info: strawberry.Info
    ) -> WorkflowResult:
        """Execute a workflow."""
        cmp = _get_cmp(info)
        
        results = []
        async for result in cmp.workflow(input.workflow_name).with_context(input.context_id).execute():
            results.append({
                "id": result.id,
                "data": result.data
            })
        
        return WorkflowResult(
            id=f"wf_{input.workflow_name}_{input.context_id}",
            workflow_name=input.workflow_name,
            context_id=input.context_id,
            status="completed",
            steps_completed=len(results),
            results=results
        )


@strawberry.type
class Subscription:
    """GraphQL Subscription root."""
    
    @strawberry.subscription
    async def context_updated(
        self,
        id: str,
        tenant_id: str,
        info: strawberry.Info = None
    ) -> Context:
        """Subscribe to context updates."""
        import asyncio
        
        cmp = _get_cmp(info)
        service = cmp.services.get_service('context_service')
        
        # Stream updates for this context
        async for event in service.stream_updates(id):
            # Get updated context
            result = await service.get(id)
            if result.is_ok():
                ctx = result.unwrap()
                yield Context(
                    id=ctx.id,
                    data=ctx.data,
                    schema=getattr(ctx, 'schema', None),
                    created_at=getattr(ctx, 'created_at', datetime.now(timezone.utc)),
                    updated_at=getattr(ctx, 'updated_at', datetime.now(timezone.utc)),
                    version=getattr(ctx, 'version', 1),
                    tenant_id=tenant_id
                )


# Create schema
schema = strawberry.Schema(
    query=Query,
    mutation=Mutation,
    subscription=Subscription
)
