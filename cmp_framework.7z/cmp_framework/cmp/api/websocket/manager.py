"""
WebSocket connection manager for real-time updates.

Manages WebSocket connections, broadcasting, and message routing.
"""

from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, Set, Optional
import json
import asyncio
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class ConnectionManager:
    """
    WebSocket connection manager.
    
    Manages multiple WebSocket connections with support for:
    - Connection pooling
    - Message broadcasting
    - Channel subscriptions
    - Heartbeat/keepalive
    """
    
    def __init__(self):
        """Initialize connection manager."""
        # Active connections: {connection_id: WebSocket}
        self.active_connections: Dict[str, WebSocket] = {}
        
        # Channel subscriptions: {channel: set of connection_ids}
        self.subscriptions: Dict[str, Set[str]] = {}
        
        # Connection metadata: {connection_id: metadata}
        self.metadata: Dict[str, dict] = {}
    
    async def connect(
        self,
        websocket: WebSocket,
        connection_id: str,
        tenant_id: str = "default"
    ):
        """
        Accept and register a new WebSocket connection.
        
        Args:
            websocket: WebSocket connection
            connection_id: Unique connection identifier
            tenant_id: Tenant ID for isolation
        """
        await websocket.accept()
        self.active_connections[connection_id] = websocket
        self.metadata[connection_id] = {
            "tenant_id": tenant_id,
            "connected_at": datetime.utcnow().isoformat(),
            "channels": set()
        }
        logger.info(f"WebSocket connected: {connection_id} (tenant: {tenant_id})")
    
    def disconnect(self, connection_id: str):
        """
        Disconnect and cleanup a WebSocket connection.
        
        Args:
            connection_id: Connection identifier
        """
        # Remove from all subscriptions
        if connection_id in self.metadata:
            channels = self.metadata[connection_id].get("channels", set())
            for channel in channels:
                if channel in self.subscriptions:
                    self.subscriptions[channel].discard(connection_id)
        
        # Remove connection
        self.active_connections.pop(connection_id, None)
        self.metadata.pop(connection_id, None)
        logger.info(f"WebSocket disconnected: {connection_id}")
    
    async def subscribe(self, connection_id: str, channel: str):
        """
        Subscribe a connection to a channel.
        
        Args:
            connection_id: Connection identifier
            channel: Channel name
        """
        if channel not in self.subscriptions:
            self.subscriptions[channel] = set()
        
        self.subscriptions[channel].add(connection_id)
        
        if connection_id in self.metadata:
            self.metadata[connection_id]["channels"].add(channel)
        
        logger.debug(f"Connection {connection_id} subscribed to {channel}")
    
    async def unsubscribe(self, connection_id: str, channel: str):
        """
        Unsubscribe a connection from a channel.
        
        Args:
            connection_id: Connection identifier
            channel: Channel name
        """
        if channel in self.subscriptions:
            self.subscriptions[channel].discard(connection_id)
        
        if connection_id in self.metadata:
            self.metadata[connection_id]["channels"].discard(channel)
        
        logger.debug(f"Connection {connection_id} unsubscribed from {channel}")
    
    async def send_personal_message(self, message: dict, connection_id: str):
        """
        Send message to a specific connection.
        
        Args:
            message: Message dictionary
            connection_id: Target connection identifier
        """
        if connection_id in self.active_connections:
            websocket = self.active_connections[connection_id]
            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.error(f"Error sending to {connection_id}: {e}")
                self.disconnect(connection_id)
    
    async def broadcast(self, message: dict, channel: Optional[str] = None):
        """
        Broadcast message to all connections or specific channel.
        
        Args:
            message: Message dictionary
            channel: Optional channel name (broadcasts to all if None)
        """
        if channel:
            # Broadcast to channel subscribers
            if channel in self.subscriptions:
                connection_ids = list(self.subscriptions[channel])
                for connection_id in connection_ids:
                    await self.send_personal_message(message, connection_id)
        else:
            # Broadcast to all connections
            connection_ids = list(self.active_connections.keys())
            for connection_id in connection_ids:
                await self.send_personal_message(message, connection_id)
    
    async def send_heartbeat(self, connection_id: str):
        """
        Send heartbeat/ping to connection.
        
        Args:
            connection_id: Connection identifier
        """
        await self.send_personal_message(
            {"type": "heartbeat", "timestamp": datetime.utcnow().isoformat()},
            connection_id
        )
    
    def get_stats(self) -> dict:
        """Get connection statistics."""
        return {
            "total_connections": len(self.active_connections),
            "total_channels": len(self.subscriptions),
            "connections_per_channel": {
                channel: len(subs)
                for channel, subs in self.subscriptions.items()
            }
        }


# Global connection manager instance
manager = ConnectionManager()


async def handle_websocket(
    websocket: WebSocket,
    connection_id: str,
    tenant_id: str = "default"
):
    """
    Handle WebSocket connection lifecycle.
    
    Args:
        websocket: WebSocket connection
        connection_id: Unique connection identifier
        tenant_id: Tenant ID for isolation
    """
    await manager.connect(websocket, connection_id, tenant_id)
    
    try:
        while True:
            # Receive message
            data = await websocket.receive_json()
            
            message_type = data.get("type")
            
            if message_type == "subscribe":
                # Subscribe to channel
                channel = data.get("channel")
                if channel:
                    await manager.subscribe(connection_id, channel)
                    await manager.send_personal_message(
                        {
                            "type": "subscribed",
                            "channel": channel,
                            "timestamp": datetime.utcnow().isoformat()
                        },
                        connection_id
                    )
            
            elif message_type == "unsubscribe":
                # Unsubscribe from channel
                channel = data.get("channel")
                if channel:
                    await manager.unsubscribe(connection_id, channel)
                    await manager.send_personal_message(
                        {
                            "type": "unsubscribed",
                            "channel": channel,
                            "timestamp": datetime.utcnow().isoformat()
                        },
                        connection_id
                    )
            
            elif message_type == "ping":
                # Respond to ping
                await manager.send_personal_message(
                    {"type": "pong", "timestamp": datetime.utcnow().isoformat()},
                    connection_id
                )
    
    except WebSocketDisconnect:
        manager.disconnect(connection_id)
    except Exception as e:
        logger.error(f"WebSocket error for {connection_id}: {e}")
        manager.disconnect(connection_id)
