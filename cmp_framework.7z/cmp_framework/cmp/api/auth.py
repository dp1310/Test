"""
Authentication and authorization for CMP API.

JWT-based authentication with optional API key support.
"""

from datetime import datetime, timedelta
from typing import Optional
from fastapi import Depends, HTTPException, status, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, APIKeyHeader
from jose import JWTError, jwt
from pydantic import BaseModel

from cmp.config import get_config


# Security schemes
security = HTTPBearer()
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


class TokenData(BaseModel):
    """JWT token data."""
    username: str
    tenant_id: str
    scopes: list[str] = []


class User(BaseModel):
    """User model."""
    username: str
    tenant_id: str
    scopes: list[str] = []
    disabled: bool = False


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Create JWT access token.
    
    Args:
        data: Token payload data
        expires_delta: Token expiration time
        
    Returns:
        Encoded JWT token
    """
    config = get_config()
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=config.security.jwt_expiration_minutes)
    
    to_encode.update({"exp": expire})
    
    encoded_jwt = jwt.encode(
        to_encode,
        config.security.jwt_secret,
        algorithm=config.security.jwt_algorithm
    )
    
    return encoded_jwt


def verify_token(token: str) -> TokenData:
    """
    Verify and decode JWT token.
    
    Args:
        token: JWT token string
        
    Returns:
        TokenData with user information
        
    Raises:
        HTTPException: If token is invalid
    """
    config = get_config()
    
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(
            token,
            config.security.jwt_secret,
            algorithms=[config.security.jwt_algorithm]
        )
        
        username: str = payload.get("sub")
        tenant_id: str = payload.get("tenant_id")
        scopes: list = payload.get("scopes", [])
        
        if username is None or tenant_id is None:
            raise credentials_exception
        
        return TokenData(username=username, tenant_id=tenant_id, scopes=scopes)
    
    except JWTError:
        raise credentials_exception


def verify_api_key(api_key: str) -> bool:
    """
    Verify API key.
    
    Args:
        api_key: API key string
        
    Returns:
        True if valid, False otherwise
    """
    config = get_config()
    
    # Simple API key validation (in production, use database)
    valid_keys = config.security.api_keys
    return api_key in valid_keys


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(security),
    api_key: Optional[str] = Security(api_key_header)
) -> User:
    """
    Get current authenticated user.
    
    Supports both JWT and API key authentication.
    
    Args:
        credentials: HTTP Bearer credentials (JWT)
        api_key: API key from header
        
    Returns:
        User object
        
    Raises:
        HTTPException: If authentication fails
    """
    config = get_config()
    
    # Skip authentication if disabled
    if not config.security.authentication_enabled:
        return User(
            username="anonymous",
            tenant_id="default",
            scopes=["*"]
        )
    
    # Try API key first
    if api_key and verify_api_key(api_key):
        return User(
            username="api_key_user",
            tenant_id="default",
            scopes=["*"]
        )
    
    # Try JWT
    if credentials:
        token_data = verify_token(credentials.credentials)
        return User(
            username=token_data.username,
            tenant_id=token_data.tenant_id,
            scopes=token_data.scopes
        )
    
    # No valid authentication
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Bearer"},
    )


def require_scope(required_scope: str):
    """
    Dependency to require specific scope.
    
    Args:
        required_scope: Required scope string
        
    Returns:
        Dependency function
    """
    async def scope_checker(user: User = Depends(get_current_user)):
        if "*" in user.scopes or required_scope in user.scopes:
            return user
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Insufficient permissions. Required scope: {required_scope}"
        )
    
    return scope_checker
