"""
CMP - Context Management Plane

A Python framework for managing context in agentic systems with policy-driven orchestration.
"""

__version__ = "0.1.0"

from cmp.sdk.client import CMP
from cmp.sdk.agent import Agent
from cmp.di.decorators import context, knowledge

__all__ = ["CMP", "Agent", "context", "knowledge"]
