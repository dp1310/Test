"""
Monitoring and metrics CLI commands.

Commands for viewing metrics, health status, and logs.
"""

import typer
import asyncio
from rich.console import Console
from rich.table import Table

from cmp.monitoring import HealthCheck, get_metrics_collector

monitor_app = typer.Typer(help="Monitoring and metrics commands")
console = Console()


@monitor_app.command("health")
def health_status(
    detailed: bool = typer.Option(False, "--detailed", "-d", help="Show detailed health info"),
):
    """Check system health status."""
    try:
        async def _check():
            health = HealthCheck()
            return await health.get_health()
        
        status = asyncio.run(_check())
        
        # Overall status
        status_color = "green" if status.is_healthy else ("yellow" if status.is_ready else "red")
        console.print(f"\n[bold]System Status:[/bold] [{status_color}]{status.status.value.upper()}[/{status_color}]")
        console.print(f"[bold]Uptime:[/bold] {status.uptime_seconds:.2f} seconds")
        
        if detailed:
            # Detailed checks
            table = Table(title="Health Checks")
            table.add_column("Check", style="cyan")
            table.add_column("Status")
            table.add_column("Message")
            table.add_column("Duration (ms)")
            
            for check in status.checks:
                status_style = "green" if check.status.value == "healthy" else ("yellow" if check.status.value == "degraded" else "red")
                table.add_row(
                    check.name,
                    f"[{status_style}]{check.status.value}[/{status_style}]",
                    check.message,
                    f"{check.duration_ms:.2f}"
                )
            
            console.print("\n")
            console.print(table)
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@monitor_app.command("metrics")
def show_metrics(
    format_type: str = typer.Option("table", "--format", "-f", help="Output format (table|prometheus|json)"),
):
    """Show system metrics."""
    try:
        metrics = get_metrics_collector()
        
        if format_type == "prometheus":
            # Prometheus format
            from prometheus_client import generate_latest
            output = generate_latest(metrics.registry).decode('utf-8')
            console.print(output)
        elif format_type == "json":
            # JSON format
            import json
            metrics_dict = {
                "contexts_created": metrics.contexts_created._value.get(),
                "contexts_retrieved": metrics.contexts_retrieved._value.get(),
                "contexts_updated": metrics.contexts_updated._value.get(),
                "contexts_deleted": metrics.contexts_deleted._value.get(),
                "workflows_executed": metrics.workflows_executed._value.get(),
                "errors": metrics.errors._value.get(),
            }
            console.print(json.dumps(metrics_dict, indent=2))
        else:
            # Table format
            table = Table(title="System Metrics")
            table.add_column("Metric", style="cyan")
            table.add_column("Value", style="green")
            
            table.add_row("Contexts Created", str(metrics.contexts_created._value.get()))
            table.add_row("Contexts Retrieved", str(metrics.contexts_retrieved._value.get()))
            table.add_row("Contexts Updated", str(metrics.contexts_updated._value.get()))
            table.add_row("Contexts Deleted", str(metrics.contexts_deleted._value.get()))
            table.add_row("Workflows Executed", str(metrics.workflows_executed._value.get()))
            table.add_row("Errors", str(metrics.errors._value.get()))
            
            console.print(table)
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@monitor_app.command("logs")
def view_logs(
    level: str = typer.Option("INFO", "--level", "-l", help="Log level filter"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
):
    """View application logs."""
    console.print("[yellow]Log viewing not yet implemented[/yellow]")
    console.print(f"Level: {level}, Follow: {follow}")
    console.print("\nTo view logs, check your configured log output file or use:")
    console.print("  journalctl -u cmp-framework -f")
    console.print("  docker logs -f cmp-framework")
