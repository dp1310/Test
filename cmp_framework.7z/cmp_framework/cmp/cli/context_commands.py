"""
Context management CLI commands.

Commands for creating, reading, updating, and deleting contexts.
"""

import typer
import asyncio
import json
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.syntax import Syntax
from pathlib import Path

from cmp import CMP
from cmp.config import CMPConfig, get_config

# Create context app
context_app = typer.Typer(help="Context management commands")
console = Console()


def get_cmp_client(tenant_id: str, config_file: Optional[str] = None) -> CMP:
    """Get CMP client instance."""
    if config_file:
        config = CMPConfig.from_yaml(config_file)
    else:
        config = get_config()
    
    return CMP(tenant_id=tenant_id)


@context_app.command("create")
def create_context(
    data: str = typer.Option(..., "--data", "-d", help="Context data as JSON string"),
    schema: Optional[str] = typer.Option(None, "--schema", "-s", help="Schema ID"),
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
    metadata: Optional[str] = typer.Option(None, "--metadata", "-m", help="Metadata as JSON string"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Create a new context."""
    try:
        # Parse data
        data_dict = json.loads(data)
        
        # Parse metadata if provided
        metadata_dict = json.loads(metadata) if metadata else {}
        
        # Create CMP client
        cmp = get_cmp_client(tenant_id, config_file)
        
        # Create context
        async def _create():
            builder = cmp.context().with_data(data_dict)
            
            if schema:
                builder = builder.with_schema(schema)
            
            if metadata_dict:
                for key, value in metadata_dict.items():
                    builder = builder.with_metadata(**{key: value})
            
            return await builder.create()
        
        context_id = asyncio.run(_create())
        
        console.print(f"[green]✓[/green] Context created: [cyan]{context_id}[/cyan]")
        
    except json.JSONDecodeError as e:
        console.print(f"[red]✗[/red] Invalid JSON: {e}", style="bold red")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@context_app.command("get")
def get_context(
    context_id: str = typer.Argument(..., help="Context ID"),
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
    output_format: str = typer.Option("table", "--format", "-f", help="Output format (table|json|yaml)"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Get a context by ID."""
    try:
        cmp = get_cmp_client(tenant_id, config_file)
        
        async def _get():
            result = await cmp.services.get_service('context_service').get(context_id)
            return result
        
        result = asyncio.run(_get())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Context not found: {context_id}", style="bold red")
            raise typer.Exit(1)
        
        context = result.unwrap()
        
        if output_format == "json":
            console.print(Syntax(json.dumps(context.to_dict(), indent=2), "json"))
        elif output_format == "yaml":
            import yaml
            console.print(Syntax(yaml.dump(context.to_dict()), "yaml"))
        else:
            # Table format
            table = Table(title=f"Context: {context_id}")
            table.add_column("Field", style="cyan")
            table.add_column("Value")
            
            table.add_row("ID", context.id)
            table.add_row("Schema", context.schema or "None")
            table.add_row("Created", context.provenance.created_at)
            table.add_row("Updated", context.provenance.updated_at)
            table.add_row("Version", str(context.provenance.version))
            
            console.print(table)
            
            # Data
            console.print("\n[bold]Data:[/bold]")
            console.print(Syntax(json.dumps(context.data, indent=2), "json"))
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@context_app.command("list")
def list_contexts(
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum number of contexts"),
    schema: Optional[str] = typer.Option(None, "--schema", "-s", help="Filter by schema"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """List contexts."""
    try:
        cmp = get_cmp_client(tenant_id, config_file)
        
        async def _list():
            result = await cmp.services.get_service('context_service').list(limit=limit)
            return result
        
        result = asyncio.run(_list())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Error listing contexts", style="bold red")
            raise typer.Exit(1)
        
        contexts = result.unwrap()
        
        # Filter by schema if specified
        if schema:
            contexts = [ctx for ctx in contexts if ctx.schema == schema]
        
        if not contexts:
            console.print("[yellow]No contexts found[/yellow]")
            return
        
        # Display table
        table = Table(title=f"Contexts (showing {len(contexts)})")
        table.add_column("ID", style="cyan")
        table.add_column("Schema")
        table.add_column("Created")
        table.add_column("Version")
        
        for ctx in contexts[:limit]:
            table.add_row(
                ctx.id[:16] + "...",
                ctx.schema or "None",
                ctx.provenance.created_at[:19],
                str(ctx.provenance.version)
            )
        
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@context_app.command("update")
def update_context(
    context_id: str = typer.Argument(..., help="Context ID"),
    data: str = typer.Option(..., "--data", "-d", help="New context data as JSON string"),
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Update a context."""
    try:
        data_dict = json.loads(data)
        cmp = get_cmp_client(tenant_id, config_file)
        
        async def _update():
            result = await cmp.services.get_service('context_service').update(context_id, data_dict)
            return result
        
        result = asyncio.run(_update())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Failed to update context: {result.unwrap_err()}", style="bold red")
            raise typer.Exit(1)
        
        console.print(f"[green]✓[/green] Context updated: [cyan]{context_id}[/cyan]")
        
    except json.JSONDecodeError as e:
        console.print(f"[red]✗[/red] Invalid JSON: {e}", style="bold red")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@context_app.command("delete")
def delete_context(
    context_id: str = typer.Argument(..., help="Context ID"),
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
    confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Delete a context."""
    try:
        if not confirm:
            confirm_delete = typer.confirm(f"Delete context {context_id}?")
            if not confirm_delete:
                console.print("[yellow]Cancelled[/yellow]")
                return
        
        cmp = get_cmp_client(tenant_id, config_file)
        
        async def _delete():
            result = await cmp.services.get_service('context_service').delete(context_id)
            return result
        
        result = asyncio.run(_delete())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Failed to delete context", style="bold red")
            raise typer.Exit(1)
        
        console.print(f"[green]✓[/green] Context deleted: [cyan]{context_id}[/cyan]")
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@context_app.command("search")
def search_contexts(
    query: str = typer.Argument(..., help="Search query"),
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Search contexts."""
    try:
        cmp = get_cmp_client(tenant_id, config_file)
        
        async def _search():
            # Simple search implementation
            result = await cmp.services.get_service('context_service').list(limit=limit * 2)
            return result
        
        result = asyncio.run(_search())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Search failed", style="bold red")
            raise typer.Exit(1)
        
        contexts = result.unwrap()
        
        # Simple text search in data
        matching = []
        for ctx in contexts:
            ctx_str = json.dumps(ctx.data).lower()
            if query.lower() in ctx_str:
                matching.append(ctx)
        
        matching = matching[:limit]
        
        if not matching:
            console.print(f"[yellow]No contexts found matching '{query}'[/yellow]")
            return
        
        table = Table(title=f"Search Results: '{query}' ({len(matching)} found)")
        table.add_column("ID", style="cyan")
        table.add_column("Schema")
        table.add_column("Match Preview")
        
        for ctx in matching:
            preview = json.dumps(ctx.data)[:50] + "..."
            table.add_row(
                ctx.id[:16] + "...",
                ctx.schema or "None",
                preview
            )
        
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@context_app.command("export")
def export_context(
    context_id: str = typer.Argument(..., help="Context ID"),
    output_file: str = typer.Option(..., "--output", "-o", help="Output file path"),
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
    format_type: str = typer.Option("json", "--format", "-f", help="Format (json|yaml)"),
    config_file: Optional[str] = typer.Option(None, "--config", "-c", help="Config file path"),
):
    """Export a context to file."""
    try:
        cmp = get_cmp_client(tenant_id, config_file)
        
        async def _get():
            result = await cmp.services.get_service('context_service').get(context_id)
            return result
        
        result = asyncio.run(_get())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Context not found", style="bold red")
            raise typer.Exit(1)
        
        context = result.unwrap()
        output_path = Path(output_file)
        
        if format_type == "yaml":
            import yaml
            content = yaml.dump(context.to_dict())
        else:
            content = json.dumps(context.to_dict(), indent=2)
        
        output_path.write_text(content)
        
        console.print(f"[green]✓[/green] Context exported to: [cyan]{output_file}[/cyan]")
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)
