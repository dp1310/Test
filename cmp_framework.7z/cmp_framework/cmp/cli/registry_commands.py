"""
Registry management CLI commands.

Commands for managing schemas, policies, and knowledge sources.
"""

import typer
import asyncio
import json
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.syntax import Syntax
from pathlib import Path

from cmp.registries import SchemaRegistry, PolicyRegistry, KnowledgeRegistry, create_backend

registry_app = typer.Typer(help="Registry management commands")
console = Console()


# Schema commands
schema_app = typer.Typer(help="Schema registry commands")
registry_app.add_typer(schema_app, name="schema")


@schema_app.command("register")
def register_schema(
    schema_file: str = typer.Option(..., "--file", "-f", help="Schema file (JSON)"),
    schema_id: str = typer.Option(..., "--id", "-i", help="Schema ID"),
    version: str = typer.Option(..., "--version", "-v", help="Schema version"),
    description: str = typer.Option("", "--description", "-d", help="Schema description"),
):
    """Register a new schema."""
    try:
        schema_path = Path(schema_file)
        if not schema_path.exists():
            console.print(f"[red]✗[/red] Schema file not found: {schema_file}", style="bold red")
            raise typer.Exit(1)
        
        schema = json.loads(schema_path.read_text())
        
        async def _register():
            backend = create_backend("file", base_path="./data/registries")
            registry = SchemaRegistry(backend=backend)
            result = await registry.register_schema(
                schema_id=schema_id,
                schema=schema,
                version=version,
                description=description
            )
            await registry.close()
            return result
        
        result = asyncio.run(_register())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Failed to register schema: {result.unwrap_err()}", style="bold red")
            raise typer.Exit(1)
        
        console.print(f"[green]✓[/green] Schema registered: [cyan]{schema_id}[/cyan] v{version}")
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@schema_app.command("list")
def list_schemas():
    """List all registered schemas."""
    try:
        async def _list():
            backend = create_backend("file", base_path="./data/registries")
            registry = SchemaRegistry(backend=backend)
            result = await registry.list_schemas()
            await registry.close()
            return result
        
        result = asyncio.run(_list())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Failed to list schemas", style="bold red")
            raise typer.Exit(1)
        
        schemas = result.unwrap()
        
        if not schemas:
            console.print("[yellow]No schemas registered[/yellow]")
            return
        
        table = Table(title=f"Registered Schemas ({len(schemas)})")
        table.add_column("Schema ID", style="cyan")
        table.add_column("Version")
        table.add_column("Description")
        table.add_column("Deprecated", style="yellow")
        
        for schema in schemas:
            table.add_row(
                schema.schema_id,
                schema.version,
                schema.description[:50] if schema.description else "",
                "Yes" if schema.deprecated else "No"
            )
        
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@schema_app.command("validate")
def validate_data(
    schema_id: str = typer.Option(..., "--schema", "-s", help="Schema ID"),
    data_file: str = typer.Option(..., "--data", "-d", help="Data file (JSON)"),
    version: Optional[str] = typer.Option(None, "--version", "-v", help="Schema version"),
):
    """Validate data against a schema."""
    try:
        data_path = Path(data_file)
        if not data_path.exists():
            console.print(f"[red]✗[/red] Data file not found: {data_file}", style="bold red")
            raise typer.Exit(1)
        
        data = json.loads(data_path.read_text())
        
        async def _validate():
            backend = create_backend("file", base_path="./data/registries")
            registry = SchemaRegistry(backend=backend)
            result = await registry.validate_data(schema_id, data, version)
            await registry.close()
            return result
        
        result = asyncio.run(_validate())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Validation failed: {result.unwrap_err()}", style="bold red")
            raise typer.Exit(1)
        
        console.print(f"[green]✓[/green] Data is valid for schema: [cyan]{schema_id}[/cyan]")
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


# Policy commands
policy_app = typer.Typer(help="Policy registry commands")
registry_app.add_typer(policy_app, name="policy")


@policy_app.command("register")
def register_policy(
    policy_file: str = typer.Option(..., "--file", "-f", help="Policy file (.rego)"),
    policy_id: str = typer.Option(..., "--id", "-i", help="Policy ID"),
    version: str = typer.Option(..., "--version", "-v", help="Policy version"),
    description: str = typer.Option("", "--description", "-d", help="Policy description"),
):
    """Register a new policy."""
    try:
        policy_path = Path(policy_file)
        if not policy_path.exists():
            console.print(f"[red]✗[/red] Policy file not found: {policy_file}", style="bold red")
            raise typer.Exit(1)
        
        rego_code = policy_path.read_text()
        
        async def _register():
            backend = create_backend("file", base_path="./data/registries")
            registry = PolicyRegistry(backend=backend)
            result = await registry.register_policy(
                policy_id=policy_id,
                rego_code=rego_code,
                version=version,
                description=description
            )
            await registry.close()
            return result
        
        result = asyncio.run(_register())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Failed to register policy: {result.unwrap_err()}", style="bold red")
            raise typer.Exit(1)
        
        console.print(f"[green]✓[/green] Policy registered: [cyan]{policy_id}[/cyan] v{version}")
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@policy_app.command("list")
def list_policies():
    """List all registered policies."""
    try:
        async def _list():
            backend = create_backend("file", base_path="./data/registries")
            registry = PolicyRegistry(backend=backend)
            result = await registry.list_policies()
            await registry.close()
            return result
        
        result = asyncio.run(_list())
        
        if result.is_err():
            console.print(f"[red]✗[/red] Failed to list policies", style="bold red")
            raise typer.Exit(1)
        
        policies = result.unwrap()
        
        if not policies:
            console.print("[yellow]No policies registered[/yellow]")
            return
        
        table = Table(title=f"Registered Policies ({len(policies)})")
        table.add_column("Policy ID", style="cyan")
        table.add_column("Version")
        table.add_column("Description")
        table.add_column("Deployed", style="green")
        
        for policy in policies:
            table.add_row(
                policy.policy_id,
                policy.version,
                policy.description[:50] if policy.description else "",
                "Yes" if policy.deployed else "No"
            )
        
        console.print(table)
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)
