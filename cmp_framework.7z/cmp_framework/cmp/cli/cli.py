"""
CMP Framework CLI - Main entry point.

Command-line interface for CMP Framework operations.
"""

import typer
from rich.console import Console
from rich.table import Table

from .context_commands import context_app
from .workflow_commands import workflow_app
from .registry_commands import registry_app
from .monitor_commands import monitor_app

# Create main app
app = typer.Typer(
    name="cmp",
    help="CMP Framework - Context Management Plane CLI",
    add_completion=False,
    rich_markup_mode="rich"
)

# Create console for rich output
console = Console()

# Add command groups
app.add_typer(context_app, name="context", help="Context management commands")
app.add_typer(workflow_app, name="workflow", help="Workflow execution commands")
app.add_typer(registry_app, name="registry", help="Registry management commands")
app.add_typer(monitor_app, name="monitor", help="Monitoring and metrics commands")


@app.command()
def version():
    """Show CMP Framework version."""
    console.print("[bold green]CMP Framework[/bold green] version [cyan]0.1.0[/cyan]")


@app.command()
def info():
    """Show CMP Framework information."""
    table = Table(title="CMP Framework Information")
    
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Description")
    
    table.add_row("Configuration", "✓", "Pydantic-based config management")
    table.add_row("Registries", "✓", "Schema, Policy, Knowledge registries")
    table.add_row("Monitoring", "✓", "Logging, tracing, health checks, profiling")
    table.add_row("CLI", "✓", "Command-line interface")
    table.add_row("API Server", "⧗", "REST API (in development)")
    
    console.print(table)


def main():
    """Main entry point for CLI."""
    app()


if __name__ == "__main__":
    main()
