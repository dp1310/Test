"""
Workflow execution CLI commands.

Commands for running and managing workflows.
"""

import typer
import asyncio
import json
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

from cmp import CMP
from cmp.config import get_config, CMPConfig

workflow_app = typer.Typer(help="Workflow execution commands")
console = Console()


@workflow_app.command("run")
def run_workflow(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    context_id: str = typer.Option(..., "--context", "-c", help="Context ID"),
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
    agents: Optional[str] = typer.Option(None, "--agents", "-a", help="Comma-separated agent IDs"),
    config_file: Optional[str] = typer.Option(None, "--config", help="Config file path"),
):
    """Run a workflow."""
    try:
        if config_file:
            config = CMPConfig.from_yaml(config_file)
        else:
            config = get_config()
        
        cmp = CMP(tenant_id=tenant_id)
        
        async def _run():
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task(f"Executing workflow: {workflow_name}", total=None)
                
                builder = cmp.workflow(workflow_name).with_context(context_id)
                
                if agents:
                    # Note: Would need to import and instantiate actual agents
                    console.print(f"[yellow]Note: Agent instantiation not implemented in CLI[/yellow]")
                
                results = []
                async for result in builder.execute():
                    results.append(result)
                    progress.update(task, description=f"Processing step {len(results)}")
                
                progress.update(task, description=f"Workflow completed ({len(results)} steps)")
                return results
        
        results = asyncio.run(_run())
        
        console.print(f"\n[green]✓[/green] Workflow completed: [cyan]{workflow_name}[/cyan]")
        console.print(f"  Steps executed: {len(results)}")
        
        # Show results
        if results:
            console.print("\n[bold]Results:[/bold]")
            for i, result in enumerate(results, 1):
                console.print(f"  Step {i}: {result.id[:16]}...")
        
    except Exception as e:
        console.print(f"[red]✗[/red] Error: {e}", style="bold red")
        raise typer.Exit(1)


@workflow_app.command("list")
def list_workflows(
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
):
    """List available workflows."""
    # This would query registered workflows from the system
    console.print("[yellow]Workflow listing not yet implemented[/yellow]")
    console.print("Available workflow types:")
    console.print("  - chaining: Sequential execution")
    console.print("  - fan_out_fan_in: Parallel execution")
    console.print("  - evolution: Progressive refinement")


@workflow_app.command("status")
def workflow_status(
    workflow_id: str = typer.Argument(..., help="Workflow ID"),
    tenant_id: str = typer.Option("default", "--tenant", "-t", help="Tenant ID"),
):
    """Get workflow execution status."""
    console.print(f"[yellow]Workflow status tracking not yet implemented[/yellow]")
    console.print(f"Workflow ID: {workflow_id}")
