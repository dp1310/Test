"""
Schema Registry for CMP Framework.

Manages JSON schemas with validation, versioning, and caching.
"""

from typing import Optional, Any
from dataclasses import dataclass
from datetime import datetime
import jsonschema
from cachetools import TTLCache

from ..core.result import Result, Ok, Err
from ..core.exceptions import CMPError
from .persistence import RegistryBackend, create_backend


class RegistryError(CMPError):
    """Base error for registry operations."""
    pass


class SchemaNotFoundError(RegistryError):
    """Schema not found in registry."""
    pass


class SchemaValidationError(RegistryError):
    """Schema validation failed."""
    pass


class SchemaVersionError(RegistryError):
    """Schema version conflict."""
    pass


@dataclass(frozen=True)
class SchemaInfo:
    """Schema metadata information."""
    
    schema_id: str
    version: str
    description: str
    created_at: str
    deprecated: bool = False
    deprecated_at: Optional[str] = None


class SchemaRegistry:
    """
    Registry for managing JSON schemas with versioning and validation.
    
    Features:
    - Schema registration with semantic versioning
    - JSON Schema validation
    - Schema caching with TTL
    - Schema deprecation
    - Version history
    
    Example:
        >>> registry = SchemaRegistry()
        >>> await registry.register_schema(
        ...     schema_id="user_event",
        ...     schema={"type": "object", "properties": {"user_id": {"type": "string"}}},
        ...     version="1.0.0",
        ...     description="User event schema"
        ... )
        >>> result = await registry.validate_data(
        ...     schema_id="user_event",
        ...     data={"user_id": "123"}
        ... )
    """
    
    def __init__(
        self,
        backend: Optional[RegistryBackend] = None,
        cache_enabled: bool = True,
        cache_ttl: int = 300,
        cache_max_size: int = 1000
    ):
        """
        Initialize schema registry.
        
        Args:
            backend: Persistence backend (defaults to in-memory)
            cache_enabled: Enable schema caching
            cache_ttl: Cache TTL in seconds
            cache_max_size: Maximum cache entries
        """
        self.backend = backend or create_backend("memory")
        self.cache_enabled = cache_enabled
        
        if cache_enabled:
            self._cache: TTLCache = TTLCache(
                maxsize=cache_max_size,
                ttl=cache_ttl
            )
        else:
            self._cache = None
    
    def _make_key(self, schema_id: str, version: Optional[str] = None) -> str:
        """Create storage key for schema."""
        if version:
            return f"schema:{schema_id}:{version}"
        return f"schema:{schema_id}:latest"
    
    async def register_schema(
        self,
        schema_id: str,
        schema: dict[str, Any],
        version: str,
        description: str = "",
        force: bool = False
    ) -> Result[None, RegistryError]:
        """
        Register a new schema or schema version.
        
        Args:
            schema_id: Unique schema identifier
            schema: JSON Schema definition
            version: Semantic version (e.g., "1.0.0")
            description: Human-readable description
            force: Overwrite existing version if True
            
        Returns:
            Result with None on success or RegistryError on failure
            
        Example:
            >>> await registry.register_schema(
            ...     schema_id="user_event",
            ...     schema={
            ...         "type": "object",
            ...         "properties": {
            ...             "user_id": {"type": "string"},
            ...             "action": {"type": "string"}
            ...         },
            ...         "required": ["user_id", "action"]
            ...     },
            ...     version="1.0.0",
            ...     description="User event schema v1"
            ... )
        """
        try:
            # Validate schema is valid JSON Schema
            jsonschema.Draft7Validator.check_schema(schema)
        except jsonschema.SchemaError as e:
            return Err(SchemaValidationError(f"Invalid JSON Schema: {e}"))
        
        # Check if version already exists
        key = self._make_key(schema_id, version)
        existing = await self.backend.load(key)
        
        if existing.is_ok() and not force:
            return Err(
                SchemaVersionError(
                    f"Schema {schema_id} version {version} already exists. "
                    "Use force=True to overwrite."
                )
            )
        
        # Save versioned schema
        metadata = {
            "schema_id": schema_id,
            "version": version,
            "description": description,
            "created_at": datetime.utcnow().isoformat(),
            "deprecated": False
        }
        
        result = await self.backend.save(
            key=key,
            value=schema,
            metadata=metadata
        )
        
        if result.is_err():
            return result
        
        # Update latest pointer
        latest_key = self._make_key(schema_id)
        await self.backend.save(
            key=latest_key,
            value=schema,
            metadata=metadata
        )
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
            self._cache.pop(latest_key, None)
        
        return Ok(None)
    
    async def get_schema(
        self,
        schema_id: str,
        version: Optional[str] = None
    ) -> Result[dict[str, Any], RegistryError]:
        """
        Get a schema by ID and optional version.
        
        Args:
            schema_id: Schema identifier
            version: Specific version (defaults to latest)
            
        Returns:
            Result with schema dict or RegistryError
            
        Example:
            >>> result = await registry.get_schema("user_event", "1.0.0")
            >>> if result.is_ok():
            ...     schema = result.unwrap()
        """
        key = self._make_key(schema_id, version)
        
        # Check cache first
        if self.cache_enabled and self._cache is not None:
            if key in self._cache:
                return Ok(self._cache[key])
        
        # Load from backend
        result = await self.backend.load(key)
        
        if result.is_err():
            return Err(
                SchemaNotFoundError(
                    f"Schema {schema_id} "
                    f"{'version ' + version if version else 'latest'} not found"
                )
            )
        
        data = result.unwrap()
        schema = data.get("value", {})
        
        # Cache the schema
        if self.cache_enabled and self._cache is not None:
            self._cache[key] = schema
        
        return Ok(schema)
    
    async def validate_data(
        self,
        schema_id: str,
        data: dict[str, Any],
        version: Optional[str] = None
    ) -> Result[None, SchemaValidationError]:
        """
        Validate data against a schema.
        
        Args:
            schema_id: Schema identifier
            data: Data to validate
            version: Schema version (defaults to latest)
            
        Returns:
            Result with None on success or SchemaValidationError
            
        Example:
            >>> result = await registry.validate_data(
            ...     schema_id="user_event",
            ...     data={"user_id": "123", "action": "login"}
            ... )
            >>> if result.is_err():
            ...     print(f"Validation failed: {result.unwrap_err()}")
        """
        # Get schema
        schema_result = await self.get_schema(schema_id, version)
        if schema_result.is_err():
            return Err(SchemaValidationError(str(schema_result.unwrap_err())))
        
        schema = schema_result.unwrap()
        
        # Validate data
        try:
            jsonschema.validate(instance=data, schema=schema)
            return Ok(None)
        except jsonschema.ValidationError as e:
            return Err(
                SchemaValidationError(
                    f"Data validation failed for schema {schema_id}: {e.message}"
                )
            )
    
    async def list_schemas(self) -> Result[list[SchemaInfo], RegistryError]:
        """
        List all registered schemas.
        
        Returns:
            Result with list of SchemaInfo or RegistryError
            
        Example:
            >>> result = await registry.list_schemas()
            >>> if result.is_ok():
            ...     for info in result.unwrap():
            ...         print(f"{info.schema_id} v{info.version}")
        """
        # List all schema keys
        result = await self.backend.list(prefix="schema:")
        if result.is_err():
            return Err(RegistryError(str(result.unwrap_err())))
        
        keys = result.unwrap()
        
        # Load metadata for each schema
        schemas = []
        seen = set()  # Track unique schema_id:version pairs
        
        for key in keys:
            if ":latest" in key:
                continue  # Skip latest pointers
            
            load_result = await self.backend.load(key)
            if load_result.is_ok():
                data = load_result.unwrap()
                metadata = data.get("metadata", {})
                
                schema_id = metadata.get("schema_id")
                version = metadata.get("version")
                
                if schema_id and version:
                    pair = f"{schema_id}:{version}"
                    if pair not in seen:
                        seen.add(pair)
                        schemas.append(
                            SchemaInfo(
                                schema_id=schema_id,
                                version=version,
                                description=metadata.get("description", ""),
                                created_at=metadata.get("created_at", ""),
                                deprecated=metadata.get("deprecated", False),
                                deprecated_at=metadata.get("deprecated_at")
                            )
                        )
        
        return Ok(sorted(schemas, key=lambda s: (s.schema_id, s.version)))
    
    async def deprecate_schema(
        self,
        schema_id: str,
        version: str
    ) -> Result[None, RegistryError]:
        """
        Mark a schema version as deprecated.
        
        Args:
            schema_id: Schema identifier
            version: Version to deprecate
            
        Returns:
            Result with None on success or RegistryError
            
        Example:
            >>> await registry.deprecate_schema("user_event", "1.0.0")
        """
        key = self._make_key(schema_id, version)
        
        # Load existing schema
        result = await self.backend.load(key)
        if result.is_err():
            return Err(SchemaNotFoundError(f"Schema {schema_id} v{version} not found"))
        
        data = result.unwrap()
        metadata = data.get("metadata", {})
        metadata["deprecated"] = True
        metadata["deprecated_at"] = datetime.utcnow().isoformat()
        
        # Save updated metadata
        save_result = await self.backend.save(
            key=key,
            value=data.get("value", {}),
            metadata=metadata
        )
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        
        return save_result
    
    async def delete_schema(
        self,
        schema_id: str,
        version: str
    ) -> Result[None, RegistryError]:
        """
        Delete a schema version.
        
        Args:
            schema_id: Schema identifier
            version: Version to delete
            
        Returns:
            Result with None on success or RegistryError
            
        Warning:
            This permanently deletes the schema. Consider using deprecate_schema instead.
        """
        key = self._make_key(schema_id, version)
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        
        result = await self.backend.delete(key)
        if result.is_err():
            return Err(SchemaNotFoundError(f"Schema {schema_id} v{version} not found"))
        
        return Ok(None)
    
    async def close(self) -> None:
        """Close registry and cleanup resources."""
        if self._cache is not None:
            self._cache.clear()
        await self.backend.close()
