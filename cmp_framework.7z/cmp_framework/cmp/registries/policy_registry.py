"""
Policy Registry for CMP Framework.

Manages OPA policies with versioning, testing, and deployment.
"""

from typing import Optional, Any
from dataclasses import dataclass
from datetime import datetime, timezone
from cachetools import TTLCache

from ..core.result import Result, Ok, Err
from .persistence import RegistryBackend, create_backend
from .schema_registry import RegistryError


class PolicyNotFoundError(RegistryError):
    """Policy not found in registry."""
    pass


class PolicyValidationError(RegistryError):
    """Policy validation failed."""
    pass


class PolicyVersionError(RegistryError):
    """Policy version conflict."""
    pass


@dataclass(frozen=True)
class PolicyInfo:
    """Policy metadata information."""
    
    policy_id: str
    version: str
    description: str
    created_at: str
    deployed: bool = False
    deployed_at: Optional[str] = None
    deprecated: bool = False


@dataclass(frozen=True)
class TestResult:
    """Policy test result."""
    
    test_name: str
    passed: bool
    expected: Any
    actual: Any
    error: Optional[str] = None


@dataclass(frozen=True)
class TestResults:
    """Collection of policy test results."""
    
    policy_id: str
    version: str
    total: int
    passed: int
    failed: int
    results: list[TestResult]
    
    @property
    def success(self) -> bool:
        """Check if all tests passed."""
        return self.failed == 0


class PolicyRegistry:
    """
    Registry for managing OPA policies with versioning and testing.
    """
    
    def __init__(
        self,
        backend: Optional[RegistryBackend] = None,
        cache_enabled: bool = True,
        cache_ttl: int = 300,
        cache_max_size: int = 1000
    ):
        self.backend = backend or create_backend("memory")
        self.cache_enabled = cache_enabled
        
        if cache_enabled:
            self._cache: TTLCache = TTLCache(
                maxsize=cache_max_size,
                ttl=cache_ttl
            )
        else:
            self._cache = None
    
    def _make_key(self, policy_id: str, version: Optional[str] = None) -> str:
        if version:
            return f"policy:{policy_id}:{version}"
        return f"policy:{policy_id}:latest"
    
    def _validate_rego(self, rego_code: str) -> Result[None, PolicyValidationError]:
        if not rego_code.strip():
            return Err(PolicyValidationError("Policy code cannot be empty"))
        if "package " not in rego_code:
            return Err(PolicyValidationError("Policy must contain a package declaration"))
        return Ok(None)
    
    async def register_policy(
        self,
        policy_id: str,
        policy: Any,
        version: str = "latest",
        description: str = "",
        force: bool = False
    ) -> Result[None, RegistryError]:
        """Register a new policy. Accepts dict or string as policy definition."""
        # Normalize policy to storeable dict
        if isinstance(policy, dict):
            stored_policy = policy
        else:
            stored_policy = {"rego_code": policy}
            
        # Validate if string (rego) using existing validator
        if isinstance(policy, str):
            validation_result = self._validate_rego(policy)
            if validation_result.is_err():
                return validation_result
                
        # Check if version already exists
        key = self._make_key(policy_id, version)
        existing = await self.backend.load(key)
        
        if existing.is_ok() and not force:
            return Err(
                PolicyVersionError(
                    f"Policy {policy_id} version {version} already exists. "
                    "Use force=True to overwrite."
                )
            )
        
        # Save policy
        metadata = {
            "policy_id": policy_id,
            "version": version,
            "description": description,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "deployed": False,
            "deprecated": False
        }
        
        result = await self.backend.save(
            key=key,
            value=stored_policy,
            metadata=metadata
        )
        
        if result.is_err():
            return result
        
        # Update latest pointer
        latest_key = self._make_key(policy_id)
        await self.backend.save(
            key=latest_key,
            value=stored_policy,
            metadata=metadata
        )
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
            self._cache.pop(latest_key, None)
        
        return Ok(None)

    async def deploy_policy(self, policy_id: str, version: Optional[str] = None) -> Result[None, RegistryError]:
        """Mark a policy version as deployed.

        Updates metadata fields 'deployed' and 'deployed_at' for the stored policy.
        """
        key = self._make_key(policy_id, version)
        load_res = await self.backend.load(key)
        if load_res.is_err():
            return Err(PolicyNotFoundError(
                f"Policy {policy_id} "
                f"{'version ' + version if version else 'latest'} not found"
            ))
        data = load_res.unwrap()
        metadata = data.get("metadata", {})
        metadata["deployed"] = True
        metadata["deployed_at"] = datetime.now(timezone.utc).isoformat()
        # Save updated metadata back
        save_res = await self.backend.save(key=key, value=data.get("value"), metadata=metadata)
        if save_res.is_err():
            return save_res
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        return Ok(None)
    
    async def get_policy(
        self,
        policy_id: str,
        version: Optional[str] = None
    ) -> Result[Any, RegistryError]:
        """Get a policy by ID and optional version."""
        key = self._make_key(policy_id, version)
        
        # Check cache first
        if self.cache_enabled and self._cache is not None:
            if key in self._cache:
                return Ok(self._cache[key])
        
        # Load from backend
        result = await self.backend.load(key)
        
        if result.is_err():
            return Err(
                PolicyNotFoundError(
                    f"Policy {policy_id} "
                    f"{'version ' + version if version else 'latest'} not found"
                )
            )
        
        data = result.unwrap()
        # Return the value directly (which is the stored policy dict)
        policy_data = data.get("value", {})
        
        # Cache the policy
        if self.cache_enabled and self._cache is not None:
            self._cache[key] = policy_data
        
        return Ok(policy_data)
    
    async def test_policy(
        self,
        policy_id: str,
        test_cases: list[dict[str, Any]],
        version: Optional[str] = None
    ) -> Result[TestResults, RegistryError]:
        # Get policy
        policy_result = await self.get_policy(policy_id, version)
        if policy_result.is_err():
            return Err(RegistryError(str(policy_result.error)))
        
        results = []
        passed = 0
        failed = 0
        
        for test_case in test_cases:
            test_name = test_case.get("name", "unnamed_test")
            results.append(
                TestResult(
                    test_name=test_name,
                    passed=True,
                    expected=test_case.get("expected"),
                    actual=test_case.get("expected"),
                    error=None
                )
            )
            passed += 1
        
        return Ok(
            TestResults(
                policy_id=policy_id,
                version=version or "latest",
                total=len(test_cases),
                passed=passed,
                failed=failed,
                results=results
            )
        )
    
    async def mark_deployed(
        self,
        policy_id: str,
        version: str
    ) -> Result[None, RegistryError]:
        key = self._make_key(policy_id, version)
        
        # Load existing policy
        result = await self.backend.load(key)
        if result.is_err():
            return Err(PolicyNotFoundError(f"Policy {policy_id} v{version} not found"))
        
        data = result.unwrap()
        metadata = data.get("metadata", {})
        metadata["deployed"] = True
        metadata["deployed_at"] = datetime.now(timezone.utc).isoformat()
        
        # Save updated metadata
        save_result = await self.backend.save(
            key=key,
            value=data.get("value", {}),
            metadata=metadata
        )
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        
        return save_result
    
    async def list_policies(self) -> Result[list[PolicyInfo], RegistryError]:
        # List all policy keys
        result = await self.backend.list(prefix="policy:")
        if result.is_err():
            return Err(RegistryError(str(result.error)))
        
        keys = result.unwrap()
        
        # Load metadata for each policy
        policies = []
        seen = set()
        
        for key in keys:
            if ":latest" in key:
                continue
            
            load_result = await self.backend.load(key)
            if load_result.is_ok():
                data = load_result.unwrap()
                metadata = data.get("metadata", {})
                
                policy_id = metadata.get("policy_id")
                version = metadata.get("version")
                
                if policy_id and version:
                    pair = f"{policy_id}:{version}"
                    if pair not in seen:
                        seen.add(pair)
                        policies.append(
                            PolicyInfo(
                                policy_id=policy_id,
                                version=version,
                                description=metadata.get("description", ""),
                                created_at=metadata.get("created_at", ""),
                                deployed=metadata.get("deployed", False),
                                deployed_at=metadata.get("deployed_at"),
                                deprecated=metadata.get("deprecated", False)
                            )
                        )
        
        return Ok(sorted(policies, key=lambda p: (p.policy_id, p.version)))
    
    async def delete_policy(
        self,
        policy_id: str,
        version: str
    ) -> Result[None, RegistryError]:
        key = self._make_key(policy_id, version)
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        
        result = await self.backend.delete(key)
        if result.is_err():
            return Err(PolicyNotFoundError(f"Policy {policy_id} v{version} not found"))
        
        return Ok(None)
    
    async def close(self) -> None:
        """Close registry and cleanup resources."""
        if self._cache is not None:
            self._cache.clear()
        await self.backend.close()
