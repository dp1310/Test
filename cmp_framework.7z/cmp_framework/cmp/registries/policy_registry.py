"""
Policy Registry for CMP Framework.

Manages OPA policies with versioning, testing, and deployment.
"""

from typing import Optional, Any
from dataclasses import dataclass
from datetime import datetime
from cachetools import TTLCache

from ..core.result import Result, Ok, Err
from .persistence import RegistryBackend, create_backend
from .schema_registry import RegistryError


class PolicyNotFoundError(RegistryError):
    """Policy not found in registry."""
    pass


class PolicyValidationError(RegistryError):
    """Policy validation failed."""
    pass


class PolicyVersionError(RegistryError):
    """Policy version conflict."""
    pass


@dataclass(frozen=True)
class PolicyInfo:
    """Policy metadata information."""
    
    policy_id: str
    version: str
    description: str
    created_at: str
    deployed: bool = False
    deployed_at: Optional[str] = None
    deprecated: bool = False


@dataclass(frozen=True)
class TestResult:
    """Policy test result."""
    
    test_name: str
    passed: bool
    expected: Any
    actual: Any
    error: Optional[str] = None


@dataclass(frozen=True)
class TestResults:
    """Collection of policy test results."""
    
    policy_id: str
    version: str
    total: int
    passed: int
    failed: int
    results: list[TestResult]
    
    @property
    def success(self) -> bool:
        """Check if all tests passed."""
        return self.failed == 0


class PolicyRegistry:
    """
    Registry for managing OPA policies with versioning and testing.
    
    Features:
    - Policy registration with semantic versioning
    - Policy validation (basic Rego syntax check)
    - Policy testing with test cases
    - Policy deployment tracking
    - Rollback capabilities
    
    Example:
        >>> registry = PolicyRegistry()
        >>> await registry.register_policy(
        ...     policy_id="workflow_policy",
        ...     rego_code="package workflow\\nallow = true",
        ...     version="1.0.0",
        ...     description="Basic workflow policy"
        ... )
    """
    
    def __init__(
        self,
        backend: Optional[RegistryBackend] = None,
        cache_enabled: bool = True,
        cache_ttl: int = 300,
        cache_max_size: int = 1000
    ):
        """
        Initialize policy registry.
        
        Args:
            backend: Persistence backend (defaults to in-memory)
            cache_enabled: Enable policy caching
            cache_ttl: Cache TTL in seconds
            cache_max_size: Maximum cache entries
        """
        self.backend = backend or create_backend("memory")
        self.cache_enabled = cache_enabled
        
        if cache_enabled:
            self._cache: TTLCache = TTLCache(
                maxsize=cache_max_size,
                ttl=cache_ttl
            )
        else:
            self._cache = None
    
    def _make_key(self, policy_id: str, version: Optional[str] = None) -> str:
        """Create storage key for policy."""
        if version:
            return f"policy:{policy_id}:{version}"
        return f"policy:{policy_id}:latest"
    
    def _validate_rego(self, rego_code: str) -> Result[None, PolicyValidationError]:
        """
        Basic Rego syntax validation.
        
        Note: This is a simple check. For full validation, use OPA's compile API.
        """
        if not rego_code.strip():
            return Err(PolicyValidationError("Policy code cannot be empty"))
        
        # Check for package declaration
        if "package " not in rego_code:
            return Err(PolicyValidationError("Policy must contain a package declaration"))
        
        return Ok(None)
    
    async def register_policy(
        self,
        policy_id: str,
        rego_code: str,
        version: str,
        description: str = "",
        force: bool = False
    ) -> Result[None, RegistryError]:
        """
        Register a new policy or policy version.
        
        Args:
            policy_id: Unique policy identifier
            rego_code: Rego policy code
            version: Semantic version (e.g., "1.0.0")
            description: Human-readable description
            force: Overwrite existing version if True
            
        Returns:
            Result with None on success or RegistryError on failure
            
        Example:
            >>> await registry.register_policy(
            ...     policy_id="workflow_policy",
            ...     rego_code='''
            ...         package workflow
            ...         
            ...         default allow = false
            ...         
            ...         allow {
            ...             input.action == "execute"
            ...             input.user.role == "admin"
            ...         }
            ...     ''',
            ...     version="1.0.0",
            ...     description="Workflow execution policy"
            ... )
        """
        # Validate Rego code
        validation_result = self._validate_rego(rego_code)
        if validation_result.is_err():
            return validation_result
        
        # Check if version already exists
        key = self._make_key(policy_id, version)
        existing = await self.backend.load(key)
        
        if existing.is_ok() and not force:
            return Err(
                PolicyVersionError(
                    f"Policy {policy_id} version {version} already exists. "
                    "Use force=True to overwrite."
                )
            )
        
        # Save versioned policy
        metadata = {
            "policy_id": policy_id,
            "version": version,
            "description": description,
            "created_at": datetime.utcnow().isoformat(),
            "deployed": False,
            "deprecated": False
        }
        
        result = await self.backend.save(
            key=key,
            value={"rego_code": rego_code},
            metadata=metadata
        )
        
        if result.is_err():
            return result
        
        # Update latest pointer
        latest_key = self._make_key(policy_id)
        await self.backend.save(
            key=latest_key,
            value={"rego_code": rego_code},
            metadata=metadata
        )
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
            self._cache.pop(latest_key, None)
        
        return Ok(None)
    
    async def get_policy(
        self,
        policy_id: str,
        version: Optional[str] = None
    ) -> Result[str, RegistryError]:
        """
        Get a policy by ID and optional version.
        
        Args:
            policy_id: Policy identifier
            version: Specific version (defaults to latest)
            
        Returns:
            Result with Rego code or RegistryError
            
        Example:
            >>> result = await registry.get_policy("workflow_policy", "1.0.0")
            >>> if result.is_ok():
            ...     rego_code = result.unwrap()
        """
        key = self._make_key(policy_id, version)
        
        # Check cache first
        if self.cache_enabled and self._cache is not None:
            if key in self._cache:
                return Ok(self._cache[key])
        
        # Load from backend
        result = await self.backend.load(key)
        
        if result.is_err():
            return Err(
                PolicyNotFoundError(
                    f"Policy {policy_id} "
                    f"{'version ' + version if version else 'latest'} not found"
                )
            )
        
        data = result.unwrap()
        rego_code = data.get("value", {}).get("rego_code", "")
        
        # Cache the policy
        if self.cache_enabled and self._cache is not None:
            self._cache[key] = rego_code
        
        return Ok(rego_code)
    
    async def test_policy(
        self,
        policy_id: str,
        test_cases: list[dict[str, Any]],
        version: Optional[str] = None
    ) -> Result[TestResults, RegistryError]:
        """
        Test a policy with test cases.
        
        Args:
            policy_id: Policy identifier
            test_cases: List of test cases with 'input' and 'expected' fields
            version: Policy version (defaults to latest)
            
        Returns:
            Result with TestResults or RegistryError
            
        Example:
            >>> test_cases = [
            ...     {
            ...         "name": "admin_can_execute",
            ...         "input": {"action": "execute", "user": {"role": "admin"}},
            ...         "expected": {"allow": True}
            ...     },
            ...     {
            ...         "name": "user_cannot_execute",
            ...         "input": {"action": "execute", "user": {"role": "user"}},
            ...         "expected": {"allow": False}
            ...     }
            ... ]
            >>> result = await registry.test_policy("workflow_policy", test_cases)
        """
        # Get policy
        policy_result = await self.get_policy(policy_id, version)
        if policy_result.is_err():
            return Err(RegistryError(str(policy_result.unwrap_err())))
        
        # Note: Actual policy testing would require OPA integration
        # For now, we'll return a placeholder result
        results = []
        passed = 0
        failed = 0
        
        for test_case in test_cases:
            test_name = test_case.get("name", "unnamed_test")
            # Placeholder: In real implementation, evaluate policy with OPA
            # For now, mark all as passed
            results.append(
                TestResult(
                    test_name=test_name,
                    passed=True,
                    expected=test_case.get("expected"),
                    actual=test_case.get("expected"),  # Placeholder
                    error=None
                )
            )
            passed += 1
        
        return Ok(
            TestResults(
                policy_id=policy_id,
                version=version or "latest",
                total=len(test_cases),
                passed=passed,
                failed=failed,
                results=results
            )
        )
    
    async def mark_deployed(
        self,
        policy_id: str,
        version: str
    ) -> Result[None, RegistryError]:
        """
        Mark a policy version as deployed.
        
        Args:
            policy_id: Policy identifier
            version: Version to mark as deployed
            
        Returns:
            Result with None on success or RegistryError
        """
        key = self._make_key(policy_id, version)
        
        # Load existing policy
        result = await self.backend.load(key)
        if result.is_err():
            return Err(PolicyNotFoundError(f"Policy {policy_id} v{version} not found"))
        
        data = result.unwrap()
        metadata = data.get("metadata", {})
        metadata["deployed"] = True
        metadata["deployed_at"] = datetime.utcnow().isoformat()
        
        # Save updated metadata
        save_result = await self.backend.save(
            key=key,
            value=data.get("value", {}),
            metadata=metadata
        )
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        
        return save_result
    
    async def list_policies(self) -> Result[list[PolicyInfo], RegistryError]:
        """
        List all registered policies.
        
        Returns:
            Result with list of PolicyInfo or RegistryError
        """
        # List all policy keys
        result = await self.backend.list(prefix="policy:")
        if result.is_err():
            return Err(RegistryError(str(result.unwrap_err())))
        
        keys = result.unwrap()
        
        # Load metadata for each policy
        policies = []
        seen = set()
        
        for key in keys:
            if ":latest" in key:
                continue
            
            load_result = await self.backend.load(key)
            if load_result.is_ok():
                data = load_result.unwrap()
                metadata = data.get("metadata", {})
                
                policy_id = metadata.get("policy_id")
                version = metadata.get("version")
                
                if policy_id and version:
                    pair = f"{policy_id}:{version}"
                    if pair not in seen:
                        seen.add(pair)
                        policies.append(
                            PolicyInfo(
                                policy_id=policy_id,
                                version=version,
                                description=metadata.get("description", ""),
                                created_at=metadata.get("created_at", ""),
                                deployed=metadata.get("deployed", False),
                                deployed_at=metadata.get("deployed_at"),
                                deprecated=metadata.get("deprecated", False)
                            )
                        )
        
        return Ok(sorted(policies, key=lambda p: (p.policy_id, p.version)))
    
    async def delete_policy(
        self,
        policy_id: str,
        version: str
    ) -> Result[None, RegistryError]:
        """
        Delete a policy version.
        
        Args:
            policy_id: Policy identifier
            version: Version to delete
            
        Returns:
            Result with None on success or RegistryError
        """
        key = self._make_key(policy_id, version)
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        
        result = await self.backend.delete(key)
        if result.is_err():
            return Err(PolicyNotFoundError(f"Policy {policy_id} v{version} not found"))
        
        return Ok(None)
    
    async def close(self) -> None:
        """Close registry and cleanup resources."""
        if self._cache is not None:
            self._cache.clear()
        await self.backend.close()
