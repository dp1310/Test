"""
Registry persistence layer for CMP Framework.

Provides abstract interface and implementations for persisting registry data
across different backends (file, SQLite, PostgreSQL).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional
from pathlib import Path
import json
import asyncio
from datetime import datetime

from ..core.result import Result, Ok, Err
from ..core.exceptions import CMPError


class PersistenceError(CMPError):
    """Error in persistence operations."""
    pass


class RegistryBackend(ABC):
    """Abstract base class for registry persistence backends."""
    
    @abstractmethod
    async def save(
        self,
        key: str,
        value: dict[str, Any],
        metadata: Optional[dict[str, Any]] = None
    ) -> Result[None, PersistenceError]:
        """
        Save a value to the backend.
        
        Args:
            key: Unique key for the value
            value: Data to save
            metadata: Optional metadata (version, timestamp, etc.)
            
        Returns:
            Result with None on success or PersistenceError on failure
        """
        pass
    
    @abstractmethod
    async def load(self, key: str) -> Result[dict[str, Any], PersistenceError]:
        """
        Load a value from the backend.
        
        Args:
            key: Key to load
            
        Returns:
            Result with loaded data or PersistenceError if not found
        """
        pass
    
    @abstractmethod
    async def list(self, prefix: str = "") -> Result[list[str], PersistenceError]:
        """
        List all keys with optional prefix filter.
        
        Args:
            prefix: Optional prefix to filter keys
            
        Returns:
            Result with list of keys or PersistenceError
        """
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> Result[None, PersistenceError]:
        """
        Delete a value from the backend.
        
        Args:
            key: Key to delete
            
        Returns:
            Result with None on success or PersistenceError on failure
        """
        pass
    
    @abstractmethod
    async def search(
        self,
        query: dict[str, Any]
    ) -> Result[list[dict[str, Any]], PersistenceError]:
        """
        Search for values matching query criteria.
        
        Args:
            query: Query criteria (backend-specific)
            
        Returns:
            Result with list of matching values or PersistenceError
        """
        pass
    
    @abstractmethod
    async def close(self) -> None:
        """Close backend connections and cleanup resources."""
        pass


class FileBackend(RegistryBackend):
    """File-based persistence backend using JSON files."""
    
    def __init__(self, base_path: Path):
        """
        Initialize file backend.
        
        Args:
            base_path: Base directory for storing files
        """
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()
    
    def _get_file_path(self, key: str) -> Path:
        """Get file path for a key."""
        # Replace path separators to avoid directory traversal
        safe_key = key.replace("/", "_").replace("\\", "_")
        return self.base_path / f"{safe_key}.json"
    
    async def save(
        self,
        key: str,
        value: dict[str, Any],
        metadata: Optional[dict[str, Any]] = None
    ) -> Result[None, PersistenceError]:
        """Save value to JSON file."""
        try:
            async with self._lock:
                file_path = self._get_file_path(key)
                
                data = {
                    "key": key,
                    "value": value,
                    "metadata": metadata or {},
                    "saved_at": datetime.utcnow().isoformat()
                }
                
                # Write to temp file first, then rename (atomic operation)
                temp_path = file_path.with_suffix(".tmp")
                await asyncio.to_thread(
                    lambda: temp_path.write_text(
                        json.dumps(data, indent=2),
                        encoding="utf-8"
                    )
                )
                await asyncio.to_thread(temp_path.replace, file_path)
                
                return Ok(None)
        except Exception as e:
            return Err(PersistenceError(f"Failed to save {key}: {e}"))
    
    async def load(self, key: str) -> Result[dict[str, Any], PersistenceError]:
        """Load value from JSON file."""
        try:
            file_path = self._get_file_path(key)
            
            if not file_path.exists():
                return Err(PersistenceError(f"Key not found: {key}"))
            
            content = await asyncio.to_thread(
                file_path.read_text,
                encoding="utf-8"
            )
            data = json.loads(content)
            
            return Ok(data)
        except json.JSONDecodeError as e:
            return Err(PersistenceError(f"Invalid JSON in {key}: {e}"))
        except Exception as e:
            return Err(PersistenceError(f"Failed to load {key}: {e}"))
    
    async def list(self, prefix: str = "") -> Result[list[str], PersistenceError]:
        """List all keys with optional prefix."""
        try:
            keys = []
            for file_path in self.base_path.glob("*.json"):
                key = file_path.stem
                if key.startswith(prefix):
                    keys.append(key)
            
            return Ok(sorted(keys))
        except Exception as e:
            return Err(PersistenceError(f"Failed to list keys: {e}"))
    
    async def delete(self, key: str) -> Result[None, PersistenceError]:
        """Delete JSON file."""
        try:
            async with self._lock:
                file_path = self._get_file_path(key)
                
                if not file_path.exists():
                    return Err(PersistenceError(f"Key not found: {key}"))
                
                await asyncio.to_thread(file_path.unlink)
                return Ok(None)
        except Exception as e:
            return Err(PersistenceError(f"Failed to delete {key}: {e}"))
    
    async def search(
        self,
        query: dict[str, Any]
    ) -> Result[list[dict[str, Any]], PersistenceError]:
        """
        Search files by loading and filtering.
        
        Query format: {"field.path": "value"} for simple equality matching.
        """
        try:
            results = []
            
            # List all keys
            keys_result = await self.list()
            if keys_result.is_err():
                return keys_result
            
            keys = keys_result.unwrap()
            
            # Load and filter each file
            for key in keys:
                load_result = await self.load(key)
                if load_result.is_ok():
                    data = load_result.unwrap()
                    
                    # Simple field matching
                    matches = True
                    for field, expected_value in query.items():
                        # Navigate nested fields
                        value = data.get("value", {})
                        for part in field.split("."):
                            value = value.get(part) if isinstance(value, dict) else None
                        
                        if value != expected_value:
                            matches = False
                            break
                    
                    if matches:
                        results.append(data)
            
            return Ok(results)
        except Exception as e:
            return Err(PersistenceError(f"Search failed: {e}"))
    
    async def close(self) -> None:
        """No cleanup needed for file backend."""
        pass


class InMemoryBackend(RegistryBackend):
    """In-memory persistence backend for testing."""
    
    def __init__(self):
        """Initialize in-memory backend."""
        self._data: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()
    
    async def save(
        self,
        key: str,
        value: dict[str, Any],
        metadata: Optional[dict[str, Any]] = None
    ) -> Result[None, PersistenceError]:
        """Save value to memory."""
        async with self._lock:
            self._data[key] = {
                "key": key,
                "value": value,
                "metadata": metadata or {},
                "saved_at": datetime.utcnow().isoformat()
            }
            return Ok(None)
    
    async def load(self, key: str) -> Result[dict[str, Any], PersistenceError]:
        """Load value from memory."""
        if key not in self._data:
            return Err(PersistenceError(f"Key not found: {key}"))
        return Ok(self._data[key])
    
    async def list(self, prefix: str = "") -> Result[list[str], PersistenceError]:
        """List all keys with optional prefix."""
        keys = [k for k in self._data.keys() if k.startswith(prefix)]
        return Ok(sorted(keys))
    
    async def delete(self, key: str) -> Result[None, PersistenceError]:
        """Delete value from memory."""
        if key not in self._data:
            return Err(PersistenceError(f"Key not found: {key}"))
        
        async with self._lock:
            del self._data[key]
            return Ok(None)
    
    async def search(
        self,
        query: dict[str, Any]
    ) -> Result[list[dict[str, Any]], PersistenceError]:
        """Search in-memory data."""
        results = []
        
        for data in self._data.values():
            matches = True
            for field, expected_value in query.items():
                value = data.get("value", {})
                for part in field.split("."):
                    value = value.get(part) if isinstance(value, dict) else None
                
                if value != expected_value:
                    matches = False
                    break
            
            if matches:
                results.append(data)
        
        return Ok(results)
    
    async def close(self) -> None:
        """Clear in-memory data."""
        self._data.clear()


def create_backend(backend_type: str, **kwargs) -> RegistryBackend:
    """
    Factory function to create persistence backends.
    
    Args:
        backend_type: Type of backend ("file", "memory", "sqlite", "postgres")
        **kwargs: Backend-specific configuration
        
    Returns:
        RegistryBackend instance
        
    Example:
        >>> backend = create_backend("file", base_path="./data")
        >>> backend = create_backend("memory")
    """
    if backend_type == "file":
        base_path = kwargs.get("base_path", "./data/registries")
        return FileBackend(Path(base_path))
    elif backend_type == "memory":
        return InMemoryBackend()
    elif backend_type == "sqlite":
        # TODO: Implement SQLite backend
        raise NotImplementedError("SQLite backend not yet implemented")
    elif backend_type == "postgres":
        # TODO: Implement PostgreSQL backend
        raise NotImplementedError("PostgreSQL backend not yet implemented")
    else:
        raise ValueError(f"Unknown backend type: {backend_type}")
