"""Registries module initialization"""

from cmp.registries.schema_registry import (
    SchemaRegistry,
    SchemaInfo,
    SchemaNotFoundError,
    SchemaValidationError,
    SchemaVersionError,
)
from cmp.registries.agent_registry import AgentRegistry, AgentMetadata
from cmp.registries.policy_registry import (
    PolicyRegistry,
    PolicyInfo,
    PolicyNotFoundError,
    PolicyValidationError,
    PolicyVersionError,
    TestResult,
    TestResults,
)
from cmp.registries.knowledge_registry import (
    KnowledgeRegistry,
    KnowledgeSource,
    KnowledgeItem,
    KnowledgeType,
    KnowledgeNotFoundError,
    SearchResult,
)
from cmp.registries.persistence import (
    RegistryBackend,
    FileBackend,
    InMemoryBackend,
    PersistenceError,
    create_backend,
)

__all__ = [
    # Schema Registry
    "SchemaRegistry",
    "SchemaInfo",
    "SchemaNotFoundError",
    "SchemaValidationError",
    "SchemaVersionError",
    # Agent Registry
    "AgentRegistry",
    "AgentMetadata",
    # Policy Registry
    "PolicyRegistry",
    "PolicyInfo",
    "PolicyNotFoundError",
    "PolicyValidationError",
    "PolicyVersionError",
    "TestResult",
    "TestResults",
    # Knowledge Registry
    "KnowledgeRegistry",
    "KnowledgeSource",
    "KnowledgeItem",
    "KnowledgeType",
    "KnowledgeNotFoundError",
    "SearchResult",
    # Persistence
    "RegistryBackend",
    "FileBackend",
    "InMemoryBackend",
    "PersistenceError",
    "create_backend",
]

