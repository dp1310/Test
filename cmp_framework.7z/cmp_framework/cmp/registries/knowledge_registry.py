"""
Knowledge Registry for CMP Framework.

Manages knowledge sources with search, indexing, and retrieval.
"""

from typing import Optional, Any
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from cachetools import TTLCache

from ..core.result import Result, Ok, Err
from .persistence import RegistryBackend, create_backend
from .schema_registry import RegistryError


class KnowledgeNotFoundError(RegistryError):
    """Knowledge source not found in registry."""
    pass


class KnowledgeType(str, Enum):
    """Type of knowledge source."""
    
    DOCUMENT = "document"
    EMBEDDING = "embedding"
    API = "api"
    DATABASE = "database"
    GRAPH = "graph"


@dataclass(frozen=True)
class KnowledgeSource:
    """Knowledge source definition."""
    
    source_id: str
    source_type: KnowledgeType
    name: str
    description: str
    config: dict[str, Any]
    metadata: dict[str, Any]
    created_at: str
    indexed: bool = False
    indexed_at: Optional[str] = None


@dataclass(frozen=True)
class KnowledgeItem:
    """Individual knowledge item."""
    
    item_id: str
    source_id: str
    content: str
    metadata: dict[str, Any]
    score: float = 1.0  # Relevance score for search results
    embedding: Optional[list[float]] = None


@dataclass(frozen=True)
class SearchResult:
    """Search result with ranking."""
    
    query: str
    total_results: int
    items: list[KnowledgeItem]
    took_ms: int


class KnowledgeRegistry:
    """
    Registry for managing knowledge sources with search and retrieval.
    
    Features:
    - Knowledge source registration (documents, embeddings, APIs)
    - Full-text search with ranking
    - Vector similarity search (for embeddings)
    - Knowledge graph support
    - Access control per knowledge source
    - Usage tracking and analytics
    
    Example:
        >>> registry = KnowledgeRegistry()
        >>> source = KnowledgeSource(
        ...     source_id="user_docs",
        ...     source_type=KnowledgeType.DOCUMENT,
        ...     name="User Documentation",
        ...     description="Product user guides",
        ...     config={"path": "/docs"},
        ...     metadata={"version": "1.0"},
        ...     created_at=datetime.now(timezone.utc).isoformat()
        ... )
        >>> await registry.register_knowledge(source)
    """
    
    def __init__(
        self,
        backend: Optional[RegistryBackend] = None,
        cache_enabled: bool = True,
        cache_ttl: int = 300,
        cache_max_size: int = 1000
    ):
        """
        Initialize knowledge registry.
        
        Args:
            backend: Persistence backend (defaults to in-memory)
            cache_enabled: Enable knowledge caching
            cache_ttl: Cache TTL in seconds
            cache_max_size: Maximum cache entries
        """
        self.backend = backend or create_backend("memory")
        self.cache_enabled = cache_enabled
        
        if cache_enabled:
            self._cache: TTLCache = TTLCache(
                maxsize=cache_max_size,
                ttl=cache_ttl
            )
        else:
            self._cache = None
    
    def _make_source_key(self, source_id: str) -> str:
        """Create storage key for knowledge source."""
        return f"knowledge:source:{source_id}"
    
    def _make_item_key(self, source_id: str, item_id: str) -> str:
        """Create storage key for knowledge item."""
        return f"knowledge:item:{source_id}:{item_id}"
    
    async def register_knowledge(
        self,
        source: KnowledgeSource
    ) -> Result[None, RegistryError]:
        """
        Register a knowledge source.
        
        Args:
            source: KnowledgeSource to register
            
        Returns:
            Result with None on success or RegistryError on failure
            
        Example:
            >>> source = KnowledgeSource(
            ...     source_id="api_docs",
            ...     source_type=KnowledgeType.DOCUMENT,
            ...     name="API Documentation",
            ...     description="REST API reference",
            ...     config={"url": "https://api.example.com/docs"},
            ...     metadata={"format": "openapi"},
            ...     created_at=datetime.utcnow().isoformat()
            ... )
            >>> await registry.register_knowledge(source)
        """
        key = self._make_source_key(source.source_id)
        
        # Convert dataclass to dict
        source_dict = {
            "source_id": source.source_id,
            "source_type": source.source_type.value,
            "name": source.name,
            "description": source.description,
            "config": source.config,
            "metadata": source.metadata,
            "created_at": source.created_at,
            "indexed": source.indexed,
            "indexed_at": source.indexed_at
        }
        
        result = await self.backend.save(
            key=key,
            value=source_dict,
            metadata={"source_id": source.source_id}
        )
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        
        return result
    
    async def get_source(
        self,
        source_id: str
    ) -> Result[KnowledgeSource, RegistryError]:
        """
        Get a knowledge source by ID.
        
        Args:
            source_id: Source identifier
            
        Returns:
            Result with KnowledgeSource or RegistryError
        """
        key = self._make_source_key(source_id)
        
        # Check cache first
        if self.cache_enabled and self._cache is not None:
            if key in self._cache:
                return Ok(self._cache[key])
        
        # Load from backend
        result = await self.backend.load(key)
        
        if result.is_err():
            return Err(KnowledgeNotFoundError(f"Knowledge source {source_id} not found"))
        
        data = result.unwrap()
        source_dict = data.get("value", {})
        
        # Convert dict to dataclass
        source = KnowledgeSource(
            source_id=source_dict["source_id"],
            source_type=KnowledgeType(source_dict["source_type"]),
            name=source_dict["name"],
            description=source_dict["description"],
            config=source_dict["config"],
            metadata=source_dict["metadata"],
            created_at=source_dict["created_at"],
            indexed=source_dict.get("indexed", False),
            indexed_at=source_dict.get("indexed_at")
        )
        
        # Cache the source
        if self.cache_enabled and self._cache is not None:
            self._cache[key] = source
        
        return Ok(source)
    
    async def add_knowledge_item(
        self,
        item: KnowledgeItem
    ) -> Result[None, RegistryError]:
        """
        Add a knowledge item to a source.
        
        Args:
            item: KnowledgeItem to add
            
        Returns:
            Result with None on success or RegistryError on failure
        """
        # Verify source exists
        source_result = await self.get_source(item.source_id)
        if source_result.is_err():
            return Err(RegistryError(f"Source {item.source_id} not found"))
        
        key = self._make_item_key(item.source_id, item.item_id)
        
        # Convert dataclass to dict
        item_dict = {
            "item_id": item.item_id,
            "source_id": item.source_id,
            "content": item.content,
            "metadata": item.metadata,
            "score": item.score,
            "embedding": item.embedding
        }
        
        result = await self.backend.save(
            key=key,
            value=item_dict,
            metadata={
                "source_id": item.source_id,
                "item_id": item.item_id
            }
        )
        
        return result
    
    async def get_knowledge(
        self,
        source_id: str,
        item_id: str
    ) -> Result[KnowledgeItem, RegistryError]:
        """
        Get a specific knowledge item.
        
        Args:
            source_id: Source identifier
            item_id: Item identifier
            
        Returns:
            Result with KnowledgeItem or RegistryError
        """
        key = self._make_item_key(source_id, item_id)
        
        result = await self.backend.load(key)
        
        if result.is_err():
            return Err(
                KnowledgeNotFoundError(
                    f"Knowledge item {item_id} not found in source {source_id}"
                )
            )
        
        data = result.unwrap()
        item_dict = data.get("value", {})
        
        # Convert dict to dataclass
        item = KnowledgeItem(
            item_id=item_dict["item_id"],
            source_id=item_dict["source_id"],
            content=item_dict["content"],
            metadata=item_dict["metadata"],
            score=item_dict.get("score", 1.0),
            embedding=item_dict.get("embedding")
        )
        
        return Ok(item)
    
    async def search(
        self,
        query: str,
        filters: Optional[dict[str, Any]] = None,
        limit: int = 10
    ) -> Result[SearchResult, RegistryError]:
        """
        Search knowledge items.
        
        Args:
            query: Search query string
            filters: Optional filters (source_id, metadata fields, etc.)
            limit: Maximum results to return
            
        Returns:
            Result with SearchResult or RegistryError
            
        Example:
            >>> result = await registry.search(
            ...     query="authentication",
            ...     filters={"source_id": "api_docs"},
            ...     limit=5
            ... )
        """
        start_time = datetime.now(timezone.utc)
        
        # List all knowledge items
        result = await self.backend.list(prefix="knowledge:item:")
        if result.is_err():
            return Err(RegistryError(str(result.error)))
        
        keys = result.unwrap()
        
        # Simple text search (in production, use proper search engine)
        items = []
        query_lower = query.lower()
        
        for key in keys:
            load_result = await self.backend.load(key)
            if load_result.is_ok():
                data = load_result.unwrap()
                item_dict = data.get("value", {})
                
                # Apply filters
                if filters:
                    if "source_id" in filters:
                        if item_dict.get("source_id") != filters["source_id"]:
                            continue
                
                # Simple text matching
                content = item_dict.get("content", "").lower()
                if query_lower in content:
                    # Calculate simple relevance score
                    score = content.count(query_lower) / max(len(content), 1)
                    
                    item = KnowledgeItem(
                        item_id=item_dict["item_id"],
                        source_id=item_dict["source_id"],
                        content=item_dict["content"],
                        metadata=item_dict["metadata"],
                        score=score,
                        embedding=item_dict.get("embedding")
                    )
                    items.append(item)
        
        # Sort by score and limit
        items.sort(key=lambda x: x.score, reverse=True)
        items = items[:limit]
        
        end_time = datetime.now(timezone.utc)
        took_ms = int((end_time - start_time).total_seconds() * 1000)
        
        return Ok(
            SearchResult(
                query=query,
                total_results=len(items),
                items=items,
                took_ms=took_ms
            )
        )
    
    async def mark_indexed(
        self,
        source_id: str
    ) -> Result[None, RegistryError]:
        """
        Mark a knowledge source as indexed.
        
        Args:
            source_id: Source identifier
            
        Returns:
            Result with None on success or RegistryError
        """
        # Get source
        source_result = await self.get_source(source_id)
        if source_result.is_err():
            return Err(RegistryError(str(source_result.error)))
        
        source = source_result.unwrap()
        
        # Update source with indexed flag
        updated_source = KnowledgeSource(
            source_id=source.source_id,
            source_type=source.source_type,
            name=source.name,
            description=source.description,
            config=source.config,
            metadata=source.metadata,
            created_at=source.created_at,
            indexed=True,
            indexed_at=datetime.now(timezone.utc).isoformat()
        )
        
        return await self.register_knowledge(updated_source)
    
    async def list_sources(self) -> Result[list[KnowledgeSource], RegistryError]:
        """
        List all knowledge sources.
        
        Returns:
            Result with list of KnowledgeSource or RegistryError
        """
        result = await self.backend.list(prefix="knowledge:source:")
        if result.is_err():
            return Err(RegistryError(str(result.error)))
        
        keys = result.unwrap()
        
        sources = []
        for key in keys:
            load_result = await self.backend.load(key)
            if load_result.is_ok():
                data = load_result.unwrap()
                source_dict = data.get("value", {})
                
                source = KnowledgeSource(
                    source_id=source_dict["source_id"],
                    source_type=KnowledgeType(source_dict["source_type"]),
                    name=source_dict["name"],
                    description=source_dict["description"],
                    config=source_dict["config"],
                    metadata=source_dict["metadata"],
                    created_at=source_dict["created_at"],
                    indexed=source_dict.get("indexed", False),
                    indexed_at=source_dict.get("indexed_at")
                )
                sources.append(source)
        
        return Ok(sorted(sources, key=lambda s: s.source_id))
    
    async def delete_source(
        self,
        source_id: str,
        delete_items: bool = True
    ) -> Result[None, RegistryError]:
        """
        Delete a knowledge source.
        
        Args:
            source_id: Source identifier
            delete_items: Also delete all items in the source
            
        Returns:
            Result with None on success or RegistryError
        """
        # Delete all items if requested
        if delete_items:
            items_result = await self.backend.list(prefix=f"knowledge:item:{source_id}:")
            if items_result.is_ok():
                for item_key in items_result.unwrap():
                    await self.backend.delete(item_key)
        
        # Delete source
        key = self._make_source_key(source_id)
        
        # Invalidate cache
        if self.cache_enabled and self._cache is not None:
            self._cache.pop(key, None)
        
        result = await self.backend.delete(key)
        if result.is_err():
            return Err(KnowledgeNotFoundError(f"Knowledge source {source_id} not found"))
        
        return Ok(None)
    
    async def close(self) -> None:
        """Close registry and cleanup resources."""
        if self._cache is not None:
            self._cache.clear()
        await self.backend.close()
