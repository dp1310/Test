"""
Agent Registry for tracking registered agents.
"""

from typing import Optional, Dict, List
from cmp.sdk.agent import Agent
from cmp.utils.async_helpers import AsyncLock


class AgentMetadata:
    """Metadata about a registered agent"""
    
    def __init__(
        self,
        agent_id: str,
        agent_type: str,
        capabilities: List[str],
        tenant_id: str
    ):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.capabilities = capabilities
        self.tenant_id = tenant_id


class AgentRegistry:
    """
    Registry for managing agents with multi-tenancy support.
    
    Tracks registered agents and their capabilities.
    """
    
    def __init__(self):
        self._agents: Dict[str, Dict[str, AgentMetadata]] = {}  # tenant_id -> agent_id -> metadata
        self._lock = AsyncLock()
    
    async def register(
        self,
        agent: Agent,
        tenant_id: str,
        capabilities: Optional[List[str]] = None
    ) -> None:
        """
        Register an agent.
        
        Args:
            agent: Agent instance
            tenant_id: Tenant ID
            capabilities: List of agent capabilities
        """
        async with self._lock:
            if tenant_id not in self._agents:
                self._agents[tenant_id] = {}
            
            metadata = AgentMetadata(
                agent_id=agent.agent_id,
                agent_type=agent.__class__.__name__,
                capabilities=capabilities or [],
                tenant_id=tenant_id
            )
            
            self._agents[tenant_id][agent.agent_id] = metadata
    
    async def get(self, agent_id: str, tenant_id: str) -> Optional[AgentMetadata]:
        """
        Get agent metadata.
        
        Args:
            agent_id: Agent ID
            tenant_id: Tenant ID
            
        Returns:
            AgentMetadata if found, None otherwise
        """
        tenant_agents = self._agents.get(tenant_id, {})
        return tenant_agents.get(agent_id)
    
    async def list(self, tenant_id: str) -> List[AgentMetadata]:
        """
        List all agents for a tenant.
        
        Args:
            tenant_id: Tenant ID
            
        Returns:
            List of agent metadata
        """
        return list(self._agents.get(tenant_id, {}).values())
    
    async def unregister(self, agent_id: str, tenant_id: str) -> bool:
        """
        Unregister an agent.
        
        Args:
            agent_id: Agent ID
            tenant_id: Tenant ID
            
        Returns:
            True if unregistered, False if not found
        """
        async with self._lock:
            tenant_agents = self._agents.get(tenant_id, {})
            if agent_id in tenant_agents:
                del tenant_agents[agent_id]
                return True
            return False
