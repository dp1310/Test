"""
Base Agent class for CMP framework.
"""

from abc import ABC, abstractmethod
from cmp.core.models import Context


class Agent(ABC):
    """
    Base class for agents in CMP framework.
    
    Agents process contexts and return new contexts.
    They can use dependency injection decorators for context and knowledge.
    """
    
    def __init__(self, agent_id: str | None = None):
        """
        Initialize agent.
        
        Args:
            agent_id: Optional agent ID (auto-generated if not provided)
        """
        import uuid
        self.agent_id = agent_id or f"agent_{uuid.uuid4().hex[:8]}"
    
    @abstractmethod
    async def process(self, context: Context) -> Context:
        """
        Process context and return new context.
        
        Args:
            context: Input context
            
        Returns:
            Processed context
        """
        pass
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(id={self.agent_id})"
