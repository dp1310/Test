"""
Main CMP SDK client.
"""

from typing import Any, Optional, AsyncIterator
from cmp.core.models import Context
from cmp.core.result import Result
from cmp.core.exceptions import ContextError
from cmp.services.context_service import ContextService
from cmp.services.policy_service import MockPolicyService
from cmp.services.orchestration_service import OrchestrationService
from cmp.storage.context_store import InMemoryContextStore
from cmp.core.observable import ContextObservable
from cmp.orchestration.strategies import Agent
from cmp.di.decorators import set_service_container

class ServiceContainer:
    """Simple service container for dependency injection"""

    def __init__(self, tenant_id: str):
        self.tenant_id = tenant_id
        self._services: dict[str, Any] = {}
        self._current_context: Optional[Context] = None

    def register_service(self, name: str, service: Any) -> None:
        """Register a service"""
        self._services[name] = service

    def get_service(self, name: str) -> Any:
        """Get a service"""
        return self._services.get(name)

    def set_current_context(self, context: Context) -> None:
        """Set current context"""
        self._current_context = context

    def get_current_context(self) -> Context:
        """Get current context"""
        if self._current_context is None:
            raise RuntimeError("No current context set")
        return self._current_context

class ContextBuilder:
    """Builder for creating contexts via SDK"""
    
    def __init__(self, context_service: ContextService, tenant_id: str):
        self._service = context_service
        self._tenant_id = tenant_id
        self._data: dict[str, Any] = {}
        self._schema_name: str = "default"
        self._metadata: dict[str, Any] = {}

    def with_data(self, data: dict[str, Any]) -> 'ContextBuilder':
        self._data = data
        return self

    def with_schema(self, schema_name: str) -> 'ContextBuilder':
        self._schema_name = schema_name
        return self

    def with_metadata(self, **kwargs: Any) -> 'ContextBuilder':
        self._metadata.update(kwargs)
        return self

    async def create(self) -> str:
        result = await self._service.create(
            data=self._data,
            schema_name=self._schema_name,
            tenant_id=self._tenant_id,
            **self._metadata
        )
        return result.unwrap()

class WorkflowBuilder:
    """Builder for executing workflows via SDK"""
    
    def __init__(
        self,
        workflow_name: str,
        context_service: ContextService,
        orchestration_service: OrchestrationService,
        tenant_id: str
    ):
        self._workflow_name = workflow_name
        self._context_service = context_service
        self._orchestration_service = orchestration_service
        self._tenant_id = tenant_id
        self._context_id: Optional[str] = None
        self._agents: list[Agent] = []

    def with_context(self, context_id: str) -> 'WorkflowBuilder':
        self._context_id = context_id
        return self

    def with_agents(self, agents: list[Agent]) -> 'WorkflowBuilder':
        self._agents = agents
        return self

    async def execute(self) -> AsyncIterator[Context]:
        if not self._context_id:
            raise ValueError("Context ID is required")
        
        # Get context
        context_result = await self._context_service.get(self._context_id)
        if context_result.is_err():
            raise ValueError(f"Context not found: {self._context_id}")
        
        context = context_result.unwrap()
        
        async for result in self._orchestration_service.execute_workflow(
            self._workflow_name,
            context,
            self._agents
        ):
            yield result

class CMP:
    """Main CMP framework client.

    Provides fluent API for context management and workflow execution.
    """

    def __init__(self, tenant_id: str, config: Optional[dict[str, Any]] = None):
        """Initialize CMP client.

        Args:
            tenant_id: Tenant ID for multi-tenancy
            config: Optional configuration dict
        """
        self.tenant_id = tenant_id
        self.config = config or {}

        # Initialize services
        self._store = InMemoryContextStore()
        self._observable = ContextObservable()
        self._policy_service = MockPolicyService()

        self._context_service = ContextService(
            store=self._store,
            schema_registry=None,  # TODO: Implement
            policy_service=self._policy_service,
            observable=self._observable,
        )

        self._orchestration_service = OrchestrationService(
            policy_service=self._policy_service,
        )

        # Setup service container for DI
        self._container = ServiceContainer(tenant_id)
        self._container.register_service('context_service', self._context_service)
        self._container.register_service('policy_service', self._policy_service)
        self._container.register_service('orchestration_service', self._orchestration_service)

        # Set global container for decorators
        set_service_container(self._container)

    def context(self) -> 'ContextBuilder':
        """Start building a context"""
        return ContextBuilder(self._context_service, self.tenant_id)

    def workflow(self, workflow_name: str) -> 'WorkflowBuilder':
        """Start building a workflow"""
        return WorkflowBuilder(
            workflow_name,
            self._context_service,
            self._orchestration_service,
            self.tenant_id,
        )

    async def register_agent(self, agent: Agent) -> None:
        """Register an agent (placeholder for future agent registry)"""
        # TODO: Implement agent registry
        pass

    @property
    def services(self) -> ServiceContainer:
        """Get service container"""
        return self._container

# Alias for backward compatibility
CMPClient = CMP
