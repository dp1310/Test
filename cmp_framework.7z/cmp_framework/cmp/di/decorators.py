"""
Dependency injection decorators for context and knowledge injection.
"""

from functools import wraps
from typing import Callable, TypeVar, ParamSpec, Awaitable, Any, Optional

P = ParamSpec('P')
R = TypeVar('R')

# Global service container (will be set by CMP client)
_service_container: Optional[Any] = None


def set_service_container(container: Any) -> None:
    """Set global service container"""
    global _service_container
    _service_container = container


def get_service_container() -> Any:
    """Get global service container"""
    if _service_container is None:
        raise RuntimeError("Service container not initialized. Call CMP() first.")
    return _service_container


def context(context_id: Optional[str] = None, schema: Optional[str] = None):
    """
    Decorator for context injection.
    
    Injects context into the decorated function's 'context' parameter.
    
    Args:
        context_id: Specific context ID to inject
        schema: Schema name to search for
        
    Example:
        @context(schema="user_profile")
        async def process(self, input_data: dict, context: Context):
            # context is automatically injected
            user_id = context.data['user_id']
    """
    def decorator(func: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            # Get context service from container
            container = get_service_container()
            context_service = container.get_service('context_service')
            
            # Resolve context
            if context_id:
                result = await context_service.get(context_id)
                if result.is_ok():
                    ctx = result.unwrap()
                else:
                    raise RuntimeError(f"Failed to get context: {result.error}")
            elif schema:
                # Search for context by schema
                async for ctx in context_service.search(
                    query={"schema": schema},
                    tenant_id=container.tenant_id,
                    limit=1
                ):
                    break
                else:
                    raise RuntimeError(f"No context found for schema: {schema}")
            else:
                # Get current context from container
                ctx = container.get_current_context()
            
            # Inject into kwargs
            kwargs['context'] = ctx
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def knowledge(source: str):
    """
    Decorator for knowledge source injection.
    
    Injects knowledge source into the decorated function's 'knowledge' parameter.
    
    Args:
        source: Knowledge source name
        
    Example:
        @knowledge(source="vector_db")
        async def process(self, query: str, knowledge: Knowledge):
            # knowledge is automatically injected
            results = await knowledge.search(query)
    """
    def decorator(func: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            # Get knowledge service from container
            container = get_service_container()
            knowledge_service = container.get_service('knowledge_service')
            
            # Get knowledge source
            knowledge_src = await knowledge_service.get_source(source, container.tenant_id)
            if not knowledge_src:
                raise RuntimeError(f"Knowledge source not found: {source}")
            
            # Inject into kwargs
            kwargs['knowledge'] = knowledge_src
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def envelope():
    """
    Decorator for full context envelope injection.
    
    Injects full ContextEnvelope instead of just Context.
    
    Example:
        @envelope()
        async def process(self, input_data: dict, context: ContextEnvelope):
            # Full envelope with metadata, provenance, etc.
            provenance = context.provenance
    """
    def decorator(func: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            container = get_service_container()
            context_service = container.get_service('context_service')
            
            # Get current context ID
            current_ctx = container.get_current_context()
            
            # Get full envelope
            result = await context_service.get_envelope(current_ctx.id)
            if result.is_ok():
                env = result.unwrap()
            else:
                raise RuntimeError(f"Failed to get envelope: {result.error}")
            
            # Inject into kwargs
            kwargs['context'] = env
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator
