"""DI module initialization"""

from cmp.di.decorators import context, knowledge, envelope, set_service_container

__all__ = ["context", "knowledge", "envelope", "set_service_container"]
