"""
Configuration management for CMP Framework.

This module provides centralized configuration using Pydantic Settings with support for:
- Environment variables (with CMP_ prefix)
- YAML configuration files
- Configuration validation
- Environment-specific configs (dev/staging/prod)
"""

from typing import Optional, Literal
from pathlib import Path
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
import yaml


class StorageConfig(BaseSettings):
    """Storage backend configuration."""
    
    backend: Literal["memory", "sqlite", "postgres", "redis"] = Field(
        default="memory",
        description="Storage backend type"
    )
    url: Optional[str] = Field(
        default=None,
        description="Connection URL for database backends"
    )
    pool_size: int = Field(
        default=10,
        description="Connection pool size for database backends"
    )
    pool_timeout: int = Field(
        default=30,
        description="Connection pool timeout in seconds"
    )


class MonitoringConfig(BaseSettings):
    """Monitoring and observability configuration."""
    
    enable_tracing: bool = Field(
        default=False,
        description="Enable distributed tracing with OpenTelemetry"
    )
    tracing_endpoint: Optional[str] = Field(
        default=None,
        description="OpenTelemetry collector endpoint (e.g., http://localhost:4318)"
    )
    tracing_service_name: str = Field(
        default="cmp-framework",
        description="Service name for tracing"
    )
    
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = Field(
        default="INFO",
        description="Logging level"
    )
    log_format: Literal["json", "text"] = Field(
        default="json",
        description="Log output format"
    )
    
    enable_metrics: bool = Field(
        default=True,
        description="Enable Prometheus metrics"
    )
    metrics_port: int = Field(
        default=9090,
        description="Port for Prometheus metrics endpoint"
    )


class APIConfig(BaseSettings):
    """API server configuration."""
    
    host: str = Field(
        default="0.0.0.0",
        description="API server host"
    )
    port: int = Field(
        default=8000,
        description="API server port"
    )
    workers: int = Field(
        default=4,
        description="Number of worker processes"
    )
    reload: bool = Field(
        default=False,
        description="Enable auto-reload for development"
    )
    
    cors_origins: list[str] = Field(
        default=["*"],
        description="CORS allowed origins"
    )
    cors_credentials: bool = Field(
        default=True,
        description="CORS allow credentials"
    )
    
    rate_limit_enabled: bool = Field(
        default=True,
        description="Enable rate limiting"
    )
    rate_limit_requests: int = Field(
        default=100,
        description="Max requests per window"
    )
    rate_limit_window: int = Field(
        default=60,
        description="Rate limit window in seconds"
    )


class SecurityConfig(BaseSettings):
    """Security configuration."""
    
    jwt_secret: str = Field(
        default="change-me-in-production",
        description="JWT signing secret (MUST be changed in production)"
    )
    jwt_algorithm: str = Field(
        default="HS256",
        description="JWT signing algorithm"
    )
    jwt_expiry: int = Field(
        default=3600,
        description="JWT token expiry in seconds"
    )
    
    api_key_header: str = Field(
        default="X-API-Key",
        description="Header name for API key authentication"
    )
    
    enable_auth: bool = Field(
        default=True,
        description="Enable authentication (disable only for development)"
    )
    
    @field_validator("jwt_secret")
    @classmethod
    def validate_jwt_secret(cls, v: str) -> str:
        """Validate JWT secret is not default in production."""
        if v == "change-me-in-production":
            import os
            if os.getenv("CMP_ENVIRONMENT", "development") == "production":
                raise ValueError(
                    "JWT secret must be changed in production! "
                    "Set CMP_SECURITY__JWT_SECRET environment variable."
                )
        return v


class ServiceConfig(BaseSettings):
    """External service configuration."""
    
    opa_url: str = Field(
        default="http://localhost:8181",
        description="Open Policy Agent URL"
    )
    opa_timeout: int = Field(
        default=5,
        description="OPA request timeout in seconds"
    )
    
    sage_mcp_url: Optional[str] = Field(
        default=None,
        description="SageMCP service URL"
    )
    sage_mcp_timeout: int = Field(
        default=10,
        description="SageMCP request timeout in seconds"
    )
    
    temporal_url: Optional[str] = Field(
        default=None,
        description="Temporal service URL"
    )
    temporal_namespace: str = Field(
        default="default",
        description="Temporal namespace"
    )


class RegistryConfig(BaseSettings):
    """Registry configuration."""
    
    persistence_backend: Literal["file", "sqlite", "postgres"] = Field(
        default="file",
        description="Registry persistence backend"
    )
    persistence_path: Path = Field(
        default=Path("./data/registries"),
        description="Path for file-based registry storage"
    )
    
    cache_enabled: bool = Field(
        default=True,
        description="Enable registry caching"
    )
    cache_ttl: int = Field(
        default=300,
        description="Cache TTL in seconds"
    )
    cache_max_size: int = Field(
        default=1000,
        description="Maximum cache entries"
    )


class CMPConfig(BaseSettings):
    """Main CMP Framework configuration."""
    
    model_config = SettingsConfigDict(
        env_prefix="CMP_",
        env_nested_delimiter="__",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    # Environment
    environment: Literal["development", "staging", "production"] = Field(
        default="development",
        description="Deployment environment"
    )
    debug: bool = Field(
        default=False,
        description="Enable debug mode"
    )
    
    # Component configurations
    storage: StorageConfig = Field(default_factory=StorageConfig)
    monitoring: MonitoringConfig = Field(default_factory=MonitoringConfig)
    api: APIConfig = Field(default_factory=APIConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    services: ServiceConfig = Field(default_factory=ServiceConfig)
    registry: RegistryConfig = Field(default_factory=RegistryConfig)
    
    @classmethod
    def from_yaml(cls, config_path: str | Path) -> "CMPConfig":
        """
        Load configuration from YAML file.
        
        Args:
            config_path: Path to YAML configuration file
            
        Returns:
            CMPConfig instance
            
        Example:
            >>> config = CMPConfig.from_yaml("config/production.yaml")
        """
        config_path = Path(config_path)
        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        with open(config_path, "r", encoding="utf-8") as f:
            yaml_data = yaml.safe_load(f)
        
        return cls(**yaml_data)
    
    def to_yaml(self, output_path: str | Path) -> None:
        """
        Export configuration to YAML file.
        
        Args:
            output_path: Path to write YAML configuration
            
        Example:
            >>> config.to_yaml("config/current.yaml")
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, "w", encoding="utf-8") as f:
            yaml.dump(
                self.model_dump(mode="json"),
                f,
                default_flow_style=False,
                sort_keys=False
            )
    
    @field_validator("environment")
    @classmethod
    def validate_environment(cls, v: str) -> str:
        """Validate environment setting."""
        if v == "production":
            # Additional production checks can be added here
            pass
        return v


# Global configuration instance
_config: Optional[CMPConfig] = None


def get_config() -> CMPConfig:
    """
    Get the global configuration instance.
    
    Returns:
        CMPConfig instance
        
    Example:
        >>> config = get_config()
        >>> print(config.storage.backend)
    """
    global _config
    if _config is None:
        _config = CMPConfig()
    return _config


def set_config(config: CMPConfig) -> None:
    """
    Set the global configuration instance.
    
    Args:
        config: CMPConfig instance to set as global
        
    Example:
        >>> config = CMPConfig.from_yaml("config.yaml")
        >>> set_config(config)
    """
    global _config
    _config = config


def reset_config() -> None:
    """
    Reset the global configuration to None.
    
    Useful for testing.
    """
    global _config
    _config = None
