"""
Async utilities and helpers for concurrent operations.
"""

import asyncio
from typing import TypeVar, Callable, Awaitable, Generic, Optional
from asyncio import Future

T = TypeVar('T')


class ContextFuture(Generic[T]):
    """Wrapper for context operations with callbacks"""
    
    def __init__(self, coro: Awaitable[T]):
        self._future: Future[T] = asyncio.ensure_future(coro)
        self._callbacks: list[Callable[[T], None]] = []
        self._error_callbacks: list[Callable[[Exception], None]] = []
        self._finally_callbacks: list[Callable[[], None]] = []
    
    def then(self, callback: Callable[[T], None]) -> 'ContextFuture[T]':
        """Add success callback"""
        self._callbacks.append(callback)
        
        def done_callback(fut: Future[T]) -> None:
            if not fut.exception():
                callback(fut.result())
        
        self._future.add_done_callback(done_callback)
        return self
    
    def catch(self, error_callback: Callable[[Exception], None]) -> 'ContextFuture[T]':
        """Add error callback"""
        self._error_callbacks.append(error_callback)
        
        def done_callback(fut: Future[T]) -> None:
            exc = fut.exception()
            if exc:
                error_callback(exc)
        
        self._future.add_done_callback(done_callback)
        return self
    
    def finally_(self, callback: Callable[[], None]) -> 'ContextFuture[T]':
        """Add finally callback"""
        self._finally_callbacks.append(callback)
        self._future.add_done_callback(lambda _: callback())
        return self
    
    async def await_(self) -> T:
        """Await the future"""
        return await self._future
    
    def __await__(self):
        """Make ContextFuture awaitable"""
        return self._future.__await__()


class AsyncLock:
    """Async lock with context manager support"""
    
    def __init__(self):
        self._lock = asyncio.Lock()
    
    async def __aenter__(self):
        await self._lock.acquire()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self._lock.release()


class AsyncPool:
    """Simple async connection pool"""
    
    def __init__(self, factory: Callable[[], Awaitable[T]], max_size: int = 10):
        self._factory = factory
        self._max_size = max_size
        self._pool: asyncio.Queue[T] = asyncio.Queue(maxsize=max_size)
        self._size = 0
        self._lock = asyncio.Lock()
    
    async def acquire(self) -> T:
        """Acquire a connection from the pool"""
        if not self._pool.empty():
            return await self._pool.get()
        
        async with self._lock:
            if self._size < self._max_size:
                self._size += 1
                return await self._factory()
        
        # Wait for available connection
        return await self._pool.get()
    
    async def release(self, conn: T) -> None:
        """Release a connection back to the pool"""
        await self._pool.put(conn)
    
    async def close(self) -> None:
        """Close all connections"""
        while not self._pool.empty():
            conn = await self._pool.get()
            if hasattr(conn, 'close'):
                await conn.close()  # type: ignore


async def gather_dict(tasks: dict[str, Awaitable[T]]) -> dict[str, T]:
    """
    Gather async tasks and return results as dictionary.
    
    Example:
        results = await gather_dict({
            "user": fetch_user(),
            "posts": fetch_posts()
        })
        # results = {"user": ..., "posts": ...}
    """
    keys = list(tasks.keys())
    values = await asyncio.gather(*[tasks[k] for k in keys])
    return dict(zip(keys, values))


async def retry(
    func: Callable[[], Awaitable[T]],
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0
) -> T:
    """
    Retry an async function with exponential backoff.
    
    Args:
        func: Async function to retry
        max_attempts: Maximum number of attempts
        delay: Initial delay between retries (seconds)
        backoff: Backoff multiplier
    """
    last_exception: Optional[Exception] = None
    current_delay = delay
    
    for attempt in range(max_attempts):
        try:
            return await func()
        except Exception as e:
            last_exception = e
            if attempt < max_attempts - 1:
                await asyncio.sleep(current_delay)
                current_delay *= backoff
    
    if last_exception:
        raise last_exception
    raise RuntimeError("Retry failed with no exception")

async def async_map(func: Callable[[T], Awaitable[T]], iterable: list[T]) -> list[T]:
    """Apply an async function to each item in *iterable* concurrently and return a list of results.
    Equivalent to ``[await func(x) for x in iterable]`` but runs all calls in parallel.
    """
    return await asyncio.gather(*[func(item) for item in iterable])

async def async_filter(predicate: Callable[[T], Awaitable[bool]], iterable: list[T]) -> list[T]:
    """Filter *iterable* by an async *predicate*.
    Returns a list of items for which ``await predicate(item)`` is ``True``.
    """
    results = await asyncio.gather(*[predicate(item) for item in iterable])
    return [item for item, keep in zip(iterable, results) if keep]

