"""
Functional programming utilities for composition and pipelines.
"""

from typing import Callable, TypeVar, Awaitable
from functools import reduce

T = TypeVar('T')
U = TypeVar('U')
V = TypeVar('V')

def compose(*functions: Callable) -> Callable:
    """Compose functions right-to-left.

    Example:
        f = compose(str.upper, str.strip)
        f("  hello  ")  # "HELLO"
    """
    return reduce(lambda f, g: lambda x: f(g(x)), functions, lambda x: x)

def pipe(*args: Callable) -> any:
    """Compose functions left-to-right.

    If the first argument is a non-callable value, the pipeline is applied
    immediately to that value and the result is returned. This matches the
    usage in the test suite where ``pipe(3, add_one, mul_two)`` should yield ``8``.
    Otherwise, a callable pipeline is returned.
    """
    if not args:
        raise ValueError("pipe requires at least one argument")
    if not callable(args[0]):
        value = args[0]
        for func in args[1:]:
            value = func(value)
        return value
    return reduce(lambda f, g: lambda x: g(f(x)), args, lambda x: x)

async def acompose(*functions: Callable[[T], Awaitable[U]]) -> Callable[[T], Awaitable[U]]:
    """Async function composition (right-to-left).

    Example:
        async def add_one(x): return x + 1
        async def double(x): return x * 2
        f = await acompose(double, add_one)
        await f(5)  # 12 (double(add_one(5)))
    """
    async def composed(x: T) -> U:
        result = x
        for func in reversed(functions):
            result = await func(result)  # type: ignore
        return result  # type: ignore
    return composed

async def apipe(*functions: Callable[[T], Awaitable[U]]) -> Callable[[T], Awaitable[U]]:
    """Async pipeline composition (left-to-right).

    Example:
        async def add_one(x): return x + 1
        async def double(x): return x * 2
        f = await apipe(add_one, double)
        await f(5)  # 12 (double(add_one(5)))
    """
    async def piped(x: T) -> U:
        result = x
        for func in functions:
            result = await func(result)  # type: ignore
        return result  # type: ignore
    return piped

def curry(func: Callable) -> Callable:
    """Curry a function to enable partial application.

    Example:
        def add(a, b, c): return a + b + c
        curried_add = curry(add)
        add_5 = curried_add(5)
        add_5_and_3 = add_5(3)
        result = add_5_and_3(2)  # 10
    """
    def curried(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except TypeError:
            return lambda *more_args, **more_kwargs: curried(
                *(args + more_args),
                **{**kwargs, **more_kwargs}
            )
    return curried

def identity(x: T) -> T:
    """Identity function (returns input unchanged)"""
    return x

def const(value: T) -> Callable[..., T]:
    """Create a function that always returns the same value"""
    return lambda *args, **kwargs: value
