"""
Builder pattern implementations for fluent API construction.
"""

from typing import Optional, Self, Any
from datetime import datetime, timezone
from cmp.core.models import (
    ContextEnvelope,
    Schema,
    Policy,
    Provenance,
    Metadata,
    ValidationStatus,
    LifecycleState
)


class ContextEnvelopeBuilder:
    """Fluent builder for context envelopes"""
    
    def __init__(self):
        self._id: Optional[str] = None
        self._data: Optional[dict[str, Any]] = None
        self._schema: Optional[Schema] = None
        self._policy: Optional[Policy] = None
        self._provenance: Provenance = Provenance.empty()
        self._metadata: Optional[Metadata] = None
        self._validation_status: ValidationStatus = ValidationStatus.PENDING
        self._lifecycle_state: LifecycleState = LifecycleState.ACTIVE
        self._ttl: Optional[int] = None
    
    def with_id(self, context_id: str) -> Self:
        """Set context ID"""
        builder = self._copy()
        builder._id = context_id
        return builder
    
    def with_data(self, data: dict[str, Any]) -> Self:
        """Set context data"""
        builder = self._copy()
        builder._data = data
        return builder
    
    def with_schema(self, schema: Schema) -> Self:
        """Set validation schema"""
        builder = self._copy()
        builder._schema = schema
        return builder
    
    def with_policy(self, policy: Policy) -> Self:
        """Set governance policy"""
        builder = self._copy()
        builder._policy = policy
        return builder
    
    def with_provenance(self, source: str, agent_id: str) -> Self:
        """Add provenance tracking"""
        builder = self._copy()
        builder._provenance = self._provenance.add_step(
            source=source,
            agent_id=agent_id,
            timestamp=datetime.now(timezone.utc)
        )
        return builder
    
    def with_metadata(self, tenant_id: str, **kwargs: Any) -> Self:
        """Set metadata"""
        builder = self._copy()
        if self._metadata is None:
            builder._metadata = Metadata(tenant_id=tenant_id, custom=kwargs)
        else:
            builder._metadata = self._metadata.update(**kwargs)
        return builder
    
    def with_ttl(self, ttl_seconds: int) -> Self:
        """Set time-to-live"""
        builder = self._copy()
        builder._ttl = ttl_seconds
        return builder
    
    async def build(self) -> ContextEnvelope:
        """Build and validate envelope"""
        if not self._id:
            raise ValueError("Context ID is required")
        if not self._data:
            raise ValueError("Data is required")
        if not self._schema:
            raise ValueError("Schema is required")
        if not self._metadata:
            raise ValueError("Metadata is required")
        
        # Validate data against schema
        try:
            await self._schema.validate(self._data)
            validation_status = ValidationStatus.VALID
            validation_errors: tuple[str, ...] = ()
        except Exception as e:
            validation_status = ValidationStatus.INVALID
            validation_errors = (str(e),)
        
        return ContextEnvelope(
            id=self._id,
            data=self._data,
            schema=self._schema,
            policy=self._policy or Policy.default(),
            provenance=self._provenance,
            metadata=self._metadata,
            validation_status=validation_status,
            validation_errors=validation_errors,
            lifecycle_state=self._lifecycle_state,
            ttl=self._ttl
        )
    
    def _copy(self) -> Self:
        """Create a copy of the builder"""
        builder = ContextEnvelopeBuilder()
        builder._id = self._id
        builder._data = self._data
        builder._schema = self._schema
        builder._policy = self._policy
        builder._provenance = self._provenance
        builder._metadata = self._metadata
        builder._validation_status = self._validation_status
        builder._lifecycle_state = self._lifecycle_state
        builder._ttl = self._ttl
        return builder  # type: ignore
