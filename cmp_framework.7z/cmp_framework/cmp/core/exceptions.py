"""
Custom exceptions for CMP framework.
"""


class CMPError(Exception):
    """Base exception for CMP framework"""
    pass


class ContextError(CMPError):
    """Base exception for context operations"""
    pass


class ContextNotFoundError(ContextError):
    """Context not found in store"""
    
    def __init__(self, context_id: str):
        self.context_id = context_id
        super().__init__(f"Context not found: {context_id}")


class SchemaNotFoundError(ContextError):
    """Schema not found in registry"""
    
    def __init__(self, schema_name: str):
        self.schema_name = schema_name
        super().__init__(f"Schema not found: {schema_name}")


class PolicyViolationError(CMPError):
    """Policy violation occurred"""
    
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(f"Policy violation: {reason}")


class ValidationError(ContextError):
    """Context validation failed"""
    
    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__(f"Validation failed: {', '.join(errors)}")


class OrchestrationError(CMPError):
    """Orchestration execution failed"""
    pass


class StorageError(CMPError):
    """Storage operation failed"""
    pass


class RegistryError(CMPError):
    """Registry operation failed"""
    pass
