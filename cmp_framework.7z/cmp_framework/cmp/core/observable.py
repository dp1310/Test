"""
Observer pattern implementation for context events.
"""

import asyncio
from typing import Callable, Awaitable, List
from cmp.core.models import ContextEvent


class ContextObservable:
    """Observable for context events using Observer pattern"""
    
    def __init__(self):
        self._observers: List[Callable[[ContextEvent], Awaitable[None]]] = []
        self._lock = asyncio.Lock()
    
    def subscribe(self, observer: Callable[[ContextEvent], Awaitable[None]]) -> None:
        """
        Subscribe to context events.
        
        Args:
            observer: Async callback function that receives ContextEvent
        """
        self._observers.append(observer)
    
    def unsubscribe(self, observer: Callable[[ContextEvent], Awaitable[None]]) -> None:
        """
        Unsubscribe from context events.
        
        Args:
            observer: Previously subscribed callback function
        """
        if observer in self._observers:
            self._observers.remove(observer)
    
    async def notify(self, event: ContextEvent) -> None:
        """
        Notify all observers asynchronously.
        
        Args:
            event: ContextEvent to broadcast to observers
        """
        async with self._lock:
            # Create tasks for all observers
            tasks = [obs(event) for obs in self._observers]
            
            # Execute all observers concurrently
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
    
    def clear(self) -> None:
        """Remove all observers"""
        self._observers.clear()
    
    @property
    def observer_count(self) -> int:
        """Get number of registered observers"""
        return len(self._observers)
