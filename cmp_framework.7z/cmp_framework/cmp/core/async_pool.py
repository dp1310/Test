"""
Async worker pool for concurrent task execution.

Provides a pool of async workers with backpressure handling and task queuing.
"""

import asyncio
from typing import Callable, Any, Optional, TypeVar, Generic
from dataclasses import dataclass
from datetime import datetime
import logging

T = TypeVar('T')
R = TypeVar('R')

logger = logging.getLogger(__name__)


@dataclass
class TaskResult(Generic[R]):
    """Result of a task execution."""
    
    task_id: str
    result: Optional[R]
    error: Optional[Exception]
    start_time: datetime
    end_time: datetime
    
    @property
    def duration(self) -> float:
        """Duration in seconds."""
        return (self.end_time - self.start_time).total_seconds()
    
    @property
    def success(self) -> bool:
        """Whether task succeeded."""
        return self.error is None


class AsyncWorkerPool(Generic[T, R]):
    """
    Async worker pool for concurrent task execution.
    
    Example:
        >>> async def process_item(item: int) -> int:
        ...     await asyncio.sleep(0.1)
        ...     return item * 2
        >>> 
        >>> pool = AsyncWorkerPool(worker_count=4, max_queue_size=100)
        >>> await pool.start()
        >>> 
        >>> # Submit tasks
        >>> for i in range(10):
        ...     await pool.submit(f"task-{i}", process_item, i)
        >>> 
        >>> # Wait for completion
        >>> results = await pool.wait_all()
        >>> await pool.stop()
    """
    
    def __init__(
        self,
        worker_count: int = 4,
        max_queue_size: int = 100,
        timeout: Optional[float] = None
    ):
        """
        Initialize worker pool.
        
        Args:
            worker_count: Number of concurrent workers
            max_queue_size: Maximum queue size (for backpressure)
            timeout: Task timeout in seconds
        """
        self.worker_count = worker_count
        self.max_queue_size = max_queue_size
        self.timeout = timeout
        
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=max_queue_size)
        self._workers: list[asyncio.Task] = []
        self._results: dict[str, TaskResult] = {}
        self._running = False
        self._tasks_submitted = 0
        self._tasks_completed = 0
    
    async def start(self):
        """Start worker pool."""
        if self._running:
            return
        
        self._running = True
        self._workers = [
            asyncio.create_task(self._worker(i))
            for i in range(self.worker_count)
        ]
        logger.info(f"Started worker pool with {self.worker_count} workers")
    
    async def stop(self):
        """Stop worker pool."""
        if not self._running:
            return
        
        self._running = False
        
        # Wait for queue to empty
        await self._queue.join()
        
        # Cancel workers
        for worker in self._workers:
            worker.cancel()
        
        # Wait for workers to finish
        await asyncio.gather(*self._workers, return_exceptions=True)
        
        logger.info("Stopped worker pool")
    
    async def submit(
        self,
        task_id: str,
        func: Callable[[T], R],
        *args: Any,
        **kwargs: Any
    ):
        """
        Submit task to pool.
        
        Args:
            task_id: Unique task identifier
            func: Async function to execute
            *args: Positional arguments for function
            **kwargs: Keyword arguments for function
        """
        if not self._running:
            raise RuntimeError("Worker pool not started")
        
        await self._queue.put((task_id, func, args, kwargs))
        self._tasks_submitted += 1
    
    async def wait_all(self) -> dict[str, TaskResult]:
        """
        Wait for all tasks to complete.
        
        Returns:
            Dictionary mapping task IDs to results
        """
        await self._queue.join()
        return self._results.copy()
    
    async def get_result(self, task_id: str) -> Optional[TaskResult]:
        """
        Get result for specific task.
        
        Args:
            task_id: Task identifier
            
        Returns:
            TaskResult if available, None otherwise
        """
        return self._results.get(task_id)
    
    def get_stats(self) -> dict:
        """Get pool statistics."""
        return {
            "worker_count": self.worker_count,
            "queue_size": self._queue.qsize(),
            "max_queue_size": self.max_queue_size,
            "tasks_submitted": self._tasks_submitted,
            "tasks_completed": self._tasks_completed,
            "tasks_pending": self._tasks_submitted - self._tasks_completed,
            "success_rate": (
                sum(1 for r in self._results.values() if r.success) / 
                len(self._results) * 100
            ) if self._results else 0
        }
    
    async def _worker(self, worker_id: int):
        """Worker coroutine."""
        logger.debug(f"Worker {worker_id} started")
        
        while self._running:
            try:
                # Get task from queue
                task_id, func, args, kwargs = await asyncio.wait_for(
                    self._queue.get(),
                    timeout=1.0
                )
                
                # Execute task
                start_time = datetime.utcnow()
                error = None
                result = None
                
                try:
                    if self.timeout:
                        result = await asyncio.wait_for(
                            func(*args, **kwargs),
                            timeout=self.timeout
                        )
                    else:
                        result = await func(*args, **kwargs)
                
                except Exception as e:
                    error = e
                    logger.error(f"Task {task_id} failed: {e}")
                
                end_time = datetime.utcnow()
                
                # Store result
                self._results[task_id] = TaskResult(
                    task_id=task_id,
                    result=result,
                    error=error,
                    start_time=start_time,
                    end_time=end_time
                )
                
                self._tasks_completed += 1
                self._queue.task_done()
                
            except asyncio.TimeoutError:
                # No tasks available, continue
                continue
            
            except asyncio.CancelledError:
                break
            
            except Exception as e:
                logger.error(f"Worker {worker_id} error: {e}")
        
        logger.debug(f"Worker {worker_id} stopped")


class BatchProcessor(Generic[T, R]):
    """
    Batch processor using worker pool.
    
    Example:
        >>> async def process(item: int) -> int:
        ...     return item * 2
        >>> 
        >>> processor = BatchProcessor(process, worker_count=4)
        >>> results = await processor.process_batch([1, 2, 3, 4, 5])
    """
    
    def __init__(
        self,
        process_func: Callable[[T], R],
        worker_count: int = 4,
        batch_size: int = 100
    ):
        """
        Initialize batch processor.
        
        Args:
            process_func: Function to process each item
            worker_count: Number of concurrent workers
            batch_size: Maximum batch size
        """
        self.process_func = process_func
        self.worker_count = worker_count
        self.batch_size = batch_size
    
    async def process_batch(self, items: list[T]) -> list[TaskResult[R]]:
        """
        Process batch of items.
        
        Args:
            items: Items to process
            
        Returns:
            List of TaskResults
        """
        pool = AsyncWorkerPool(
            worker_count=self.worker_count,
            max_queue_size=len(items)
        )
        
        await pool.start()
        
        try:
            # Submit all items
            for i, item in enumerate(items):
                await pool.submit(f"item-{i}", self.process_func, item)
            
            # Wait for completion
            results = await pool.wait_all()
            
            # Return in order
            return [results[f"item-{i}"] for i in range(len(items))]
        
        finally:
            await pool.stop()
