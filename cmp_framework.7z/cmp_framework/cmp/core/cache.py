"""
Unified caching layer for CMP Framework.

Provides multiple cache backends with consistent interface.
"""

from typing import Any, Optional, Protocol
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
import json
import asyncio
from cachetools import TTLCache


class CacheBackend(Protocol):
    """Protocol for cache backends."""
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        ...
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value in cache."""
        ...
    
    async def delete(self, key: str) -> None:
        """Delete value from cache."""
        ...
    
    async def clear(self) -> None:
        """Clear all cache entries."""
        ...
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        ...


class InMemoryCache(CacheBackend):
    """In-memory cache backend using cachetools."""
    
    def __init__(self, maxsize: int = 1000, ttl: int = 300):
        """
        Initialize in-memory cache.
        
        Args:
            maxsize: Maximum number of cache entries
            ttl: Default TTL in seconds
        """
        self.cache = TTLCache(maxsize=maxsize, ttl=ttl)
        self._lock = asyncio.Lock()
        self.default_ttl = ttl
        
        # Statistics
        self.hits = 0
        self.misses = 0
        self.sets = 0
        self.deletes = 0
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        async with self._lock:
            if key in self.cache:
                self.hits += 1
                return self.cache[key]
            self.misses += 1
            return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value in cache."""
        async with self._lock:
            self.cache[key] = value
            self.sets += 1
    
    async def delete(self, key: str) -> None:
        """Delete value from cache."""
        async with self._lock:
            self.cache.pop(key, None)
            self.deletes += 1
    
    async def clear(self) -> None:
        """Clear all cache entries."""
        async with self._lock:
            self.cache.clear()
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        async with self._lock:
            return key in self.cache
    
    def get_stats(self) -> dict:
        """Get cache statistics."""
        total_requests = self.hits + self.misses
        hit_rate = (self.hits / total_requests * 100) if total_requests > 0 else 0
        
        return {
            "backend": "in-memory",
            "size": len(self.cache),
            "maxsize": self.cache.maxsize,
            "hits": self.hits,
            "misses": self.misses,
            "sets": self.sets,
            "deletes": self.deletes,
            "hit_rate": hit_rate
        }


class RedisCache(CacheBackend):
    """Redis cache backend."""
    
    def __init__(self, redis_url: str = "redis://localhost:6379", ttl: int = 300):
        """
        Initialize Redis cache.
        
        Args:
            redis_url: Redis connection URL
            ttl: Default TTL in seconds
        """
        self.redis_url = redis_url
        self.default_ttl = ttl
        self._redis = None
        
        # Statistics
        self.hits = 0
        self.misses = 0
        self.sets = 0
        self.deletes = 0
    
    async def _get_redis(self):
        """Get Redis connection."""
        if self._redis is None:
            try:
                import redis.asyncio as redis
                self._redis = await redis.from_url(self.redis_url, decode_responses=True)
            except ImportError:
                raise ImportError("redis package required for RedisCache. Install with: pip install redis")
        return self._redis
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        redis = await self._get_redis()
        value = await redis.get(key)
        
        if value is not None:
            self.hits += 1
            return json.loads(value)
        
        self.misses += 1
        return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value in cache."""
        redis = await self._get_redis()
        serialized = json.dumps(value)
        await redis.setex(key, ttl or self.default_ttl, serialized)
        self.sets += 1
    
    async def delete(self, key: str) -> None:
        """Delete value from cache."""
        redis = await self._get_redis()
        await redis.delete(key)
        self.deletes += 1
    
    async def clear(self) -> None:
        """Clear all cache entries."""
        redis = await self._get_redis()
        await redis.flushdb()
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        redis = await self._get_redis()
        return await redis.exists(key) > 0
    
    def get_stats(self) -> dict:
        """Get cache statistics."""
        total_requests = self.hits + self.misses
        hit_rate = (self.hits / total_requests * 100) if total_requests > 0 else 0
        
        return {
            "backend": "redis",
            "hits": self.hits,
            "misses": self.misses,
            "sets": self.sets,
            "deletes": self.deletes,
            "hit_rate": hit_rate
        }
    
    async def close(self):
        """Close Redis connection."""
        if self._redis:
            await self._redis.close()


class CacheManager:
    """
    Unified cache manager with multiple backends.
    
    Example:
        >>> cache = CacheManager(backend="memory", maxsize=1000, ttl=300)
        >>> 
        >>> # Set value
        >>> await cache.set("user:123", {"name": "John"})
        >>> 
        >>> # Get value
        >>> user = await cache.get("user:123")
        >>> 
        >>> # Get stats
        >>> stats = cache.get_stats()
        >>> print(f"Hit rate: {stats['hit_rate']:.1f}%")
    """
    
    def __init__(
        self,
        backend: str = "memory",
        maxsize: int = 1000,
        ttl: int = 300,
        redis_url: str = "redis://localhost:6379"
    ):
        """
        Initialize cache manager.
        
        Args:
            backend: Cache backend ("memory" or "redis")
            maxsize: Maximum cache size (for memory backend)
            ttl: Default TTL in seconds
            redis_url: Redis URL (for redis backend)
        """
        if backend == "memory":
            self.backend = InMemoryCache(maxsize=maxsize, ttl=ttl)
        elif backend == "redis":
            self.backend = RedisCache(redis_url=redis_url, ttl=ttl)
        else:
            raise ValueError(f"Unknown cache backend: {backend}")
        
        self.backend_type = backend
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        return await self.backend.get(key)
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value in cache."""
        await self.backend.set(key, value, ttl)
    
    async def delete(self, key: str) -> None:
        """Delete value from cache."""
        await self.backend.delete(key)
    
    async def clear(self) -> None:
        """Clear all cache entries."""
        await self.backend.clear()
    
    async def exists(self, key: str) -> bool:
        """Check if key exists."""
        return await self.backend.exists(key)
    
    def get_stats(self) -> dict:
        """Get cache statistics."""
        return self.backend.get_stats()
    
    async def close(self):
        """Close cache backend."""
        if hasattr(self.backend, 'close'):
            await self.backend.close()


# Global cache instance
_global_cache: Optional[CacheManager] = None


def get_cache() -> CacheManager:
    """Get global cache instance."""
    global _global_cache
    if _global_cache is None:
        from cmp.config import get_config
        config = get_config()
        
        _global_cache = CacheManager(
            backend=config.storage.backend if config.storage.backend in ["memory", "redis"] else "memory",
            maxsize=1000,
            ttl=300
        )
    
    return _global_cache


def set_cache(cache: CacheManager):
    """Set global cache instance."""
    global _global_cache
    _global_cache = cache
