"""
Core Data Models for CMP Framework.

This module defines the fundamental immutable data structures used throughout
the CMP Framework. All models follow functional programming principles and
are designed to be thread-safe.

SOLID Principles Applied:
    - Single Responsibility: Each model has one clear purpose
    - Open/Closed: Models are closed for modification, open for extension
    - Liskov Substitution: All models maintain consistent interfaces
    - Interface Segregation: Models expose only necessary attributes
    - Dependency Inversion: Models depend on abstractions (Mapping, not dict)

Key Models:
    - Context: Immutable context data with tenant isolation
    - ContextEnvelope: Wrapper with schema, policy, and provenance
    - Provenance: Immutable chain tracking context transformations
    - Metadata: Context metadata including versioning and lifecycle
    - Schema: Schema definition for validation
    - Policy: Policy definition for governance

Design Patterns:
    - Immutable Data Structures: All dataclasses are frozen
    - Value Objects: Models represent values, not entities
    - Builder Pattern: Separate builders for complex construction

Thread Safety:
    All models are immutable and thread-safe by design.

Example:
    >>> from cmp.core.models import Context
    >>> context = Context(
    ...     id="ctx_123",
    ...     data={"key": "value"},
    ...     tenant_id="tenant1"
    ... )
    >>> # Create new version with updated data
    >>> updated = context.with_data(new_key="new_value")
    >>> assert context.data != updated.data  # Original unchanged

See Also:
    - cmp.core.builders: Builder classes for complex model construction
    - cmp.services.context_service: Service layer for context operations
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping, Optional
from enum import Enum


class LifecycleState(Enum):
    """Context lifecycle states"""
    ACTIVE = "active"
    ARCHIVED = "archived"
    DELETED = "deleted"


class ValidationStatus(Enum):
    """Validation status for context data"""
    VALID = "valid"
    INVALID = "invalid"
    PENDING = "pending"


@dataclass(frozen=True)
class ProvenanceStep:
    """Single step in provenance chain"""
    source: str
    agent_id: str
    timestamp: datetime
    operation: str = "transform"
    metadata: Mapping[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return {
            "source": self.source,
            "agent_id": self.agent_id,
            "timestamp": self.timestamp.isoformat(),
            "operation": self.operation,
            "metadata": dict(self.metadata)
        }


@dataclass(frozen=True)
class Provenance:
    """Immutable provenance chain tracking context transformations"""
    steps: tuple[ProvenanceStep, ...] = field(default_factory=tuple)
    
    def add_step(
        self,
        source: str,
        agent_id: str,
        timestamp: datetime,
        operation: str = "transform",
        **metadata: Any
    ) -> 'Provenance':
        """Add a step to provenance chain (returns new instance)"""
        new_step = ProvenanceStep(
            source=source,
            agent_id=agent_id,
            timestamp=timestamp,
            operation=operation,
            metadata=metadata
        )
        return Provenance(steps=(*self.steps, new_step))
    
    @staticmethod
    def empty() -> 'Provenance':
        """Create empty provenance"""
        return Provenance(steps=())
    
    @classmethod
    def from_list(cls, steps_data: list[dict[str, Any]]) -> 'Provenance':
        """Create from list of step dictionaries"""
        steps = tuple(
            ProvenanceStep(
                source=step["source"],
                agent_id=step["agent_id"],
                timestamp=datetime.fromisoformat(step["timestamp"]),
                operation=step.get("operation", "transform"),
                metadata=step.get("metadata", {})
            )
            for step in steps_data
        )
        return cls(steps=steps)
    
    def to_list(self) -> list[dict[str, Any]]:
        """Convert to list of dictionaries"""
        return [step.to_dict() for step in self.steps]


@dataclass(frozen=True)
class Metadata:
    """Immutable metadata for context"""
    tenant_id: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    version: int = 1
    tags: tuple[str, ...] = field(default_factory=tuple)
    custom: Mapping[str, Any] = field(default_factory=dict)
    
    def update(self, **kwargs: Any) -> 'Metadata':
        """Update metadata (returns new instance)"""
        current_dict = self.to_dict()
        current_dict.update(kwargs)
        current_dict['updated_at'] = datetime.now(timezone.utc)
        return Metadata.from_dict(current_dict)
    
    def add_tag(self, tag: str) -> 'Metadata':
        """Add a tag (returns new instance)"""
        if tag in self.tags:
            return self
        return Metadata(
            tenant_id=self.tenant_id,
            created_at=self.created_at,
            updated_at=datetime.now(timezone.utc),
            version=self.version,
            tags=(*self.tags, tag),
            custom=self.custom
        )
    
    @staticmethod
    def default() -> 'Metadata':
        """Create default metadata (requires tenant_id to be set later)"""
        return Metadata(tenant_id="default")
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'Metadata':
        """Create from dictionary"""
        return cls(
            tenant_id=data["tenant_id"],
            created_at=data.get("created_at", datetime.now(timezone.utc)),
            updated_at=data.get("updated_at", datetime.now(timezone.utc)),
            version=data.get("version", 1),
            tags=tuple(data.get("tags", [])),
            custom=data.get("custom", {})
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return {
            "tenant_id": self.tenant_id,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "version": self.version,
            "tags": list(self.tags),
            "custom": dict(self.custom)
        }


@dataclass(frozen=True)
class Schema:
    """Schema definition for context validation"""
    name: str
    version: str
    fields: Mapping[str, Any]
    required_fields: tuple[str, ...] = field(default_factory=tuple)
    
    async def validate(self, data: dict[str, Any]) -> bool:
        """Validate data against schema"""
        # Check required fields
        for field_name in self.required_fields:
            if field_name not in data:
                raise ValueError(f"Missing required field: {field_name}")
        
        # TODO: Add more sophisticated validation
        return True
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return {
            "name": self.name,
            "version": self.version,
            "fields": dict(self.fields),
            "required_fields": list(self.required_fields)
        }


@dataclass(frozen=True)
class Policy:
    """Policy definition for governance"""
    name: str
    rules: Mapping[str, Any]
    tenant_id: str
    
    @staticmethod
    def default() -> 'Policy':
        """Create default policy"""
        return Policy(
            name="default",
            rules={},
            tenant_id="default"
        )
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'Policy':
        """Create from dictionary"""
        return cls(
            name=data.get("name", "default"),
            rules=data.get("rules", {}),
            tenant_id=data.get("tenant_id", "default")
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return {
            "name": self.name,
            "rules": dict(self.rules),
            "tenant_id": self.tenant_id
        }


@dataclass(frozen=True)
class Context:
    """Immutable context data"""
    id: str
    data: Mapping[str, Any]
    tenant_id: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    def with_data(self, **updates: Any) -> 'Context':
        """Create new context with updated data"""
        new_data = {**self.data, **updates}
        return Context(
            id=self.id,
            data=new_data,
            tenant_id=self.tenant_id,
            created_at=self.created_at
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "data": dict(self.data),
            "tenant_id": self.tenant_id,
            "created_at": self.created_at.isoformat()
        }


@dataclass(frozen=True)
class ContextEnvelope:
    """Complete context envelope with metadata"""
    id: str
    data: Mapping[str, Any]
    schema: Schema
    policy: Policy
    provenance: Provenance
    metadata: Metadata
    validation_status: ValidationStatus = ValidationStatus.VALID
    validation_errors: tuple[str, ...] = field(default_factory=tuple)
    lifecycle_state: LifecycleState = LifecycleState.ACTIVE
    ttl: Optional[int] = None
    
    def to_context(self) -> Context:
        """Extract core context"""
        return Context(
            id=self.id,
            data=self.data,
            tenant_id=self.metadata.tenant_id,
            created_at=self.metadata.created_at
        )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "data": dict(self.data),
            "schema": self.schema.to_dict(),
            "policy": self.policy.to_dict(),
            "provenance": self.provenance.to_list(),
            "metadata": self.metadata.to_dict(),
            "validation_status": self.validation_status.value,
            "validation_errors": list(self.validation_errors),
            "lifecycle_state": self.lifecycle_state.value,
            "ttl": self.ttl
        }
    
    def to_sage_format(self) -> dict[str, Any]:
        """Convert to SageMCP format"""
        return {
            "id": self.id,
            "content": dict(self.data),
            "tenant": self.metadata.tenant_id,
            "schema": self.schema.name,
            "meta": {
                "policy": self.policy.name,
                "provenance": self.provenance.to_list(),
                **self.metadata.to_dict()
            }
        }


@dataclass(frozen=True)
class ContextEvent:
    """Immutable context event for observer pattern"""
    event_type: str
    context_id: str
    tenant_id: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    payload: Mapping[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return {
            "event_type": self.event_type,
            "context_id": self.context_id,
            "tenant_id": self.tenant_id,
            "timestamp": self.timestamp.isoformat(),
            "payload": dict(self.payload)
        }
