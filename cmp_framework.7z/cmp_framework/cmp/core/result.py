"""
Result monad for functional error handling.

Provides Ok and Err types for explicit error handling without exceptions.
"""

from typing import Generic, TypeVar, Callable, Union, Awaitable
from dataclasses import dataclass

T = TypeVar('T')
E = TypeVar('E')
U = TypeVar('U')


@dataclass(frozen=True)
class Ok(Generic[T]):
    """Success result wrapper"""
    value: T
    
    def is_ok(self) -> bool:
        """Check if result is Ok"""
        return True
    
    def is_err(self) -> bool:
        """Check if result is Err"""
        return False
    
    def map(self, func: Callable[[T], U]) -> 'Result[U, E]':
        """Transform success value"""
        try:
            return Ok(func(self.value))
        except Exception as e:
            return Err(e)  # type: ignore
    
    async def map_async(self, func: Callable[[T], Awaitable[U]]) -> 'Result[U, E]':
        """Async transform"""
        try:
            return Ok(await func(self.value))
        except Exception as e:
            return Err(e)  # type: ignore
    
    def and_then(self, func: Callable[[T], 'Result[U, E]']) -> 'Result[U, E]':
        """Chain result-returning functions (flatMap)"""
        try:
            return func(self.value)
        except Exception as e:
            return Err(e)  # type: ignore
    
    async def and_then_async(
        self,
        func: Callable[[T], Awaitable['Result[U, E]']]
    ) -> 'Result[U, E]':
        """Async chain"""
        try:
            return await func(self.value)
        except Exception as e:
            return Err(e)  # type: ignore
    
    def unwrap(self) -> T:
        """Get value or raise"""
        return self.value
    
    def unwrap_or(self, default: T) -> T:
        """Get value or default"""
        return self.value
    
    def unwrap_or_else(self, func: Callable[[], T]) -> T:
        """Get value or compute default"""
        return self.value

    def unwrap_err(self) -> E:
        """Raise error as this is Ok"""
        raise ValueError(f"Called unwrap_err on Ok: {self.value}")


@dataclass(frozen=True)
class Err(Generic[E]):
    """Error result wrapper"""
    error: E
    
    def is_ok(self) -> bool:
        """Check if result is Ok"""
        return False
    
    def is_err(self) -> bool:
        """Check if result is Err"""
        return True
    
    def map(self, func: Callable[[T], U]) -> 'Result[U, E]':
        """No-op for errors"""
        return self  # type: ignore
    
    async def map_async(self, func: Callable[[T], Awaitable[U]]) -> 'Result[U, E]':
        """No-op for errors"""
        return self  # type: ignore
    
    def and_then(self, func: Callable[[T], 'Result[U, E]']) -> 'Result[U, E]':
        """No-op for errors"""
        return self  # type: ignore
    
    async def and_then_async(
        self,
        func: Callable[[T], Awaitable['Result[U, E]']]
    ) -> 'Result[U, E]':
        """No-op for errors"""
        return self  # type: ignore
    
    def unwrap(self) -> T:
        """Raise error"""
        if isinstance(self.error, Exception):
            raise self.error
        raise RuntimeError(f"Result error: {self.error}")
    
    def unwrap_or(self, default: T) -> T:
        """Get default value"""
        return default
    
    def unwrap_or_else(self, func: Callable[[], T]) -> T:
        """Compute default value"""
        return func()

    def unwrap_err(self) -> E:
        """Get error"""
        return self.error


# Type alias for Result
Result = Union[Ok[T], Err[E]]


# Helper functions
def ok(value: T) -> Ok[T]:
    """Create Ok result"""
    return Ok(value)


def err(error: E) -> Err[E]:
    """Create Err result"""
    return Err(error)


async def try_async(func: Callable[[], Awaitable[T]]) -> Result[T, Exception]:
    """Try to execute async function and return Result"""
    try:
        value = await func()
        return Ok(value)
    except Exception as e:
        return Err(e)


def try_sync(func: Callable[[], T]) -> Result[T, Exception]:
    """Try to execute function and return Result"""
    try:
        value = func()
        return Ok(value)
    except Exception as e:
        return Err(e)
