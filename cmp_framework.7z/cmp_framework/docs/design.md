# Context Management Plane (CMP) - Python Framework Design

## 1.0 Executive Summary

This document outlines the architectural design for a Python-based Context Management Plane (CMP) framework. The design leverages **SageMCP** as the foundational implementation, incorporates **Gang of Four (GoF) design patterns** for robust architecture, adopts **functional programming (FP) principles** for immutability and composability, and utilizes **async/await** with **future callbacks** for high-performance concurrent operations.

### Design Principles

1. **Composition over Inheritance**: Favor functional composition and dependency injection
2. **Immutability**: Use immutable data structures where possible
3. **Async-First**: All I/O operations are asynchronous
4. **Policy-Driven**: Externalize orchestration logic to OPA policies
5. **Type Safety**: Leverage Python type hints and runtime validation

---

## 2.0 Architecture Overview

### 2.1 High-Level Architecture

```mermaid
graph TB
    subgraph "Agent Layer"
        A1[Agent 1]
        A2[Agent 2]
        A3[Agent N]
    end
    
    subgraph "CMP Framework"
        SDK[CMP SDK]
        DI[Dependency Injector]
        
        subgraph "Core Services"
            CS[Context Service]
            OS[Orchestration Service]
            PS[Policy Service]
            SS[Streaming Service]
        end
        
        subgraph "Registries"
            SR[Schema Registry]
            PR[Policy Registry]
            KR[Knowledge Registry]
            AR[Agent Registry]
        end
        
        subgraph "Storage Layer"
            CST[Context Store]
            MST[Metadata Store]
        end
    end
    
    subgraph "External Systems"
        OPA[OPA Server]
        SAGE[SageMCP]
        TEMP[Temporal]
        MCP[MCP Servers]
    end
    
    A1 --> SDK
    A2 --> SDK
    A3 --> SDK
    
    SDK --> DI
    DI --> CS
    DI --> OS
    
    CS --> CST
    CS --> SR
    OS --> PS
    PS --> OPA
    OS --> TEMP
    
    CS --> SAGE
    SS --> SAGE
    
    CS --> MCP
```

### 2.2 Layered Architecture

| Layer | Responsibility | Key Components |
|-------|---------------|----------------|
| **Agent Interface** | SDK for agent interactions | Decorators, Annotations, Client API |
| **Service Layer** | Business logic and orchestration | Context, Policy, Orchestration, Streaming services |
| **Registry Layer** | Metadata management | Schema, Policy, Knowledge, Agent registries |
| **Storage Layer** | Data persistence | Context Store, Metadata Store |
| **Integration Layer** | External system integration | SageMCP, OPA, Temporal, MCP adapters |

---

## 3.0 Design Patterns & Architectural Patterns

### 3.1 Gang of Four (GoF) Patterns

#### 3.1.1 Strategy Pattern - Orchestration Strategies

**Purpose**: Encapsulate different orchestration algorithms (Chaining, Fan-out/Fan-in, Evolution)

**Implementation**:
```python
from abc import ABC, abstractmethod
from typing import Protocol, AsyncIterator
from dataclasses import dataclass

class OrchestrationStrategy(Protocol):
    """Strategy interface for orchestration patterns"""
    
    async def execute(
        self,
        context: Context,
        agents: list[Agent],
        policy: Policy
    ) -> AsyncIterator[Context]:
        """Execute orchestration strategy"""
        ...

@dataclass(frozen=True)
class ChainingStrategy:
    """Sequential context chaining"""
    
    async def execute(
        self,
        context: Context,
        agents: list[Agent],
        policy: Policy
    ) -> AsyncIterator[Context]:
        current_context = context
        for agent in agents:
            current_context = await agent.process(current_context)
            yield current_context

@dataclass(frozen=True)
class FanOutFanInStrategy:
    """Parallel processing with aggregation"""
    
    async def execute(
        self,
        context: Context,
        agents: list[Agent],
        policy: Policy
    ) -> AsyncIterator[Context]:
        # Fan-out: split context
        slices = await self._split_context(context, policy)
        
        # Parallel execution
        tasks = [agent.process(slice_ctx) for agent, slice_ctx in zip(agents, slices)]
        results = await asyncio.gather(*tasks)
        
        # Fan-in: aggregate results
        aggregated = await self._aggregate_contexts(results, policy)
        yield aggregated
```

**Benefits**:
- Easy to add new orchestration patterns
- Policy-driven strategy selection
- Testable in isolation

---

#### 3.1.2 Builder Pattern - Context Envelope Construction

**Purpose**: Construct complex Context Envelope objects step-by-step

**Implementation**:
```python
from typing import Optional, Self
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class ContextEnvelope:
    """Immutable context envelope"""
    data: dict
    schema: Schema
    policy: Policy
    provenance: Provenance
    metadata: Metadata
    
class ContextEnvelopeBuilder:
    """Fluent builder for context envelopes"""
    
    def __init__(self):
        self._data: Optional[dict] = None
        self._schema: Optional[Schema] = None
        self._policy: Optional[Policy] = None
        self._provenance: Provenance = Provenance.empty()
        self._metadata: Metadata = Metadata.default()
    
    def with_data(self, data: dict) -> Self:
        """Set context data"""
        return self._copy(data=data)
    
    def with_schema(self, schema: Schema) -> Self:
        """Set validation schema"""
        return self._copy(schema=schema)
    
    def with_policy(self, policy: Policy) -> Self:
        """Set governance policy"""
        return self._copy(policy=policy)
    
    def with_provenance(self, source: str, agent_id: str) -> Self:
        """Add provenance tracking"""
        prov = self._provenance.add_step(source, agent_id, datetime.utcnow())
        return self._copy(provenance=prov)
    
    def with_metadata(self, **kwargs) -> Self:
        """Add metadata fields"""
        meta = self._metadata.update(**kwargs)
        return self._copy(metadata=meta)
    
    async def build(self) -> ContextEnvelope:
        """Build and validate envelope"""
        if not self._data or not self._schema:
            raise ValueError("Data and schema are required")
        
        # Validate data against schema
        await self._schema.validate(self._data)
        
        return ContextEnvelope(
            data=self._data,
            schema=self._schema,
            policy=self._policy or Policy.default(),
            provenance=self._provenance,
            metadata=self._metadata
        )
    
    def _copy(self, **changes) -> Self:
        """Create a copy with changes (immutability)"""
        builder = ContextEnvelopeBuilder()
        builder._data = changes.get('data', self._data)
        builder._schema = changes.get('schema', self._schema)
        builder._policy = changes.get('policy', self._policy)
        builder._provenance = changes.get('provenance', self._provenance)
        builder._metadata = changes.get('metadata', self._metadata)
        return builder
```

**Benefits**:
- Immutable envelope construction
- Fluent, readable API
- Automatic validation

---

#### 3.1.3 Observer Pattern - Event-Driven Context Updates

**Purpose**: Notify subscribers when context changes occur

**Implementation**:
```python
from typing import Callable, Awaitable
from dataclasses import dataclass, field

@dataclass
class ContextEvent:
    """Immutable context event"""
    event_type: str
    context_id: str
    tenant_id: str
    timestamp: datetime
    payload: dict = field(default_factory=dict)

class ContextObservable:
    """Observable for context events"""
    
    def __init__(self):
        self._observers: list[Callable[[ContextEvent], Awaitable[None]]] = []
    
    def subscribe(self, observer: Callable[[ContextEvent], Awaitable[None]]) -> None:
        """Subscribe to context events"""
        self._observers.append(observer)
    
    def unsubscribe(self, observer: Callable[[ContextEvent], Awaitable[None]]) -> None:
        """Unsubscribe from context events"""
        self._observers.remove(observer)
    
    async def notify(self, event: ContextEvent) -> None:
        """Notify all observers asynchronously"""
        await asyncio.gather(*[obs(event) for obs in self._observers])

# Usage example
class ContextService:
    def __init__(self):
        self.observable = ContextObservable()
    
    async def create_context(self, envelope: ContextEnvelope) -> str:
        # Store context
        context_id = await self._store.save(envelope)
        
        # Notify observers
        event = ContextEvent(
            event_type="context.created",
            context_id=context_id,
            tenant_id=envelope.metadata.tenant_id,
            timestamp=datetime.utcnow()
        )
        await self.observable.notify(event)
        
        return context_id
```

**Benefits**:
- Decoupled event handling
- Async notification
- Extensible event system

---

#### 3.1.4 Decorator Pattern - Context Injection

**Purpose**: Inject context dependencies into agent methods

**Implementation**:
```python
from functools import wraps
from typing import Callable, TypeVar, ParamSpec

P = ParamSpec('P')
R = TypeVar('R')

def context(context_id: Optional[str] = None, schema: Optional[str] = None):
    """Decorator for context injection"""
    def decorator(func: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            # Get context service from DI container
            context_service = get_service(ContextService)
            
            # Resolve context
            if context_id:
                ctx = await context_service.get(context_id)
            elif schema:
                ctx = await context_service.search(schema=schema, limit=1)
            else:
                ctx = await context_service.get_current()
            
            # Inject into kwargs
            kwargs['context'] = ctx
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator

def knowledge(source: str):
    """Decorator for knowledge source injection"""
    def decorator(func: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            knowledge_service = get_service(KnowledgeService)
            knowledge = await knowledge_service.get_source(source)
            kwargs['knowledge'] = knowledge
            return await func(*args, **kwargs)
        return wrapper
    return decorator

# Usage
class MyAgent:
    @context(schema="user_profile")
    @knowledge(source="vector_db")
    async def process(self, input_data: dict, context: Context, knowledge: Knowledge) -> dict:
        # Context and knowledge automatically injected
        enriched_data = await knowledge.search(input_data['query'])
        return {**context.data, **enriched_data}
```

**Benefits**:
- Declarative dependency injection
- Clean agent code
- Testable (can mock injected dependencies)

---

#### 3.1.5 Factory Pattern - Registry Factories

**Purpose**: Create registry instances based on type

**Implementation**:
```python
from typing import Protocol
from enum import Enum

class Registry(Protocol):
    """Registry interface"""
    async def register(self, key: str, value: Any) -> None: ...
    async def get(self, key: str) -> Any: ...
    async def list(self, tenant_id: str) -> list[Any]: ...

class RegistryType(Enum):
    SCHEMA = "schema"
    POLICY = "policy"
    KNOWLEDGE = "knowledge"
    AGENT = "agent"

class RegistryFactory:
    """Factory for creating registries"""
    
    _registries: dict[RegistryType, type[Registry]] = {}
    
    @classmethod
    def register_type(cls, registry_type: RegistryType, registry_class: type[Registry]):
        """Register a registry implementation"""
        cls._registries[registry_type] = registry_class
    
    @classmethod
    async def create(cls, registry_type: RegistryType, **config) -> Registry:
        """Create a registry instance"""
        if registry_type not in cls._registries:
            raise ValueError(f"Unknown registry type: {registry_type}")
        
        registry_class = cls._registries[registry_type]
        return registry_class(**config)

# Register implementations
RegistryFactory.register_type(RegistryType.SCHEMA, SchemaRegistry)
RegistryFactory.register_type(RegistryType.POLICY, PolicyRegistry)
RegistryFactory.register_type(RegistryType.KNOWLEDGE, KnowledgeRegistry)
RegistryFactory.register_type(RegistryType.AGENT, AgentRegistry)
```

**Benefits**:
- Centralized registry creation
- Easy to add new registry types
- Configuration-driven instantiation

---

### 3.2 Functional Programming Patterns

#### 3.2.1 Immutable Data Structures

**Implementation**:
```python
from dataclasses import dataclass
from typing import Mapping

@dataclass(frozen=True)
class Context:
    """Immutable context"""
    id: str
    data: Mapping[str, Any]  # Use Mapping for immutability
    tenant_id: str
    created_at: datetime
    
    def with_data(self, **updates) -> 'Context':
        """Create new context with updated data"""
        new_data = {**self.data, **updates}
        return Context(
            id=self.id,
            data=new_data,
            tenant_id=self.tenant_id,
            created_at=self.created_at
        )

@dataclass(frozen=True)
class Provenance:
    """Immutable provenance chain"""
    steps: tuple[ProvenanceStep, ...]  # Tuple for immutability
    
    def add_step(self, source: str, agent_id: str, timestamp: datetime) -> 'Provenance':
        """Add a step to provenance chain"""
        new_step = ProvenanceStep(source, agent_id, timestamp)
        return Provenance(steps=(*self.steps, new_step))
    
    @staticmethod
    def empty() -> 'Provenance':
        return Provenance(steps=())
```

**Benefits**:
- Thread-safe by default
- Easier to reason about
- Prevents accidental mutations

---

#### 3.2.2 Function Composition & Pipelines

**Implementation**:
```python
from typing import Callable, TypeVar
from functools import reduce

T = TypeVar('T')
U = TypeVar('U')

def compose(*functions: Callable) -> Callable:
    """Compose functions right-to-left"""
    return reduce(lambda f, g: lambda x: f(g(x)), functions, lambda x: x)

def pipe(*functions: Callable) -> Callable:
    """Compose functions left-to-right (pipeline)"""
    return reduce(lambda f, g: lambda x: g(f(x)), functions, lambda x: x)

# Async versions
async def acompose(*functions: Callable[[T], Awaitable[U]]) -> Callable[[T], Awaitable[U]]:
    """Async function composition"""
    async def composed(x: T) -> U:
        result = x
        for func in reversed(functions):
            result = await func(result)
        return result
    return composed

async def apipe(*functions: Callable[[T], Awaitable[U]]) -> Callable[[T], Awaitable[U]]:
    """Async pipeline composition"""
    async def piped(x: T) -> U:
        result = x
        for func in functions:
            result = await func(result)
        return result
    return piped

# Usage: Context transformation pipeline
async def enrich_with_user_data(ctx: Context) -> Context:
    user_data = await fetch_user_data(ctx.data['user_id'])
    return ctx.with_data(user=user_data)

async def apply_business_rules(ctx: Context) -> Context:
    validated = await validate_rules(ctx.data)
    return ctx.with_data(validated=validated)

async def add_metadata(ctx: Context) -> Context:
    return ctx.with_data(processed_at=datetime.utcnow())

# Create processing pipeline
process_context = apipe(
    enrich_with_user_data,
    apply_business_rules,
    add_metadata
)

# Execute
result = await process_context(initial_context)
```

**Benefits**:
- Declarative data transformations
- Reusable transformation functions
- Easy to test individual steps

---

#### 3.2.3 Monads for Error Handling (Result Type)

**Implementation**:
```python
from typing import Generic, TypeVar, Callable, Union
from dataclasses import dataclass

T = TypeVar('T')
E = TypeVar('E')
U = TypeVar('U')

@dataclass(frozen=True)
class Ok(Generic[T]):
    """Success result"""
    value: T
    
    def is_ok(self) -> bool:
        return True
    
    def is_err(self) -> bool:
        return False
    
    def map(self, func: Callable[[T], U]) -> 'Result[U, E]':
        """Transform success value"""
        return Ok(func(self.value))
    
    async def map_async(self, func: Callable[[T], Awaitable[U]]) -> 'Result[U, E]':
        """Async transform"""
        return Ok(await func(self.value))
    
    def unwrap(self) -> T:
        """Get value or raise"""
        return self.value

@dataclass(frozen=True)
class Err(Generic[E]):
    """Error result"""
    error: E
    
    def is_ok(self) -> bool:
        return False
    
    def is_err(self) -> bool:
        return True
    
    def map(self, func: Callable[[T], U]) -> 'Result[U, E]':
        """No-op for errors"""
        return self
    
    async def map_async(self, func: Callable[[T], Awaitable[U]]) -> 'Result[U, E]':
        """No-op for errors"""
        return self
    
    def unwrap(self) -> T:
        """Raise error"""
        raise self.error

Result = Union[Ok[T], Err[E]]

# Usage in context service
async def get_context(context_id: str) -> Result[Context, ContextError]:
    """Get context with error handling"""
    try:
        context = await store.get(context_id)
        if context is None:
            return Err(ContextNotFoundError(context_id))
        return Ok(context)
    except Exception as e:
        return Err(ContextError(str(e)))

# Chain operations
result = await get_context("ctx_123")
enriched = await result.map_async(enrich_with_user_data)
final = enriched.map(lambda ctx: ctx.data)

if final.is_ok():
    print(final.unwrap())
else:
    print(f"Error: {final.error}")
```

**Benefits**:
- Explicit error handling
- No exceptions in happy path
- Composable error handling

---

## 4.0 Async/Await & Future Callbacks

### 4.1 Async-First Design

**All I/O operations are async**:
```python
from typing import AsyncIterator
import asyncio

class ContextService:
    """Fully async context service"""
    
    async def create(self, envelope: ContextEnvelope) -> str:
        """Async context creation"""
        async with self._lock:
            context_id = await self._store.save(envelope)
            await self._index.add(context_id, envelope.metadata)
            await self.observable.notify(ContextEvent(...))
            return context_id
    
    async def search(
        self,
        query: dict,
        tenant_id: str,
        limit: int = 10
    ) -> AsyncIterator[Context]:
        """Async streaming search"""
        async for context_id in self._index.search(query, tenant_id, limit):
            context = await self._store.get(context_id)
            yield context
    
    async def stream_updates(
        self,
        context_id: str
    ) -> AsyncIterator[ContextEvent]:
        """Stream context updates via SSE"""
        queue = asyncio.Queue()
        
        async def observer(event: ContextEvent):
            if event.context_id == context_id:
                await queue.put(event)
        
        self.observable.subscribe(observer)
        
        try:
            while True:
                event = await queue.get()
                yield event
        finally:
            self.observable.unsubscribe(observer)
```

---

### 4.2 Future Callbacks

**Implementation using asyncio.Future**:
```python
from asyncio import Future
from typing import Callable, Optional

class ContextFuture:
    """Wrapper for context operations with callbacks"""
    
    def __init__(self, coro: Awaitable[T]):
        self._future: Future[T] = asyncio.ensure_future(coro)
        self._callbacks: list[Callable[[T], None]] = []
        self._error_callbacks: list[Callable[[Exception], None]] = []
    
    def then(self, callback: Callable[[T], None]) -> 'ContextFuture[T]':
        """Add success callback"""
        self._callbacks.append(callback)
        
        def done_callback(fut: Future):
            if not fut.exception():
                callback(fut.result())
        
        self._future.add_done_callback(done_callback)
        return self
    
    def catch(self, error_callback: Callable[[Exception], None]) -> 'ContextFuture[T]':
        """Add error callback"""
        self._error_callbacks.append(error_callback)
        
        def done_callback(fut: Future):
            if fut.exception():
                error_callback(fut.exception())
        
        self._future.add_done_callback(done_callback)
        return self
    
    def finally_(self, callback: Callable[[], None]) -> 'ContextFuture[T]':
        """Add finally callback"""
        self._future.add_done_callback(lambda _: callback())
        return self
    
    async def await_(self) -> T:
        """Await the future"""
        return await self._future

# Usage
context_future = ContextFuture(context_service.create(envelope))

context_future \
    .then(lambda ctx_id: print(f"Created: {ctx_id}")) \
    .catch(lambda err: logger.error(f"Failed: {err}")) \
    .finally_(lambda: print("Operation complete"))

# Can still await if needed
context_id = await context_future.await_()
```

---

### 4.3 Async Context Managers

**Resource management with async context managers**:
```python
from contextlib import asynccontextmanager
from typing import AsyncIterator

class ContextTransaction:
    """Transactional context operations"""
    
    def __init__(self, store: ContextStore):
        self._store = store
        self._operations: list[Callable] = []
    
    async def __aenter__(self) -> 'ContextTransaction':
        await self._store.begin_transaction()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            await self._store.commit()
        else:
            await self._store.rollback()
    
    async def create(self, envelope: ContextEnvelope) -> str:
        """Create context within transaction"""
        return await self._store.save(envelope)

# Usage
async with ContextTransaction(store) as txn:
    ctx1_id = await txn.create(envelope1)
    ctx2_id = await txn.create(envelope2)
    # Auto-commit on success, rollback on exception

@asynccontextmanager
async def context_lock(context_id: str) -> AsyncIterator[Context]:
    """Lock context for exclusive access"""
    lock = await acquire_lock(context_id)
    try:
        context = await load_context(context_id)
        yield context
    finally:
        await release_lock(lock)

# Usage
async with context_lock("ctx_123") as ctx:
    # Exclusive access to context
    updated = ctx.with_data(status="processing")
    await save_context(updated)
```

---

## 5.0 SageMCP Integration

### 5.1 SageMCP Adapter Pattern

**Wrap SageMCP functionality with CMP interface**:
```python
from sagemcp import SageMCPClient
from typing import Protocol

class MCPAdapter(Protocol):
    """Adapter interface for MCP servers"""
    async def get_context(self, context_id: str) -> dict: ...
    async def list_contexts(self, filters: dict) -> list[dict]: ...
    async def stream_context(self, context_id: str) -> AsyncIterator[dict]: ...

class SageMCPAdapter:
    """Adapter for SageMCP"""
    
    def __init__(self, client: SageMCPClient):
        self._client = client
    
    async def get_context(self, context_id: str) -> dict:
        """Get context from SageMCP"""
        response = await self._client.contexts.get(context_id)
        return self._transform_response(response)
    
    async def list_contexts(self, filters: dict) -> list[dict]:
        """List contexts with filters"""
        response = await self._client.contexts.list(**filters)
        return [self._transform_response(ctx) for ctx in response]
    
    async def stream_context(self, context_id: str) -> AsyncIterator[dict]:
        """Stream context updates"""
        async for event in self._client.contexts.stream(context_id):
            yield self._transform_response(event)
    
    def _transform_response(self, sage_context: dict) -> dict:
        """Transform SageMCP format to CMP format"""
        return {
            "id": sage_context["id"],
            "data": sage_context["content"],
            "metadata": {
                "tenant_id": sage_context.get("tenant"),
                "created_at": sage_context.get("timestamp"),
                **sage_context.get("meta", {})
            }
        }

class ContextStore:
    """Context store using SageMCP"""
    
    def __init__(self, sage_adapter: SageMCPAdapter):
        self._sage = sage_adapter
    
    async def save(self, envelope: ContextEnvelope) -> str:
        """Save context via SageMCP"""
        sage_context = {
            "content": envelope.data,
            "tenant": envelope.metadata.tenant_id,
            "schema": envelope.schema.name,
            "meta": envelope.metadata.to_dict()
        }
        response = await self._sage._client.contexts.create(sage_context)
        return response["id"]
    
    async def get(self, context_id: str) -> Optional[Context]:
        """Get context via SageMCP"""
        sage_ctx = await self._sage.get_context(context_id)
        if not sage_ctx:
            return None
        return self._to_context(sage_ctx)
```

---

### 5.2 Enhanced Context Envelope

**Extend SageMCP with sophisticated envelope**:
```python
@dataclass(frozen=True)
class EnhancedEnvelope:
    """Extended envelope beyond SageMCP"""
    
    # Core SageMCP fields
    id: str
    data: Mapping[str, Any]
    tenant_id: str
    
    # CMP extensions
    schema: Schema
    policy: Policy
    provenance: Provenance
    metadata: Metadata
    
    # Validation state
    validation_status: ValidationStatus
    validation_errors: tuple[str, ...] = ()
    
    # Lifecycle
    lifecycle_state: LifecycleState = LifecycleState.ACTIVE
    ttl: Optional[int] = None  # Time-to-live in seconds
    
    def to_sage_format(self) -> dict:
        """Convert to SageMCP format"""
        return {
            "id": self.id,
            "content": dict(self.data),
            "tenant": self.tenant_id,
            "schema": self.schema.name,
            "meta": {
                "policy": self.policy.name,
                "provenance": [step.to_dict() for step in self.provenance.steps],
                **self.metadata.to_dict()
            }
        }
    
    @classmethod
    def from_sage_format(cls, sage_ctx: dict, schema_registry: SchemaRegistry) -> 'EnhancedEnvelope':
        """Create from SageMCP format"""
        schema = schema_registry.get(sage_ctx["schema"])
        meta = sage_ctx.get("meta", {})
        
        return cls(
            id=sage_ctx["id"],
            data=sage_ctx["content"],
            tenant_id=sage_ctx["tenant"],
            schema=schema,
            policy=Policy.from_dict(meta.get("policy", {})),
            provenance=Provenance.from_list(meta.get("provenance", [])),
            metadata=Metadata.from_dict(meta),
            validation_status=ValidationStatus.VALID
        )
```

---

## 6.0 Core Components Design

### 6.1 Context Service

```python
class ContextService:
    """Core context management service"""
    
    def __init__(
        self,
        store: ContextStore,
        schema_registry: SchemaRegistry,
        policy_service: PolicyService,
        observable: ContextObservable
    ):
        self._store = store
        self._schema_registry = schema_registry
        self._policy_service = policy_service
        self._observable = observable
    
    async def create(
        self,
        data: dict,
        schema_name: str,
        tenant_id: str,
        **metadata
    ) -> Result[str, ContextError]:
        """Create new context"""
        try:
            # Get schema
            schema = await self._schema_registry.get(schema_name, tenant_id)
            if not schema:
                return Err(SchemaNotFoundError(schema_name))
            
            # Build envelope
            envelope = await (
                ContextEnvelopeBuilder()
                .with_data(data)
                .with_schema(schema)
                .with_metadata(tenant_id=tenant_id, **metadata)
                .build()
            )
            
            # Check policy
            policy_result = await self._policy_service.evaluate(
                "context.create",
                envelope
            )
            if not policy_result.allowed:
                return Err(PolicyViolationError(policy_result.reason))
            
            # Save
            context_id = await self._store.save(envelope)
            
            # Notify
            await self._observable.notify(ContextEvent(
                event_type="context.created",
                context_id=context_id,
                tenant_id=tenant_id,
                timestamp=datetime.utcnow()
            ))
            
            return Ok(context_id)
            
        except Exception as e:
            return Err(ContextError(str(e)))
    
    async def search(
        self,
        query: dict,
        tenant_id: str,
        limit: int = 10
    ) -> AsyncIterator[Context]:
        """Search contexts"""
        # Policy check
        policy_result = await self._policy_service.evaluate(
            "context.search",
            {"tenant_id": tenant_id, "query": query}
        )
        if not policy_result.allowed:
            raise PolicyViolationError(policy_result.reason)
        
        # Stream results
        async for context in self._store.search(query, tenant_id, limit):
            yield context
```

---

### 6.2 Orchestration Service

```python
class OrchestrationService:
    """Policy-driven orchestration"""
    
    def __init__(
        self,
        policy_service: PolicyService,
        temporal_client: TemporalClient,
        strategies: dict[str, OrchestrationStrategy]
    ):
        self._policy_service = policy_service
        self._temporal = temporal_client
        self._strategies = strategies
    
    async def execute_workflow(
        self,
        workflow_name: str,
        context: Context,
        agents: list[Agent]
    ) -> AsyncIterator[Context]:
        """Execute orchestration workflow"""
        
        # Get workflow policy
        policy = await self._policy_service.get_workflow_policy(workflow_name)
        
        # Determine strategy from policy
        strategy_name = policy.get("strategy", "chaining")
        strategy = self._strategies.get(strategy_name)
        
        if not strategy:
            raise ValueError(f"Unknown strategy: {strategy_name}")
        
        # Execute via Temporal for state management
        workflow_id = await self._temporal.start_workflow(
            workflow_name,
            context.id,
            [agent.id for agent in agents]
        )
        
        try:
            # Stream results
            async for result_context in strategy.execute(context, agents, policy):
                # Update Temporal state
                await self._temporal.signal_workflow(
                    workflow_id,
                    "step_completed",
                    {"context_id": result_context.id}
                )
                yield result_context
                
        except Exception as e:
            await self._temporal.fail_workflow(workflow_id, str(e))
            raise
        
        await self._temporal.complete_workflow(workflow_id)
```

---

### 6.3 Policy Service (OPA Integration)

```python
import aiohttp
from typing import Any

class PolicyService:
    """OPA policy evaluation service"""
    
    def __init__(self, opa_url: str):
        self._opa_url = opa_url
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        self._session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._session:
            await self._session.close()
    
    async def evaluate(
        self,
        policy_path: str,
        input_data: Any
    ) -> PolicyResult:
        """Evaluate policy via OPA"""
        url = f"{self._opa_url}/v1/data/{policy_path.replace('.', '/')}"
        
        async with self._session.post(url, json={"input": input_data}) as resp:
            result = await resp.json()
            
            return PolicyResult(
                allowed=result.get("result", {}).get("allow", False),
                reason=result.get("result", {}).get("reason", ""),
                metadata=result.get("result", {}).get("metadata", {})
            )
    
    async def get_workflow_policy(self, workflow_name: str) -> dict:
        """Get workflow orchestration policy"""
        result = await self.evaluate(
            f"workflows.{workflow_name}",
            {}
        )
        return result.metadata.get("workflow_config", {})

@dataclass(frozen=True)
class PolicyResult:
    """Policy evaluation result"""
    allowed: bool
    reason: str
    metadata: dict = field(default_factory=dict)
```

---

## 7.0 SDK Design

### 7.1 Agent SDK

```python
from cmp import CMP, context, knowledge, Agent

# Initialize CMP
cmp = CMP(
    tenant_id="acme_corp",
    config={
        "sage_mcp_url": "https://sage.example.com",
        "opa_url": "http://opa:8181",
        "temporal_url": "temporal:7233"
    }
)

# Define agent
class ResumeAnalyzer(Agent):
    """Agent for analyzing resumes"""
    
    @context(schema="resume")
    @knowledge(source="skills_db")
    async def analyze(
        self,
        resume_text: str,
        context: Context,
        knowledge: Knowledge
    ) -> dict:
        """Analyze resume and extract skills"""
        
        # Use injected context
        user_profile = context.data.get("user_profile", {})
        
        # Query knowledge source
        skills = await knowledge.search(resume_text)
        
        # Return enriched data
        return {
            "user_id": user_profile["id"],
            "extracted_skills": skills,
            "analyzed_at": datetime.utcnow().isoformat()
        }

# Register agent
await cmp.register_agent(ResumeAnalyzer())

# Execute workflow
async with cmp.workflow("resume_analysis") as workflow:
    context = await workflow.create_context(
        data={"resume": resume_text},
        schema="resume"
    )
    
    results = await workflow.execute([ResumeAnalyzer()])
    
    async for result_context in results:
        print(f"Step completed: {result_context.id}")
```

---

### 7.2 Fluent API

```python
# Fluent context creation
context_id = await (
    cmp.context()
    .with_data({"user_id": "123", "action": "login"})
    .with_schema("user_event")
    .with_policy("standard_retention")
    .with_metadata(source="web_app", version="1.0")
    .create()
)

# Fluent workflow execution
results = await (
    cmp.workflow("data_enrichment")
    .with_context(context_id)
    .with_agents([EnrichmentAgent(), ValidationAgent()])
    .with_strategy("chaining")
    .execute()
)

# Fluent search
contexts = (
    cmp.search()
    .where(schema="user_event")
    .where(metadata__source="web_app")
    .where(created_at__gte=datetime.now() - timedelta(days=7))
    .limit(100)
    .stream()
)

async for ctx in contexts:
    print(ctx.data)
```

---

## 8.0 Testing Strategy

### 8.1 Unit Testing with Mocks

```python
import pytest
from unittest.mock import AsyncMock, Mock

@pytest.fixture
async def context_service():
    """Mock context service"""
    store = AsyncMock(spec=ContextStore)
    schema_registry = AsyncMock(spec=SchemaRegistry)
    policy_service = AsyncMock(spec=PolicyService)
    observable = Mock(spec=ContextObservable)
    
    return ContextService(store, schema_registry, policy_service, observable)

@pytest.mark.asyncio
async def test_create_context_success(context_service):
    """Test successful context creation"""
    # Arrange
    context_service._schema_registry.get.return_value = Schema(name="test")
    context_service._policy_service.evaluate.return_value = PolicyResult(
        allowed=True,
        reason=""
    )
    context_service._store.save.return_value = "ctx_123"
    
    # Act
    result = await context_service.create(
        data={"key": "value"},
        schema_name="test",
        tenant_id="tenant_1"
    )
    
    # Assert
    assert result.is_ok()
    assert result.unwrap() == "ctx_123"
    context_service._store.save.assert_called_once()
```

---

### 8.2 Integration Testing

```python
@pytest.mark.integration
async def test_end_to_end_workflow():
    """Test complete workflow execution"""
    # Setup real services
    cmp = CMP(config=test_config)
    
    # Create context
    context_id = await cmp.context() \
        .with_data({"input": "test"}) \
        .with_schema("test_schema") \
        .create()
    
    # Execute workflow
    results = []
    async for result in cmp.workflow("test_workflow") \
            .with_context(context_id) \
            .with_agents([TestAgent()]) \
            .execute():
        results.append(result)
    
    # Verify
    assert len(results) == 1
    assert results[0].data["processed"] is True
```

---

## 9.0 Deployment Architecture

### 9.1 Component Deployment

```yaml
# docker-compose.yml
version: '3.8'

services:
  cmp-api:
    build: ./cmp
    environment:
      - SAGE_MCP_URL=http://sage-mcp:8080
      - OPA_URL=http://opa:8181
      - TEMPORAL_URL=temporal:7233
    depends_on:
      - sage-mcp
      - opa
      - temporal
  
  sage-mcp:
    image: sagemcp/server:latest
    ports:
      - "8080:8080"
  
  opa:
    image: openpolicyagent/opa:latest
    command: run --server --addr :8181
    volumes:
      - ./policies:/policies
  
  temporal:
    image: temporalio/auto-setup:latest
    ports:
      - "7233:7233"
```

---

## 10.0 Performance Optimizations

### 10.1 Caching Strategy

```python
from functools import lru_cache
from cachetools import TTLCache
import asyncio

class CachedSchemaRegistry:
    """Schema registry with caching"""
    
    def __init__(self, backend: SchemaRegistry):
        self._backend = backend
        self._cache = TTLCache(maxsize=1000, ttl=300)  # 5 min TTL
        self._lock = asyncio.Lock()
    
    async def get(self, schema_name: str, tenant_id: str) -> Optional[Schema]:
        """Get schema with caching"""
        cache_key = f"{tenant_id}:{schema_name}"
        
        # Check cache
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        # Fetch from backend
        async with self._lock:
            # Double-check after acquiring lock
            if cache_key in self._cache:
                return self._cache[cache_key]
            
            schema = await self._backend.get(schema_name, tenant_id)
            if schema:
                self._cache[cache_key] = schema
            
            return schema
```

---

### 10.2 Connection Pooling

```python
import aiohttp
from typing import AsyncContextManager

class HTTPClientPool:
    """Pooled HTTP client for external services"""
    
    def __init__(self, max_connections: int = 100):
        self._connector = aiohttp.TCPConnector(
            limit=max_connections,
            limit_per_host=20
        )
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        self._session = aiohttp.ClientSession(connector=self._connector)
        return self._session
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._session:
            await self._session.close()
```

---

## 11.0 Monitoring & Observability

### 11.1 Metrics Collection

```python
from prometheus_client import Counter, Histogram, Gauge
import time

# Metrics
context_operations = Counter(
    'cmp_context_operations_total',
    'Total context operations',
    ['operation', 'tenant_id', 'status']
)

context_operation_duration = Histogram(
    'cmp_context_operation_duration_seconds',
    'Context operation duration',
    ['operation']
)

active_workflows = Gauge(
    'cmp_active_workflows',
    'Number of active workflows',
    ['workflow_name']
)

# Instrumentation decorator
def instrument(operation: str):
    """Decorator for instrumenting operations"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start = time.time()
            status = "success"
            
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                status = "error"
                raise
            finally:
                duration = time.time() - start
                context_operation_duration.labels(operation=operation).observe(duration)
                
                # Extract tenant_id if available
                tenant_id = kwargs.get('tenant_id', 'unknown')
                context_operations.labels(
                    operation=operation,
                    tenant_id=tenant_id,
                    status=status
                ).inc()
        
        return wrapper
    return decorator

# Usage
class ContextService:
    @instrument("create_context")
    async def create(self, data: dict, schema_name: str, tenant_id: str) -> str:
        ...
```

---

## 12.0 Security Considerations

### 12.1 Encryption

```python
from cryptography.fernet import Fernet
import base64

class EncryptedContextStore:
    """Context store with encryption at rest"""
    
    def __init__(self, backend: ContextStore, encryption_key: bytes):
        self._backend = backend
        self._cipher = Fernet(encryption_key)
    
    async def save(self, envelope: ContextEnvelope) -> str:
        """Save with encryption"""
        # Encrypt sensitive data
        encrypted_data = self._encrypt_dict(envelope.data)
        
        encrypted_envelope = ContextEnvelope(
            data=encrypted_data,
            schema=envelope.schema,
            policy=envelope.policy,
            provenance=envelope.provenance,
            metadata=envelope.metadata
        )
        
        return await self._backend.save(encrypted_envelope)
    
    async def get(self, context_id: str) -> Optional[Context]:
        """Get and decrypt"""
        envelope = await self._backend.get(context_id)
        if not envelope:
            return None
        
        # Decrypt data
        decrypted_data = self._decrypt_dict(envelope.data)
        
        return Context(
            id=envelope.id,
            data=decrypted_data,
            tenant_id=envelope.tenant_id,
            created_at=envelope.created_at
        )
    
    def _encrypt_dict(self, data: dict) -> dict:
        """Encrypt dictionary values"""
        return {
            k: self._cipher.encrypt(str(v).encode()).decode()
            for k, v in data.items()
        }
    
    def _decrypt_dict(self, data: dict) -> dict:
        """Decrypt dictionary values"""
        return {
            k: self._cipher.decrypt(v.encode()).decode()
            for k, v in data.items()
        }
```

---

## 13.0 Implementation Roadmap

### Phase 1: Foundation (Weeks 1-4)

**Week 1-2: Core Data Structures**
- [ ] Implement immutable Context, Envelope, Provenance
- [ ] Create Builder pattern for envelope construction
- [ ] Implement Result monad for error handling
- [ ] Set up project structure and dependencies

**Week 3-4: SageMCP Integration**
- [ ] Create SageMCP adapter
- [ ] Implement ContextStore with SageMCP backend
- [ ] Add enhanced envelope support
- [ ] Write integration tests

### Phase 2: Services (Weeks 5-8)

**Week 5-6: Context Service**
- [ ] Implement ContextService with CRUD operations
- [ ] Add search functionality
- [ ] Implement Observer pattern for events
- [ ] Add caching layer

**Week 7-8: Policy Service**
- [ ] Integrate OPA client
- [ ] Implement policy evaluation
- [ ] Add policy caching
- [ ] Create policy templates

### Phase 3: Orchestration (Weeks 9-12)

**Week 9-10: Orchestration Strategies**
- [ ] Implement Strategy pattern for orchestration
- [ ] Create ChainingStrategy
- [ ] Create FanOutFanInStrategy
- [ ] Create EvolutionStrategy

**Week 11-12: Temporal Integration**
- [ ] Integrate Temporal client
- [ ] Implement workflow state management
- [ ] Add workflow resumption
- [ ] Write orchestration tests

### Phase 4: SDK & Polish (Weeks 13-16)

**Week 13-14: SDK Development**
- [ ] Create decorator-based DI system
- [ ] Implement fluent API
- [ ] Add streaming support
- [ ] Write SDK documentation

**Week 15-16: Production Readiness**
- [ ] Add monitoring and metrics
- [ ] Implement encryption
- [ ] Performance optimization
- [ ] Security audit

---

## 14.0 Conclusion

This design provides a comprehensive blueprint for implementing the CMP framework in Python with:

✅ **SageMCP Integration**: Leverages existing infrastructure while extending capabilities  
✅ **GOF Patterns**: Strategy, Builder, Observer, Decorator, Factory for robust architecture  
✅ **Functional Programming**: Immutability, composition, monads for clean code  
✅ **Async/Await**: High-performance concurrent operations with future callbacks  
✅ **Policy-Driven**: OPA integration for externalized orchestration logic  
✅ **Production-Ready**: Monitoring, security, testing, and deployment strategies  

The framework is designed to be:
- **Extensible**: Easy to add new orchestration strategies and integrations
- **Testable**: Dependency injection and mocking support
- **Performant**: Async-first with caching and connection pooling
- **Secure**: Encryption, access control, and audit logging
- **Observable**: Comprehensive metrics and logging

---

**Document Version**: 1.0  
**Last Updated**: 2025-11-25  
**Status**: Design for Review
