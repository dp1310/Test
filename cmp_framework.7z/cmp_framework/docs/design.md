# CMP Framework - Design Document

## 1. Overview

The Context Management Plane (CMP) Framework is designed following **SOLID principles** to ensure maintainability, extensibility, and testability. This document outlines the architectural design, key patterns, and design decisions.

---

## 2. SOLID Principles Application

### 2.1 Single Responsibility Principle (SRP)

Each class in the CMP Framework has a single, well-defined responsibility:

| Class | Single Responsibility |
|-------|----------------------|
| `ContextService` | Manage context lifecycle (CRUD operations) |
| `PolicyService` | Evaluate policies and enforce governance |
| `OrchestrationService` | Execute workflow orchestration strategies |
| `SchemaRegistry` | Manage and validate schemas |
| `PolicyRegistry` | Store and retrieve policies |
| `ContextStore` | Persist and retrieve context data |
| `ContextObservable` | Notify subscribers of context events |

**Example**:

```python
class ContextService:
    """
    Single Responsibility: Context lifecycle management.
    
    Does NOT handle:
    - Policy evaluation (delegated to PolicyService)
    - Schema validation (delegated to SchemaRegistry)
    - Storage (delegated to ContextStore)
    - Event notification (delegated to ContextObservable)
    """
```

### 2.2 Open/Closed Principle (OCP)

The framework is **open for extension** but **closed for modification**:

#### Orchestration Strategies

New orchestration strategies can be added without modifying existing code:

```python
# Base abstraction
class OrchestrationStrategy(ABC):
    @abstractmethod
    async def execute(
        self,
        context: Context,
        agents: list[Agent],
        policy: dict[str, Any]
    ) -> AsyncIterator[Context]:
        pass

# Existing strategies (closed for modification)
class ChainingStrategy(OrchestrationStrategy): ...
class FanOutFanInStrategy(OrchestrationStrategy): ...

# New strategy (open for extension)
class CustomStrategy(OrchestrationStrategy):
    async def execute(self, context, agents, policy):
        # Custom implementation
        pass
```

#### Plugin System

```python
# Base plugin class
class Plugin(ABC):
    @abstractmethod
    async def on_init(self) -> None: ...
    
# Extend with custom plugins
class CustomPlugin(Plugin):
    async def on_init(self) -> None:
        # Custom initialization
        pass
```

### 2.3 Liskov Substitution Principle (LSP)

Subtypes can be substituted for their base types without breaking functionality:

```python
# Any OrchestrationStrategy can be used interchangeably
def register_strategy(name: str, strategy: OrchestrationStrategy):
    strategies[name] = strategy

# All these work identically
register_strategy("chaining", ChainingStrategy())
register_strategy("fan_out", FanOutFanInStrategy())
register_strategy("custom", CustomStrategy())
```

### 2.4 Interface Segregation Principle (ISP)

Interfaces are segregated so clients only depend on methods they use:

```python
# Separate interfaces for different concerns
class ContextStore(ABC):
    """Interface for context persistence only"""
    @abstractmethod
    async def save(self, envelope: ContextEnvelope) -> str: ...
    @abstractmethod
    async def get(self, context_id: str) -> Optional[ContextEnvelope]: ...

class SearchableStore(ABC):
    """Separate interface for search capabilities"""
    @abstractmethod
    async def search(
        self, 
        query: dict, 
        tenant_id: str, 
        limit: int
    ) -> AsyncIterator[ContextEnvelope]: ...

# Clients depend only on what they need
class ContextService:
    def __init__(self, store: ContextStore):  # Only needs basic store
        self._store = store
```

### 2.5 Dependency Inversion Principle (DIP)

High-level modules depend on abstractions, not concrete implementations:

```python
# High-level module (ContextService) depends on abstraction (ContextStore)
class ContextService:
    def __init__(
        self,
        store: ContextStore,  # Abstraction
        schema_registry: Any,  # Abstraction
        policy_service: Any,  # Abstraction
        observable: Optional[ContextObservable] = None
    ):
        self._store = store
        self._schema_registry = schema_registry
        self._policy_service = policy_service

# Concrete implementations injected at runtime
service = ContextService(
    store=InMemoryContextStore(),  # Concrete
    schema_registry=SchemaRegistry(),  # Concrete
    policy_service=MockPolicyService(),  # Concrete
)
```

---

## 3. Architectural Patterns

### 3.1 Repository Pattern

Context storage abstracted through repository interface:

```python
class ContextStore(ABC):
    """Repository interface for context persistence"""
    
    @abstractmethod
    async def save(self, envelope: ContextEnvelope) -> str:
        """Save context and return ID"""
        
    @abstractmethod
    async def get(self, context_id: str) -> Optional[ContextEnvelope]:
        """Retrieve context by ID"""
        
    @abstractmethod
    async def update(self, context_id: str, envelope: ContextEnvelope) -> bool:
        """Update existing context"""
```

### 3.2 Strategy Pattern

Orchestration strategies are interchangeable:

```python
class OrchestrationService:
    def __init__(self, strategies: dict[str, OrchestrationStrategy]):
        self._strategies = strategies
    
    async def execute_workflow(self, workflow_name: str, ...):
        # Select strategy at runtime
        strategy = self._strategies[policy["strategy"]]
        async for result in strategy.execute(context, agents, policy):
            yield result
```

### 3.3 Observer Pattern

Event-driven architecture for context changes:

```python
class ContextObservable:
    """Observable for context events"""
    
    def subscribe(self, observer: Callable[[ContextEvent], Awaitable[None]]):
        """Subscribe to context events"""
        
    async def notify(self, event: ContextEvent):
        """Notify all subscribers of event"""
```

### 3.4 Builder Pattern

Fluent API for context and workflow construction:

```python
# Context builder
context_id = await cmp.context()\
    .with_data(data)\
    .with_schema("transaction")\
    .with_policy("high_value")\
    .create()

# Workflow builder
async for result in cmp.workflow("processing")\
    .with_context(context_id)\
    .with_agents(agents)\
    .execute():
    process(result)
```

### 3.5 Result Monad Pattern

Explicit error handling without exceptions:

```python
result = await context_service.get(context_id)

if result.is_ok():
    context = result.unwrap()
    # Success path
else:
    error = result.unwrap_err()
    # Error handling
```

---

## 4. Layered Architecture

### 4.1 Layer Overview

```
┌─────────────────────────────────────────┐
│         Presentation Layer              │
│  CLI, API, GraphQL, WebSocket           │
└─────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│         Application Layer               │
│  SDK, Builders, Facades                 │
└─────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│         Domain Layer                    │
│  Services, Orchestration, Policies      │
└─────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│         Infrastructure Layer            │
│  Storage, Registries, Monitoring        │
└─────────────────────────────────────────┘
```

### 4.2 Layer Responsibilities

#### Presentation Layer

- **Purpose**: User-facing interfaces
- **Components**: CLI, REST API, GraphQL, WebSocket
- **Dependencies**: Application Layer only

#### Application Layer

- **Purpose**: Application-specific logic and coordination
- **Components**: CMP SDK, Builders, Workflow orchestration
- **Dependencies**: Domain Layer

#### Domain Layer

- **Purpose**: Core business logic
- **Components**: Services (Context, Policy, Orchestration)
- **Dependencies**: Infrastructure Layer (via abstractions)

#### Infrastructure Layer

- **Purpose**: Technical capabilities
- **Components**: Storage, Registries, Monitoring, Caching
- **Dependencies**: None (lowest level)

---

## 5. Key Design Decisions

### 5.1 Immutability

**Decision**: All contexts are immutable.

**Rationale**:

- Prevents accidental modifications
- Enables safe concurrent access
- Facilitates audit trails and versioning
- Simplifies reasoning about state

**Implementation**:

```python
@dataclass(frozen=True)
class Context:
    """Immutable context data"""
    id: str
    data: Mapping[str, Any]  # Immutable mapping
    tenant_id: str
    created_at: datetime
    
    def with_data(self, **updates: Any) -> 'Context':
        """Create new context with updated data"""
        new_data = {**self.data, **updates}
        return Context(
            id=self.id,
            data=new_data,
            tenant_id=self.tenant_id,
            created_at=self.created_at
        )
```

### 5.2 Policy-Driven Orchestration

**Decision**: Externalize all orchestration logic into policies.

**Rationale**:

- Separates business rules from code
- Enables runtime policy updates
- Supports multi-tenancy with tenant-specific policies
- Facilitates governance and compliance

**Implementation**:

```python
# Orchestration service has NO hardcoded logic
class OrchestrationService:
    async def execute_workflow(self, workflow_name, context, agents):
        # Get policy from external source
        policy = await self._policy_service.get_workflow_policy(workflow_name)
        
        # Select strategy based on policy
        strategy_name = policy.get("strategy", "chaining")
        strategy = self._strategies[strategy_name]
        
        # Execute based on policy
        async for result in strategy.execute(context, agents, policy):
            yield result
```

### 5.3 Dependency Injection

**Decision**: Use constructor injection for all dependencies.

**Rationale**:

- Explicit dependencies
- Easier testing (mock injection)
- Supports multiple implementations
- Follows DIP

**Implementation**:

```python
class ContextService:
    def __init__(
        self,
        store: ContextStore,  # Injected
        schema_registry: Any,  # Injected
        policy_service: Any,  # Injected
        observable: Optional[ContextObservable] = None  # Optional injection
    ):
        self._store = store
        self._schema_registry = schema_registry
        self._policy_service = policy_service
        self._observable = observable or ContextObservable()
```

### 5.4 Async-First Design

**Decision**: All I/O operations are asynchronous.

**Rationale**:

- Non-blocking operations
- Better resource utilization
- Supports high concurrency
- Natural fit for event-driven architecture

**Implementation**:

```python
class ContextService:
    async def create(self, data: dict, schema_name: str, tenant_id: str):
        """Async context creation"""
        # All operations are async
        schema = await self._get_schema(schema_name, tenant_id)
        envelope = await self._build_envelope(data, schema)
        context_id = await self._store.save(envelope)
        await self._observable.notify(event)
        return Ok(context_id)
```

---

## 6. Multi-Tenancy Design

### 6.1 Tenant Isolation

**Levels of Isolation**:

1. **Data Isolation**: Separate context stores per tenant
2. **Policy Isolation**: Tenant-specific policies
3. **Resource Isolation**: Quota management per tenant
4. **Operational Isolation**: Separate monitoring per tenant

### 6.2 Implementation

```python
class CMP:
    def __init__(self, tenant_id: str):
        """Initialize CMP for specific tenant"""
        self.tenant_id = tenant_id
        
        # All operations scoped to tenant
        self._context_service = ContextService(
            store=self._get_tenant_store(tenant_id),
            schema_registry=self._get_tenant_registry(tenant_id),
            policy_service=self._get_tenant_policies(tenant_id)
        )
```

---

## 7. Error Handling Strategy

### 7.1 Result Monad

Use Result monad for expected errors:

```python
# Service returns Result
async def get(self, context_id: str) -> Result[Context, ContextError]:
    try:
        envelope = await self._store.get(context_id)
        if envelope is None:
            return Err(ContextNotFoundError(context_id))
        return Ok(envelope.to_context())
    except Exception as e:
        return Err(ContextError(str(e)))
```

### 7.2 Exception Hierarchy

```python
class CMPError(Exception):
    """Base exception for all CMP errors"""

class ContextError(CMPError):
    """Context-related errors"""

class ContextNotFoundError(ContextError):
    """Specific context not found"""

class SchemaValidationError(CMPError):
    """Schema validation failures"""

class PolicyViolationError(CMPError):
    """Policy enforcement failures"""
```

---

## 8. Testing Strategy

### 8.1 Unit Tests

- Test each class in isolation
- Mock all dependencies
- Focus on single responsibility

### 8.2 Integration Tests

- Test service interactions
- Use real implementations where possible
- Verify end-to-end flows

### 8.3 Contract Tests

- Verify interface contracts
- Ensure LSP compliance
- Test all implementations of abstractions

---

## 9. Performance Considerations

### 9.1 Caching Strategy

```python
class ContextService:
    def __init__(self, cache_enabled: bool = True):
        if cache_enabled:
            self._cache = TTLCache(maxsize=1000, ttl=300)
        
    async def get(self, context_id: str):
        # Check cache first
        if self._cache:
            cached = self._cache.get(f"context:{context_id}")
            if cached:
                return Ok(cached)
        
        # Fetch from store
        envelope = await self._store.get(context_id)
        
        # Update cache
        if self._cache and envelope:
            self._cache[f"context:{context_id}"] = envelope.to_context()
```

### 9.2 Async Worker Pools

```python
class AsyncWorkerPool:
    """Pool of async workers for parallel processing"""
    
    async def submit(self, task_id: str, func: Callable, *args):
        """Submit task to worker pool"""
        
    async def wait_all(self) -> dict[str, Any]:
        """Wait for all tasks to complete"""
```

---

## 10. Extensibility Points

### 10.1 Plugin System

```python
class Plugin(ABC):
    """Base class for all plugins"""
    
    @abstractmethod
    async def on_init(self) -> None:
        """Initialize plugin"""
    
    @hook("context.before_create")
    async def validate(self, context):
        """Hook into context creation"""
```

### 10.2 Custom Strategies

```python
# Implement custom orchestration strategy
class MyCustomStrategy(OrchestrationStrategy):
    async def execute(self, context, agents, policy):
        # Custom orchestration logic
        pass

# Register with service
orchestration_service.register_strategy("custom", MyCustomStrategy())
```

---

## 11. Documentation Standards

### 11.1 Module Documentation

```python
"""
Module: context_service.py

Purpose: Core context lifecycle management.

This module provides the ContextService class which handles all CRUD
operations for contexts, including creation, retrieval, updates, and
deletion. It enforces schema validation and policy compliance.

Key Classes:
    - ContextService: Main service for context operations
    - PolicyResult: Result of policy evaluation

Dependencies:
    - ContextStore: For persistence
    - SchemaRegistry: For validation
    - PolicyService: For governance
"""
```

### 11.2 Class Documentation

```python
class ContextService:
    """
    Core service for context lifecycle management.
    
    This service handles all CRUD operations for contexts while enforcing
    schema validation, policy compliance, and multi-tenant isolation.
    
    Responsibilities:
        - Create new contexts with validation
        - Retrieve contexts by ID
        - Update existing contexts
        - Delete contexts
        - Search contexts by criteria
        - Emit events for context changes
    
    Design Patterns:
        - Repository pattern for storage abstraction
        - Observer pattern for event notification
        - Result monad for error handling
    
    Thread Safety:
        This class is thread-safe when used with async/await.
    
    Example:
        >>> service = ContextService(store, schema_registry, policy_service)
        >>> result = await service.create(
        ...     data={"key": "value"},
        ...     schema_name="test",
        ...     tenant_id="tenant1"
        ... )
        >>> if result.is_ok():
        ...     context_id = result.unwrap()
    """
```

### 11.3 Method Documentation

```python
async def create(
    self,
    data: dict[str, Any],
    schema_name: str,
    tenant_id: str,
    **metadata_kwargs: Any,
) -> Result[str, ContextError]:
    """
    Create a new context with validation and policy enforcement.
    
    This method creates a new context by:
    1. Retrieving and validating against the schema
    2. Building a context envelope with metadata
    3. Checking policy compliance
    4. Persisting to the context store
    5. Emitting a creation event
    
    Args:
        data: The context data to store
        schema_name: Name of the schema to validate against
        tenant_id: Tenant ID for multi-tenancy isolation
        **metadata_kwargs: Additional metadata to include in envelope
    
    Returns:
        Result[str, ContextError]: 
            - Ok(context_id) if successful
            - Err(ContextError) if creation fails
    
    Raises:
        No exceptions are raised; all errors returned via Result monad.
    
    Example:
        >>> result = await service.create(
        ...     data={"amount": 100},
        ...     schema_name="transaction",
        ...     tenant_id="acme_corp"
        ... )
        >>> if result.is_ok():
        ...     print(f"Created: {result.unwrap()}")
    
    See Also:
        - get(): Retrieve created context
        - update(): Modify existing context
    """
```

---

## 12. Code Organization

### 12.1 Directory Structure

```
cmp_framework/
├── cmp/
│   ├── core/              # Core models and utilities
│   │   ├── models.py      # Domain models
│   │   ├── result.py      # Result monad
│   │   ├── exceptions.py  # Exception hierarchy
│   │   └── builders.py    # Builder patterns
│   ├── services/          # Domain services
│   │   ├── context_service.py
│   │   ├── policy_service.py
│   │   └── orchestration_service.py
│   ├── storage/           # Infrastructure - persistence
│   │   └── context_store.py
│   ├── registries/        # Infrastructure - registries
│   │   ├── schema_registry.py
│   │   ├── policy_registry.py
│   │   └── knowledge_registry.py
│   ├── orchestration/     # Orchestration patterns
│   │   ├── strategies.py
│   │   └── patterns/
│   ├── sdk/               # Application layer
│   │   ├── client.py
│   │   └── agent.py
│   ├── api/               # Presentation layer
│   │   ├── server.py
│   │   ├── graphql/
│   │   └── websocket/
│   └── cli/               # Presentation layer
│       └── commands.py
```

---

## 13. Future Enhancements

### 13.1 Planned Features

1. **Advanced Caching**: Redis-based distributed cache
2. **Event Sourcing**: Complete event log for context changes
3. **CQRS**: Separate read/write models
4. **GraphQL Subscriptions**: Real-time updates
5. **gRPC Support**: High-performance RPC
6. **Kafka Integration**: Event streaming

### 13.2 Extensibility Roadmap

- Custom storage backends
- Additional orchestration strategies
- More plugin hooks
- Advanced monitoring integrations

---

**Document Version**: 1.0  
**Last Updated**: 2025-11-26  
**Status**: Living Document
