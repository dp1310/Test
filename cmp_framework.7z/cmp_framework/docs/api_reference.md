# CMP Framework - API Reference

## Table of Contents

1. [Core Models](#core-models)
2. [Services](#services)
3. [Orchestration](#orchestration)
4. [SDK](#sdk)
5. [Dependency Injection](#dependency-injection)
6. [Utilities](#utilities)

---

## Core Models

### Context

Immutable context data structure.

```python
from cmp.core.models import Context

context = Context(
    id="ctx_123",
    data={"key": "value"},
    tenant_id="acme_corp",
    created_at=datetime.utcnow()
)

# Update data (returns new instance)
updated = context.with_data(new_key="new_value")
```

**Methods**:

- `with_data(**updates)` - Create new context with updated data
- `to_dict()` - Convert to dictionary

---

### ContextEnvelope

Complete context wrapper with metadata, schema, policy, and provenance.

```python
from cmp.core.models import ContextEnvelope

envelope = ContextEnvelope(
    id="ctx_123",
    data={"key": "value"},
    schema=schema,
    policy=policy,
    provenance=provenance,
    metadata=metadata
)

# Convert to SageMCP format
sage_format = envelope.to_sage_format()

# Extract core context
context = envelope.to_context()
```

---

### Provenance

Immutable chain tracking context transformations.

```python
from cmp.core.models import Provenance

prov = (
    Provenance.empty()
    .add_step("agent_1", "a1", datetime.utcnow())
    .add_step("agent_2", "a2", datetime.utcnow())
)
```

---

### Result Monad

Functional error handling with Ok/Err types.

```python
from cmp.core.result import Result, Ok, Err

# Create results
success = Ok("value")
failure = Err(Exception("error"))

# Check result
if result.is_ok():
    value = result.unwrap()
else:
    error = result.error

# Transform results
mapped = result.map(lambda x: x.upper())
chained = await result.map_async(async_function)
```

---

## Services

### ContextService

Core context management service.

```python
from cmp.services import ContextService

service = ContextService(store, schema_registry, policy_service, observable)

# Create context
result = await service.create(
    data={"key": "value"},
    schema_name="my_schema",
    tenant_id="acme_corp"
)

# Get context
result = await service.get("ctx_123")

# Update context
result = await service.update("ctx_123", {"new_key": "new_value"})

# Search contexts
async for ctx in service.search(
    query={"type": "user"},
    tenant_id="acme_corp",
    limit=10
):
    print(ctx.data)

# Stream updates
async for event in service.stream_updates("ctx_123"):
    print(event.event_type)
```

**Methods**:

- `create(data, schema_name, tenant_id, **metadata)` → `Result[str, ContextError]`
- `get(context_id)` → `Result[Context, ContextError]`
- `get_envelope(context_id)` → `Result[ContextEnvelope, ContextError]`
- `update(context_id, data_updates)` → `Result[Context, ContextError]`
- `delete(context_id)` → `Result[bool, ContextError]`
- `search(query, tenant_id, limit)` → `AsyncIterator[Context]`
- `stream_updates(context_id)` → `AsyncIterator[ContextEvent]`

---

### PolicyService

OPA policy evaluation service.

```python
from cmp.services.policy_service import PolicyService

service = PolicyService(opa_url="http://opa:8181")

# Evaluate policy
result = await service.evaluate("context.create", input_data)
if result.allowed:
    # Proceed
    pass

# Get workflow policy
config = await service.get_workflow_policy("my_workflow")
strategy = config.get("strategy", "chaining")
```

**Methods**:

- `evaluate(policy_path, input_data)` → `PolicyResult`
- `get_workflow_policy(workflow_name)` → `dict`

---

### OrchestrationService

Policy-driven workflow execution.

```python
from cmp.services.orchestration_service import OrchestrationService

service = OrchestrationService(policy_service)

# Execute workflow
async for result in service.execute_workflow(
    workflow_name="data_processing",
    context=initial_context,
    agents=[agent1, agent2, agent3]
):
    print(result.data)

# Register custom strategy
service.register_strategy("custom", CustomStrategy())
```

**Methods**:

- `execute_workflow(workflow_name, context, agents)` → `AsyncIterator[Context]`
- `register_strategy(name, strategy)` → `None`

---

## Orchestration

### Strategies

#### ChainingStrategy

Sequential execution.

```python
from cmp.orchestration import ChainingStrategy

strategy = ChainingStrategy()

async for result in strategy.execute(context, agents, policy):
    # Each agent processes sequentially
    print(result.data)
```

#### FanOutFanInStrategy

Parallel processing with aggregation.

```python
from cmp.orchestration import FanOutFanInStrategy

strategy = FanOutFanInStrategy()

async for result in strategy.execute(context, agents, policy):
    # All agents process in parallel, then aggregate
    print(result.data)
```

#### EvolutionStrategy

Progressive enrichment.

```python
from cmp.orchestration import EvolutionStrategy

strategy = EvolutionStrategy()

async for result in strategy.execute(context, agents, policy):
    # Each agent adds to context cumulatively
    print(result.data)
```

---

### Agent

Base agent class.

```python
from cmp.sdk import Agent

class MyAgent(Agent):
    async def process(self, context: Context) -> Context:
        # Process context
        return context.with_data(processed=True)

agent = MyAgent("my_agent_id")
```

---

## SDK

### CMP Client

Main framework client.

```python
from cmp import CMP

# Initialize
cmp = CMP(
    tenant_id="acme_corp",
    config={
        "sage_mcp_url": "http://sage:8080",
        "opa_url": "http://opa:8181"
    }
)

# Create context (fluent API)
ctx_id = await cmp.context() \
    .with_data({"key": "value"}) \
    .with_schema("my_schema") \
    .with_metadata(source="api") \
    .create()

# Execute workflow (fluent API)
async for result in cmp.workflow("my_workflow") \
        .with_context(ctx_id) \
        .with_agents([agent1, agent2]) \
        .execute():
    print(result.data)

# Register agent
await cmp.register_agent(MyAgent())
```

---

## Dependency Injection

### Decorators

#### @context

Inject context into agent methods.

```python
from cmp.di import context

class MyAgent(Agent):
    @context(schema="user_profile")
    async def process(self, input_data: dict, context: Context):
        # context is automatically injected
        user_id = context.data['user_id']
        return context.with_data(processed=True)
```

**Parameters**:

- `context_id` - Specific context ID to inject
- `schema` - Schema name to search for

---

#### @knowledge

Inject knowledge sources.

```python
from cmp.di import knowledge

class MyAgent(Agent):
    @knowledge(source="vector_db")
    async def process(self, query: str, knowledge: Knowledge):
        # knowledge source is automatically injected
        results = await knowledge.search(query)
        return results
```

---

#### @envelope

Inject full context envelope.

```python
from cmp.di import envelope

class MyAgent(Agent):
    @envelope()
    async def process(self, input_data: dict, context: ContextEnvelope):
        # Full envelope with metadata, provenance, etc.
        provenance = context.provenance
        return context.to_context()
```

---

## Utilities

### Functional Programming

```python
from cmp.utils import compose, pipe, acompose, apipe

# Sync composition
f = compose(str.upper, str.strip)
result = f("  hello  ")  # "HELLO"

# Sync pipeline
f = pipe(str.strip, str.upper)
result = f("  hello  ")  # "HELLO"

# Async composition
process = await acompose(step3, step2, step1)
result = await process(data)

# Async pipeline
process = await apipe(step1, step2, step3)
result = await process(data)
```

---

### Async Helpers

```python
from cmp.utils import ContextFuture, retry, gather_dict

# Future with callbacks
ContextFuture(async_operation()) \
    .then(lambda x: print(f"Success: {x}")) \
    .catch(lambda e: print(f"Error: {e}")) \
    .finally_(lambda: print("Done"))

# Retry with backoff
result = await retry(
    lambda: fetch_data(),
    max_attempts=3,
    delay=1.0,
    backoff=2.0
)

# Gather dict
results = await gather_dict({
    "user": fetch_user(),
    "posts": fetch_posts()
})
```

---

## Error Handling

### Exceptions

```python
from cmp.core.exceptions import (
    ContextError,
    ContextNotFoundError,
    PolicyViolationError,
    ValidationError
)

try:
    result = await service.get("ctx_123")
    if result.is_err():
        raise result.error
except ContextNotFoundError as e:
    print(f"Context not found: {e.context_id}")
except PolicyViolationError as e:
    print(f"Policy violation: {e.reason}")
```

---

## Best Practices

### 1. Use Result Monad

```python
# Good: Explicit error handling
result = await service.create(data, schema, tenant)
if result.is_ok():
    context_id = result.unwrap()
else:
    logger.error(f"Failed: {result.error}")

# Avoid: Exceptions in happy path
```

### 2. Immutable Data

```python
# Good: Create new instances
updated = context.with_data(new_key="value")

# Avoid: Mutating data
context.data["new_key"] = "value"  # Won't work (frozen)
```

### 3. Async/Await

```python
# Good: All I/O is async
result = await service.create(...)

# Avoid: Blocking operations
```

### 4. Policy-Driven

```python
# Good: Externalize logic to policies
config = await policy_service.get_workflow_policy("my_workflow")
strategy = config.get("strategy")

# Avoid: Hardcoded orchestration logic
```

---

## Configuration

### Environment Variables

```bash
SAGE_MCP_URL=http://sage:8080
OPA_URL=http://opa:8181
TEMPORAL_URL=temporal:7233
```

### CMP Config

```python
cmp = CMP(
    tenant_id="acme_corp",
    config={
        "sage_mcp_url": "http://sage:8080",
        "opa_url": "http://opa:8181",
        "temporal_url": "temporal:7233"
    }
)
```

---

## Testing

### Unit Tests

```python
import pytest
from cmp.services import ContextService

@pytest.fixture
def context_service():
    return ContextService(store, None, policy_service, observable)

@pytest.mark.asyncio
async def test_create_context(context_service):
    result = await context_service.create(
        data={"key": "value"},
        schema_name="test",
        tenant_id="tenant_1"
    )
    assert result.is_ok()
```

### Running Tests

```bash
# All tests
poetry run pytest

# Unit tests only
poetry run pytest tests/unit/

# With coverage
poetry run pytest --cov=cmp --cov-report=html
```

---

## Deployment

### Docker

```bash
# Build image
docker build -t cmp-framework .

# Run container
docker run -p 8000:8000 cmp-framework

# Docker Compose
docker-compose up -d
```

---

**Version**: 0.1.0  
**Last Updated**: 2025-11-25
