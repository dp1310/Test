"""
Context operation benchmarks.

Benchmarks for context CRUD operations and schema validation.
"""

import asyncio
from benchmarks.framework import BenchmarkSuite
from cmp import CMP
from cmp.config import CMPConfig, set_config


async def benchmark_context_create():
    """Benchmark context creation."""
    cmp = CMP(tenant_id="benchmark")
    
    await cmp.context()\
        .with_data({"test": "data", "value": 123})\
        .create()


async def benchmark_context_create_with_schema():
    """Benchmark context creation with schema validation."""
    cmp = CMP(tenant_id="benchmark")
    
    await cmp.context()\
        .with_data({"user_id": "123", "action": "test"})\
        .with_schema("test_schema")\
        .create()


async def benchmark_context_read():
    """Benchmark context retrieval."""
    cmp = CMP(tenant_id="benchmark")
    
    # Create context first
    ctx_id = await cmp.context()\
        .with_data({"test": "data"})\
        .create()
    
    # Benchmark read
    await cmp.services.get_service('context_service').get(ctx_id)


async def benchmark_context_update():
    """Benchmark context update."""
    cmp = CMP(tenant_id="benchmark")
    
    # Create context first
    ctx_id = await cmp.context()\
        .with_data({"test": "data"})\
        .create()
    
    # Benchmark update
    await cmp.services.get_service('context_service').update(
        ctx_id,
        {"test": "updated_data", "new_field": "value"}
    )


async def benchmark_context_delete():
    """Benchmark context deletion."""
    cmp = CMP(tenant_id="benchmark")
    
    # Create context first
    ctx_id = await cmp.context()\
        .with_data({"test": "data"})\
        .create()
    
    # Benchmark delete
    await cmp.services.get_service('context_service').delete(ctx_id)


async def benchmark_context_list():
    """Benchmark context listing."""
    cmp = CMP(tenant_id="benchmark")
    
    # Create some contexts first
    for i in range(10):
        await cmp.context()\
            .with_data({"index": i})\
            .create()
    
    # Benchmark list
    await cmp.services.get_service('context_service').list(limit=10)


async def run_context_benchmarks():
    """Run all context benchmarks."""
    # Configure for benchmarking
    config = CMPConfig()
    config.storage.backend = "memory"  # Use in-memory for consistent benchmarks
    set_config(config)
    
    suite = BenchmarkSuite("Context Operations")
    
    # Add benchmarks
    suite.add_benchmark("context_create", benchmark_context_create, iterations=100)
    suite.add_benchmark("context_create_with_schema", benchmark_context_create_with_schema, iterations=100)
    suite.add_benchmark("context_read", benchmark_context_read, iterations=100)
    suite.add_benchmark("context_update", benchmark_context_update, iterations=100)
    suite.add_benchmark("context_delete", benchmark_context_delete, iterations=100)
    suite.add_benchmark("context_list", benchmark_context_list, iterations=50)
    
    # Run benchmarks
    await suite.run_all()
    
    # Print summary
    suite.print_summary()
    
    # Save results
    suite.save_results()
    
    return suite


if __name__ == "__main__":
    asyncio.run(run_context_benchmarks())
