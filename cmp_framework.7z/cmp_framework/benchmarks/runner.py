"""
Benchmark runner - Execute all benchmarks and generate reports.

Usage:
    python -m benchmarks.runner --all
    python -m benchmarks.runner --context
    python -m benchmarks.runner --baseline
"""

import asyncio
import argparse
from pathlib import Path

from benchmarks.context_benchmarks import run_context_benchmarks


async def run_all_benchmarks(baseline: bool = False):
    """
    Run all benchmark suites.
    
    Args:
        baseline: If True, save results as baseline
    """
    print("\n" + "="*80)
    print("CMP Framework - Performance Benchmarks")
    print("="*80)
    
    # Run context benchmarks
    context_suite = await run_context_benchmarks()
    
    # Save results
    if baseline:
        output_dir = "benchmark_results/baselines"
        context_suite.save_results(output_dir)
        print(f"\n✓ Baseline results saved to {output_dir}")
    else:
        context_suite.save_results()
        
        # Compare with baseline if exists
        baseline_file = "benchmark_results/baselines/Context_Operations_*.json"
        baseline_path = list(Path("benchmark_results/baselines").glob("Context_Operations_*.json"))
        if baseline_path:
            context_suite.compare_with_baseline(str(baseline_path[-1]))
    
    print("\n" + "="*80)
    print("Benchmark run complete!")
    print("="*80 + "\n")


def main():
    """Main entry point for benchmark runner."""
    parser = argparse.ArgumentParser(description="CMP Framework Benchmark Runner")
    parser.add_argument("--all", action="store_true", help="Run all benchmarks")
    parser.add_argument("--context", action="store_true", help="Run context benchmarks")
    parser.add_argument("--baseline", action="store_true", help="Save results as baseline")
    
    args = parser.parse_args()
    
    if args.all or args.context or not any(vars(args).values()):
        asyncio.run(run_all_benchmarks(baseline=args.baseline))
    else:
        print("No benchmarks selected. Use --all or --context")


if __name__ == "__main__":
    main()
