"""
Benchmarking framework for CMP Framework.

Provides utilities for running performance benchmarks and collecting metrics.
"""

import time
import asyncio
import statistics
from typing import Callable, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path


@dataclass
class BenchmarkResult:
    """Result of a benchmark run."""
    
    name: str
    iterations: int
    total_time: float
    mean_time: float
    median_time: float
    p95_time: float
    p99_time: float
    min_time: float
    max_time: float
    std_dev: float
    throughput: float  # operations per second
    timestamp: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "iterations": self.iterations,
            "total_time": self.total_time,
            "mean_time": self.mean_time,
            "median_time": self.median_time,
            "p95_time": self.p95_time,
            "p99_time": self.p99_time,
            "min_time": self.min_time,
            "max_time": self.max_time,
            "std_dev": self.std_dev,
            "throughput": self.throughput,
            "timestamp": self.timestamp
        }


class Benchmark:
    """
    Benchmark runner for performance testing.
    
    Example:
        >>> benchmark = Benchmark("context_create")
        >>> 
        >>> async def test_func():
        ...     await create_context()
        >>> 
        >>> result = await benchmark.run_async(test_func, iterations=100)
        >>> print(f"Mean time: {result.mean_time:.3f}ms")
    """
    
    def __init__(self, name: str):
        """
        Initialize benchmark.
        
        Args:
            name: Benchmark name
        """
        self.name = name
        self.results: list[BenchmarkResult] = []
    
    async def run_async(
        self,
        func: Callable,
        iterations: int = 100,
        warmup: int = 10,
        **kwargs
    ) -> BenchmarkResult:
        """
        Run async benchmark.
        
        Args:
            func: Async function to benchmark
            iterations: Number of iterations
            warmup: Number of warmup iterations
            **kwargs: Arguments to pass to function
            
        Returns:
            BenchmarkResult with timing statistics
        """
        # Warmup
        for _ in range(warmup):
            await func(**kwargs)
        
        # Benchmark
        times = []
        start_total = time.perf_counter()
        
        for _ in range(iterations):
            start = time.perf_counter()
            await func(**kwargs)
            end = time.perf_counter()
            times.append((end - start) * 1000)  # Convert to ms
        
        end_total = time.perf_counter()
        total_time = (end_total - start_total) * 1000
        
        # Calculate statistics
        result = self._calculate_stats(times, total_time, iterations)
        self.results.append(result)
        
        return result
    
    def run_sync(
        self,
        func: Callable,
        iterations: int = 100,
        warmup: int = 10,
        **kwargs
    ) -> BenchmarkResult:
        """
        Run synchronous benchmark.
        
        Args:
            func: Function to benchmark
            iterations: Number of iterations
            warmup: Number of warmup iterations
            **kwargs: Arguments to pass to function
            
        Returns:
            BenchmarkResult with timing statistics
        """
        # Warmup
        for _ in range(warmup):
            func(**kwargs)
        
        # Benchmark
        times = []
        start_total = time.perf_counter()
        
        for _ in range(iterations):
            start = time.perf_counter()
            func(**kwargs)
            end = time.perf_counter()
            times.append((end - start) * 1000)  # Convert to ms
        
        end_total = time.perf_counter()
        total_time = (end_total - start_total) * 1000
        
        # Calculate statistics
        result = self._calculate_stats(times, total_time, iterations)
        self.results.append(result)
        
        return result
    
    def _calculate_stats(
        self,
        times: list[float],
        total_time: float,
        iterations: int
    ) -> BenchmarkResult:
        """Calculate benchmark statistics."""
        times_sorted = sorted(times)
        
        return BenchmarkResult(
            name=self.name,
            iterations=iterations,
            total_time=total_time,
            mean_time=statistics.mean(times),
            median_time=statistics.median(times),
            p95_time=times_sorted[int(len(times) * 0.95)],
            p99_time=times_sorted[int(len(times) * 0.99)],
            min_time=min(times),
            max_time=max(times),
            std_dev=statistics.stdev(times) if len(times) > 1 else 0,
            throughput=iterations / (total_time / 1000),  # ops/sec
            timestamp=datetime.utcnow().isoformat()
        )
    
    def save_results(self, output_dir: str = "benchmark_results"):
        """
        Save benchmark results to JSON file.
        
        Args:
            output_dir: Output directory path
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.name}_{timestamp}.json"
        filepath = output_path / filename
        
        data = {
            "benchmark": self.name,
            "results": [r.to_dict() for r in self.results]
        }
        
        filepath.write_text(json.dumps(data, indent=2))
        print(f"Results saved to: {filepath}")


class BenchmarkSuite:
    """
    Suite of benchmarks for comprehensive testing.
    
    Example:
        >>> suite = BenchmarkSuite("CMP Performance")
        >>> suite.add_benchmark("context_create", test_context_create)
        >>> suite.add_benchmark("policy_eval", test_policy_eval)
        >>> await suite.run_all()
        >>> suite.print_summary()
    """
    
    def __init__(self, name: str):
        """
        Initialize benchmark suite.
        
        Args:
            name: Suite name
        """
        self.name = name
        self.benchmarks: dict[str, tuple[Callable, dict]] = {}
        self.results: dict[str, BenchmarkResult] = {}
    
    def add_benchmark(
        self,
        name: str,
        func: Callable,
        iterations: int = 100,
        **kwargs
    ):
        """
        Add benchmark to suite.
        
        Args:
            name: Benchmark name
            func: Function to benchmark
            iterations: Number of iterations
            **kwargs: Additional arguments for function
        """
        self.benchmarks[name] = (func, {"iterations": iterations, **kwargs})
    
    async def run_all(self):
        """Run all benchmarks in suite."""
        print(f"\n{'='*60}")
        print(f"Running Benchmark Suite: {self.name}")
        print(f"{'='*60}\n")
        
        for name, (func, config) in self.benchmarks.items():
            print(f"Running: {name}...")
            
            benchmark = Benchmark(name)
            
            if asyncio.iscoroutinefunction(func):
                result = await benchmark.run_async(func, **config)
            else:
                result = benchmark.run_sync(func, **config)
            
            self.results[name] = result
            
            print(f"  Mean: {result.mean_time:.3f}ms")
            print(f"  P95:  {result.p95_time:.3f}ms")
            print(f"  Throughput: {result.throughput:.1f} ops/sec\n")
    
    def print_summary(self):
        """Print benchmark summary table."""
        print(f"\n{'='*60}")
        print(f"Benchmark Summary: {self.name}")
        print(f"{'='*60}\n")
        
        print(f"{'Benchmark':<30} {'Mean (ms)':<12} {'P95 (ms)':<12} {'Ops/sec':<12}")
        print("-" * 66)
        
        for name, result in self.results.items():
            print(f"{name:<30} {result.mean_time:<12.3f} {result.p95_time:<12.3f} {result.throughput:<12.1f}")
        
        print()
    
    def save_results(self, output_dir: str = "benchmark_results"):
        """Save all results to JSON file."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.name.replace(' ', '_')}_{timestamp}.json"
        filepath = output_path / filename
        
        data = {
            "suite": self.name,
            "timestamp": datetime.utcnow().isoformat(),
            "results": {name: result.to_dict() for name, result in self.results.items()}
        }
        
        filepath.write_text(json.dumps(data, indent=2))
        print(f"Results saved to: {filepath}")
    
    def compare_with_baseline(self, baseline_file: str):
        """
        Compare results with baseline.
        
        Args:
            baseline_file: Path to baseline JSON file
        """
        baseline_path = Path(baseline_file)
        if not baseline_path.exists():
            print(f"Baseline file not found: {baseline_file}")
            return
        
        baseline_data = json.loads(baseline_path.read_text())
        baseline_results = baseline_data.get("results", {})
        
        print(f"\n{'='*80}")
        print(f"Comparison with Baseline: {baseline_file}")
        print(f"{'='*80}\n")
        
        print(f"{'Benchmark':<25} {'Current':<12} {'Baseline':<12} {'Change':<12} {'Status':<10}")
        print("-" * 80)
        
        for name, result in self.results.items():
            if name in baseline_results:
                baseline_mean = baseline_results[name]["mean_time"]
                current_mean = result.mean_time
                change_pct = ((current_mean - baseline_mean) / baseline_mean) * 100
                
                if change_pct < -5:
                    status = "✓ Faster"
                elif change_pct > 5:
                    status = "✗ Slower"
                else:
                    status = "~ Same"
                
                print(f"{name:<25} {current_mean:<12.3f} {baseline_mean:<12.3f} {change_pct:>+11.1f}% {status:<10}")
            else:
                print(f"{name:<25} {result.mean_time:<12.3f} {'N/A':<12} {'N/A':<12} {'New':<10}")
        
        print()
