# CMP Framework

**Context Management Plane** - A production-ready Python framework for managing context in agentic systems.

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

CMP Framework provides a robust, scalable platform for managing context in multi-agent systems. It offers enterprise-grade features including schema validation, policy enforcement, workflow orchestration, and comprehensive observability.

## Features

### Core Capabilities

- **Context Management**: Immutable, versioned contexts with schema validation
- **Policy Enforcement**: OPA integration for fine-grained access control
- **Workflow Orchestration**: Multiple strategies (chaining, fan-out/fan-in, evolution)
- **Multi-Tenancy**: Built-in tenant isolation and data segregation

### Advanced Features (Phase 4)

- **Configuration Management**: Pydantic-based config with YAML + env vars
- **Registry System**: Schema, Policy, and Knowledge registries with versioning
- **Enhanced Monitoring**: Structured logging, distributed tracing, health checks, profiling
- **CLI Tool**: Comprehensive command-line interface with Rich output
- **REST API**: FastAPI server with JWT auth, rate limiting, OpenAPI docs

## Quick Start

### Installation

```bash
# Clone repository
git clone https://github.com/yourusername/cmp-framework.git
cd cmp-framework

# Install with Poetry
poetry install

# Or with pip
pip install -e .
```

### Basic Usage

```python
from cmp import CMP

# Initialize CMP
cmp = CMP(tenant_id="acme_corp")

# Create context
context_id = await cmp.context()\
    .with_data({"user_id": "123", "action": "login"})\
    .with_schema("user_event")\
    .create()

# Execute workflow
async for result in cmp.workflow("enrichment")\
    .with_context(context_id)\
    .execute():
    print(f"Step completed: {result.id}")
```

### CLI Usage

```bash
# Context management
cmp context create --data '{"key": "value"}' --tenant acme
cmp context list --tenant acme

# Monitoring
cmp monitor health --detailed
cmp monitor metrics

# Registry management
cmp registry schema list
cmp registry policy list
```

### API Server

```bash
# Run server
poetry run python -m cmp.api.server

# Access
# API: http://localhost:8000
# Docs: http://localhost:8000/docs
```

## Architecture

```
┌─────────────────────────────────────────────────────┐
│              Client Layer                            │
│  CLI Tool  │  REST API  │  Python SDK               │
└─────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────┐
│         Monitoring & Observability                   │
│  Logging  │  Tracing  │  Metrics  │  Health         │
└─────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────┐
│              Core Services                           │
│  Context  │  Policy  │  Orchestration  │  Registry  │
└─────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────┐
│            Storage & External Services               │
│  Persistence  │  OPA  │  SageMCP  │  Temporal       │
└─────────────────────────────────────────────────────┘
```

## Configuration

### Environment Variables

```bash
# Core
export CMP_ENVIRONMENT=production
export CMP_DEBUG=false

# Security
export CMP_SECURITY__JWT_SECRET=your-secret-key
export CMP_SECURITY__AUTHENTICATION_ENABLED=true

# Storage
export CMP_STORAGE__BACKEND=postgresql
export CMP_STORAGE__URL=postgresql://user:pass@localhost/cmp

# Monitoring
export CMP_MONITORING__LOG_LEVEL=INFO
export CMP_MONITORING__TRACING_ENABLED=true
```

### YAML Configuration

```yaml
# config/production.yaml
environment: production
debug: false

storage:
  backend: postgresql
  url: ${DATABASE_URL}

security:
  authentication_enabled: true
  jwt_secret: ${JWT_SECRET}

monitoring:
  log_level: INFO
  tracing_enabled: true
  jaeger_endpoint: http://jaeger:14268/api/traces
```

## Deployment

### Docker

```bash
docker-compose up -d
```

### Kubernetes

```bash
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

See [deployment guide](docs/deployment.md) for details.

## Documentation

- [Requirements](docs/requirements.md) - Original requirements and specifications
- [Phase 4 Summary](docs/phase4_summary.md) - Advanced features documentation
- [Walkthrough](walkthrough.md) - Complete implementation walkthrough
- [API Documentation](http://localhost:8000/docs) - OpenAPI/Swagger docs (when server running)

## Examples

- [Registry Demo](examples/registry_demo.py) - Schema, Policy, Knowledge registries
- [Monitoring Demo](examples/monitoring_demo.py) - Logging, tracing, profiling

## Testing

```bash
# Run all tests
poetry run pytest

# With coverage
poetry run pytest --cov=cmp

# Specific test
poetry run pytest tests/test_context.py
```

## Development

### Project Structure

```
cmp_framework/
├── cmp/                    # Main package
│   ├── core/              # Core models and utilities
│   ├── services/          # Context, Policy, Orchestration services
│   ├── sdk/               # SDK layer (CMP client, Agent base)
│   ├── registries/        # Schema, Policy, Knowledge registries
│   ├── monitoring/        # Logging, tracing, health checks
│   ├── cli/               # Command-line interface
│   └── api/               # REST API server
├── config/                # Configuration files
├── examples/              # Usage examples
├── tests/                 # Test suite
└── docs/                  # Documentation
```

### Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests
5. Submit a pull request

## Monitoring

### Health Checks

```bash
# Liveness probe
curl http://localhost:8000/health/live

# Readiness probe
curl http://localhost:8000/health/ready

# Detailed status
curl http://localhost:8000/health/
```

### Metrics

```bash
# Prometheus format
curl http://localhost:8000/metrics

# CLI
cmp monitor metrics --format prometheus
```

### Tracing

Access Jaeger UI at <http://localhost:16686> (when Jaeger is running)

## Performance

- **Context Operations**: ~10ms (in-memory), ~50ms (PostgreSQL)
- **Schema Validation**: ~2ms per validation
- **Policy Evaluation**: ~5ms per decision
- **API Latency**: ~20ms (p50), ~50ms (p95)

## Security

- JWT-based authentication
- API key support
- Rate limiting (configurable)
- Tenant isolation
- Sensitive data masking in logs

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/cmp-framework/issues)
- **Documentation**: [docs/](docs/)
- **Examples**: [examples/](examples/)

## Roadmap

- [x] Phase 1: Foundation
- [x] Phase 2: Services & Orchestration
- [x] Phase 3: Testing & Production
- [x] Phase 4: Advanced Features
- [ ] Phase 5: Performance Optimization
- [ ] Phase 6: Advanced Integrations

## Acknowledgments

Built with:

- [FastAPI](https://fastapi.tiangolo.com/) - Modern web framework
- [Pydantic](https://pydantic-docs.helpmanual.io/) - Data validation
- [Typer](https://typer.tiangolo.com/) - CLI framework
- [OpenTelemetry](https://opentelemetry.io/) - Observability
- [OPA](https://www.openpolicyagent.org/) - Policy engine

---

**CMP Framework** - Production-ready context management for agentic systems.
