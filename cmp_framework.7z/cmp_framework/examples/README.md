# CMP Framework Examples

This directory contains comprehensive examples demonstrating various features of the CMP Framework.

> 📚 **See [EXAMPLES_SUMMARY.md](EXAMPLES_SUMMARY.md) for a complete feature coverage matrix and quick reference guide.**

## Available Examples

### 1. **graphql_example.py** - GraphQL API

Demonstrates GraphQL queries, mutations, and subscriptions:

- Creating contexts via GraphQL mutations
- Querying contexts and schemas
- Updating and deleting contexts
- Executing workflows through GraphQL
- Real-time subscriptions

**Run**: `python examples/graphql_example.py`

### 2. **websocket_example.py** - WebSocket Real-Time Updates

Shows WebSocket connections and real-time messaging:

- Connecting to WebSocket server
- Channel subscriptions
- Message broadcasting
- Multi-client scenarios

**Run**: `python examples/websocket_example.py`

### 3. **workflow_patterns_example.py** - Advanced Workflow Patterns

Demonstrates sophisticated workflow patterns:

- **Conditional workflows**: If/else branching based on context data
- **Switch workflows**: Case-based routing
- **Saga pattern**: Distributed transactions with compensation
- **Retry pattern**: Exponential backoff
- **Circuit breaker**: Preventing cascading failures

**Run**: `python examples/workflow_patterns_example.py`

### 4. **fan_out_fan_in_example.py** - Fan-Out/Fan-In Pattern

Demonstrates parallel agent execution with result aggregation:

- **Fan-out**: Multiple agents process the same context concurrently
- **Fan-in**: Results are aggregated into a single context
- Performance comparison: Parallel vs Sequential execution
- Error handling and graceful degradation
- Real-world use case: User dashboard data aggregation

**Run**: `python examples/fan_out_fan_in_example.py`

### 5. **plugin_example.py** - Plugin System

Shows how to create and use plugins:

- Creating custom plugins (logging, validation, metrics)
- Plugin lifecycle (init, start, stop)
- Hook system for extensibility
- Plugin discovery and loading

**Run**: `python examples/plugin_example.py`

### 6. **performance_example.py** - Performance Optimization

Demonstrates performance features:

- Caching (in-memory and Redis)
- Async worker pools
- Batch processing
- Sequential vs parallel performance comparison

**Run**: `python examples/performance_example.py`

### 7. **end_to_end_example.py** - Complete Workflow

Comprehensive example using multiple features:

- Context creation and management
- Multi-agent workflows
- Multi-tenant isolation
- Monitoring and health checks
- Structured logging

**Run**: `python examples/end_to_end_example.py`

### 8. **monitoring_demo.py** - Monitoring & Observability

(Already exists) Demonstrates:

- Structured logging
- Health checks
- Distributed tracing
- Profiling

**Run**: `python examples/monitoring_demo.py`

### 9. **registry_demo.py** - Registry System

(Already exists) Shows:

- Schema registry
- Policy registry
- Knowledge registry

**Run**: `python examples/registry_demo.py`

## Quick Start

1. **Install dependencies**:

   ```bash
   poetry install
   ```

2. **Start the API server** (for GraphQL/WebSocket examples):

   ```bash
   poetry run python -m cmp.api.server
   ```

3. **Run an example**:

   ```bash
   poetry run python examples/graphql_example.py
   ```

## Example Categories

### Basic Features

- Context CRUD operations
- Schema validation
- Policy enforcement
- Multi-tenancy

### Advanced Features

- GraphQL API
- WebSocket real-time updates
- Advanced workflow patterns
- Plugin system

### Performance

- Caching strategies
- Async worker pools
- Batch processing
- Load testing

### Observability

- Structured logging
- Health checks
- Distributed tracing
- Metrics collection

## Prerequisites

Some examples require additional setup:

- **GraphQL examples**: Install `gql` client

  ```bash
  pip install gql[aiohttp]
  ```

- **WebSocket examples**: Install `websockets`

  ```bash
  pip install websockets
  ```

- **Redis caching**: Run Redis server

  ```bash
  docker run -d -p 6379:6379 redis
  ```

## Example Output

Each example includes detailed console output showing:

- ✓ Successful operations
- ✗ Errors and failures
- Performance metrics
- State transitions

## Contributing

To add a new example:

1. Create a new file in `examples/`
2. Follow the existing format with clear sections
3. Include docstrings and comments
4. Add entry to this README
5. Test the example thoroughly

## Support

For questions or issues with examples:

- Check the main documentation in `docs/`
- Review the walkthrough in `walkthrough.md`
- Open an issue on GitHub
