"""
Example demonstrating the complete registry system.

This example shows how to use:
- SchemaRegistry for JSON schema management
- PolicyRegistry for OPA policy management
- KnowledgeRegistry for knowledge source management
- Configuration management
"""

import asyncio
from datetime import datetime
from pathlib import Path

from cmp.config import CMPConfig, get_config, set_config
from cmp.registries import (
    SchemaRegistry,
    PolicyRegistry,
    KnowledgeRegistry,
    KnowledgeSource,
    KnowledgeItem,
    KnowledgeType,
    create_backend,
)


async def demonstrate_schema_registry():
    """Demonstrate SchemaRegistry features."""
    print("\n=== Schema Registry Demo ===\n")
    
    # Create registry with file backend
    backend = create_backend("file", base_path="./data/schemas")
    registry = SchemaRegistry(backend=backend, cache_enabled=True)
    
    # Register a schema
    user_schema = {
        "type": "object",
        "properties": {
            "user_id": {"type": "string"},
            "email": {"type": "string", "format": "email"},
            "age": {"type": "integer", "minimum": 0}
        },
        "required": ["user_id", "email"]
    }
    
    result = await registry.register_schema(
        schema_id="user_profile",
        schema=user_schema,
        version="1.0.0",
        description="User profile schema v1"
    )
    
    if result.is_ok():
        print("✓ Registered user_profile schema v1.0.0")
    else:
        print(f"✗ Failed to register schema: {result.unwrap_err()}")
    
    # Register a new version
    user_schema_v2 = {
        **user_schema,
        "properties": {
            **user_schema["properties"],
            "phone": {"type": "string"}
        }
    }
    
    result = await registry.register_schema(
        schema_id="user_profile",
        schema=user_schema_v2,
        version="2.0.0",
        description="User profile schema v2 with phone"
    )
    
    if result.is_ok():
        print("✓ Registered user_profile schema v2.0.0")
    
    # Validate data
    valid_data = {
        "user_id": "123",
        "email": "user@example.com",
        "age": 25
    }
    
    result = await registry.validate_data("user_profile", valid_data)
    if result.is_ok():
        print(f"✓ Valid data passed validation")
    
    invalid_data = {
        "user_id": "123",
        "email": "not-an-email",  # Invalid email format
        "age": -5  # Negative age
    }
    
    result = await registry.validate_data("user_profile", invalid_data)
    if result.is_err():
        print(f"✓ Invalid data correctly rejected: {result.unwrap_err()}")
    
    # List all schemas
    result = await registry.list_schemas()
    if result.is_ok():
        schemas = result.unwrap()
        print(f"\n✓ Found {len(schemas)} schema versions:")
        for schema_info in schemas:
            print(f"  - {schema_info.schema_id} v{schema_info.version}: {schema_info.description}")
    
    # Deprecate old version
    result = await registry.deprecate_schema("user_profile", "1.0.0")
    if result.is_ok():
        print("\n✓ Deprecated user_profile v1.0.0")
    
    await registry.close()


async def demonstrate_policy_registry():
    """Demonstrate PolicyRegistry features."""
    print("\n=== Policy Registry Demo ===\n")
    
    # Create registry with file backend
    backend = create_backend("file", base_path="./data/policies")
    registry = PolicyRegistry(backend=backend)
    
    # Register a policy
    workflow_policy = """
package workflow

default allow = false

# Allow admins to execute any workflow
allow {
    input.user.role == "admin"
    input.action == "execute"
}

# Allow users to execute their own workflows
allow {
    input.user.id == input.workflow.owner_id
    input.action == "execute"
}

# Get recommended strategy based on workflow type
strategy[s] {
    input.workflow.type == "sequential"
    s := "chaining"
}

strategy[s] {
    input.workflow.type == "parallel"
    s := "fan_out_fan_in"
}

strategy[s] {
    input.workflow.type == "iterative"
    s := "evolution"
}
"""
    
    result = await registry.register_policy(
        policy_id="workflow_policy",
        rego_code=workflow_policy,
        version="1.0.0",
        description="Workflow execution and strategy policy"
    )
    
    if result.is_ok():
        print("✓ Registered workflow_policy v1.0.0")
    else:
        print(f"✗ Failed to register policy: {result.unwrap_err()}")
    
    # Test the policy
    test_cases = [
        {
            "name": "admin_can_execute",
            "input": {
                "user": {"role": "admin", "id": "user1"},
                "action": "execute",
                "workflow": {"owner_id": "user2"}
            },
            "expected": {"allow": True}
        },
        {
            "name": "owner_can_execute",
            "input": {
                "user": {"role": "user", "id": "user1"},
                "action": "execute",
                "workflow": {"owner_id": "user1"}
            },
            "expected": {"allow": True}
        },
        {
            "name": "non_owner_cannot_execute",
            "input": {
                "user": {"role": "user", "id": "user1"},
                "action": "execute",
                "workflow": {"owner_id": "user2"}
            },
            "expected": {"allow": False}
        }
    ]
    
    result = await registry.test_policy("workflow_policy", test_cases)
    if result.is_ok():
        test_results = result.unwrap()
        print(f"\n✓ Policy tests: {test_results.passed}/{test_results.total} passed")
        for test_result in test_results.results:
            status = "✓" if test_result.passed else "✗"
            print(f"  {status} {test_result.test_name}")
    
    # Mark as deployed
    result = await registry.mark_deployed("workflow_policy", "1.0.0")
    if result.is_ok():
        print("\n✓ Marked workflow_policy v1.0.0 as deployed")
    
    # List all policies
    result = await registry.list_policies()
    if result.is_ok():
        policies = result.unwrap()
        print(f"\n✓ Found {len(policies)} policy versions:")
        for policy_info in policies:
            deployed = "deployed" if policy_info.deployed else "not deployed"
            print(f"  - {policy_info.policy_id} v{policy_info.version} ({deployed})")
    
    await registry.close()


async def demonstrate_knowledge_registry():
    """Demonstrate KnowledgeRegistry features."""
    print("\n=== Knowledge Registry Demo ===\n")
    
    # Create registry with file backend
    backend = create_backend("file", base_path="./data/knowledge")
    registry = KnowledgeRegistry(backend=backend)
    
    # Register a knowledge source
    source = KnowledgeSource(
        source_id="api_docs",
        source_type=KnowledgeType.DOCUMENT,
        name="API Documentation",
        description="REST API reference documentation",
        config={"format": "markdown", "version": "1.0"},
        metadata={"language": "en", "last_updated": "2025-11-25"},
        created_at=datetime.utcnow().isoformat()
    )
    
    result = await registry.register_knowledge(source)
    if result.is_ok():
        print("✓ Registered knowledge source: api_docs")
    
    # Add knowledge items
    items = [
        KnowledgeItem(
            item_id="auth_guide",
            source_id="api_docs",
            content="Authentication Guide: Use JWT tokens for API authentication. "
                   "Include the token in the Authorization header as 'Bearer <token>'.",
            metadata={"section": "authentication", "difficulty": "beginner"},
            score=1.0
        ),
        KnowledgeItem(
            item_id="rate_limits",
            source_id="api_docs",
            content="Rate Limiting: API requests are limited to 100 requests per minute. "
                   "Use the X-RateLimit headers to track your usage.",
            metadata={"section": "limits", "difficulty": "intermediate"},
            score=1.0
        ),
        KnowledgeItem(
            item_id="webhooks",
            source_id="api_docs",
            content="Webhooks: Configure webhooks to receive real-time notifications. "
                   "Webhook payloads include authentication signatures for verification.",
            metadata={"section": "webhooks", "difficulty": "advanced"},
            score=1.0
        )
    ]
    
    for item in items:
        result = await registry.add_knowledge_item(item)
        if result.is_ok():
            print(f"✓ Added knowledge item: {item.item_id}")
    
    # Mark source as indexed
    result = await registry.mark_indexed("api_docs")
    if result.is_ok():
        print("\n✓ Marked api_docs as indexed")
    
    # Search knowledge
    search_queries = ["authentication", "rate", "webhook"]
    
    for query in search_queries:
        result = await registry.search(query, limit=5)
        if result.is_ok():
            search_result = result.unwrap()
            print(f"\n✓ Search for '{query}' found {search_result.total_results} results (took {search_result.took_ms}ms):")
            for item in search_result.items:
                print(f"  - {item.item_id} (score: {item.score:.3f})")
                print(f"    {item.content[:80]}...")
    
    # List all sources
    result = await registry.list_sources()
    if result.is_ok():
        sources = result.unwrap()
        print(f"\n✓ Found {len(sources)} knowledge sources:")
        for src in sources:
            indexed = "indexed" if src.indexed else "not indexed"
            print(f"  - {src.source_id} ({src.source_type.value}, {indexed})")
    
    await registry.close()


async def demonstrate_configuration():
    """Demonstrate configuration management."""
    print("\n=== Configuration Management Demo ===\n")
    
    # Load config from YAML
    config_path = Path("config/development.yaml")
    if config_path.exists():
        config = CMPConfig.from_yaml(config_path)
        print(f"✓ Loaded configuration from {config_path}")
        print(f"  Environment: {config.environment}")
        print(f"  Debug: {config.debug}")
        print(f"  Storage backend: {config.storage.backend}")
        print(f"  API port: {config.api.port}")
        print(f"  Log level: {config.monitoring.log_level}")
        
        # Set as global config
        set_config(config)
        print("\n✓ Set as global configuration")
        
        # Access global config
        global_config = get_config()
        print(f"✓ Retrieved global config: {global_config.environment} environment")
    else:
        print(f"✗ Configuration file not found: {config_path}")
        print("  Using default configuration")
        config = CMPConfig()
        print(f"  Environment: {config.environment}")
        print(f"  Storage backend: {config.storage.backend}")


async def main():
    """Run all demonstrations."""
    print("=" * 60)
    print("CMP Framework - Phase 4 Registry System Demonstration")
    print("=" * 60)
    
    # Configuration
    await demonstrate_configuration()
    
    # Schema Registry
    await demonstrate_schema_registry()
    
    # Policy Registry
    await demonstrate_policy_registry()
    
    # Knowledge Registry
    await demonstrate_knowledge_registry()
    
    print("\n" + "=" * 60)
    print("All demonstrations completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
