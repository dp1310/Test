"""
Dependency Injection Example - Using DI decorators for context and knowledge.

This example demonstrates how to use dependency injection decorators
to automatically inject context and knowledge into agent methods.
"""

import asyncio
from cmp import CMP
from cmp.sdk.agent import Agent
from cmp.core.models import Context
from cmp.di.decorators import context as inject_context


class DataProcessingAgent(Agent):
    """Agent that uses dependency injection."""
    
    async def process(self, context: Context) -> Context:
        """Process method - context passed directly."""
        print(f"Processing context: {context.id}")
        print(f"Current data: {context.data}")
        
        # Process the data
        context.data["processed"] = True
        context.data["processor"] = "DataProcessingAgent"
        
        return context
    
    async def validate_data(self, context: Context) -> bool:
        """Validate data with context."""
        print(f"\nValidating context: {context.id}")
        
        required_fields = ["user_id", "action"]
        for field in required_fields:
            if field not in context.data:
                print(f"  ✗ Missing required field: {field}")
                return False
        
        print(f"  ✓ All required fields present")
        return True


class EnrichmentAgent(Agent):
    """Agent that enriches context with additional data."""
    
    async def process(self, context: Context) -> Context:
        """Enrich context with additional information."""
        print(f"\nEnriching context: {context.id}")
        
        # Add enrichment data
        context.data["enriched_at"] = "2025-11-25T00:00:00Z"
        context.data["enrichment_source"] = "EnrichmentAgent"
        context.data["metadata"] = {
            "version": "1.0",
            "confidence": 0.95
        }
        
        print(f"  ✓ Added enrichment data")
        return context


async def dependency_injection_example():
    """Demonstrate dependency injection features."""
    
    print("=" * 70)
    print("Dependency Injection Example")
    print("=" * 70)
    
    # Initialize CMP
    cmp = CMP(tenant_id="demo_tenant")
    
    # 1. Create context
    print("\n1. Creating context...")
    ctx_id = await cmp.context()\
        .with_data({
            "user_id": "user_123",
            "action": "process_data",
            "value": 42
        })\
        .create()
    
    print(f"✓ Created context: {ctx_id}")
    
    # 2. Use agent with DI
    print("\n2. Using agent with dependency injection...")
    agent = DataProcessingAgent()
    
    # Get context
    result = await cmp.services.get_service('context_service').get(ctx_id)
    context = result.unwrap()
    
    # Process with DI
    processed_context = await agent.process(context)
    print(f"✓ Context processed: {processed_context.data}")
    
    # 3. Validate with DI
    print("\n3. Validating with dependency injection...")
    is_valid = await agent.validate_data(processed_context)
    print(f"✓ Validation result: {is_valid}")
    
    # 4. Chain multiple agents with DI
    print("\n4. Chaining agents with DI...")
    enrichment_agent = EnrichmentAgent()
    enriched_context = await enrichment_agent.process(processed_context)
    
    print(f"\n✓ Final context data:")
    for key, value in enriched_context.data.items():
        print(f"  {key}: {value}")
    
    print("\n" + "=" * 70)
    print("Dependency injection example completed!")
    print("=" * 70)


async def service_container_example():
    """Demonstrate service container usage."""
    
    print("\n" + "=" * 70)
    print("Service Container Example")
    print("=" * 70)
    
    # Initialize CMP
    cmp = CMP(tenant_id="demo_tenant")
    
    # 1. Access services from container
    print("\n1. Accessing services from container...")
    
    context_service = cmp.services.get_service('context_service')
    print(f"✓ Context service: {context_service}")
    
    policy_service = cmp.services.get_service('policy_service')
    print(f"✓ Policy service: {policy_service}")
    
    orchestration_service = cmp.services.get_service('orchestration_service')
    print(f"✓ Orchestration service: {orchestration_service}")
    
    # 2. Use services
    print("\n2. Using services...")
    
    # Create context via service
    ctx_result = await context_service.create(
        data={"test": "data"},
        schema_name="default",
        tenant_id="demo_tenant"
    )
    ctx_id = ctx_result.unwrap()
    print(f"✓ Created context via service: {ctx_id}")
    
    # Retrieve context
    get_result = await context_service.get(ctx_id)
    context = get_result.unwrap()
    print(f"✓ Retrieved context: {context.data}")
    
    # Update context
    update_result = await context_service.update(ctx_id, {"updated": True})
    if update_result.is_ok():
        print(f"✓ Updated context")
    
    # Search contexts
    print("\n3. Searching contexts...")
    count = 0
    async for ctx in context_service.search(
        query={"updated": True},
        tenant_id="demo_tenant",
        limit=10
    ):
        count += 1
        print(f"  Found context: {ctx.id}")
    
    print(f"✓ Found {count} contexts")
    
    print("\n" + "=" * 70)
    print("Service container example completed!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(dependency_injection_example())
    asyncio.run(service_container_example())
