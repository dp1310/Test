"""
GraphQL API Example - Demonstrates GraphQL queries, mutations, and subscriptions.

This example shows how to use the GraphQL API for context management.
"""

import asyncio
from gql import gql, Client
from gql.transport.aiohttp import AIOHTTPTransport


async def graphql_example():
    """Demonstrate GraphQL API usage."""
    
    # Setup GraphQL client
    transport = AIOHTTPTransport(url="http://localhost:8000/graphql")
    client = Client(transport=transport, fetch_schema_from_transport=True)
    
    print("=" * 60)
    print("GraphQL API Example")
    print("=" * 60)
    
    # 1. Create a context using mutation
    print("\n1. Creating context via GraphQL mutation...")
    create_mutation = gql("""
        mutation CreateContext($input: ContextInput!) {
            createContext(input: $input) {
                id
                data
                schema
                createdAt
                version
            }
        }
    """)
    
    result = await client.execute(
        create_mutation,
        variable_values={
            "input": {
                "data": {
                    "user_id": "user_123",
                    "action": "purchase",
                    "amount": 1500.00,
                    "items": ["item1", "item2"]
                },
                "schema": "transaction",
                "tenantId": "acme_corp"
            }
        }
    )
    
    context_id = result["createContext"]["id"]
    print(f"✓ Created context: {context_id}")
    print(f"  Data: {result['createContext']['data']}")
    
    # 2. Query contexts
    print("\n2. Querying contexts...")
    query = gql("""
        query GetContexts($limit: Int!) {
            contexts(limit: $limit) {
                id
                data
                schema
                createdAt
            }
        }
    """)
    
    result = await client.execute(query, variable_values={"limit": 5})
    print(f"✓ Found {len(result['contexts'])} contexts")
    for ctx in result['contexts']:
        print(f"  - {ctx['id']}: {ctx['schema']}")
    
    # 3. Get specific context
    print(f"\n3. Getting context {context_id}...")
    get_query = gql("""
        query GetContext($id: String!) {
            context(id: $id) {
                id
                data
                schema
                version
            }
        }
    """)
    
    result = await client.execute(get_query, variable_values={"id": context_id})
    print(f"✓ Retrieved context")
    print(f"  Version: {result['context']['version']}")
    print(f"  Data: {result['context']['data']}")
    
    # 4. Update context
    print(f"\n4. Updating context {context_id}...")
    update_mutation = gql("""
        mutation UpdateContext($id: String!, $input: ContextUpdateInput!) {
            updateContext(id: $id, input: $input) {
                id
                data
                version
            }
        }
    """)
    
    result = await client.execute(
        update_mutation,
        variable_values={
            "id": context_id,
            "input": {
                "data": {
                    "user_id": "user_123",
                    "action": "purchase",
                    "amount": 1500.00,
                    "items": ["item1", "item2"],
                    "status": "completed"
                }
            }
        }
    )
    
    print(f"✓ Updated context")
    print(f"  New version: {result['updateContext']['version']}")
    print(f"  Updated data: {result['updateContext']['data']}")
    
    # 5. Query schemas
    print("\n5. Querying registered schemas...")
    schemas_query = gql("""
        query GetSchemas {
            schemas {
                schemaId
                version
                description
                deprecated
            }
        }
    """)
    
    result = await client.execute(schemas_query)
    print(f"✓ Found {len(result['schemas'])} schemas")
    for schema in result['schemas']:
        print(f"  - {schema['schemaId']} v{schema['version']}")
    
    # 6. Execute workflow
    print("\n6. Executing workflow via GraphQL...")
    workflow_mutation = gql("""
        mutation ExecuteWorkflow($input: WorkflowExecuteInput!) {
            executeWorkflow(input: $input) {
                id
                workflowName
                status
                stepsCompleted
            }
        }
    """)
    
    result = await client.execute(
        workflow_mutation,
        variable_values={
            "input": {
                "workflowName": "enrichment",
                "contextId": context_id,
                "tenantId": "acme_corp"
            }
        }
    )
    
    print(f"✓ Workflow executed")
    print(f"  Status: {result['executeWorkflow']['status']}")
    print(f"  Steps completed: {result['executeWorkflow']['stepsCompleted']}")
    
    print("\n" + "=" * 60)
    print("GraphQL example completed!")
    print("=" * 60)


async def graphql_subscription_example():
    """Demonstrate GraphQL subscriptions for real-time updates."""
    
    print("\n" + "=" * 60)
    print("GraphQL Subscription Example")
    print("=" * 60)
    
    # Note: This requires WebSocket support
    # In a real implementation, you'd use:
    # from gql.transport.websockets import WebsocketsTransport
    
    subscription = gql("""
        subscription ContextUpdated($id: String!) {
            contextUpdated(id: $id) {
                id
                data
                version
                updatedAt
            }
        }
    """)
    
    print("\nSubscription query created:")
    print("  Listening for updates to context...")
    print("  (In production, this would stream real-time updates)")


if __name__ == "__main__":
    # Run the example
    asyncio.run(graphql_example())
    asyncio.run(graphql_subscription_example())
