"""
Plugin System Example - Creating and using plugins.

This example shows how to create custom plugins and use the plugin system.
"""

import asyncio
from cmp.plugins import Plugin, hook, get_plugin_registry
from cmp.core.models import Context


# Example Plugin 1: Logging Plugin
class LoggingPlugin(Plugin):
    """Plugin that logs all context operations."""
    
    name = "logging-plugin"
    version = "1.0.0"
    description = "Logs all context create/update/delete operations"
    author = "CMP Team"
    
    def on_init(self):
        """Initialize plugin."""
        print(f"[{self.name}] Initializing...")
        self.log_file = "context_operations.log"
    
    def on_start(self):
        """Start plugin."""
        print(f"[{self.name}] Started - logging to {self.log_file}")
    
    def on_stop(self):
        """Stop plugin."""
        print(f"[{self.name}] Stopped")
    
    @hook("context.before_create")
    async def log_before_create(self, context: Context):
        """Log before context creation."""
        print(f"[{self.name}] BEFORE CREATE: {context.id}")
        # In real implementation, write to log file
    
    @hook("context.after_create")
    async def log_after_create(self, context: Context):
        """Log after context creation."""
        print(f"[{self.name}] AFTER CREATE: {context.id}")
    
    @hook("context.before_update")
    async def log_before_update(self, context: Context):
        """Log before context update."""
        print(f"[{self.name}] BEFORE UPDATE: {context.id}")
    
    @hook("context.after_delete")
    async def log_after_delete(self, context_id: str):
        """Log after context deletion."""
        print(f"[{self.name}] AFTER DELETE: {context_id}")


# Example Plugin 2: Validation Plugin
class ValidationPlugin(Plugin):
    """Plugin that validates context data."""
    
    name = "validation-plugin"
    version = "1.0.0"
    description = "Validates context data against custom rules"
    author = "CMP Team"
    
    def on_init(self):
        """Initialize plugin."""
        print(f"[{self.name}] Initializing...")
        self.validation_rules = {}
    
    def on_start(self):
        """Start plugin."""
        print(f"[{self.name}] Started - validation enabled")
        # Load validation rules
        self.validation_rules = {
            "amount": lambda x: x > 0,
            "user_id": lambda x: len(x) > 0
        }
    
    @hook("context.before_create")
    async def validate_context(self, context: Context):
        """Validate context before creation."""
        print(f"[{self.name}] Validating context {context.id}")
        
        for field, rule in self.validation_rules.items():
            if field in context.data:
                if not rule(context.data[field]):
                    raise ValueError(f"Validation failed for field: {field}")
        
        print(f"[{self.name}] ✓ Validation passed")


# Example Plugin 3: Metrics Plugin
class MetricsPlugin(Plugin):
    """Plugin that collects metrics."""
    
    name = "metrics-plugin"
    version = "1.0.0"
    description = "Collects metrics on context operations"
    author = "CMP Team"
    
    def on_init(self):
        """Initialize plugin."""
        print(f"[{self.name}] Initializing...")
        self.metrics = {
            "contexts_created": 0,
            "contexts_updated": 0,
            "contexts_deleted": 0
        }
    
    def on_start(self):
        """Start plugin."""
        print(f"[{self.name}] Started - collecting metrics")
    
    def on_stop(self):
        """Stop plugin."""
        print(f"[{self.name}] Metrics summary:")
        for metric, value in self.metrics.items():
            print(f"  {metric}: {value}")
    
    @hook("context.after_create")
    async def count_create(self, context: Context):
        """Count context creations."""
        self.metrics["contexts_created"] += 1
    
    @hook("context.after_update")
    async def count_update(self, context: Context):
        """Count context updates."""
        self.metrics["contexts_updated"] += 1
    
    @hook("context.after_delete")
    async def count_delete(self, context_id: str):
        """Count context deletions."""
        self.metrics["contexts_deleted"] += 1


async def plugin_system_example():
    """Demonstrate plugin system usage."""
    
    print("=" * 60)
    print("Plugin System Example")
    print("=" * 60)
    
    # Get plugin registry
    registry = get_plugin_registry()
    
    # 1. Manually register plugins
    print("\n1. Registering plugins...")
    
    # Create plugin instances
    logging_plugin = LoggingPlugin()
    validation_plugin = ValidationPlugin()
    metrics_plugin = MetricsPlugin()
    
    # Initialize plugins
    logging_plugin.on_init()
    validation_plugin.on_init()
    metrics_plugin.on_init()
    
    # Register plugins
    registry._plugins["logging-plugin"] = logging_plugin
    registry._plugins["validation-plugin"] = validation_plugin
    registry._plugins["metrics-plugin"] = metrics_plugin
    
    # Register hooks
    registry._register_hooks(logging_plugin)
    registry._register_hooks(validation_plugin)
    registry._register_hooks(metrics_plugin)
    
    print(f"✓ Registered {len(registry.list_plugins())} plugins")
    
    # 2. Start plugins
    print("\n2. Starting plugins...")
    await registry.start_all()
    
    # 3. Trigger hooks
    print("\n3. Triggering hooks...")
    
    from cmp import CMP
    cmp = CMP(tenant_id="demo")
    
    # Create context (triggers before_create and after_create hooks)
    print("\n  Creating context...")
    ctx_id = await cmp.context()\
        .with_data({"amount": 100, "user_id": "user_123"})\
        .create()
    
    result = await cmp.services.get_service('context_service').get(ctx_id)
    context = result.unwrap()
    
    # Manually trigger hooks for demonstration
    await registry.trigger_hook("context.before_create", context)
    await registry.trigger_hook("context.after_create", context)
    
    # Update context
    print("\n  Updating context...")
    await registry.trigger_hook("context.before_update", context)
    await registry.trigger_hook("context.after_update", context)
    
    # Delete context
    print("\n  Deleting context...")
    await registry.trigger_hook("context.after_delete", ctx_id)
    
    # 4. Get plugin info
    print("\n4. Plugin information:")
    for plugin_name in registry.list_plugins():
        plugin = registry.get_plugin(plugin_name)
        metadata = plugin.get_metadata()
        print(f"\n  {metadata.name} v{metadata.version}")
        print(f"    Description: {metadata.description}")
        print(f"    Author: {metadata.author}")
        print(f"    Enabled: {plugin.enabled}")
    
    # 5. Stop plugins
    print("\n5. Stopping plugins...")
    await registry.stop_all()
    
    print("\n" + "=" * 60)
    print("Plugin system example completed!")
    print("=" * 60)


async def plugin_discovery_example():
    """Demonstrate plugin discovery from directory."""
    
    print("\n" + "=" * 60)
    print("Plugin Discovery Example")
    print("=" * 60)
    
    registry = get_plugin_registry()
    
    # Discover plugins from directory
    print("\n1. Discovering plugins from ./plugins directory...")
    discovered = await registry.discover("./plugins")
    
    if discovered:
        print(f"✓ Discovered {len(discovered)} plugins:")
        for plugin_name in discovered:
            print(f"  - {plugin_name}")
        
        # Load all discovered plugins
        print("\n2. Loading discovered plugins...")
        loaded = await registry.load_all()
        print(f"✓ Loaded {loaded} plugins")
        
        # Start all plugins
        print("\n3. Starting all plugins...")
        await registry.start_all()
    else:
        print("  No plugins found in ./plugins directory")
        print("  (This is expected if the directory doesn't exist)")
    
    print("\n" + "=" * 60)


if __name__ == "__main__":
    # Run examples
    asyncio.run(plugin_system_example())
    asyncio.run(plugin_discovery_example())
