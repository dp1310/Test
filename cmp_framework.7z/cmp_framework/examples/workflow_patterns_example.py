"""
Advanced Workflow Patterns Example.

Demonstrates conditional workflows, saga pattern, and retry/circuit breaker.
"""

import asyncio
from cmp import CMP
from cmp.orchestration.patterns import (
    ConditionalWorkflow,
    SwitchWorkflow,
    SagaWorkflow,
    RetryPolicy,
    CircuitBreaker,
    RetryWithCircuitBreaker
)
from cmp.sdk.agent import Agent
from cmp.core.models import Context


# Example agents
class HighValueAgent(Agent):
    """Agent for high-value transactions."""
    
    async def process(self, context: Context) -> Context:
        print("  → Processing high-value transaction")
        context.data["processed_by"] = "high_value_agent"
        context.data["priority"] = "high"
        return context


class StandardAgent(Agent):
    """Agent for standard transactions."""
    
    async def process(self, context: Context) -> Context:
        print("  → Processing standard transaction")
        context.data["processed_by"] = "standard_agent"
        context.data["priority"] = "normal"
        return context


class InventoryAgent(Agent):
    """Reserve inventory."""
    
    async def process(self, context: Context) -> Context:
        print("  → Reserving inventory")
        context.data["inventory_reserved"] = True
        return context


class PaymentAgent(Agent):
    """Charge payment."""
    
    async def process(self, context: Context) -> Context:
        print("  → Charging payment")
        context.data["payment_charged"] = True
        return context


class ShippingAgent(Agent):
    """Ship order."""
    
    async def process(self, context: Context) -> Context:
        print("  → Shipping order")
        context.data["order_shipped"] = True
        return context


async def conditional_workflow_example():
    """Demonstrate conditional workflow."""
    
    print("=" * 60)
    print("Conditional Workflow Example")
    print("=" * 60)
    
    cmp = CMP(tenant_id="demo")
    
    # Create workflow with condition
    workflow = ConditionalWorkflow()
    workflow.when(lambda ctx: ctx.data.get("amount", 0) > 1000) \
        .then(HighValueAgent()) \
        .otherwise(StandardAgent())
    
    # Test with high-value transaction
    print("\n1. High-value transaction (amount > 1000):")
    ctx_id = await cmp.context()\
        .with_data({"amount": 1500, "user": "john"})\
        .create()
    
    result = await cmp.services.get_service('context_service').get(ctx_id)
    context = result.unwrap()
    
    result_context = await workflow.execute(context)
    print(f"  Processed by: {result_context.data['processed_by']}")
    print(f"  Priority: {result_context.data['priority']}")
    
    # Test with standard transaction
    print("\n2. Standard transaction (amount <= 1000):")
    ctx_id = await cmp.context()\
        .with_data({"amount": 500, "user": "jane"})\
        .create()
    
    result = await cmp.services.get_service('context_service').get(ctx_id)
    context = result.unwrap()
    
    result_context = await workflow.execute(context)
    print(f"  Processed by: {result_context.data['processed_by']}")
    print(f"  Priority: {result_context.data['priority']}")


async def switch_workflow_example():
    """Demonstrate switch/case workflow."""
    
    print("\n" + "=" * 60)
    print("Switch Workflow Example")
    print("=" * 60)
    
    cmp = CMP(tenant_id="demo")
    
    # Create switch workflow
    workflow = SwitchWorkflow(lambda ctx: ctx.data.get("type"))
    workflow.case("premium", HighValueAgent()) \
        .case("standard", StandardAgent()) \
        .default(StandardAgent())
    
    # Test different types
    for transaction_type in ["premium", "standard", "basic"]:
        print(f"\n{transaction_type.capitalize()} transaction:")
        ctx_id = await cmp.context()\
            .with_data({"type": transaction_type, "amount": 100})\
            .create()
        
        result = await cmp.services.get_service('context_service').get(ctx_id)
        context = result.unwrap()
        
        result_context = await workflow.execute(context)
        print(f"  Processed by: {result_context.data.get('processed_by', 'default')}")


async def saga_pattern_example():
    """Demonstrate saga pattern with compensation."""
    
    print("\n" + "=" * 60)
    print("Saga Pattern Example")
    print("=" * 60)
    
    cmp = CMP(tenant_id="demo")
    
    # Compensation functions
    async def release_inventory(context: Context) -> Context:
        print("  ↩ Compensating: Releasing inventory")
        context.data["inventory_reserved"] = False
        return context
    
    async def refund_payment(context: Context) -> Context:
        print("  ↩ Compensating: Refunding payment")
        context.data["payment_charged"] = False
        return context
    
    async def cancel_shipment(context: Context) -> Context:
        print("  ↩ Compensating: Canceling shipment")
        context.data["order_shipped"] = False
        return context
    
    # Create saga
    saga = SagaWorkflow()
    saga.step(InventoryAgent().process, compensate=release_inventory, name="reserve_inventory") \
        .step(PaymentAgent().process, compensate=refund_payment, name="charge_payment") \
        .step(ShippingAgent().process, compensate=cancel_shipment, name="ship_order")
    
    # Test successful saga
    print("\n1. Successful transaction:")
    ctx_id = await cmp.context()\
        .with_data({"order_id": "ORD-123", "amount": 100})\
        .create()
    
    result = await cmp.services.get_service('context_service').get(ctx_id)
    context = result.unwrap()
    
    saga_result = await saga.execute(context)
    if saga_result.is_ok():
        final_context = saga_result.unwrap()
        print(f"✓ Saga completed successfully")
        print(f"  Inventory reserved: {final_context.data.get('inventory_reserved')}")
        print(f"  Payment charged: {final_context.data.get('payment_charged')}")
        print(f"  Order shipped: {final_context.data.get('order_shipped')}")


async def retry_circuit_breaker_example():
    """Demonstrate retry and circuit breaker patterns."""
    
    print("\n" + "=" * 60)
    print("Retry & Circuit Breaker Example")
    print("=" * 60)
    
    cmp = CMP(tenant_id="demo")
    
    # Simulated unreliable service
    call_count = 0
    
    async def unreliable_service(context: Context) -> Context:
        nonlocal call_count
        call_count += 1
        
        if call_count < 3:
            print(f"  ✗ Attempt {call_count} failed")
            raise Exception("Service temporarily unavailable")
        
        print(f"  ✓ Attempt {call_count} succeeded")
        context.data["processed"] = True
        return context
    
    # 1. Retry policy
    print("\n1. Retry with exponential backoff:")
    ctx_id = await cmp.context()\
        .with_data({"request": "test"})\
        .create()
    
    result = await cmp.services.get_service('context_service').get(ctx_id)
    context = result.unwrap()
    
    retry_policy = RetryPolicy(max_attempts=5, base_delay=0.5)
    
    try:
        result_context = await retry_policy.execute(unreliable_service, context)
        print(f"✓ Request succeeded after {call_count} attempts")
    except Exception as e:
        print(f"✗ Request failed: {e}")
    
    # 2. Circuit breaker
    print("\n2. Circuit breaker:")
    breaker = CircuitBreaker(failure_threshold=3, timeout=5.0)
    
    print(f"  Circuit state: {breaker.state.value}")
    
    # 3. Combined retry + circuit breaker
    print("\n3. Retry with circuit breaker:")
    combined = RetryWithCircuitBreaker(
        max_attempts=3,
        base_delay=0.5,
        failure_threshold=5
    )
    
    print("  Using combined policy for resilient execution")


if __name__ == "__main__":
    # Run all examples
    asyncio.run(conditional_workflow_example())
    asyncio.run(switch_workflow_example())
    asyncio.run(saga_pattern_example())
    asyncio.run(retry_circuit_breaker_example())
