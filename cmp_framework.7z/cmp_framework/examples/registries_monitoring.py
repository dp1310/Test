"""
Example: Using registries and monitoring.
"""

import asyncio
from cmp import CMP, Agent
from cmp.core.models import Context, Schema
from cmp.registries import SchemaRegistry, AgentRegistry
from cmp.monitoring import get_metrics_collector


class DataProcessingAgent(Agent):
    """Agent that processes data"""
    
    async def process(self, context: Context) -> Context:
        print(f"[{self.agent_id}] Processing context...")
        return context.with_data(
            processed=True,
            processor=self.agent_id
        )


async def main():
    """Run registries and monitoring example"""
    
    print("=== CMP Framework - Registries & Monitoring Example ===\n")
    
    # Get metrics collector
    metrics = get_metrics_collector()
    metrics.reset()
    
    # Initialize CMP
    cmp = CMP(tenant_id="acme_corp")
    
    # 1. Schema Registry
    print("1. Schema Registry")
    schema_registry = SchemaRegistry()
    
    # Register schema
    schema = Schema(
        name="data_processing",
        version="1.0",
        fields={"input": "string", "value": "int"},
        required_fields=("input",)
    )
    
    await schema_registry.register(schema, "acme_corp")
    print(f"   ✓ Registered schema: {schema.name}")
    
    # List schemas
    schemas = await schema_registry.list("acme_corp")
    print(f"   ✓ Total schemas: {len(schemas)}\n")
    
    # 2. Agent Registry
    print("2. Agent Registry")
    agent_registry = AgentRegistry()
    
    # Register agents
    agent1 = DataProcessingAgent("processor_1")
    agent2 = DataProcessingAgent("processor_2")
    
    await agent_registry.register(
        agent1,
        "acme_corp",
        capabilities=["process", "transform"]
    )
    await agent_registry.register(
        agent2,
        "acme_corp",
        capabilities=["process", "validate"]
    )
    
    print(f"   ✓ Registered agent: {agent1.agent_id}")
    print(f"   ✓ Registered agent: {agent2.agent_id}")
    
    # List agents
    agents = await agent_registry.list("acme_corp")
    print(f"   ✓ Total agents: {len(agents)}")
    for agent_meta in agents:
        print(f"     - {agent_meta.agent_id}: {agent_meta.capabilities}\n")
    
    # 3. Execute workflow with monitoring
    print("3. Execute Workflow (with monitoring)")
    
    # Create context
    ctx_id = await cmp.context() \
        .with_data({"input": "test_data", "value": 100}) \
        .with_schema("data_processing") \
        .create()
    
    print(f"   ✓ Created context: {ctx_id}")
    
    # Execute workflow
    async for result in cmp.workflow("data_processing") \
            .with_context(ctx_id) \
            .with_agents([agent1, agent2]) \
            .execute():
        print(f"   ✓ Step completed: {result.data}")
    
    # 4. View Metrics
    print("\n4. Metrics Summary")
    current_metrics = metrics.get_metrics()
    
    print(f"   Contexts Created: {current_metrics.contexts_created}")
    print(f"   Contexts Retrieved: {current_metrics.contexts_retrieved}")
    print(f"   Workflows Executed: {current_metrics.workflows_executed}")
    print(f"   Workflow Steps: {current_metrics.workflow_steps_completed}")
    print(f"   Errors: {current_metrics.errors_total}")
    
    if current_metrics.avg_context_create_time_ms > 0:
        print(f"   Avg Create Time: {current_metrics.avg_context_create_time_ms:.2f}ms")
    
    # 5. Prometheus Export
    print("\n5. Prometheus Metrics Export")
    prometheus_output = metrics.to_prometheus()
    print("   " + "\n   ".join(prometheus_output.split("\n")[:10]))
    print("   ...")
    
    print("\n=== Example Complete ===")


if __name__ == "__main__":
    asyncio.run(main())
