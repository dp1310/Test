"""
Functional Utilities Example - Functional programming patterns.

This example demonstrates functional programming utilities in the CMP framework.
"""

from cmp.utils.functional import pipe, compose, curry, identity, const
from functools import partial


def functional_composition_example():
    """Demonstrate function composition."""
    
    print("=" * 70)
    print("Function Composition Example")
    print("=" * 70)
    
    # Define simple functions
    def add_10(x):
        return x + 10
    
    def multiply_2(x):
        return x * 2
    
    def square(x):
        return x ** 2
    
    # 1. Using pipe (left to right)
    print("\n1. Using pipe (left to right):")
    result = pipe(
        5,
        add_10,      # 5 + 10 = 15
        multiply_2,  # 15 * 2 = 30
        square       # 30^2 = 900
    )
    print(f"  pipe(5, add_10, multiply_2, square) = {result}")
    
    # 2. Using compose (right to left)
    print("\n2. Using compose (right to left):")
    composed = compose(square, multiply_2, add_10)
    result = composed(5)
    print(f"  compose(square, multiply_2, add_10)(5) = {result}")


def currying_example():
    """Demonstrate currying and partial application."""
    
    print("\n" + "=" * 70)
    print("Currying & Partial Application Example")
    print("=" * 70)
    
    # 1. Currying
    print("\n1. Currying:")
    
    @curry
    def add_three(a, b, c):
        return a + b + c
    
    # Can call with all args at once
    result1 = add_three(1, 2, 3)
    print(f"  add_three(1, 2, 3) = {result1}")
    
    # Or partially apply
    add_1 = add_three(1)
    add_1_2 = add_1(2)
    result2 = add_1_2(3)
    print(f"  add_three(1)(2)(3) = {result2}")
    
    # 2. Partial application
    print("\n2. Partial application:")
    
    def multiply(a, b, c):
        return a * b * c
    
    # Create specialized functions
    double = partial(multiply, 2)
    result3 = double(5, 3)  # 2 * 5 * 3
    print(f"  double(5, 3) = {result3}")
    
    triple = partial(multiply, 3)
    result4 = triple(4, 2)  # 3 * 4 * 2
    print(f"  triple(4, 2) = {result4}")


def identity_const_example():
    """Demonstrate identity and const functions."""
    
    print("\n" + "=" * 70)
    print("Identity & Const Example")
    print("=" * 70)
    
    # 1. Identity function
    print("\n1. Identity function:")
    value = 42
    result = identity(value)
    print(f"  identity({value}) = {result}")
    
    # Useful in pipelines
    result = pipe(10, identity, lambda x: x * 2)
    print(f"  pipe(10, identity, lambda x: x * 2) = {result}")
    
    # 2. Const function
    print("\n2. Const function:")
    always_42 = const(42)
    print(f"  always_42() = {always_42()}")
    print(f"  always_42('ignored') = {always_42('ignored')}")
    print(f"  always_42(1, 2, 3) = {always_42(1, 2, 3)}")
    
    # Useful for default values
    get_default = const({"status": "ok"})
    print(f"  get_default() = {get_default()}")


def pipeline_example():
    """Demonstrate data processing pipeline."""
    
    print("\n" + "=" * 70)
    print("Data Processing Pipeline Example")
    print("=" * 70)
    
    # Sample data
    users = [
        {"name": "Alice", "age": 30, "score": 85},
        {"name": "Bob", "age": 25, "score": 92},
        {"name": "Charlie", "age": 35, "score": 78},
        {"name": "Diana", "age": 28, "score": 95},
    ]
    
    print(f"\n1. Original data: {len(users)} users")
    
    # Define transformation functions
    def filter_high_scores(users):
        """Keep users with score >= 80."""
        return [u for u in users if u["score"] >= 80]
    
    def add_grade(users):
        """Add grade based on score."""
        result = []
        for u in users:
            user = u.copy()
            if u["score"] >= 90:
                user["grade"] = "A"
            elif u["score"] >= 80:
                user["grade"] = "B"
            else:
                user["grade"] = "C"
            result.append(user)
        return result
    
    def sort_by_score(users):
        """Sort by score descending."""
        return sorted(users, key=lambda u: u["score"], reverse=True)
    
    # Apply pipeline
    print("\n2. Applying pipeline:")
    print("   filter_high_scores → add_grade → sort_by_score")
    
    result = pipe(
        users,
        filter_high_scores,
        add_grade,
        sort_by_score
    )
    
    print(f"\n✓ Results ({len(result)} users):")
    for user in result:
        print(f"  {user['name']}: {user['score']} (Grade {user['grade']})")


def immutable_updates_example():
    """Demonstrate immutable data updates."""
    
    print("\n" + "=" * 70)
    print("Immutable Updates Example")
    print("=" * 70)
    
    # Original data
    original = {
        "user_id": "123",
        "name": "Alice",
        "settings": {
            "theme": "dark",
            "notifications": True
        }
    }
    
    print(f"\n1. Original data:")
    print(f"  {original}")
    
    # Create updated version (immutable)
    def update_nested(data, path, value):
        """Update nested dict immutably."""
        result = data.copy()
        keys = path.split(".")
        
        current = result
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            else:
                current[key] = current[key].copy()
            current = current[key]
        
        current[keys[-1]] = value
        return result
    
    # Update theme
    updated = update_nested(original, "settings.theme", "light")
    
    print(f"\n2. After updating theme:")
    print(f"  Original: {original['settings']['theme']}")
    print(f"  Updated: {updated['settings']['theme']}")
    print(f"  ✓ Original unchanged (immutable)")


def higher_order_functions_example():
    """Demonstrate higher-order functions."""
    
    print("\n" + "=" * 70)
    print("Higher-Order Functions Example")
    print("=" * 70)
    
    # 1. Function that returns a function
    print("\n1. Function factory:")
    
    def make_multiplier(factor):
        """Create a multiplier function."""
        def multiplier(x):
            return x * factor
        return multiplier
    
    double = make_multiplier(2)
    triple = make_multiplier(3)
    
    print(f"  double(5) = {double(5)}")
    print(f"  triple(5) = {triple(5)}")
    
    # 2. Function that takes a function
    print("\n2. Function decorator:")
    
    def with_logging(func):
        """Add logging to a function."""
        def wrapper(*args, **kwargs):
            print(f"  Calling {func.__name__} with args={args}")
            result = func(*args, **kwargs)
            print(f"  {func.__name__} returned {result}")
            return result
        return wrapper
    
    @with_logging
    def add(a, b):
        return a + b
    
    result = add(3, 4)
    print(f"  Final result: {result}")


if __name__ == "__main__":
    functional_composition_example()
    currying_example()
    identity_const_example()
    pipeline_example()
    immutable_updates_example()
    higher_order_functions_example()
    
    print("\n" + "=" * 70)
    print("All functional utility examples completed!")
    print("=" * 70)
