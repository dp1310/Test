"""
WebSocket Example - Real-time context updates via WebSocket.

This example shows how to connect to the WebSocket endpoint and
receive real-time updates for contexts.
"""

import asyncio
import websockets
import json
from datetime import datetime


async def websocket_client_example():
    """Demonstrate WebSocket client usage."""
    
    print("=" * 60)
    print("WebSocket Client Example")
    print("=" * 60)
    
    uri = "ws://localhost:8000/ws"
    connection_id = "client_123"
    
    try:
        async with websockets.connect(f"{uri}?connection_id={connection_id}") as websocket:
            print(f"\n✓ Connected to WebSocket server")
            print(f"  Connection ID: {connection_id}")
            
            # 1. Subscribe to a context channel
            print("\n1. Subscribing to context updates...")
            subscribe_msg = {
                "type": "subscribe",
                "channel": "context.ctx_abc123"
            }
            await websocket.send(json.dumps(subscribe_msg))
            
            # Wait for subscription confirmation
            response = await websocket.recv()
            msg = json.loads(response)
            print(f"✓ Subscription confirmed: {msg['type']}")
            
            # 2. Send a ping
            print("\n2. Sending ping...")
            ping_msg = {"type": "ping"}
            await websocket.send(json.dumps(ping_msg))
            
            # Wait for pong
            response = await websocket.recv()
            msg = json.loads(response)
            print(f"✓ Received {msg['type']}")
            
            # 3. Listen for updates (with timeout)
            print("\n3. Listening for context updates...")
            print("  (Waiting 10 seconds for updates...)")
            
            try:
                async with asyncio.timeout(10):
                    while True:
                        message = await websocket.recv()
                        data = json.loads(message)
                        
                        if data["type"] == "context.updated":
                            print(f"\n✓ Context update received!")
                            print(f"  Context ID: {data['payload']['context_id']}")
                            print(f"  Data: {data['payload']['data']}")
                            print(f"  Timestamp: {data['payload']['timestamp']}")
            
            except asyncio.TimeoutError:
                print("\n  No updates received (timeout)")
            
            # 4. Unsubscribe
            print("\n4. Unsubscribing from channel...")
            unsubscribe_msg = {
                "type": "unsubscribe",
                "channel": "context.ctx_abc123"
            }
            await websocket.send(json.dumps(unsubscribe_msg))
            
            response = await websocket.recv()
            msg = json.loads(response)
            print(f"✓ Unsubscribed: {msg['type']}")
    
    except Exception as e:
        print(f"\n✗ Error: {e}")
    
    print("\n" + "=" * 60)
    print("WebSocket example completed!")
    print("=" * 60)


async def websocket_broadcast_example():
    """Demonstrate broadcasting to multiple clients."""
    
    print("\n" + "=" * 60)
    print("WebSocket Broadcast Example")
    print("=" * 60)
    
    # Simulate multiple clients
    async def client(client_id: str, channel: str):
        uri = f"ws://localhost:8000/ws?connection_id={client_id}"
        
        try:
            async with websockets.connect(uri) as websocket:
                # Subscribe to channel
                await websocket.send(json.dumps({
                    "type": "subscribe",
                    "channel": channel
                }))
                
                # Wait for confirmation
                await websocket.recv()
                print(f"✓ Client {client_id} subscribed to {channel}")
                
                # Listen for broadcasts
                async with asyncio.timeout(5):
                    while True:
                        message = await websocket.recv()
                        data = json.loads(message)
                        print(f"  {client_id} received: {data['type']}")
        
        except asyncio.TimeoutError:
            print(f"  {client_id} timeout")
        except Exception as e:
            print(f"  {client_id} error: {e}")
    
    # Create multiple clients
    print("\nCreating 3 clients subscribed to same channel...")
    await asyncio.gather(
        client("client_1", "context.shared"),
        client("client_2", "context.shared"),
        client("client_3", "context.shared")
    )
    
    print("\n" + "=" * 60)


if __name__ == "__main__":
    # Run examples
    asyncio.run(websocket_client_example())
    asyncio.run(websocket_broadcast_example())
