"""
Async Helpers Example - Utility functions for async operations.

This example demonstrates async utility functions and patterns.
"""

import asyncio
from cmp.utils.async_helpers import AsyncLock, retry, gather_dict, async_map, async_filter


async def async_task(task_id: int, duration: float):
    """Simulate an async task."""
    print(f"  Task {task_id} starting (duration: {duration}s)")
    await asyncio.sleep(duration)
    print(f"  Task {task_id} completed")
    return f"Result {task_id}"


async def async_lock_example():
    """Demonstrate AsyncLock for thread-safe operations."""
    
    print("=" * 70)
    print("AsyncLock Example")
    print("=" * 70)
    
    lock = AsyncLock()
    shared_resource = {"counter": 0}
    
    async def increment_counter(worker_id: int):
        """Increment counter with lock protection."""
        async with lock:
            current = shared_resource["counter"]
            print(f"  Worker {worker_id}: Read counter = {current}")
            await asyncio.sleep(0.1)  # Simulate work
            shared_resource["counter"] = current + 1
            print(f"  Worker {worker_id}: Updated counter = {shared_resource['counter']}")
    
    print("\n1. Running 5 workers concurrently with lock protection...")
    
    tasks = [increment_counter(i) for i in range(5)]
    await asyncio.gather(*tasks)
    
    print(f"\n✓ Final counter value: {shared_resource['counter']}")
    print("  (Should be 5 - all increments were atomic)")


async def gather_dict_example():
    """Demonstrate gathering tasks as dictionary."""
    
    print("\n" + "=" * 70)
    print("Gather Dict Example")
    print("=" * 70)
    
    async def fetch_user():
        await asyncio.sleep(0.2)
        return {"id": "123", "name": "Alice"}
    
    async def fetch_posts():
        await asyncio.sleep(0.3)
        return [{"id": 1, "title": "Post 1"}, {"id": 2, "title": "Post 2"}]
    
    async def fetch_comments():
        await asyncio.sleep(0.1)
        return [{"id": 1, "text": "Comment 1"}]
    
    print("\n1. Fetching multiple resources concurrently...")
    
    results = await gather_dict({
        "user": fetch_user(),
        "posts": fetch_posts(),
        "comments": fetch_comments()
    })
    
    print(f"\n✓ Results:")
    print(f"  User: {results['user']}")
    print(f"  Posts: {len(results['posts'])} items")
    print(f"  Comments: {len(results['comments'])} items")


async def async_map_example():
    """Demonstrate async map."""
    
    print("\n" + "=" * 70)
    print("Async Map Example")
    print("=" * 70)
    
    async def process_item(item: int):
        """Process an item asynchronously."""
        await asyncio.sleep(0.1)
        return item * 2
    
    items = [1, 2, 3, 4, 5]
    
    print(f"\n1. Mapping over {len(items)} items concurrently...")
    print(f"  Input: {items}")
    
    results = await async_map(process_item, items)
    
    print(f"  Output: {results}")
    print(f"✓ All items processed concurrently")


async def error_handling_example():
    """Demonstrate error handling in async operations."""
    
    print("\n" + "=" * 70)
    print("Error Handling Example")
    print("=" * 70)
    
    async def failing_task(task_id: int):
        """Task that fails."""
        print(f"  Task {task_id} starting")
        await asyncio.sleep(0.1)
        if task_id == 2:
            raise ValueError(f"Task {task_id} failed!")
        return f"Result {task_id}"
    
    print("\n1. Running tasks with error handling...")
    
    tasks = [failing_task(i) for i in range(5)]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    print("\n✓ Results:")
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            print(f"  Task {i}: ✗ Error - {result}")
        else:
            print(f"  Task {i}: ✓ {result}")


async def batch_processing_example():
    """Demonstrate batch processing pattern."""
    
    print("\n" + "=" * 70)
    print("Batch Processing Example")
    print("=" * 70)
    
    async def process_batch(batch_id: int, items: list):
        """Process a batch of items."""
        print(f"  Processing batch {batch_id} ({len(items)} items)")
        await asyncio.sleep(0.2)
        return {
            "batch_id": batch_id,
            "processed": len(items),
            "results": [f"processed_{item}" for item in items]
        }
    
    # Create batches
    all_items = list(range(20))
    batch_size = 5
    batches = [all_items[i:i+batch_size] for i in range(0, len(all_items), batch_size)]
    
    print(f"\n1. Processing {len(all_items)} items in {len(batches)} batches...")
    
    # Process batches concurrently
    tasks = [process_batch(i, batch) for i, batch in enumerate(batches)]
    results = await asyncio.gather(*tasks)
    
    total_processed = sum(r["processed"] for r in results)
    print(f"\n✓ Processed {total_processed} items across {len(results)} batches")


async def retry_pattern_example():
    """Demonstrate retry pattern."""
    
    print("\n" + "=" * 70)
    print("Retry Pattern Example")
    print("=" * 70)
    
    attempt_count = {"value": 0}
    
    async def unreliable_operation():
        """Operation that fails first few times."""
        attempt_count["value"] += 1
        print(f"  Attempt {attempt_count['value']}")
        
        if attempt_count["value"] < 3:
            raise ConnectionError("Service temporarily unavailable")
        
        return "Success!"
    
    print("\n1. Attempting unreliable operation with retry...")
    
    try:
        result = await retry(unreliable_operation, max_attempts=5, delay=0.5, backoff=2.0)
        print(f"\n✓ Operation succeeded: {result}")
        print(f"✓ Total attempts: {attempt_count['value']}")
    except Exception as e:
        print(f"\n✗ Operation failed after all retries: {e}")


async def async_filter_example():
    """Demonstrate async filter."""
    
    print("\n" + "=" * 70)
    print("Async Filter Example")
    print("=" * 70)
    
    async def is_even(n: int):
        """Check if number is even (async)."""
        await asyncio.sleep(0.05)
        return n % 2 == 0
    
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    print(f"\n1. Filtering {len(numbers)} numbers concurrently...")
    print(f"  Input: {numbers}")
    
    evens = await async_filter(is_even, numbers)
    
    print(f"  Even numbers: {evens}")
    print(f"✓ Filtered {len(evens)} even numbers")


if __name__ == "__main__":
    asyncio.run(async_lock_example())
    asyncio.run(gather_dict_example())
    asyncio.run(async_map_example())
    asyncio.run(async_filter_example())
    asyncio.run(error_handling_example())
    asyncio.run(batch_processing_example())
    asyncio.run(retry_pattern_example())
    
    print("\n" + "=" * 70)
    print("All async helper examples completed!")
    print("=" * 70)
