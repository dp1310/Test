"""
Caching Example - Demonstrating cache functionality.

This example shows how to use the caching system for performance optimization.
"""

import asyncio
import time
from cmp.core.cache import InMemoryCache, TTLCache


async def basic_cache_example():
    """Demonstrate basic cache operations."""
    
    print("=" * 70)
    print("Basic Cache Example")
    print("=" * 70)
    
    # 1. In-memory cache
    print("\n1. In-memory cache:")
    cache = InMemoryCache(maxsize=100)
    
    # Set values
    await cache.set("user:123", {"name": "Alice", "email": "alice@example.com"})
    await cache.set("user:456", {"name": "Bob", "email": "bob@example.com"})
    await cache.set("config:app", {"debug": True, "version": "1.0"})
    
    print("✓ Set 3 cache entries")
    
    # Get values
    user = await cache.get("user:123")
    print(f"✓ Retrieved user:123: {user}")
    
    config = await cache.get("config:app")
    print(f"✓ Retrieved config:app: {config}")
    
    # Check existence
    exists = await cache.exists("user:123")
    print(f"✓ user:123 exists: {exists}")
    
    # Get stats
    stats = cache.get_stats()
    print(f"\n✓ Cache statistics:")
    print(f"  Backend: {stats['backend']}")
    print(f"  Size: {stats['size']}/{stats['maxsize']}")
    print(f"  Hits: {stats['hits']}")
    print(f"  Misses: {stats['misses']}")
    print(f"  Hit rate: {stats['hit_rate']:.1f}%")
    
    # Delete entry
    await cache.delete("user:456")
    print(f"\n✓ Deleted user:456")
    
    # Clear cache
    await cache.clear()
    print(f"✓ Cleared cache")
    
    stats = cache.get_stats()
    print(f"✓ Cache size after clear: {stats['size']}")


async def ttl_cache_example():
    """Demonstrate TTL (Time-To-Live) cache."""
    
    print("\n" + "=" * 70)
    print("TTL Cache Example")
    print("=" * 70)
    
    # Create TTL cache with 2 second expiration
    cache = InMemoryCache(maxsize=100, ttl=2)
    
    print("\n1. Setting values with TTL...")
    await cache.set("session:abc", {"user_id": "123", "token": "xyz"})
    await cache.set("temp:data", {"value": 42})
    
    print("✓ Set 2 entries with 2s TTL")
    
    # Immediate retrieval
    session = await cache.get("session:abc")
    print(f"✓ Retrieved immediately: {session}")
    
    # Wait 1 second
    print("\n2. Waiting 1 second...")
    await asyncio.sleep(1)
    
    session = await cache.get("session:abc")
    print(f"✓ Retrieved after 1s: {session}")
    
    # Wait another 1.5 seconds (total 2.5s)
    print("\n3. Waiting another 1.5 seconds (total 2.5s)...")
    await asyncio.sleep(1.5)
    
    session = await cache.get("session:abc")
    print(f"✓ Retrieved after 2.5s: {session} (expired)")
    
    stats = cache.get_stats()
    print(f"\n✓ Cache statistics:")
    print(f"  Hits: {stats['hits']}")
    print(f"  Misses: {stats['misses']}")
    print(f"  Expired entries cleaned: {stats.get('expired_cleaned', 0)}")


async def cache_performance_example():
    """Demonstrate cache performance benefits."""
    
    print("\n" + "=" * 70)
    print("Cache Performance Example")
    print("=" * 70)
    
    cache = InMemoryCache(maxsize=1000)
    
    # Simulate expensive operation
    async def expensive_operation(key: str):
        """Simulate a slow database query or API call."""
        await asyncio.sleep(0.1)  # 100ms delay
        return {"key": key, "data": f"expensive_result_{key}"}
    
    # 1. Without cache
    print("\n1. Without cache (10 operations):")
    start = time.time()
    
    for i in range(10):
        result = await expensive_operation(f"item_{i}")
    
    uncached_time = time.time() - start
    print(f"✓ Time: {uncached_time:.3f}s")
    
    # 2. With cache (first pass - cache miss)
    print("\n2. With cache - first pass (cache miss):")
    start = time.time()
    
    for i in range(10):
        key = f"item_{i}"
        result = await cache.get(key)
        if result is None:
            result = await expensive_operation(key)
            await cache.set(key, result)
    
    first_pass_time = time.time() - start
    print(f"✓ Time: {first_pass_time:.3f}s")
    
    # 3. With cache (second pass - cache hit)
    print("\n3. With cache - second pass (cache hit):")
    start = time.time()
    
    for i in range(10):
        key = f"item_{i}"
        result = await cache.get(key)
        if result is None:
            result = await expensive_operation(key)
            await cache.set(key, result)
    
    cached_time = time.time() - start
    print(f"✓ Time: {cached_time:.3f}s")
    
    # Show improvement
    speedup = uncached_time / cached_time if cached_time > 0 else 0
    print(f"\n✓ Performance improvement:")
    print(f"  Uncached: {uncached_time:.3f}s")
    print(f"  Cached: {cached_time:.3f}s")
    print(f"  Speedup: {speedup:.1f}x faster")
    
    # Show cache stats
    stats = cache.get_stats()
    print(f"\n✓ Cache statistics:")
    print(f"  Total requests: {stats['hits'] + stats['misses']}")
    print(f"  Cache hits: {stats['hits']}")
    print(f"  Cache misses: {stats['misses']}")
    print(f"  Hit rate: {stats['hit_rate']:.1f}%")


async def cache_patterns_example():
    """Demonstrate common caching patterns."""
    
    print("\n" + "=" * 70)
    print("Cache Patterns Example")
    print("=" * 70)
    
    cache = InMemoryCache(maxsize=100)
    
    # 1. Cache-aside pattern
    print("\n1. Cache-aside pattern:")
    
    async def get_user(user_id: str):
        """Get user with cache-aside pattern."""
        cache_key = f"user:{user_id}"
        
        # Try cache first
        user = await cache.get(cache_key)
        if user is not None:
            print(f"  ✓ Cache hit for {cache_key}")
            return user
        
        # Cache miss - fetch from "database"
        print(f"  ✗ Cache miss for {cache_key} - fetching from DB")
        user = {"id": user_id, "name": f"User {user_id}", "email": f"user{user_id}@example.com"}
        
        # Store in cache
        await cache.set(cache_key, user)
        return user
    
    # First call - cache miss
    user1 = await get_user("123")
    print(f"  Result: {user1}")
    
    # Second call - cache hit
    user2 = await get_user("123")
    print(f"  Result: {user2}")
    
    # 2. Write-through pattern
    print("\n2. Write-through pattern:")
    
    async def update_user(user_id: str, data: dict):
        """Update user with write-through pattern."""
        cache_key = f"user:{user_id}"
        
        # Update "database"
        print(f"  ✓ Updating database for {cache_key}")
        
        # Update cache immediately
        await cache.set(cache_key, data)
        print(f"  ✓ Updated cache for {cache_key}")
    
    await update_user("123", {"id": "123", "name": "Alice Updated", "email": "alice@example.com"})
    
    # Verify cache was updated
    user = await cache.get("user:123")
    print(f"  ✓ Cached user: {user}")
    
    # 3. Cache invalidation
    print("\n3. Cache invalidation:")
    
    async def delete_user(user_id: str):
        """Delete user and invalidate cache."""
        cache_key = f"user:{user_id}"
        
        # Delete from "database"
        print(f"  ✓ Deleting from database: {cache_key}")
        
        # Invalidate cache
        await cache.delete(cache_key)
        print(f"  ✓ Invalidated cache: {cache_key}")
    
    await delete_user("123")
    
    # Verify cache was invalidated
    user = await cache.get("user:123")
    print(f"  ✓ Cache after deletion: {user}")
    
    print("\n" + "=" * 70)
    print("All caching examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(basic_cache_example())
    asyncio.run(ttl_cache_example())
    asyncio.run(cache_performance_example())
    asyncio.run(cache_patterns_example())
