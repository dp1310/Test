"""Examples module"""
# This directory contains usage examples for the CMP framework
