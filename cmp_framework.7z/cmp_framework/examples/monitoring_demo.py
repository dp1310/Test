"""
Example demonstrating the enhanced monitoring and observability features.

This example shows how to use:
- Structured logging with context propagation
- Health checks for liveness/readiness probes
- Distributed tracing with OpenTelemetry
- CPU and memory profiling
"""

import asyncio
from datetime import datetime

from cmp.monitoring import (
    # Logging
    configure_logging,
    get_logger,
    set_context,
    clear_context,
    # Health Checks
    HealthCheck,
    check_service_url,
    # Tracing
    configure_tracing,
    trace_function,
    trace_workflow,
    add_span_attribute,
    add_span_event,
    # Profiling
    profile_cpu,
    profile_memory,
    CPUProfiler,
    MemoryProfiler,
)


async def demonstrate_structured_logging():
    """Demonstrate structured logging features."""
    print("\n=== Structured Logging Demo ===\n")
    
    # Configure logging (JSON format for production, text for development)
    configure_logging(level="INFO", format_type="text")
    
    logger = get_logger(__name__)
    
    # Basic logging
    logger.info("Application started", version="1.0.0", environment="development")
    logger.debug("Debug message", detail="This won't show at INFO level")
    
    # Logging with context
    set_context(
        context_id="ctx-12345",
        workflow_id="wf-67890",
        tenant_id="acme_corp"
    )
    
    logger.info("Processing context", action="validate")
    logger.info("Context validated successfully", duration_ms=15.3)
    
    # Logging with sensitive data (automatically masked)
    logger.info(
        "User authenticated",
        user_id="user123",
        password="secret123",  # Will be masked
        api_key="sk-1234567890"  # Will be masked
    )
    
    # Error logging
    try:
        raise ValueError("Example error for demonstration")
    except Exception as e:
        logger.exception("An error occurred", error_type="ValueError")
    
    # Clear context
    clear_context()
    logger.info("Context cleared")
    
    print("\n✓ Structured logging demonstration complete")


async def demonstrate_health_checks():
    """Demonstrate health check features."""
    print("\n=== Health Checks Demo ===\n")
    
    # Create health check system
    health = HealthCheck()
    
    # Add custom check for a service
    async def check_database():
        """Simulate database health check."""
        from cmp.monitoring.health_checks import HealthCheckResult, HealthStatus
        
        # Simulate check
        await asyncio.sleep(0.01)
        
        return HealthCheckResult(
            name="database",
            status=HealthStatus.HEALTHY,
            message="Database connection pool healthy",
            timestamp=datetime.utcnow().isoformat(),
            duration_ms=10.5,
            metadata={"connections": 5, "max_connections": 20}
        )
    
    health.add_check("database", check_database)
    
    # Check liveness (is process running?)
    is_alive = await health.is_live()
    print(f"✓ Liveness probe: {'PASS' if is_alive else 'FAIL'}")
    
    # Check readiness (can accept traffic?)
    is_ready = await health.is_ready()
    print(f"✓ Readiness probe: {'PASS' if is_ready else 'FAIL'}")
    
    # Get detailed health status
    status = await health.get_health()
    print(f"\n✓ Overall status: {status.status.value}")
    print(f"✓ Uptime: {status.uptime_seconds:.2f} seconds")
    print(f"\n✓ Individual checks:")
    for check in status.checks:
        print(f"  - {check.name}: {check.status.value} - {check.message}")
        if check.metadata:
            for key, value in check.metadata.items():
                print(f"    {key}: {value}")
    
    # Check external service (example with OPA)
    print("\n✓ Checking external services:")
    opa_result = await check_service_url(
        "opa",
        "http://localhost:8181/health",
        timeout=2.0
    )
    print(f"  - OPA: {opa_result.status.value} - {opa_result.message}")


async def demonstrate_distributed_tracing():
    """Demonstrate distributed tracing features."""
    print("\n=== Distributed Tracing Demo ===\n")
    
    # Configure tracing (set enabled=False if Jaeger not running)
    configure_tracing(
        service_name="cmp-framework-demo",
        jaeger_endpoint=None,  # Set to "http://localhost:14268/api/traces" if Jaeger running
        enabled=False  # Set to True if Jaeger running
    )
    
    # Example 1: Trace a function
    @trace_function(span_name="process_data", attributes={"version": "1.0"})
    async def process_data(data_id: str):
        """Process some data."""
        add_span_attribute("data.id", data_id)
        add_span_event("processing_started")
        
        await asyncio.sleep(0.05)  # Simulate work
        
        add_span_event("processing_completed", {"records": 100})
        return {"status": "success", "records": 100}
    
    # Example 2: Trace a workflow
    @trace_workflow("data_pipeline")
    async def execute_workflow(workflow_id: str):
        """Execute a data pipeline workflow."""
        add_span_attribute("workflow.id", workflow_id)
        
        # Step 1: Fetch data
        add_span_event("fetch_data_started")
        await asyncio.sleep(0.02)
        add_span_event("fetch_data_completed")
        
        # Step 2: Process data
        result = await process_data("data-123")
        
        # Step 3: Store results
        add_span_event("store_results_started")
        await asyncio.sleep(0.02)
        add_span_event("store_results_completed")
        
        return result
    
    # Execute traced workflow
    print("✓ Executing traced workflow...")
    result = await execute_workflow("wf-demo-001")
    print(f"✓ Workflow completed: {result}")
    
    print("\n✓ Distributed tracing demonstration complete")
    print("  (Traces would be visible in Jaeger UI if enabled)")


async def demonstrate_profiling():
    """Demonstrate profiling features."""
    print("\n=== Profiling Demo ===\n")
    
    # Example 1: CPU profiling with decorator
    @profile_cpu(limit=10)
    async def cpu_intensive_task():
        """Simulate CPU-intensive task."""
        result = 0
        for i in range(100000):
            result += i ** 2
        return result
    
    # Example 2: Memory profiling with decorator
    @profile_memory(top_n=5)
    async def memory_intensive_task():
        """Simulate memory-intensive task."""
        data = []
        for i in range(10000):
            data.append({"id": i, "value": f"item_{i}" * 10})
        return len(data)
    
    # Example 3: Manual profiling
    async def manual_profiling_example():
        """Example of manual profiling."""
        # CPU profiling
        cpu_profiler = CPUProfiler()
        with cpu_profiler:
            # Do CPU-intensive work
            result = sum(i ** 2 for i in range(50000))
        
        print("\n=== Manual CPU Profile ===")
        print(cpu_profiler.get_stats(limit=5))
        
        # Memory profiling
        memory_profiler = MemoryProfiler()
        with memory_profiler:
            # Do memory-intensive work
            data = [{"id": i} for i in range(50000)]
        
        print("\n=== Manual Memory Profile ===")
        stats = memory_profiler.get_stats(top_n=3)
        print(f"Peak memory: {stats.get('peak_mb', 0):.2f} MB")
    
    print("✓ Running CPU-intensive task with profiling...")
    await cpu_intensive_task()
    
    print("\n✓ Running memory-intensive task with profiling...")
    await memory_intensive_task()
    
    print("\n✓ Running manual profiling example...")
    await manual_profiling_example()
    
    print("\n✓ Profiling demonstration complete")


async def demonstrate_integrated_monitoring():
    """Demonstrate integrated monitoring in a realistic scenario."""
    print("\n=== Integrated Monitoring Demo ===\n")
    
    # Configure all monitoring
    configure_logging(level="INFO", format_type="text")
    configure_tracing(service_name="cmp-demo", enabled=False)
    
    logger = get_logger(__name__)
    health = HealthCheck()
    
    # Simulate a workflow with full monitoring
    @trace_workflow("user_onboarding")
    async def onboard_user(user_id: str, tenant_id: str):
        """Onboard a new user with full monitoring."""
        # Set logging context
        set_context(
            context_id=f"ctx-{user_id}",
            workflow_id="wf-onboarding",
            tenant_id=tenant_id
        )
        
        logger.info("Starting user onboarding", user_id=user_id)
        add_span_attribute("user.id", user_id)
        add_span_attribute("tenant.id", tenant_id)
        
        # Step 1: Validate user data
        add_span_event("validation_started")
        logger.info("Validating user data")
        await asyncio.sleep(0.02)
        add_span_event("validation_completed", {"valid": True})
        logger.info("User data validated")
        
        # Step 2: Create user account
        add_span_event("account_creation_started")
        logger.info("Creating user account")
        await asyncio.sleep(0.03)
        add_span_event("account_creation_completed")
        logger.info("User account created", account_id=f"acc-{user_id}")
        
        # Step 3: Send welcome email
        add_span_event("email_sending_started")
        logger.info("Sending welcome email")
        await asyncio.sleep(0.01)
        add_span_event("email_sending_completed")
        logger.info("Welcome email sent")
        
        logger.info("User onboarding completed successfully", user_id=user_id)
        
        # Clear context
        clear_context()
        
        return {"status": "success", "user_id": user_id}
    
    # Execute monitored workflow
    print("✓ Executing fully monitored workflow...")
    result = await onboard_user("user-12345", "acme_corp")
    print(f"✓ Workflow result: {result}")
    
    # Check health after workflow
    print("\n✓ Checking system health...")
    status = await health.get_health()
    print(f"✓ System status: {status.status.value}")
    
    print("\n✓ Integrated monitoring demonstration complete")


async def main():
    """Run all demonstrations."""
    print("=" * 60)
    print("CMP Framework - Enhanced Monitoring & Observability Demo")
    print("=" * 60)
    
    # Structured Logging
    await demonstrate_structured_logging()
    
    # Health Checks
    await demonstrate_health_checks()
    
    # Distributed Tracing
    await demonstrate_distributed_tracing()
    
    # Profiling
    await demonstrate_profiling()
    
    # Integrated Example
    await demonstrate_integrated_monitoring()
    
    print("\n" + "=" * 60)
    print("All monitoring demonstrations completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
