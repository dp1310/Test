# CMP Framework Examples Summary

This document provides an overview of all available examples and what features they demonstrate.

## ✅ Working Examples

### 1. **basic_usage.py**
Demonstrates basic CMP operations:
- Creating contexts
- Retrieving contexts
- Updating contexts
- Searching contexts
- Deleting contexts
- Event notifications

**Run:** `python -m examples.basic_usage`

### 2. **end_to_end_example.py**
Complete workflow demonstration:
- Context creation and management
- Multi-agent workflows (validation → enrichment → processing)
- Policy enforcement
- Monitoring and observability
- Multi-tenant isolation
- Health checks and structured logging

**Run:** `python -m examples.end_to_end_example`

### 3. **workflow_example.py**
Advanced workflow patterns:
- **Chaining**: Sequential agent execution
- **Fan-out/Fan-in**: Parallel processing with aggregation
- **Evolution**: Progressive context enrichment

**Run:** `python -m examples.workflow_example`

### 4. **monitoring_demo.py**
Comprehensive monitoring features:
- Structured logging with context
- Health checks (liveness, readiness, detailed)
- Distributed tracing (Jaeger integration)
- CPU and memory profiling
- Integrated monitoring workflows

**Run:** `python -m examples.monitoring_demo`

### 5. **performance_example.py**
Performance optimization techniques:
- In-memory caching with statistics
- Async worker pools
- Batch processing
- Sequential vs parallel comparison
- Performance metrics

**Run:** `python -m examples.performance_example`

### 6. **plugin_example.py**
Plugin system demonstration:
- Creating custom plugins
- Plugin lifecycle (init, start, stop)
- Hook system for events
- Plugin discovery
- Multiple plugin coordination

**Run:** `python -m examples.plugin_example`

### 7. **registry_demo.py**
Registry system features:
- Configuration management
- Schema registry with validation
- Policy registry with Rego
- Knowledge registry
- Versioning and deprecation

**Run:** `python -m examples.registry_demo`

### 8. **workflow_patterns_example.py**
Advanced orchestration patterns:
- Conditional workflows (if/then/else)
- Switch workflows (case statements)
- Saga pattern (distributed transactions with compensation)
- Retry policies with exponential backoff
- Circuit breaker pattern

**Run:** `python -m examples.workflow_patterns_example`

### 9. **dependency_injection_example.py**
Dependency injection features:
- Service container usage
- Context injection
- Service access patterns
- Agent chaining with DI

**Run:** `python -m examples.dependency_injection_example`

### 10. **caching_example.py**
Caching strategies and patterns:
- In-memory cache operations
- TTL (Time-To-Live) caching
- Performance benchmarking
- Cache-aside pattern
- Write-through pattern
- Cache invalidation

**Run:** `python -m examples.caching_example`

### 11. **async_helpers_example.py**
Async utility functions and patterns:
- AsyncLock for thread-safe operations
- Gather dict for concurrent task execution
- Async map and filter operations
- Error handling in async code
- Batch processing patterns
- Retry with exponential backoff

**Run:** `python -m examples.async_helpers_example`

### 12. **functional_utils_example.py**
Functional programming utilities:
- Function composition (pipe and compose)
- Currying and partial application
- Identity and const functions
- Data processing pipelines
- Immutable updates
- Higher-order functions

**Run:** `python -m examples.functional_utils_example`

## 🚧 Examples Requiring External Dependencies

### 13. **graphql_example.py**
GraphQL API integration (requires `gql` library)

### 14. **websocket_example.py**
WebSocket real-time communication (requires running server)

## 📋 Feature Coverage Matrix

| Feature | Example(s) |
|---------|-----------|
| Context Management | basic_usage, end_to_end_example |
| Multi-Agent Workflows | end_to_end_example, workflow_example |
| Workflow Patterns | workflow_patterns_example |
| Monitoring & Logging | monitoring_demo, end_to_end_example |
| Health Checks | monitoring_demo, end_to_end_example |
| Profiling | monitoring_demo |
| Caching | caching_example, performance_example |
| Performance Optimization | performance_example |
| Plugin System | plugin_example |
| Schema Registry | registry_demo |
| Policy Registry | registry_demo |
| Knowledge Registry | registry_demo |
| Configuration Management | registry_demo |
| Dependency Injection | dependency_injection_example |
| Multi-Tenancy | end_to_end_example |
| Event System | basic_usage, plugin_example |
| Saga Pattern | workflow_patterns_example |
| Circuit Breaker | workflow_patterns_example |
| Retry Policies | workflow_patterns_example |
| Conditional Workflows | workflow_patterns_example |

## 🎯 Quick Start Guide

### For Beginners
Start with these examples in order:
1. `basic_usage.py` - Learn the fundamentals
2. `workflow_example.py` - Understand workflow patterns
3. `end_to_end_example.py` - See a complete application

### For Performance Optimization
1. `caching_example.py` - Learn caching strategies
2. `performance_example.py` - Understand async patterns
3. `monitoring_demo.py` - Profile and optimize

### For Advanced Patterns
1. `workflow_patterns_example.py` - Master orchestration
2. `plugin_example.py` - Extend the framework
3. `registry_demo.py` - Manage schemas and policies

## 🔧 Common Patterns

### Creating a Context
```python
from cmp import CMP

cmp = CMP(tenant_id="my_tenant")
ctx_id = await cmp.context()\
    .with_data({"key": "value"})\
    .with_schema("my_schema")\
    .create()
```

### Creating an Agent
```python
from cmp.sdk.agent import Agent
from cmp.core.models import Context

class MyAgent(Agent):
    async def process(self, context: Context) -> Context:
        # Process the context
        context.data["processed"] = True
        return context
```

### Running a Workflow
```python
results = []
async for result in cmp.workflow("my_workflow")\
    .with_context(ctx_id)\
    .with_agents([Agent1(), Agent2(), Agent3()])\
    .execute():
    results.append(result)
```

### Using Cache
```python
from cmp.core.cache import InMemoryCache

cache = InMemoryCache(maxsize=1000, ttl=300)
await cache.set("key", {"data": "value"})
value = await cache.get("key")
```

### Health Checks
```python
from cmp.monitoring import HealthCheck

health = HealthCheck()
is_alive = await health.is_live()
is_ready = await health.is_ready()
status = await health.get_health()
```

## 📚 Additional Resources

- **API Documentation**: See individual module docstrings
- **Architecture**: Check `README.md` in the root directory
- **Contributing**: See `CONTRIBUTING.md` for guidelines

## 🐛 Troubleshooting

### Import Errors
Make sure you're running from the `cmp_framework` directory:
```bash
cd cmp_framework
python -m examples.basic_usage
```

### Module Not Found
Install required dependencies:
```bash
pip install -r requirements.txt
```

### Windows Path Issues
The framework handles Windows path separators automatically. Colons (`:`) in keys are converted to underscores (`_`) for file storage.

## 💡 Tips

1. **Start Simple**: Begin with `basic_usage.py` to understand core concepts
2. **Use Type Hints**: All examples use type hints for better IDE support
3. **Check Logs**: Enable debug logging to see what's happening
4. **Read Docstrings**: Each module has comprehensive documentation
5. **Experiment**: Modify examples to learn how things work

## 🎓 Learning Path

```
Beginner → Intermediate → Advanced
   ↓            ↓            ↓
basic_usage  workflow   patterns
   ↓         caching    plugins
end_to_end  performance registries
```

Happy coding with CMP Framework! 🚀
