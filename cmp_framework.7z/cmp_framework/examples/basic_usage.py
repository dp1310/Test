"""
Example: Basic context operations using CMP framework.

This example demonstrates:
- Creating contexts with schema validation
- Retrieving contexts
- Updating context data
- Subscribing to context events
- Searching for contexts
"""

import asyncio
from cmp.core.models import ContextEvent
from cmp.services.context_service import ContextService
from cmp.storage.context_store import InMemoryContextStore
from cmp.core.observable import ContextObservable


async def event_logger(event: ContextEvent) -> None:
    """Log context events"""
    print(f"[EVENT] {event.event_type}: {event.context_id} at {event.timestamp}")


async def main():
    """Run example"""
    
    # Initialize components
    store = InMemoryContextStore()
    observable = ContextObservable()
    
    # Subscribe to events
    observable.subscribe(event_logger)
    
    # Create service
    service = ContextService(
        store=store,
        schema_registry=None,  # Mock
        policy_service=None,  # Mock
        observable=observable
    )
    
    print("=== CMP Framework Example ===\n")
    
    # 1. Create a context
    print("1. Creating context...")
    result = await service.create(
        data={"user_id": "user_123", "action": "login", "timestamp": "2025-11-25T01:00:00Z"},
        schema_name="user_event",
        tenant_id="acme_corp",
        source="web_app"
    )
    
    if result.is_ok():
        context_id = result.unwrap()
        print(f"   ✓ Created context: {context_id}\n")
    else:
        print(f"   ✗ Error: {result.error}\n")
        return
    
    # 2. Retrieve context
    print("2. Retrieving context...")
    result = await service.get(context_id)
    
    if result.is_ok():
        context = result.unwrap()
        print(f"   ✓ Retrieved context:")
        print(f"     - ID: {context.id}")
        print(f"     - Tenant: {context.tenant_id}")
        print(f"     - Data: {context.data}\n")
    else:
        print(f"   ✗ Error: {result.error}\n")
    
    # 3. Update context
    print("3. Updating context...")
    result = await service.update(
        context_id=context_id,
        data_updates={"status": "completed", "duration_ms": 1250}
    )
    
    if result.is_ok():
        updated_context = result.unwrap()
        print(f"   ✓ Updated context:")
        print(f"     - Data: {updated_context.data}\n")
    else:
        print(f"   ✗ Error: {result.error}\n")
    
    # 4. Create another context
    print("4. Creating second context...")
    result2 = await service.create(
        data={"user_id": "user_456", "action": "logout"},
        schema_name="user_event",
        tenant_id="acme_corp"
    )
    
    if result2.is_ok():
        context_id_2 = result2.unwrap()
        print(f"   ✓ Created context: {context_id_2}\n")
    
    # 5. Search contexts
    print("5. Searching contexts...")
    count = 0
    async for ctx in service.search(
        query={"action": "login"},
        tenant_id="acme_corp",
        limit=10
    ):
        count += 1
        print(f"   ✓ Found context: {ctx.id} - {ctx.data}")
    print(f"   Total found: {count}\n")
    
    # 6. Delete context
    print("6. Deleting context...")
    result = await service.delete(context_id)
    
    if result.is_ok():
        deleted = result.unwrap()
        print(f"   ✓ Deleted: {deleted}\n")
    else:
        print(f"   ✗ Error: {result.error}\n")
    
    print("=== Example Complete ===")


if __name__ == "__main__":
    asyncio.run(main())
