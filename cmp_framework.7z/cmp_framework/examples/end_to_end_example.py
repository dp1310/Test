"""
End-to-End Example - Complete CMP Framework usage.

This example demonstrates a complete workflow using multiple features:
- Context creation and management
- Multi-agent workflows
- Policy enforcement
- Monitoring and observability
- Performance optimization
"""

import asyncio
from cmp import CMP
from cmp.sdk.agent import Agent
from cmp.core.models import Context
from cmp.monitoring import configure_logging, get_logger


# Custom agents
class DataValidationAgent(Agent):
    """Validates incoming data."""
    
    async def process(self, context: Context) -> Context:
        logger = get_logger(__name__)
        logger.info(f"Validating context {context.id}")
        
        # Validation logic
        if "amount" in context.data and context.data["amount"] < 0:
            raise ValueError("Amount cannot be negative")
        
        context.data["validated"] = True
        return context


class EnrichmentAgent(Agent):
    """Enriches context with additional data."""
    
    async def process(self, context: Context) -> Context:
        logger = get_logger(__name__)
        logger.info(f"Enriching context {context.id}")
        
        # Simulate enrichment
        context.data["enriched_at"] = "2024-01-01T00:00:00Z"
        context.data["risk_score"] = 0.3
        context.data["category"] = "standard"
        
        return context


class ProcessingAgent(Agent):
    """Processes the enriched context."""
    
    async def process(self, context: Context) -> Context:
        logger = get_logger(__name__)
        logger.info(f"Processing context {context.id}")
        
        # Processing logic
        context.data["processed"] = True
        context.data["status"] = "completed"
        
        return context


async def end_to_end_example():
    """Complete end-to-end example."""
    
    print("=" * 70)
    print("CMP Framework - End-to-End Example")
    print("=" * 70)
    
    # Configure logging
    configure_logging(level="INFO", format_type="text")
    logger = get_logger(__name__)
    
    # Initialize CMP
    cmp = CMP(tenant_id="acme_corp")
    
    # 1. Create context
    print("\n1. Creating context...")
    ctx_id = await cmp.context()\
        .with_data({
            "transaction_id": "TXN-12345",
            "user_id": "user_789",
            "amount": 2500.00,
            "currency": "USD",
            "items": [
                {"id": "item1", "price": 1500.00},
                {"id": "item2", "price": 1000.00}
            ]
        })\
        .with_schema("transaction")\
        .create()
    
    print(f"✓ Created context: {ctx_id}")
    
    # 2. Execute multi-agent workflow
    print("\n2. Executing multi-agent workflow...")
    
    results = []
    async for result in cmp.workflow("transaction_processing")\
        .with_context(ctx_id)\
        .with_agents([
            DataValidationAgent(),
            EnrichmentAgent(),
            ProcessingAgent()
        ])\
        .execute():
        
        results.append(result)
        print(f"  ✓ Step {len(results)}: {result.data.get('status', 'in_progress')}")
    
    # 3. Retrieve final context
    print("\n3. Retrieving final context...")
    result = await cmp.services.get_service('context_service').get(ctx_id)
    final_context = result.unwrap()
    
    print(f"✓ Final context state:")
    print(f"  Validated: {final_context.data.get('validated')}")
    print(f"  Risk score: {final_context.data.get('risk_score')}")
    print(f"  Category: {final_context.data.get('category')}")
    print(f"  Status: {final_context.data.get('status')}")
    
    # 4. Search contexts
    print("\n4. Searching contexts...")
    service = cmp.services.get_service('context_service')
    
    count = 0
    async for ctx in service.search(
        query={"status": "completed"},
        tenant_id="acme_corp",
        limit=10
    ):
        count += 1
    
    print(f"✓ Found {count} completed transactions")
    
    # 5. Update context
    print("\n5. Updating context...")
    update_result = await service.update(
        ctx_id,
        {"notes": "Processed successfully", "reviewed": True}
    )
    
    if update_result.is_ok():
        print(f"✓ Context updated")
    
    print("\n" + "=" * 70)
    print("End-to-end example completed!")
    print("=" * 70)


async def multi_tenant_example():
    """Demonstrate multi-tenant isolation."""
    
    print("\n" + "=" * 70)
    print("Multi-Tenant Example")
    print("=" * 70)
    
    # Create contexts for different tenants
    tenants = ["tenant_a", "tenant_b", "tenant_c"]
    
    for tenant in tenants:
        print(f"\n{tenant}:")
        cmp = CMP(tenant_id=tenant)
        
        # Create contexts
        for i in range(3):
            ctx_id = await cmp.context()\
                .with_data({"index": i, "tenant": tenant})\
                .create()
            print(f"  ✓ Created context: {ctx_id}")
    
    # Verify isolation
    print("\n\nVerifying tenant isolation:")
    for tenant in tenants:
        cmp = CMP(tenant_id=tenant)
        service = cmp.services.get_service('context_service')
        
        count = 0
        async for ctx in service.search(
            query={},
            tenant_id=tenant,
            limit=100
        ):
            count += 1
        
        print(f"  {tenant}: {count} contexts (isolated)")


async def monitoring_example():
    """Demonstrate monitoring and observability."""
    
    print("\n" + "=" * 70)
    print("Monitoring & Observability Example")
    print("=" * 70)
    
    from cmp.monitoring import HealthCheck
    
    # Health checks
    print("\n1. Health checks:")
    health = HealthCheck()
    
    # Liveness check
    is_alive = await health.is_live()
    print(f"  Liveness: {'✓ OK' if is_alive else '✗ FAIL'}")
    
    # Readiness check
    is_ready = await health.is_ready()
    print(f"  Readiness: {'✓ OK' if is_ready else '✗ FAIL'}")
    
    # Detailed health
    health_status = await health.get_health()
    print(f"\n  Detailed health:")
    print(f"    Status: {health_status.status}")
    print(f"    Uptime: {health_status.uptime_seconds:.1f}s")
    
    # Show individual checks
    for check in health_status.checks:
        print(f"    {check.name}: {check.status.value} - {check.message}")
    
    # 2. Structured logging
    print("\n2. Structured logging:")
    logger = get_logger(__name__)
    
    logger.info("Processing transaction", extra={
        "transaction_id": "TXN-123",
        "amount": 1000.00,
        "user_id": "user_456"
    })
    
    logger.warning("High-value transaction detected", extra={
        "transaction_id": "TXN-124",
        "amount": 50000.00,
        "risk_level": "high"
    })
    
    print("  ✓ Logs written with structured data")


if __name__ == "__main__":
    # Run all examples
    asyncio.run(end_to_end_example())
    asyncio.run(multi_tenant_example())
    asyncio.run(monitoring_example())
