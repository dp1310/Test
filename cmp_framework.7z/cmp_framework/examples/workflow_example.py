"""
Example: Complete workflow with agents and orchestration.

This example demonstrates:
- Creating custom agents with @context decorator
- Executing workflows with different strategies
- Chaining, Fan-out/Fan-in, and Evolution patterns
"""

import asyncio
from cmp import CMP, Agent
from cmp.di import context
from cmp.core.models import Context


# Define custom agents

class DataEnrichmentAgent(Agent):
    """Agent that enriches context with additional data"""
    
    async def process(self, ctx: Context) -> Context:
        """Add enrichment data"""
        print(f"[{self.agent_id}] Enriching context...")
        
        enriched_data = {
            "enriched": True,
            "enrichment_timestamp": "2025-11-25T01:20:00Z",
            "source": "enrichment_agent"
        }
        
        return ctx.with_data(**enriched_data)


class ValidationAgent(Agent):
    """Agent that validates context data"""
    
    async def process(self, ctx: Context) -> Context:
        """Validate and add validation status"""
        print(f"[{self.agent_id}] Validating context...")
        
        # Simple validation
        is_valid = "user_id" in ctx.data
        
        return ctx.with_data(
            validated=True,
            validation_status="valid" if is_valid else "invalid"
        )


class TransformationAgent(Agent):
    """Agent that transforms context data"""
    
    async def process(self, ctx: Context) -> Context:
        """Transform data"""
        print(f"[{self.agent_id}] Transforming context...")
        
        # Example transformation
        transformed_data = {
            "transformed": True,
            "original_keys": list(ctx.data.keys()),
            "transformation_applied": "uppercase_keys"
        }
        
        return ctx.with_data(**transformed_data)


async def main():
    """Run complete workflow example"""
    
    print("=== CMP Framework - Complete Workflow Example ===\n")
    
    # Initialize CMP
    cmp = CMP(tenant_id="acme_corp")
    
    # Create initial context
    print("1. Creating initial context...")
    context_id = await cmp.context() \
        .with_data({
            "user_id": "user_123",
            "action": "process_data",
            "timestamp": "2025-11-25T01:20:00Z"
        }) \
        .with_schema("data_processing") \
        .with_metadata(source="api", version="1.0") \
        .create()
    
    print(f"   ✓ Created context: {context_id}\n")
    
    # Define agents
    enrichment_agent = DataEnrichmentAgent("enrichment_1")
    validation_agent = ValidationAgent("validation_1")
    transformation_agent = TransformationAgent("transform_1")
    
    # Example 1: Chaining Strategy (Sequential)
    print("2. Executing CHAINING workflow...")
    print("   (Sequential: Enrichment → Validation → Transformation)\n")
    
    step = 1
    async for result in cmp.workflow("data_processing_chain") \
            .with_context(context_id) \
            .with_agents([enrichment_agent, validation_agent, transformation_agent]) \
            .execute():
        print(f"   Step {step} completed:")
        print(f"   - Keys: {list(result.data.keys())}")
        print(f"   - Data: {result.data}\n")
        step += 1
    
    # Example 2: Fan-out/Fan-in Strategy (Parallel)
    print("\n3. Executing FAN-OUT/FAN-IN workflow...")
    print("   (Parallel: All agents process simultaneously, then aggregate)\n")
    
    # Create new context for parallel processing
    context_id_2 = await cmp.context() \
        .with_data({
            "user_id": "user_456",
            "action": "parallel_process"
        }) \
        .with_schema("parallel_processing") \
        .create()
    
    async for result in cmp.workflow("parallel_processing") \
            .with_context(context_id_2) \
            .with_agents([enrichment_agent, validation_agent, transformation_agent]) \
            .execute():
        print(f"   Aggregated result:")
        print(f"   - Keys: {list(result.data.keys())}")
        print(f"   - Data: {result.data}\n")
    
    # Example 3: Evolution Strategy (Progressive enrichment)
    print("\n4. Executing EVOLUTION workflow...")
    print("   (Progressive: Each agent adds to context without replacing)\n")
    
    context_id_3 = await cmp.context() \
        .with_data({
            "user_id": "user_789",
            "action": "evolve_data"
        }) \
        .with_schema("evolution_processing") \
        .create()
    
    step = 1
    async for result in cmp.workflow("evolution_processing") \
            .with_context(context_id_3) \
            .with_agents([enrichment_agent, validation_agent, transformation_agent]) \
            .execute():
        print(f"   Evolution step {step}:")
        print(f"   - Total keys: {len(result.data)}")
        print(f"   - Keys: {list(result.data.keys())}\n")
        step += 1
    
    print("=== Example Complete ===")


if __name__ == "__main__":
    asyncio.run(main())
