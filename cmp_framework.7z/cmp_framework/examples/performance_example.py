"""
Performance Optimization Example - Caching and async worker pool.

Demonstrates the performance features including caching and worker pools.
"""

import asyncio
import time
from cmp import CMP
from cmp.core.cache import CacheManager
from cmp.core.async_pool import AsyncWorkerPool, BatchProcessor


async def caching_example():
    """Demonstrate caching for improved performance."""
    
    print("=" * 60)
    print("Caching Example")
    print("=" * 60)
    
    # 1. In-memory cache
    print("\n1. In-memory cache:")
    cache = CacheManager(backend="memory", maxsize=100, ttl=60)
    
    # Set values
    print("  Setting values...")
    await cache.set("user:123", {"name": "John", "email": "john@example.com"})
    await cache.set("user:456", {"name": "Jane", "email": "jane@example.com"})
    
    # Get values
    print("  Getting values...")
    user = await cache.get("user:123")
    print(f"  ✓ Retrieved: {user}")
    
    # Cache stats
    stats = cache.get_stats()
    print(f"\n  Cache statistics:")
    print(f"    Backend: {stats['backend']}")
    print(f"    Size: {stats['size']}/{stats['maxsize']}")
    print(f"    Hits: {stats['hits']}")
    print(f"    Misses: {stats['misses']}")
    print(f"    Hit rate: {stats['hit_rate']:.1f}%")
    
    # 2. Performance comparison
    print("\n2. Performance comparison (cached vs uncached):")
    
    cmp = CMP(tenant_id="demo")
    
    # Create some contexts
    context_ids = []
    for i in range(10):
        ctx_id = await cmp.context()\
            .with_data({"index": i, "value": f"data_{i}"})\
            .create()
        context_ids.append(ctx_id)
    
    # Uncached reads
    print("\n  Uncached reads:")
    start = time.perf_counter()
    for ctx_id in context_ids:
        result = await cmp.services.get_service('context_service').get(ctx_id)
    uncached_time = time.perf_counter() - start
    print(f"    Time: {uncached_time*1000:.2f}ms")
    
    # Cached reads (ContextService has caching enabled)
    print("\n  Cached reads (second pass):")
    start = time.perf_counter()
    for ctx_id in context_ids:
        result = await cmp.services.get_service('context_service').get(ctx_id)
    cached_time = time.perf_counter() - start
    print(f"    Time: {cached_time*1000:.2f}ms")
    
    speedup = uncached_time / cached_time if cached_time > 0 else 0
    print(f"\n  ✓ Speedup: {speedup:.1f}x faster with caching")


async def worker_pool_example():
    """Demonstrate async worker pool for concurrent processing."""
    
    print("\n" + "=" * 60)
    print("Async Worker Pool Example")
    print("=" * 60)
    
    # Simulated work function
    async def process_item(item: int) -> dict:
        """Simulate processing an item."""
        await asyncio.sleep(0.1)  # Simulate work
        return {
            "item": item,
            "result": item * 2,
            "processed_at": time.time()
        }
    
    # 1. Worker pool
    print("\n1. Processing with worker pool:")
    pool = AsyncWorkerPool(worker_count=4, max_queue_size=100)
    await pool.start()
    
    # Submit tasks
    print(f"  Submitting 20 tasks...")
    start = time.perf_counter()
    
    for i in range(20):
        await pool.submit(f"task-{i}", process_item, i)
    
    # Wait for completion
    results = await pool.wait_all()
    elapsed = time.perf_counter() - start
    
    print(f"  ✓ Completed {len(results)} tasks in {elapsed:.2f}s")
    print(f"  Average: {elapsed/len(results)*1000:.2f}ms per task")
    
    # Get stats
    stats = pool.get_stats()
    print(f"\n  Worker pool statistics:")
    print(f"    Workers: {stats['worker_count']}")
    print(f"    Tasks submitted: {stats['tasks_submitted']}")
    print(f"    Tasks completed: {stats['tasks_completed']}")
    print(f"    Success rate: {stats['success_rate']:.1f}%")
    
    await pool.stop()
    
    # 2. Batch processor
    print("\n2. Batch processing:")
    processor = BatchProcessor(process_item, worker_count=4)
    
    items = list(range(50))
    print(f"  Processing {len(items)} items...")
    
    start = time.perf_counter()
    results = await processor.process_batch(items)
    elapsed = time.perf_counter() - start
    
    successful = sum(1 for r in results if r.success)
    print(f"  ✓ Processed {successful}/{len(results)} items in {elapsed:.2f}s")
    print(f"  Throughput: {len(items)/elapsed:.1f} items/sec")


async def performance_comparison():
    """Compare sequential vs parallel processing."""
    
    print("\n" + "=" * 60)
    print("Sequential vs Parallel Comparison")
    print("=" * 60)
    
    async def slow_operation(item: int) -> int:
        """Simulated slow operation."""
        await asyncio.sleep(0.05)
        return item * 2
    
    items = list(range(100))
    
    # Sequential processing
    print("\n1. Sequential processing:")
    start = time.perf_counter()
    results = []
    for item in items:
        result = await slow_operation(item)
        results.append(result)
    sequential_time = time.perf_counter() - start
    print(f"  Time: {sequential_time:.2f}s")
    
    # Parallel processing with worker pool
    print("\n2. Parallel processing (8 workers):")
    pool = AsyncWorkerPool(worker_count=8, max_queue_size=200)
    await pool.start()
    
    start = time.perf_counter()
    for i, item in enumerate(items):
        await pool.submit(f"item-{i}", slow_operation, item)
    
    results = await pool.wait_all()
    parallel_time = time.perf_counter() - start
    print(f"  Time: {parallel_time:.2f}s")
    
    await pool.stop()
    
    # Comparison
    speedup = sequential_time / parallel_time
    print(f"\n  ✓ Speedup: {speedup:.1f}x faster with parallel processing")
    print(f"  Efficiency: {speedup/8*100:.1f}% (8 workers)")


if __name__ == "__main__":
    # Run examples
    asyncio.run(caching_example())
    asyncio.run(worker_pool_example())
    asyncio.run(performance_comparison())
