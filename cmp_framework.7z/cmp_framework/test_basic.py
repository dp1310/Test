"""Simple test to verify CMP framework can be imported and basic operations work."""

import sys
print(f"Python: {sys.version}")
print(f"Path: {sys.path[:3]}")

try:
    print("\n1. Importing CMP...")
    from cmp import CMP
    print("✓ CMP imported successfully")
    
    print("\n2. Creating CMP instance...")
    cmp = CMP(tenant_id="test")
    print("✓ CMP instance created")
    
    print("\n3. Testing context creation...")
    import asyncio
    
    async def test():
        ctx_id = await cmp.context().with_data({"test": "data"}).create()
        print(f"✓ Context created: {ctx_id}")
        return ctx_id
    
    ctx_id = asyncio.run(test())
    
    print("\n✅ All basic tests passed!")
    print(f"Created context: {ctx_id}")
    
except Exception as e:
    print(f"\n✗ Error: {e}")
    import traceback
    traceback.print_exc()
