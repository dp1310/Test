
import pytest
import asyncio
from datetime import datetime, timezone
from typing import Any

from cmp.core.result import Ok, Err
from cmp.registries.persistence import InMemoryBackend, PersistenceError
from cmp.registries.knowledge_registry import (
    KnowledgeRegistry,
    KnowledgeSource,
    KnowledgeType,
    KnowledgeItem,
    RegistryError
)

# ---------- Persistence Tests ----------

@pytest.mark.asyncio
async def test_in_memory_backend_crud():
    backend = InMemoryBackend()
    
    # Save
    await backend.save("key1", {"foo": "bar"}, metadata={"meta": "data"})
    
    # Load
    result = await backend.load("key1")
    assert result.is_ok()
    data = result.unwrap()
    assert data["key"] == "key1"
    assert data["value"] == {"foo": "bar"}
    assert data["metadata"] == {"meta": "data"}
    assert "saved_at" in data
    
    # List
    list_res = await backend.list()
    assert list_res.is_ok()
    assert "key1" in list_res.unwrap()
    
    # Delete
    del_res = await backend.delete("key1")
    assert del_res.is_ok()
    
    # Load deleted
    load_res = await backend.load("key1")
    assert load_res.is_err()
    assert isinstance(load_res.error, PersistenceError)

@pytest.mark.asyncio
async def test_in_memory_backend_search():
    backend = InMemoryBackend()
    await backend.save("user1", {"name": "Alice", "role": "admin"})
    await backend.save("user2", {"name": "Bob", "role": "user"})
    await backend.save("user3", {"name": "Charlie", "role": "user"})
    
    # Search for users
    search_res = await backend.search({"role": "user"})
    assert search_res.is_ok()
    results = search_res.unwrap()
    assert len(results) == 2
    names = sorted([r["value"]["name"] for r in results])
    assert names == ["Bob", "Charlie"]

# ---------- Knowledge Registry Tests ----------

@pytest.mark.asyncio
async def test_knowledge_registry_flow():
    backend = InMemoryBackend()
    registry = KnowledgeRegistry(backend=backend, cache_enabled=False)
    
    source = KnowledgeSource(
        source_id="docs_1",
        source_type=KnowledgeType.DOCUMENT,
        name="API Docs",
        description="Documentation for API",
        config={"url": "http://example.com"},
        metadata={"version": "1.0"},
        created_at=datetime.now(timezone.utc).isoformat()
    )
    
    # Register
    reg_res = await registry.register_knowledge(source)
    assert reg_res.is_ok()
    
    # Get
    get_res = await registry.get_source("docs_1")
    assert get_res.is_ok()
    retrieved = get_res.unwrap()
    assert retrieved.name == "API Docs"
    
    # Mark indexed
    idx_res = await registry.mark_indexed("docs_1")
    assert idx_res.is_ok()
    
    get_res_2 = await registry.get_source("docs_1")
    assert get_res_2.unwrap().indexed is True
    assert get_res_2.unwrap().indexed_at is not None

@pytest.mark.asyncio
async def test_knowledge_registry_search():
    backend = InMemoryBackend()
    registry = KnowledgeRegistry(backend=backend, cache_enabled=False)
    
    # Manually inject items into backend for search testing
    # (Since we don't have a full ingestion pipeline in this test)
    item1 = {
        "item_id": "item_1",
        "source_id": "src_1",
        "content": "This is a test document about python.",
        "metadata": {},
        "embedding": None
    }
    item2 = {
        "item_id": "item_2",
        "source_id": "src_1",
        "content": "Another document about java.",
        "metadata": {},
        "embedding": None
    }
    
    await backend.save("knowledge:item:src_1:item_1", item1)
    await backend.save("knowledge:item:src_1:item_2", item2)
    
    # Search
    search_res = await registry.search("python")
    assert search_res.is_ok()
    results = search_res.unwrap()
    assert results.total_results == 1
    assert results.items[0].item_id == "item_1"

# ---------- Policy Registry Tests ----------

from cmp.registries.policy_registry import PolicyRegistry, PolicyInfo

@pytest.mark.asyncio
async def test_policy_registry_flow():
    backend = InMemoryBackend()
    registry = PolicyRegistry(backend=backend, cache_enabled=False)
    
    policy_data = {"action": "allow", "resource": "*"}
    
    # Register
    reg_res = await registry.register_policy("pol_1", policy_data, version="1.0.0", description="Test Policy")
    assert reg_res.is_ok()
    
    # Get
    get_res = await registry.get_policy("pol_1", version="1.0.0")
    assert get_res.is_ok()
    assert get_res.unwrap() == policy_data
    
    # List versions - Not implemented in PolicyRegistry yet
    # vers_res = await registry.list_versions("pol_1")
    # assert vers_res.is_ok()

# ---------- Schema Registry Tests ----------

from cmp.registries.schema_registry import SchemaRegistry

@pytest.mark.asyncio
async def test_schema_registry_flow():
    backend = InMemoryBackend()
    registry = SchemaRegistry(backend=backend, cache_enabled=False)
    
    schema_data = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"}
        },
        "required": ["name"]
    }
    
    # Register
    reg_res = await registry.register_schema("user_schema", schema_data, version="1.0.0", description="User Schema")
    assert reg_res.is_ok()
    
    # Get
    get_res = await registry.get_schema("user_schema", version="1.0.0")
    assert get_res.is_ok()
    assert get_res.unwrap() == schema_data
    
    # Validate data
    valid_data = {"name": "Alice", "age": 30}
    val_res = await registry.validate_data("user_schema", valid_data, version="1.0.0")
    assert val_res.is_ok()
    assert val_res.unwrap() is None
    
    # Validate invalid data
    invalid_data = {"age": 30} # Missing name
    val_res_inv = await registry.validate_data("user_schema", invalid_data, version="1.0.0")
    assert val_res_inv.is_err()
