# Incremental coverage tests
"""High‑impact tests to boost overall coverage.
These tests target core SDK, service layer, and utility modules.
"""
import asyncio
import pytest
from cmp.sdk.agent import Agent as SdkAgent
from cmp.sdk.client import CMP, CMPClient
from cmp.services.context_service import ContextService
from cmp.storage.context_store import InMemoryContextStore
from cmp.registries.schema_registry import SchemaRegistry
from cmp.utils.async_helpers import async_map, async_filter
from cmp.utils.functional import compose, pipe

# ---------- Fixtures ----------
@pytest.fixture
def in_memory_store():
    return InMemoryContextStore()

@pytest.fixture
def schema_registry():
    return SchemaRegistry()

@pytest.fixture
def context_service(in_memory_store, schema_registry):
    # Use dummy policy service that always allows actions
    from cmp.services.policy_service import MockPolicyService
    return ContextService(
        store=in_memory_store,
        schema_registry=schema_registry,
        policy_service=MockPolicyService(),
    )

# ---------- SDK Tests ----------
def test_sdk_client_initialization():
    client = CMPClient(tenant_id="test_tenant", config={"base_url": "http://localhost"})
    assert client.tenant_id == "test_tenant"
    assert client.config["base_url"] == "http://localhost"
    # The client should expose a default agent
    # Note: CMP client doesn't expose .agent directly in current implementation, 
    # checking services container instead
    assert client.services is not None

# ---------- Context Service Tests ----------
@pytest.mark.asyncio
async def test_context_creation_and_metrics(context_service, schema_registry):
    # Register a simple schema
    schema_def = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "required": ["name"],
    }
    schema_registry.register_schema("test_schema", schema_def, version="1.0")

    ctx_id_res = await context_service.create({"name": "Alice"}, "test_schema", "tenant1")
    assert ctx_id_res.is_ok()
    # Verify that a metric was recorded (contexts_created should be > 0)
    from cmp.monitoring.metrics import get_metrics_collector
    metrics = get_metrics_collector().get_metrics()
    assert metrics.contexts_created > 0

# ---------- Async Helpers Tests ----------
@pytest.mark.asyncio
async def test_async_map_and_filter():
    async def double(x):
        return x * 2
    async def is_even(x):
        return x % 2 == 0

    data = [1, 2, 3, 4]
    mapped = await async_map(double, data)
    assert mapped == [2, 4, 6, 8]
    filtered = await async_filter(is_even, data)
    assert filtered == [2, 4]

# ---------- Functional Utils Tests ----------
def test_compose_and_pipe():
    def add_one(x):
        return x + 1
    def mul_two(x):
        return x * 2
    composed = compose(mul_two, add_one)  # mul_two(add_one(x))
    assert composed(3) == 8
    piped = pipe(3, add_one, mul_two)
    assert piped == 8
