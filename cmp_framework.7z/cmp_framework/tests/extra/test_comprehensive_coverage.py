
import pytest
import asyncio
from datetime import datetime, timezone
from typing import Any, Callable, List

# Core imports
from cmp.core.result import Ok, Err

# Registries and services
from cmp.registries.persistence import InMemoryBackend, PersistenceError
from cmp.registries.knowledge_registry import (
    KnowledgeRegistry,
    KnowledgeSource,
    KnowledgeType,
    KnowledgeItem,
    RegistryError,
)
from cmp.registries.policy_registry import PolicyRegistry, PolicyInfo, PolicyVersionError, PolicyNotFoundError
from cmp.registries.schema_registry import SchemaRegistry, SchemaInfo, SchemaVersionError
from cmp.services.context_service import ContextService, ContextEvent
from cmp.services.policy_service import MockPolicyService, PolicyResult

# Utils
from cmp.utils.async_helpers import async_map, async_filter
from cmp.utils.functional import pipe, compose

# ---------- Persistence Backend Tests ----------

@pytest.mark.asyncio
async def test_in_memory_backend_full_cycle():
    backend = InMemoryBackend()
    # Save a record
    await backend.save("test:key", {"a": 1}, metadata={"meta": "data"})
    # Load and verify
    load_res = await backend.load("test:key")
    assert load_res.is_ok()
    data = load_res.unwrap()
    assert data["key"] == "test:key"
    assert data["value"] == {"a": 1}
    assert data["metadata"] == {"meta": "data"}
    assert "saved_at" in data
    # List keys
    list_res = await backend.list()
    assert list_res.is_ok()
    assert "test:key" in list_res.unwrap()
    # Search by value content
    search_res = await backend.search({"a": 1})
    assert search_res.is_ok()
    results = search_res.unwrap()
    assert any(r["key"] == "test:key" for r in results)
    # Delete and confirm error
    # Delete and confirm error
    del_res = await backend.delete("test:key")
    assert del_res.is_ok()
    load_err = await backend.load("test:key")
    assert load_err.is_err()
    assert isinstance(load_err.error, PersistenceError)

# ---------- Knowledge Registry Tests ----------

@pytest.mark.asyncio
async def test_knowledge_registry_crud_and_search():
    backend = InMemoryBackend()
    registry = KnowledgeRegistry(backend=backend, cache_enabled=False)
    source = KnowledgeSource(
        source_id="src1",
        source_type=KnowledgeType.DOCUMENT,
        name="Doc 1",
        description="Test doc",
        config={"path": "/tmp"},
        metadata={"author": "tester"},
        created_at=datetime.now(timezone.utc).isoformat(),
    )
    # Register source
    reg_res = await registry.register_knowledge(source)
    assert reg_res.is_ok()
    # Retrieve source
    get_res = await registry.get_source("src1")
    assert get_res.is_ok()
    retrieved = get_res.unwrap()
    assert retrieved.name == "Doc 1"
    # Add an item manually to backend for search
    item = {
        "item_id": "item1",
        "source_id": "src1",
        "content": "Python testing utilities",
        "metadata": {},
        "embedding": None,
    }
    await backend.save("knowledge:item:src1:item1", item)
    # Search
    search_res = await registry.search("Python")
    assert search_res.is_ok()
    results = search_res.unwrap()
    assert results.total_results == 1
    assert results.items[0].item_id == "item1"
    # Mark indexed
    idx_res = await registry.mark_indexed("src1")
    assert idx_res.is_ok()
    src_after = await registry.get_source("src1")
    assert src_after.unwrap().indexed is True
    assert src_after.unwrap().indexed_at is not None

# ---------- Policy Registry Tests ----------

@pytest.mark.asyncio
async def test_policy_registry_register_and_deploy():
    backend = InMemoryBackend()
    registry = PolicyRegistry(backend=backend, cache_enabled=False)
    policy_data = {"allow": True}
    # Register policy version 1.0.0
    reg_res = await registry.register_policy("pol1", policy_data, version="1.0.0", description="test policy")
    assert reg_res.is_ok()
    # Retrieve policy
    get_res = await registry.get_policy("pol1", version="1.0.0")
    assert get_res.is_ok()
    assert get_res.unwrap() == policy_data
    # Deploy policy
    deploy_res = await registry.deploy_policy("pol1", version="1.0.0")
    assert deploy_res.is_ok()
    # Verify deployment metadata via backend directly
    key = registry._make_key("pol1", "1.0.0")
    stored = await backend.load(key)
    assert stored.is_ok()
    meta = stored.unwrap()["metadata"]
    assert meta.get("deployed") is True
    assert "deployed_at" in meta
    # Attempt duplicate registration without force should error
    dup_res = await registry.register_policy("pol1", policy_data, version="1.0.0")
    assert dup_res.is_err()
    assert isinstance(dup_res.unwrap_err(), PolicyVersionError)

# ---------- Schema Registry Tests ----------

@pytest.mark.asyncio
async def test_schema_registry_register_validate_and_deprecate():
    backend = InMemoryBackend()
    registry = SchemaRegistry(backend=backend, cache_enabled=False)
    schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "required": ["name"],
    }
    # Register schema version 1.0.0
    reg_res = await registry.register_schema("user", schema, version="1.0.0", description="User schema")
    assert reg_res.is_ok()
    # Retrieve schema
    get_res = await registry.get_schema("user", version="1.0.0")
    assert get_res.is_ok()
    assert get_res.unwrap() == schema
    # Validate correct data
    valid = {"name": "Alice"}
    val_res = await registry.validate_data("user", valid, version="1.0.0")
    assert val_res.is_ok()
    # Validate incorrect data (missing required field)
    invalid = {"age": 30}
    inv_res = await registry.validate_data("user", invalid, version="1.0.0")
    assert inv_res.is_err()
    # Deprecate version
    deprec_res = await registry.deprecate_schema("user", version="1.0.0")
    assert deprec_res.is_ok()
    # Verify deprecation flag via backend
    key = registry._make_key("user", "1.0.0")
    stored = await backend.load(key)
    assert stored.is_ok()
    meta = stored.unwrap()["metadata"]
    assert meta.get("deprecated") is True
    assert "deprecated_at" in meta

# ---------- Context Service Tests ----------

@pytest.mark.asyncio
async def test_context_service_create_and_update():
    from cmp.storage.context_store import InMemoryContextStore
    backend = InMemoryBackend()
    store = InMemoryContextStore()
    schema_registry = SchemaRegistry()
    policy_service = MockPolicyService()
    service = ContextService(
        store=store,
        schema_registry=schema_registry,
        policy_service=policy_service,
        cache_enabled=False
    )
    
    # Add observer to track events in backend for testing
    async def event_observer(event: ContextEvent) -> None:
        await backend.save(f"context:event:{event.context_id}:{event.event_type}", event.to_dict())
    service.observable.subscribe(event_observer)

    # Register a schema first
    await schema_registry.register_schema("schema1", {"type": "object"}, version="1.0")
    
    # Create a context
    ctx_res = await service.create(
        tenant_id="t1",
        data={"foo": "bar"},
        schema_name="schema1",
    )
    assert ctx_res.is_ok()
    ctx_id = ctx_res.unwrap()
    # Retrieve context
    get_res = await service.get(ctx_id)
    assert get_res.is_ok()
    ctx = get_res.unwrap()
    assert ctx.id == ctx_id
    assert ctx.data["foo"] == "bar"
    # Update context data
    upd_res = await service.update(ctx_id, {"baz": 123})
    assert upd_res.is_ok()
    upd_ctx = upd_res.unwrap()
    assert upd_ctx.data["baz"] == 123
    # Ensure an event was emitted
    events = await backend.list(prefix="context:event:")
    assert events.is_ok()
    # Ensure at least two events (creation and update) were recorded
    assert len(events.unwrap()) >= 2

# ---------- Policy Service (Mock) Tests ----------

@pytest.mark.asyncio
async def test_mock_policy_service_always_allows():
    service = MockPolicyService()
    result = await service.evaluate("any.path", {"sample": 1})
    assert isinstance(result, PolicyResult)
    assert result.allowed is True
    assert result.reason == "Mock policy - always allow"
    workflow_cfg = await service.get_workflow_policy("demo")
    assert workflow_cfg["strategy"] == "chaining"

# ---------- Async Helpers Tests ----------

async def async_double(x: int) -> int:
    await asyncio.sleep(0.01)
    return x * 2

async def async_is_even(x: int) -> bool:
    await asyncio.sleep(0.01)
    return x % 2 == 0

@pytest.mark.asyncio
async def test_async_helpers_map_and_filter():
    numbers = [1, 2, 3, 4]
    doubled = await async_map(async_double, numbers)
    assert doubled == [2, 4, 6, 8]
    evens = await async_filter(async_is_even, numbers)
    assert evens == [2, 4]

# ---------- Functional Utils Tests ----------

def add_one(x: int) -> int:
    return x + 1

def mul_two(x: int) -> int:
    return x * 2

def to_str(x: int) -> str:
    return str(x)

def test_pipe_and_compose():
    # pipe: value first
    result = pipe(3, add_one, mul_two, to_str)
    assert result == "8"
    # (curried style not supported; omitted)
    # compose creates a new function (right-to-left)
    composed = compose(to_str, mul_two, add_one)
    assert composed(4) == "10"

