"""
Comprehensive tests to boost overall coverage above 85%.
These tests exercise many low‑coverage modules in the `cmp` package.
"""
import asyncio
import pytest

# Async helpers
from cmp.utils.async_helpers import (
    async_map,
    async_filter,
    AsyncLock,
    AsyncPool,
)

# Functional utils
from cmp.utils.functional import compose, pipe, curry, identity, const

# Registries
from cmp.registries.schema_registry import SchemaRegistry
from cmp.registries.policy_registry import PolicyRegistry
from cmp.registries.knowledge_registry import KnowledgeRegistry
from cmp.registries.persistence import RegistryBackend

# Services
from cmp.services.policy_service import PolicyService
from cmp.services.context_service import ContextService
from cmp.storage.context_store import InMemoryContextStore

# Simple async functions for testing async helpers
async def inc(x: int) -> int:
    return x + 1

async def is_odd(x: int) -> bool:
    return x % 2 == 1

# ---------- Async Helpers Tests ----------
@pytest.mark.asyncio
async def test_async_helpers_map_filter_and_pool():
    # async_map and async_filter
    data = [1, 2, 3]
    mapped = await async_map(inc, data)
    assert mapped == [2, 3, 4]
    filtered = await async_filter(is_odd, data)
    assert filtered == [1, 3]

    # AsyncLock usage
    lock = AsyncLock()
    async with lock:
        # Inside lock, nothing to test other than no exception
        pass

    # AsyncPool usage with a simple factory
    async def factory():
        return "resource"
    pool = AsyncPool(factory, max_size=2)
    conn1 = await pool.acquire()
    conn2 = await pool.acquire()
    assert conn1 == "resource"
    assert conn2 == "resource"
    await pool.release(conn1)
    await pool.release(conn2)
    await pool.close()

# ---------- Functional Utils Tests ----------
def test_functional_compose_pipe_curry_identity_const():
    # compose and pipe
    def add_one(x):
        return x + 1
    def mul_two(x):
        return x * 2
    assert compose(mul_two, add_one)(3) == 8
    assert pipe(3, add_one, mul_two) == 8

    # curry
    def add(a, b, c):
        return a + b + c
    cur = curry(add)
    assert cur(1)(2)(3) == 6
    assert cur(1, 2)(3) == 6

    # identity and const
    obj = object()
    assert identity(obj) is obj
    const_five = const(5)
    assert const_five() == 5
    assert const_five('ignored') == 5

# ---------- Registry Tests ----------
def test_schema_and_policy_registry():
    sr = SchemaRegistry()
    schema_def = {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}
    sr.register_schema("test", schema_def, version="1.0")
    retrieved = sr.get_schema("test", "1.0")
    assert retrieved["type"] == "object"

    pr = PolicyRegistry()
    # Register a simple policy and retrieve it
    policy = {"action": "allow", "resource": "*"}
    pr.register_policy("test_policy", policy)
    assert pr.get_policy("test_policy") == policy

def test_knowledge_registry_and_persistence_backend():
    kr = KnowledgeRegistry()
    # Register and retrieve a simple knowledge entry
    kr.register("key", {"value": 123})
    assert kr.get("key") == {"value": 123}

    # Persistence backend is abstract; we can instantiate a concrete subclass for test
    class DummyBackend(RegistryBackend):
        async def save(self, item):
            return True
        async def load(self, key):
            return {"dummy": True}
        async def delete(self, key):
            return True
        async def search(self, query):
            return []
    dummy = DummyBackend()
    # Call each method to increase coverage
    assert asyncio.run(dummy.save({})) is True
    assert asyncio.run(dummy.load("any")) == {"dummy": True}
    assert asyncio.run(dummy.delete("any")) is True
    assert asyncio.run(dummy.search({})) == []

# ---------- Service Tests ----------
@pytest.mark.asyncio
async def test_context_service_and_policy_service():
    store = InMemoryContextStore()
    schema_reg = SchemaRegistry()
    policy_srv = PolicyService()
    ctx_srv = ContextService(store=store, schema_registry=schema_reg, policy_service=policy_srv)

    # Register a simple schema
    schema_def = {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}
    schema_reg.register_schema("person", schema_def, version="1.0")

    # Create a context and verify result
    res = await ctx_srv.create({"name": "Bob"}, "person", "tenantA")
    assert res.is_ok()
    ctx_id = res.unwrap()
    # Retrieve the context
    get_res = await ctx_srv.get(ctx_id)
    assert get_res.is_ok()
    # Update the context
    upd_res = await ctx_srv.update(ctx_id, {"age": 30})
    assert upd_res.is_ok()
    # Delete the context
    del_res = await ctx_srv.delete(ctx_id)
    assert del_res.is_ok()
