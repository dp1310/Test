"""
Additional tests to increase overall coverage above 85%.
Covers async helpers, functional utilities, policy service, policy registry, and orchestration service.
"""
import pytest
import asyncio
from cmp.utils.async_helpers import async_map, async_filter, AsyncLock, AsyncPool
from cmp.utils.functional import compose, pipe, curry, identity, const
from cmp.services.policy_service import MockPolicyService
from cmp.registries.policy_registry import PolicyRegistry
from cmp.services.orchestration_service import OrchestrationService
from cmp.orchestration.strategies import Agent, OrchestrationStrategy
from typing import AsyncIterator
from cmp.core.models import Context

# ---------- Async Helpers Tests ----------
@pytest.mark.asyncio
async def test_async_helpers_lock_and_pool():
    lock = AsyncLock()
    async with lock:
        # No exception means lock works
        pass

    async def factory():
        return "resource"
    pool = AsyncPool(factory, max_size=1)
    res = await pool.acquire()
    assert res == "resource"
    await pool.release(res)
    await pool.close()

@pytest.mark.asyncio
async def test_async_map_and_filter():
    async def inc(x):
        return x + 1
    async def is_even(x):
        return x % 2 == 0
    data = [1, 2, 3]
    mapped = await async_map(inc, data)
    assert mapped == [2, 3, 4]
    filtered = await async_filter(is_even, data)
    assert filtered == [2]

# ---------- Functional Utils Tests ----------
def test_functional_compose_pipe_curry_identity_const():
    def add_one(x):
        return x + 1
    def mul_two(x):
        return x * 2
    assert compose(mul_two, add_one)(3) == 8
    assert pipe(3, add_one, mul_two) == 8
    cur = curry(lambda a, b, c: a + b + c)
    assert cur(1)(2)(3) == 6
    assert cur(1, 2)(3) == 6
    obj = object()
    assert identity(obj) is obj
    five = const(5)
    assert five() == 5
    assert five('ignored') == 5

# ---------- Policy Service Tests ----------
@pytest.mark.asyncio
async def test_mock_policy_service():
    svc = MockPolicyService()
    result = await svc.evaluate("some.path", {"key": "value"})
    assert result.allowed is True
    policy = await svc.get_workflow_policy("any")
    assert isinstance(policy, dict)
    assert policy.get("strategy") == "chaining"

# ---------- Policy Registry Tests ----------
@pytest.mark.asyncio
async def test_policy_registry_register_and_get():
    pr = PolicyRegistry()
    # Register a simple policy and retrieve it
    policy = {"action": "allow", "resource": "*"}
    await pr.register_policy("test_policy", policy)
    retrieved_res = await pr.get_policy("test_policy")
    assert retrieved_res.is_ok()
    retrieved = retrieved_res.unwrap()
    assert retrieved == policy

# ---------- Orchestration Service Tests ----------
class DummyAgent(Agent):
    async def process(self, context: Context) -> Context:
        # Simple processing: add a flag
        return context.with_data(processed=True)

class SimpleStrategy(OrchestrationStrategy):
    async def execute(self, context: Context, agents: list[Agent], policy: dict) -> AsyncIterator[Context]:
        # Yield the original context then each agent's processed context
        yield context
        for agent in agents:
            ctx = await agent.process(context)
            yield ctx

@pytest.mark.asyncio
async def test_orchestration_service_execute_workflow():
    policy_srv = MockPolicyService()
    orch_srv = OrchestrationService(policy_service=policy_srv, strategies={"simple": SimpleStrategy()})
    # Use the simple strategy via policy
    # Mock get_workflow_policy to return our strategy name
    async def fake_get_workflow_policy(name):
        return {"strategy": "simple"}
    policy_srv.get_workflow_policy = fake_get_workflow_policy
    # Prepare a dummy context
    ctx = Context(id="ctx_1", data={"value": 1}, tenant_id="test_tenant")
    agents = [DummyAgent("agent1")]
    results = []
    async for res in orch_srv.execute_workflow("wf", ctx, agents):
        results.append(res)
    assert len(results) == 2
    assert results[0].data == {"value": 1}
    assert results[1].data.get("processed") is True
