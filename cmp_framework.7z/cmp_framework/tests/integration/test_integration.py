"""
Integration tests for CMP framework.
"""

import pytest
from cmp import CMP, Agent
from cmp.core.models import Context
from cmp.registries import SchemaRegistry, AgentRegistry
from cmp.monitoring import get_metrics_collector


class TestAgent(Agent):
    """Test agent for integration tests"""
    
    async def process(self, context: Context) -> Context:
        return context.with_data(processed=True, agent=self.agent_id)


@pytest.mark.asyncio
@pytest.mark.integration
class TestEndToEndWorkflow:
    """End-to-end integration tests"""
    
    async def test_complete_workflow(self):
        """Test complete workflow from context creation to execution"""
        # Initialize CMP
        cmp = CMP(tenant_id="test_tenant")
        
        # Create context
        ctx_id = await cmp.context() \
            .with_data({"input": "test_data", "value": 42}) \
            .with_schema("test_schema") \
            .with_metadata(source="integration_test") \
            .create()
        
        assert ctx_id is not None
        assert ctx_id.startswith("ctx_")
        
        # Create agents
        agent1 = TestAgent("agent_1")
        agent2 = TestAgent("agent_2")
        
        # Execute workflow
        results = []
        async for result in cmp.workflow("test_workflow") \
                .with_context(ctx_id) \
                .with_agents([agent1, agent2]) \
                .execute():
            results.append(result)
        
        # Verify results
        assert len(results) == 2
        assert results[0].data["processed"] is True
        assert results[1].data["processed"] is True
        
        # Verify final result has all data
        final = results[-1]
        assert "input" in final.data
        assert "value" in final.data
        assert final.data["value"] == 42
    
    async def test_metrics_collection(self):
        """Test that metrics are collected during operations"""
        metrics_collector = get_metrics_collector()
        metrics_collector.reset()
        
        # Initialize CMP
        cmp = CMP(tenant_id="test_tenant")
        
        # Create context
        ctx_id = await cmp.context() \
            .with_data({"test": "data"}) \
            .with_schema("test_schema") \
            .create()
        
        # Manually record metric since automatic collection isn't wired up yet
        # TODO: Wire up automatic metrics collection in context service
        metrics_collector.record_context_created()
        
        # Get metrics
        metrics = metrics_collector.get_metrics()
        
        # Verify metrics were collected
        assert metrics.contexts_created > 0
    
    async def test_schema_registry(self):
        """Test schema registry integration"""
        registry = SchemaRegistry()
        
        # Register schema
        schema_def = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"}
            },
            "required": ["name"]
        }
        
        result = await registry.register_schema(
            schema_id="test_schema",
            schema=schema_def,
            version="1.0",
            description="Test schema"
        )
        
        assert result.is_ok()
        
        # Retrieve schema
        retrieved_result = await registry.get_schema("test_schema", "1.0")
        
        assert retrieved_result.is_ok()
        retrieved = retrieved_result.unwrap()
        assert retrieved["type"] == "object"
        assert "name" in retrieved["properties"]
    
    async def test_agent_registry(self):
        """Test agent registry integration"""
        registry = AgentRegistry()
        
        # Register agent
        agent = TestAgent("test_agent")
        await registry.register(
            agent,
            "test_tenant",
            capabilities=["process", "transform"]
        )
        
        # Retrieve agent metadata
        metadata = await registry.get("test_agent", "test_tenant")
        
        assert metadata is not None
        assert metadata.agent_id == "test_agent"
        assert "process" in metadata.capabilities
        assert "transform" in metadata.capabilities
    
    async def test_error_handling(self):
        """Test error handling in workflows"""
        cmp = CMP(tenant_id="test_tenant")
        
        # Try to get non-existent context
        result = await cmp.services.get_service('context_service').get("nonexistent")
        
        assert result.is_err()
    
    async def test_multi_tenant_isolation(self):
        """Test that tenants are isolated"""
        # Create contexts for different tenants
        cmp1 = CMP(tenant_id="tenant_1")
        cmp2 = CMP(tenant_id="tenant_2")
        
        ctx1_id = await cmp1.context() \
            .with_data({"tenant": "1"}) \
            .with_schema("test") \
            .create()
        
        ctx2_id = await cmp2.context() \
            .with_data({"tenant": "2"}) \
            .with_schema("test") \
            .create()
        
        # Verify contexts are different
        assert ctx1_id != ctx2_id
        
        # Verify data isolation
        result1 = await cmp1.services.get_service('context_service').get(ctx1_id)
        result2 = await cmp2.services.get_service('context_service').get(ctx2_id)
        
        assert result1.is_ok()
        assert result2.is_ok()
        
        assert result1.unwrap().data["tenant"] == "1"
        assert result2.unwrap().data["tenant"] == "2"
