"""Tests for websocket module initialization."""

import pytest
from cmp.api.websocket import ConnectionManager, manager, handle_websocket
from cmp.api.websocket.manager import ConnectionManager as DirectConnectionManager


def test_websocket_module_imports():
    """Test that websocket module imports work correctly."""
    # Test that imports are available
    assert ConnectionManager is not None
    assert manager is not None
    assert handle_websocket is not None
    
    # Test that imported classes are correct types
    assert isinstance(manager, ConnectionManager)
    assert ConnectionManager is DirectConnectionManager


def test_websocket_module_all_exports():
    """Test that __all__ exports are correct."""
    from cmp.api.websocket import __all__
    
    expected_exports = [
        "ConnectionManager",
        "manager", 
        "handle_websocket"
    ]
    
    assert set(__all__) == set(expected_exports)


def test_manager_is_singleton():
    """Test that manager is a singleton instance."""
    from cmp.api.websocket import manager as manager1
    from cmp.api.websocket import manager as manager2
    
    # Should be the same instance
    assert manager1 is manager2


def test_connection_manager_instantiation():
    """Test that ConnectionManager can be instantiated."""
    cm = ConnectionManager()
    
    assert hasattr(cm, 'active_connections')
    assert hasattr(cm, 'subscriptions')
    assert hasattr(cm, 'metadata')
    assert len(cm.active_connections) == 0
    assert len(cm.subscriptions) == 0
    assert len(cm.metadata) == 0


@pytest.mark.asyncio
async def test_handle_websocket_callable():
    """Test that handle_websocket is callable."""
    assert callable(handle_websocket)
    
    # Test function signature (should not raise)
    import inspect
    sig = inspect.signature(handle_websocket)
    params = list(sig.parameters.keys())
    
    expected_params = ['websocket', 'connection_id', 'tenant_id']
    assert params == expected_params