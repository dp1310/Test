
import pytest
from typer.testing import CliRunner
from cmp.cli.cli import app
from unittest.mock import patch, MagicMock

runner = CliRunner()

def test_cli_base():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "CMP Framework - Context Management Plane CLI" in result.output

def test_cli_version():
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert "CMP Framework version" in result.output

def test_cli_info():
    result = runner.invoke(app, ["info"])
    assert result.exit_code == 0
    assert "CMP Framework Information" in result.output
