"""Tests for main CLI functionality."""

import pytest
from typer.testing import CliRunner
from unittest.mock import patch

from cmp.cli.cli import app, version, info, main


@pytest.fixture
def runner():
    """CLI test runner."""
    return CliRunner()


def test_cli_app_creation():
    """Test that CLI app is created properly."""
    assert app is not None
    assert app.info.name == "cmp"
    assert "Context Management Plane CLI" in app.info.help


def test_version_command(runner):
    """Test version command."""
    result = runner.invoke(app, ["version"])
    
    assert result.exit_code == 0
    assert "CMP Framework" in result.stdout
    assert "version" in result.stdout
    assert "0.1.0" in result.stdout


def test_info_command(runner):
    """Test info command."""
    result = runner.invoke(app, ["info"])
    
    assert result.exit_code == 0
    assert "CMP Framework Information" in result.stdout
    assert "Configuration" in result.stdout
    assert "Registries" in result.stdout
    assert "Monitoring" in result.stdout
    assert "CLI" in result.stdout
    assert "API Server" in result.stdout


def test_help_command(runner):
    """Test help command."""
    result = runner.invoke(app, ["--help"])
    
    assert result.exit_code == 0
    assert "Context Management Plane CLI" in result.stdout
    assert "context" in result.stdout
    assert "workflow" in result.stdout
    assert "registry" in result.stdout
    assert "monitor" in result.stdout


def test_context_subcommand_available(runner):
    """Test that context subcommand is available."""
    result = runner.invoke(app, ["context", "--help"])
    
    assert result.exit_code == 0
    assert "Context management commands" in result.stdout


def test_workflow_subcommand_available(runner):
    """Test that workflow subcommand is available."""
    result = runner.invoke(app, ["workflow", "--help"])
    
    assert result.exit_code == 0
    assert "Workflow execution commands" in result.stdout


def test_registry_subcommand_available(runner):
    """Test that registry subcommand is available."""
    result = runner.invoke(app, ["registry", "--help"])
    
    assert result.exit_code == 0
    assert "Registry management commands" in result.stdout


def test_monitor_subcommand_available(runner):
    """Test that monitor subcommand is available."""
    result = runner.invoke(app, ["monitor", "--help"])
    
    assert result.exit_code == 0
    assert "Monitoring and metrics commands" in result.stdout


def test_main_function():
    """Test main function."""
    # Test that main function calls app without raising exception when help is requested
    with patch('sys.argv', ['cmp', '--help']):
        with pytest.raises(SystemExit) as exc_info:
            main()
        # Help command should exit with code 0
        assert exc_info.value.code == 0


def test_version_function_direct():
    """Test version function directly."""
    with patch('cmp.cli.cli.console') as mock_console:
        version()
        mock_console.print.assert_called_once()
        call_args = mock_console.print.call_args[0][0]
        assert "CMP Framework" in call_args
        assert "0.1.0" in call_args


def test_info_function_direct():
    """Test info function directly."""
    with patch('cmp.cli.cli.console') as mock_console:
        with patch('cmp.cli.cli.Table') as mock_table_class:
            mock_table = mock_table_class.return_value
            
            info()
            
            # Should create table and add rows
            mock_table_class.assert_called_once_with(title="CMP Framework Information")
            mock_table.add_column.assert_called()
            mock_table.add_row.assert_called()
            mock_console.print.assert_called_with(mock_table)


def test_invalid_command(runner):
    """Test invalid command handling."""
    result = runner.invoke(app, ["invalid-command"])
    
    assert result.exit_code != 0
    # Check for error message in stderr or stdout
    error_output = result.stdout + (result.stderr or "")
    assert ("No such command" in error_output or 
            "invalid-command" in error_output or
            "Usage:" in error_output)


def test_app_configuration():
    """Test app configuration settings."""
    # Test basic app properties that are available
    assert app.info.name == "cmp"
    assert hasattr(app, 'registered_commands')
    assert hasattr(app, 'registered_groups')


def test_subcommand_integration(runner):
    """Test that subcommands are properly integrated."""
    # Test that we can access nested commands
    result = runner.invoke(app, ["context", "list", "--help"])
    assert result.exit_code == 0
    
    result = runner.invoke(app, ["monitor", "health", "--help"])
    assert result.exit_code == 0


def test_console_creation():
    """Test that console is created."""
    from cmp.cli.cli import console
    assert console is not None


def test_app_typer_groups():
    """Test that all typer groups are added."""
    # Check that all expected commands are registered by function name
    command_functions = [cmd.callback.__name__ for cmd in app.registered_commands]
    groups = [group.name for group in app.registered_groups]
    
    # Should have version and info commands
    assert "version" in command_functions
    assert "info" in command_functions
    
    # Should have all command groups
    assert "context" in groups
    assert "workflow" in groups
    assert "registry" in groups
    assert "monitor" in groups


def test_main_entry_point():
    """Test main entry point when called as script."""
    with patch('cmp.cli.cli.app') as mock_app:
        # Simulate calling as script
        import cmp.cli.cli
        
        # Mock __name__ == "__main__"
        with patch.object(cmp.cli.cli, '__name__', '__main__'):
            with patch('cmp.cli.cli.main') as mock_main:
                # This would normally trigger main() call
                # We just test that main function exists and is callable
                assert callable(main)


def test_rich_formatting_in_commands(runner):
    """Test that rich formatting works in commands."""
    result = runner.invoke(app, ["version"])
    
    # Rich markup should be processed (though exact output depends on terminal)
    assert result.exit_code == 0
    assert len(result.stdout) > 0


def test_command_descriptions():
    """Test that commands have proper descriptions."""
    # Test version command
    version_cmd = None
    for cmd in app.registered_commands:
        if cmd.callback.__name__ == "version":
            version_cmd = cmd
            break
    
    assert version_cmd is not None
    # Check the docstring since help might be None
    assert "Show CMP Framework version" in version_cmd.callback.__doc__
    
    # Test info command
    info_cmd = None
    for cmd in app.registered_commands:
        if cmd.callback.__name__ == "info":
            info_cmd = cmd
            break
    
    assert info_cmd is not None
    assert "Show CMP Framework information" in info_cmd.callback.__doc__