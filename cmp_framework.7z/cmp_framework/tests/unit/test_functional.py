
import pytest
import asyncio
from cmp.utils.functional import compose, pipe, acompose, apipe, curry, identity, const

def test_compose():
    def add_one(x): return x + 1
    def double(x): return x * 2
    
    # compose(f, g)(x) = f(g(x))
    f = compose(double, add_one)
    assert f(5) == 12 # double(add_one(5)) = 6 * 2 = 12
    
    # verify empty compose returns identity
    assert compose()(5) == 5

def test_pipe():
    def add_one(x): return x + 1
    def double(x): return x * 2
    
    # pipe(value, f, g) = g(f(value))
    assert pipe(3, add_one, double) == 8 # double(add_one(3)) = 4 * 2 = 8
    
    # pipe(f, g)(x) = g(f(x))
    f = pipe(add_one, double)
    assert f(3) == 8
    
    # Test error
    with pytest.raises(ValueError):
        pipe()

@pytest.mark.asyncio
async def test_acompose():
    async def add_one(x): return x + 1
    async def double(x): return x * 2
    
    f = await acompose(double, add_one)
    assert await f(5) == 12

@pytest.mark.asyncio
async def test_apipe():
    async def add_one(x): return x + 1
    async def double(x): return x * 2
    
    f = await apipe(add_one, double)
    assert await f(5) == 12

def test_curry():
    def add(a, b, c): return a + b + c
    
    curried = curry(add)
    assert curried(1, 2, 3) == 6
    assert curried(1)(2)(3) == 6
    assert curried(1, 2)(3) == 6
    
    # Test exception handling fallback in curried wrapper
    # This is tricky because standard python function calls don't raise TypeError just because args are missing unless called.
    # The curry implementation relies on catching TypeError to determine if it should return a partial.
    # However, standard python behavior: calling func(1) when it expects 3 will raise TypeError.
    
    assert curried(1)(2, 3) == 6

def test_utils():
    assert identity(5) == 5
    
    five = const(5)
    assert five() == 5
    assert five(1, 2, 3) == 5
