
import pytest
from cmp.config.config import CMPConfig, get_config
from cmp.di.decorators import context, knowledge, set_service_container
from cmp.core.models import Context

class MockServiceContainer:
    def __init__(self):
        self.tenant_id = "test_tenant"
        self._current_context = None
        
    def get_service(self, name):
        return self
        
    def get_current_context(self):
        return self._current_context
        
    async def get_source(self, source, tenant_id):
        return f"mock_source_{source}"

def test_config_loading():
    config = get_config()
    # Default values
    assert config.monitoring.enable_metrics is True
    
    # Check that it's a CMPConfig
    assert isinstance(config, CMPConfig)

@pytest.mark.asyncio
async def test_di_decorators():
    container = MockServiceContainer()
    set_service_container(container)
    
    @context()
    async def func_with_context(context: Context = None):
        return context
        
    ctx = Context(id="c1", data={}, tenant_id="t1")
    container._current_context = ctx
    
    # When called without args, it should inject from container
    res = await func_with_context()
    assert res == ctx
    
    # When called with args, it should still inject because the decorator overwrites kwargs['context']
    # unless we change the decorator. Current implementation: kwargs['context'] = ctx
    other_ctx = Context(id="c2", data={}, tenant_id="t2")
    res2 = await func_with_context(context=other_ctx)
    assert res2 == ctx # Should be ctx because decorator injects it

@pytest.mark.asyncio
async def test_knowledge_decorator():
    container = MockServiceContainer()
    set_service_container(container)
    
    @knowledge(source="python")
    async def use_knowledge(knowledge=None):
        return knowledge
        
    res = await use_knowledge()
    assert res == "mock_source_python"
