"""Tests for CLI context commands."""

import pytest
import json
import tempfile
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from pathlib import Path
from typer.testing import CliRunner
from datetime import datetime

from cmp.cli.context_commands import context_app, get_cmp_client
from cmp.core.models import Context
from cmp.core.result import Ok, Err


class TestGetCMPClient:
    """Test get_cmp_client helper function."""
    
    def test_get_cmp_client_default_config(self):
        """Test getting CMP client with default config."""
        with patch('cmp.cli.context_commands.get_config') as mock_get_config:
            with patch('cmp.cli.context_commands.CMP') as mock_cmp:
                mock_config = Mock()
                mock_get_config.return_value = mock_config
                mock_cmp_instance = Mock()
                mock_cmp.return_value = mock_cmp_instance
                
                result = get_cmp_client("test-tenant")
                
                mock_get_config.assert_called_once()
                mock_cmp.assert_called_once_with(tenant_id="test-tenant")
                assert result is mock_cmp_instance
    
    def test_get_cmp_client_with_config_file(self):
        """Test getting CMP client with config file."""
        with patch('cmp.cli.context_commands.CMPConfig') as mock_config_class:
            with patch('cmp.cli.context_commands.CMP') as mock_cmp:
                mock_config = Mock()
                mock_config_class.from_yaml.return_value = mock_config
                mock_cmp_instance = Mock()
                mock_cmp.return_value = mock_cmp_instance
                
                result = get_cmp_client("test-tenant", "config.yaml")
                
                mock_config_class.from_yaml.assert_called_once_with("config.yaml")
                mock_cmp.assert_called_once_with(tenant_id="test-tenant")
                assert result is mock_cmp_instance


class TestCreateContextCommand:
    """Test create context CLI command."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_create_context_success(self):
        """Test successful context creation."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_builder = Mock()
            mock_builder.with_data.return_value = mock_builder
            mock_builder.with_schema.return_value = mock_builder
            mock_builder.with_metadata.return_value = mock_builder
            mock_builder.create = AsyncMock(return_value="ctx-123")
            mock_cmp.context.return_value = mock_builder
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "create",
                "--data", '{"key": "value"}',
                "--schema", "test-schema",
                "--tenant", "test-tenant"
            ])
            
            assert result.exit_code == 0
            assert "Context created: ctx-123" in result.stdout
            mock_get_client.assert_called_once_with("test-tenant", None)
            mock_cmp.context.assert_called_once()
            mock_builder.with_data.assert_called_once_with({"key": "value"})
            mock_builder.with_schema.assert_called_once_with("test-schema")
    
    def test_create_context_with_metadata(self):
        """Test context creation with metadata."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_builder = Mock()
            mock_builder.with_data.return_value = mock_builder
            mock_builder.with_metadata.return_value = mock_builder
            mock_builder.create = AsyncMock(return_value="ctx-123")
            mock_cmp.context.return_value = mock_builder
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "create",
                "--data", '{"key": "value"}',
                "--metadata", '{"author": "test", "version": "1.0"}'
            ])
            
            assert result.exit_code == 0
            assert "Context created: ctx-123" in result.stdout
            # Should call with_metadata for each metadata key
            assert mock_builder.with_metadata.call_count == 2
    
    def test_create_context_invalid_json_data(self):
        """Test context creation with invalid JSON data."""
        result = self.runner.invoke(context_app, [
            "create",
            "--data", "invalid json"
        ])
        
        assert result.exit_code == 1
        assert "Invalid JSON" in result.stdout
    
    def test_create_context_invalid_json_metadata(self):
        """Test context creation with invalid JSON metadata."""
        result = self.runner.invoke(context_app, [
            "create",
            "--data", '{"key": "value"}',
            "--metadata", "invalid json"
        ])
        
        assert result.exit_code == 1
        assert "Invalid JSON" in result.stdout
    
    def test_create_context_error(self):
        """Test context creation with error."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_builder = Mock()
            mock_builder.with_data.return_value = mock_builder
            mock_builder.create = AsyncMock(side_effect=Exception("Creation failed"))
            mock_cmp.context.return_value = mock_builder
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "create",
                "--data", '{"key": "value"}'
            ])
            
            assert result.exit_code == 1
            assert "Error: Creation failed" in result.stdout


class TestGetContextCommand:
    """Test get context CLI command."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_get_context_success_table_format(self):
        """Test successful context retrieval in table format."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_context = Context(
                id="ctx-123",
                data={"key": "value"},
                tenant_id="test-tenant",
                schema="test-schema",
                created_at=datetime.now(),
                updated_at=datetime.now(),
                version=1
            )
            mock_service.get.return_value = Ok(mock_context)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "get", "ctx-123",
                "--tenant", "test-tenant"
            ])
            
            assert result.exit_code == 0
            assert "Context: ctx-123" in result.stdout
            assert "test-schema" in result.stdout
            mock_service.get.assert_called_once_with("ctx-123")
    
    def test_get_context_success_json_format(self):
        """Test successful context retrieval in JSON format."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_context = Context(
                id="ctx-123",
                data={"key": "value"},
                tenant_id="test-tenant"
            )
            mock_service.get.return_value = Ok(mock_context)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "get", "ctx-123",
                "--format", "json"
            ])
            
            assert result.exit_code == 0
            assert '"id": "ctx-123"' in result.stdout
            assert '"key": "value"' in result.stdout
    
    def test_get_context_success_yaml_format(self):
        """Test successful context retrieval in YAML format."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_context = Context(
                id="ctx-123",
                data={"key": "value"},
                tenant_id="test-tenant"
            )
            mock_service.get.return_value = Ok(mock_context)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            with patch('yaml.dump', return_value="id: ctx-123\nkey: value\n") as mock_yaml:
                result = self.runner.invoke(context_app, [
                    "get", "ctx-123",
                    "--format", "yaml"
                ])
                
                assert result.exit_code == 0
                assert "id: ctx-123" in result.stdout
                mock_yaml.assert_called_once()
    
    def test_get_context_not_found(self):
        """Test context retrieval when context not found."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_service.get.return_value = Err("Not found")
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "get", "nonexistent"
            ])
            
            assert result.exit_code == 1
            assert "Context not found: nonexistent" in result.stdout
    
    def test_get_context_error(self):
        """Test context retrieval with error."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_get_client.side_effect = Exception("Service error")
            
            result = self.runner.invoke(context_app, [
                "get", "ctx-123"
            ])
            
            assert result.exit_code == 1
            assert "Error: Service error" in result.stdout


class TestListContextsCommand:
    """Test list contexts CLI command."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_list_contexts_success(self):
        """Test successful context listing."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            contexts = [
                Context(id="ctx-1", data={"key": "value1"}, tenant_id="test-tenant", schema="schema1"),
                Context(id="ctx-2", data={"key": "value2"}, tenant_id="test-tenant", schema="schema2")
            ]
            mock_service.list.return_value = Ok(contexts)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "list",
                "--limit", "10"
            ])
            
            assert result.exit_code == 0
            assert "Contexts (showing 2)" in result.stdout
            assert "ctx-1" in result.stdout
            assert "ctx-2" in result.stdout
            assert "schema1" in result.stdout
            assert "schema2" in result.stdout
            mock_service.list.assert_called_once_with(limit=10)
    
    def test_list_contexts_with_schema_filter(self):
        """Test context listing with schema filter."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            contexts = [
                Context(id="ctx-1", data={"key": "value1"}, tenant_id="test-tenant", schema="schema1"),
                Context(id="ctx-2", data={"key": "value2"}, tenant_id="test-tenant", schema="schema2")
            ]
            mock_service.list.return_value = Ok(contexts)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "list",
                "--schema", "schema1"
            ])
            
            assert result.exit_code == 0
            assert "ctx-1" in result.stdout
            assert "ctx-2" not in result.stdout
    
    def test_list_contexts_empty(self):
        """Test context listing when no contexts exist."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_service.list.return_value = Ok([])
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, ["list"])
            
            assert result.exit_code == 0
            assert "No contexts found" in result.stdout
    
    def test_list_contexts_error(self):
        """Test context listing with error."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_service.list.return_value = Err("List error")
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, ["list"])
            
            assert result.exit_code == 1
            assert "Error listing contexts" in result.stdout


class TestUpdateContextCommand:
    """Test update context CLI command."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_update_context_success(self):
        """Test successful context update."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_service.update.return_value = Ok(True)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "update", "ctx-123",
                "--data", '{"updated": "value"}'
            ])
            
            assert result.exit_code == 0
            assert "Context updated: ctx-123" in result.stdout
            mock_service.update.assert_called_once_with("ctx-123", {"updated": "value"})
    
    def test_update_context_invalid_json(self):
        """Test context update with invalid JSON."""
        result = self.runner.invoke(context_app, [
            "update", "ctx-123",
            "--data", "invalid json"
        ])
        
        assert result.exit_code == 1
        assert "Invalid JSON" in result.stdout
    
    def test_update_context_error(self):
        """Test context update with error."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_service.update.return_value = Err("Update failed")
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "update", "ctx-123",
                "--data", '{"updated": "value"}'
            ])
            
            assert result.exit_code == 1
            assert "Failed to update context: Update failed" in result.stdout


class TestDeleteContextCommand:
    """Test delete context CLI command."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_delete_context_success_with_confirmation(self):
        """Test successful context deletion with confirmation."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            with patch('typer.confirm', return_value=True) as mock_confirm:
                mock_cmp = Mock()
                mock_service = AsyncMock()
                mock_service.delete.return_value = Ok(True)
                mock_cmp.services.get_service.return_value = mock_service
                mock_get_client.return_value = mock_cmp
                
                result = self.runner.invoke(context_app, [
                    "delete", "ctx-123"
                ])
                
                assert result.exit_code == 0
                assert "Context deleted: ctx-123" in result.stdout
                mock_confirm.assert_called_once_with("Delete context ctx-123?")
                mock_service.delete.assert_called_once_with("ctx-123")
    
    def test_delete_context_success_skip_confirmation(self):
        """Test successful context deletion skipping confirmation."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_service.delete.return_value = Ok(True)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "delete", "ctx-123",
                "--yes"
            ])
            
            assert result.exit_code == 0
            assert "Context deleted: ctx-123" in result.stdout
            mock_service.delete.assert_called_once_with("ctx-123")
    
    def test_delete_context_cancelled(self):
        """Test context deletion cancelled by user."""
        with patch('typer.confirm', return_value=False) as mock_confirm:
            result = self.runner.invoke(context_app, [
                "delete", "ctx-123"
            ])
            
            assert result.exit_code == 0
            assert "Cancelled" in result.stdout
            mock_confirm.assert_called_once_with("Delete context ctx-123?")
    
    def test_delete_context_error(self):
        """Test context deletion with error."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            with patch('typer.confirm', return_value=True):
                mock_cmp = Mock()
                mock_service = AsyncMock()
                mock_service.delete.return_value = Err("Delete failed")
                mock_cmp.services.get_service.return_value = mock_service
                mock_get_client.return_value = mock_cmp
                
                result = self.runner.invoke(context_app, [
                    "delete", "ctx-123"
                ])
                
                assert result.exit_code == 1
                assert "Failed to delete context" in result.stdout


class TestSearchContextsCommand:
    """Test search contexts CLI command."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_search_contexts_success(self):
        """Test successful context search."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            contexts = [
                Context(id="ctx-1", data={"name": "test user", "email": "test@example.com"}, tenant_id="test-tenant"),
                Context(id="ctx-2", data={"name": "other user", "email": "other@example.com"}, tenant_id="test-tenant"),
                Context(id="ctx-3", data={"title": "test document"}, tenant_id="test-tenant")
            ]
            mock_service.list.return_value = Ok(contexts)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "search", "test"
            ])
            
            assert result.exit_code == 0
            assert "Search Results: 'test'" in result.stdout
            assert "ctx-1" in result.stdout  # Contains "test user"
            assert "ctx-3" in result.stdout  # Contains "test document"
            # ctx-2 should not be in results as it doesn't contain "test"
    
    def test_search_contexts_no_results(self):
        """Test context search with no results."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            contexts = [
                Context(id="ctx-1", data={"name": "user"}, tenant_id="test-tenant")
            ]
            mock_service.list.return_value = Ok(contexts)
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "search", "nonexistent"
            ])
            
            assert result.exit_code == 0
            assert "No contexts found matching 'nonexistent'" in result.stdout
    
    def test_search_contexts_error(self):
        """Test context search with error."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_service.list.return_value = Err("Search error")
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "search", "test"
            ])
            
            assert result.exit_code == 1
            assert "Search failed" in result.stdout


class TestExportContextCommand:
    """Test export context CLI command."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_export_context_json_success(self):
        """Test successful context export to JSON."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_file_path = Path(tmpdir) / "export.json"
            with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
                mock_cmp = Mock()
                mock_service = AsyncMock()
                mock_context = Context(
                    id="ctx-123",
                    data={"key": "value"},
                    tenant_id="test-tenant",
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )
                mock_service.get.return_value = Ok(mock_context)
                mock_cmp.services.get_service.return_value = mock_service
                mock_get_client.return_value = mock_cmp

                result = self.runner.invoke(context_app, [
                    "export", "ctx-123",
                    "--output", str(tmp_file_path),
                    "--format", "json"
                ])

                assert result.exit_code == 0
                assert "Context exported to:" in result.stdout
                assert str(tmp_file_path) in result.stdout

                # Verify file content
                content = tmp_file_path.read_text()
                data = json.loads(content)
                assert data["id"] == "ctx-123"
                assert data["data"]["key"] == "value"

    def test_export_context_yaml_success(self):
        """Test successful context export to YAML."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_file_path = Path(tmpdir) / "export.yaml"
            with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
                mock_cmp = Mock()
                mock_service = AsyncMock()
                mock_context = Context(
                    id="ctx-123",
                    data={"key": "value"},
                    tenant_id="test-tenant",
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )
                mock_service.get.return_value = Ok(mock_context)
                mock_cmp.services.get_service.return_value = mock_service
                mock_get_client.return_value = mock_cmp

                with patch('yaml.dump', return_value="id: ctx-123\ndata:\n  key: value\n") as mock_yaml:
                    result = self.runner.invoke(context_app, [
                        "export", "ctx-123",
                        "--output", str(tmp_file_path),
                        "--format", "yaml"
                    ])

                    assert result.exit_code == 0
                    assert "Context exported to:" in result.stdout
                    assert str(tmp_file_path) in result.stdout
                    mock_yaml.assert_called_once()

                    # Verify file content
                    content = tmp_file_path.read_text()
                    assert "id: ctx-123" in content
    
    def test_export_context_not_found(self):
        """Test context export when context not found."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_service = AsyncMock()
            mock_service.get.return_value = Err("Not found")
            mock_cmp.services.get_service.return_value = mock_service
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "export", "nonexistent",
                "--output", "output.json"
            ])
            
            assert result.exit_code == 1
            assert "Context not found" in result.stdout
    
    def test_export_context_error(self):
        """Test context export with error."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_get_client.side_effect = Exception("Service error")
            
            result = self.runner.invoke(context_app, [
                "export", "ctx-123",
                "--output", "output.json"
            ])
            
            assert result.exit_code == 1
            assert "Error: Service error" in result.stdout


class TestCLIIntegration:
    """Test CLI integration scenarios."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_context_app_help(self):
        """Test context app help command."""
        result = self.runner.invoke(context_app, ["--help"])
        
        assert result.exit_code == 0
        assert "Context management commands" in result.stdout
        assert "create" in result.stdout
        assert "get" in result.stdout
        assert "list" in result.stdout
        assert "update" in result.stdout
        assert "delete" in result.stdout
        assert "search" in result.stdout
        assert "export" in result.stdout
    
    def test_create_command_help(self):
        """Test create command help."""
        result = self.runner.invoke(context_app, ["create", "--help"])
        
        assert result.exit_code == 0
        assert "Create a new context" in result.stdout
        assert "--data" in result.stdout
        assert "--schema" in result.stdout
        assert "--tenant" in result.stdout
        assert "--metadata" in result.stdout
    
    def test_get_command_help(self):
        """Test get command help."""
        result = self.runner.invoke(context_app, ["get", "--help"])
        
        assert result.exit_code == 0
        assert "Get a context by ID" in result.stdout
        assert "--format" in result.stdout
        assert "--tenant" in result.stdout
    
    def test_list_command_help(self):
        """Test list command help."""
        result = self.runner.invoke(context_app, ["list", "--help"])
        
        assert result.exit_code == 0
        assert "List contexts" in result.stdout
        assert "--limit" in result.stdout
        assert "--schema" in result.stdout
    
    def test_update_command_help(self):
        """Test update command help."""
        result = self.runner.invoke(context_app, ["update", "--help"])
        
        assert result.exit_code == 0
        assert "Update a context" in result.stdout
        assert "--data" in result.stdout
    
    def test_delete_command_help(self):
        """Test delete command help."""
        result = self.runner.invoke(context_app, ["delete", "--help"])
        
        assert result.exit_code == 0
        assert "Delete a context" in result.stdout
        assert "--yes" in result.stdout
    
    def test_search_command_help(self):
        """Test search command help."""
        result = self.runner.invoke(context_app, ["search", "--help"])
        
        assert result.exit_code == 0
        assert "Search contexts" in result.stdout
        assert "--limit" in result.stdout
    
    def test_export_command_help(self):
        """Test export command help."""
        result = self.runner.invoke(context_app, ["export", "--help"])
        
        assert result.exit_code == 0
        assert "Export a context to file" in result.stdout
        assert "--output" in result.stdout
        assert "--format" in result.stdout


class TestErrorHandling:
    """Test error handling scenarios."""
    
    def setup_method(self):
        """Set up test runner."""
        self.runner = CliRunner()
    
    def test_missing_required_arguments(self):
        """Test commands with missing required arguments."""
        # Create without data
        result = self.runner.invoke(context_app, ["create"])
        assert result.exit_code != 0
        
        # Get without context ID
        result = self.runner.invoke(context_app, ["get"])
        assert result.exit_code != 0
        
        # Update without context ID
        result = self.runner.invoke(context_app, ["update"])
        assert result.exit_code != 0
        
        # Delete without context ID
        result = self.runner.invoke(context_app, ["delete"])
        assert result.exit_code != 0
        
        # Search without query
        result = self.runner.invoke(context_app, ["search"])
        assert result.exit_code != 0
        
        # Export without context ID
        result = self.runner.invoke(context_app, ["export"])
        assert result.exit_code != 0
    
    def test_invalid_command(self):
        """Test invalid command."""
        result = self.runner.invoke(context_app, ["invalid-command"])
        assert result.exit_code != 0
    
    def test_config_file_handling(self):
        """Test config file parameter handling."""
        with patch('cmp.cli.context_commands.get_cmp_client') as mock_get_client:
            mock_cmp = Mock()
            mock_builder = Mock()
            mock_builder.with_data.return_value = mock_builder
            mock_builder.create = AsyncMock(return_value="ctx-123")
            mock_cmp.context.return_value = mock_builder
            mock_get_client.return_value = mock_cmp
            
            result = self.runner.invoke(context_app, [
                "create",
                "--data", '{"key": "value"}',
                "--config", "custom-config.yaml"
            ])
            
            assert result.exit_code == 0
            mock_get_client.assert_called_once_with("default", "custom-config.yaml")