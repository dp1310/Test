"""
Tests for knowledge registry.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone

from cmp.registries.knowledge_registry import (
    KnowledgeRegistry, KnowledgeSource, KnowledgeItem, SearchResult,
    KnowledgeType, KnowledgeNotFoundError
)
from cmp.registries.schema_registry import RegistryError
from cmp.registries.persistence import InMemoryBackend, PersistenceError
from cmp.core.result import Ok, Err


class TestKnowledgeType:
    """Test KnowledgeType enum"""
    
    def test_knowledge_type_values(self):
        """Test all knowledge type values"""
        assert KnowledgeType.DOCUMENT == "document"
        assert KnowledgeType.EMBEDDING == "embedding"
        assert KnowledgeType.API == "api"
        assert KnowledgeType.DATABASE == "database"
        assert KnowledgeType.GRAPH == "graph"


class TestKnowledgeSource:
    """Test KnowledgeSource dataclass"""
    
    def test_knowledge_source_creation(self):
        """Test creating a knowledge source"""
        source = KnowledgeSource(
            source_id="test_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Test Source",
            description="A test knowledge source",
            config={"path": "/test"},
            metadata={"version": "1.0"},
            created_at="2023-01-01T00:00:00Z"
        )
        
        assert source.source_id == "test_source"
        assert source.source_type == KnowledgeType.DOCUMENT
        assert source.name == "Test Source"
        assert source.description == "A test knowledge source"
        assert source.config == {"path": "/test"}
        assert source.metadata == {"version": "1.0"}
        assert source.created_at == "2023-01-01T00:00:00Z"
        assert source.indexed is False
        assert source.indexed_at is None
    
    def test_knowledge_source_with_indexed(self):
        """Test knowledge source with indexed fields"""
        source = KnowledgeSource(
            source_id="indexed_source",
            source_type=KnowledgeType.EMBEDDING,
            name="Indexed Source",
            description="An indexed source",
            config={},
            metadata={},
            created_at="2023-01-01T00:00:00Z",
            indexed=True,
            indexed_at="2023-01-01T01:00:00Z"
        )
        
        assert source.indexed is True
        assert source.indexed_at == "2023-01-01T01:00:00Z"


class TestKnowledgeItem:
    """Test KnowledgeItem dataclass"""
    
    def test_knowledge_item_creation(self):
        """Test creating a knowledge item"""
        item = KnowledgeItem(
            item_id="item_1",
            source_id="source_1",
            content="Test content",
            metadata={"type": "text"}
        )
        
        assert item.item_id == "item_1"
        assert item.source_id == "source_1"
        assert item.content == "Test content"
        assert item.metadata == {"type": "text"}
        assert item.score == 1.0
        assert item.embedding is None
    
    def test_knowledge_item_with_embedding(self):
        """Test knowledge item with embedding"""
        embedding = [0.1, 0.2, 0.3]
        item = KnowledgeItem(
            item_id="item_2",
            source_id="source_1",
            content="Embedded content",
            metadata={},
            score=0.8,
            embedding=embedding
        )
        
        assert item.score == 0.8
        assert item.embedding == embedding


class TestSearchResult:
    """Test SearchResult dataclass"""
    
    def test_search_result_creation(self):
        """Test creating a search result"""
        items = [
            KnowledgeItem("item_1", "source_1", "content 1", {}),
            KnowledgeItem("item_2", "source_1", "content 2", {})
        ]
        
        result = SearchResult(
            query="test query",
            total_results=2,
            items=items,
            took_ms=150
        )
        
        assert result.query == "test query"
        assert result.total_results == 2
        assert len(result.items) == 2
        assert result.took_ms == 150


class TestKnowledgeRegistry:
    """Test KnowledgeRegistry class"""
    
    @pytest.fixture
    def registry(self):
        """Create a knowledge registry with in-memory backend"""
        backend = InMemoryBackend()
        return KnowledgeRegistry(backend=backend, cache_enabled=True)
    
    @pytest.fixture
    def sample_source(self):
        """Create a sample knowledge source"""
        return KnowledgeSource(
            source_id="test_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Test Source",
            description="A test knowledge source",
            config={"path": "/test"},
            metadata={"version": "1.0"},
            created_at=datetime.now(timezone.utc).isoformat()
        )
    
    @pytest.fixture
    def sample_item(self):
        """Create a sample knowledge item"""
        return KnowledgeItem(
            item_id="test_item",
            source_id="test_source",
            content="This is test content for searching",
            metadata={"type": "text", "category": "test"}
        )
    
    def test_registry_initialization(self):
        """Test registry initialization"""
        registry = KnowledgeRegistry()
        assert registry.backend is not None
        assert registry.cache_enabled is True
        assert registry._cache is not None
    
    def test_registry_initialization_no_cache(self):
        """Test registry initialization without cache"""
        registry = KnowledgeRegistry(cache_enabled=False)
        assert registry.cache_enabled is False
        assert registry._cache is None
    
    def test_make_source_key(self, registry):
        """Test source key generation"""
        key = registry._make_source_key("test_source")
        assert key == "knowledge:source:test_source"
    
    def test_make_item_key(self, registry):
        """Test item key generation"""
        key = registry._make_item_key("test_source", "test_item")
        assert key == "knowledge:item:test_source:test_item"
    
    @pytest.mark.asyncio
    async def test_register_knowledge_success(self, registry, sample_source):
        """Test successful knowledge source registration"""
        result = await registry.register_knowledge(sample_source)
        
        assert result.is_ok()
        
        # Verify source was saved
        get_result = await registry.get_source("test_source")
        assert get_result.is_ok()
        
        retrieved_source = get_result.unwrap()
        assert retrieved_source.source_id == sample_source.source_id
        assert retrieved_source.name == sample_source.name
    
    @pytest.mark.asyncio
    async def test_register_knowledge_backend_error(self, sample_source):
        """Test knowledge registration with backend error"""
        mock_backend = AsyncMock()
        mock_backend.save.return_value = Err(PersistenceError("Save failed"))
        
        registry = KnowledgeRegistry(backend=mock_backend)
        result = await registry.register_knowledge(sample_source)
        
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_get_source_success(self, registry, sample_source):
        """Test successful source retrieval"""
        # Register source first
        await registry.register_knowledge(sample_source)
        
        result = await registry.get_source("test_source")
        
        assert result.is_ok()
        source = result.unwrap()
        assert source.source_id == "test_source"
        assert source.name == "Test Source"
    
    @pytest.mark.asyncio
    async def test_get_source_not_found(self, registry):
        """Test source retrieval when not found"""
        result = await registry.get_source("nonexistent_source")
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), KnowledgeNotFoundError)
    
    @pytest.mark.asyncio
    async def test_get_source_with_cache(self, registry, sample_source):
        """Test source retrieval with caching"""
        # Register source
        await registry.register_knowledge(sample_source)
        
        # First retrieval (from backend)
        result1 = await registry.get_source("test_source")
        assert result1.is_ok()
        
        # Second retrieval (from cache)
        result2 = await registry.get_source("test_source")
        assert result2.is_ok()
        
        # Should be the same object from cache
        assert result1.unwrap().source_id == result2.unwrap().source_id
    
    @pytest.mark.asyncio
    async def test_add_knowledge_item_success(self, registry, sample_source, sample_item):
        """Test successful knowledge item addition"""
        # Register source first
        await registry.register_knowledge(sample_source)
        
        result = await registry.add_knowledge_item(sample_item)
        
        assert result.is_ok()
        
        # Verify item was saved
        get_result = await registry.get_knowledge("test_source", "test_item")
        assert get_result.is_ok()
        
        retrieved_item = get_result.unwrap()
        assert retrieved_item.item_id == sample_item.item_id
        assert retrieved_item.content == sample_item.content
    
    @pytest.mark.asyncio
    async def test_add_knowledge_item_source_not_found(self, registry, sample_item):
        """Test adding item when source doesn't exist"""
        result = await registry.add_knowledge_item(sample_item)
        
        assert result.is_err()
        assert "not found" in str(result.unwrap_err())
    
    @pytest.mark.asyncio
    async def test_get_knowledge_success(self, registry, sample_source, sample_item):
        """Test successful knowledge item retrieval"""
        # Setup
        await registry.register_knowledge(sample_source)
        await registry.add_knowledge_item(sample_item)
        
        result = await registry.get_knowledge("test_source", "test_item")
        
        assert result.is_ok()
        item = result.unwrap()
        assert item.item_id == "test_item"
        assert item.content == "This is test content for searching"
    
    @pytest.mark.asyncio
    async def test_get_knowledge_not_found(self, registry):
        """Test knowledge item retrieval when not found"""
        result = await registry.get_knowledge("nonexistent_source", "nonexistent_item")
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), KnowledgeNotFoundError)
    
    @pytest.mark.asyncio
    async def test_search_success(self, registry, sample_source, sample_item):
        """Test successful search"""
        # Setup
        await registry.register_knowledge(sample_source)
        await registry.add_knowledge_item(sample_item)
        
        result = await registry.search("test content")
        
        assert result.is_ok()
        search_result = result.unwrap()
        assert search_result.query == "test content"
        assert search_result.total_results == 1
        assert len(search_result.items) == 1
        assert search_result.items[0].item_id == "test_item"
        assert search_result.took_ms >= 0
    
    @pytest.mark.asyncio
    async def test_search_with_filters(self, registry, sample_source, sample_item):
        """Test search with filters"""
        # Setup
        await registry.register_knowledge(sample_source)
        await registry.add_knowledge_item(sample_item)
        
        # Add another item from different source
        other_source = KnowledgeSource(
            source_id="other_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Other Source",
            description="Another source",
            config={},
            metadata={},
            created_at=datetime.now(timezone.utc).isoformat()
        )
        other_item = KnowledgeItem(
            item_id="other_item",
            source_id="other_source",
            content="This is test content from other source",
            metadata={}
        )
        
        await registry.register_knowledge(other_source)
        await registry.add_knowledge_item(other_item)
        
        # Search with source filter
        result = await registry.search(
            "test content",
            filters={"source_id": "test_source"}
        )
        
        assert result.is_ok()
        search_result = result.unwrap()
        assert search_result.total_results == 1
        assert search_result.items[0].source_id == "test_source"
    
    @pytest.mark.asyncio
    async def test_search_no_results(self, registry, sample_source, sample_item):
        """Test search with no matching results"""
        # Setup
        await registry.register_knowledge(sample_source)
        await registry.add_knowledge_item(sample_item)
        
        result = await registry.search("nonexistent query")
        
        assert result.is_ok()
        search_result = result.unwrap()
        assert search_result.total_results == 0
        assert len(search_result.items) == 0
    
    @pytest.mark.asyncio
    async def test_search_with_limit(self, registry, sample_source):
        """Test search with result limit"""
        # Setup
        await registry.register_knowledge(sample_source)
        
        # Add multiple items
        for i in range(5):
            item = KnowledgeItem(
                item_id=f"item_{i}",
                source_id="test_source",
                content=f"test content {i}",
                metadata={}
            )
            await registry.add_knowledge_item(item)
        
        result = await registry.search("test content", limit=3)
        
        assert result.is_ok()
        search_result = result.unwrap()
        assert len(search_result.items) == 3
    
    @pytest.mark.asyncio
    async def test_search_backend_error(self, sample_source):
        """Test search with backend error"""
        mock_backend = AsyncMock()
        mock_backend.list.return_value = Err(PersistenceError("List failed"))
        
        registry = KnowledgeRegistry(backend=mock_backend)
        result = await registry.search("test")
        
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_mark_indexed_success(self, registry, sample_source):
        """Test marking source as indexed"""
        # Register source
        await registry.register_knowledge(sample_source)
        
        result = await registry.mark_indexed("test_source")
        
        assert result.is_ok()
        
        # Verify source is marked as indexed
        get_result = await registry.get_source("test_source")
        assert get_result.is_ok()
        
        source = get_result.unwrap()
        assert source.indexed is True
        assert source.indexed_at is not None
    
    @pytest.mark.asyncio
    async def test_mark_indexed_source_not_found(self, registry):
        """Test marking nonexistent source as indexed"""
        result = await registry.mark_indexed("nonexistent_source")
        
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_list_sources_success(self, registry):
        """Test listing all sources"""
        # Add multiple sources
        sources = []
        for i in range(3):
            source = KnowledgeSource(
                source_id=f"source_{i}",
                source_type=KnowledgeType.DOCUMENT,
                name=f"Source {i}",
                description=f"Description {i}",
                config={},
                metadata={},
                created_at=datetime.now(timezone.utc).isoformat()
            )
            sources.append(source)
            await registry.register_knowledge(source)
        
        result = await registry.list_sources()
        
        assert result.is_ok()
        retrieved_sources = result.unwrap()
        assert len(retrieved_sources) == 3
        
        # Should be sorted by source_id
        source_ids = [s.source_id for s in retrieved_sources]
        assert source_ids == ["source_0", "source_1", "source_2"]
    
    @pytest.mark.asyncio
    async def test_list_sources_empty(self, registry):
        """Test listing sources when none exist"""
        result = await registry.list_sources()
        
        assert result.is_ok()
        sources = result.unwrap()
        assert len(sources) == 0
    
    @pytest.mark.asyncio
    async def test_list_sources_backend_error(self):
        """Test listing sources with backend error"""
        mock_backend = AsyncMock()
        mock_backend.list.return_value = Err(PersistenceError("List failed"))
        
        registry = KnowledgeRegistry(backend=mock_backend)
        result = await registry.list_sources()
        
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_delete_source_success(self, registry, sample_source, sample_item):
        """Test successful source deletion"""
        # Setup
        await registry.register_knowledge(sample_source)
        await registry.add_knowledge_item(sample_item)
        
        result = await registry.delete_source("test_source", delete_items=True)
        
        assert result.is_ok()
        
        # Verify source is deleted
        get_result = await registry.get_source("test_source")
        assert get_result.is_err()
        
        # Verify item is also deleted
        item_result = await registry.get_knowledge("test_source", "test_item")
        assert item_result.is_err()
    
    @pytest.mark.asyncio
    async def test_delete_source_without_items(self, registry, sample_source, sample_item):
        """Test source deletion without deleting items"""
        # Setup
        await registry.register_knowledge(sample_source)
        await registry.add_knowledge_item(sample_item)
        
        result = await registry.delete_source("test_source", delete_items=False)
        
        assert result.is_ok()
        
        # Verify source is deleted
        get_result = await registry.get_source("test_source")
        assert get_result.is_err()
        
        # Item should still exist (though orphaned)
        item_result = await registry.get_knowledge("test_source", "test_item")
        assert item_result.is_ok()
    
    @pytest.mark.asyncio
    async def test_delete_source_not_found(self, registry):
        """Test deleting nonexistent source"""
        result = await registry.delete_source("nonexistent_source")
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), KnowledgeNotFoundError)
    
    @pytest.mark.asyncio
    async def test_delete_source_backend_error(self, sample_source):
        """Test source deletion with backend error"""
        mock_backend = AsyncMock()
        mock_backend.list.return_value = Ok([])  # No items to delete
        mock_backend.delete.return_value = Err(PersistenceError("Delete failed"))
        
        registry = KnowledgeRegistry(backend=mock_backend)
        result = await registry.delete_source("test_source")
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), KnowledgeNotFoundError)
    
    @pytest.mark.asyncio
    async def test_close_registry(self, registry):
        """Test closing registry"""
        # Add some data to cache
        sample_source = KnowledgeSource(
            source_id="test_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Test",
            description="Test",
            config={},
            metadata={},
            created_at=datetime.now(timezone.utc).isoformat()
        )
        await registry.register_knowledge(sample_source)
        await registry.get_source("test_source")  # This should cache it
        
        # Verify cache has data
        assert len(registry._cache) > 0
        
        # Close registry
        await registry.close()
        
        # Verify cache is cleared
        assert len(registry._cache) == 0


class TestKnowledgeRegistryEdgeCases:
    """Test edge cases and error scenarios"""
    
    @pytest.mark.asyncio
    async def test_search_scoring(self):
        """Test search result scoring"""
        registry = KnowledgeRegistry()
        
        # Create source
        source = KnowledgeSource(
            source_id="test_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Test Source",
            description="Test",
            config={},
            metadata={},
            created_at=datetime.now(timezone.utc).isoformat()
        )
        await registry.register_knowledge(source)
        
        # Add items with different relevance
        item1 = KnowledgeItem(
            item_id="item1",
            source_id="test_source",
            content="python programming",  # Single occurrence
            metadata={}
        )
        item2 = KnowledgeItem(
            item_id="item2",
            source_id="test_source",
            content="python python programming python",  # Multiple occurrences
            metadata={}
        )
        
        await registry.add_knowledge_item(item1)
        await registry.add_knowledge_item(item2)
        
        result = await registry.search("python")
        
        assert result.is_ok()
        search_result = result.unwrap()
        assert len(search_result.items) == 2
        
        # Item2 should have higher score due to more occurrences
        assert search_result.items[0].score > search_result.items[1].score
    
    @pytest.mark.asyncio
    async def test_cache_invalidation_on_register(self):
        """Test cache invalidation when registering source"""
        registry = KnowledgeRegistry(cache_enabled=True)
        
        source = KnowledgeSource(
            source_id="test_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Test Source",
            description="Test",
            config={},
            metadata={},
            created_at=datetime.now(timezone.utc).isoformat()
        )
        
        # Register and cache
        await registry.register_knowledge(source)
        await registry.get_source("test_source")  # Cache it
        
        # Register again (should invalidate cache)
        updated_source = KnowledgeSource(
            source_id="test_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Updated Source",  # Changed name
            description="Test",
            config={},
            metadata={},
            created_at=datetime.now(timezone.utc).isoformat()
        )
        await registry.register_knowledge(updated_source)
        
        # Get source should return updated version
        result = await registry.get_source("test_source")
        assert result.is_ok()
        assert result.unwrap().name == "Updated Source"
    
    @pytest.mark.asyncio
    async def test_cache_invalidation_on_delete(self):
        """Test cache invalidation when deleting source"""
        registry = KnowledgeRegistry(cache_enabled=True)
        
        source = KnowledgeSource(
            source_id="test_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Test Source",
            description="Test",
            config={},
            metadata={},
            created_at=datetime.now(timezone.utc).isoformat()
        )
        
        # Register and cache
        await registry.register_knowledge(source)
        await registry.get_source("test_source")  # Cache it
        
        # Delete source
        await registry.delete_source("test_source")
        
        # Should not be found
        result = await registry.get_source("test_source")
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_registry_without_cache(self):
        """Test registry operations without caching"""
        registry = KnowledgeRegistry(cache_enabled=False)
        
        source = KnowledgeSource(
            source_id="test_source",
            source_type=KnowledgeType.DOCUMENT,
            name="Test Source",
            description="Test",
            config={},
            metadata={},
            created_at=datetime.now(timezone.utc).isoformat()
        )
        
        # Register source
        result = await registry.register_knowledge(source)
        assert result.is_ok()
        
        # Get source (should work without cache)
        get_result = await registry.get_source("test_source")
        assert get_result.is_ok()
        assert get_result.unwrap().name == "Test Source"


class TestKnowledgeNotFoundError:
    """Test KnowledgeNotFoundError exception"""
    
    def test_knowledge_not_found_error_inheritance(self):
        """Test that KnowledgeNotFoundError inherits from RegistryError"""
        error = KnowledgeNotFoundError("Test error")
        assert isinstance(error, RegistryError)
        assert str(error) == "Test error"