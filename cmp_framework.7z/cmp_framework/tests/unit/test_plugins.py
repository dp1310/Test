
import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from cmp.plugins.base import Plugin, hook, PluginMetadata
from cmp.plugins.registry import PluginRegistry

# Mock Plugin
class MyPlugin(Plugin):
    name = "test-plugin"
    version = "1.0.0"
    
    def on_init(self):
        self.initialized = True
        
    def on_start(self):
        self.started = True
        
    def on_stop(self):
        self.started = False
        
    @hook("test.event")
    async def my_hook(self, data):
        data["processed"] = True

def test_plugin_base():
    p = MyPlugin()
    p.configure({"key": "value"})
    assert p._config["key"] == "value"
    
    meta = p.get_metadata()
    assert meta.name == "test-plugin"
    assert meta.version == "1.0.0"
    
    assert not p.enabled
    p.enable()
    assert p.enabled
    p.disable()
    assert not p.enabled

@pytest.mark.asyncio
async def test_plugin_registry():
    registry = PluginRegistry()
    
    # Mock loader
    mock_loader = MagicMock()
    mock_loader.discover_plugins = AsyncMock(return_value=["test-plugin"])
    mock_loader.load_plugin = AsyncMock(return_value=MyPlugin())
    mock_loader.list_discovered = MagicMock(return_value=["test-plugin"])
    registry._loader = mock_loader
    
    # Discover
    discovered = await registry.discover("./plugins")
    assert "test-plugin" in discovered
    
    # Load
    loaded = await registry.load("test-plugin")
    assert loaded is True
    assert registry.get_plugin("test-plugin") is not None
    
    # Start
    await registry.start("test-plugin")
    plugin = registry.get_plugin("test-plugin")
    assert plugin.started is True
    assert plugin.enabled is True
    
    # Trigger Hook
    data = {}
    await registry.trigger_hook("test.event", data)
    assert data.get("processed") is True
    
    # Stop
    await registry.stop("test-plugin")
    assert plugin.started is False
    assert plugin.enabled is False
    
    # Load All
    count = await registry.load_all()
    assert count == 1
    
    # Start All / Stop All
    await registry.start_all()
    assert plugin.started is True
    await registry.stop_all()
    assert plugin.started is False
