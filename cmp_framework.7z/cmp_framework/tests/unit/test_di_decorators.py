"""
Tests for dependency injection decorators.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone

from cmp.di.decorators import (
    context, knowledge, envelope,
    set_service_container, get_service_container,
    _service_container
)
from cmp.core.models import Context, ContextEnvelope, Schema, Policy, Provenance, Metadata
from cmp.core.result import Ok, Err


class TestServiceContainer:
    """Test service container management"""
    
    def test_set_service_container(self):
        """Test setting service container"""
        container = MagicMock()
        set_service_container(container)
        assert get_service_container() is container
    
    def test_get_service_container_not_initialized(self):
        """Test getting service container when not initialized"""
        # Reset global container
        import cmp.di.decorators
        cmp.di.decorators._service_container = None
        
        with pytest.raises(RuntimeError, match="Service container not initialized"):
            get_service_container()
    
    def test_get_service_container_initialized(self):
        """Test getting initialized service container"""
        container = MagicMock()
        set_service_container(container)
        result = get_service_container()
        assert result is container


class TestContextDecorator:
    """Test context decorator"""
    
    @pytest.fixture
    def mock_container(self):
        """Mock service container"""
        container = MagicMock()
        container.tenant_id = "test_tenant"
        
        # Mock context service
        context_service = AsyncMock()
        container.get_service.return_value = context_service
        
        # Mock current context
        current_context = Context(
            id="ctx_123",
            data={"key": "value"},
            tenant_id="test_tenant"
        )
        container.get_current_context.return_value = current_context
        
        set_service_container(container)
        return container, context_service, current_context
    
    @pytest.mark.asyncio
    async def test_context_decorator_with_context_id(self, mock_container):
        """Test context decorator with specific context ID"""
        container, context_service, _ = mock_container
        
        # Mock successful context retrieval
        test_context = Context(
            id="specific_ctx",
            data={"specific": "data"},
            tenant_id="test_tenant"
        )
        context_service.get.return_value = Ok(test_context)
        
        @context(context_id="specific_ctx")
        async def test_func(input_data: dict, context: Context):
            return context.data
        
        result = await test_func({"test": "input"})
        
        assert result == {"specific": "data"}
        context_service.get.assert_called_once_with("specific_ctx")
    
    @pytest.mark.asyncio
    async def test_context_decorator_with_context_id_error(self, mock_container):
        """Test context decorator with context ID retrieval error"""
        container, context_service, _ = mock_container
        
        # Mock failed context retrieval
        context_service.get.return_value = Err("Context not found")
        
        @context(context_id="missing_ctx")
        async def test_func(input_data: dict, context: Context):
            return context.data
        
        with pytest.raises(RuntimeError, match="Failed to get context: Context not found"):
            await test_func({"test": "input"})
    
    @pytest.mark.asyncio
    async def test_context_decorator_with_schema(self, mock_container):
        """Test context decorator with schema search"""
        container, context_service, _ = mock_container
        
        # Mock schema search
        schema_context = Context(
            id="schema_ctx",
            data={"schema": "data"},
            tenant_id="test_tenant",
            schema="user_profile"
        )
        
        async def mock_search(*args, **kwargs):
            yield schema_context
        
        context_service.search = mock_search
        
        @context(schema="user_profile")
        async def test_func(input_data: dict, context: Context):
            return context.data
        
        result = await test_func({"test": "input"})
        
        assert result == {"schema": "data"}
    
    @pytest.mark.asyncio
    async def test_context_decorator_with_schema_not_found(self, mock_container):
        """Test context decorator with schema not found"""
        container, context_service, _ = mock_container
        
        # Mock empty search results
        async def mock_search(*args, **kwargs):
            return
            yield  # Make it an async generator
        
        context_service.search = mock_search
        
        @context(schema="missing_schema")
        async def test_func(input_data: dict, context: Context):
            return context.data
        
        with pytest.raises(RuntimeError, match="No context found for schema: missing_schema"):
            await test_func({"test": "input"})
    
    @pytest.mark.asyncio
    async def test_context_decorator_current_context(self, mock_container):
        """Test context decorator using current context"""
        container, context_service, current_context = mock_container
        
        @context()
        async def test_func(input_data: dict, context: Context):
            return context.data
        
        result = await test_func({"test": "input"})
        
        assert result == {"key": "value"}
        container.get_current_context.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_context_decorator_preserves_args_kwargs(self, mock_container):
        """Test context decorator preserves original args and kwargs"""
        container, context_service, current_context = mock_container
        
        @context()
        async def test_func(self, input_data: dict, extra_param: str = "default", context: Context = None):
            return {
                "self": self,
                "input_data": input_data,
                "extra_param": extra_param,
                "context_id": context.id
            }
        
        test_self = "test_self"
        result = await test_func(test_self, {"test": "input"}, extra_param="custom")
        
        assert result["self"] == "test_self"
        assert result["input_data"] == {"test": "input"}
        assert result["extra_param"] == "custom"
        assert result["context_id"] == "ctx_123"


class TestKnowledgeDecorator:
    """Test knowledge decorator"""
    
    @pytest.fixture
    def mock_container_knowledge(self):
        """Mock service container for knowledge tests"""
        container = MagicMock()
        container.tenant_id = "test_tenant"
        
        # Mock knowledge service
        knowledge_service = AsyncMock()
        container.get_service.return_value = knowledge_service
        
        set_service_container(container)
        return container, knowledge_service
    
    @pytest.mark.asyncio
    async def test_knowledge_decorator_success(self, mock_container_knowledge):
        """Test knowledge decorator with successful source retrieval"""
        container, knowledge_service = mock_container_knowledge
        
        # Mock knowledge source
        mock_knowledge_source = MagicMock()
        mock_knowledge_source.search = AsyncMock(return_value=["result1", "result2"])
        knowledge_service.get_source.return_value = mock_knowledge_source
        
        @knowledge(source="vector_db")
        async def test_func(query: str, knowledge):
            return await knowledge.search(query)
        
        result = await test_func("test query")
        
        assert result == ["result1", "result2"]
        knowledge_service.get_source.assert_called_once_with("vector_db", "test_tenant")
        mock_knowledge_source.search.assert_called_once_with("test query")
    
    @pytest.mark.asyncio
    async def test_knowledge_decorator_source_not_found(self, mock_container_knowledge):
        """Test knowledge decorator with source not found"""
        container, knowledge_service = mock_container_knowledge
        
        # Mock missing knowledge source
        knowledge_service.get_source.return_value = None
        
        @knowledge(source="missing_source")
        async def test_func(query: str, knowledge):
            return await knowledge.search(query)
        
        with pytest.raises(RuntimeError, match="Knowledge source not found: missing_source"):
            await test_func("test query")
    
    @pytest.mark.asyncio
    async def test_knowledge_decorator_preserves_args_kwargs(self, mock_container_knowledge):
        """Test knowledge decorator preserves original args and kwargs"""
        container, knowledge_service = mock_container_knowledge
        
        mock_knowledge_source = MagicMock()
        knowledge_service.get_source.return_value = mock_knowledge_source
        
        @knowledge(source="test_source")
        async def test_func(self, query: str, limit: int = 10, knowledge=None):
            return {
                "self": self,
                "query": query,
                "limit": limit,
                "knowledge": knowledge
            }
        
        test_self = "test_self"
        result = await test_func(test_self, "test query", limit=5)
        
        assert result["self"] == "test_self"
        assert result["query"] == "test query"
        assert result["limit"] == 5
        assert result["knowledge"] is mock_knowledge_source


class TestEnvelopeDecorator:
    """Test envelope decorator"""
    
    @pytest.fixture
    def mock_container_envelope(self):
        """Mock service container for envelope tests"""
        container = MagicMock()
        container.tenant_id = "test_tenant"
        
        # Mock context service
        context_service = AsyncMock()
        container.get_service.return_value = context_service
        
        # Mock current context
        current_context = Context(
            id="ctx_123",
            data={"key": "value"},
            tenant_id="test_tenant"
        )
        container.get_current_context.return_value = current_context
        
        set_service_container(container)
        return container, context_service, current_context
    
    @pytest.mark.asyncio
    async def test_envelope_decorator_success(self, mock_container_envelope):
        """Test envelope decorator with successful envelope retrieval"""
        container, context_service, current_context = mock_container_envelope
        
        # Mock envelope
        test_envelope = ContextEnvelope(
            id="ctx_123",
            data={"key": "value"},
            schema=Schema(name="test_schema", version="1.0", fields={}),
            policy=Policy.default(),
            provenance=Provenance.empty(),
            metadata=Metadata(tenant_id="test_tenant")
        )
        context_service.get_envelope.return_value = Ok(test_envelope)
        
        @envelope()
        async def test_func(input_data: dict, context: ContextEnvelope):
            return {
                "envelope_id": context.id,
                "schema_name": context.schema.name
            }
        
        result = await test_func({"test": "input"})
        
        assert result["envelope_id"] == "ctx_123"
        assert result["schema_name"] == "test_schema"
        context_service.get_envelope.assert_called_once_with("ctx_123")
    
    @pytest.mark.asyncio
    async def test_envelope_decorator_error(self, mock_container_envelope):
        """Test envelope decorator with envelope retrieval error"""
        container, context_service, current_context = mock_container_envelope
        
        # Mock failed envelope retrieval
        context_service.get_envelope.return_value = Err("Envelope not found")
        
        @envelope()
        async def test_func(input_data: dict, context: ContextEnvelope):
            return context.id
        
        with pytest.raises(RuntimeError, match="Failed to get envelope: Envelope not found"):
            await test_func({"test": "input"})
    
    @pytest.mark.asyncio
    async def test_envelope_decorator_preserves_args_kwargs(self, mock_container_envelope):
        """Test envelope decorator preserves original args and kwargs"""
        container, context_service, current_context = mock_container_envelope
        
        test_envelope = ContextEnvelope(
            id="ctx_123",
            data={"key": "value"},
            schema=Schema(name="test_schema", version="1.0", fields={}),
            policy=Policy.default(),
            provenance=Provenance.empty(),
            metadata=Metadata(tenant_id="test_tenant")
        )
        context_service.get_envelope.return_value = Ok(test_envelope)
        
        @envelope()
        async def test_func(self, input_data: dict, extra_param: str = "default", context: ContextEnvelope = None):
            return {
                "self": self,
                "input_data": input_data,
                "extra_param": extra_param,
                "envelope_id": context.id
            }
        
        test_self = "test_self"
        result = await test_func(test_self, {"test": "input"}, extra_param="custom")
        
        assert result["self"] == "test_self"
        assert result["input_data"] == {"test": "input"}
        assert result["extra_param"] == "custom"
        assert result["envelope_id"] == "ctx_123"


class TestDecoratorIntegration:
    """Test decorator integration scenarios"""
    
    @pytest.fixture
    def mock_full_container(self):
        """Mock complete service container"""
        container = MagicMock()
        container.tenant_id = "test_tenant"
        
        # Mock context service
        context_service = AsyncMock()
        knowledge_service = AsyncMock()
        
        def get_service(service_name):
            if service_name == 'context_service':
                return context_service
            elif service_name == 'knowledge_service':
                return knowledge_service
            return MagicMock()
        
        container.get_service.side_effect = get_service
        
        # Mock current context
        current_context = Context(
            id="ctx_123",
            data={"key": "value"},
            tenant_id="test_tenant"
        )
        container.get_current_context.return_value = current_context
        
        set_service_container(container)
        return container, context_service, knowledge_service, current_context
    
    @pytest.mark.asyncio
    async def test_multiple_decorators(self, mock_full_container):
        """Test function with multiple decorators"""
        container, context_service, knowledge_service, current_context = mock_full_container
        
        # Mock knowledge source
        mock_knowledge_source = MagicMock()
        knowledge_service.get_source.return_value = mock_knowledge_source
        
        @context()
        @knowledge(source="test_source")
        async def test_func(input_data: dict, context: Context = None, knowledge=None):
            return {
                "context_id": context.id,
                "has_knowledge": knowledge is not None
            }
        
        result = await test_func({"test": "input"})
        
        assert result["context_id"] == "ctx_123"
        assert result["has_knowledge"] is True
    
    @pytest.mark.asyncio
    async def test_decorator_with_class_method(self, mock_full_container):
        """Test decorator on class method"""
        container, context_service, knowledge_service, current_context = mock_full_container
        
        class TestAgent:
            @context()
            async def process(self, input_data: dict, context: Context = None):
                return {
                    "agent": self.__class__.__name__,
                    "context_id": context.id,
                    "input": input_data
                }
        
        agent = TestAgent()
        result = await agent.process({"test": "data"})
        
        assert result["agent"] == "TestAgent"
        assert result["context_id"] == "ctx_123"
        assert result["input"] == {"test": "data"}


class TestErrorHandling:
    """Test error handling scenarios"""
    
    @pytest.mark.asyncio
    async def test_context_decorator_no_container(self):
        """Test context decorator when no container is set"""
        # Reset global container
        import cmp.di.decorators
        cmp.di.decorators._service_container = None
        
        @context()
        async def test_func(context: Context):
            return context.id
        
        with pytest.raises(RuntimeError, match="Service container not initialized"):
            await test_func()
    
    @pytest.mark.asyncio
    async def test_knowledge_decorator_no_container(self):
        """Test knowledge decorator when no container is set"""
        # Reset global container
        import cmp.di.decorators
        cmp.di.decorators._service_container = None
        
        @knowledge(source="test")
        async def test_func(knowledge):
            return knowledge
        
        with pytest.raises(RuntimeError, match="Service container not initialized"):
            await test_func()
    
    @pytest.mark.asyncio
    async def test_envelope_decorator_no_container(self):
        """Test envelope decorator when no container is set"""
        # Reset global container
        import cmp.di.decorators
        cmp.di.decorators._service_container = None
        
        @envelope()
        async def test_func(context: ContextEnvelope):
            return context.id
        
        with pytest.raises(RuntimeError, match="Service container not initialized"):
            await test_func()


class TestDecoratorMetadata:
    """Test decorator metadata preservation"""
    
    def test_context_decorator_preserves_metadata(self):
        """Test that context decorator preserves function metadata"""
        @context()
        async def test_func(context: Context):
            """Test function docstring"""
            return context.id
        
        assert test_func.__name__ == "test_func"
        assert test_func.__doc__ == "Test function docstring"
    
    def test_knowledge_decorator_preserves_metadata(self):
        """Test that knowledge decorator preserves function metadata"""
        @knowledge(source="test")
        async def test_func(knowledge):
            """Test function docstring"""
            return knowledge
        
        assert test_func.__name__ == "test_func"
        assert test_func.__doc__ == "Test function docstring"
    
    def test_envelope_decorator_preserves_metadata(self):
        """Test that envelope decorator preserves function metadata"""
        @envelope()
        async def test_func(context: ContextEnvelope):
            """Test function docstring"""
            return context.id
        
        assert test_func.__name__ == "test_func"
        assert test_func.__doc__ == "Test function docstring"