
import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock
from cmp.services.context_service import ContextService, PolicyResult, ContextError, SchemaNotFoundError, PolicyViolationError, ContextNotFoundError
from cmp.core.models import Context, ContextEnvelope, Metadata, Schema

@pytest.fixture
def mock_service():
    # Mock store with async methods
    mock_store = MagicMock()
    mock_store.save = AsyncMock(return_value="ctx-err")
    mock_store.get = AsyncMock(return_value=None)
    mock_store.list_all = AsyncMock(return_value=[])
    mock_store.search = AsyncMock(return_value=[])
    mock_store.update = AsyncMock()
    mock_store.delete = AsyncMock(return_value=False)
    # Simple schema registry placeholder
    schema_registry = MagicMock()
    # Policy service placeholder
    policy_service = MagicMock()
    service = ContextService(store=mock_store, schema_registry=schema_registry, policy_service=policy_service)
    return service, mock_store

@pytest.mark.asyncio
async def test_create_schema_not_found(mock_service):
    service, mock_store = mock_service
    # Patch _get_schema to return None
    async def mock_get_schema(name, tenant):
        return None
    service._get_schema = mock_get_schema
    result = await service.create(data={"a": 1}, schema_name="missing", tenant_id="t1")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), SchemaNotFoundError)
    # Ensure store.save not called
    mock_store.save.assert_not_called()

@pytest.mark.asyncio
async def test_create_exception_handling(mock_service):
    service, mock_store = mock_service
    # Force exception in _get_schema
    async def mock_get_schema(name, tenant):
        raise RuntimeError("boom")
    service._get_schema = mock_get_schema
    result = await service.create(data={}, schema_name="any", tenant_id="t1")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), ContextError)

@pytest.mark.asyncio
async def test_get_policy_violation(mock_service):
    service, mock_store = mock_service
    # Mock envelope returned
    envelope = MagicMock()
    envelope.to_context.return_value = MagicMock()
    mock_store.get = AsyncMock(return_value=envelope)
    # Patch policy check to deny
    async def mock_check_policy(action, data):
        return PolicyResult(allowed=False, reason="denied")
    service._check_policy = mock_check_policy
    result = await service.get("ctx-1")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), PolicyViolationError)

@pytest.mark.asyncio
async def test_get_envelope_policy_violation(mock_service):
    service, mock_store = mock_service
    envelope = MagicMock()
    mock_store.get = AsyncMock(return_value=envelope)
    async def mock_check_policy(action, data):
        return PolicyResult(allowed=False, reason="denied")
    service._check_policy = mock_check_policy
    result = await service.get_envelope("ctx-1")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), PolicyViolationError)

@pytest.mark.asyncio
async def test_list_exception(mock_service):
    service, mock_store = mock_service
    mock_store.list_all = AsyncMock(side_effect=Exception("list fail"))
    result = await service.list()
    assert result.is_err()
    assert isinstance(result.unwrap_err(), ContextError)

@pytest.mark.asyncio
async def test_update_policy_violation(mock_service):
    service, mock_store = mock_service
    envelope = MagicMock()
    mock_store.get = AsyncMock(return_value=envelope)
    async def mock_check_policy(action, data):
        return PolicyResult(allowed=False, reason="denied")
    service._check_policy = mock_check_policy
    result = await service.update("ctx-1", {"b": 2})
    assert result.is_err()
    assert isinstance(result.unwrap_err(), PolicyViolationError)

@pytest.mark.asyncio
async def test_update_exception(mock_service):
    service, mock_store = mock_service
    envelope = MagicMock()
    mock_store.get = AsyncMock(return_value=envelope)
    # Make policy allow
    async def mock_check_policy(action, data):
        return PolicyResult(allowed=True)
    service._check_policy = mock_check_policy
    # Force exception in store.update
    mock_store.update = AsyncMock(side_effect=Exception("update fail"))
    result = await service.update("ctx-1", {"b": 2})
    assert result.is_err()
    assert isinstance(result.unwrap_err(), ContextError)

@pytest.mark.asyncio
async def test_delete_policy_violation(mock_service):
    service, mock_store = mock_service
    envelope = MagicMock()
    mock_store.get = AsyncMock(return_value=envelope)
    async def mock_check_policy(action, data):
        return PolicyResult(allowed=False, reason="denied")
    service._check_policy = mock_check_policy
    result = await service.delete("ctx-1")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), PolicyViolationError)

@pytest.mark.asyncio
async def test_delete_exception(mock_service):
    service, mock_store = mock_service
    envelope = MagicMock()
    mock_store.get = AsyncMock(return_value=envelope)
    async def mock_check_policy(action, data):
        return PolicyResult(allowed=True)
    service._check_policy = mock_check_policy
    mock_store.delete = AsyncMock(side_effect=Exception("del fail"))
    result = await service.delete("ctx-1")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), ContextError)
