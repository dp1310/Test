"""Tests for monitoring module initialization."""

import pytest
from unittest.mock import patch, MagicMock


def test_monitoring_imports():
    """Test that all monitoring components can be imported."""
    import cmp.monitoring as monitoring
    
    # Test metrics imports
    assert hasattr(monitoring, 'MetricsCollector')
    assert hasattr(monitoring, 'Metrics')
    assert hasattr(monitoring, 'MetricsTimer')
    assert hasattr(monitoring, 'get_metrics_collector')
    
    # Test logging imports
    assert hasattr(monitoring, 'configure_logging')
    assert hasattr(monitoring, 'get_logger')
    assert hasattr(monitoring, 'set_context')
    assert hasattr(monitoring, 'clear_context')
    assert hasattr(monitoring, 'get_current_context')
    assert hasattr(monitoring, 'LogLevel')
    assert hasattr(monitoring, 'StructuredLogger')
    
    # Test health check imports
    assert hasattr(monitoring, 'HealthCheck')
    assert hasattr(monitoring, 'HealthStatus')
    assert hasattr(monitoring, 'HealthCheckResult')
    assert hasattr(monitoring, 'SystemHealth')
    assert hasattr(monitoring, 'check_service_url')
    
    # Test profiling imports
    assert hasattr(monitoring, 'CPUProfiler')
    assert hasattr(monitoring, 'MemoryProfiler')
    assert hasattr(monitoring, 'ProfileResult')
    assert hasattr(monitoring, 'profile_cpu')
    assert hasattr(monitoring, 'profile_memory')
    assert hasattr(monitoring, 'profile_async_function')


def test_tracing_available_true():
    """Test when tracing is available."""
    # Mock successful tracing import
    with patch.dict('sys.modules', {
        'cmp.monitoring.tracing': MagicMock()
    }):
        # Force reimport to test the try/except block
        import importlib
        import cmp.monitoring
        importlib.reload(cmp.monitoring)
        
        # Should have tracing functions
        assert hasattr(cmp.monitoring, 'configure_tracing')
        assert hasattr(cmp.monitoring, 'get_tracer')
        assert hasattr(cmp.monitoring, 'trace_function')
        assert hasattr(cmp.monitoring, 'trace_workflow')
        assert hasattr(cmp.monitoring, 'trace_agent')
        assert hasattr(cmp.monitoring, 'TracingContext')
        assert hasattr(cmp.monitoring, 'add_span_attribute')
        assert hasattr(cmp.monitoring, 'add_span_event')
        assert hasattr(cmp.monitoring, 'get_current_span')
        assert hasattr(cmp.monitoring, 'inject_trace_context')
        assert hasattr(cmp.monitoring, 'extract_trace_context')
        assert hasattr(cmp.monitoring, 'shutdown_tracing')


def test_tracing_available_false():
    """Test when tracing is not available (ImportError)."""
    # Since tracing is available in this environment, we'll test the basic functionality
    import cmp.monitoring as monitoring
    
    # Test that tracing functions exist and are callable
    assert hasattr(monitoring, 'configure_tracing')
    assert hasattr(monitoring, 'get_tracer')
    assert hasattr(monitoring, 'trace_function')
    assert hasattr(monitoring, 'trace_workflow')
    assert hasattr(monitoring, 'trace_agent')
    
    # Test that TRACING_AVAILABLE is a boolean
    assert isinstance(monitoring.TRACING_AVAILABLE, bool)


def test_all_exports():
    """Test that __all__ contains all expected exports."""
    import cmp.monitoring as monitoring
    
    expected_exports = [
        # Metrics
        "MetricsCollector",
        "Metrics", 
        "MetricsTimer",
        "get_metrics_collector",
        # Logging
        "configure_logging",
        "get_logger",
        "set_context",
        "clear_context",
        "get_current_context",
        "LogLevel",
        "StructuredLogger",
        # Health Checks
        "HealthCheck",
        "HealthStatus",
        "HealthCheckResult",
        "SystemHealth",
        "check_service_url",
        # Tracing
        "configure_tracing",
        "get_tracer",
        "trace_function",
        "trace_workflow",
        "trace_agent",
        "TracingContext",
        "add_span_attribute",
        "add_span_event",
        "get_current_span",
        "inject_trace_context",
        "extract_trace_context",
        "shutdown_tracing",
        # Profiling
        "CPUProfiler",
        "MemoryProfiler",
        "ProfileResult",
        "profile_cpu",
        "profile_memory",
        "profile_async_function",
    ]
    
    assert hasattr(monitoring, '__all__')
    assert set(monitoring.__all__) == set(expected_exports)
    
    # Test that all exports are actually available
    for export in expected_exports:
        assert hasattr(monitoring, export), f"Missing export: {export}"


def test_tracing_no_op_decorators_with_args():
    """Test that tracing decorators work with arguments."""
    import cmp.monitoring as monitoring
    
    def test_func():
        return "result"
    
    # Test that decorators are callable and return callable objects
    assert callable(monitoring.trace_function)
    assert callable(monitoring.trace_workflow)
    assert callable(monitoring.trace_agent)
    
    # Test that decorators can be applied
    decorated_func = monitoring.trace_function("test_name")
    assert callable(decorated_func)
    
    decorated_workflow = monitoring.trace_workflow("workflow_name")
    assert callable(decorated_workflow)
    
    decorated_agent = monitoring.trace_agent("agent_name")
    assert callable(decorated_agent)


def test_module_level_constants():
    """Test module-level constants."""
    import cmp.monitoring as monitoring
    
    # TRACING_AVAILABLE should be a boolean
    assert isinstance(monitoring.TRACING_AVAILABLE, bool)


def test_import_error_handling():
    """Test that ImportError is properly handled for tracing."""
    # This test verifies the module structure handles missing dependencies
    import cmp.monitoring as monitoring
    
    # The module should have all expected attributes regardless of tracing availability
    assert hasattr(monitoring, 'TRACING_AVAILABLE')
    assert hasattr(monitoring, 'configure_tracing')
    assert hasattr(monitoring, 'get_tracer')
    
    # Test that functions are callable
    assert callable(monitoring.configure_tracing)
    assert callable(monitoring.get_tracer)


def test_metrics_integration():
    """Test that metrics components are properly imported."""
    import cmp.monitoring as monitoring
    
    # Test that we can create a metrics collector
    collector = monitoring.get_metrics_collector()
    assert collector is not None
    
    # Test that metrics classes are available
    assert monitoring.MetricsCollector is not None
    assert monitoring.Metrics is not None
    assert monitoring.MetricsTimer is not None


def test_logging_integration():
    """Test that logging components are properly imported."""
    import cmp.monitoring as monitoring
    
    # Test that logging functions are callable
    logger = monitoring.get_logger("test")
    assert logger is not None
    
    # Test LogLevel enum
    assert monitoring.LogLevel is not None
    assert hasattr(monitoring.LogLevel, 'DEBUG')
    assert hasattr(monitoring.LogLevel, 'INFO')
    assert hasattr(monitoring.LogLevel, 'WARNING')
    assert hasattr(monitoring.LogLevel, 'ERROR')


def test_health_checks_integration():
    """Test that health check components are properly imported."""
    import cmp.monitoring as monitoring
    
    # Test that health check classes are available
    assert monitoring.HealthCheck is not None
    assert monitoring.HealthStatus is not None
    assert monitoring.HealthCheckResult is not None
    assert monitoring.SystemHealth is not None
    
    # Test utility function
    assert monitoring.check_service_url is not None


def test_profiling_integration():
    """Test that profiling components are properly imported."""
    import cmp.monitoring as monitoring
    
    # Test that profiling classes are available
    assert monitoring.CPUProfiler is not None
    assert monitoring.MemoryProfiler is not None
    assert monitoring.ProfileResult is not None
    
    # Test profiling decorators
    assert monitoring.profile_cpu is not None
    assert monitoring.profile_memory is not None
    assert monitoring.profile_async_function is not None