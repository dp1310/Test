"""Tests for async worker pool functionality."""

import pytest
import asyncio
from unittest.mock import AsyncMock, patch
from datetime import datetime, timezone

from cmp.core.async_pool import AsyncWorkerPool, BatchProcessor, TaskResult


@pytest.mark.asyncio
async def test_task_result_properties():
    """Test TaskResult properties."""
    start_time = datetime.now(timezone.utc)
    # Add 100ms to end time safely
    end_time = start_time.replace(microsecond=min(start_time.microsecond + 100000, 999999))
    
    # If microseconds would overflow, add to seconds instead
    if start_time.microsecond + 100000 > 999999:
        end_time = start_time.replace(second=start_time.second + 1, microsecond=0)
    
    # Successful result
    result = TaskResult(
        task_id="test-1",
        result="success",
        error=None,
        start_time=start_time,
        end_time=end_time
    )
    
    assert result.success is True
    assert result.duration > 0
    
    # Failed result
    failed_result = TaskResult(
        task_id="test-2",
        result=None,
        error=Exception("Test error"),
        start_time=start_time,
        end_time=end_time
    )
    
    assert failed_result.success is False
    assert failed_result.duration > 0


@pytest.mark.asyncio
async def test_async_worker_pool_initialization():
    """Test AsyncWorkerPool initialization."""
    pool = AsyncWorkerPool(worker_count=2, max_queue_size=50, timeout=10.0)
    
    assert pool.worker_count == 2
    assert pool.max_queue_size == 50
    assert pool.timeout == 10.0
    assert pool._running is False
    assert pool._tasks_submitted == 0
    assert pool._tasks_completed == 0


@pytest.mark.asyncio
async def test_async_worker_pool_start_stop():
    """Test starting and stopping worker pool."""
    pool = AsyncWorkerPool(worker_count=2)
    
    # Start pool
    await pool.start()
    assert pool._running is True
    assert len(pool._workers) == 2
    
    # Stop pool
    await pool.stop()
    assert pool._running is False


@pytest.mark.asyncio
async def test_async_worker_pool_submit_and_execute():
    """Test submitting and executing tasks."""
    async def test_task(x):
        await asyncio.sleep(0.01)
        return x * 2
    
    pool = AsyncWorkerPool(worker_count=2, max_queue_size=10)
    await pool.start()
    
    try:
        # Submit tasks
        await pool.submit("task-1", test_task, 5)
        await pool.submit("task-2", test_task, 10)
        
        # Wait for completion
        results = await pool.wait_all()
        
        assert len(results) == 2
        assert results["task-1"].success is True
        assert results["task-1"].result == 10
        assert results["task-2"].success is True
        assert results["task-2"].result == 20
        
    finally:
        await pool.stop()


@pytest.mark.asyncio
async def test_async_worker_pool_task_failure():
    """Test handling task failures."""
    async def failing_task():
        raise ValueError("Task failed")
    
    pool = AsyncWorkerPool(worker_count=1)
    await pool.start()
    
    try:
        await pool.submit("fail-task", failing_task)
        results = await pool.wait_all()
        
        assert len(results) == 1
        assert results["fail-task"].success is False
        assert isinstance(results["fail-task"].error, ValueError)
        
    finally:
        await pool.stop()


@pytest.mark.asyncio
async def test_async_worker_pool_timeout():
    """Test task timeout handling."""
    async def slow_task():
        await asyncio.sleep(1.0)
        return "done"
    
    pool = AsyncWorkerPool(worker_count=1, timeout=0.1)
    await pool.start()
    
    try:
        await pool.submit("slow-task", slow_task)
        results = await pool.wait_all()
        
        assert len(results) == 1
        assert results["slow-task"].success is False
        assert isinstance(results["slow-task"].error, asyncio.TimeoutError)
        
    finally:
        await pool.stop()


@pytest.mark.asyncio
async def test_async_worker_pool_get_result():
    """Test getting individual task results."""
    async def test_task(x):
        return x * 3
    
    pool = AsyncWorkerPool(worker_count=1)
    await pool.start()
    
    try:
        await pool.submit("task-1", test_task, 7)
        
        # Wait a bit for task to complete
        await asyncio.sleep(0.1)
        
        result = await pool.get_result("task-1")
        assert result is not None
        assert result.success is True
        assert result.result == 21
        
        # Test non-existent task
        no_result = await pool.get_result("non-existent")
        assert no_result is None
        
    finally:
        await pool.stop()


@pytest.mark.asyncio
async def test_async_worker_pool_stats():
    """Test worker pool statistics."""
    async def test_task(x):
        await asyncio.sleep(0.01)
        return x
    
    pool = AsyncWorkerPool(worker_count=2, max_queue_size=10)
    await pool.start()
    
    try:
        # Submit some tasks
        await pool.submit("task-1", test_task, 1)
        await pool.submit("task-2", test_task, 2)
        
        stats = pool.get_stats()
        assert stats["worker_count"] == 2
        assert stats["max_queue_size"] == 10
        assert stats["tasks_submitted"] == 2
        
        # Wait for completion
        await pool.wait_all()
        
        final_stats = pool.get_stats()
        assert final_stats["tasks_completed"] == 2
        assert final_stats["tasks_pending"] == 0
        assert final_stats["success_rate"] == 100.0
        
    finally:
        await pool.stop()


@pytest.mark.asyncio
async def test_async_worker_pool_submit_when_not_running():
    """Test submitting task when pool is not running."""
    pool = AsyncWorkerPool(worker_count=1)
    
    with pytest.raises(RuntimeError, match="Worker pool not started"):
        await pool.submit("task-1", lambda: None)


@pytest.mark.asyncio
async def test_async_worker_pool_double_start():
    """Test starting pool twice."""
    pool = AsyncWorkerPool(worker_count=1)
    
    await pool.start()
    assert pool._running is True
    
    # Starting again should not create new workers
    await pool.start()
    assert len(pool._workers) == 1
    
    await pool.stop()


@pytest.mark.asyncio
async def test_async_worker_pool_double_stop():
    """Test stopping pool twice."""
    pool = AsyncWorkerPool(worker_count=1)
    
    await pool.start()
    await pool.stop()
    assert pool._running is False
    
    # Stopping again should not raise error
    await pool.stop()


@pytest.mark.asyncio
async def test_batch_processor_initialization():
    """Test BatchProcessor initialization."""
    async def process_func(x):
        return x * 2
    
    processor = BatchProcessor(process_func, worker_count=3, batch_size=50)
    
    assert processor.process_func == process_func
    assert processor.worker_count == 3
    assert processor.batch_size == 50


@pytest.mark.asyncio
async def test_batch_processor_process_batch():
    """Test batch processing functionality."""
    async def double_value(x):
        await asyncio.sleep(0.01)
        return x * 2
    
    processor = BatchProcessor(double_value, worker_count=2)
    
    items = [1, 2, 3, 4, 5]
    results = await processor.process_batch(items)
    
    assert len(results) == 5
    
    # Results should be in order
    for i, result in enumerate(results):
        assert result.task_id == f"item-{i}"
        assert result.success is True
        assert result.result == items[i] * 2


@pytest.mark.asyncio
async def test_batch_processor_with_failures():
    """Test batch processing with some failures."""
    async def conditional_fail(x):
        if x == 3:
            raise ValueError(f"Failed on {x}")
        return x * 2
    
    processor = BatchProcessor(conditional_fail, worker_count=2)
    
    items = [1, 2, 3, 4, 5]
    results = await processor.process_batch(items)
    
    assert len(results) == 5
    
    # Check specific results
    assert results[0].success is True
    assert results[0].result == 2
    
    assert results[1].success is True
    assert results[1].result == 4
    
    assert results[2].success is False
    assert isinstance(results[2].error, ValueError)
    
    assert results[3].success is True
    assert results[3].result == 8
    
    assert results[4].success is True
    assert results[4].result == 10


@pytest.mark.asyncio
async def test_batch_processor_empty_batch():
    """Test batch processing with empty list."""
    async def process_func(x):
        return x
    
    processor = BatchProcessor(process_func)
    results = await processor.process_batch([])
    
    assert len(results) == 0


@pytest.mark.asyncio
async def test_worker_pool_stats_with_no_results():
    """Test stats when no tasks have been executed."""
    pool = AsyncWorkerPool(worker_count=2)
    
    stats = pool.get_stats()
    assert stats["success_rate"] == 0
    assert stats["tasks_submitted"] == 0
    assert stats["tasks_completed"] == 0
    assert stats["tasks_pending"] == 0


@pytest.mark.asyncio
async def test_worker_pool_mixed_success_failure():
    """Test stats calculation with mixed success/failure."""
    async def conditional_task(x):
        if x % 2 == 0:
            raise ValueError("Even number")
        return x
    
    pool = AsyncWorkerPool(worker_count=2)
    await pool.start()
    
    try:
        # Submit mix of tasks that will succeed and fail
        for i in range(1, 6):  # 1, 2, 3, 4, 5
            await pool.submit(f"task-{i}", conditional_task, i)
        
        await pool.wait_all()
        
        stats = pool.get_stats()
        # Should have 3 successes (1, 3, 5) and 2 failures (2, 4)
        assert stats["success_rate"] == 60.0  # 3/5 * 100
        
    finally:
        await pool.stop()