"""Tests for GraphQL schema."""

import pytest
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime, timezone
import strawberry

from cmp.api.graphql.schema import (
    Query, Mutation, Subscription, Context, WorkflowResult, 
    SchemaInfo, PolicyInfo, ContextInput, ContextUpdateInput, 
    WorkflowExecuteInput, _get_cmp, schema
)
from cmp.core.models import Context as CoreContext
from cmp.core.result import Ok, Err
from cmp.sdk.client import CMP


class TestGraphQLTypes:
    """Test GraphQL type definitions."""
    
    def test_context_type_creation(self):
        """Test Context type creation."""
        now = datetime.now(timezone.utc)
        context = Context(
            id="ctx-1",
            data={"key": "value"},
            schema="test_schema",
            created_at=now,
            updated_at=now,
            version=1,
            tenant_id="tenant-1"
        )
        
        assert context.id == "ctx-1"
        assert context.data == {"key": "value"}
        assert context.schema == "test_schema"
        assert context.created_at == now
        assert context.updated_at == now
        assert context.version == 1
        assert context.tenant_id == "tenant-1"
    
    def test_workflow_result_type_creation(self):
        """Test WorkflowResult type creation."""
        result = WorkflowResult(
            id="wf-1",
            workflow_name="test_workflow",
            context_id="ctx-1",
            status="completed",
            steps_completed=3,
            results=[{"step": 1}, {"step": 2}, {"step": 3}]
        )
        
        assert result.id == "wf-1"
        assert result.workflow_name == "test_workflow"
        assert result.context_id == "ctx-1"
        assert result.status == "completed"
        assert result.steps_completed == 3
        assert len(result.results) == 3
    
    def test_schema_info_type_creation(self):
        """Test SchemaInfo type creation."""
        schema_info = SchemaInfo(
            schema_id="schema-1",
            version="1.0",
            description="Test schema",
            deprecated=False
        )
        
        assert schema_info.schema_id == "schema-1"
        assert schema_info.version == "1.0"
        assert schema_info.description == "Test schema"
        assert schema_info.deprecated is False
    
    def test_policy_info_type_creation(self):
        """Test PolicyInfo type creation."""
        policy_info = PolicyInfo(
            policy_id="policy-1",
            version="1.0",
            description="Test policy",
            deployed=True
        )
        
        assert policy_info.policy_id == "policy-1"
        assert policy_info.version == "1.0"
        assert policy_info.description == "Test policy"
        assert policy_info.deployed is True


class TestInputTypes:
    """Test GraphQL input types."""
    
    def test_context_input_creation(self):
        """Test ContextInput creation."""
        input_data = ContextInput(
            data={"key": "value"},
            schema="test_schema",
            tenant_id="tenant-1"
        )
        
        assert input_data.data == {"key": "value"}
        assert input_data.schema == "test_schema"
        assert input_data.tenant_id == "tenant-1"
    
    def test_context_input_defaults(self):
        """Test ContextInput with defaults."""
        input_data = ContextInput(data={"key": "value"})
        
        assert input_data.data == {"key": "value"}
        assert input_data.schema is None
        assert input_data.tenant_id == "default"
    
    def test_context_update_input_creation(self):
        """Test ContextUpdateInput creation."""
        input_data = ContextUpdateInput(data={"updated": "value"})
        
        assert input_data.data == {"updated": "value"}
    
    def test_workflow_execute_input_creation(self):
        """Test WorkflowExecuteInput creation."""
        input_data = WorkflowExecuteInput(
            workflow_name="test_workflow",
            context_id="ctx-1",
            tenant_id="tenant-1"
        )
        
        assert input_data.workflow_name == "test_workflow"
        assert input_data.context_id == "ctx-1"
        assert input_data.tenant_id == "tenant-1"
    
    def test_workflow_execute_input_defaults(self):
        """Test WorkflowExecuteInput with defaults."""
        input_data = WorkflowExecuteInput(
            workflow_name="test_workflow",
            context_id="ctx-1"
        )
        
        assert input_data.workflow_name == "test_workflow"
        assert input_data.context_id == "ctx-1"
        assert input_data.tenant_id == "default"


class TestGetCMPFunction:
    """Test _get_cmp helper function."""
    
    def test_get_cmp_from_info_context(self):
        """Test getting CMP from info context."""
        mock_cmp = Mock()
        mock_app = Mock()
        mock_app.state.cmp = mock_cmp
        mock_context = Mock()
        mock_context.app = mock_app
        mock_info = Mock()
        mock_info.context = mock_context
        
        result = _get_cmp(mock_info)
        assert result is mock_cmp
    
    def test_get_cmp_fallback(self):
        """Test CMP fallback when info context not available."""
        mock_info = Mock()
        mock_context = Mock(spec=[])  # Empty spec means no attributes
        mock_info.context = mock_context
        
        # Clear any existing cached instance
        if hasattr(Query, '_test_cmp'):
            delattr(Query, '_test_cmp')
        
        with patch('cmp.CMP') as mock_cmp_class:
            mock_cmp_instance = Mock()
            mock_cmp_class.return_value = mock_cmp_instance
            
            result = _get_cmp(mock_info)
            
            # Should create and cache CMP instance
            mock_cmp_class.assert_called_once_with(tenant_id="default")
            assert result is mock_cmp_instance
            
            # Clean up
            if hasattr(Query, '_test_cmp'):
                delattr(Query, '_test_cmp')
    
    def test_get_cmp_fallback_cached(self):
        """Test CMP fallback uses cached instance."""
        mock_info = Mock()
        mock_context = Mock(spec=[])  # Empty spec means no attributes
        mock_info.context = mock_context
        
        # Set cached instance
        cached_cmp = Mock()
        Query._test_cmp = cached_cmp
        
        result = _get_cmp(mock_info)
        assert result is cached_cmp
        
        # Clean up
        delattr(Query, '_test_cmp')


class TestQuery:
    """Test GraphQL Query operations."""
    
    @pytest.fixture
    def mock_cmp(self):
        """Mock CMP instance."""
        cmp = Mock()
        context_service = AsyncMock()
        services = Mock()
        services.get_service.return_value = context_service
        cmp.services = services
        return cmp, context_service
    
    @pytest.mark.asyncio
    async def test_context_query_success(self, mock_cmp):
        """Test successful context query."""
        cmp, context_service = mock_cmp
        
        # Mock context
        core_context = CoreContext(
            id="ctx-1",
            data={"key": "value"},
            tenant_id="tenant-1",
            schema="test_schema",
            version=2
        )
        context_service.get.return_value = Ok(core_context)
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            query = Query()
            result = await query.context(id="ctx-1", tenant_id="tenant-1")
            
            assert result is not None
            assert result.id == "ctx-1"
            assert result.data == {"key": "value"}
            assert result.schema == "test_schema"
            assert result.version == 2
            assert result.tenant_id == "tenant-1"
            
            context_service.get.assert_called_once_with("ctx-1")
    
    @pytest.mark.asyncio
    async def test_context_query_not_found(self, mock_cmp):
        """Test context query when context not found."""
        cmp, context_service = mock_cmp
        context_service.get.return_value = Err("Not found")
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            query = Query()
            result = await query.context(id="nonexistent", tenant_id="tenant-1")
            
            assert result is None
            context_service.get.assert_called_once_with("nonexistent")
    
    @pytest.mark.asyncio
    async def test_contexts_query_success(self, mock_cmp):
        """Test successful contexts list query."""
        cmp, context_service = mock_cmp
        
        # Mock contexts
        contexts = [
            CoreContext(id="ctx-1", data={"key": "value1"}, tenant_id="tenant-1"),
            CoreContext(id="ctx-2", data={"key": "value2"}, tenant_id="tenant-1")
        ]
        context_service.list.return_value = Ok(contexts)
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            query = Query()
            result = await query.contexts(limit=10, tenant_id="tenant-1")
            
            assert len(result) == 2
            assert result[0].id == "ctx-1"
            assert result[1].id == "ctx-2"
            
            context_service.list.assert_called_once_with(limit=10, tenant_id="tenant-1")
    
    @pytest.mark.asyncio
    async def test_contexts_query_error(self, mock_cmp):
        """Test contexts query with error."""
        cmp, context_service = mock_cmp
        context_service.list.return_value = Err("Database error")
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            query = Query()
            result = await query.contexts(limit=10, tenant_id="tenant-1")
            
            assert result == []
            context_service.list.assert_called_once_with(limit=10, tenant_id="tenant-1")
    
    @pytest.mark.asyncio
    async def test_schemas_query_success(self):
        """Test successful schemas query."""
        mock_schema = Mock()
        mock_schema.schema_id = "schema-1"
        mock_schema.version = "1.0"
        mock_schema.description = "Test schema"
        mock_schema.deprecated = False
        
        mock_registry = AsyncMock()
        mock_registry.list_schemas.return_value = Ok([mock_schema])
        
        with patch('cmp.registries.create_backend') as mock_create_backend:
            with patch('cmp.registries.SchemaRegistry', return_value=mock_registry):
                query = Query()
                result = await query.schemas(info=Mock())
                
                assert len(result) == 1
                assert result[0].schema_id == "schema-1"
                assert result[0].version == "1.0"
                assert result[0].description == "Test schema"
                assert result[0].deprecated is False
                
                mock_create_backend.assert_called_once_with("file", base_path="./data/registries")
                mock_registry.list_schemas.assert_called_once()
                mock_registry.close.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_schemas_query_error(self):
        """Test schemas query with error."""
        mock_registry = AsyncMock()
        mock_registry.list_schemas.return_value = Err("Registry error")
        
        with patch('cmp.registries.create_backend'):
            with patch('cmp.registries.SchemaRegistry', return_value=mock_registry):
                query = Query()
                result = await query.schemas(info=Mock())
                
                assert result == []
                mock_registry.close.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_policies_query_success(self):
        """Test successful policies query."""
        mock_policy = Mock()
        mock_policy.policy_id = "policy-1"
        mock_policy.version = "1.0"
        mock_policy.description = "Test policy"
        mock_policy.deployed = True
        
        mock_registry = AsyncMock()
        mock_registry.list_policies.return_value = Ok([mock_policy])
        
        with patch('cmp.registries.create_backend') as mock_create_backend:
            with patch('cmp.registries.PolicyRegistry', return_value=mock_registry):
                query = Query()
                result = await query.policies(info=Mock())
                
                assert len(result) == 1
                assert result[0].policy_id == "policy-1"
                assert result[0].version == "1.0"
                assert result[0].description == "Test policy"
                assert result[0].deployed is True
                
                mock_create_backend.assert_called_once_with("file", base_path="./data/registries")
                mock_registry.list_policies.assert_called_once()
                mock_registry.close.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_policies_query_error(self):
        """Test policies query with error."""
        mock_registry = AsyncMock()
        mock_registry.list_policies.return_value = Err("Registry error")
        
        with patch('cmp.registries.create_backend'):
            with patch('cmp.registries.PolicyRegistry', return_value=mock_registry):
                query = Query()
                result = await query.policies(info=Mock())
                
                assert result == []
                mock_registry.close.assert_called_once()


class TestMutation:
    """Test GraphQL Mutation operations."""
    
    @pytest.fixture
    def mock_cmp(self):
        """Mock CMP instance."""
        cmp = Mock()
        context_service = AsyncMock()
        services = Mock()
        services.get_service.return_value = context_service
        cmp.services = services
        
        # Mock context builder
        builder = Mock()
        builder.with_data.return_value = builder
        builder.with_schema.return_value = builder
        builder.create = AsyncMock(return_value="ctx-123")
        cmp.context.return_value = builder
        
        # Mock workflow builder
        workflow_builder = Mock()
        workflow_builder.with_context.return_value = workflow_builder
        
        async def mock_execute():
            yield CoreContext(id="ctx-123", data={"result": "success"}, tenant_id="tenant-1")
        
        workflow_builder.execute = mock_execute
        cmp.workflow.return_value = workflow_builder
        
        return cmp, context_service, builder, workflow_builder
    
    @pytest.mark.asyncio
    async def test_create_context_success(self, mock_cmp):
        """Test successful context creation."""
        cmp, context_service, builder, _ = mock_cmp
        
        # Mock created context
        core_context = CoreContext(
            id="ctx-123",
            data={"key": "value"},
            tenant_id="tenant-1",
            schema="test_schema"
        )
        context_service.get.return_value = Ok(core_context)
        
        input_data = ContextInput(
            data={"key": "value"},
            schema="test_schema",
            tenant_id="tenant-1"
        )
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            mutation = Mutation()
            result = await mutation.create_context(input=input_data, info=Mock())
            
            assert result.id == "ctx-123"
            assert result.data == {"key": "value"}
            assert result.schema == "test_schema"
            assert result.tenant_id == "tenant-1"
            
            cmp.context.assert_called_once()
            builder.with_data.assert_called_once_with({"key": "value"})
            builder.with_schema.assert_called_once_with("test_schema")
            builder.create.assert_called_once()
            context_service.get.assert_called_once_with("ctx-123")
    
    @pytest.mark.asyncio
    async def test_create_context_without_schema(self, mock_cmp):
        """Test context creation without schema."""
        cmp, context_service, builder, _ = mock_cmp
        
        core_context = CoreContext(
            id="ctx-123",
            data={"key": "value"},
            tenant_id="tenant-1"
        )
        context_service.get.return_value = Ok(core_context)
        
        input_data = ContextInput(
            data={"key": "value"},
            tenant_id="tenant-1"
        )
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            mutation = Mutation()
            result = await mutation.create_context(input=input_data, info=Mock())
            
            assert result.id == "ctx-123"
            builder.with_data.assert_called_once_with({"key": "value"})
            builder.with_schema.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_update_context_success(self, mock_cmp):
        """Test successful context update."""
        cmp, context_service, _, _ = mock_cmp
        
        updated_context = CoreContext(
            id="ctx-1",
            data={"updated": "value"},
            tenant_id="tenant-1"
        )
        context_service.update.return_value = Ok(updated_context)
        
        input_data = ContextUpdateInput(data={"updated": "value"})
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            mutation = Mutation()
            result = await mutation.update_context(
                id="ctx-1",
                input=input_data,
                tenant_id="tenant-1",
                info=Mock()
            )
            
            assert result is not None
            assert result.id == "ctx-1"
            assert result.data == {"updated": "value"}
            assert result.tenant_id == "tenant-1"
            
            context_service.update.assert_called_once_with("ctx-1", {"updated": "value"})
    
    @pytest.mark.asyncio
    async def test_update_context_error(self, mock_cmp):
        """Test context update with error."""
        cmp, context_service, _, _ = mock_cmp
        context_service.update.return_value = Err("Update failed")
        
        input_data = ContextUpdateInput(data={"updated": "value"})
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            mutation = Mutation()
            result = await mutation.update_context(
                id="ctx-1",
                input=input_data,
                tenant_id="tenant-1",
                info=Mock()
            )
            
            assert result is None
            context_service.update.assert_called_once_with("ctx-1", {"updated": "value"})
    
    @pytest.mark.asyncio
    async def test_delete_context_success(self, mock_cmp):
        """Test successful context deletion."""
        cmp, context_service, _, _ = mock_cmp
        context_service.delete.return_value = Ok(True)
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            mutation = Mutation()
            result = await mutation.delete_context(
                id="ctx-1",
                tenant_id="tenant-1",
                info=Mock()
            )
            
            assert result is True
            context_service.delete.assert_called_once_with("ctx-1")
    
    @pytest.mark.asyncio
    async def test_delete_context_error(self, mock_cmp):
        """Test context deletion with error."""
        cmp, context_service, _, _ = mock_cmp
        context_service.delete.return_value = Err("Delete failed")
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            mutation = Mutation()
            result = await mutation.delete_context(
                id="ctx-1",
                tenant_id="tenant-1",
                info=Mock()
            )
            
            assert result is False
            context_service.delete.assert_called_once_with("ctx-1")
    
    @pytest.mark.asyncio
    async def test_execute_workflow_success(self, mock_cmp):
        """Test successful workflow execution."""
        cmp, _, _, workflow_builder = mock_cmp
        
        input_data = WorkflowExecuteInput(
            workflow_name="test_workflow",
            context_id="ctx-1",
            tenant_id="tenant-1"
        )
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=cmp):
            mutation = Mutation()
            result = await mutation.execute_workflow(input=input_data, info=Mock())
            
            assert result.id == "wf_test_workflow_ctx-1"
            assert result.workflow_name == "test_workflow"
            assert result.context_id == "ctx-1"
            assert result.status == "completed"
            assert result.steps_completed == 1
            assert len(result.results) == 1
            assert result.results[0]["id"] == "ctx-123"
            
            cmp.workflow.assert_called_once_with("test_workflow")
            workflow_builder.with_context.assert_called_once_with("ctx-1")


class TestSubscription:
    """Test GraphQL Subscription operations."""
    
    @pytest.mark.asyncio
    async def test_context_updated_subscription(self):
        """Test context updated subscription."""
        mock_cmp = Mock()
        context_service = AsyncMock()
        services = Mock()
        services.get_service.return_value = context_service
        mock_cmp.services = services
        
        # Mock stream updates as async generator
        async def mock_stream_updates(context_id):
            yield {"event": "updated", "context_id": context_id}
        
        context_service.stream_updates = mock_stream_updates
        
        # Mock get context
        core_context = CoreContext(
            id="ctx-1",
            data={"updated": "value"},
            tenant_id="tenant-1"
        )
        context_service.get.return_value = Ok(core_context)
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=mock_cmp):
            subscription = Subscription()
            
            results = []
            async for result in subscription.context_updated(
                id="ctx-1",
                tenant_id="tenant-1",
                info=Mock()
            ):
                results.append(result)
                break  # Just test one iteration
            
            # Can't assert on function call, just verify it worked
            assert len(results) == 1
            assert results[0].id == "ctx-1"
            assert results[0].data == {"updated": "value"}
            assert results[0].tenant_id == "tenant-1"
            
            context_service.get.assert_called_once_with("ctx-1")


class TestSchemaIntegration:
    """Test schema integration."""
    
    def test_schema_creation(self):
        """Test that schema is created successfully."""
        assert schema is not None
        # Check that schema has the expected types
        assert hasattr(schema, '_schema')  # Internal strawberry schema
    
    def test_schema_types_registered(self):
        """Test that all types are registered in schema."""
        # This is a basic test to ensure schema compilation works
        schema_str = str(schema)
        assert "Query" in schema_str
        assert "Mutation" in schema_str
        assert "Subscription" in schema_str


class TestErrorHandling:
    """Test error handling in GraphQL operations."""
    
    @pytest.mark.asyncio
    async def test_context_query_with_missing_attributes(self):
        """Test context query handling missing attributes gracefully."""
        mock_cmp = Mock()
        context_service = AsyncMock()
        services = Mock()
        services.get_service.return_value = context_service
        mock_cmp.services = services
        
        # Mock context with minimal attributes (no getattr fallbacks)
        core_context = CoreContext(
            id="ctx-1",
            data={"key": "value"},
            tenant_id="tenant-1"
        )
        # This context will have default None for schema
        
        context_service.get.return_value = Ok(core_context)
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=mock_cmp):
            query = Query()
            result = await query.context(id="ctx-1", tenant_id="tenant-1")
            
            assert result is not None
            assert result.id == "ctx-1"
            assert result.data == {"key": "value"}
            assert result.schema is None  # Default for CoreContext without schema
            assert result.version == 1  # Default for CoreContext
            assert isinstance(result.created_at, datetime)  # Default timestamp
            assert isinstance(result.updated_at, datetime)  # Default timestamp
    
    @pytest.mark.asyncio
    async def test_create_context_with_logging(self):
        """Test create context with defensive logging."""
        mock_cmp = Mock()
        context_service = AsyncMock()
        services = Mock()
        services.get_service.return_value = context_service
        mock_cmp.services = services
        
        # Mock context builder
        builder = Mock()
        builder.with_data.return_value = builder
        builder.with_schema.return_value = builder
        builder.create = AsyncMock(return_value="ctx-123")
        mock_cmp.context.return_value = builder
        
        # Mock context without schema attribute using spec
        core_context = Mock(spec=['id', 'data'])
        core_context.id = "ctx-123"
        core_context.data = {"key": "value"}
        # No schema attribute - getattr will return None
        
        context_service.get.return_value = Ok(core_context)
        
        input_data = ContextInput(
            data={"key": "value"},
            tenant_id="tenant-1"
        )
        
        with patch('cmp.api.graphql.schema._get_cmp', return_value=mock_cmp):
            with patch('logging.error') as mock_log:
                mutation = Mutation()
                result = await mutation.create_context(input=input_data, info=Mock())
                
                assert result.id == "ctx-123"
                assert result.schema is None
                
                # Should log error about missing schema attribute
                assert mock_log.call_count >= 1
                log_calls = [call[0][0] for call in mock_log.call_args_list]
                assert any("missing 'schema' attribute" in call for call in log_calls)