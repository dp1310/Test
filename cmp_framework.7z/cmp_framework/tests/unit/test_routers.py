
import pytest
from fastapi.testclient import TestClient
from fastapi import FastAPI
from unittest.mock import MagicMock, AsyncMock, patch

from cmp.api.routers import context_router, workflow_router, registry_router, health_router
from cmp.core.models import Context, ContextEnvelope
from cmp.api.auth import get_current_user

# Setup App
app = FastAPI()
app.include_router(context_router, prefix="/api/v1/context")
app.include_router(workflow_router, prefix="/api/v1/workflow")
app.include_router(registry_router, prefix="/api/v1/registry")
app.include_router(health_router, prefix="/health")

# Setup Mock User Dependency
mock_user = MagicMock()
mock_user.username = "test_user"
mock_user.tenant_id = "default"
mock_user.scopes = ["*"]

app.dependency_overrides[get_current_user] = lambda: mock_user

client = TestClient(app)

@pytest.fixture
def mock_cmp():
    with patch("cmp.api.routers._get_cmp") as mock:
        cmp_instance = MagicMock()
        mock.return_value = cmp_instance
        
        # Context Service Builder Mocks
        # cmp.context() -> builder
        mock_builder = MagicMock()
        mock_builder.with_data.return_value = mock_builder
        mock_builder.with_schema.return_value = mock_builder
        mock_builder.with_metadata.return_value = mock_builder
        mock_builder.create = AsyncMock(return_value="ctx-1")
        
        cmp_instance.context.return_value = mock_builder
        
        # Context object for get/list
        mock_ctx = MagicMock()
        mock_ctx.id = "ctx-1"
        mock_ctx.data = {"foo": "bar"}
        mock_ctx.schema = "test"
        mock_ctx.created_at.isoformat.return_value = "2023-01-01T00:00:00Z"
        mock_ctx.updated_at.isoformat.return_value = "2023-01-01T00:00:00Z"
        mock_ctx.version = 1
        
        # Service Access for get() after create
        mock_service = MagicMock()
        mock_service.get = AsyncMock(return_value=MagicMock(is_ok=lambda: True, is_err=lambda: False, unwrap=lambda: mock_ctx))
        mock_service.list = AsyncMock(return_value=MagicMock(is_ok=lambda: True, is_err=lambda: False, unwrap=lambda: [mock_ctx]))
        mock_service.update = AsyncMock(return_value=MagicMock(is_ok=lambda: True, is_err=lambda: False, unwrap=lambda: mock_ctx))
        mock_service.delete = AsyncMock(return_value=MagicMock(is_ok=lambda: True, is_err=lambda: False, unwrap=lambda: True))
        
        cmp_instance.services.get_service.return_value = mock_service
        
        # Workflow
        mock_wf_builder = MagicMock()
        mock_result = MagicMock()
        mock_result.id = "res-1"
        mock_result.data = {"status": "done"}
        
        async def mock_execute():
            yield mock_result
        mock_wf_builder.execute.return_value = mock_execute()
        
        mock_wf_builder.with_context.return_value = mock_wf_builder
        cmp_instance.workflow.return_value = mock_wf_builder
        
        # Registry
        cmp_instance.schema.list_schemas = AsyncMock(return_value=MagicMock(is_ok=lambda: True, is_err=lambda: False, unwrap=lambda: [{"schema_id": "s1"}]))
        cmp_instance.policy.list_policies = AsyncMock(return_value=MagicMock(is_ok=lambda: True, is_err=lambda: False, unwrap=lambda: [{"policy_id": "p1"}]))
        
        yield cmp_instance

def test_context_routes(mock_cmp):
    # Create
    resp = client.post("/api/v1/context/", json={"data": {"foo": "bar"}, "schema": "test"})
    assert resp.status_code == 201, resp.text
    assert resp.json()["id"] == "ctx-1"
    
    # Get
    resp = client.get("/api/v1/context/ctx-1")
    assert resp.status_code == 200
    assert resp.json()["data"]["foo"] == "bar"
    
    # List
    resp = client.get("/api/v1/context/")
    assert resp.status_code == 200
    assert len(resp.json()) == 1
    
    # Update
    resp = client.put("/api/v1/context/ctx-1", json={"data": {"foo": "baz"}})
    assert resp.status_code == 200
    
    # Delete
    resp = client.delete("/api/v1/context/ctx-1")
    assert resp.status_code == 204

def test_workflow_routes(mock_cmp):
    resp = client.post("/api/v1/workflow/execute", json={"context_id": "ctx-1", "workflow_name": "test-wf"})
    assert resp.status_code == 200
    assert resp.json()["steps"] == 1
    assert resp.json()["results"][0]["id"] == "res-1"

def test_registry_routes(mock_cmp):
    resp = client.get("/api/v1/registry/schemas")
    assert resp.status_code == 200
    assert len(resp.json()) == 1
    
    resp = client.get("/api/v1/registry/policies")
    assert resp.status_code == 200
    assert len(resp.json()) == 1

def test_error_handling(mock_cmp):
    # Mock error response for context get via service
    err_res = MagicMock()
    err_res.is_ok.return_value = False
    err_res.is_err.return_value = True
    err_res.unwrap_err.return_value = Exception("Not found")
    
    # Access the mock service created in fixture
    mock_service = mock_cmp.services.get_service.return_value
    mock_service.get.return_value = err_res
    
    resp = client.get("/api/v1/context/ctx-err")
    assert resp.status_code == 404

