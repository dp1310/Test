"""Tests for plugin loader functionality."""

import pytest
import tempfile
import os
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import importlib.util

from cmp.plugins.loader import PluginLoader
from cmp.plugins.base import Plugin, PluginMetadata, hook


class TestPlugin(Plugin):
    """Test plugin for testing."""
    
    name = "test-plugin"
    version = "1.0.0"
    description = "Test plugin"
    author = "Test Author"
    dependencies = ["dep1", "dep2"]
    
    def __init__(self):
        super().__init__()
        self.init_called = False
    
    def on_init(self):
        self.init_called = True


class AnotherTestPlugin(Plugin):
    """Another test plugin."""
    
    name = "another-plugin"
    version = "2.0.0"
    
    def on_init(self):
        pass


@pytest.fixture
def plugin_loader():
    """Plugin loader fixture."""
    return PluginLoader()


@pytest.fixture
def temp_plugin_dir():
    """Temporary directory with test plugins."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create a test plugin file
        plugin_file = Path(temp_dir) / "test_plugin.py"
        plugin_code = '''
from cmp.plugins.base import Plugin

class TestPlugin(Plugin):
    name = "file-test-plugin"
    version = "1.0.0"
    
    def on_init(self):
        pass

class NotAPlugin:
    """This should be ignored."""
    pass
'''
        plugin_file.write_text(plugin_code)
        
        # Create another plugin file
        another_file = Path(temp_dir) / "another_plugin.py"
        another_code = '''
from cmp.plugins.base import Plugin

class AnotherPlugin(Plugin):
    name = "another-file-plugin"
    version = "2.0.0"
    
    def on_init(self):
        pass
'''
        another_file.write_text(another_code)
        
        # Create a file that should be ignored (starts with _)
        ignored_file = Path(temp_dir) / "_ignored.py"
        ignored_file.write_text("# This should be ignored")
        
        # Create a file with invalid Python
        invalid_file = Path(temp_dir) / "invalid.py"
        invalid_file.write_text("invalid python syntax !!!")
        
        yield temp_dir


def test_plugin_loader_initialization(plugin_loader):
    """Test PluginLoader initialization."""
    assert isinstance(plugin_loader._discovered_plugins, dict)
    assert len(plugin_loader._discovered_plugins) == 0


@pytest.mark.asyncio
async def test_discover_plugins_nonexistent_directory(plugin_loader):
    """Test discovering plugins in non-existent directory."""
    plugins = await plugin_loader.discover_plugins("/nonexistent/path")
    assert plugins == []


@pytest.mark.asyncio
async def test_discover_plugins_success(plugin_loader, temp_plugin_dir):
    """Test successful plugin discovery."""
    with patch('cmp.plugins.base.Plugin', Plugin):
        plugins = await plugin_loader.discover_plugins(temp_plugin_dir)
        
        # Should discover 2 plugins (ignoring _ignored.py and invalid.py)
        assert len(plugins) >= 2
        assert "file-test-plugin" in plugins
        assert "another-file-plugin" in plugins


@pytest.mark.asyncio
async def test_discover_plugins_with_import_error(plugin_loader):
    """Test plugin discovery with import errors."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create a plugin file with import error
        plugin_file = Path(temp_dir) / "broken_plugin.py"
        plugin_code = '''
import nonexistent_module  # This will cause ImportError
from cmp.plugins.base import Plugin

class BrokenPlugin(Plugin):
    name = "broken-plugin"
    
    def on_init(self):
        pass
'''
        plugin_file.write_text(plugin_code)
        
        with patch('builtins.print') as mock_print:
            plugins = await plugin_loader.discover_plugins(temp_dir)
            
            # Should handle the error gracefully
            assert plugins == []
            mock_print.assert_called()  # Should print error message


@pytest.mark.asyncio
async def test_load_plugin_success(plugin_loader):
    """Test successful plugin loading."""
    # Manually add a plugin to discovered plugins
    plugin_loader._discovered_plugins["test-plugin"] = TestPlugin
    
    plugin = await plugin_loader.load_plugin("test-plugin")
    
    assert plugin is not None
    assert isinstance(plugin, TestPlugin)
    assert plugin.init_called is True  # on_init should be called


@pytest.mark.asyncio
async def test_load_plugin_not_found(plugin_loader):
    """Test loading non-existent plugin."""
    plugin = await plugin_loader.load_plugin("nonexistent-plugin")
    assert plugin is None


def test_list_discovered_empty(plugin_loader):
    """Test listing discovered plugins when none are discovered."""
    plugins = plugin_loader.list_discovered()
    assert plugins == []


def test_list_discovered_with_plugins(plugin_loader):
    """Test listing discovered plugins."""
    # Manually add plugins to discovered plugins
    plugin_loader._discovered_plugins["plugin1"] = TestPlugin
    plugin_loader._discovered_plugins["plugin2"] = AnotherTestPlugin
    
    plugins = plugin_loader.list_discovered()
    assert len(plugins) == 2
    assert "plugin1" in plugins
    assert "plugin2" in plugins


@pytest.mark.asyncio
async def test_discover_plugins_ignores_underscore_files(plugin_loader):
    """Test that files starting with underscore are ignored."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create files that should be ignored
        ignored_files = ["_private.py", "__init__.py", "_test.py"]
        for filename in ignored_files:
            file_path = Path(temp_dir) / filename
            file_path.write_text('''
from cmp.plugins.base import Plugin

class IgnoredPlugin(Plugin):
    name = "ignored-plugin"
    
    def on_init(self):
        pass
''')
        
        plugins = await plugin_loader.discover_plugins(temp_dir)
        assert plugins == []


@pytest.mark.asyncio
async def test_discover_plugins_filters_non_plugin_classes(plugin_loader):
    """Test that non-Plugin classes are filtered out."""
    with tempfile.TemporaryDirectory() as temp_dir:
        plugin_file = Path(temp_dir) / "mixed_classes.py"
        plugin_code = '''
from cmp.plugins.base import Plugin

class ValidPlugin(Plugin):
    name = "valid-plugin"
    
    def on_init(self):
        pass

class NotAPlugin:
    """This should be ignored."""
    pass

class AlsoNotAPlugin(object):
    """This should also be ignored."""
    pass

# The base Plugin class itself should also be ignored
'''
        plugin_file.write_text(plugin_code)
        
        with patch('cmp.plugins.base.Plugin', Plugin):
            plugins = await plugin_loader.discover_plugins(temp_dir)
            
            # Should only find the ValidPlugin
            assert len(plugins) == 1
            assert "valid-plugin" in plugins


@pytest.mark.asyncio
async def test_discover_plugins_handles_spec_creation_failure(plugin_loader):
    """Test handling of spec creation failure."""
    with tempfile.TemporaryDirectory() as temp_dir:
        plugin_file = Path(temp_dir) / "test_plugin.py"
        plugin_file.write_text("# Valid Python file")
        
        with patch('importlib.util.spec_from_file_location', return_value=None):
            with patch('builtins.print') as mock_print:
                plugins = await plugin_loader.discover_plugins(temp_dir)
                
                assert plugins == []
                # Should not print error for None spec (it's handled gracefully)


@pytest.mark.asyncio
async def test_discover_plugins_handles_loader_none(plugin_loader):
    """Test handling when spec.loader is None."""
    with tempfile.TemporaryDirectory() as temp_dir:
        plugin_file = Path(temp_dir) / "test_plugin.py"
        plugin_file.write_text("# Valid Python file")
        
        mock_spec = Mock()
        mock_spec.loader = None
        
        with patch('importlib.util.spec_from_file_location', return_value=mock_spec):
            plugins = await plugin_loader.discover_plugins(temp_dir)
            assert plugins == []


@pytest.mark.asyncio
async def test_discover_plugins_handles_module_execution_error(plugin_loader):
    """Test handling of module execution errors."""
    with tempfile.TemporaryDirectory() as temp_dir:
        plugin_file = Path(temp_dir) / "test_plugin.py"
        plugin_file.write_text("raise RuntimeError('Module execution failed')")
        
        with patch('builtins.print') as mock_print:
            plugins = await plugin_loader.discover_plugins(temp_dir)
            
            assert plugins == []
            mock_print.assert_called()  # Should print error message


@pytest.mark.asyncio
async def test_load_plugin_calls_on_init(plugin_loader):
    """Test that load_plugin calls on_init method."""
    class InitTestPlugin(Plugin):
        name = "init-test"
        
        def __init__(self):
            super().__init__()
            self.on_init_called = False
        
        def on_init(self):
            self.on_init_called = True
    
    plugin_loader._discovered_plugins["init-test"] = InitTestPlugin
    
    plugin = await plugin_loader.load_plugin("init-test")
    
    assert plugin.on_init_called is True


@pytest.mark.asyncio
async def test_discover_plugins_multiple_plugins_same_file(plugin_loader):
    """Test discovering multiple plugins in the same file."""
    with tempfile.TemporaryDirectory() as temp_dir:
        plugin_file = Path(temp_dir) / "multiple_plugins.py"
        plugin_code = '''
from cmp.plugins.base import Plugin

class FirstPlugin(Plugin):
    name = "first-plugin"
    
    def on_init(self):
        pass

class SecondPlugin(Plugin):
    name = "second-plugin"
    
    def on_init(self):
        pass
'''
        plugin_file.write_text(plugin_code)
        
        with patch('cmp.plugins.base.Plugin', Plugin):
            plugins = await plugin_loader.discover_plugins(temp_dir)
            
            assert len(plugins) == 2
            assert "first-plugin" in plugins
            assert "second-plugin" in plugins


def test_plugin_loader_discovered_plugins_dict_access(plugin_loader):
    """Test direct access to discovered plugins dictionary."""
    plugin_loader._discovered_plugins["test"] = TestPlugin
    
    assert "test" in plugin_loader._discovered_plugins
    assert plugin_loader._discovered_plugins["test"] == TestPlugin