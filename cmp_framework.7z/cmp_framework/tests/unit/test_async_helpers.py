
import pytest
import asyncio
from cmp.utils.async_helpers import (
    ContextFuture, AsyncLock, AsyncPool, gather_dict, retry, async_map, async_filter
)

@pytest.mark.asyncio
async def test_context_future():
    async def success_task():
        return "success"
    
    async def fail_task():
        raise ValueError("failed")
        
    # Test Then
    fut = ContextFuture(success_task())
    results = []
    fut.then(lambda res: results.append(res))
    assert await fut == "success"
    # Callbacks run in done_callback, loop needs to spin
    await asyncio.sleep(0.01)
    assert "success" in results

    # Test Catch
    fut2 = ContextFuture(fail_task())
    errors = []
    fut2.catch(lambda e: errors.append(e))
    try:
        await fut2
    except ValueError:
        pass
    await asyncio.sleep(0.01)
    assert len(errors) == 1
    assert str(errors[0]) == "failed"
    
    # Test Finally
    fut3 = ContextFuture(success_task())
    cleanup = []
    fut3.finally_(lambda: cleanup.append(True))
    await fut3
    await asyncio.sleep(0.01)
    assert len(cleanup) == 1

@pytest.mark.asyncio
async def test_async_lock():
    lock = AsyncLock()
    async with lock:
        assert lock._lock.locked()
    assert not lock._lock.locked()

@pytest.mark.asyncio
async def test_async_pool():
    class MockConn:
        closed = False
        async def close(self):
            self.closed = True
            
    async def factory():
        return MockConn()
        
    pool = AsyncPool(factory, max_size=2)
    
    # Acquire
    c1 = await pool.acquire()
    c2 = await pool.acquire()
    assert pool._size == 2
    
    # Release
    await pool.release(c1)
    c3 = await pool.acquire() # Should reuse c1
    assert c3 == c1
    
    # Close
    await pool.release(c2)
    # Release c3 (which is c1)
    await pool.release(c3)
    
    await pool.close()
    assert c2.closed
    assert c3.closed

@pytest.mark.asyncio
async def test_gather_dict():
    async def get_val(v):
        return v
        
    res = await gather_dict({
        "a": get_val(1),
        "b": get_val(2)
    })
    assert res == {"a": 1, "b": 2}

@pytest.mark.asyncio
async def test_retry():
    attempts = 0
    async def fail_twice():
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise ValueError("fail")
        return "ok"
        
    res = await retry(fail_twice, max_attempts=3, delay=0.01)
    assert res == "ok"
    assert attempts == 3
    
    # Test Fail
    attempts = 0
    with pytest.raises(ValueError):
        await retry(fail_twice, max_attempts=2, delay=0.01)

@pytest.mark.asyncio
async def test_async_map_filter():
    async def double(x):
        return x * 2
        
    res = await async_map(double, [1, 2, 3])
    assert res == [2, 4, 6]
    
    async def is_even(x):
        return x % 2 == 0
        
    res2 = await async_filter(is_even, [1, 2, 3, 4])
    assert res2 == [2, 4]
