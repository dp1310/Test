
import pytest
from unittest.mock import MagicMock, AsyncMock
from cmp.adapters.sage_mcp_adapter import SageMCPAdapter, SageMCPContextStore
from cmp.core.models import ContextEnvelope, Schema, Policy, Provenance, Metadata

@pytest.fixture
def mock_sage_client():
    return MagicMock()

@pytest.fixture
def adapter(mock_sage_client):
    return SageMCPAdapter(mock_sage_client)

@pytest.fixture
def store(adapter):
    return SageMCPContextStore(adapter)

@pytest.fixture
def sample_envelope():
    return ContextEnvelope(
        id="ctx-1",
        data={"key": "val"},
        schema=Schema(name="test", version="1.0", fields={}),
        policy=Policy.default(),
        provenance=Provenance.empty(),
        metadata=Metadata.default().add_tag("test")
    )

@pytest.mark.asyncio
async def test_adapter_transform(adapter, sample_envelope):
    sage_format = adapter._transform_to_sage(sample_envelope)
    assert sage_format["id"] == "ctx-1"
    assert sage_format["content"] == {"key": "val"}
    
    cmp_format = adapter._transform_from_sage({
        "id": "ctx-1",
        "content": {"key": "val"},
        "tenant": "default",
        "meta": {}
    })
    assert cmp_format["id"] == "ctx-1"
    assert cmp_format["data"] == {"key": "val"}

@pytest.mark.asyncio
async def test_store_placeholder(store, sample_envelope):
    # Test methods that are currently placeholders
    assert await store.save(sample_envelope) == "ctx-1"
    assert await store.get("ctx-1") is None
    assert await store.delete("ctx-1") is False
    assert await store.update("ctx-1", sample_envelope) is False
    
    # Test search (it's empty)
    found = []
    async for ctx in store.search({}, "tenant"):
        found.append(ctx)
    assert len(found) == 0

def test_store_to_envelope(store):
    # Test internal conversion
    # Note: _to_envelope requires Metadata.from_dict structure match
    # Since adapter output structure for metadata is:
    # "metadata": { "tenant_id": ..., "created_at": ..., ... }
    # We must match that.
    
    sage_ctx = {
        "id": "ctx-2",
        "data": {"foo": "bar"},
        "metadata": {
            "tenant_id": "t1",
            "created_at": "2023-01-01T00:00:00Z",
            "updated_at": "2023-01-01T00:00:00Z",
            "version": 1,
            "tags": []
        }
    }
    
    envelope = store._to_envelope(sage_ctx)
    assert envelope.id == "ctx-2"
    assert envelope.data == {"foo": "bar"}
