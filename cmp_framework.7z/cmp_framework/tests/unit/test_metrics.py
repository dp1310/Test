"""Tests for monitoring metrics."""

import pytest
from datetime import datetime, timezone
import time
from freezegun import freeze_time

from cmp.monitoring.metrics import (
    Metrics,
    MetricsCollector,
    MetricsTimer,
    get_metrics_collector,
)


class TestMetricsCollector:
    """Tests for the MetricsCollector class."""

    def setup_method(self):
        """Reset the global metrics collector before each test."""
        self.collector = get_metrics_collector()
        self.collector.reset()

    def test_singleton_get_metrics_collector(self):
        """Test that get_metrics_collector returns a singleton."""
        c1 = get_metrics_collector()
        c2 = get_metrics_collector()
        assert c1 is c2

    def test_initial_metrics(self):
        """Test that metrics are initialized to zero."""
        with freeze_time("2025-01-01 01:00:00"):
            self.collector.reset()  # Reset within the frozen time context
            metrics = self.collector.get_metrics()
            
        assert metrics.contexts_created == 0
        assert metrics.workflows_executed == 0
        assert metrics.errors_total == 0
        # Check that last_updated is a datetime object and has the expected date
        assert metrics.last_updated.year == 2025
        assert metrics.last_updated.month == 1
        assert metrics.last_updated.day == 1
        assert metrics.last_updated.hour == 1

    def test_record_context_created(self):
        """Test recording context creation."""
        self.collector.record_context_created(duration_ms=100)
        metrics = self.collector.get_metrics()
        assert metrics.contexts_created == 1
        assert metrics.avg_context_create_time_ms == 100.0

    def test_record_context_retrieved(self):
        """Test recording context retrieval."""
        self.collector.record_context_retrieved()
        metrics = self.collector.get_metrics()
        assert metrics.contexts_retrieved == 1

    def test_record_context_updated(self):
        """Test recording context update."""
        self.collector.record_context_updated()
        metrics = self.collector.get_metrics()
        assert metrics.contexts_updated == 1

    def test_record_context_deleted(self):
        """Test recording context deletion."""
        self.collector.record_context_deleted()
        metrics = self.collector.get_metrics()
        assert metrics.contexts_deleted == 1

    def test_record_workflow_executed(self):
        """Test recording workflow execution."""
        self.collector.record_workflow_executed(duration_ms=500)
        metrics = self.collector.get_metrics()
        assert metrics.workflows_executed == 1
        assert metrics.avg_workflow_execution_time_ms == 500.0

    def test_record_workflow_step(self):
        """Test recording workflow step."""
        self.collector.record_workflow_step()
        metrics = self.collector.get_metrics()
        assert metrics.workflow_steps_completed == 1

    def test_record_error(self):
        """Test recording a generic error."""
        self.collector.record_error()
        metrics = self.collector.get_metrics()
        assert metrics.errors_total == 1

    def test_record_policy_violation(self):
        """Test recording a policy violation."""
        self.collector.record_policy_violation()
        metrics = self.collector.get_metrics()
        assert metrics.policy_violations == 1
        assert metrics.errors_total == 1

    def test_reset_metrics(self):
        """Test resetting metrics."""
        self.collector.record_context_created()
        self.collector.reset()
        metrics = self.collector.get_metrics()
        assert metrics.contexts_created == 0

    def test_avg_timing(self):
        """Test average timing calculation."""
        self.collector.record_context_created(duration_ms=100)
        self.collector.record_context_created(duration_ms=200)
        metrics = self.collector.get_metrics()
        assert metrics.avg_context_create_time_ms == 150.0

    def test_prometheus_export(self):
        """Test exporting metrics to Prometheus format."""
        self.collector.record_context_created(duration_ms=123)
        self.collector.record_context_retrieved()
        self.collector.record_workflow_executed()
        self.collector.record_error()
        
        output = self.collector.to_prometheus()
        
        assert "# HELP cmp_contexts_created_total Total contexts created" in output
        assert "cmp_contexts_created_total 1" in output
        assert "cmp_contexts_retrieved_total 1" in output
        assert "cmp_workflows_executed_total 1" in output
        assert "cmp_errors_total 1" in output
        assert "cmp_context_create_duration_ms 123.0" in output


class TestMetricsTimer:
    """Tests for the MetricsTimer context manager."""

    def test_timer_duration(self):
        """Test that the timer correctly measures duration."""
        with MetricsTimer("test_op") as timer:
            time.sleep(0.1)
        
        assert timer.duration_ms > 90
        assert timer.duration_ms < 150
