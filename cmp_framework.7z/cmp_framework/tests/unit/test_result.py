"""Tests for Result monad."""

import pytest
import asyncio
from cmp.core.result import Ok, Err, Result, ok, err, try_async, try_sync


class TestOk:
    """Test Ok result type."""
    
    def test_ok_creation(self):
        """Test creating Ok result."""
        result = Ok(42)
        assert result.value == 42
        assert result.is_ok() is True
        assert result.is_err() is False
    
    def test_ok_unwrap(self):
        """Test unwrapping Ok result."""
        result = Ok("success")
        assert result.unwrap() == "success"
    
    def test_ok_unwrap_or(self):
        """Test unwrap_or with Ok result."""
        result = Ok(42)
        assert result.unwrap_or(0) == 42
    
    def test_ok_unwrap_or_else(self):
        """Test unwrap_or_else with Ok result."""
        result = Ok(42)
        assert result.unwrap_or_else(lambda: 0) == 42
    
    def test_ok_unwrap_err_raises(self):
        """Test that unwrap_err raises on Ok result."""
        result = Ok(42)
        with pytest.raises(ValueError, match="Called unwrap_err on Ok"):
            result.unwrap_err()
    
    def test_ok_map(self):
        """Test mapping over Ok result."""
        result = Ok(5)
        mapped = result.map(lambda x: x * 2)
        assert mapped.is_ok()
        assert mapped.unwrap() == 10
    
    def test_ok_map_with_exception(self):
        """Test mapping with function that raises exception."""
        result = Ok(5)
        mapped = result.map(lambda x: 1 / 0)  # Division by zero
        assert mapped.is_err()
        assert isinstance(mapped.unwrap_err(), ZeroDivisionError)
    
    @pytest.mark.asyncio
    async def test_ok_map_async(self):
        """Test async mapping over Ok result."""
        result = Ok(5)
        
        async def double(x):
            return x * 2
        
        mapped = await result.map_async(double)
        assert mapped.is_ok()
        assert mapped.unwrap() == 10
    
    @pytest.mark.asyncio
    async def test_ok_map_async_with_exception(self):
        """Test async mapping with function that raises exception."""
        result = Ok(5)
        
        async def failing_func(x):
            raise ValueError("Async error")
        
        mapped = await result.map_async(failing_func)
        assert mapped.is_err()
        assert isinstance(mapped.unwrap_err(), ValueError)
    
    def test_ok_and_then(self):
        """Test chaining Ok results."""
        result = Ok(5)
        chained = result.and_then(lambda x: Ok(x * 2))
        assert chained.is_ok()
        assert chained.unwrap() == 10
    
    def test_ok_and_then_to_err(self):
        """Test chaining Ok to Err."""
        result = Ok(5)
        chained = result.and_then(lambda x: Err("error"))
        assert chained.is_err()
        assert chained.unwrap_err() == "error"
    
    def test_ok_and_then_with_exception(self):
        """Test and_then with function that raises exception."""
        result = Ok(5)
        chained = result.and_then(lambda x: 1 / 0)  # Will raise
        assert chained.is_err()
        assert isinstance(chained.unwrap_err(), ZeroDivisionError)
    
    @pytest.mark.asyncio
    async def test_ok_and_then_async(self):
        """Test async chaining Ok results."""
        result = Ok(5)
        
        async def double_result(x):
            return Ok(x * 2)
        
        chained = await result.and_then_async(double_result)
        assert chained.is_ok()
        assert chained.unwrap() == 10
    
    @pytest.mark.asyncio
    async def test_ok_and_then_async_with_exception(self):
        """Test async and_then with function that raises exception."""
        result = Ok(5)
        
        async def failing_func(x):
            raise ValueError("Async error")
        
        chained = await result.and_then_async(failing_func)
        assert chained.is_err()
        assert isinstance(chained.unwrap_err(), ValueError)


class TestErr:
    """Test Err result type."""
    
    def test_err_creation(self):
        """Test creating Err result."""
        result = Err("error message")
        assert result.error == "error message"
        assert result.is_ok() is False
        assert result.is_err() is True
    
    def test_err_unwrap_raises(self):
        """Test that unwrap raises on Err result."""
        result = Err(ValueError("test error"))
        with pytest.raises(ValueError, match="test error"):
            result.unwrap()
    
    def test_err_unwrap_non_exception(self):
        """Test unwrap with non-exception error."""
        result = Err("string error")
        with pytest.raises(RuntimeError, match="Result error: string error"):
            result.unwrap()
    
    def test_err_unwrap_or(self):
        """Test unwrap_or with Err result."""
        result = Err("error")
        assert result.unwrap_or(42) == 42
    
    def test_err_unwrap_or_else(self):
        """Test unwrap_or_else with Err result."""
        result = Err("error")
        assert result.unwrap_or_else(lambda: 42) == 42
    
    def test_err_unwrap_err(self):
        """Test unwrapping error from Err result."""
        result = Err("error message")
        assert result.unwrap_err() == "error message"
    
    def test_err_map_noop(self):
        """Test that map is no-op for Err."""
        result = Err("error")
        mapped = result.map(lambda x: x * 2)
        assert mapped.is_err()
        assert mapped.unwrap_err() == "error"
    
    @pytest.mark.asyncio
    async def test_err_map_async_noop(self):
        """Test that map_async is no-op for Err."""
        result = Err("error")
        
        async def double(x):
            return x * 2
        
        mapped = await result.map_async(double)
        assert mapped.is_err()
        assert mapped.unwrap_err() == "error"
    
    def test_err_and_then_noop(self):
        """Test that and_then is no-op for Err."""
        result = Err("error")
        chained = result.and_then(lambda x: Ok(x * 2))
        assert chained.is_err()
        assert chained.unwrap_err() == "error"
    
    @pytest.mark.asyncio
    async def test_err_and_then_async_noop(self):
        """Test that and_then_async is no-op for Err."""
        result = Err("error")
        
        async def double_result(x):
            return Ok(x * 2)
        
        chained = await result.and_then_async(double_result)
        assert chained.is_err()
        assert chained.unwrap_err() == "error"


class TestHelperFunctions:
    """Test helper functions."""
    
    def test_ok_helper(self):
        """Test ok() helper function."""
        result = ok(42)
        assert isinstance(result, Ok)
        assert result.value == 42
    
    def test_err_helper(self):
        """Test err() helper function."""
        result = err("error")
        assert isinstance(result, Err)
        assert result.error == "error"
    
    def test_try_sync_success(self):
        """Test try_sync with successful function."""
        def success_func():
            return 42
        
        result = try_sync(success_func)
        assert result.is_ok()
        assert result.unwrap() == 42
    
    def test_try_sync_failure(self):
        """Test try_sync with failing function."""
        def failing_func():
            raise ValueError("test error")
        
        result = try_sync(failing_func)
        assert result.is_err()
        assert isinstance(result.unwrap_err(), ValueError)
    
    @pytest.mark.asyncio
    async def test_try_async_success(self):
        """Test try_async with successful function."""
        async def success_func():
            return 42
        
        result = await try_async(success_func)
        assert result.is_ok()
        assert result.unwrap() == 42
    
    @pytest.mark.asyncio
    async def test_try_async_failure(self):
        """Test try_async with failing function."""
        async def failing_func():
            raise ValueError("test error")
        
        result = await try_async(failing_func)
        assert result.is_err()
        assert isinstance(result.unwrap_err(), ValueError)


class TestResultChaining:
    """Test complex result chaining scenarios."""
    
    def test_chain_multiple_ok(self):
        """Test chaining multiple Ok results."""
        result = (Ok(5)
                 .and_then(lambda x: Ok(x * 2))
                 .and_then(lambda x: Ok(x + 1))
                 .map(lambda x: x * 3))
        
        assert result.is_ok()
        assert result.unwrap() == 33  # ((5 * 2) + 1) * 3
    
    def test_chain_with_early_error(self):
        """Test chaining with early error."""
        result = (Ok(5)
                 .and_then(lambda x: Err("error"))
                 .and_then(lambda x: Ok(x * 2))  # Should not execute
                 .map(lambda x: x * 3))  # Should not execute
        
        assert result.is_err()
        assert result.unwrap_err() == "error"
    
    @pytest.mark.asyncio
    async def test_async_chain_multiple_ok(self):
        """Test async chaining multiple Ok results."""
        async def double(x):
            return Ok(x * 2)
        
        async def add_one(x):
            return x + 1
        
        result = Ok(5)
        result = await result.and_then_async(double)
        result = await result.map_async(add_one)
        
        assert result.is_ok()
        assert result.unwrap() == 11  # (5 * 2) + 1
    
    @pytest.mark.asyncio
    async def test_async_chain_with_error(self):
        """Test async chaining with error."""
        async def failing_func(x):
            raise ValueError("async error")
        
        async def double(x):
            return Ok(x * 2)
        
        result = Ok(5)
        result = await result.and_then_async(failing_func)
        result = await result.and_then_async(double)  # Should not execute
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), ValueError)


class TestResultEquality:
    """Test result equality and representation."""
    
    def test_ok_equality(self):
        """Test Ok result equality."""
        ok1 = Ok(42)
        ok2 = Ok(42)
        ok3 = Ok(43)
        
        assert ok1 == ok2
        assert ok1 != ok3
    
    def test_err_equality(self):
        """Test Err result equality."""
        err1 = Err("error")
        err2 = Err("error")
        err3 = Err("different")
        
        assert err1 == err2
        assert err1 != err3
    
    def test_ok_err_inequality(self):
        """Test that Ok and Err are never equal."""
        ok_result = Ok(42)
        err_result = Err(42)
        
        assert ok_result != err_result
    
    def test_ok_repr(self):
        """Test Ok string representation."""
        result = Ok(42)
        assert "Ok" in str(result)
        assert "42" in str(result)
    
    def test_err_repr(self):
        """Test Err string representation."""
        result = Err("error")
        assert "Err" in str(result)
        assert "error" in str(result)


class TestResultTypeAnnotations:
    """Test that Result works with type annotations."""
    
    def test_result_type_alias(self):
        """Test that Result type alias works."""
        def get_result(success: bool) -> Result[int, str]:
            if success:
                return Ok(42)
            else:
                return Err("error")
        
        success_result = get_result(True)
        error_result = get_result(False)
        
        assert success_result.is_ok()
        assert error_result.is_err()
    
    def test_generic_result_handling(self):
        """Test generic result handling."""
        def process_result(result: Result[int, str]) -> str:
            if result.is_ok():
                return f"Success: {result.unwrap()}"
            else:
                return f"Error: {result.unwrap_err()}"
        
        ok_result = Ok(42)
        err_result = Err("failed")
        
        assert process_result(ok_result) == "Success: 42"
        assert process_result(err_result) == "Error: failed"


class TestEdgeCases:
    """Test edge cases and error conditions."""
    
    def test_ok_with_none(self):
        """Test Ok with None value."""
        result = Ok(None)
        assert result.is_ok()
        assert result.unwrap() is None
    
    def test_err_with_none(self):
        """Test Err with None error."""
        result = Err(None)
        assert result.is_err()
        assert result.unwrap_err() is None
    
    def test_nested_results(self):
        """Test nested Result types."""
        nested = Ok(Ok(42))
        assert nested.is_ok()
        inner = nested.unwrap()
        assert inner.is_ok()
        assert inner.unwrap() == 42
    
    def test_result_with_complex_types(self):
        """Test Result with complex data types."""
        data = {"key": "value", "numbers": [1, 2, 3]}
        result = Ok(data)
        
        assert result.is_ok()
        assert result.unwrap() == data
        assert result.unwrap()["key"] == "value"
    
    def test_unwrap_or_else_with_exception(self):
        """Test unwrap_or_else when default function raises."""
        result = Err("error")
        
        def failing_default():
            raise RuntimeError("Default failed")
        
        with pytest.raises(RuntimeError, match="Default failed"):
            result.unwrap_or_else(failing_default)
    
    def test_map_preserves_error_type(self):
        """Test that map preserves the original error type."""
        original_error = ValueError("original")
        result = Err(original_error)
        
        mapped = result.map(lambda x: x * 2)
        assert mapped.is_err()
        assert mapped.unwrap_err() is original_error
    
    @pytest.mark.asyncio
    async def test_concurrent_async_operations(self):
        """Test concurrent async operations on results."""
        async def async_double(x):
            await asyncio.sleep(0.01)  # Small delay
            return x * 2
        
        results = [Ok(i) for i in range(5)]
        
        # Process all results concurrently
        tasks = [result.map_async(async_double) for result in results]
        processed = await asyncio.gather(*tasks)
        
        # All should be Ok with doubled values
        for i, result in enumerate(processed):
            assert result.is_ok()
            assert result.unwrap() == i * 2