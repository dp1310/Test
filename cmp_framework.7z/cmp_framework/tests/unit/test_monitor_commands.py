"""Tests for CLI monitor commands."""

import pytest
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from typer.testing import CliRunner
import asyncio
import json

from cmp.cli.monitor_commands import monitor_app, health_status, show_metrics, view_logs


@pytest.fixture
def runner():
    """CLI test runner."""
    return CliRunner()


@pytest.fixture
def mock_health_status():
    """Mock health status."""
    mock_status = Mock()
    mock_status.is_healthy = True
    mock_status.is_ready = True
    mock_status.status.value = "healthy"
    mock_status.uptime_seconds = 123.45
    
    mock_check = Mock()
    mock_check.name = "database"
    mock_check.status.value = "healthy"
    mock_check.message = "Connection OK"
    mock_check.duration_ms = 15.2
    
    mock_status.checks = [mock_check]
    return mock_status


@pytest.fixture
def mock_metrics():
    """Mock metrics collector."""
    mock_metrics = Mock()
    
    # Mock counter values
    for attr in ['contexts_created', 'contexts_retrieved', 'contexts_updated', 
                 'contexts_deleted', 'workflows_executed', 'errors']:
        counter = Mock()
        counter._value.get.return_value = 42
        setattr(mock_metrics, attr, counter)
    
    mock_metrics.registry = Mock()
    return mock_metrics


def test_health_status_basic(runner, mock_health_status):
    """Test basic health status command."""
    with patch('cmp.cli.monitor_commands.HealthCheck') as mock_health_class:
        mock_health_instance = AsyncMock()
        mock_health_instance.get_health.return_value = mock_health_status
        mock_health_class.return_value = mock_health_instance
        
        result = runner.invoke(monitor_app, ["health"])
        
        assert result.exit_code == 0
        assert "System Status:" in result.stdout
        assert "HEALTHY" in result.stdout
        assert "123.45 seconds" in result.stdout


def test_health_status_detailed(runner, mock_health_status):
    """Test detailed health status command."""
    with patch('cmp.cli.monitor_commands.HealthCheck') as mock_health_class:
        mock_health_instance = AsyncMock()
        mock_health_instance.get_health.return_value = mock_health_status
        mock_health_class.return_value = mock_health_instance
        
        result = runner.invoke(monitor_app, ["health", "--detailed"])
        
        assert result.exit_code == 0
        assert "System Status:" in result.stdout
        assert "Health Checks" in result.stdout
        assert "database" in result.stdout
        assert "Connection OK" in result.stdout


def test_health_status_unhealthy(runner):
    """Test health status with unhealthy system."""
    mock_status = Mock()
    mock_status.is_healthy = False
    mock_status.is_ready = False
    mock_status.status.value = "unhealthy"
    mock_status.uptime_seconds = 60.0
    mock_status.checks = []
    
    with patch('cmp.cli.monitor_commands.HealthCheck') as mock_health_class:
        mock_health_instance = AsyncMock()
        mock_health_instance.get_health.return_value = mock_status
        mock_health_class.return_value = mock_health_instance
        
        result = runner.invoke(monitor_app, ["health"])
        
        assert result.exit_code == 0
        assert "UNHEALTHY" in result.stdout


def test_health_status_degraded(runner):
    """Test health status with degraded system."""
    mock_status = Mock()
    mock_status.is_healthy = False
    mock_status.is_ready = True
    mock_status.status.value = "degraded"
    mock_status.uptime_seconds = 30.0
    mock_status.checks = []
    
    with patch('cmp.cli.monitor_commands.HealthCheck') as mock_health_class:
        mock_health_instance = AsyncMock()
        mock_health_instance.get_health.return_value = mock_status
        mock_health_class.return_value = mock_health_instance
        
        result = runner.invoke(monitor_app, ["health"])
        
        assert result.exit_code == 0
        assert "DEGRADED" in result.stdout


def test_health_status_error(runner):
    """Test health status command with error."""
    with patch('cmp.cli.monitor_commands.HealthCheck') as mock_health_class:
        mock_health_class.side_effect = Exception("Health check failed")
        
        result = runner.invoke(monitor_app, ["health"])
        
        assert result.exit_code == 1
        assert "Error:" in result.stdout


def test_show_metrics_table_format(runner, mock_metrics):
    """Test metrics command with table format."""
    with patch('cmp.cli.monitor_commands.get_metrics_collector', return_value=mock_metrics):
        result = runner.invoke(monitor_app, ["metrics"])
        
        assert result.exit_code == 0
        assert "System Metrics" in result.stdout
        assert "Contexts Created" in result.stdout
        assert "42" in result.stdout


def test_show_metrics_json_format(runner, mock_metrics):
    """Test metrics command with JSON format."""
    with patch('cmp.cli.monitor_commands.get_metrics_collector', return_value=mock_metrics):
        result = runner.invoke(monitor_app, ["metrics", "--format", "json"])
        
        assert result.exit_code == 0
        
        # Should be valid JSON
        try:
            data = json.loads(result.stdout)
            assert data["contexts_created"] == 42
            assert data["workflows_executed"] == 42
        except json.JSONDecodeError:
            pytest.fail("Output is not valid JSON")


def test_show_metrics_prometheus_format(runner, mock_metrics):
    """Test metrics command with Prometheus format."""
    with patch('cmp.cli.monitor_commands.get_metrics_collector', return_value=mock_metrics):
        with patch('prometheus_client.generate_latest') as mock_generate:
            mock_generate.return_value = b"# HELP test_metric Test metric\ntest_metric 42\n"
            
            result = runner.invoke(monitor_app, ["metrics", "--format", "prometheus"])
            
            assert result.exit_code == 0
            assert "test_metric 42" in result.stdout


def test_show_metrics_error(runner):
    """Test metrics command with error."""
    with patch('cmp.cli.monitor_commands.get_metrics_collector') as mock_get_metrics:
        mock_get_metrics.side_effect = Exception("Metrics collection failed")
        
        result = runner.invoke(monitor_app, ["metrics"])
        
        assert result.exit_code == 1
        assert "Error:" in result.stdout


def test_view_logs_basic(runner):
    """Test basic logs command."""
    result = runner.invoke(monitor_app, ["logs"])
    
    assert result.exit_code == 0
    assert "Log viewing not yet implemented" in result.stdout
    assert "Level: INFO" in result.stdout
    assert "Follow: False" in result.stdout


def test_view_logs_with_options(runner):
    """Test logs command with options."""
    result = runner.invoke(monitor_app, ["logs", "--level", "DEBUG", "--follow"])
    
    assert result.exit_code == 0
    assert "Level: DEBUG" in result.stdout
    assert "Follow: True" in result.stdout
    assert "journalctl" in result.stdout
    assert "docker logs" in result.stdout


def test_health_status_detailed_with_degraded_check(runner):
    """Test detailed health status with degraded check."""
    mock_status = Mock()
    mock_status.is_healthy = True
    mock_status.is_ready = True
    mock_status.status.value = "healthy"
    mock_status.uptime_seconds = 100.0
    
    # Create a degraded check
    mock_check = Mock()
    mock_check.name = "cache"
    mock_check.status.value = "degraded"
    mock_check.message = "High latency"
    mock_check.duration_ms = 250.5
    
    mock_status.checks = [mock_check]
    
    with patch('cmp.cli.monitor_commands.HealthCheck') as mock_health_class:
        mock_health_instance = AsyncMock()
        mock_health_instance.get_health.return_value = mock_status
        mock_health_class.return_value = mock_health_instance
        
        result = runner.invoke(monitor_app, ["health", "--detailed"])
        
        assert result.exit_code == 0
        assert "cache" in result.stdout
        assert "degraded" in result.stdout
        assert "High latency" in result.stdout
        assert "250.50" in result.stdout


def test_health_status_detailed_with_unhealthy_check(runner):
    """Test detailed health status with unhealthy check."""
    mock_status = Mock()
    mock_status.is_healthy = False
    mock_status.is_ready = False
    mock_status.status.value = "unhealthy"
    mock_status.uptime_seconds = 50.0
    
    # Create an unhealthy check
    mock_check = Mock()
    mock_check.name = "database"
    mock_check.status.value = "unhealthy"
    mock_check.message = "Connection failed"
    mock_check.duration_ms = 5000.0
    
    mock_status.checks = [mock_check]
    
    with patch('cmp.cli.monitor_commands.HealthCheck') as mock_health_class:
        mock_health_instance = AsyncMock()
        mock_health_instance.get_health.return_value = mock_status
        mock_health_class.return_value = mock_health_instance
        
        result = runner.invoke(monitor_app, ["health", "--detailed"])
        
        assert result.exit_code == 0
        assert "database" in result.stdout
        assert "unhealthy" in result.stdout
        assert "Connection failed" in result.stdout


def test_show_metrics_table_format_explicit(runner, mock_metrics):
    """Test metrics command with explicit table format."""
    with patch('cmp.cli.monitor_commands.get_metrics_collector', return_value=mock_metrics):
        result = runner.invoke(monitor_app, ["metrics", "--format", "table"])
        
        assert result.exit_code == 0
        assert "System Metrics" in result.stdout
        assert "Contexts Retrieved" in result.stdout
        assert "Contexts Updated" in result.stdout
        assert "Contexts Deleted" in result.stdout
        assert "Errors" in result.stdout


def test_monitor_app_help(runner):
    """Test monitor app help."""
    result = runner.invoke(monitor_app, ["--help"])
    
    assert result.exit_code == 0
    assert "Monitoring and metrics commands" in result.stdout
    assert "health" in result.stdout
    assert "metrics" in result.stdout
    assert "logs" in result.stdout