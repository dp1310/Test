
import pytest
from datetime import timedelta, datetime, timezone
from jose import jwt
from fastapi import HTTPException
from cmp.api.auth import create_access_token, verify_token, verify_api_key, get_current_user, require_scope, User
from unittest.mock import MagicMock, patch

@pytest.fixture
def mock_config():
    with patch("cmp.api.auth.get_config") as mock:
        conf = MagicMock()
        conf.security.jwt_secret = "secret"
        conf.security.jwt_algorithm = "HS256"
        conf.security.jwt_expiration_minutes = 30
        conf.security.api_keys = ["valid-key"]
        conf.security.authentication_enabled = True
        mock.return_value = conf
        yield conf

def test_token_creation_and_verification(mock_config):
    data = {"sub": "user1", "tenant_id": "t1", "scopes": ["read"]}
    token = create_access_token(data)
    
    decoded = verify_token(token)
    assert decoded.username == "user1"
    assert decoded.tenant_id == "t1"
    assert decoded.scopes == ["read"]

def test_verify_token_invalid(mock_config):
    with pytest.raises(HTTPException):
        verify_token("invalid.token.here")

def test_api_key(mock_config):
    assert verify_api_key("valid-key") is True
    assert verify_api_key("invalid") is False

@pytest.mark.asyncio
async def test_get_current_user_jwt(mock_config):
    data = {"sub": "user1", "tenant_id": "t1", "scopes": ["read"]}
    token = create_access_token(data)
    credentials = MagicMock()
    credentials.credentials = token
    
    user = await get_current_user(credentials=credentials, api_key=None) # type: ignore
    assert user.username == "user1"

@pytest.mark.asyncio
async def test_get_current_user_api_key(mock_config):
    user = await get_current_user(credentials=None, api_key="valid-key") # type: ignore
    assert user.username == "api_key_user"

@pytest.mark.asyncio
async def test_get_current_user_disabled(mock_config):
    mock_config.security.authentication_enabled = False
    user = await get_current_user(credentials=None, api_key=None) # type: ignore
    assert user.username == "anonymous"

@pytest.mark.asyncio
async def test_get_current_user_no_auth(mock_config):
    with pytest.raises(HTTPException) as exc:
        await get_current_user(credentials=None, api_key=None) # type: ignore
    assert exc.value.status_code == 401

@pytest.mark.asyncio
async def test_require_scope():
    user = User(username="u", tenant_id="t", scopes=["read", "write"])
    
    # Success
    dep = require_scope("read")
    res = await dep(user)
    assert res == user
    
    # Failure
    dep = require_scope("admin")
    with pytest.raises(HTTPException) as exc:
        await dep(user)
    assert exc.value.status_code == 403
    
    # Admin wildcard
    admin = User(username="a", tenant_id="t", scopes=["*"])
    dep = require_scope("admin")
    res = await dep(admin)
    assert res == admin
