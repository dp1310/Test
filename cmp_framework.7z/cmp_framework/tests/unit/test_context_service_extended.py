
import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from cmp.services.context_service import ContextService, ContextStore, PolicyResult, PolicyViolationError, SchemaNotFoundError, ContextNotFoundError
from cmp.core.models import ContextEnvelope, Schema, Policy, Provenance, Metadata

@pytest.fixture
def mock_store():
    store = AsyncMock(spec=ContextStore)
    store.save = AsyncMock(return_value="ctx_123")
    store.get = AsyncMock()
    store.delete = AsyncMock(return_value=True)
    store.update = AsyncMock(return_value=True)
    # Correct mocking for async iterator method search
    async def mock_search(*args, **kwargs):
        for i in range(1):
             yield MagicMock()
    store.search = mock_search
    return store

@pytest.fixture
def mock_search_envelope():
    env = MagicMock(spec=ContextEnvelope)
    env.to_context.return_value = MagicMock()
    return env

@pytest.fixture
def service(mock_store):
    return ContextService(store=mock_store, schema_registry=MagicMock(), policy_service=MagicMock())

@pytest.fixture
def sample_envelope():
    return ContextEnvelope(
        id="ctx_123",
        data={"k": "v"},
        schema=Schema(name="s1", version="1.0", fields={}),
        policy=Policy.default(),
        provenance=Provenance.empty(),
        metadata=Metadata(tenant_id="t1")
    )


@pytest.mark.asyncio
async def test_create_schema_not_found(service):
    # Override _get_schema to return None
    service._get_schema = AsyncMock(return_value=None)
    
    result = await service.create(
        data={}, 
        schema_name="missing", 
        tenant_id="t1"
    )
    assert result.is_err()
    assert isinstance(result.unwrap_err(), SchemaNotFoundError)

@pytest.mark.asyncio
async def test_create_policy_violation(service):
    # Mock schema found
    service._get_schema = AsyncMock(return_value=Schema(name="s1", version="1.0", fields={}))
    # Mock policy failure
    service._check_policy = AsyncMock(return_value=PolicyResult(allowed=False, reason="no"))
    
    result = await service.create({"some": "data"}, "s1", "t1")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), PolicyViolationError)

@pytest.mark.asyncio
async def test_get_not_found(service, mock_store):
    mock_store.get.return_value = None
    result = await service.get("ctx_missing")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), ContextNotFoundError)

@pytest.mark.asyncio
async def test_get_policy_violation(service, mock_store, sample_envelope):
    mock_store.get.return_value = sample_envelope
    service._check_policy = AsyncMock(return_value=PolicyResult(allowed=False, reason="no read"))
    
    result = await service.get("ctx_123")
    assert result.is_err()
    assert isinstance(result.unwrap_err(), PolicyViolationError)

@pytest.mark.asyncio
async def test_get_envelope(service, mock_store, sample_envelope):
    mock_store.get.return_value = sample_envelope
    result = await service.get_envelope("ctx_123")
    assert result.is_ok()
    assert result.unwrap() == sample_envelope
    
    # Test not found
    mock_store.get.return_value = None
    result = await service.get_envelope("ctx_missing")
    assert result.is_err()

@pytest.mark.asyncio
async def test_list(service, mock_store, sample_envelope):
    mock_store.list_all = AsyncMock(return_value=[sample_envelope])
    result = await service.list(limit=5)
    assert result.is_ok()
    assert len(result.unwrap()) == 1

@pytest.mark.asyncio
async def test_search(service, mock_store, sample_envelope):
    # Mocking generator helper
    async def mock_search_gen(*args, **kwargs):
        yield sample_envelope
        
    mock_store.search = mock_search_gen
    
    results = []
    async for ctx in service.search({"q": "1"}, "t1"):
        results.append(ctx)
    assert len(results) == 1
    
    # Test policy violation
    service._check_policy = AsyncMock(return_value=PolicyResult(allowed=False))
    with pytest.raises(PolicyViolationError):
        async for _ in service.search({}, "t1"): pass

@pytest.mark.asyncio
async def test_update_not_found(service, mock_store):
    mock_store.get.return_value = None
    result = await service.update("ctx_missing", {})
    assert result.is_err()
    assert isinstance(result.unwrap_err(), ContextNotFoundError)

@pytest.mark.asyncio
async def test_update_policy_violation(service, mock_store, sample_envelope):
    mock_store.get.return_value = sample_envelope
    service._check_policy = AsyncMock(return_value=PolicyResult(allowed=False))
    
    result = await service.update("ctx_123", {})
    assert result.is_err()

@pytest.mark.asyncio
async def test_delete_not_found(service, mock_store):
    mock_store.get.return_value = None
    result = await service.delete("ctx_missing")
    assert result.is_err()

@pytest.mark.asyncio
async def test_delete_policy_violation(service, mock_store, sample_envelope):
    mock_store.get.return_value = sample_envelope
    service._check_policy = AsyncMock(return_value=PolicyResult(allowed=False))
    
    result = await service.delete("ctx_123")
    assert result.is_err()

@pytest.mark.asyncio
async def test_stream_updates(service):
    # Need to simulate sending an event
    import asyncio
    
    async def produce():
        await asyncio.sleep(0.01)
        await service._observable.notify(
            MagicMock(context_id="ctx_stream", event_type="test")
        )
    
    asyncio.create_task(produce())
    
    updates = []
    async for event in service.stream_updates("ctx_stream"):
        updates.append(event)
        break # Exit after one
        
    assert len(updates) == 1
    assert updates[0].context_id == "ctx_stream"
