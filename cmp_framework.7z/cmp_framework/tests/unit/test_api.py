
import pytest
from fastapi.testclient import TestClient
from cmp.api.server import app

client = TestClient(app)

def test_api_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_api_docs():
    response = client.get("/docs")
    assert response.status_code == 200

def test_api_metrics():
    response = client.get("/health/metrics")
    assert response.status_code == 200
    assert "cmp_contexts_created_total" in response.text
