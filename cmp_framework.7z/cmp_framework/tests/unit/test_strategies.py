"""
Unit tests for orchestration strategies.
"""

import pytest
from cmp.orchestration.strategies import (
    ChainingStrategy,
    FanOutFanInStrategy,
    EvolutionStrategy,
    Agent
)
from cmp.core.models import Context
from datetime import datetime


class MockAgent(Agent):
    """Mock agent for testing"""
    
    def __init__(self, agent_id: str, add_key: str):
        super().__init__(agent_id)
        self.add_key = add_key
    
    async def process(self, context: Context) -> Context:
        """Add a key to context"""
        return context.with_data(**{self.add_key: True})


@pytest.mark.asyncio
class TestChainingStrategy:
    """Tests for ChainingStrategy"""
    
    async def test_chaining_execution(self):
        """Test sequential chaining"""
        strategy = ChainingStrategy()
        
        context = Context(
            id="ctx_1",
            data={"initial": True},
            tenant_id="tenant_1",
            created_at=datetime.utcnow()
        )
        
        agents = [
            MockAgent("agent_1", "step_1"),
            MockAgent("agent_2", "step_2"),
            MockAgent("agent_3", "step_3")
        ]
        
        results = []
        async for result in strategy.execute(context, agents, {}):
            results.append(result)
        
        # Should have 3 results (one per agent)
        assert len(results) == 3
        
        # Check progressive addition
        assert "step_1" in results[0].data
        assert "step_2" in results[1].data
        assert "step_3" in results[2].data
        
        # Final result should have all keys
        final = results[-1]
        assert "initial" in final.data
        assert "step_1" in final.data
        assert "step_2" in final.data
        assert "step_3" in final.data


@pytest.mark.asyncio
class TestFanOutFanInStrategy:
    """Tests for FanOutFanInStrategy"""
    
    async def test_parallel_execution(self):
        """Test parallel fan-out/fan-in"""
        strategy = FanOutFanInStrategy()
        
        context = Context(
            id="ctx_1",
            data={"initial": True},
            tenant_id="tenant_1",
            created_at=datetime.utcnow()
        )
        
        agents = [
            MockAgent("agent_1", "parallel_1"),
            MockAgent("agent_2", "parallel_2"),
            MockAgent("agent_3", "parallel_3")
        ]
        
        results = []
        async for result in strategy.execute(context, agents, {}):
            results.append(result)
        
        # Should have 1 aggregated result
        assert len(results) == 1
        
        # Should have all parallel results
        final = results[0]
        assert "parallel_1" in final.data
        assert "parallel_2" in final.data
        assert "parallel_3" in final.data


@pytest.mark.asyncio
class TestEvolutionStrategy:
    """Tests for EvolutionStrategy"""
    
    async def test_evolution_execution(self):
        """Test progressive evolution"""
        strategy = EvolutionStrategy()
        
        context = Context(
            id="ctx_1",
            data={"initial": True},
            tenant_id="tenant_1",
            created_at=datetime.utcnow()
        )
        
        agents = [
            MockAgent("agent_1", "evolved_1"),
            MockAgent("agent_2", "evolved_2"),
            MockAgent("agent_3", "evolved_3")
        ]
        
        results = []
        async for result in strategy.execute(context, agents, {}):
            results.append(result)
        
        # Should have 3 results (one per evolution step)
        assert len(results) == 3
        
        # Each result should accumulate previous data
        assert "evolved_1" in results[0].data
        assert "evolved_1" in results[1].data
        assert "evolved_2" in results[1].data
        assert "evolved_1" in results[2].data
        assert "evolved_2" in results[2].data
        assert "evolved_3" in results[2].data
