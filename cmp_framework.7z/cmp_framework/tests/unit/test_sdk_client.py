"""Tests for SDK client."""

import pytest
from unittest.mock import Mock, AsyncMock, patch
from cmp.sdk.client import CMP, CMPClient, ServiceContainer, ContextBuilder, WorkflowBuilder
from cmp.core.models import Context
from cmp.core.result import Ok, Err
from cmp.orchestration.strategies import Agent


class MockAgent(Agent):
    """Mock agent for testing."""
    
    def __init__(self, name: str):
        super().__init__(agent_id=name)
        self.name = name
    
    async def process(self, context: Context) -> Context:
        return context
    
    async def execute(self, context: Context) -> Context:
        return context


class TestServiceContainer:
    """Test ServiceContainer class."""
    
    def test_service_container_creation(self):
        """Test creating service container."""
        container = ServiceContainer("tenant-1")
        assert container.tenant_id == "tenant-1"
        assert container._services == {}
        assert container._current_context is None
    
    def test_register_and_get_service(self):
        """Test registering and getting services."""
        container = ServiceContainer("tenant-1")
        mock_service = Mock()
        
        container.register_service("test_service", mock_service)
        retrieved = container.get_service("test_service")
        
        assert retrieved is mock_service
    
    def test_get_nonexistent_service(self):
        """Test getting non-existent service."""
        container = ServiceContainer("tenant-1")
        service = container.get_service("nonexistent")
        assert service is None
    
    def test_set_and_get_current_context(self):
        """Test setting and getting current context."""
        container = ServiceContainer("tenant-1")
        context = Context(id="ctx-1", data={"key": "value"}, tenant_id="tenant-1")
        
        container.set_current_context(context)
        retrieved = container.get_current_context()
        
        assert retrieved is context
    
    def test_get_current_context_not_set(self):
        """Test getting current context when not set."""
        container = ServiceContainer("tenant-1")
        
        with pytest.raises(RuntimeError, match="No current context set"):
            container.get_current_context()


class TestContextBuilder:
    """Test ContextBuilder class."""
    
    @pytest.fixture
    def mock_context_service(self):
        """Mock context service."""
        service = AsyncMock()
        service.create.return_value = Ok("ctx-123")
        return service
    
    def test_context_builder_creation(self, mock_context_service):
        """Test creating context builder."""
        builder = ContextBuilder(mock_context_service, "tenant-1")
        assert builder._service is mock_context_service
        assert builder._tenant_id == "tenant-1"
        assert builder._data == {}
        assert builder._schema_name == "default"
        assert builder._metadata == {}
    
    def test_with_data(self, mock_context_service):
        """Test setting data."""
        builder = ContextBuilder(mock_context_service, "tenant-1")
        data = {"key": "value", "number": 42}
        
        result = builder.with_data(data)
        
        assert result is builder  # Fluent interface
        assert builder._data == data
    
    def test_with_schema(self, mock_context_service):
        """Test setting schema."""
        builder = ContextBuilder(mock_context_service, "tenant-1")
        
        result = builder.with_schema("user_schema")
        
        assert result is builder
        assert builder._schema_name == "user_schema"
    
    def test_with_metadata(self, mock_context_service):
        """Test setting metadata."""
        builder = ContextBuilder(mock_context_service, "tenant-1")
        
        result = builder.with_metadata(version="1.0", author="test")
        
        assert result is builder
        assert builder._metadata == {"version": "1.0", "author": "test"}
    
    def test_with_metadata_multiple_calls(self, mock_context_service):
        """Test multiple metadata calls."""
        builder = ContextBuilder(mock_context_service, "tenant-1")
        
        builder.with_metadata(version="1.0")
        builder.with_metadata(author="test", priority="high")
        
        assert builder._metadata == {
            "version": "1.0",
            "author": "test", 
            "priority": "high"
        }
    
    @pytest.mark.asyncio
    async def test_create_success(self, mock_context_service):
        """Test successful context creation."""
        builder = ContextBuilder(mock_context_service, "tenant-1")
        builder.with_data({"key": "value"}).with_schema("test_schema")
        
        context_id = await builder.create()
        
        assert context_id == "ctx-123"
        mock_context_service.create.assert_called_once_with(
            data={"key": "value"},
            schema_name="test_schema",
            tenant_id="tenant-1"
        )
    
    @pytest.mark.asyncio
    async def test_create_with_metadata(self, mock_context_service):
        """Test context creation with metadata."""
        builder = ContextBuilder(mock_context_service, "tenant-1")
        builder.with_data({"key": "value"}).with_metadata(version="1.0")
        
        await builder.create()
        
        mock_context_service.create.assert_called_once_with(
            data={"key": "value"},
            schema_name="default",
            tenant_id="tenant-1",
            version="1.0"
        )
    
    @pytest.mark.asyncio
    async def test_create_failure(self, mock_context_service):
        """Test context creation failure."""
        mock_context_service.create.return_value = Err("Creation failed")
        builder = ContextBuilder(mock_context_service, "tenant-1")
        
        with pytest.raises(Exception):  # unwrap() will raise
            await builder.create()


class TestWorkflowBuilder:
    """Test WorkflowBuilder class."""
    
    @pytest.fixture
    def mock_context_service(self):
        """Mock context service."""
        service = AsyncMock()
        context = Context(id="ctx-1", data={"key": "value"}, tenant_id="tenant-1")
        service.get.return_value = Ok(context)
        return service
    
    @pytest.fixture
    def mock_orchestration_service(self):
        """Mock orchestration service."""
        service = AsyncMock()
        
        # Create a proper async iterator
        async def mock_execute_workflow(workflow_name, context, agents):
            yield context
        
        service.execute_workflow = mock_execute_workflow
        return service
    
    def test_workflow_builder_creation(self, mock_context_service, mock_orchestration_service):
        """Test creating workflow builder."""
        builder = WorkflowBuilder(
            "test_workflow",
            mock_context_service,
            mock_orchestration_service,
            "tenant-1"
        )
        
        assert builder._workflow_name == "test_workflow"
        assert builder._context_service is mock_context_service
        assert builder._orchestration_service is mock_orchestration_service
        assert builder._tenant_id == "tenant-1"
        assert builder._context_id is None
        assert builder._agents == []
    
    def test_with_context(self, mock_context_service, mock_orchestration_service):
        """Test setting context ID."""
        builder = WorkflowBuilder(
            "test_workflow",
            mock_context_service,
            mock_orchestration_service,
            "tenant-1"
        )
        
        result = builder.with_context("ctx-123")
        
        assert result is builder
        assert builder._context_id == "ctx-123"
    
    def test_with_agents(self, mock_context_service, mock_orchestration_service):
        """Test setting agents."""
        builder = WorkflowBuilder(
            "test_workflow",
            mock_context_service,
            mock_orchestration_service,
            "tenant-1"
        )
        agents = [MockAgent("agent1"), MockAgent("agent2")]
        
        result = builder.with_agents(agents)
        
        assert result is builder
        assert builder._agents == agents
    
    @pytest.mark.asyncio
    async def test_execute_success(self, mock_context_service, mock_orchestration_service):
        """Test successful workflow execution."""
        builder = WorkflowBuilder(
            "test_workflow",
            mock_context_service,
            mock_orchestration_service,
            "tenant-1"
        )
        builder.with_context("ctx-1")
        
        results = []
        async for result in builder.execute():
            results.append(result)
        
        assert len(results) == 1
        mock_context_service.get.assert_called_once_with("ctx-1")
    
    @pytest.mark.asyncio
    async def test_execute_without_context(self, mock_context_service, mock_orchestration_service):
        """Test workflow execution without context ID."""
        builder = WorkflowBuilder(
            "test_workflow",
            mock_context_service,
            mock_orchestration_service,
            "tenant-1"
        )
        
        with pytest.raises(ValueError, match="Context ID is required"):
            async for _ in builder.execute():
                pass
    
    @pytest.mark.asyncio
    async def test_execute_context_not_found(self, mock_context_service, mock_orchestration_service):
        """Test workflow execution with non-existent context."""
        mock_context_service.get.return_value = Err("Context not found")
        builder = WorkflowBuilder(
            "test_workflow",
            mock_context_service,
            mock_orchestration_service,
            "tenant-1"
        )
        builder.with_context("nonexistent")
        
        with pytest.raises(ValueError, match="Context not found: nonexistent"):
            async for _ in builder.execute():
                pass
    
    @pytest.mark.asyncio
    async def test_execute_with_agents(self, mock_context_service, mock_orchestration_service):
        """Test workflow execution with agents."""
        agents = [MockAgent("agent1")]
        builder = WorkflowBuilder(
            "test_workflow",
            mock_context_service,
            mock_orchestration_service,
            "tenant-1"
        )
        builder.with_context("ctx-1").with_agents(agents)
        
        results = []
        async for result in builder.execute():
            results.append(result)
        
        assert len(results) == 1
        # Verify context service was called
        mock_context_service.get.assert_called_once_with("ctx-1")


class TestCMP:
    """Test CMP main client class."""
    
    def test_cmp_initialization(self):
        """Test CMP client initialization."""
        client = CMP("tenant-1")
        
        assert client.tenant_id == "tenant-1"
        assert client.config == {}
        assert client._store is not None
        assert client._observable is not None
        assert client._policy_service is not None
        assert client._context_service is not None
        assert client._orchestration_service is not None
        assert client._container is not None
    
    def test_cmp_initialization_with_config(self):
        """Test CMP client initialization with config."""
        config = {"setting": "value"}
        client = CMP("tenant-1", config)
        
        assert client.config == config
    
    def test_context_builder_creation(self):
        """Test creating context builder."""
        client = CMP("tenant-1")
        builder = client.context()
        
        assert isinstance(builder, ContextBuilder)
        assert builder._tenant_id == "tenant-1"
        assert builder._service is client._context_service
    
    def test_workflow_builder_creation(self):
        """Test creating workflow builder."""
        client = CMP("tenant-1")
        builder = client.workflow("test_workflow")
        
        assert isinstance(builder, WorkflowBuilder)
        assert builder._workflow_name == "test_workflow"
        assert builder._tenant_id == "tenant-1"
        assert builder._context_service is client._context_service
        assert builder._orchestration_service is client._orchestration_service
    
    @pytest.mark.asyncio
    async def test_register_agent(self):
        """Test registering agent (placeholder)."""
        client = CMP("tenant-1")
        agent = MockAgent("test_agent")
        
        # Should not raise (placeholder implementation)
        await client.register_agent(agent)
    
    def test_services_property(self):
        """Test accessing services container."""
        client = CMP("tenant-1")
        services = client.services
        
        assert isinstance(services, ServiceContainer)
        assert services.tenant_id == "tenant-1"
        
        # Verify services are registered
        assert services.get_service('context_service') is client._context_service
        assert services.get_service('policy_service') is client._policy_service
        assert services.get_service('orchestration_service') is client._orchestration_service
    
    def test_service_container_setup(self):
        """Test that service container is set up for DI."""
        with patch('cmp.sdk.client.set_service_container') as mock_set_container:
            client = CMP("tenant-1")
            mock_set_container.assert_called_once_with(client._container)
    
    def test_cmp_client_alias(self):
        """Test CMPClient alias."""
        assert CMPClient is CMP


class TestCMPIntegration:
    """Test CMP client integration scenarios."""
    
    @pytest.mark.asyncio
    async def test_full_context_workflow(self):
        """Test full context creation and workflow execution."""
        client = CMP("tenant-1")
        
        # Mock successful context creation
        with patch.object(client._context_service, 'create', return_value=Ok("ctx-123")):
            with patch.object(client._context_service, 'get') as mock_get:
                context = Context(id="ctx-123", data={"key": "value"}, tenant_id="tenant-1")
                mock_get.return_value = Ok(context)
                
                with patch.object(client._orchestration_service, 'execute_workflow') as mock_execute:
                    async def mock_workflow_execution(workflow_name, context, agents):
                        yield context
                    
                    mock_execute.return_value = mock_workflow_execution("test", context, [])
                    
                    # Create context
                    context_id = await (client.context()
                                      .with_data({"key": "value"})
                                      .with_schema("test_schema")
                                      .create())
                    
                    assert context_id == "ctx-123"
                    
                    # Execute workflow
                    results = []
                    async for result in (client.workflow("test_workflow")
                                       .with_context(context_id)
                                       .execute()):
                        results.append(result)
                    
                    assert len(results) == 1
                    assert results[0].id == "ctx-123"
    
    @pytest.mark.asyncio
    async def test_fluent_api_chaining(self):
        """Test fluent API method chaining."""
        client = CMP("tenant-1")
        
        # Test context builder chaining
        builder = (client.context()
                  .with_data({"name": "test"})
                  .with_schema("user")
                  .with_metadata(version="1.0", author="test"))
        
        assert builder._data == {"name": "test"}
        assert builder._schema_name == "user"
        assert builder._metadata == {"version": "1.0", "author": "test"}
        
        # Test workflow builder chaining
        agents = [MockAgent("agent1")]
        workflow_builder = (client.workflow("test_workflow")
                          .with_context("ctx-123")
                          .with_agents(agents))
        
        assert workflow_builder._context_id == "ctx-123"
        assert workflow_builder._agents == agents
    
    def test_service_dependency_injection(self):
        """Test that services are properly set up for DI."""
        client = CMP("tenant-1")
        container = client.services
        
        # Verify all expected services are registered
        expected_services = [
            'context_service',
            'policy_service', 
            'orchestration_service'
        ]
        
        for service_name in expected_services:
            service = container.get_service(service_name)
            assert service is not None
    
    def test_multiple_clients_isolation(self):
        """Test that multiple clients are properly isolated."""
        client1 = CMP("tenant-1")
        client2 = CMP("tenant-2")
        
        assert client1.tenant_id != client2.tenant_id
        assert client1._container is not client2._container
        assert client1._context_service is not client2._context_service
        
        # Verify tenant isolation in containers
        assert client1.services.tenant_id == "tenant-1"
        assert client2.services.tenant_id == "tenant-2"


class TestErrorHandling:
    """Test error handling in SDK client."""
    
    @pytest.mark.asyncio
    async def test_context_creation_error_propagation(self):
        """Test that context creation errors are properly propagated."""
        client = CMP("tenant-1")
        
        with patch.object(client._context_service, 'create', return_value=Err("Creation failed")):
            builder = client.context().with_data({"key": "value"})
            
            with pytest.raises(Exception):  # unwrap() will raise
                await builder.create()
    
    @pytest.mark.asyncio
    async def test_workflow_execution_error_handling(self):
        """Test workflow execution error handling."""
        client = CMP("tenant-1")
        
        # Test missing context ID
        workflow_builder = client.workflow("test")
        
        with pytest.raises(ValueError, match="Context ID is required"):
            async for _ in workflow_builder.execute():
                pass
        
        # Test context not found
        with patch.object(client._context_service, 'get', return_value=Err("Not found")):
            workflow_builder = client.workflow("test").with_context("nonexistent")
            
            with pytest.raises(ValueError, match="Context not found"):
                async for _ in workflow_builder.execute():
                    pass
    
    def test_service_container_error_handling(self):
        """Test service container error handling."""
        container = ServiceContainer("tenant-1")
        
        # Test getting current context when not set
        with pytest.raises(RuntimeError, match="No current context set"):
            container.get_current_context()
        
        # Test getting non-existent service returns None
        service = container.get_service("nonexistent")
        assert service is None