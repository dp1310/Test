import sys
import importlib
from unittest.mock import patch, MagicMock

import pytest
import time
import asyncio
from cmp.monitoring.metrics import get_metrics_collector, MetricsTimer
from cmp.monitoring.health_checks import HealthCheck, HealthStatus, HealthCheckResult
from cmp.monitoring.structured_logging import get_logger

# Module under test
import cmp.monitoring


@pytest.fixture
def reload_monitoring():
    """Fixture to reload the monitoring module for each test case."""
    importlib.reload(cmp.monitoring)
    yield
    importlib.reload(cmp.monitoring)

def test_tracing_available_by_default(reload_monitoring):
    """Test that tracing is available by default when dependencies are installed."""
    assert cmp.monitoring.TRACING_AVAILABLE is True
    # Check if a real function is imported (not a no-op)
    assert callable(cmp.monitoring.configure_tracing)
    # A simple check to see if it's not the no-op lambda
    assert cmp.monitoring.configure_tracing.__name__ != '<lambda>'

@patch.dict(sys.modules, {'cmp.monitoring.tracing': None})
def test_tracing_unavailable_when_missing(reload_monitoring):
    """Test that tracing is gracefully disabled when dependencies are missing."""
    # We need to reload the module for the ImportError to be triggered
    importlib.reload(cmp.monitoring)
    
    assert cmp.monitoring.TRACING_AVAILABLE is False
    
    # Test that the no-op functions are in place
    assert cmp.monitoring.configure_tracing() is None
    assert cmp.monitoring.get_tracer() is None
    
    # Test a decorator
    @cmp.monitoring.trace_function()
    def my_func():
        return "hello"
        
    assert my_func() == "hello"
    
    assert cmp.monitoring.TracingContext is None
    assert cmp.monitoring.add_span_attribute() is None
    assert cmp.monitoring.add_span_event() is None
    assert cmp.monitoring.get_current_span() is None
    assert cmp.monitoring.inject_trace_context() is None
    assert cmp.monitoring.extract_trace_context() is None
    assert cmp.monitoring.shutdown_tracing() is None

def test_all_exports():
    """Test that __all__ contains all expected names."""
    expected_exports = [
        "MetricsCollector", "Metrics", "MetricsTimer", "get_metrics_collector",
        "configure_logging", "get_logger", "set_context", "clear_context",
        "get_current_context", "LogLevel", "StructuredLogger",
        "HealthCheck", "HealthStatus", "HealthCheckResult", "SystemHealth", "check_service_url",
        "configure_tracing", "get_tracer", "trace_function", "trace_workflow",
        "trace_agent", "TracingContext", "add_span_attribute", "add_span_event",
        "get_current_span", "inject_trace_context", "extract_trace_context",
        "shutdown_tracing",
        "CPUProfiler", "MemoryProfiler", "ProfileResult", "profile_cpu",
        "profile_memory", "profile_async_function",
    ]
    
    for export in expected_exports:
        assert hasattr(cmp.monitoring, export)
    
    assert len(cmp.monitoring.__all__) == len(expected_exports)

def test_metrics_collection():
    collector = get_metrics_collector()
    collector.reset()
    
    collector.record_context_created(duration_ms=10.0)
    collector.record_error()
    
    metrics = collector.get_metrics()
    assert metrics.contexts_created == 1
    assert metrics.errors_total == 1
    assert metrics.avg_context_create_time_ms == 10.0
    
    prom = collector.to_prometheus()
    assert "cmp_contexts_created_total 1" in prom

def test_metrics_timer():
    collector = get_metrics_collector()
    collector.reset()
    
    with MetricsTimer("test_op") as timer:
        time.sleep(0.01)
    
    assert timer.duration_ms >= 10.0

@pytest.mark.asyncio
async def test_health_checks():
    health = HealthCheck()
    
    async def check_ok():
        return HealthCheckResult(
            name="test_service",
            status=HealthStatus.HEALTHY,
            message="All good",
            timestamp="now",
            duration_ms=1.0
        )
        
    health.add_check("test_service", check_ok)
    
    report = await health.get_health()
    assert report.status == HealthStatus.HEALTHY
    assert any(c.name == "test_service" for c in report.checks)

def test_structured_logging():
    logger = get_logger("test")
    # This just tests that it doesn't crash
    logger.info("test message", key="value")
    logger.error("error message", error="test error")
