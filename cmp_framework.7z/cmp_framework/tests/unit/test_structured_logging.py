"""
Tests for structured logging.
"""

import pytest
import logging
import json
import sys
from unittest.mock import patch, MagicMock
from datetime import datetime, timezone
from io import StringIO

from cmp.monitoring.structured_logging import (
    LogLevel, SensitiveDataMasker, JSONFormatter, TextFormatter,
    StructuredLogger, configure_logging, get_logger, set_context,
    clear_context, get_current_context,
    context_id_var, workflow_id_var, tenant_id_var, request_id_var
)


class TestLogLevel:
    """Test LogLevel enum"""
    
    def test_log_level_values(self):
        """Test all log level values"""
        assert LogLevel.DEBUG == "DEBUG"
        assert LogLevel.INFO == "INFO"
        assert LogLevel.WARNING == "WARNING"
        assert LogLevel.ERROR == "ERROR"
        assert LogLevel.CRITICAL == "CRITICAL"


class TestSensitiveDataMasker:
    """Test SensitiveDataMasker class"""
    
    def test_mask_dict_with_sensitive_keys(self):
        """Test masking dictionary with sensitive keys"""
        data = {
            "username": "john_doe",
            "password": "secret123",
            "api_key": "abc123",
            "token": "xyz789",
            "normal_field": "normal_value"
        }
        
        masked = SensitiveDataMasker.mask_dict(data)
        
        assert masked["username"] == "john_doe"
        assert masked["password"] == "***MASKED***"
        assert masked["api_key"] == "***MASKED***"
        assert masked["token"] == "***MASKED***"
        assert masked["normal_field"] == "normal_value"
    
    def test_mask_dict_case_insensitive(self):
        """Test masking is case insensitive"""
        data = {
            "PASSWORD": "secret123",
            "Api_Key": "abc123",
            "JWT_TOKEN": "xyz789"
        }
        
        masked = SensitiveDataMasker.mask_dict(data)
        
        assert masked["PASSWORD"] == "***MASKED***"
        assert masked["Api_Key"] == "***MASKED***"
        assert masked["JWT_TOKEN"] == "***MASKED***"
    
    def test_mask_dict_nested(self):
        """Test masking nested dictionaries"""
        data = {
            "user": {
                "name": "john",
                "credentials": {
                    "password": "secret123",
                    "api_key": "abc123"
                }
            },
            "config": {
                "database_url": "postgres://localhost",
                "secret": "hidden"
            }
        }
        
        masked = SensitiveDataMasker.mask_dict(data)
        
        assert masked["user"]["name"] == "john"
        assert masked["user"]["credentials"]["password"] == "***MASKED***"
        assert masked["user"]["credentials"]["api_key"] == "***MASKED***"
        assert masked["config"]["database_url"] == "postgres://localhost"
        assert masked["config"]["secret"] == "***MASKED***"
    
    def test_mask_dict_with_lists(self):
        """Test masking dictionaries within lists"""
        data = {
            "users": [
                {"name": "john", "password": "secret1"},
                {"name": "jane", "api_key": "key123"}
            ],
            "simple_list": ["item1", "item2"]
        }
        
        masked = SensitiveDataMasker.mask_dict(data)
        
        assert masked["users"][0]["name"] == "john"
        assert masked["users"][0]["password"] == "***MASKED***"
        assert masked["users"][1]["name"] == "jane"
        assert masked["users"][1]["api_key"] == "***MASKED***"
        assert masked["simple_list"] == ["item1", "item2"]
    
    def test_mask_dict_partial_key_match(self):
        """Test masking with partial key matches"""
        data = {
            "user_password": "secret123",
            "oauth_token": "token123",
            "private_key_data": "key123",
            "authorization_header": "Bearer xyz"
        }
        
        masked = SensitiveDataMasker.mask_dict(data)
        
        assert masked["user_password"] == "***MASKED***"
        assert masked["oauth_token"] == "***MASKED***"
        assert masked["private_key_data"] == "***MASKED***"
        assert masked["authorization_header"] == "***MASKED***"
    
    def test_mask_dict_empty(self):
        """Test masking empty dictionary"""
        data = {}
        masked = SensitiveDataMasker.mask_dict(data)
        assert masked == {}
    
    def test_sensitive_keys_list(self):
        """Test that all expected sensitive keys are present"""
        expected_keys = {
            "password", "secret", "token", "api_key", "apikey",
            "authorization", "auth", "jwt", "private_key", "privatekey"
        }
        assert SensitiveDataMasker.SENSITIVE_KEYS == expected_keys


class TestJSONFormatter:
    """Test JSONFormatter class"""
    
    @pytest.fixture
    def formatter(self):
        """Create JSON formatter"""
        return JSONFormatter()
    
    @pytest.fixture
    def log_record(self):
        """Create a sample log record"""
        record = logging.LogRecord(
            name="test.logger",
            level=logging.INFO,
            pathname="/path/to/file.py",
            lineno=42,
            msg="Test message",
            args=(),
            exc_info=None,
            func="test_function"
        )
        return record
    
    def test_format_basic_record(self, formatter, log_record):
        """Test formatting basic log record"""
        formatted = formatter.format(log_record)
        log_data = json.loads(formatted)
        
        assert log_data["level"] == "INFO"
        assert log_data["logger"] == "test.logger"
        assert log_data["message"] == "Test message"
        assert "timestamp" in log_data
        assert log_data["source"]["file"] == "/path/to/file.py"
        assert log_data["source"]["line"] == 42
        assert log_data["source"]["function"] == "test_function"
    
    def test_format_with_context(self, formatter, log_record):
        """Test formatting with context variables"""
        # Set context variables
        context_id_var.set("ctx-123")
        workflow_id_var.set("wf-456")
        tenant_id_var.set("tenant-789")
        request_id_var.set("req-abc")
        
        try:
            formatted = formatter.format(log_record)
            log_data = json.loads(formatted)
            
            assert log_data["context_id"] == "ctx-123"
            assert log_data["workflow_id"] == "wf-456"
            assert log_data["tenant_id"] == "tenant-789"
            assert log_data["request_id"] == "req-abc"
        finally:
            # Clean up context
            clear_context()
    
    def test_format_with_extra_fields(self, formatter, log_record):
        """Test formatting with extra fields"""
        log_record.extra = {
            "user_id": "user123",
            "action": "login",
            "password": "secret123"  # Should be masked
        }
        
        formatted = formatter.format(log_record)
        log_data = json.loads(formatted)
        
        assert "extra" in log_data
        assert log_data["extra"]["user_id"] == "user123"
        assert log_data["extra"]["action"] == "login"
        assert log_data["extra"]["password"] == "***MASKED***"
    
    def test_format_with_exception(self, formatter, log_record):
        """Test formatting with exception info"""
        try:
            raise ValueError("Test exception")
        except ValueError:
            log_record.exc_info = sys.exc_info()
        
        formatted = formatter.format(log_record)
        log_data = json.loads(formatted)
        
        assert "exception" in log_data
        assert log_data["exception"]["type"] == "ValueError"
        assert log_data["exception"]["message"] == "Test exception"
        assert "traceback" in log_data["exception"]
    
    def test_format_timestamp_format(self, formatter, log_record):
        """Test timestamp format"""
        formatted = formatter.format(log_record)
        log_data = json.loads(formatted)
        
        timestamp = log_data["timestamp"]
        assert timestamp.endswith("Z")
        
        # Should be valid ISO format - remove the Z and parse
        timestamp_without_z = timestamp.rstrip("Z")
        datetime.fromisoformat(timestamp_without_z)
    
    def test_format_partial_context(self, formatter, log_record):
        """Test formatting with partial context"""
        # Set only some context variables
        context_id_var.set("ctx-123")
        tenant_id_var.set("tenant-789")
        
        try:
            formatted = formatter.format(log_record)
            log_data = json.loads(formatted)
            
            assert log_data["context_id"] == "ctx-123"
            assert log_data["tenant_id"] == "tenant-789"
            assert "workflow_id" not in log_data
            assert "request_id" not in log_data
        finally:
            clear_context()


class TestTextFormatter:
    """Test TextFormatter class"""
    
    @pytest.fixture
    def formatter(self):
        """Create text formatter"""
        return TextFormatter()
    
    @pytest.fixture
    def log_record(self):
        """Create a sample log record"""
        record = logging.LogRecord(
            name="test.logger",
            level=logging.INFO,
            pathname="/path/to/file.py",
            lineno=42,
            msg="Test message",
            args=(),
            exc_info=None,
            func="test_function"
        )
        return record
    
    def test_format_basic_record(self, formatter, log_record):
        """Test formatting basic log record"""
        formatted = formatter.format(log_record)
        
        assert "INFO" in formatted
        assert "test.logger" in formatted
        assert "Test message" in formatted
        assert "\033[32m" in formatted  # Green color for INFO
        assert "\033[0m" in formatted   # Reset color
    
    def test_format_with_context(self, formatter, log_record):
        """Test formatting with context variables"""
        context_id_var.set("ctx-123456789")  # Long ID to test truncation
        workflow_id_var.set("wf-456789012")   # Long ID to test truncation
        tenant_id_var.set("tenant-789")
        
        try:
            formatted = formatter.format(log_record)
            
            assert "ctx=ctx-1234" in formatted  # Should be truncated to 8 chars
            assert "wf=wf-45678" in formatted   # Should be truncated to 8 chars
            assert "tenant=tenant-789" in formatted
        finally:
            clear_context()
    
    def test_format_with_exception(self, formatter, log_record):
        """Test formatting with exception info"""
        try:
            raise ValueError("Test exception")
        except ValueError:
            log_record.exc_info = sys.exc_info()
        
        formatted = formatter.format(log_record)
        
        assert "Test message" in formatted
        assert "ValueError" in formatted
        assert "Test exception" in formatted
    
    def test_format_different_log_levels(self, formatter):
        """Test formatting different log levels with colors"""
        levels_colors = [
            (logging.DEBUG, "\033[36m"),    # Cyan
            (logging.INFO, "\033[32m"),     # Green
            (logging.WARNING, "\033[33m"),  # Yellow
            (logging.ERROR, "\033[31m"),    # Red
            (logging.CRITICAL, "\033[35m")  # Magenta
        ]
        
        for level, color in levels_colors:
            record = logging.LogRecord(
                name="test.logger",
                level=level,
                pathname="/path/to/file.py",
                lineno=42,
                msg="Test message",
                args=(),
                exc_info=None,
                func="test_function"
            )
            
            formatted = formatter.format(record)
            assert color in formatted
            assert "\033[0m" in formatted  # Reset color
    
    def test_format_no_context(self, formatter, log_record):
        """Test formatting without any context"""
        clear_context()
        
        formatted = formatter.format(log_record)
        
        # Should not contain context brackets
        assert "[" not in formatted or "] " not in formatted
        assert "ctx=" not in formatted
        assert "wf=" not in formatted
        assert "tenant=" not in formatted


class TestStructuredLogger:
    """Test StructuredLogger class"""
    
    @pytest.fixture
    def mock_logger(self):
        """Create mock Python logger"""
        return MagicMock(spec=logging.Logger)
    
    @pytest.fixture
    def structured_logger(self, mock_logger):
        """Create structured logger with mock"""
        return StructuredLogger("test.logger", mock_logger)
    
    def test_structured_logger_initialization(self, mock_logger):
        """Test structured logger initialization"""
        logger = StructuredLogger("test.logger", mock_logger)
        assert logger.name == "test.logger"
        assert logger._logger is mock_logger
    
    def test_debug_logging(self, structured_logger, mock_logger):
        """Test debug logging"""
        structured_logger.debug("Debug message", user_id="123", action="test")
        
        mock_logger.log.assert_called_once_with(
            logging.DEBUG,
            "Debug message",
            extra={"extra": {"user_id": "123", "action": "test"}}
        )
    
    def test_info_logging(self, structured_logger, mock_logger):
        """Test info logging"""
        structured_logger.info("Info message", request_id="req-123")
        
        mock_logger.log.assert_called_once_with(
            logging.INFO,
            "Info message",
            extra={"extra": {"request_id": "req-123"}}
        )
    
    def test_warning_logging(self, structured_logger, mock_logger):
        """Test warning logging"""
        structured_logger.warning("Warning message", error_code=404)
        
        mock_logger.log.assert_called_once_with(
            logging.WARNING,
            "Warning message",
            extra={"extra": {"error_code": 404}}
        )
    
    def test_error_logging(self, structured_logger, mock_logger):
        """Test error logging"""
        structured_logger.error("Error message", exception_type="ValueError")
        
        mock_logger.log.assert_called_once_with(
            logging.ERROR,
            "Error message",
            extra={"extra": {"exception_type": "ValueError"}}
        )
    
    def test_critical_logging(self, structured_logger, mock_logger):
        """Test critical logging"""
        structured_logger.critical("Critical message", system="database")
        
        mock_logger.log.assert_called_once_with(
            logging.CRITICAL,
            "Critical message",
            extra={"extra": {"system": "database"}}
        )
    
    def test_exception_logging(self, structured_logger, mock_logger):
        """Test exception logging"""
        structured_logger.exception("Exception occurred", context="processing")
        
        mock_logger.exception.assert_called_once_with(
            "Exception occurred",
            extra={"extra": {"context": "processing"}}
        )
    
    def test_logging_without_extra_fields(self, structured_logger, mock_logger):
        """Test logging without extra fields"""
        structured_logger.info("Simple message")
        
        mock_logger.log.assert_called_once_with(
            logging.INFO,
            "Simple message",
            extra={"extra": {}}
        )


class TestLoggingConfiguration:
    """Test logging configuration functions"""
    
    def teardown_method(self):
        """Clean up after each test"""
        # Reset logging configuration
        logging.getLogger().handlers.clear()
        import cmp.monitoring.structured_logging
        cmp.monitoring.structured_logging._configured = False
    
    def test_configure_logging_json_format(self):
        """Test configuring logging with JSON format"""
        with patch('sys.stdout', new_callable=StringIO):
            configure_logging(level="INFO", format_type="json")
            
            root_logger = logging.getLogger()
            assert root_logger.level == logging.INFO
            assert len(root_logger.handlers) == 1
            
            handler = root_logger.handlers[0]
            assert isinstance(handler.formatter, JSONFormatter)
    
    def test_configure_logging_text_format(self):
        """Test configuring logging with text format"""
        with patch('sys.stdout', new_callable=StringIO):
            configure_logging(level="DEBUG", format_type="text")
            
            root_logger = logging.getLogger()
            assert root_logger.level == logging.DEBUG
            assert len(root_logger.handlers) == 1
            
            handler = root_logger.handlers[0]
            assert isinstance(handler.formatter, TextFormatter)
    
    def test_configure_logging_with_file(self):
        """Test configuring logging with file output"""
        with patch('sys.stdout', new_callable=StringIO), \
             patch('logging.FileHandler') as mock_file_handler:
            
            mock_handler = MagicMock()
            mock_file_handler.return_value = mock_handler
            
            configure_logging(level="WARNING", format_type="json", output_file="app.log")
            
            root_logger = logging.getLogger()
            assert len(root_logger.handlers) == 2  # Console + File
            
            mock_file_handler.assert_called_once_with("app.log")
            mock_handler.setFormatter.assert_called_once()
    
    def test_configure_logging_clears_existing_handlers(self):
        """Test that configure_logging clears existing handlers"""
        root_logger = logging.getLogger()
        
        # Clear any existing handlers first
        root_logger.handlers.clear()
        
        # Add a dummy handler
        dummy_handler = logging.StreamHandler()
        root_logger.addHandler(dummy_handler)
        assert len(root_logger.handlers) == 1
        
        with patch('sys.stdout', new_callable=StringIO):
            configure_logging(level="INFO", format_type="json")
        
        # Should have cleared old handlers and added new one
        assert len(root_logger.handlers) == 1
        assert root_logger.handlers[0] is not dummy_handler
    
    def test_get_logger_auto_configure(self):
        """Test that get_logger auto-configures logging"""
        with patch('sys.stdout', new_callable=StringIO):
            logger = get_logger("test.module")
            
            assert isinstance(logger, StructuredLogger)
            assert logger.name == "test.module"
            
            # Should have auto-configured logging
            root_logger = logging.getLogger()
            assert len(root_logger.handlers) > 0
    
    def test_get_logger_with_existing_config(self):
        """Test get_logger with existing configuration"""
        with patch('sys.stdout', new_callable=StringIO):
            # Configure first
            configure_logging(level="DEBUG", format_type="text")
            
            logger = get_logger("test.module")
            
            assert isinstance(logger, StructuredLogger)
            assert logger.name == "test.module"


class TestContextManagement:
    """Test context management functions"""
    
    def teardown_method(self):
        """Clean up context after each test"""
        clear_context()
    
    def test_set_context_all_fields(self):
        """Test setting all context fields"""
        set_context(
            context_id="ctx-123",
            workflow_id="wf-456",
            tenant_id="tenant-789",
            request_id="req-abc"
        )
        
        assert context_id_var.get() == "ctx-123"
        assert workflow_id_var.get() == "wf-456"
        assert tenant_id_var.get() == "tenant-789"
        assert request_id_var.get() == "req-abc"
    
    def test_set_context_partial_fields(self):
        """Test setting partial context fields"""
        set_context(context_id="ctx-123", tenant_id="tenant-789")
        
        assert context_id_var.get() == "ctx-123"
        assert workflow_id_var.get() is None
        assert tenant_id_var.get() == "tenant-789"
        assert request_id_var.get() is None
    
    def test_set_context_none_values(self):
        """Test setting context with None values (should not change)"""
        # Set initial values
        set_context(context_id="ctx-123", tenant_id="tenant-789")
        
        # Try to set with None (should not change existing values)
        set_context(context_id=None, workflow_id="wf-456")
        
        assert context_id_var.get() == "ctx-123"  # Should remain unchanged
        assert workflow_id_var.get() == "wf-456"  # Should be set
        assert tenant_id_var.get() == "tenant-789"  # Should remain unchanged
    
    def test_clear_context(self):
        """Test clearing all context"""
        # Set some context
        set_context(
            context_id="ctx-123",
            workflow_id="wf-456",
            tenant_id="tenant-789",
            request_id="req-abc"
        )
        
        # Clear context
        clear_context()
        
        assert context_id_var.get() is None
        assert workflow_id_var.get() is None
        assert tenant_id_var.get() is None
        assert request_id_var.get() is None
    
    def test_get_current_context(self):
        """Test getting current context"""
        set_context(
            context_id="ctx-123",
            workflow_id="wf-456",
            tenant_id="tenant-789"
        )
        
        context = get_current_context()
        
        expected = {
            "context_id": "ctx-123",
            "workflow_id": "wf-456",
            "tenant_id": "tenant-789",
            "request_id": None
        }
        assert context == expected
    
    def test_get_current_context_empty(self):
        """Test getting current context when empty"""
        clear_context()
        
        context = get_current_context()
        
        expected = {
            "context_id": None,
            "workflow_id": None,
            "tenant_id": None,
            "request_id": None
        }
        assert context == expected


class TestLoggingIntegration:
    """Integration tests for structured logging"""
    
    def teardown_method(self):
        """Clean up after each test"""
        clear_context()
        logging.getLogger().handlers.clear()
        import cmp.monitoring.structured_logging
        cmp.monitoring.structured_logging._configured = False
    
    def test_end_to_end_json_logging(self):
        """Test end-to-end JSON logging with context"""
        output = StringIO()
        
        with patch('sys.stdout', output):
            configure_logging(level="INFO", format_type="json")
            logger = get_logger("test.module")
            
            # Set context
            set_context(context_id="ctx-123", tenant_id="acme")
            
            # Log message
            logger.info("User action", user_id="user456", action="login")
            
            # Parse output
            log_output = output.getvalue().strip()
            log_data = json.loads(log_output)
            
            assert log_data["level"] == "INFO"
            assert log_data["logger"] == "test.module"
            assert log_data["message"] == "User action"
            assert log_data["context_id"] == "ctx-123"
            assert log_data["tenant_id"] == "acme"
            assert log_data["extra"]["user_id"] == "user456"
            assert log_data["extra"]["action"] == "login"
    
    def test_end_to_end_text_logging(self):
        """Test end-to-end text logging with context"""
        output = StringIO()
        
        with patch('sys.stdout', output):
            configure_logging(level="INFO", format_type="text")
            logger = get_logger("test.module")
            
            # Set context
            set_context(context_id="ctx-123456789", tenant_id="acme")
            
            # Log message
            logger.info("User action")
            
            # Check output
            log_output = output.getvalue()
            
            assert "INFO" in log_output
            assert "test.module" in log_output
            assert "User action" in log_output
            assert "ctx=ctx-1234" in log_output  # Truncated
            assert "tenant=acme" in log_output
    
    def test_sensitive_data_masking_integration(self):
        """Test sensitive data masking in real logging"""
        output = StringIO()
        
        with patch('sys.stdout', output):
            configure_logging(level="INFO", format_type="json")
            logger = get_logger("test.module")
            
            # Log with sensitive data
            logger.info(
                "User authentication",
                user_id="user123",
                password="secret123",
                api_key="key456",
                normal_field="normal_value"
            )
            
            # Parse output
            log_output = output.getvalue().strip()
            log_data = json.loads(log_output)
            
            extra = log_data["extra"]
            assert extra["user_id"] == "user123"
            assert extra["password"] == "***MASKED***"
            assert extra["api_key"] == "***MASKED***"
            assert extra["normal_field"] == "normal_value"
    
    def test_exception_logging_integration(self):
        """Test exception logging integration"""
        output = StringIO()
        
        with patch('sys.stdout', output):
            configure_logging(level="ERROR", format_type="json")
            logger = get_logger("test.module")
            
            try:
                raise ValueError("Test exception")
            except ValueError:
                logger.exception("An error occurred", operation="test")
            
            # Parse output
            log_output = output.getvalue().strip()
            log_data = json.loads(log_output)
            
            assert log_data["level"] == "ERROR"
            assert log_data["message"] == "An error occurred"
            assert log_data["extra"]["operation"] == "test"
            assert "exception" in log_data
            assert log_data["exception"]["type"] == "ValueError"
            assert log_data["exception"]["message"] == "Test exception"
            assert "traceback" in log_data["exception"]