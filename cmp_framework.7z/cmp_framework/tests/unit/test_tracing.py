"""Tests for distributed tracing utilities."""

import pytest
import asyncio
from unittest.mock import Mock, patch, MagicMock
from contextvars import copy_context


def test_tracing_available_import():
    """Test that tracing module can be imported."""
    try:
        from cmp.monitoring.tracing import TRACING_AVAILABLE
        assert isinstance(TRACING_AVAILABLE, bool)
    except ImportError:
        pytest.skip("Tracing module not available")


def test_configure_tracing_not_available():
    """Test configure_tracing when OpenTelemetry is not available."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import configure_tracing
        # Should not raise an error
        configure_tracing(service_name="test", enabled=True)


def test_get_tracer_not_available():
    """Test get_tracer when tracing is not available."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import get_tracer
        tracer = get_tracer()
        assert tracer is not None  # Should return a no-op tracer


def test_no_op_span():
    """Test NoOpSpan functionality."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import get_tracer
        tracer = get_tracer()
        span = tracer.start_span("test")
        
        # Should not raise errors
        span.set_attribute("key", "value")
        span.set_status("OK")
        span.record_exception(Exception("test"))
        span.add_event("test_event")
        span.end()
        
        # Test context manager
        with span:
            pass


def test_trace_function_decorator_basic():
    """Test basic trace_function decorator."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import trace_function
        
        @trace_function()
        def test_func(x):
            return x * 2
        
        result = test_func(5)
        assert result == 10


@pytest.mark.asyncio
async def test_trace_function_decorator_async():
    """Test trace_function decorator on async function."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import trace_function
        
        @trace_function()
        async def test_async_func(x):
            await asyncio.sleep(0.01)
            return x * 3
        
        result = await test_async_func(4)
        assert result == 12


def test_trace_workflow_decorator():
    """Test trace_workflow decorator."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import trace_workflow
        
        @trace_workflow("test_workflow")
        def workflow_func():
            return "result"
        
        result = workflow_func()
        assert result == "result"


def test_trace_agent_decorator():
    """Test trace_agent decorator."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import trace_agent
        
        @trace_agent("test_agent")
        def agent_func():
            return "result"
        
        result = agent_func()
        assert result == "result"


def test_tracing_context_sync():
    """Test TracingContext as sync context manager."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import TracingContext
        
        with TracingContext("test_span") as span:
            assert span is not None


@pytest.mark.asyncio
async def test_tracing_context_async():
    """Test TracingContext as async context manager."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import TracingContext
        
        async with TracingContext("test_span") as span:
            assert span is not None


def test_add_span_attribute_no_span():
    """Test add_span_attribute when no current span."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import add_span_attribute
        # Should not raise error
        add_span_attribute("test_key", "test_value")


def test_add_span_event_no_span():
    """Test add_span_event when no current span."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import add_span_event
        # Should not raise error
        add_span_event("test_event")


def test_get_current_span_none():
    """Test get_current_span when no span is set."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import get_current_span
        span = get_current_span()
        assert span is None


def test_inject_trace_context():
    """Test inject_trace_context function."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import inject_trace_context
        carrier = {}
        # Should not raise error
        inject_trace_context(carrier)


def test_extract_trace_context():
    """Test extract_trace_context function."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import extract_trace_context
        carrier = {"traceparent": "00-trace-span-01"}
        # Should not raise error
        result = extract_trace_context(carrier)


@pytest.mark.asyncio
async def test_shutdown_tracing_no_provider():
    """Test shutdown_tracing when no provider is set."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import shutdown_tracing
        # Should not raise error
        await shutdown_tracing()


def test_context_var_import():
    """Test that context variable can be imported."""
    try:
        from cmp.monitoring.tracing import current_span_var
        assert current_span_var is not None
    except ImportError:
        pytest.skip("Context variable not available")


def test_trace_function_with_exception():
    """Test trace_function decorator when function raises exception."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import trace_function
        
        @trace_function()
        def failing_func():
            raise ValueError("Test error")
        
        with pytest.raises(ValueError, match="Test error"):
            failing_func()


@pytest.mark.asyncio
async def test_tracing_context_with_exception():
    """Test TracingContext when exception occurs."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', False):
        from cmp.monitoring.tracing import TracingContext
        
        with pytest.raises(ValueError, match="Test error"):
            async with TracingContext("test_span") as span:
                raise ValueError("Test error")


def test_configure_tracing_disabled():
    """Test configure_tracing when disabled."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', True):
        with patch('cmp.monitoring.tracing.trace') as mock_trace:
            from cmp.monitoring.tracing import configure_tracing
            mock_tracer = Mock()
            mock_trace.get_tracer.return_value = mock_tracer
            
            configure_tracing(enabled=False)
            
            mock_trace.get_tracer.assert_called_once()


def test_get_tracer_available():
    """Test get_tracer when tracing is available."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', True):
        with patch('cmp.monitoring.tracing._tracer', None):
            with patch('cmp.monitoring.tracing.trace') as mock_trace:
                from cmp.monitoring.tracing import get_tracer
                mock_tracer = Mock()
                mock_trace.get_tracer.return_value = mock_tracer
                
                tracer = get_tracer()
                
                mock_trace.get_tracer.assert_called_once()
                assert tracer == mock_tracer


def test_configure_tracing_with_jaeger():
    """Test configure_tracing with Jaeger endpoint."""
    with patch('cmp.monitoring.tracing.TRACING_AVAILABLE', True):
        with patch('cmp.monitoring.tracing.TracerProvider') as mock_provider_class:
            with patch('cmp.monitoring.tracing.JaegerExporter') as mock_exporter_class:
                with patch('cmp.monitoring.tracing.BatchSpanProcessor') as mock_processor_class:
                    with patch('cmp.monitoring.tracing.Resource') as mock_resource_class:
                        with patch('cmp.monitoring.tracing.trace') as mock_trace:
                            from cmp.monitoring.tracing import configure_tracing
                            
                            mock_tracer_provider = Mock()
                            mock_provider_class.return_value = mock_tracer_provider
                            
                            configure_tracing(
                                service_name="test-service",
                                jaeger_endpoint="http://localhost:14268/api/traces",
                                enabled=True
                            )
                            
                            mock_resource_class.assert_called_once()
                            mock_provider_class.assert_called_once()
                            mock_exporter_class.assert_called_once()
                            mock_processor_class.assert_called_once()
                            mock_tracer_provider.add_span_processor.assert_called_once()


def test_trace_function_sync_with_mocked_tracer():
    """Test trace_function decorator on sync function with mocked tracer."""
    with patch('cmp.monitoring.tracing.get_tracer') as mock_get_tracer:
        from cmp.monitoring.tracing import trace_function
        
        mock_tracer = Mock()
        mock_span = Mock()
        mock_tracer.start_as_current_span.return_value.__enter__ = Mock(return_value=mock_span)
        mock_tracer.start_as_current_span.return_value.__exit__ = Mock(return_value=None)
        mock_get_tracer.return_value = mock_tracer
        
        @trace_function(span_name="test_span", attributes={"key": "value"})
        def test_func(x):
            return x * 2
        
        result = test_func(5)
        
        assert result == 10
        mock_tracer.start_as_current_span.assert_called_once_with("test_span")
        mock_span.set_attribute.assert_any_call("key", "value")
        mock_span.set_attribute.assert_any_call("function.name", "test_func")