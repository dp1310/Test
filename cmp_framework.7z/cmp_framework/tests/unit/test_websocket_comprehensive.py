"""Comprehensive tests for websocket functionality."""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch
from datetime import datetime, timezone
from cmp.api.websocket.manager import ConnectionManager, handle_websocket
from fastapi import WebSocket, WebSocketDisconnect

@pytest.fixture
def manager():
    return ConnectionManager()

@pytest.mark.asyncio
async def test_connection_manager_complete_lifecycle(manager):
    """Test complete connection manager lifecycle."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    # Connect
    await manager.connect(mock_ws, conn_id, "tenant1")
    assert conn_id in manager.active_connections
    assert manager.metadata[conn_id]["tenant_id"] == "tenant1"
    assert "connected_at" in manager.metadata[conn_id]
    assert "channels" in manager.metadata[conn_id]
    
    # Subscribe to multiple channels
    await manager.subscribe(conn_id, "channel1")
    await manager.subscribe(conn_id, "channel2")
    assert conn_id in manager.subscriptions["channel1"]
    assert conn_id in manager.subscriptions["channel2"]
    assert "channel1" in manager.metadata[conn_id]["channels"]
    assert "channel2" in manager.metadata[conn_id]["channels"]
    
    # Send personal message
    await manager.send_personal_message({"type": "msg"}, conn_id)
    mock_ws.send_json.assert_called_with({"type": "msg"})
    
    # Broadcast to specific channel
    await manager.broadcast({"type": "broadcast"}, "channel1")
    assert mock_ws.send_json.call_count >= 2
    
    # Unsubscribe from one channel
    await manager.unsubscribe(conn_id, "channel1")
    assert conn_id not in manager.subscriptions["channel1"]
    assert "channel1" not in manager.metadata[conn_id]["channels"]
    assert conn_id in manager.subscriptions["channel2"]  # Still subscribed to channel2
    
    # Disconnect
    manager.disconnect(conn_id)
    assert conn_id not in manager.active_connections
    assert conn_id not in manager.metadata
    assert conn_id not in manager.subscriptions.get("channel2", set())

@pytest.mark.asyncio
async def test_connection_with_default_tenant(manager):
    """Test connection with default tenant."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    assert manager.metadata[conn_id]["tenant_id"] == "default"

@pytest.mark.asyncio
async def test_disconnect_nonexistent_connection(manager):
    """Test disconnecting a connection that doesn't exist."""
    # Should not raise an error
    manager.disconnect("nonexistent")

@pytest.mark.asyncio
async def test_subscribe_new_channel(manager):
    """Test subscribing to a new channel."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    await manager.subscribe(conn_id, "new_channel")
    
    assert "new_channel" in manager.subscriptions
    assert conn_id in manager.subscriptions["new_channel"]

@pytest.mark.asyncio
async def test_unsubscribe_nonexistent_channel(manager):
    """Test unsubscribing from a channel that doesn't exist."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    # Should not raise an error
    await manager.unsubscribe(conn_id, "nonexistent_channel")

@pytest.mark.asyncio
async def test_send_personal_message_nonexistent_connection(manager):
    """Test sending message to nonexistent connection."""
    # Should not raise an error
    await manager.send_personal_message({"type": "test"}, "nonexistent")

@pytest.mark.asyncio
async def test_broadcast_to_nonexistent_channel(manager):
    """Test broadcasting to a channel that doesn't exist."""
    # Should not raise an error
    await manager.broadcast({"type": "test"}, "nonexistent_channel")

@pytest.mark.asyncio
async def test_send_heartbeat(manager):
    """Test sending heartbeat to connection."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    await manager.send_heartbeat(conn_id)
    
    # Should have called send_json with heartbeat message
    mock_ws.send_json.assert_called()
    call_args = mock_ws.send_json.call_args[0][0]
    assert call_args["type"] == "heartbeat"
    assert "timestamp" in call_args

@pytest.mark.asyncio
async def test_get_stats_comprehensive(manager):
    """Test comprehensive stats functionality."""
    mock_ws1 = AsyncMock(spec=WebSocket)
    mock_ws2 = AsyncMock(spec=WebSocket)
    
    await manager.connect(mock_ws1, "user1")
    await manager.connect(mock_ws2, "user2")
    
    await manager.subscribe("user1", "channel1")
    await manager.subscribe("user2", "channel1")
    await manager.subscribe("user1", "channel2")
    
    stats = manager.get_stats()
    assert stats["total_connections"] == 2
    assert stats["total_channels"] == 2
    assert stats["connections_per_channel"]["channel1"] == 2
    assert stats["connections_per_channel"]["channel2"] == 1

@pytest.mark.asyncio
async def test_handle_websocket_complete_flow():
    """Test complete websocket handling flow."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = [
        {"type": "subscribe", "channel": "ch1"},
        {"type": "ping"},
        {"type": "unsubscribe", "channel": "ch1"},
        WebSocketDisconnect()
    ]
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.subscribe = AsyncMock()
        mock_manager.unsubscribe = AsyncMock()
        mock_manager.send_personal_message = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        mock_manager.connect.assert_called_once_with(mock_ws, "user1", "tenant1")
        mock_manager.subscribe.assert_called_with("user1", "ch1")
        mock_manager.unsubscribe.assert_called_with("user1", "ch1")
        
        # Check all send_personal_message calls
        calls = mock_manager.send_personal_message.call_args_list
        assert len(calls) == 3  # subscribed, pong, unsubscribed
        
        # Check subscribed response
        assert calls[0][0][0]["type"] == "subscribed"
        assert calls[0][0][0]["channel"] == "ch1"
        
        # Check pong response
        assert calls[1][0][0]["type"] == "pong"
        
        # Check unsubscribed response
        assert calls[2][0][0]["type"] == "unsubscribed"
        assert calls[2][0][0]["channel"] == "ch1"
        
        mock_manager.disconnect.assert_called_once_with("user1")

@pytest.mark.asyncio
async def test_handle_websocket_with_exception():
    """Test websocket handling with general exception."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = Exception("Connection error")
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        mock_manager.connect.assert_called_once()
        mock_manager.disconnect.assert_called_once_with("user1")

@pytest.mark.asyncio
async def test_handle_websocket_subscribe_without_channel():
    """Test websocket subscribe message without channel."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = [
        {"type": "subscribe"},  # No channel
        WebSocketDisconnect()
    ]
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.subscribe = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        # Should not call subscribe without channel
        mock_manager.subscribe.assert_not_called()

@pytest.mark.asyncio
async def test_handle_websocket_unsubscribe_without_channel():
    """Test websocket unsubscribe message without channel."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = [
        {"type": "unsubscribe"},  # No channel
        WebSocketDisconnect()
    ]
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.unsubscribe = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        # Should not call unsubscribe without channel
        mock_manager.unsubscribe.assert_not_called()

@pytest.mark.asyncio
async def test_broadcast_all_connections(manager):
    """Test broadcasting to all connections."""
    ws1 = AsyncMock(spec=WebSocket)
    ws2 = AsyncMock(spec=WebSocket)
    await manager.connect(ws1, "u1")
    await manager.connect(ws2, "u2")
    
    await manager.broadcast({"type": "all"})
    ws1.send_json.assert_called()
    ws2.send_json.assert_called()

@pytest.mark.asyncio
async def test_send_error_handling(manager):
    """Test error handling when sending messages."""
    ws = AsyncMock(spec=WebSocket)
    ws.send_json.side_effect = Exception("Send failed")
    
    await manager.connect(ws, "u1")
    await manager.send_personal_message({"type": "test"}, "u1")
    
    # Should disconnect on error
    assert "u1" not in manager.active_connections

@pytest.mark.asyncio
async def test_disconnect_with_multiple_channels(manager):
    """Test disconnecting a connection subscribed to multiple channels."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    await manager.subscribe(conn_id, "channel1")
    await manager.subscribe(conn_id, "channel2")
    
    # Verify subscriptions
    assert conn_id in manager.subscriptions["channel1"]
    assert conn_id in manager.subscriptions["channel2"]
    
    # Disconnect
    manager.disconnect(conn_id)
    
    # Should be removed from all channels
    assert conn_id not in manager.subscriptions.get("channel1", set())
    assert conn_id not in manager.subscriptions.get("channel2", set())
    assert conn_id not in manager.active_connections
    assert conn_id not in manager.metadata

@pytest.mark.asyncio
async def test_multiple_connections_same_channel(manager):
    """Test multiple connections subscribing to the same channel."""
    ws1 = AsyncMock(spec=WebSocket)
    ws2 = AsyncMock(spec=WebSocket)
    ws3 = AsyncMock(spec=WebSocket)
    
    await manager.connect(ws1, "user1")
    await manager.connect(ws2, "user2")
    await manager.connect(ws3, "user3")
    
    # Subscribe all to same channel
    await manager.subscribe("user1", "common_channel")
    await manager.subscribe("user2", "common_channel")
    await manager.subscribe("user3", "common_channel")
    
    # Broadcast to channel
    await manager.broadcast({"type": "channel_msg"}, "common_channel")
    
    # All should receive the message
    ws1.send_json.assert_called_with({"type": "channel_msg"})
    ws2.send_json.assert_called_with({"type": "channel_msg"})
    ws3.send_json.assert_called_with({"type": "channel_msg"})

@pytest.mark.asyncio
async def test_unsubscribe_connection_not_in_metadata(manager):
    """Test unsubscribing when connection is not in metadata."""
    # Create subscription without proper metadata
    manager.subscriptions["test_channel"] = {"user1"}
    
    # Should not raise error
    await manager.unsubscribe("user1", "test_channel")
    
    # Should remove from subscription
    assert "user1" not in manager.subscriptions["test_channel"]

@pytest.mark.asyncio
async def test_send_heartbeat_to_nonexistent_connection(manager):
    """Test sending heartbeat to nonexistent connection."""
    # Should not raise error
    await manager.send_heartbeat("nonexistent")

@pytest.mark.asyncio
async def test_handle_websocket_unknown_message_type():
    """Test websocket handling with unknown message type."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = [
        {"type": "unknown_type", "data": "test"},
        WebSocketDisconnect()
    ]
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        # Should handle unknown message type gracefully
        mock_manager.connect.assert_called_once()
        mock_manager.disconnect.assert_called_once_with("user1")

@pytest.mark.asyncio
async def test_stats_empty_manager(manager):
    """Test stats when manager is empty."""
    stats = manager.get_stats()
    
    assert stats["total_connections"] == 0
    assert stats["total_channels"] == 0
    assert stats["connections_per_channel"] == {}

@pytest.mark.asyncio
async def test_connection_metadata_structure(manager):
    """Test connection metadata structure."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    tenant_id = "test_tenant"
    
    await manager.connect(mock_ws, conn_id, tenant_id)
    
    metadata = manager.metadata[conn_id]
    assert metadata["tenant_id"] == tenant_id
    assert "connected_at" in metadata
    assert isinstance(metadata["channels"], set)
    
    # Verify timestamp format
    connected_at = metadata["connected_at"]
    datetime.fromisoformat(connected_at)  # Should not raise exception