"""Tests for websocket functionality."""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch
from datetime import datetime, timezone
from cmp.api.websocket.manager import ConnectionManager, handle_websocket
from fastapi import WebSocket, WebSocketDisconnect

@pytest.fixture
def manager():
    return ConnectionManager()

@pytest.mark.asyncio
async def test_connection_manager_cycle(manager):
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    # Connect
    await manager.connect(mock_ws, conn_id, "tenant1")
    assert conn_id in manager.active_connections
    assert manager.metadata[conn_id]["tenant_id"] == "tenant1"
    assert "connected_at" in manager.metadata[conn_id]
    assert "channels" in manager.metadata[conn_id]
    
    # Subscribe
    await manager.subscribe(conn_id, "channel1")
    assert conn_id in manager.subscriptions["channel1"]
    assert "channel1" in manager.metadata[conn_id]["channels"]
    
    # Send Personal Message
    await manager.send_personal_message({"type": "msg"}, conn_id)
    mock_ws.send_json.assert_called_with({"type": "msg"})
    
    # Broadcast
    await manager.broadcast({"type": "broadcast"}, "channel1")
    # Verify send_json called again (mock_ws is same object)
    assert mock_ws.send_json.call_count >= 2
    
    # Unsubscribe
    await manager.unsubscribe(conn_id, "channel1")
    assert conn_id not in manager.subscriptions["channel1"]
    assert "channel1" not in manager.metadata[conn_id]["channels"]
    
    # Disconnect
    manager.disconnect(conn_id)
    assert conn_id not in manager.active_connections
    assert conn_id not in manager.metadata

@pytest.mark.asyncio
async def test_connect_with_default_tenant(manager):
    """Test connection with default tenant."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    assert manager.metadata[conn_id]["tenant_id"] == "default"

@pytest.mark.asyncio
async def test_disconnect_nonexistent_connection(manager):
    """Test disconnecting a connection that doesn't exist."""
    # Should not raise an error
    manager.disconnect("nonexistent")

@pytest.mark.asyncio
async def test_subscribe_new_channel(manager):
    """Test subscribing to a new channel."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    await manager.subscribe(conn_id, "new_channel")
    
    assert "new_channel" in manager.subscriptions
    assert conn_id in manager.subscriptions["new_channel"]

@pytest.mark.asyncio
async def test_unsubscribe_nonexistent_channel(manager):
    """Test unsubscribing from a channel that doesn't exist."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    # Should not raise an error
    await manager.unsubscribe(conn_id, "nonexistent_channel")

@pytest.mark.asyncio
async def test_send_personal_message_nonexistent_connection(manager):
    """Test sending message to nonexistent connection."""
    # Should not raise an error
    await manager.send_personal_message({"type": "test"}, "nonexistent")

@pytest.mark.asyncio
async def test_broadcast_to_nonexistent_channel(manager):
    """Test broadcasting to a channel that doesn't exist."""
    # Should not raise an error
    await manager.broadcast({"type": "test"}, "nonexistent_channel")

@pytest.mark.asyncio
async def test_send_heartbeat(manager):
    """Test sending heartbeat to connection."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    await manager.send_heartbeat(conn_id)
    
    # Should have called send_json with heartbeat message
    mock_ws.send_json.assert_called()
    call_args = mock_ws.send_json.call_args[0][0]
    assert call_args["type"] == "heartbeat"
    assert "timestamp" in call_args

@pytest.mark.asyncio
async def test_get_stats_comprehensive(manager):
    """Test comprehensive stats functionality."""
    mock_ws1 = AsyncMock(spec=WebSocket)
    mock_ws2 = AsyncMock(spec=WebSocket)
    
    await manager.connect(mock_ws1, "user1")
    await manager.connect(mock_ws2, "user2")
    
    await manager.subscribe("user1", "channel1")
    await manager.subscribe("user2", "channel1")
    await manager.subscribe("user1", "channel2")
    
    stats = manager.get_stats()
    assert stats["total_connections"] == 2
    assert stats["total_channels"] == 2
    assert stats["connections_per_channel"]["channel1"] == 2
    assert stats["connections_per_channel"]["channel2"] == 1

@pytest.mark.asyncio
async def test_handle_websocket_complete_flow():
    """Test complete websocket handling flow."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = [
        {"type": "subscribe", "channel": "ch1"},
        {"type": "ping"},
        {"type": "unsubscribe", "channel": "ch1"},
        WebSocketDisconnect()
    ]
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.subscribe = AsyncMock()
        mock_manager.unsubscribe = AsyncMock()
        mock_manager.send_personal_message = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        mock_manager.connect.assert_called_once_with(mock_ws, "user1", "tenant1")
        mock_manager.subscribe.assert_called_with("user1", "ch1")
        mock_manager.unsubscribe.assert_called_with("user1", "ch1")
        
        # Check all send_personal_message calls
        calls = mock_manager.send_personal_message.call_args_list
        assert len(calls) == 3  # subscribed, pong, unsubscribed
        
        # Check subscribed response
        assert calls[0][0][0]["type"] == "subscribed"
        assert calls[0][0][0]["channel"] == "ch1"
        
        # Check pong response
        assert calls[1][0][0]["type"] == "pong"
        
        # Check unsubscribed response
        assert calls[2][0][0]["type"] == "unsubscribed"
        assert calls[2][0][0]["channel"] == "ch1"
        
        mock_manager.disconnect.assert_called_once_with("user1")

@pytest.mark.asyncio
async def test_handle_websocket_with_exception():
    """Test websocket handling with general exception."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = Exception("Connection error")
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        mock_manager.connect.assert_called_once()
        mock_manager.disconnect.assert_called_once_with("user1")

@pytest.mark.asyncio
async def test_handle_websocket_subscribe_without_channel():
    """Test websocket subscribe message without channel."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = [
        {"type": "subscribe"},  # No channel
        WebSocketDisconnect()
    ]
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.subscribe = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        # Should not call subscribe without channel
        mock_manager.subscribe.assert_not_called()

@pytest.mark.asyncio
async def test_handle_websocket_unsubscribe_without_channel():
    """Test websocket unsubscribe message without channel."""
    mock_ws = AsyncMock(spec=WebSocket)
    mock_ws.receive_json.side_effect = [
        {"type": "unsubscribe"},  # No channel
        WebSocketDisconnect()
    ]
    
    with patch("cmp.api.websocket.manager.manager") as mock_manager:
        mock_manager.connect = AsyncMock()
        mock_manager.unsubscribe = AsyncMock()
        mock_manager.disconnect = MagicMock()
        
        await handle_websocket(mock_ws, "user1", "tenant1")
        
        # Should not call unsubscribe without channel
        mock_manager.unsubscribe.assert_not_called()

@pytest.mark.asyncio
async def test_broadcast_all(manager):
    ws1 = AsyncMock(spec=WebSocket)
    ws2 = AsyncMock(spec=WebSocket)
    await manager.connect(ws1, "u1")
    await manager.connect(ws2, "u2")
    
    await manager.broadcast({"t": "all"})
    ws1.send_json.assert_called()
    ws2.send_json.assert_called()

@pytest.mark.asyncio
async def test_send_error_handling(manager):
    ws = AsyncMock(spec=WebSocket)
    ws.send_json.side_effect = Exception("Send failed")
    
    await manager.connect(ws, "u1")
    await manager.send_personal_message({"t": "test"}, "u1")
    
    # Should disconnect on error
    assert "u1" not in manager.active_connections

@pytest.mark.asyncio
async def test_disconnect_with_multiple_channels(manager):
    """Test disconnecting a connection subscribed to multiple channels."""
    mock_ws = AsyncMock(spec=WebSocket)
    conn_id = "user1"
    
    await manager.connect(mock_ws, conn_id)
    await manager.subscribe(conn_id, "channel1")
    await manager.subscribe(conn_id, "channel2")
    
    # Verify subscriptions
    assert conn_id in manager.subscriptions["channel1"]
    assert conn_id in manager.subscriptions["channel2"]
    
    # Disconnect
    manager.disconnect(conn_id)
    
    # Should be removed from all channels
    assert conn_id not in manager.subscriptions.get("channel1", set())
    assert conn_id not in manager.subscriptions.get("channel2", set())
    assert conn_id not in manager.active_connections
    assert conn_id not in manager.metadata