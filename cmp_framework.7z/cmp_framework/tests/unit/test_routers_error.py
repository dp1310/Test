
import pytest
from fastapi.testclient import TestClient
from unittest.mock import MagicMock, AsyncMock, patch
from cmp.api.routers import health_router, context_router, workflow_router, registry_router
from cmp.api.auth import get_current_user, require_scope, User
from fastapi import FastAPI

# Mock user for testing
def mock_user():
    return User(
        username="test_user",
        tenant_id="test-tenant",
        scopes=["*"],
        disabled=False
    )

# Mock require_scope dependency
def mock_require_scope(scope):
    async def dependency():
        return mock_user()
    return dependency

# Create a test app that includes all routers
app = FastAPI()
app.include_router(health_router, prefix="/health")
app.include_router(context_router, prefix="/api/v1/context")
app.include_router(workflow_router, prefix="/api/v1/workflow")
app.include_router(registry_router, prefix="/api/v1/registry")

# Override dependencies to bypass auth
app.dependency_overrides[get_current_user] = mock_user

# Override require_scope dependencies
from cmp.api.routers import require_scope as router_require_scope
app.dependency_overrides[router_require_scope("context:read")] = mock_user
app.dependency_overrides[router_require_scope("context:write")] = mock_user
app.dependency_overrides[router_require_scope("workflow:execute")] = mock_user
app.dependency_overrides[router_require_scope("registry:read")] = mock_user

client = TestClient(app)

# Helper to patch _get_cmp
def mock_cmp_service(return_values):
    """Create a mock CMP instance with services returning specified async mocks.
    return_values is a dict mapping method name to AsyncMock result.
    """
    cmp_instance = MagicMock()
    # services.get_service returns an object with methods
    service_mock = MagicMock()
    for method, result in return_values.items():
        setattr(service_mock, method, AsyncMock(return_value=result))
    cmp_instance.services.get_service.return_value = service_mock
    # workflow mock
    wf_builder = MagicMock()
    wf_builder.with_context.return_value = wf_builder
    wf_builder.execute.return_value = AsyncMock()
    cmp_instance.workflow.return_value = wf_builder
    return cmp_instance

@pytest.fixture
def patch_get_cmp():
    with patch("cmp.api.routers._get_cmp") as mock_get:
        yield mock_get

def test_health_endpoints():
    resp = client.get("/health/live")
    assert resp.status_code == 200
    assert resp.json()["status"] == "alive"
    resp = client.get("/health/ready")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ready"
    resp = client.get("/health/")
    assert resp.status_code == 200
    assert "uptime_seconds" in resp.json()
    resp = client.get("/health/metrics")
    assert resp.status_code == 200
    # plain text metrics, just ensure non-empty
    assert resp.text != ""

def test_list_contexts_error(patch_get_cmp):
    # Service list returns Err
    err_result = MagicMock(is_err=lambda: True, unwrap=lambda: None)
    mock_cmp = mock_cmp_service({"list": err_result})
    patch_get_cmp.return_value = mock_cmp
    resp = client.get("/api/v1/context/", params={"limit": 5})
    assert resp.status_code == 500
    assert "Failed to list contexts" in resp.text

def test_update_context_not_found(patch_get_cmp):
    err_result = MagicMock(is_err=lambda: True, unwrap=lambda: None)
    mock_cmp = mock_cmp_service({"update": err_result})
    patch_get_cmp.return_value = mock_cmp
    resp = client.put("/api/v1/context/ctx-1", json={"data": {"foo": "bar"}})
    assert resp.status_code == 404
    assert "Context not found" in resp.text

def test_delete_context_not_found(patch_get_cmp):
    err_result = MagicMock(is_err=lambda: True, unwrap=lambda: None)
    mock_cmp = mock_cmp_service({"delete": err_result})
    patch_get_cmp.return_value = mock_cmp
    resp = client.delete("/api/v1/context/ctx-1")
    assert resp.status_code == 404
    assert "Context not found" in resp.text

def test_workflow_execute_error(patch_get_cmp):
    # Make workflow execution raise exception
    wf_builder = MagicMock()
    wf_builder.with_context.return_value = wf_builder
    
    # Create an async generator that raises an exception
    async def async_generator_with_error():
        raise RuntimeError("boom")
        yield  # This will never be reached
    
    wf_builder.execute.return_value = async_generator_with_error()
    mock_cmp = MagicMock()
    mock_cmp.workflow.return_value = wf_builder
    patch_get_cmp.return_value = mock_cmp
    resp = client.post("/api/v1/workflow/execute", json={"context_id": "c1", "workflow_name": "wf"})
    assert resp.status_code == 500
    assert "boom" in resp.text

def test_registry_schemas_error(patch_get_cmp):
    # Simulate error in registry list_schemas
    with patch("cmp.registries.create_backend") as mock_backend:
        mock_backend.return_value = MagicMock()
        # Patch SchemaRegistry to return Err
        with patch("cmp.registries.SchemaRegistry") as mock_registry_cls:
            mock_registry = AsyncMock()
            err_result = MagicMock(is_err=lambda: True, unwrap=lambda: None)
            mock_registry.list_schemas.return_value = err_result
            mock_registry.close.return_value = AsyncMock()
            mock_registry_cls.return_value = mock_registry
            resp = client.get("/api/v1/registry/schemas")
            assert resp.status_code == 500
            assert "Failed to list schemas" in resp.text

def test_registry_policies_error(patch_get_cmp):
    with patch("cmp.registries.create_backend") as mock_backend:
        mock_backend.return_value = MagicMock()
        with patch("cmp.registries.PolicyRegistry") as mock_registry_cls:
            mock_registry = AsyncMock()
            err_result = MagicMock(is_err=lambda: True, unwrap=lambda: None)
            mock_registry.list_policies.return_value = err_result
            mock_registry.close.return_value = AsyncMock()
            mock_registry_cls.return_value = mock_registry
            resp = client.get("/api/v1/registry/policies")
            assert resp.status_code == 500
            assert "Failed to list policies" in resp.text
