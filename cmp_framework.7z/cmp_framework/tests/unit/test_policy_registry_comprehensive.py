"""Comprehensive tests for PolicyRegistry."""

import pytest
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime, timezone

from cmp.registries.policy_registry import (
    PolicyRegistry, PolicyInfo, TestResult, TestResults,
    PolicyNotFoundError, PolicyValidationError, PolicyVersionError
)
from cmp.registries.persistence import InMemoryBackend
from cmp.core.result import Ok, Err


class TestPolicyInfo:
    """Test PolicyInfo dataclass."""
    
    def test_policy_info_creation(self):
        """Test PolicyInfo creation with all fields."""
        now = datetime.now(timezone.utc).isoformat()
        
        policy_info = PolicyInfo(
            policy_id="test-policy",
            version="1.0",
            description="Test policy",
            created_at=now,
            deployed=True,
            deployed_at=now,
            deprecated=False
        )
        
        assert policy_info.policy_id == "test-policy"
        assert policy_info.version == "1.0"
        assert policy_info.description == "Test policy"
        assert policy_info.created_at == now
        assert policy_info.deployed is True
        assert policy_info.deployed_at == now
        assert policy_info.deprecated is False
    
    def test_policy_info_defaults(self):
        """Test PolicyInfo with default values."""
        policy_info = PolicyInfo(
            policy_id="test-policy",
            version="1.0",
            description="Test policy",
            created_at="2023-01-01T00:00:00Z"
        )
        
        assert policy_info.deployed is False
        assert policy_info.deployed_at is None
        assert policy_info.deprecated is False


class TestTestResult:
    """Test TestResult dataclass."""
    
    def test_test_result_creation(self):
        """Test TestResult creation."""
        result = TestResult(
            test_name="test_allow",
            passed=True,
            expected=True,
            actual=True,
            error=None
        )
        
        assert result.test_name == "test_allow"
        assert result.passed is True
        assert result.expected is True
        assert result.actual is True
        assert result.error is None
    
    def test_test_result_with_error(self):
        """Test TestResult with error."""
        result = TestResult(
            test_name="test_deny",
            passed=False,
            expected=False,
            actual=True,
            error="Unexpected result"
        )
        
        assert result.test_name == "test_deny"
        assert result.passed is False
        assert result.expected is False
        assert result.actual is True
        assert result.error == "Unexpected result"


class TestTestResults:
    """Test TestResults dataclass."""
    
    def test_test_results_creation(self):
        """Test TestResults creation."""
        results = [
            TestResult("test1", True, True, True),
            TestResult("test2", False, False, True, "Error")
        ]
        
        test_results = TestResults(
            policy_id="test-policy",
            version="1.0",
            total=2,
            passed=1,
            failed=1,
            results=results
        )
        
        assert test_results.policy_id == "test-policy"
        assert test_results.version == "1.0"
        assert test_results.total == 2
        assert test_results.passed == 1
        assert test_results.failed == 1
        assert len(test_results.results) == 2
        assert test_results.success is False
    
    def test_test_results_success_property(self):
        """Test TestResults success property."""
        # All tests passed
        test_results = TestResults(
            policy_id="test-policy",
            version="1.0",
            total=2,
            passed=2,
            failed=0,
            results=[]
        )
        assert test_results.success is True
        
        # Some tests failed
        test_results = TestResults(
            policy_id="test-policy",
            version="1.0",
            total=2,
            passed=1,
            failed=1,
            results=[]
        )
        assert test_results.success is False


class TestPolicyRegistry:
    """Test PolicyRegistry class."""
    
    @pytest.fixture
    async def registry(self):
        """Create registry with in-memory backend."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend, cache_enabled=True)
        yield registry
        await registry.close()
    
    @pytest.fixture
    async def registry_no_cache(self):
        """Create registry without cache."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend, cache_enabled=False)
        yield registry
        await registry.close()
    
    def test_registry_initialization(self):
        """Test registry initialization."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(
            backend=backend,
            cache_enabled=True,
            cache_ttl=600,
            cache_max_size=500
        )
        
        assert registry.backend is backend
        assert registry.cache_enabled is True
        assert registry._cache is not None
        assert registry._cache.maxsize == 500
        assert registry._cache.ttl == 600
    
    def test_registry_initialization_no_cache(self):
        """Test registry initialization without cache."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend, cache_enabled=False)
        
        assert registry.backend is backend
        assert registry.cache_enabled is False
        assert registry._cache is None
    
    def test_registry_initialization_default_backend(self):
        """Test registry initialization with default backend."""
        with patch('cmp.registries.policy_registry.create_backend') as mock_create:
            mock_backend = Mock()
            mock_create.return_value = mock_backend
            
            registry = PolicyRegistry()
            
            assert registry.backend is mock_backend
            mock_create.assert_called_once_with("memory")
    
    def test_make_key(self):
        """Test key generation."""
        registry = PolicyRegistry()
        
        # With version
        key = registry._make_key("test-policy", "1.0")
        assert key == "policy:test-policy:1.0"
        
        # Without version (latest)
        key = registry._make_key("test-policy")
        assert key == "policy:test-policy:latest"
    
    def test_validate_rego_success(self):
        """Test successful rego validation."""
        registry = PolicyRegistry()
        
        rego_code = """
        package test.policy
        
        allow {
            input.user == "admin"
        }
        """
        
        result = registry._validate_rego(rego_code)
        assert result.is_ok()
    
    def test_validate_rego_empty(self):
        """Test rego validation with empty code."""
        registry = PolicyRegistry()
        
        result = registry._validate_rego("")
        assert result.is_err()
        assert isinstance(result.error, PolicyValidationError)
        assert "cannot be empty" in str(result.error)
    
    def test_validate_rego_no_package(self):
        """Test rego validation without package declaration."""
        registry = PolicyRegistry()
        
        rego_code = """
        allow {
            input.user == "admin"
        }
        """
        
        result = registry._validate_rego(rego_code)
        assert result.is_err()
        assert isinstance(result.error, PolicyValidationError)
        assert "package declaration" in str(result.error)
    
    @pytest.mark.asyncio
    async def test_register_policy_dict(self, registry):
        """Test registering policy as dict."""
        policy_dict = {
            "rego_code": "package test\nallow { true }",
            "metadata": {"author": "test"}
        }
        
        result = await registry.register_policy(
            policy_id="test-policy",
            policy=policy_dict,
            version="1.0",
            description="Test policy"
        )
        
        assert result.is_ok()
        
        # Verify policy was saved
        get_result = await registry.get_policy("test-policy", "1.0")
        assert get_result.is_ok()
        assert get_result.unwrap() == policy_dict
    
    @pytest.mark.asyncio
    async def test_register_policy_string(self, registry):
        """Test registering policy as string (rego code)."""
        rego_code = """
        package test.policy
        
        allow {
            input.user == "admin"
        }
        """
        
        result = await registry.register_policy(
            policy_id="test-policy",
            policy=rego_code,
            version="1.0",
            description="Test policy"
        )
        
        assert result.is_ok()
        
        # Verify policy was saved
        get_result = await registry.get_policy("test-policy", "1.0")
        assert get_result.is_ok()
        stored_policy = get_result.unwrap()
        assert stored_policy["rego_code"] == rego_code
    
    @pytest.mark.asyncio
    async def test_register_policy_invalid_rego(self, registry):
        """Test registering invalid rego code."""
        invalid_rego = "invalid rego code"
        
        result = await registry.register_policy(
            policy_id="test-policy",
            policy=invalid_rego,
            version="1.0"
        )
        
        assert result.is_err()
        assert isinstance(result.error, PolicyValidationError)
    
    @pytest.mark.asyncio
    async def test_register_policy_version_conflict(self, registry):
        """Test registering policy with existing version."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register first time
        result1 = await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        assert result1.is_ok()
        
        # Try to register same version again
        result2 = await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        assert result2.is_err()
        assert isinstance(result2.error, PolicyVersionError)
        assert "already exists" in str(result2.error)
    
    @pytest.mark.asyncio
    async def test_register_policy_force_overwrite(self, registry):
        """Test force overwriting existing policy version."""
        policy1 = {"rego_code": "package test\nallow { true }"}
        policy2 = {"rego_code": "package test\nallow { false }"}
        
        # Register first time
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy1,
            version="1.0"
        )
        
        # Force overwrite
        result = await registry.register_policy(
            policy_id="test-policy",
            policy=policy2,
            version="1.0",
            force=True
        )
        assert result.is_ok()
        
        # Verify new policy was saved
        get_result = await registry.get_policy("test-policy", "1.0")
        assert get_result.is_ok()
        assert get_result.unwrap() == policy2
    
    @pytest.mark.asyncio
    async def test_register_policy_updates_latest(self, registry):
        """Test that registering policy updates latest pointer."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        result = await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        assert result.is_ok()
        
        # Verify latest pointer was updated
        get_result = await registry.get_policy("test-policy")  # No version = latest
        assert get_result.is_ok()
        assert get_result.unwrap() == policy
    
    @pytest.mark.asyncio
    async def test_register_policy_backend_error(self, registry):
        """Test register policy with backend error."""
        # Mock backend to return error
        registry.backend.save = AsyncMock(return_value=Err("Backend error"))
        
        policy = {"rego_code": "package test\nallow { true }"}
        
        result = await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        assert result.is_err()
        assert str(result.error) == "Backend error"
    
    @pytest.mark.asyncio
    async def test_get_policy_success(self, registry):
        """Test successful policy retrieval."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy first
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Get policy
        result = await registry.get_policy("test-policy", "1.0")
        assert result.is_ok()
        assert result.unwrap() == policy
    
    @pytest.mark.asyncio
    async def test_get_policy_latest(self, registry):
        """Test getting latest policy version."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Get latest version
        result = await registry.get_policy("test-policy")
        assert result.is_ok()
        assert result.unwrap() == policy
    
    @pytest.mark.asyncio
    async def test_get_policy_not_found(self, registry):
        """Test getting non-existent policy."""
        result = await registry.get_policy("nonexistent-policy", "1.0")
        assert result.is_err()
        assert isinstance(result.error, PolicyNotFoundError)
        assert "not found" in str(result.error)
    
    @pytest.mark.asyncio
    async def test_get_policy_caching(self, registry):
        """Test policy caching."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Get policy twice
        result1 = await registry.get_policy("test-policy", "1.0")
        result2 = await registry.get_policy("test-policy", "1.0")
        
        assert result1.is_ok()
        assert result2.is_ok()
        assert result1.unwrap() == result2.unwrap()
        
        # Verify cache was used
        key = registry._make_key("test-policy", "1.0")
        assert key in registry._cache
    
    @pytest.mark.asyncio
    async def test_get_policy_no_cache(self, registry_no_cache):
        """Test policy retrieval without cache."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry_no_cache.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Get policy
        result = await registry_no_cache.get_policy("test-policy", "1.0")
        assert result.is_ok()
        assert result.unwrap() == policy
        
        # Verify no cache was used
        assert registry_no_cache._cache is None
    
    @pytest.mark.asyncio
    async def test_deploy_policy_success(self, registry):
        """Test successful policy deployment."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Deploy policy
        result = await registry.deploy_policy("test-policy", "1.0")
        assert result.is_ok()
        
        # Verify deployment metadata was updated
        # We can't directly check metadata, but we can verify the operation succeeded
        assert result.is_ok()
    
    @pytest.mark.asyncio
    async def test_deploy_policy_not_found(self, registry):
        """Test deploying non-existent policy."""
        result = await registry.deploy_policy("nonexistent-policy", "1.0")
        assert result.is_err()
        assert isinstance(result.error, PolicyNotFoundError)
        assert "not found" in str(result.error)
    
    @pytest.mark.asyncio
    async def test_deploy_policy_latest(self, registry):
        """Test deploying latest policy version."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Deploy latest version
        result = await registry.deploy_policy("test-policy")
        assert result.is_ok()
    
    @pytest.mark.asyncio
    async def test_test_policy_success(self, registry):
        """Test successful policy testing."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Test policy
        test_cases = [
            {"name": "test_allow", "expected": True},
            {"name": "test_deny", "expected": False}
        ]
        
        result = await registry.test_policy("test-policy", test_cases, "1.0")
        assert result.is_ok()
        
        test_results = result.unwrap()
        assert test_results.policy_id == "test-policy"
        assert test_results.version == "1.0"
        assert test_results.total == 2
        assert test_results.passed == 2
        assert test_results.failed == 0
        assert test_results.success is True
        assert len(test_results.results) == 2
    
    @pytest.mark.asyncio
    async def test_test_policy_not_found(self, registry):
        """Test testing non-existent policy."""
        test_cases = [{"name": "test", "expected": True}]
        
        result = await registry.test_policy("nonexistent-policy", test_cases, "1.0")
        assert result.is_err()
        assert "not found" in str(result.error)
    
    @pytest.mark.asyncio
    async def test_test_policy_latest_version(self, registry):
        """Test testing latest policy version."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Test latest version
        test_cases = [{"name": "test", "expected": True}]
        
        result = await registry.test_policy("test-policy", test_cases)
        assert result.is_ok()
        
        test_results = result.unwrap()
        assert test_results.version == "latest"
    
    @pytest.mark.asyncio
    async def test_mark_deployed_success(self, registry):
        """Test marking policy as deployed."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Mark as deployed
        result = await registry.mark_deployed("test-policy", "1.0")
        assert result.is_ok()
    
    @pytest.mark.asyncio
    async def test_mark_deployed_not_found(self, registry):
        """Test marking non-existent policy as deployed."""
        result = await registry.mark_deployed("nonexistent-policy", "1.0")
        assert result.is_err()
        assert isinstance(result.error, PolicyNotFoundError)
        assert "not found" in str(result.error)
    
    @pytest.mark.asyncio
    async def test_list_policies_empty(self, registry):
        """Test listing policies when registry is empty."""
        result = await registry.list_policies()
        assert result.is_ok()
        assert result.unwrap() == []
    
    @pytest.mark.asyncio
    async def test_list_policies_success(self, registry):
        """Test listing policies."""
        # Register multiple policies
        policy1 = {"rego_code": "package test1\nallow { true }"}
        policy2 = {"rego_code": "package test2\nallow { false }"}
        
        await registry.register_policy(
            policy_id="policy-1",
            policy=policy1,
            version="1.0",
            description="First policy"
        )
        
        await registry.register_policy(
            policy_id="policy-2",
            policy=policy2,
            version="1.0",
            description="Second policy"
        )
        
        await registry.register_policy(
            policy_id="policy-1",
            policy=policy1,
            version="2.0",
            description="First policy v2"
        )
        
        # List policies
        result = await registry.list_policies()
        assert result.is_ok()
        
        policies = result.unwrap()
        assert len(policies) == 3  # 2 versions of policy-1 + 1 version of policy-2
        
        # Verify sorting
        assert policies[0].policy_id == "policy-1"
        assert policies[0].version == "1.0"
        assert policies[1].policy_id == "policy-1"
        assert policies[1].version == "2.0"
        assert policies[2].policy_id == "policy-2"
        assert policies[2].version == "1.0"
        
        # Verify metadata
        assert policies[0].description == "First policy"
        assert policies[0].deployed is False
        assert policies[0].deprecated is False
    
    @pytest.mark.asyncio
    async def test_list_policies_backend_error(self, registry):
        """Test listing policies with backend error."""
        # Mock backend to return error
        registry.backend.list = AsyncMock(return_value=Err("Backend error"))
        
        result = await registry.list_policies()
        assert result.is_err()
        assert "Backend error" in str(result.error)
    
    @pytest.mark.asyncio
    async def test_delete_policy_success(self, registry):
        """Test successful policy deletion."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Delete policy
        result = await registry.delete_policy("test-policy", "1.0")
        assert result.is_ok()
        
        # Verify policy was deleted
        get_result = await registry.get_policy("test-policy", "1.0")
        assert get_result.is_err()
        assert isinstance(get_result.error, PolicyNotFoundError)
    
    @pytest.mark.asyncio
    async def test_delete_policy_not_found(self, registry):
        """Test deleting non-existent policy."""
        result = await registry.delete_policy("nonexistent-policy", "1.0")
        assert result.is_err()
        assert isinstance(result.error, PolicyNotFoundError)
        assert "not found" in str(result.error)
    
    @pytest.mark.asyncio
    async def test_delete_policy_cache_invalidation(self, registry):
        """Test cache invalidation on policy deletion."""
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register and get policy (to cache it)
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        await registry.get_policy("test-policy", "1.0")
        
        # Verify policy is cached
        key = registry._make_key("test-policy", "1.0")
        assert key in registry._cache
        
        # Delete policy
        await registry.delete_policy("test-policy", "1.0")
        
        # Verify cache was invalidated
        assert key not in registry._cache
    
    @pytest.mark.asyncio
    async def test_close_registry(self, registry):
        """Test closing registry."""
        # Add something to cache
        policy = {"rego_code": "package test\nallow { true }"}
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        await registry.get_policy("test-policy", "1.0")
        
        # Verify cache has content
        assert len(registry._cache) > 0
        
        # Close registry
        await registry.close()
        
        # Verify cache was cleared
        assert len(registry._cache) == 0
    
    @pytest.mark.asyncio
    async def test_close_registry_no_cache(self, registry_no_cache):
        """Test closing registry without cache."""
        # Should not raise error
        await registry_no_cache.close()


class TestPolicyRegistryEdgeCases:
    """Test edge cases and error conditions."""
    
    @pytest.mark.asyncio
    async def test_register_policy_empty_description(self):
        """Test registering policy with empty description."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend)
        
        policy = {"rego_code": "package test\nallow { true }"}
        
        result = await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0",
            description=""  # Empty description
        )
        
        assert result.is_ok()
        await registry.close()
    
    @pytest.mark.asyncio
    async def test_cache_invalidation_on_register(self):
        """Test cache invalidation when registering policy."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend, cache_enabled=True)
        
        policy1 = {"rego_code": "package test\nallow { true }"}
        policy2 = {"rego_code": "package test\nallow { false }"}
        
        # Register and cache policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy1,
            version="1.0"
        )
        await registry.get_policy("test-policy", "1.0")
        
        key = registry._make_key("test-policy", "1.0")
        assert key in registry._cache
        
        # Force overwrite (should invalidate cache)
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy2,
            version="1.0",
            force=True
        )
        
        # Cache should be invalidated
        assert key not in registry._cache
        
        await registry.close()
    
    @pytest.mark.asyncio
    async def test_list_policies_filters_latest_keys(self):
        """Test that list_policies filters out :latest keys."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend)
        
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy (creates both versioned and latest keys)
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # List policies should only show versioned policies, not latest
        result = await registry.list_policies()
        assert result.is_ok()
        
        policies = result.unwrap()
        assert len(policies) == 1
        assert policies[0].policy_id == "test-policy"
        assert policies[0].version == "1.0"
        
        await registry.close()
    
    @pytest.mark.asyncio
    async def test_list_policies_handles_missing_metadata(self):
        """Test list_policies handles policies with missing metadata."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend)
        
        # Manually save policy without proper metadata
        await backend.save(
            key="policy:test-policy:1.0",
            value={"rego_code": "package test\nallow { true }"},
            metadata={}  # Missing required metadata
        )
        
        # List policies should handle missing metadata gracefully
        result = await registry.list_policies()
        assert result.is_ok()
        
        policies = result.unwrap()
        # Policy without proper metadata should be filtered out
        assert len(policies) == 0
        
        await registry.close()
    
    @pytest.mark.asyncio
    async def test_deploy_policy_backend_save_error(self):
        """Test deploy_policy with backend save error."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend)
        
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        
        # Mock backend save to return error
        original_save = backend.save
        backend.save = AsyncMock(return_value=Err("Save error"))
        
        # Deploy should fail
        result = await registry.deploy_policy("test-policy", "1.0")
        assert result.is_err()
        assert "Save error" in str(result.error)
        
        # Restore original save method
        backend.save = original_save
        await registry.close()
    
    @pytest.mark.asyncio
    async def test_mark_deployed_cache_invalidation(self):
        """Test cache invalidation when marking policy as deployed."""
        backend = InMemoryBackend()
        registry = PolicyRegistry(backend=backend, cache_enabled=True)
        
        policy = {"rego_code": "package test\nallow { true }"}
        
        # Register and cache policy
        await registry.register_policy(
            policy_id="test-policy",
            policy=policy,
            version="1.0"
        )
        await registry.get_policy("test-policy", "1.0")
        
        key = registry._make_key("test-policy", "1.0")
        assert key in registry._cache
        
        # Mark as deployed (should invalidate cache)
        await registry.mark_deployed("test-policy", "1.0")
        
        # Cache should be invalidated
        assert key not in registry._cache
        
        await registry.close()