
import pytest
import asyncio
from cmp.core.cache import CacheManager, InMemoryCache, RedisCache

@pytest.mark.asyncio
async def test_in_memory_cache():
    cache = InMemoryCache(maxsize=10, ttl=1)
    
    # Test Set/Get
    await cache.set("key1", "value1")
    assert await cache.get("key1") == "value1"
    
    # Test Exists
    assert await cache.exists("key1") is True
    assert await cache.exists("key2") is False
    
    # Test Delete
    await cache.delete("key1")
    assert await cache.get("key1") is None
    assert await cache.exists("key1") is False
    
    # Test Clear
    await cache.set("key1", "value1")
    await cache.set("key2", "value2")
    await cache.clear()
    assert await cache.get("key1") is None
    assert await cache.get("key2") is None
    
    # Test TTL
    # InMemoryCache using TTLCache only supports global TTL, not per-item override in set()
    # So we create a new cache instance with short TTL to test expiry
    short_ttl_cache = InMemoryCache(maxsize=10, ttl=0.01)
    await short_ttl_cache.set("key_ttl", "val")
    assert await short_ttl_cache.get("key_ttl") == "val"
    await asyncio.sleep(0.05)
    assert await short_ttl_cache.get("key_ttl") is None

@pytest.mark.asyncio
async def test_cache_manager_memory():
    manager = CacheManager(backend="memory", maxsize=10, ttl=60)
    
    await manager.set("mkey", "mval")
    assert await manager.get("mkey") == "mval"
    assert await manager.exists("mkey") is True
    
    # get_stats is synchronous, so we don't await it
    stats = manager.get_stats()
    assert stats["hits"] >= 1

@pytest.mark.asyncio
async def test_cache_manager_invalid_backend():
    with pytest.raises(ValueError):
        CacheManager(backend="invalid")
