
import pytest
from unittest.mock import patch, AsyncMock
from aiohttp import ClientSession
from cmp.services.policy_service import PolicyService, PolicyResult

@pytest.fixture
async def policy_service():
    service = PolicyService("http://mock-opa:8181")
    yield service
    await service.close()

@pytest.mark.asyncio
async def test_policy_service_evaluate_success(policy_service):
    mock_response = {
        "result": {
            "allow": True,
            "reason": "Looking good",
            "metadata": {"key": "value"}
        }
    }
    
    with patch("aiohttp.ClientSession.post") as mock_post:
        mock_ctx = AsyncMock()
        mock_ctx.__aenter__.return_value.status = 200
        mock_ctx.__aenter__.return_value.json = AsyncMock(return_value=mock_response)
        mock_post.return_value = mock_ctx
        
        result = await policy_service.evaluate("test.policy", {"foo": "bar"})
        
        assert result.allowed is True
        assert result.reason == "Looking good"
        assert result.metadata == {"key": "value"}

@pytest.mark.asyncio
async def test_policy_service_evaluate_denied(policy_service):
    mock_response = {
        "result": {
            "allow": False,
            "reason": "Denied!"
        }
    }
    
    with patch("aiohttp.ClientSession.post") as mock_post:
        mock_ctx = AsyncMock()
        mock_ctx.__aenter__.return_value.status = 200
        mock_ctx.__aenter__.return_value.json = AsyncMock(return_value=mock_response)
        mock_post.return_value = mock_ctx
        
        result = await policy_service.evaluate("test.policy", {"foo": "bar"})
        
        assert result.allowed is False
        assert result.reason == "Denied!"

@pytest.mark.asyncio
async def test_policy_service_failure(policy_service):
    with patch("aiohttp.ClientSession.post") as mock_post:
        mock_ctx = AsyncMock()
        mock_ctx.__aenter__.return_value.status = 500
        mock_post.return_value = mock_ctx
        
        result = await policy_service.evaluate("test.policy", {})
        
        assert result.allowed is False
        assert "OPA request failed: 500" in result.reason

@pytest.mark.asyncio
async def test_policy_service_exception(policy_service):
    with patch("aiohttp.ClientSession.post", side_effect=Exception("Network error")):
        result = await policy_service.evaluate("test.policy", {})
        assert result.allowed is False
        assert "Policy evaluation error: Network error" in result.reason

@pytest.mark.asyncio
async def test_get_workflow_policy(policy_service):
    mock_response = {
        "result": {
            "allow": True,
            "metadata": {
                "workflow_config": {"strategy": "parallel"}
            }
        }
    }
    
    with patch("aiohttp.ClientSession.post") as mock_post:
        mock_ctx = AsyncMock()
        mock_ctx.__aenter__.return_value.status = 200
        mock_ctx.__aenter__.return_value.json = AsyncMock(return_value=mock_response)
        mock_post.return_value = mock_ctx
        
        config = await policy_service.get_workflow_policy("my_workflow")
        assert config["strategy"] == "parallel"

@pytest.mark.asyncio
async def test_context_manager():
    async with PolicyService("http://test") as ps:
        assert ps._session is not None
        assert not ps._session.closed
    # After context manager, session should be closed
    # But PolicyService.__aexit__ only calls close().
    # mocking close check is hard since we can't inspect the closed internal session easily 
    # unless we mocked ClientSession constructor.
    pass
