"""
Tests for conditional orchestration patterns.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from datetime import datetime, timezone

from cmp.orchestration.patterns.conditional import ConditionalWorkflow, SwitchWorkflow
from cmp.core.models import Context
from cmp.sdk.agent import Agent


class MockAgent(Agent):
    """Mock agent for testing"""
    
    def __init__(self, agent_id: str, return_data: dict = None):
        super().__init__(agent_id)
        self.return_data = return_data or {}
        self.process_called = False
        self.last_context = None
    
    async def process(self, context: Context) -> Context:
        """Mock process method"""
        self.process_called = True
        self.last_context = context
        
        # Return context with additional data
        new_data = {**context.data, **self.return_data}
        return context.with_data(**new_data)


class TestConditionalWorkflow:
    """Test ConditionalWorkflow class"""
    
    @pytest.fixture
    def sample_context(self):
        """Create a sample context for testing"""
        return Context(
            id="test_ctx",
            data={"amount": 500, "user_type": "premium"},
            tenant_id="test_tenant"
        )
    
    @pytest.fixture
    def high_value_agent(self):
        """Create a mock agent for high value processing"""
        return MockAgent("high_value_agent", {"processed_by": "high_value"})
    
    @pytest.fixture
    def standard_agent(self):
        """Create a mock agent for standard processing"""
        return MockAgent("standard_agent", {"processed_by": "standard"})
    
    def test_conditional_workflow_initialization(self):
        """Test ConditionalWorkflow initialization"""
        workflow = ConditionalWorkflow()
        
        assert workflow._condition is None
        assert workflow._then_agent is None
        assert workflow._else_agent is None
    
    def test_when_method_chaining(self):
        """Test when method returns self for chaining"""
        workflow = ConditionalWorkflow()
        condition = lambda ctx: ctx.data["amount"] > 1000
        
        result = workflow.when(condition)
        
        assert result is workflow
        assert workflow._condition is condition
    
    def test_then_method_chaining(self, high_value_agent):
        """Test then method returns self for chaining"""
        workflow = ConditionalWorkflow()
        
        result = workflow.then(high_value_agent)
        
        assert result is workflow
        assert workflow._then_agent is high_value_agent
    
    def test_otherwise_method_chaining(self, standard_agent):
        """Test otherwise method returns self for chaining"""
        workflow = ConditionalWorkflow()
        
        result = workflow.otherwise(standard_agent)
        
        assert result is workflow
        assert workflow._else_agent is standard_agent
    
    def test_fluent_interface_chaining(self, high_value_agent, standard_agent):
        """Test complete fluent interface chaining"""
        condition = lambda ctx: ctx.data["amount"] > 1000
        
        workflow = ConditionalWorkflow() \
            .when(condition) \
            .then(high_value_agent) \
            .otherwise(standard_agent)
        
        assert workflow._condition is condition
        assert workflow._then_agent is high_value_agent
        assert workflow._else_agent is standard_agent
    
    @pytest.mark.asyncio
    async def test_execute_condition_true(self, sample_context, high_value_agent, standard_agent):
        """Test execution when condition is True"""
        # Condition that should be True for sample_context (amount = 500)
        condition = lambda ctx: ctx.data["amount"] > 100
        
        workflow = ConditionalWorkflow() \
            .when(condition) \
            .then(high_value_agent) \
            .otherwise(standard_agent)
        
        result = await workflow.execute(sample_context)
        
        # Should execute then branch
        assert high_value_agent.process_called
        assert not standard_agent.process_called
        assert result.data["processed_by"] == "high_value"
        assert high_value_agent.last_context is sample_context
    
    @pytest.mark.asyncio
    async def test_execute_condition_false(self, sample_context, high_value_agent, standard_agent):
        """Test execution when condition is False"""
        # Condition that should be False for sample_context (amount = 500)
        condition = lambda ctx: ctx.data["amount"] > 1000
        
        workflow = ConditionalWorkflow() \
            .when(condition) \
            .then(high_value_agent) \
            .otherwise(standard_agent)
        
        result = await workflow.execute(sample_context)
        
        # Should execute else branch
        assert not high_value_agent.process_called
        assert standard_agent.process_called
        assert result.data["processed_by"] == "standard"
        assert standard_agent.last_context is sample_context
    
    @pytest.mark.asyncio
    async def test_execute_condition_false_no_else(self, sample_context, high_value_agent):
        """Test execution when condition is False and no else agent"""
        condition = lambda ctx: ctx.data["amount"] > 1000
        
        workflow = ConditionalWorkflow() \
            .when(condition) \
            .then(high_value_agent)
        
        result = await workflow.execute(sample_context)
        
        # Should return original context unchanged
        assert not high_value_agent.process_called
        assert result is sample_context
    
    @pytest.mark.asyncio
    async def test_execute_no_condition_error(self, sample_context, high_value_agent):
        """Test execution without setting condition raises error"""
        workflow = ConditionalWorkflow().then(high_value_agent)
        
        with pytest.raises(ValueError, match="Condition not set"):
            await workflow.execute(sample_context)
    
    @pytest.mark.asyncio
    async def test_execute_no_then_agent_error(self, sample_context):
        """Test execution without setting then agent raises error"""
        condition = lambda ctx: True
        workflow = ConditionalWorkflow().when(condition)
        
        with pytest.raises(ValueError, match="Then agent not set"):
            await workflow.execute(sample_context)
    
    @pytest.mark.asyncio
    async def test_execute_with_complex_condition(self, high_value_agent, standard_agent):
        """Test execution with complex condition logic"""
        # Complex condition checking multiple fields
        condition = lambda ctx: (
            ctx.data.get("amount", 0) > 100 and 
            ctx.data.get("user_type") == "premium"
        )
        
        workflow = ConditionalWorkflow() \
            .when(condition) \
            .then(high_value_agent) \
            .otherwise(standard_agent)
        
        # Test with matching context
        matching_context = Context(
            id="test_ctx",
            data={"amount": 500, "user_type": "premium"},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(matching_context)
        assert high_value_agent.process_called
        assert result.data["processed_by"] == "high_value"
        
        # Reset agents
        high_value_agent.process_called = False
        standard_agent.process_called = False
        
        # Test with non-matching context
        non_matching_context = Context(
            id="test_ctx",
            data={"amount": 500, "user_type": "basic"},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(non_matching_context)
        assert standard_agent.process_called
        assert result.data["processed_by"] == "standard"
    
    @pytest.mark.asyncio
    async def test_execute_condition_exception_handling(self, sample_context, high_value_agent):
        """Test execution when condition raises exception"""
        def failing_condition(ctx):
            raise KeyError("Missing key")
        
        workflow = ConditionalWorkflow() \
            .when(failing_condition) \
            .then(high_value_agent)
        
        with pytest.raises(KeyError, match="Missing key"):
            await workflow.execute(sample_context)
    
    @pytest.mark.asyncio
    async def test_execute_agent_exception_handling(self, sample_context):
        """Test execution when agent raises exception"""
        failing_agent = AsyncMock()
        failing_agent.process.side_effect = RuntimeError("Agent failed")
        
        condition = lambda ctx: True
        workflow = ConditionalWorkflow() \
            .when(condition) \
            .then(failing_agent)
        
        with pytest.raises(RuntimeError, match="Agent failed"):
            await workflow.execute(sample_context)


class TestSwitchWorkflow:
    """Test SwitchWorkflow class"""
    
    @pytest.fixture
    def sample_context(self):
        """Create a sample context for testing"""
        return Context(
            id="test_ctx",
            data={"type": "A", "value": 100},
            tenant_id="test_tenant"
        )
    
    @pytest.fixture
    def agent_a(self):
        """Create mock agent A"""
        return MockAgent("agent_a", {"processed_by": "agent_a"})
    
    @pytest.fixture
    def agent_b(self):
        """Create mock agent B"""
        return MockAgent("agent_b", {"processed_by": "agent_b"})
    
    @pytest.fixture
    def default_agent(self):
        """Create mock default agent"""
        return MockAgent("default_agent", {"processed_by": "default"})
    
    def test_switch_workflow_initialization(self):
        """Test SwitchWorkflow initialization"""
        selector = lambda ctx: ctx.data["type"]
        workflow = SwitchWorkflow(selector)
        
        assert workflow._selector is selector
        assert workflow._cases == {}
        assert workflow._default is None
    
    def test_case_method_chaining(self, agent_a):
        """Test case method returns self for chaining"""
        selector = lambda ctx: ctx.data["type"]
        workflow = SwitchWorkflow(selector)
        
        result = workflow.case("A", agent_a)
        
        assert result is workflow
        assert workflow._cases["A"] is agent_a
    
    def test_default_method_chaining(self, default_agent):
        """Test default method returns self for chaining"""
        selector = lambda ctx: ctx.data["type"]
        workflow = SwitchWorkflow(selector)
        
        result = workflow.default(default_agent)
        
        assert result is workflow
        assert workflow._default is default_agent
    
    def test_fluent_interface_chaining(self, agent_a, agent_b, default_agent):
        """Test complete fluent interface chaining"""
        selector = lambda ctx: ctx.data["type"]
        
        workflow = SwitchWorkflow(selector) \
            .case("A", agent_a) \
            .case("B", agent_b) \
            .default(default_agent)
        
        assert workflow._cases["A"] is agent_a
        assert workflow._cases["B"] is agent_b
        assert workflow._default is default_agent
    
    @pytest.mark.asyncio
    async def test_execute_matching_case(self, sample_context, agent_a, agent_b, default_agent):
        """Test execution with matching case"""
        selector = lambda ctx: ctx.data["type"]
        
        workflow = SwitchWorkflow(selector) \
            .case("A", agent_a) \
            .case("B", agent_b) \
            .default(default_agent)
        
        result = await workflow.execute(sample_context)
        
        # Should execute agent_a since type is "A"
        assert agent_a.process_called
        assert not agent_b.process_called
        assert not default_agent.process_called
        assert result.data["processed_by"] == "agent_a"
        assert agent_a.last_context is sample_context
    
    @pytest.mark.asyncio
    async def test_execute_different_case(self, agent_a, agent_b, default_agent):
        """Test execution with different matching case"""
        selector = lambda ctx: ctx.data["type"]
        
        workflow = SwitchWorkflow(selector) \
            .case("A", agent_a) \
            .case("B", agent_b) \
            .default(default_agent)
        
        # Create context with type "B"
        context_b = Context(
            id="test_ctx",
            data={"type": "B", "value": 200},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(context_b)
        
        # Should execute agent_b since type is "B"
        assert not agent_a.process_called
        assert agent_b.process_called
        assert not default_agent.process_called
        assert result.data["processed_by"] == "agent_b"
        assert agent_b.last_context is context_b
    
    @pytest.mark.asyncio
    async def test_execute_default_case(self, agent_a, agent_b, default_agent):
        """Test execution with no matching case, falls back to default"""
        selector = lambda ctx: ctx.data["type"]
        
        workflow = SwitchWorkflow(selector) \
            .case("A", agent_a) \
            .case("B", agent_b) \
            .default(default_agent)
        
        # Create context with unmatched type
        context_c = Context(
            id="test_ctx",
            data={"type": "C", "value": 300},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(context_c)
        
        # Should execute default agent
        assert not agent_a.process_called
        assert not agent_b.process_called
        assert default_agent.process_called
        assert result.data["processed_by"] == "default"
        assert default_agent.last_context is context_c
    
    @pytest.mark.asyncio
    async def test_execute_no_match_no_default(self, agent_a, agent_b):
        """Test execution with no matching case and no default"""
        selector = lambda ctx: ctx.data["type"]
        
        workflow = SwitchWorkflow(selector) \
            .case("A", agent_a) \
            .case("B", agent_b)
        
        # Create context with unmatched type
        context_c = Context(
            id="test_ctx",
            data={"type": "C", "value": 300},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(context_c)
        
        # Should return original context unchanged
        assert not agent_a.process_called
        assert not agent_b.process_called
        assert result is context_c
    
    @pytest.mark.asyncio
    async def test_execute_with_complex_selector(self, agent_a, agent_b, default_agent):
        """Test execution with complex selector logic"""
        # Selector that combines multiple fields
        selector = lambda ctx: f"{ctx.data['type']}_{ctx.data.get('priority', 'normal')}"
        
        workflow = SwitchWorkflow(selector) \
            .case("A_high", agent_a) \
            .case("B_normal", agent_b) \
            .default(default_agent)
        
        # Test with matching complex case
        context = Context(
            id="test_ctx",
            data={"type": "A", "priority": "high", "value": 100},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(context)
        
        assert agent_a.process_called
        assert result.data["processed_by"] == "agent_a"
    
    @pytest.mark.asyncio
    async def test_execute_with_numeric_cases(self):
        """Test execution with numeric case values"""
        selector = lambda ctx: ctx.data["status_code"]
        
        agent_200 = MockAgent("agent_200", {"status": "success"})
        agent_404 = MockAgent("agent_404", {"status": "not_found"})
        agent_500 = MockAgent("agent_500", {"status": "error"})
        
        workflow = SwitchWorkflow(selector) \
            .case(200, agent_200) \
            .case(404, agent_404) \
            .case(500, agent_500)
        
        # Test with numeric case
        context = Context(
            id="test_ctx",
            data={"status_code": 404},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(context)
        
        assert agent_404.process_called
        assert result.data["status"] == "not_found"
    
    @pytest.mark.asyncio
    async def test_execute_selector_exception_handling(self, agent_a):
        """Test execution when selector raises exception"""
        def failing_selector(ctx):
            raise KeyError("Missing key")
        
        workflow = SwitchWorkflow(failing_selector).case("A", agent_a)
        
        context = Context(
            id="test_ctx",
            data={"value": 100},
            tenant_id="test_tenant"
        )
        
        with pytest.raises(KeyError, match="Missing key"):
            await workflow.execute(context)
    
    @pytest.mark.asyncio
    async def test_execute_agent_exception_handling(self):
        """Test execution when agent raises exception"""
        failing_agent = AsyncMock()
        failing_agent.process.side_effect = RuntimeError("Agent failed")
        
        selector = lambda ctx: ctx.data["type"]
        workflow = SwitchWorkflow(selector).case("A", failing_agent)
        
        context = Context(
            id="test_ctx",
            data={"type": "A"},
            tenant_id="test_tenant"
        )
        
        with pytest.raises(RuntimeError, match="Agent failed"):
            await workflow.execute(context)
    
    @pytest.mark.asyncio
    async def test_execute_multiple_cases_same_agent(self, agent_a):
        """Test execution with multiple cases pointing to same agent"""
        selector = lambda ctx: ctx.data["type"]
        
        workflow = SwitchWorkflow(selector) \
            .case("A", agent_a) \
            .case("A1", agent_a) \
            .case("A2", agent_a)
        
        # Test different cases that should all use the same agent
        for case_type in ["A", "A1", "A2"]:
            agent_a.process_called = False  # Reset
            
            context = Context(
                id="test_ctx",
                data={"type": case_type},
                tenant_id="test_tenant"
            )
            
            result = await workflow.execute(context)
            
            assert agent_a.process_called
            assert result.data["processed_by"] == "agent_a"


class TestConditionalWorkflowIntegration:
    """Integration tests for conditional workflows"""
    
    @pytest.mark.asyncio
    async def test_nested_conditional_workflows(self):
        """Test using conditional workflows within other workflows"""
        # Create agents
        high_priority_agent = MockAgent("high_priority", {"priority": "high"})
        medium_priority_agent = MockAgent("medium_priority", {"priority": "medium"})
        low_priority_agent = MockAgent("low_priority", {"priority": "low"})
        
        # Create nested conditional workflow
        priority_workflow = ConditionalWorkflow() \
            .when(lambda ctx: ctx.data.get("amount", 0) > 1000) \
            .then(high_priority_agent) \
            .otherwise(
                ConditionalWorkflow()
                .when(lambda ctx: ctx.data.get("amount", 0) > 100)
                .then(medium_priority_agent)
                .otherwise(low_priority_agent)
            )
        
        # This won't work directly since otherwise expects an Agent, not a ConditionalWorkflow
        # But we can test the concept by creating a wrapper agent
        
        class ConditionalAgent(Agent):
            def __init__(self, workflow: ConditionalWorkflow):
                super().__init__("conditional_wrapper")
                self.workflow = workflow
            
            async def process(self, context: Context) -> Context:
                return await self.workflow.execute(context)
        
        # Create the nested structure
        inner_workflow = ConditionalWorkflow() \
            .when(lambda ctx: ctx.data.get("amount", 0) > 100) \
            .then(medium_priority_agent) \
            .otherwise(low_priority_agent)
        
        outer_workflow = ConditionalWorkflow() \
            .when(lambda ctx: ctx.data.get("amount", 0) > 1000) \
            .then(high_priority_agent) \
            .otherwise(ConditionalAgent(inner_workflow))
        
        # Test high amount (should use high priority)
        high_context = Context(
            id="test_ctx",
            data={"amount": 2000},
            tenant_id="test_tenant"
        )
        
        result = await outer_workflow.execute(high_context)
        assert result.data["priority"] == "high"
        
        # Test medium amount (should use medium priority)
        medium_context = Context(
            id="test_ctx",
            data={"amount": 500},
            tenant_id="test_tenant"
        )
        
        result = await outer_workflow.execute(medium_context)
        assert result.data["priority"] == "medium"
        
        # Test low amount (should use low priority)
        low_context = Context(
            id="test_ctx",
            data={"amount": 50},
            tenant_id="test_tenant"
        )
        
        result = await outer_workflow.execute(low_context)
        assert result.data["priority"] == "low"
    
    @pytest.mark.asyncio
    async def test_switch_and_conditional_combination(self):
        """Test combining switch and conditional workflows"""
        # Create agents
        premium_agent = MockAgent("premium", {"service": "premium"})
        basic_agent = MockAgent("basic", {"service": "basic"})
        error_agent = MockAgent("error", {"service": "error"})
        
        # Create conditional workflow for premium users
        premium_workflow = ConditionalWorkflow() \
            .when(lambda ctx: ctx.data.get("balance", 0) > 0) \
            .then(premium_agent) \
            .otherwise(error_agent)
        
        class ConditionalAgent(Agent):
            def __init__(self, workflow: ConditionalWorkflow):
                super().__init__("conditional_wrapper")
                self.workflow = workflow
            
            async def process(self, context: Context) -> Context:
                return await self.workflow.execute(context)
        
        # Create switch workflow that uses conditional for premium
        switch_workflow = SwitchWorkflow(lambda ctx: ctx.data["user_type"]) \
            .case("premium", ConditionalAgent(premium_workflow)) \
            .case("basic", basic_agent) \
            .default(error_agent)
        
        # Test premium user with positive balance
        premium_context = Context(
            id="test_ctx",
            data={"user_type": "premium", "balance": 100},
            tenant_id="test_tenant"
        )
        
        result = await switch_workflow.execute(premium_context)
        assert result.data["service"] == "premium"
        
        # Test premium user with zero balance
        premium_no_balance_context = Context(
            id="test_ctx",
            data={"user_type": "premium", "balance": 0},
            tenant_id="test_tenant"
        )
        
        result = await switch_workflow.execute(premium_no_balance_context)
        assert result.data["service"] == "error"
        
        # Test basic user
        basic_context = Context(
            id="test_ctx",
            data={"user_type": "basic"},
            tenant_id="test_tenant"
        )
        
        result = await switch_workflow.execute(basic_context)
        assert result.data["service"] == "basic"


class TestEdgeCases:
    """Test edge cases and boundary conditions"""
    
    @pytest.mark.asyncio
    async def test_conditional_with_none_values(self):
        """Test conditional workflow with None values in context"""
        agent = MockAgent("test_agent", {"processed": True})
        
        workflow = ConditionalWorkflow() \
            .when(lambda ctx: ctx.data.get("value") is not None) \
            .then(agent)
        
        # Test with None value
        context_none = Context(
            id="test_ctx",
            data={"value": None},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(context_none)
        assert result is context_none  # Should return original context
        
        # Test with actual value
        context_value = Context(
            id="test_ctx",
            data={"value": 42},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(context_value)
        assert result.data["processed"] is True
    
    @pytest.mark.asyncio
    async def test_switch_with_none_selector_value(self):
        """Test switch workflow when selector returns None"""
        agent_none = MockAgent("none_agent", {"handled_none": True})
        default_agent = MockAgent("default_agent", {"handled_default": True})
        
        workflow = SwitchWorkflow(lambda ctx: ctx.data.get("missing_key")) \
            .case(None, agent_none) \
            .default(default_agent)
        
        context = Context(
            id="test_ctx",
            data={"other_key": "value"},
            tenant_id="test_tenant"
        )
        
        result = await workflow.execute(context)
        assert result.data["handled_none"] is True
    
    @pytest.mark.asyncio
    async def test_empty_context_data(self):
        """Test workflows with empty context data"""
        agent = MockAgent("test_agent", {"processed": True})
        
        # Test conditional with empty data
        conditional = ConditionalWorkflow() \
            .when(lambda ctx: len(ctx.data) == 0) \
            .then(agent)
        
        empty_context = Context(
            id="test_ctx",
            data={},
            tenant_id="test_tenant"
        )
        
        result = await conditional.execute(empty_context)
        assert result.data["processed"] is True
        
        # Test switch with empty data
        switch = SwitchWorkflow(lambda ctx: ctx.data.get("type", "empty")) \
            .case("empty", agent)
        
        result = await switch.execute(empty_context)
        assert result.data["processed"] is True