
import pytest
from typer.testing import CliRunner
from unittest.mock import patch, MagicMock, AsyncMock, mock_open
from cmp.cli.registry_commands import registry_app

runner = CliRunner()

def test_schema_commands():
    # Mock SchemaRegistry
    with patch("cmp.cli.registry_commands.SchemaRegistry") as MockRegistry:
        mock_reg = MockRegistry.return_value
        
        # Test Register
        mock_res = MagicMock()
        mock_res.is_ok.return_value = True
        mock_res.is_err.return_value = False
        
        mock_reg.register_schema = AsyncMock(return_value=mock_res)
        mock_reg.close = AsyncMock()
        
        # Mock Path to exist and read text
        with patch("cmp.cli.registry_commands.Path") as MockPath:
            MockPath.return_value.exists.return_value = True
            MockPath.return_value.read_text.return_value = '{"type": "object"}'
            
            result = runner.invoke(registry_app, [
                "schema", "register", 
                "--file", "schema.json",
                "--id", "my-schema",
                "--version", "1.0",
                "--description", "test schema"
            ])
            if result.exit_code != 0:
                print(result.output)
            assert result.exit_code == 0
            assert "Schema registered: my-schema" in result.output
            
        # Test List
        mock_schema = MagicMock()
        mock_schema.schema_id = "my-schema"
        mock_schema.version = "1.0"
        mock_schema.description = "test"
        mock_schema.deprecated = False
        
        mock_list_res = MagicMock()
        mock_list_res.is_ok.return_value = True
        mock_list_res.is_err.return_value = False
        mock_list_res.unwrap.return_value = [mock_schema]
        
        mock_reg.list_schemas = AsyncMock(return_value=mock_list_res)
        
        result = runner.invoke(registry_app, ["schema", "list"])
        if result.exit_code != 0:
            print(result.output)
        assert result.exit_code == 0
        assert "my-schema" in result.output

def test_policy_commands():
    # Mock PolicyRegistry
    with patch("cmp.cli.registry_commands.PolicyRegistry") as MockRegistry:
        mock_reg = MockRegistry.return_value
        
        # Test Register
        mock_res = MagicMock()
        mock_res.is_ok.return_value = True
        mock_res.is_err.return_value = False
        
        mock_reg.register_policy = AsyncMock(return_value=mock_res)
        mock_reg.close = AsyncMock()
        
        # Mock Path
        with patch("cmp.cli.registry_commands.Path") as MockPath:
            MockPath.return_value.exists.return_value = True
            MockPath.return_value.read_text.return_value = 'package test'
            
            result = runner.invoke(registry_app, [
                "policy", "register",
                "--file", "policy.rego",
                "--id", "my-policy",
                "--version", "1.0"
            ])
            if result.exit_code != 0:
                print(result.output)
            assert result.exit_code == 0
            assert "Policy registered: my-policy" in result.output
            
        # Test List
        mock_policy = MagicMock()
        mock_policy.policy_id = "my-policy"
        mock_policy.version = "1.0"
        mock_policy.description = "test"
        mock_policy.deployed = True
        
        mock_list_res = MagicMock()
        mock_list_res.is_ok.return_value = True
        mock_list_res.is_err.return_value = False
        mock_list_res.unwrap.return_value = [mock_policy]
        
        mock_reg.list_policies = AsyncMock(return_value=mock_list_res)
        
        result = runner.invoke(registry_app, ["policy", "list"])
        if result.exit_code != 0:
            print(result.output)
        assert result.exit_code == 0
        assert "my-policy" in result.output
