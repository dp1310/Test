
import pytest
from typer.testing import CliRunner
from unittest.mock import patch, MagicMock, AsyncMock
import json
from cmp.cli.context_commands import context_app
from cmp.core.models import Context, ContextEnvelope


runner = CliRunner()

@patch("cmp.cli.context_commands.get_cmp_client")
def test_context_commands(mock_get_client):
    # Mock Client
    mock_client = MagicMock()
    mock_get_client.return_value = mock_client
    
    # Mock Context Service
    mock_ctx_service = MagicMock()
    mock_client.services.get_service.return_value = mock_ctx_service
    
    # Mock Context Builder
    mock_builder = MagicMock()
    mock_client.context.return_value = mock_builder
    mock_builder.with_data.return_value = mock_builder
    mock_builder.with_schema.return_value = mock_builder
    mock_builder.with_metadata.return_value = mock_builder
    mock_builder.create = AsyncMock(return_value="ctx-123")
    
    # Mock Context Object
    # Mock Context Object
    ctx = Context(id="ctx-123", data={"foo": "bar"}, tenant_id="default")
    mock_result = MagicMock()
    mock_result.is_ok.return_value = True
    mock_result.is_err.return_value = False
    mock_result.unwrap.return_value = ctx
    
    mock_list_result = MagicMock()
    mock_list_result.is_ok.return_value = True
    mock_list_result.is_err.return_value = False
    mock_list_result.unwrap.return_value = [ctx]
    
    mock_delete_result = MagicMock()
    mock_delete_result.is_ok.return_value = True
    mock_delete_result.is_err.return_value = False
    
    mock_ctx_service.get = AsyncMock(return_value=mock_result)
    mock_ctx_service.list = AsyncMock(return_value=mock_list_result)
    mock_ctx_service.update = AsyncMock(return_value=mock_result)
    mock_ctx_service.delete = AsyncMock(return_value=mock_delete_result)
    
    # Test Create
    result = runner.invoke(context_app, ["create", "-d", '{"foo": "bar"}', "-s", "schema1"])
    assert result.exit_code == 0, f"Create failed: {result.output}"
    assert "✓ Context created: ctx-123" in result.output
    
    # Test Get
    result = runner.invoke(context_app, ["get", "ctx-123"])
    assert result.exit_code == 0, f"Get failed: {result.output}"
    assert "ctx-123" in result.output
    
    # Test List
    result = runner.invoke(context_app, ["list"])
    assert result.exit_code == 0, f"List failed: {result.output}"
    assert "ctx-123" in result.output
    
    # Test Update
    result = runner.invoke(context_app, ["update", "ctx-123", "-d", '{"foo": "baz"}'])
    assert result.exit_code == 0, f"Update failed: {result.output}"
    assert "✓ Context updated: ctx-123" in result.output
    
    # Test Delete
    result = runner.invoke(context_app, ["delete", "ctx-123", "--yes"])
    assert result.exit_code == 0, f"Delete failed: {result.output}"
    assert "✓ Context deleted: ctx-123" in result.output
    
    # Test Search
    # Reuse list result for search (which calls list internally in current impl)
    result = runner.invoke(context_app, ["search", "bar"]) # "bar" is in data {"foo": "bar"}
    assert result.exit_code == 0, f"Search failed: {result.output}"
    assert "ctx-123" in result.output
    
    # Test Search No Results
    result = runner.invoke(context_app, ["search", "nonexistent"])
    assert result.exit_code == 0
    assert "No contexts found matching" in result.output

    # Test Export
    with runner.isolated_filesystem():
        result = runner.invoke(context_app, ["export", "ctx-123", "-o", "export.json"])
        assert result.exit_code == 0, f"Export failed: {result.output}"
        assert "✓ Context exported" in result.output
        
        with open("export.json", "r") as f:
            content = json.load(f)
            assert content["id"] == "ctx-123"
            assert content["data"]["foo"] == "bar"
