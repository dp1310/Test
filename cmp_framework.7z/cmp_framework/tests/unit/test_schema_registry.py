"""
Tests for schema registry.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone
import jsonschema

from cmp.registries.schema_registry import (
    SchemaRegistry, SchemaInfo, RegistryError, SchemaNotFoundError,
    SchemaValidationError, SchemaVersionError
)
from cmp.registries.persistence import InMemoryBackend, PersistenceError
from cmp.core.result import Ok, Err


class TestSchemaInfo:
    """Test SchemaInfo dataclass"""
    
    def test_schema_info_creation(self):
        """Test creating schema info"""
        info = SchemaInfo(
            schema_id="test_schema",
            version="1.0.0",
            description="Test schema",
            created_at="2023-01-01T00:00:00Z"
        )
        
        assert info.schema_id == "test_schema"
        assert info.version == "1.0.0"
        assert info.description == "Test schema"
        assert info.created_at == "2023-01-01T00:00:00Z"
        assert info.deprecated is False
        assert info.deprecated_at is None
    
    def test_schema_info_with_deprecation(self):
        """Test schema info with deprecation fields"""
        info = SchemaInfo(
            schema_id="deprecated_schema",
            version="1.0.0",
            description="Deprecated schema",
            created_at="2023-01-01T00:00:00Z",
            deprecated=True,
            deprecated_at="2023-06-01T00:00:00Z"
        )
        
        assert info.deprecated is True
        assert info.deprecated_at == "2023-06-01T00:00:00Z"


class TestSchemaRegistryErrors:
    """Test schema registry error classes"""
    
    def test_registry_error_inheritance(self):
        """Test RegistryError inheritance"""
        error = RegistryError("Test error")
        assert str(error) == "Test error"
    
    def test_schema_not_found_error(self):
        """Test SchemaNotFoundError"""
        error = SchemaNotFoundError("Schema not found")
        assert isinstance(error, RegistryError)
        assert str(error) == "Schema not found"
    
    def test_schema_validation_error(self):
        """Test SchemaValidationError"""
        error = SchemaValidationError("Validation failed")
        assert isinstance(error, RegistryError)
        assert str(error) == "Validation failed"
    
    def test_schema_version_error(self):
        """Test SchemaVersionError"""
        error = SchemaVersionError("Version conflict")
        assert isinstance(error, RegistryError)
        assert str(error) == "Version conflict"


class TestSchemaRegistry:
    """Test SchemaRegistry class"""
    
    @pytest.fixture
    def registry(self):
        """Create a schema registry with in-memory backend"""
        backend = InMemoryBackend()
        return SchemaRegistry(backend=backend, cache_enabled=True)
    
    @pytest.fixture
    def sample_schema(self):
        """Create a sample JSON schema"""
        return {
            "type": "object",
            "properties": {
                "user_id": {"type": "string"},
                "action": {"type": "string"},
                "timestamp": {"type": "string", "format": "date-time"}
            },
            "required": ["user_id", "action"]
        }
    
    def test_registry_initialization(self):
        """Test registry initialization"""
        registry = SchemaRegistry()
        assert registry.backend is not None
        assert registry.cache_enabled is True
        assert registry._cache is not None
    
    def test_registry_initialization_no_cache(self):
        """Test registry initialization without cache"""
        registry = SchemaRegistry(cache_enabled=False)
        assert registry.cache_enabled is False
        assert registry._cache is None
    
    def test_make_key_with_version(self, registry):
        """Test key generation with version"""
        key = registry._make_key("test_schema", "1.0.0")
        assert key == "schema:test_schema:1.0.0"
    
    def test_make_key_without_version(self, registry):
        """Test key generation without version (latest)"""
        key = registry._make_key("test_schema")
        assert key == "schema:test_schema:latest"
    
    @pytest.mark.asyncio
    async def test_register_schema_success(self, registry, sample_schema):
        """Test successful schema registration"""
        result = await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0",
            description="User event schema"
        )
        
        assert result.is_ok()
        
        # Verify schema was saved
        get_result = await registry.get_schema("user_event", "1.0.0")
        assert get_result.is_ok()
        
        retrieved_schema = get_result.unwrap()
        assert retrieved_schema == sample_schema
    
    @pytest.mark.asyncio
    async def test_register_schema_invalid_json_schema(self, registry):
        """Test registering invalid JSON schema"""
        invalid_schema = {
            "type": "invalid_type"  # Invalid JSON Schema type
        }
        
        result = await registry.register_schema(
            schema_id="invalid_schema",
            schema=invalid_schema,
            version="1.0.0"
        )
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), SchemaValidationError)
        assert "Invalid JSON Schema" in str(result.unwrap_err())
    
    @pytest.mark.asyncio
    async def test_register_schema_version_exists(self, registry, sample_schema):
        """Test registering schema when version already exists"""
        # Register schema first time
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        # Try to register same version again
        result = await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), SchemaVersionError)
        assert "already exists" in str(result.unwrap_err())
    
    @pytest.mark.asyncio
    async def test_register_schema_force_overwrite(self, registry, sample_schema):
        """Test force overwriting existing schema version"""
        # Register schema first time
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        # Modify schema
        modified_schema = {**sample_schema, "additionalProperties": False}
        
        # Force overwrite
        result = await registry.register_schema(
            schema_id="user_event",
            schema=modified_schema,
            version="1.0.0",
            force=True
        )
        
        assert result.is_ok()
        
        # Verify schema was updated
        get_result = await registry.get_schema("user_event", "1.0.0")
        assert get_result.is_ok()
        
        retrieved_schema = get_result.unwrap()
        assert retrieved_schema["additionalProperties"] is False
    
    @pytest.mark.asyncio
    async def test_register_schema_backend_error(self, sample_schema):
        """Test schema registration with backend error"""
        mock_backend = AsyncMock()
        mock_backend.load.return_value = Err(PersistenceError("Not found"))
        mock_backend.save.return_value = Err(PersistenceError("Save failed"))
        
        registry = SchemaRegistry(backend=mock_backend)
        result = await registry.register_schema(
            schema_id="test_schema",
            schema=sample_schema,
            version="1.0.0"
        )
        
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_get_schema_success(self, registry, sample_schema):
        """Test successful schema retrieval"""
        # Register schema first
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        result = await registry.get_schema("user_event", "1.0.0")
        
        assert result.is_ok()
        schema = result.unwrap()
        assert schema == sample_schema
    
    @pytest.mark.asyncio
    async def test_get_schema_latest(self, registry, sample_schema):
        """Test retrieving latest schema version"""
        # Register schema
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        # Get latest version (no version specified)
        result = await registry.get_schema("user_event")
        
        assert result.is_ok()
        schema = result.unwrap()
        assert schema == sample_schema
    
    @pytest.mark.asyncio
    async def test_get_schema_not_found(self, registry):
        """Test schema retrieval when not found"""
        result = await registry.get_schema("nonexistent_schema", "1.0.0")
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), SchemaNotFoundError)
        assert "not found" in str(result.unwrap_err())
    
    @pytest.mark.asyncio
    async def test_get_schema_with_cache(self, registry, sample_schema):
        """Test schema retrieval with caching"""
        # Register schema
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        # First retrieval (from backend)
        result1 = await registry.get_schema("user_event", "1.0.0")
        assert result1.is_ok()
        
        # Second retrieval (from cache)
        result2 = await registry.get_schema("user_event", "1.0.0")
        assert result2.is_ok()
        
        # Should be the same
        assert result1.unwrap() == result2.unwrap()
    
    @pytest.mark.asyncio
    async def test_validate_data_success(self, registry, sample_schema):
        """Test successful data validation"""
        # Register schema
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        # Valid data
        valid_data = {
            "user_id": "user123",
            "action": "login",
            "timestamp": "2023-01-01T00:00:00Z"
        }
        
        result = await registry.validate_data(
            schema_id="user_event",
            data=valid_data,
            version="1.0.0"
        )
        
        assert result.is_ok()
    
    @pytest.mark.asyncio
    async def test_validate_data_validation_error(self, registry, sample_schema):
        """Test data validation with validation error"""
        # Register schema
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        # Invalid data (missing required field)
        invalid_data = {
            "user_id": "user123"
            # Missing required "action" field
        }
        
        result = await registry.validate_data(
            schema_id="user_event",
            data=invalid_data,
            version="1.0.0"
        )
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), SchemaValidationError)
        assert "validation failed" in str(result.unwrap_err()).lower()
    
    @pytest.mark.asyncio
    async def test_validate_data_schema_not_found(self, registry):
        """Test data validation when schema not found"""
        result = await registry.validate_data(
            schema_id="nonexistent_schema",
            data={"test": "data"}
        )
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), SchemaValidationError)
    
    @pytest.mark.asyncio
    async def test_list_schemas_success(self, registry, sample_schema):
        """Test listing all schemas"""
        # Register multiple schemas
        schemas_to_register = [
            ("user_event", "1.0.0", "User events v1"),
            ("user_event", "2.0.0", "User events v2"),
            ("product_event", "1.0.0", "Product events v1")
        ]
        
        for schema_id, version, description in schemas_to_register:
            await registry.register_schema(
                schema_id=schema_id,
                schema=sample_schema,
                version=version,
                description=description
            )
        
        result = await registry.list_schemas()
        
        assert result.is_ok()
        schemas = result.unwrap()
        assert len(schemas) == 3
        
        # Should be sorted by schema_id, version
        schema_pairs = [(s.schema_id, s.version) for s in schemas]
        expected_pairs = [
            ("product_event", "1.0.0"),
            ("user_event", "1.0.0"),
            ("user_event", "2.0.0")
        ]
        assert schema_pairs == expected_pairs
    
    @pytest.mark.asyncio
    async def test_list_schemas_empty(self, registry):
        """Test listing schemas when none exist"""
        result = await registry.list_schemas()
        
        assert result.is_ok()
        schemas = result.unwrap()
        assert len(schemas) == 0
    
    @pytest.mark.asyncio
    async def test_list_schemas_backend_error(self):
        """Test listing schemas with backend error"""
        mock_backend = AsyncMock()
        mock_backend.list.return_value = Err(PersistenceError("List failed"))
        
        registry = SchemaRegistry(backend=mock_backend)
        result = await registry.list_schemas()
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), RegistryError)
    
    @pytest.mark.asyncio
    async def test_deprecate_schema_success(self, registry, sample_schema):
        """Test successful schema deprecation"""
        # Register schema
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        result = await registry.deprecate_schema("user_event", "1.0.0")
        
        assert result.is_ok()
        
        # Verify schema is marked as deprecated
        schemas_result = await registry.list_schemas()
        assert schemas_result.is_ok()
        
        schemas = schemas_result.unwrap()
        assert len(schemas) == 1
        assert schemas[0].deprecated is True
        assert schemas[0].deprecated_at is not None
    
    @pytest.mark.asyncio
    async def test_deprecate_schema_not_found(self, registry):
        """Test deprecating nonexistent schema"""
        result = await registry.deprecate_schema("nonexistent_schema", "1.0.0")
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), SchemaNotFoundError)
    
    @pytest.mark.asyncio
    async def test_delete_schema_success(self, registry, sample_schema):
        """Test successful schema deletion"""
        # Register schema
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        
        result = await registry.delete_schema("user_event", "1.0.0")
        
        assert result.is_ok()
        
        # Verify schema is deleted
        get_result = await registry.get_schema("user_event", "1.0.0")
        assert get_result.is_err()
    
    @pytest.mark.asyncio
    async def test_delete_schema_not_found(self, registry):
        """Test deleting nonexistent schema"""
        result = await registry.delete_schema("nonexistent_schema", "1.0.0")
        
        assert result.is_err()
        assert isinstance(result.unwrap_err(), SchemaNotFoundError)
    
    @pytest.mark.asyncio
    async def test_close_registry(self, registry, sample_schema):
        """Test closing registry"""
        # Add some data to cache
        await registry.register_schema(
            schema_id="user_event",
            schema=sample_schema,
            version="1.0.0"
        )
        await registry.get_schema("user_event", "1.0.0")  # This should cache it
        
        # Verify cache has data
        assert len(registry._cache) > 0
        
        # Close registry
        await registry.close()
        
        # Verify cache is cleared
        assert len(registry._cache) == 0


class TestSchemaRegistryEdgeCases:
    """Test edge cases and boundary conditions"""
    
    @pytest.mark.asyncio
    async def test_cache_invalidation_on_register(self):
        """Test cache invalidation when registering schema"""
        registry = SchemaRegistry(cache_enabled=True)
        
        schema = {"type": "object", "properties": {"id": {"type": "string"}}}
        
        # Register and cache
        await registry.register_schema("test_schema", schema, "1.0.0")
        await registry.get_schema("test_schema", "1.0.0")  # Cache it
        
        # Register again with force (should invalidate cache)
        updated_schema = {**schema, "additionalProperties": False}
        await registry.register_schema(
            "test_schema", updated_schema, "1.0.0", force=True
        )
        
        # Get schema should return updated version
        result = await registry.get_schema("test_schema", "1.0.0")
        assert result.is_ok()
        assert result.unwrap()["additionalProperties"] is False
    
    @pytest.mark.asyncio
    async def test_cache_invalidation_on_deprecate(self):
        """Test cache invalidation when deprecating schema"""
        registry = SchemaRegistry(cache_enabled=True)
        
        schema = {"type": "object", "properties": {"id": {"type": "string"}}}
        
        # Register and cache
        await registry.register_schema("test_schema", schema, "1.0.0")
        await registry.get_schema("test_schema", "1.0.0")  # Cache it
        
        # Deprecate schema
        await registry.deprecate_schema("test_schema", "1.0.0")
        
        # Verify deprecation worked (cache should be invalidated)
        schemas_result = await registry.list_schemas()
        assert schemas_result.is_ok()
        schemas = schemas_result.unwrap()
        assert len(schemas) == 1
        assert schemas[0].deprecated is True
    
    @pytest.mark.asyncio
    async def test_cache_invalidation_on_delete(self):
        """Test cache invalidation when deleting schema"""
        registry = SchemaRegistry(cache_enabled=True)
        
        schema = {"type": "object", "properties": {"id": {"type": "string"}}}
        
        # Register and cache
        await registry.register_schema("test_schema", schema, "1.0.0")
        await registry.get_schema("test_schema", "1.0.0")  # Cache it
        
        # Delete schema
        await registry.delete_schema("test_schema", "1.0.0")
        
        # Should not be found
        result = await registry.get_schema("test_schema", "1.0.0")
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_registry_without_cache(self):
        """Test registry operations without caching"""
        registry = SchemaRegistry(cache_enabled=False)
        
        schema = {"type": "object", "properties": {"id": {"type": "string"}}}
        
        # Register schema
        result = await registry.register_schema("test_schema", schema, "1.0.0")
        assert result.is_ok()
        
        # Get schema (should work without cache)
        get_result = await registry.get_schema("test_schema", "1.0.0")
        assert get_result.is_ok()
        assert get_result.unwrap() == schema
    
    @pytest.mark.asyncio
    async def test_complex_schema_validation(self):
        """Test validation with complex schema"""
        registry = SchemaRegistry()
        
        # Complex schema with nested objects and arrays
        complex_schema = {
            "type": "object",
            "properties": {
                "user": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "name": {"type": "string"},
                        "tags": {
                            "type": "array",
                            "items": {"type": "string"}
                        }
                    },
                    "required": ["id", "name"]
                },
                "events": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "type": {"type": "string"},
                            "timestamp": {"type": "string", "format": "date-time"}
                        },
                        "required": ["type", "timestamp"]
                    }
                }
            },
            "required": ["user", "events"]
        }
        
        await registry.register_schema("complex_schema", complex_schema, "1.0.0")
        
        # Valid complex data
        valid_data = {
            "user": {
                "id": "user123",
                "name": "John Doe",
                "tags": ["premium", "active"]
            },
            "events": [
                {
                    "type": "login",
                    "timestamp": "2023-01-01T00:00:00Z"
                },
                {
                    "type": "purchase",
                    "timestamp": "2023-01-01T01:00:00Z"
                }
            ]
        }
        
        result = await registry.validate_data("complex_schema", valid_data, "1.0.0")
        assert result.is_ok()
        
        # Invalid complex data (missing required nested field)
        invalid_data = {
            "user": {
                "id": "user123"
                # Missing required "name" field
            },
            "events": []
        }
        
        result = await registry.validate_data("complex_schema", invalid_data, "1.0.0")
        assert result.is_err()
        assert isinstance(result.unwrap_err(), SchemaValidationError)
    
    @pytest.mark.asyncio
    async def test_list_schemas_with_corrupted_metadata(self):
        """Test listing schemas when some have corrupted metadata"""
        registry = SchemaRegistry()
        
        # Register a normal schema
        schema = {"type": "object", "properties": {"id": {"type": "string"}}}
        await registry.register_schema("normal_schema", schema, "1.0.0")
        
        # Manually add corrupted entry to backend
        await registry.backend.save(
            key="schema:corrupted:1.0.0",
            value=schema,
            metadata={}  # Missing required metadata fields
        )
        
        # List schemas should handle corrupted entries gracefully
        result = await registry.list_schemas()
        assert result.is_ok()
        
        schemas = result.unwrap()
        # Should only return the valid schema
        assert len(schemas) == 1
        assert schemas[0].schema_id == "normal_schema"