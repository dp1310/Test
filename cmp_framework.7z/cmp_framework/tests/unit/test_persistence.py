"""Tests for registry persistence layer."""

import pytest
import asyncio
import tempfile
import shutil
from pathlib import Path
from datetime import datetime, timezone

from cmp.registries.persistence import (
    RegistryBackend, FileBackend, InMemoryBackend, PersistenceError,
    create_backend
)
from cmp.core.result import Ok, Err


class TestPersistenceError:
    """Test PersistenceError exception."""
    
    def test_persistence_error_creation(self):
        """Test PersistenceError creation."""
        error = PersistenceError("Test error")
        assert str(error) == "Test error"
        assert isinstance(error, Exception)


class TestInMemoryBackend:
    """Test InMemoryBackend implementation."""
    
    @pytest.fixture
    async def backend(self):
        """Create in-memory backend for testing."""
        backend = InMemoryBackend()
        yield backend
        await backend.close()
    
    @pytest.mark.asyncio
    async def test_save_and_load(self, backend):
        """Test saving and loading data."""
        key = "test_key"
        value = {"name": "test", "version": "1.0"}
        metadata = {"author": "test_user"}
        
        # Save data
        result = await backend.save(key, value, metadata)
        assert result.is_ok()
        
        # Load data
        result = await backend.load(key)
        assert result.is_ok()
        
        data = result.unwrap()
        assert data["key"] == key
        assert data["value"] == value
        assert data["metadata"] == metadata
        assert "saved_at" in data
    
    @pytest.mark.asyncio
    async def test_load_nonexistent_key(self, backend):
        """Test loading non-existent key."""
        result = await backend.load("nonexistent")
        assert result.is_err()
        assert "Key not found" in str(result.unwrap_err())
    
    @pytest.mark.asyncio
    async def test_list_keys(self, backend):
        """Test listing keys."""
        # Save multiple keys
        await backend.save("key1", {"data": 1})
        await backend.save("key2", {"data": 2})
        await backend.save("prefix_key3", {"data": 3})
        
        # List all keys
        result = await backend.list()
        assert result.is_ok()
        keys = result.unwrap()
        assert sorted(keys) == ["key1", "key2", "prefix_key3"]
        
        # List with prefix
        result = await backend.list("prefix_")
        assert result.is_ok()
        keys = result.unwrap()
        assert keys == ["prefix_key3"]
    
    @pytest.mark.asyncio
    async def test_delete_key(self, backend):
        """Test deleting keys."""
        key = "test_key"
        await backend.save(key, {"data": "test"})
        
        # Verify key exists
        result = await backend.load(key)
        assert result.is_ok()
        
        # Delete key
        result = await backend.delete(key)
        assert result.is_ok()
        
        # Verify key is gone
        result = await backend.load(key)
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_delete_nonexistent_key(self, backend):
        """Test deleting non-existent key."""
        result = await backend.delete("nonexistent")
        assert result.is_err()
        assert "Key not found" in str(result.unwrap_err())
    
    @pytest.mark.asyncio
    async def test_search_simple(self, backend):
        """Test simple search functionality."""
        # Save test data
        await backend.save("item1", {"type": "schema", "name": "user"})
        await backend.save("item2", {"type": "policy", "name": "admin"})
        await backend.save("item3", {"type": "schema", "name": "product"})
        
        # Search by type
        result = await backend.search({"type": "schema"})
        assert result.is_ok()
        
        results = result.unwrap()
        assert len(results) == 2
        
        # Verify results contain correct items
        names = [r["value"]["name"] for r in results]
        assert "user" in names
        assert "product" in names
    
    @pytest.mark.asyncio
    async def test_search_nested_fields(self, backend):
        """Test search with nested field paths."""
        # Save nested data
        await backend.save("item1", {
            "metadata": {"category": "user", "version": "1.0"}
        })
        await backend.save("item2", {
            "metadata": {"category": "admin", "version": "2.0"}
        })
        
        # Search by nested field
        result = await backend.search({"metadata.category": "user"})
        assert result.is_ok()
        
        results = result.unwrap()
        assert len(results) == 1
        assert results[0]["value"]["metadata"]["category"] == "user"
    
    @pytest.mark.asyncio
    async def test_search_no_matches(self, backend):
        """Test search with no matches."""
        await backend.save("item1", {"type": "schema"})
        
        result = await backend.search({"type": "nonexistent"})
        assert result.is_ok()
        assert result.unwrap() == []
    
    @pytest.mark.asyncio
    async def test_close(self, backend):
        """Test closing backend."""
        await backend.save("test", {"data": "test"})
        await backend.close()
        
        # Data should be cleared after close
        result = await backend.load("test")
        assert result.is_err()


class TestFileBackend:
    """Test FileBackend implementation."""
    
    @pytest.fixture
    async def backend(self):
        """Create file backend with temporary directory."""
        temp_dir = tempfile.mkdtemp()
        backend = FileBackend(Path(temp_dir))
        yield backend
        await backend.close()
        shutil.rmtree(temp_dir, ignore_errors=True)
    
    @pytest.mark.asyncio
    async def test_save_and_load(self, backend):
        """Test saving and loading to files."""
        key = "test_schema"
        value = {"name": "User", "fields": ["id", "name"]}
        metadata = {"version": "1.0"}
        
        # Save data
        result = await backend.save(key, value, metadata)
        assert result.is_ok()
        
        # Verify file exists
        file_path = backend._get_file_path(key)
        assert file_path.exists()
        
        # Load data
        result = await backend.load(key)
        assert result.is_ok()
        
        data = result.unwrap()
        assert data["key"] == key
        assert data["value"] == value
        assert data["metadata"] == metadata
        assert "saved_at" in data
    
    @pytest.mark.asyncio
    async def test_safe_key_handling(self, backend):
        """Test that unsafe characters in keys are handled."""
        unsafe_key = "path/with\\slashes:and:colons"
        value = {"data": "test"}
        
        result = await backend.save(unsafe_key, value)
        assert result.is_ok()
        
        # Should be able to load back
        result = await backend.load(unsafe_key)
        assert result.is_ok()
        assert result.unwrap()["value"] == value
    
    @pytest.mark.asyncio
    async def test_load_nonexistent_file(self, backend):
        """Test loading non-existent file."""
        result = await backend.load("nonexistent")
        assert result.is_err()
        assert "Key not found" in str(result.unwrap_err())
    
    @pytest.mark.asyncio
    async def test_list_files(self, backend):
        """Test listing files."""
        # Save multiple files
        await backend.save("schema1", {"type": "schema"})
        await backend.save("schema2", {"type": "schema"})
        await backend.save("policy1", {"type": "policy"})
        
        # List all
        result = await backend.list()
        assert result.is_ok()
        keys = result.unwrap()
        assert sorted(keys) == ["policy1", "schema1", "schema2"]
        
        # List with prefix
        result = await backend.list("schema")
        assert result.is_ok()
        keys = result.unwrap()
        assert sorted(keys) == ["schema1", "schema2"]
    
    @pytest.mark.asyncio
    async def test_delete_file(self, backend):
        """Test deleting files."""
        key = "test_delete"
        await backend.save(key, {"data": "test"})
        
        # Verify file exists
        file_path = backend._get_file_path(key)
        assert file_path.exists()
        
        # Delete
        result = await backend.delete(key)
        assert result.is_ok()
        
        # Verify file is gone
        assert not file_path.exists()
        
        # Loading should fail
        result = await backend.load(key)
        assert result.is_err()
    
    @pytest.mark.asyncio
    async def test_delete_nonexistent_file(self, backend):
        """Test deleting non-existent file."""
        result = await backend.delete("nonexistent")
        assert result.is_err()
        assert "Key not found" in str(result.unwrap_err())
    
    @pytest.mark.asyncio
    async def test_search_files(self, backend):
        """Test searching across files."""
        # Save test data
        await backend.save("user_schema", {
            "type": "schema",
            "name": "User",
            "category": "entity"
        })
        await backend.save("admin_policy", {
            "type": "policy", 
            "name": "AdminAccess",
            "category": "security"
        })
        await backend.save("product_schema", {
            "type": "schema",
            "name": "Product", 
            "category": "entity"
        })
        
        # Search by type
        result = await backend.search({"type": "schema"})
        assert result.is_ok()
        
        results = result.unwrap()
        assert len(results) == 2
        
        # Search by category
        result = await backend.search({"category": "entity"})
        assert result.is_ok()
        
        results = result.unwrap()
        assert len(results) == 2
    
    @pytest.mark.asyncio
    async def test_atomic_save(self, backend):
        """Test that saves are atomic (using temp file)."""
        key = "atomic_test"
        value = {"data": "test"}
        
        # Save should use temp file then rename
        result = await backend.save(key, value)
        assert result.is_ok()
        
        # Final file should exist
        file_path = backend._get_file_path(key)
        assert file_path.exists()
        
        # Temp file should not exist
        temp_path = file_path.with_suffix(".tmp")
        assert not temp_path.exists()
    
    @pytest.mark.asyncio
    async def test_concurrent_access(self, backend):
        """Test concurrent access with locking."""
        async def save_data(i):
            result = await backend.save(f"key_{i}", {"value": i})
            return result
        
        # Run multiple saves concurrently
        tasks = [save_data(i) for i in range(10)]
        results = await asyncio.gather(*tasks)
        
        # All should succeed
        assert all(r.is_ok() for r in results)
        
        # All files should exist
        list_result = await backend.list()
        assert list_result.is_ok()
        keys = list_result.unwrap()
        assert len(keys) == 10


class TestCreateBackend:
    """Test backend factory function."""
    
    def test_create_memory_backend(self):
        """Test creating in-memory backend."""
        backend = create_backend("memory")
        assert isinstance(backend, InMemoryBackend)
    
    def test_create_file_backend(self):
        """Test creating file backend."""
        with tempfile.TemporaryDirectory() as temp_dir:
            backend = create_backend("file", base_path=temp_dir)
            assert isinstance(backend, FileBackend)
            assert backend.base_path == Path(temp_dir)
    
    def test_create_file_backend_default_path(self):
        """Test creating file backend with default path."""
        backend = create_backend("file")
        assert isinstance(backend, FileBackend)
        assert backend.base_path == Path("./data/registries")
    
    def test_create_unknown_backend(self):
        """Test creating unknown backend type."""
        with pytest.raises(ValueError, match="Unknown backend type"):
            create_backend("unknown")
    
    def test_create_unimplemented_backends(self):
        """Test creating unimplemented backend types."""
        with pytest.raises(NotImplementedError, match="SQLite backend not yet implemented"):
            create_backend("sqlite")
        
        with pytest.raises(NotImplementedError, match="PostgreSQL backend not yet implemented"):
            create_backend("postgres")


class TestRegistryBackendInterface:
    """Test that backends implement the interface correctly."""
    
    @pytest.mark.asyncio
    async def test_memory_backend_interface(self):
        """Test that InMemoryBackend implements all abstract methods."""
        backend = InMemoryBackend()
        
        # Test all methods exist and are callable
        assert hasattr(backend, 'save')
        assert hasattr(backend, 'load')
        assert hasattr(backend, 'list')
        assert hasattr(backend, 'delete')
        assert hasattr(backend, 'search')
        assert hasattr(backend, 'close')
        
        await backend.close()
    
    @pytest.mark.asyncio
    async def test_file_backend_interface(self):
        """Test that FileBackend implements all abstract methods."""
        with tempfile.TemporaryDirectory() as temp_dir:
            backend = FileBackend(Path(temp_dir))
            
            # Test all methods exist and are callable
            assert hasattr(backend, 'save')
            assert hasattr(backend, 'load')
            assert hasattr(backend, 'list')
            assert hasattr(backend, 'delete')
            assert hasattr(backend, 'search')
            assert hasattr(backend, 'close')
            
            await backend.close()


class TestErrorHandling:
    """Test error handling in persistence operations."""
    
    @pytest.mark.asyncio
    async def test_file_backend_invalid_json(self):
        """Test handling of corrupted JSON files."""
        with tempfile.TemporaryDirectory() as temp_dir:
            backend = FileBackend(Path(temp_dir))
            
            # Create invalid JSON file
            key = "invalid_json"
            file_path = backend._get_file_path(key)
            file_path.write_text("invalid json content")
            
            # Loading should return error
            result = await backend.load(key)
            assert result.is_err()
            assert "Invalid JSON" in str(result.unwrap_err())
            
            await backend.close()
    
    @pytest.mark.asyncio
    async def test_search_with_missing_fields(self):
        """Test search when data doesn't have expected fields."""
        backend = InMemoryBackend()
        
        # Save data without expected field
        await backend.save("item1", {"name": "test"})  # No "type" field
        
        # Search for missing field should not match
        result = await backend.search({"type": "schema"})
        assert result.is_ok()
        assert result.unwrap() == []
        
        await backend.close()