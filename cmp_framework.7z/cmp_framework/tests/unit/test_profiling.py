"""Tests for profiling utilities."""

import pytest
import asyncio
import tempfile
import os
from unittest.mock import patch, MagicMock, mock_open
from datetime import datetime, timezone

from cmp.monitoring.profiling import (
    ProfileResult, CPUProfiler, MemoryProfiler, 
    profile_cpu, profile_memory, profile_async_function
)


def test_profile_result_creation():
    """Test ProfileResult creation and properties."""
    result = ProfileResult(
        function_name="test_func",
        duration_seconds=1.5,
        cpu_stats="cpu stats",
        memory_stats={"peak_mb": 10.5}
    )
    
    assert result.function_name == "test_func"
    assert result.duration_seconds == 1.5
    assert result.cpu_stats == "cpu stats"
    assert result.memory_stats == {"peak_mb": 10.5}
    assert result.timestamp is not None


def test_profile_result_auto_timestamp():
    """Test ProfileResult automatic timestamp generation."""
    result = ProfileResult(
        function_name="test_func",
        duration_seconds=1.0
    )
    
    # Should have auto-generated timestamp
    assert result.timestamp is not None
    # Should be valid ISO format
    datetime.fromisoformat(result.timestamp.replace('Z', '+00:00'))


def test_cpu_profiler_context_manager():
    """Test CPUProfiler as context manager."""
    profiler = CPUProfiler()
    
    # Initially no stats
    stats = profiler.get_stats()
    assert "No profiling data available" in stats
    
    # Use as context manager
    with profiler:
        # Simple operation to profile
        sum(range(1000))
    
    # Should have stats now
    stats = profiler.get_stats()
    assert "No profiling data available" not in stats
    assert len(stats) > 0


def test_cpu_profiler_get_stats_options():
    """Test CPUProfiler get_stats with different options."""
    profiler = CPUProfiler()
    
    with profiler:
        sum(range(100))
    
    # Test different sort options
    stats_cumulative = profiler.get_stats(sort_by="cumulative", limit=5)
    stats_time = profiler.get_stats(sort_by="time", limit=10)
    stats_calls = profiler.get_stats(sort_by="calls", limit=15)
    
    assert len(stats_cumulative) > 0
    assert len(stats_time) > 0
    assert len(stats_calls) > 0


def test_cpu_profiler_save_stats():
    """Test CPUProfiler save_stats functionality."""
    profiler = CPUProfiler()
    
    with profiler:
        sum(range(100))
    
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp_name = tmp.name
    
    try:
        profiler.save_stats(tmp_name)
        # File should exist and have content
        assert os.path.exists(tmp_name)
        assert os.path.getsize(tmp_name) > 0
    finally:
        # Use try/except for Windows file permission issues
        try:
            os.unlink(tmp_name)
        except (PermissionError, FileNotFoundError):
            pass


def test_cpu_profiler_save_stats_no_data():
    """Test CPUProfiler save_stats with no data."""
    profiler = CPUProfiler()
    
    # Should not raise error even with no data
    with tempfile.NamedTemporaryFile() as tmp:
        profiler.save_stats(tmp.name)


@patch('tracemalloc.start')
@patch('tracemalloc.stop')
@patch('tracemalloc.take_snapshot')
@patch('tracemalloc.get_traced_memory')
def test_memory_profiler_context_manager(mock_get_memory, mock_snapshot, mock_stop, mock_start):
    """Test MemoryProfiler as context manager."""
    # Mock snapshots
    mock_before = MagicMock()
    mock_after = MagicMock()
    mock_snapshot.side_effect = [mock_before, mock_after]
    mock_get_memory.return_value = (1000, 2000)  # current, peak
    
    # Mock comparison
    mock_stat = MagicMock()
    mock_stat.size_diff = 1024 * 1024  # 1MB
    mock_stat.count_diff = 100
    mock_stat.traceback.format.return_value = ["test.py:10"]
    mock_after.compare_to.return_value = [mock_stat]
    
    profiler = MemoryProfiler()
    
    with profiler:
        # Simple operation
        data = list(range(100))
    
    # Verify tracemalloc calls
    mock_start.assert_called_once()
    mock_stop.assert_called_once()
    assert mock_snapshot.call_count == 2
    
    # Get stats
    stats = profiler.get_stats(top_n=5)
    assert "peak_mb" in stats
    assert "top_allocations" in stats
    assert stats["peak_mb"] == 2000 / 1024 / 1024


@patch('tracemalloc.start')
@patch('tracemalloc.stop')
def test_memory_profiler_no_data(mock_stop, mock_start):
    """Test MemoryProfiler with no data."""
    profiler = MemoryProfiler()
    
    # Don't use context manager, so no snapshots
    stats = profiler.get_stats()
    assert "error" in stats
    assert "No profiling data available" in stats["error"]


def test_profile_cpu_decorator_sync():
    """Test profile_cpu decorator on sync function."""
    @profile_cpu(limit=5)
    def test_function():
        return sum(range(1000))
    
    with patch('builtins.print') as mock_print:
        result = test_function()
        
        assert result == sum(range(1000))
        # Should have printed profile info
        mock_print.assert_called()
        
        # Check that CPU profile header was printed
        calls = [str(call) for call in mock_print.call_args_list]
        profile_header_found = any("CPU Profile for test_function" in call for call in calls)
        assert profile_header_found


@pytest.mark.asyncio
async def test_profile_cpu_decorator_async():
    """Test profile_cpu decorator on async function."""
    @profile_cpu(limit=5)
    async def test_async_function():
        await asyncio.sleep(0.01)
        return sum(range(1000))
    
    with patch('builtins.print') as mock_print:
        result = await test_async_function()
        
        assert result == sum(range(1000))
        # Should have printed profile info
        mock_print.assert_called()


@patch('tracemalloc.start')
@patch('tracemalloc.stop')
@patch('tracemalloc.take_snapshot')
@patch('tracemalloc.get_traced_memory')
def test_profile_memory_decorator_sync(mock_get_memory, mock_snapshot, mock_stop, mock_start):
    """Test profile_memory decorator on sync function."""
    # Setup mocks
    mock_before = MagicMock()
    mock_after = MagicMock()
    mock_snapshot.side_effect = [mock_before, mock_after]
    mock_get_memory.return_value = (1000, 2000)
    
    mock_stat = MagicMock()
    mock_stat.size_diff = 1024 * 1024
    mock_stat.count_diff = 100
    mock_stat.traceback.format.return_value = ["test.py:10"]
    mock_after.compare_to.return_value = [mock_stat]
    
    @profile_memory(top_n=3)
    def test_function():
        return list(range(1000))
    
    with patch('builtins.print') as mock_print:
        result = test_function()
        
        assert len(result) == 1000
        # Should have printed memory profile info
        mock_print.assert_called()
        
        # Check for memory profile output
        calls = [str(call) for call in mock_print.call_args_list]
        memory_header_found = any("Memory Profile for test_function" in call for call in calls)
        assert memory_header_found


@pytest.mark.asyncio
@patch('tracemalloc.start')
@patch('tracemalloc.stop')
@patch('tracemalloc.take_snapshot')
@patch('tracemalloc.get_traced_memory')
async def test_profile_memory_decorator_async(mock_get_memory, mock_snapshot, mock_stop, mock_start):
    """Test profile_memory decorator on async function."""
    # Setup mocks
    mock_before = MagicMock()
    mock_after = MagicMock()
    mock_snapshot.side_effect = [mock_before, mock_after]
    mock_get_memory.return_value = (1000, 2000)
    
    mock_stat = MagicMock()
    mock_stat.size_diff = 1024 * 1024
    mock_stat.count_diff = 100
    mock_stat.traceback.format.return_value = ["test.py:10"]
    mock_after.compare_to.return_value = [mock_stat]
    
    @profile_memory(top_n=3)
    async def test_async_function():
        await asyncio.sleep(0.01)
        return list(range(1000))
    
    with patch('builtins.print') as mock_print:
        result = await test_async_function()
        
        assert len(result) == 1000
        mock_print.assert_called()


@pytest.mark.asyncio
async def test_profile_async_function_both_enabled():
    """Test profile_async_function with both CPU and memory profiling."""
    async def test_func(x, y):
        await asyncio.sleep(0.01)
        return x + y
    
    with patch('cmp.monitoring.profiling.CPUProfiler') as mock_cpu_class:
        with patch('cmp.monitoring.profiling.MemoryProfiler') as mock_memory_class:
            # Setup mocks
            mock_cpu = MagicMock()
            mock_cpu.get_stats.return_value = "cpu stats"
            mock_cpu_class.return_value = mock_cpu
            
            mock_memory = MagicMock()
            mock_memory.get_stats.return_value = {"peak_mb": 5.0}
            mock_memory_class.return_value = mock_memory
            
            result = await profile_async_function(
                test_func, 10, 20,
                profile_cpu_enabled=True,
                profile_memory_enabled=True
            )
            
            assert isinstance(result, ProfileResult)
            assert result.function_name == "test_func"
            assert result.duration_seconds > 0
            assert result.cpu_stats == "cpu stats"
            assert result.memory_stats == {"peak_mb": 5.0}


@pytest.mark.asyncio
async def test_profile_async_function_cpu_only():
    """Test profile_async_function with only CPU profiling."""
    async def test_func():
        return "result"
    
    with patch('cmp.monitoring.profiling.CPUProfiler') as mock_cpu_class:
        mock_cpu = MagicMock()
        mock_cpu.get_stats.return_value = "cpu stats"
        mock_cpu_class.return_value = mock_cpu
        
        result = await profile_async_function(
            test_func,
            profile_cpu_enabled=True,
            profile_memory_enabled=False
        )
        
        assert result.cpu_stats == "cpu stats"
        assert result.memory_stats is None


@pytest.mark.asyncio
async def test_profile_async_function_memory_only():
    """Test profile_async_function with only memory profiling."""
    async def test_func():
        return "result"
    
    with patch('cmp.monitoring.profiling.MemoryProfiler') as mock_memory_class:
        mock_memory = MagicMock()
        mock_memory.get_stats.return_value = {"peak_mb": 3.0}
        mock_memory_class.return_value = mock_memory
        
        result = await profile_async_function(
            test_func,
            profile_cpu_enabled=False,
            profile_memory_enabled=True
        )
        
        assert result.cpu_stats is None
        assert result.memory_stats == {"peak_mb": 3.0}


@pytest.mark.asyncio
async def test_profile_async_function_with_exception():
    """Test profile_async_function when function raises exception."""
    async def failing_func():
        raise ValueError("Test error")
    
    with patch('cmp.monitoring.profiling.CPUProfiler') as mock_cpu_class:
        with patch('cmp.monitoring.profiling.MemoryProfiler') as mock_memory_class:
            mock_cpu = MagicMock()
            mock_memory = MagicMock()
            mock_cpu_class.return_value = mock_cpu
            mock_memory_class.return_value = mock_memory
            
            with pytest.raises(ValueError, match="Test error"):
                await profile_async_function(
                    failing_func,
                    profile_cpu_enabled=True,
                    profile_memory_enabled=True
                )
            
            # Should still call __exit__ on profilers
            mock_cpu.__exit__.assert_called_once()
            mock_memory.__exit__.assert_called_once()


def test_memory_profiler_get_stats_with_traceback():
    """Test MemoryProfiler get_stats with traceback formatting."""
    profiler = MemoryProfiler()
    
    # Mock snapshots
    mock_before = MagicMock()
    mock_after = MagicMock()
    profiler._snapshot_before = mock_before
    profiler._snapshot_after = mock_after
    profiler._peak_memory = 5 * 1024 * 1024  # 5MB
    
    # Mock stat with no traceback
    mock_stat_no_tb = MagicMock()
    mock_stat_no_tb.size_diff = 2 * 1024 * 1024  # 2MB
    mock_stat_no_tb.count_diff = 50
    mock_stat_no_tb.traceback = None
    
    mock_after.compare_to.return_value = [mock_stat_no_tb]
    
    stats = profiler.get_stats(top_n=1)
    
    assert stats["peak_mb"] == 5.0
    assert len(stats["top_allocations"]) == 1
    assert stats["top_allocations"][0]["file"] == "unknown"
    assert stats["top_allocations"][0]["size_mb"] == 2.0
    assert stats["top_allocations"][0]["count"] == 50