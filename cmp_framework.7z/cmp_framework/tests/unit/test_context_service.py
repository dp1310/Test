"""
Unit tests for ContextService.
"""

import pytest
from cmp.services.context_service import ContextService
from cmp.storage.context_store import InMemoryContextStore
from cmp.core.observable import ContextObservable
from cmp.services.policy_service import MockPolicyService
from cmp.core.models import ContextEvent


@pytest.fixture
def context_service():
    """Create ContextService for testing"""
    store = InMemoryContextStore()
    observable = ContextObservable()
    policy_service = MockPolicyService()
    
    return ContextService(
        store=store,
        schema_registry=None,
        policy_service=policy_service,
        observable=observable
    )


@pytest.mark.asyncio
class TestContextService:
    """Tests for ContextService"""
    
    async def test_create_context(self, context_service):
        """Test creating a context"""
        result = await context_service.create(
            data={"key": "value"},
            schema_name="test_schema",
            tenant_id="tenant_1"
        )
        
        assert result.is_ok()
        context_id = result.unwrap()
        assert context_id.startswith("ctx_")
    
    async def test_get_context(self, context_service):
        """Test retrieving a context"""
        # Create context
        create_result = await context_service.create(
            data={"key": "value"},
            schema_name="test_schema",
            tenant_id="tenant_1"
        )
        context_id = create_result.unwrap()
        
        # Get context
        get_result = await context_service.get(context_id)
        
        assert get_result.is_ok()
        context = get_result.unwrap()
        assert context.id == context_id
        assert context.data["key"] == "value"
    
    async def test_get_nonexistent_context(self, context_service):
        """Test getting non-existent context"""
        result = await context_service.get("nonexistent")
        
        assert result.is_err()
    
    async def test_update_context(self, context_service):
        """Test updating a context"""
        # Create context
        create_result = await context_service.create(
            data={"key": "value"},
            schema_name="test_schema",
            tenant_id="tenant_1"
        )
        context_id = create_result.unwrap()
        
        # Update context
        update_result = await context_service.update(
            context_id=context_id,
            data_updates={"new_key": "new_value"}
        )
        
        assert update_result.is_ok()
        updated = update_result.unwrap()
        assert updated.data["key"] == "value"
        assert updated.data["new_key"] == "new_value"
    
    async def test_delete_context(self, context_service):
        """Test deleting a context"""
        # Create context
        create_result = await context_service.create(
            data={"key": "value"},
            schema_name="test_schema",
            tenant_id="tenant_1"
        )
        context_id = create_result.unwrap()
        
        # Delete context
        delete_result = await context_service.delete(context_id)
        
        assert delete_result.is_ok()
        assert delete_result.unwrap() is True
        
        # Verify deleted
        get_result = await context_service.get(context_id)
        assert get_result.is_err()
    
    async def test_search_contexts(self, context_service):
        """Test searching for contexts"""
        # Create multiple contexts
        await context_service.create(
            data={"type": "user", "name": "Alice"},
            schema_name="test_schema",
            tenant_id="tenant_1"
        )
        await context_service.create(
            data={"type": "user", "name": "Bob"},
            schema_name="test_schema",
            tenant_id="tenant_1"
        )
        await context_service.create(
            data={"type": "admin", "name": "Charlie"},
            schema_name="test_schema",
            tenant_id="tenant_1"
        )
        
        # Search for user type
        results = []
        async for ctx in context_service.search(
            query={"type": "user"},
            tenant_id="tenant_1",
            limit=10
        ):
            results.append(ctx)
        
        assert len(results) == 2
        assert all(ctx.data["type"] == "user" for ctx in results)
    
    async def test_event_notification(self, context_service):
        """Test that events are emitted"""
        events = []
        
        async def event_handler(event: ContextEvent):
            events.append(event)
        
        # Subscribe to events
        context_service.observable.subscribe(event_handler)
        
        # Create context
        await context_service.create(
            data={"key": "value"},
            schema_name="test_schema",
            tenant_id="tenant_1"
        )
        
        # Check event was emitted
        assert len(events) == 1
        assert events[0].event_type == "context.created"
