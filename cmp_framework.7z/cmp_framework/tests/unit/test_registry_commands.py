
import pytest
from typer.testing import CliRunner
from unittest.mock import patch, MagicMock, AsyncMock
import json
from pathlib import Path

from cmp.cli.registry_commands import registry_app
from cmp.core.result import Ok, Err
from cmp.registries.schema_registry import SchemaInfo
from cmp.registries.policy_registry import PolicyInfo

runner = CliRunner()

@pytest.fixture
def mock_backend():
    """Fixture for a mock registry backend."""
    return AsyncMock()

@pytest.fixture
def mock_schema_registry(mock_backend):
    """Fixture for a mock SchemaRegistry."""
    with patch('cmp.cli.registry_commands.SchemaRegistry') as mock:
        registry_instance = mock.return_value
        registry_instance.register_schema = AsyncMock()
        registry_instance.list_schemas = AsyncMock()
        registry_instance.validate_data = AsyncMock()
        registry_instance.close = AsyncMock()
        yield registry_instance

@pytest.fixture
def mock_policy_registry(mock_backend):
    """Fixture for a mock PolicyRegistry."""
    with patch('cmp.cli.registry_commands.PolicyRegistry') as mock:
        registry_instance = mock.return_value
        registry_instance.register_policy = AsyncMock()
        registry_instance.list_policies = AsyncMock()
        registry_instance.close = AsyncMock()
        yield registry_instance

@pytest.fixture(autouse=True)
def mock_create_backend(mock_backend):
    """Auto-used fixture to mock create_backend."""
    with patch('cmp.cli.registry_commands.create_backend', return_value=mock_backend) as mock:
        yield mock


class TestSchemaCommands:
    """Tests for the schema registry commands."""

    def test_register_schema_success(self, mock_schema_registry, tmp_path):
        """Test successful schema registration."""
        schema_file = tmp_path / "schema.json"
        schema_file.write_text('{"type": "object"}')
        mock_schema_registry.register_schema.return_value = Ok(True)

        result = runner.invoke(registry_app, [
            "schema", "register",
            "--file", str(schema_file),
            "--id", "test-schema",
            "--version", "1.0",
        ])

        assert result.exit_code == 0
        assert "Schema registered: test-schema v1.0" in result.stdout
        mock_schema_registry.register_schema.assert_called_once()

    def test_register_schema_file_not_found(self, mock_schema_registry):
        """Test schema registration with a non-existent file."""
        result = runner.invoke(registry_app, [
            "schema", "register",
            "--file", "nonexistent.json",
            "--id", "test-schema",
            "--version", "1.0",
        ])

        assert result.exit_code == 1
        assert "Schema file not found" in result.stdout

    def test_register_schema_failure(self, mock_schema_registry, tmp_path):
        """Test schema registration that fails at the backend."""
        schema_file = tmp_path / "schema.json"
        schema_file.write_text('{"type": "object"}')
        mock_schema_registry.register_schema.return_value = Err("Already exists")

        result = runner.invoke(registry_app, [
            "schema", "register",
            "--file", str(schema_file),
            "--id", "test-schema",
            "--version", "1.0",
        ])

        assert result.exit_code == 1
        assert "Failed to register schema: Already exists" in result.stdout

    def test_list_schemas_success(self, mock_schema_registry):
        """Test listing schemas successfully."""
        schemas = [
            SchemaInfo(schema_id="s1", version="1.0", description="desc1", created_at="2023-01-01T00:00:00Z", deprecated=False),
            SchemaInfo(schema_id="s2", version="2.0", description="desc2", created_at="2023-01-01T00:00:00Z", deprecated=True),
        ]
        mock_schema_registry.list_schemas.return_value = Ok(schemas)
        
        result = runner.invoke(registry_app, ["schema", "list"])

        assert result.exit_code == 0
        assert "s1" in result.stdout
        assert "s2" in result.stdout
        assert "desc1" in result.stdout
        assert "Yes" in result.stdout # for deprecated

    def test_list_schemas_empty(self, mock_schema_registry):
        """Test listing schemas when none are registered."""
        mock_schema_registry.list_schemas.return_value = Ok([])
        
        result = runner.invoke(registry_app, ["schema", "list"])

        assert result.exit_code == 0
        assert "No schemas registered" in result.stdout

    def test_list_schemas_failure(self, mock_schema_registry):
        """Test schema listing that fails at the backend."""
        mock_schema_registry.list_schemas.return_value = Err("Backend error")
        
        result = runner.invoke(registry_app, ["schema", "list"])

        assert result.exit_code == 1
        assert "Failed to list schemas" in result.stdout

    def test_validate_data_success(self, mock_schema_registry, tmp_path):
        """Test successful data validation."""
        data_file = tmp_path / "data.json"
        data_file.write_text('{"key": "value"}')
        mock_schema_registry.validate_data.return_value = Ok(True)

        result = runner.invoke(registry_app, [
            "schema", "validate",
            "--schema", "test-schema",
            "--data", str(data_file),
        ])

        assert result.exit_code == 0
        assert "Data is valid for schema: test-schema" in result.stdout

    def test_validate_data_file_not_found(self, mock_schema_registry):
        """Test data validation with a non-existent data file."""
        result = runner.invoke(registry_app, [
            "schema", "validate",
            "--schema", "test-schema",
            "--data", "nonexistent.json",
        ])

        assert result.exit_code == 1
        assert "Data file not found" in result.stdout

    def test_validate_data_failure(self, mock_schema_registry, tmp_path):
        """Test data validation that fails."""
        data_file = tmp_path / "data.json"
        data_file.write_text('{}')
        mock_schema_registry.validate_data.return_value = Err("Invalid data")

        result = runner.invoke(registry_app, [
            "schema", "validate",
            "--schema", "test-schema",
            "--data", str(data_file),
        ])

        assert result.exit_code == 1
        assert "Validation failed: Invalid data" in result.stdout

class TestPolicyCommands:
    """Tests for the policy registry commands."""

    def test_register_policy_success(self, mock_policy_registry, tmp_path):
        """Test successful policy registration."""
        policy_file = tmp_path / "policy.rego"
        policy_file.write_text("package main")
        mock_policy_registry.register_policy.return_value = Ok(True)

        result = runner.invoke(registry_app, [
            "policy", "register",
            "--file", str(policy_file),
            "--id", "test-policy",
            "--version", "1.0",
        ])

        assert result.exit_code == 0
        assert "Policy registered: test-policy v1.0" in result.stdout

    def test_register_policy_file_not_found(self, mock_policy_registry):
        """Test policy registration with a non-existent file."""
        result = runner.invoke(registry_app, [
            "policy", "register",
            "--file", "nonexistent.rego",
            "--id", "test-policy",
            "--version", "1.0",
        ])

        assert result.exit_code == 1
        assert "Policy file not found" in result.stdout

    def test_register_policy_failure(self, mock_policy_registry, tmp_path):
        """Test policy registration that fails at the backend."""
        policy_file = tmp_path / "policy.rego"
        policy_file.write_text("package main")
        mock_policy_registry.register_policy.return_value = Err("Already exists")

        result = runner.invoke(registry_app, [
            "policy", "register",
            "--file", str(policy_file),
            "--id", "test-policy",
            "--version", "1.0",
        ])

        assert result.exit_code == 1
        assert "Failed to register policy: Already exists" in result.stdout

    def test_list_policies_success(self, mock_policy_registry):
        """Test listing policies successfully."""
        policies = [
            PolicyInfo(policy_id="p1", version="1.0", description="desc1", created_at="2023-01-01T00:00:00Z", deployed=True),
            PolicyInfo(policy_id="p2", version="2.0", description="desc2", created_at="2023-01-01T00:00:00Z", deployed=False),
        ]
        mock_policy_registry.list_policies.return_value = Ok(policies)
        
        result = runner.invoke(registry_app, ["policy", "list"])

        assert result.exit_code == 0
        assert "p1" in result.stdout
        assert "p2" in result.stdout
        assert "desc1" in result.stdout
        assert "Yes" in result.stdout # for deployed

    def test_list_policies_empty(self, mock_policy_registry):
        """Test listing policies when none are registered."""
        mock_policy_registry.list_policies.return_value = Ok([])
        
        result = runner.invoke(registry_app, ["policy", "list"])

        assert result.exit_code == 0
        assert "No policies registered" in result.stdout

    def test_list_policies_failure(self, mock_policy_registry):
        """Test policy listing that fails at the backend."""
        mock_policy_registry.list_policies.return_value = Err("Backend error")
        
        result = runner.invoke(registry_app, ["policy", "list"])

        assert result.exit_code == 1
        assert "Failed to list policies" in result.stdout
