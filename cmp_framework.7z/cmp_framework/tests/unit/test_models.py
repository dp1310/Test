"""
Unit tests for core models.
"""

import pytest
from datetime import datetime
from cmp.core.models import (
    Context,
    ContextEnvelope,
    Provenance,
    ProvenanceStep,
    Metadata,
    Schema,
    Policy,
    ContextEvent,
    LifecycleState,
    ValidationStatus
)


class TestContext:
    """Tests for Context model"""
    
    def test_context_creation(self):
        """Test creating a context"""
        ctx = Context(
            id="ctx_123",
            data={"key": "value"},
            tenant_id="tenant_1",
            created_at=datetime.utcnow()
        )
        
        assert ctx.id == "ctx_123"
        assert ctx.data["key"] == "value"
        assert ctx.tenant_id == "tenant_1"
    
    def test_context_immutability(self):
        """Test that context is immutable"""
        ctx = Context(
            id="ctx_123",
            data={"key": "value"},
            tenant_id="tenant_1"
        )
        
        # Should not be able to modify
        with pytest.raises(Exception):
            ctx.id = "new_id"  # type: ignore
    
    def test_context_with_data(self):
        """Test updating context data (creates new instance)"""
        ctx = Context(
            id="ctx_123",
            data={"key": "value"},
            tenant_id="tenant_1"
        )
        
        updated = ctx.with_data(new_key="new_value")
        
        # Original unchanged
        assert "new_key" not in ctx.data
        
        # New instance has both
        assert updated.data["key"] == "value"
        assert updated.data["new_key"] == "new_value"
        assert updated.id == ctx.id


class TestProvenance:
    """Tests for Provenance model"""
    
    def test_empty_provenance(self):
        """Test creating empty provenance"""
        prov = Provenance.empty()
        assert len(prov.steps) == 0
    
    def test_add_step(self):
        """Test adding provenance steps"""
        prov = Provenance.empty()
        
        prov2 = prov.add_step(
            source="agent_1",
            agent_id="a1",
            timestamp=datetime.utcnow()
        )
        
        # Original unchanged
        assert len(prov.steps) == 0
        
        # New instance has step
        assert len(prov2.steps) == 1
        assert prov2.steps[0].source == "agent_1"
    
    def test_provenance_chain(self):
        """Test building provenance chain"""
        prov = (
            Provenance.empty()
            .add_step("agent_1", "a1", datetime.utcnow())
            .add_step("agent_2", "a2", datetime.utcnow())
            .add_step("agent_3", "a3", datetime.utcnow())
        )
        
        assert len(prov.steps) == 3
        assert prov.steps[0].source == "agent_1"
        assert prov.steps[1].source == "agent_2"
        assert prov.steps[2].source == "agent_3"


class TestMetadata:
    """Tests for Metadata model"""
    
    def test_metadata_creation(self):
        """Test creating metadata"""
        meta = Metadata(tenant_id="tenant_1")
        
        assert meta.tenant_id == "tenant_1"
        assert meta.version == 1
        assert len(meta.tags) == 0
    
    def test_add_tag(self):
        """Test adding tags"""
        meta = Metadata(tenant_id="tenant_1")
        
        meta2 = meta.add_tag("important")
        meta3 = meta2.add_tag("processed")
        
        # Original unchanged
        assert len(meta.tags) == 0
        
        # New instances have tags
        assert "important" in meta2.tags
        assert "important" in meta3.tags
        assert "processed" in meta3.tags
    
    def test_update_metadata(self):
        """Test updating metadata"""
        meta = Metadata(tenant_id="tenant_1")
        
        updated = meta.update(version=2, custom={"key": "value"})
        
        assert meta.version == 1
        assert updated.version == 2


@pytest.mark.asyncio
class TestSchema:
    """Tests for Schema model"""
    
    async def test_schema_validation(self):
        """Test schema validation"""
        schema = Schema(
            name="test_schema",
            version="1.0",
            fields={"name": "string", "age": "int"},
            required_fields=("name",)
        )
        
        # Valid data
        valid = await schema.validate({"name": "John", "age": 30})
        assert valid is True
        
        # Missing required field
        with pytest.raises(ValueError):
            await schema.validate({"age": 30})


class TestContextEvent:
    """Tests for ContextEvent model"""
    
    def test_event_creation(self):
        """Test creating context event"""
        event = ContextEvent(
            event_type="context.created",
            context_id="ctx_123",
            tenant_id="tenant_1",
            payload={"key": "value"}
        )
        
        assert event.event_type == "context.created"
        assert event.context_id == "ctx_123"
        assert event.payload["key"] == "value"
    
    def test_event_to_dict(self):
        """Test converting event to dict"""
        event = ContextEvent(
            event_type="context.created",
            context_id="ctx_123",
            tenant_id="tenant_1"
        )
        
        data = event.to_dict()
        
        assert data["event_type"] == "context.created"
        assert data["context_id"] == "ctx_123"
        assert "timestamp" in data
