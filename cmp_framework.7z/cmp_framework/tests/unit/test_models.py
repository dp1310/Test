
import pytest
from datetime import datetime, timezone
from cmp.core.models import (
    Context, ContextEnvelope, Schema, Policy, Provenance, 
    Metadata, ValidationStatus, LifecycleState, ProvenanceStep
)

def test_context_model():
    # Test creation
    ctx = Context(id="test-1", data={"key": "val"}, tenant_id="t1")
    assert ctx.id == "test-1"
    assert ctx.version == 1
    assert ctx.created_at.tzinfo == timezone.utc
    
    # Test with_data
    ctx2 = ctx.with_data(new_key="val2")
    assert ctx2.id == ctx.id
    assert ctx2.version == 1 # Version doesn't increment in model automatically, controlled by service potentially or stays same for just data update structure
    assert "new_key" in ctx2.data
    assert "key" in ctx2.data
    
    # Test to_dict
    d = ctx2.to_dict()
    assert d["id"] == "test-1"
    assert d["data"]["new_key"] == "val2"

def test_context_envelope():
    meta = Metadata.default()
    # Need to set tenant_id for default metadata?
    # Metadata definition: tenant_id: str
    # default() creates one with EMPTY tenant_id if not patched?
    # Let's check Metadata.default() impl.
    # It seems it needs tenant_id passed or sets default. 
    # Metadata definition: tenant_id: str. No default.
    # def default(): return Metadata(tenant_id="default") (Hypothetically)
    
    meta = Metadata(tenant_id="t1")
    
    env = ContextEnvelope(
        id="env-1",
        data={"k": "v"},
        schema=Schema(name="s1", version="1.0", fields={}),
        policy=Policy.default(),
        provenance=Provenance.empty(),
        metadata=meta
    )
    
    assert env.validation_status == ValidationStatus.VALID
    assert env.lifecycle_state == LifecycleState.ACTIVE
    
    # Test to_context
    ctx = env.to_context()
    assert ctx.id == "env-1"
    assert ctx.tenant_id == "t1"
    
    # Test to_sage_format
    sage = env.to_sage_format()
    assert sage["id"] == "env-1"
    assert sage["tenant"] == "t1"

def test_provenance():
    p = Provenance.empty()
    assert len(p.steps) == 0
    
    p2 = p.add_step(
        source="system",
        agent_id="agent-1",
        timestamp=datetime.now(timezone.utc),
        operation="create"
    )
    assert len(p2.steps) == 1
    assert p2.steps[0].operation == "create"
    
    l = p2.to_list()
    assert len(l) == 1
    assert l[0]["agent_id"] == "agent-1"
    
    p3 = Provenance.from_list(l)
    assert len(p3.steps) == 1

def test_metadata():
    m = Metadata(tenant_id="t1")
    m2 = m.add_tag("tag1")
    assert "tag1" in m2.tags
    
    m3 = m2.update(custom={"owner": "user1"})
    assert m3.custom["owner"] == "user1"
    assert "tag1" in m3.tags
    
    d = m3.to_dict()
    assert d["tenant_id"] == "t1"
    
    m4 = Metadata.from_dict(d)
    assert m4.tenant_id == "t1"
