
import pytest
import asyncio
from cmp.core.models import Context
from cmp.orchestration.patterns.retry import RetryPolicy, CircuitBreaker, CircuitState
from cmp.orchestration.patterns.conditional import ConditionalWorkflow, SwitchWorkflow
from cmp.orchestration.patterns.saga import SagaWorkflow, SagaStep
from cmp.sdk.agent import Agent

import inspect

class MockAgent(Agent):
    def __init__(self, name, func=None):
        super().__init__(name)
        self.func = func
        self.call_count = 0
        
    async def process(self, context: Context) -> Context:
        self.call_count += 1
        if self.func:
            result = self.func(context)
            if inspect.isawaitable(result):
                return await result
            return result
        return context

@pytest.mark.asyncio
async def test_retry_policy_success():
    policy = RetryPolicy(max_attempts=3, base_delay=0.01)
    ctx = Context(id="test", data={"count": 0}, tenant_id="t1")
    
    async def successful_func(c: Context) -> Context:
        return c.with_data(count=c.data["count"] + 1)
        
    result = await policy.execute(successful_func, ctx)
    assert result.data["count"] == 1

@pytest.mark.asyncio
async def test_retry_policy_failure_then_success():
    policy = RetryPolicy(max_attempts=3, base_delay=0.01)
    ctx = Context(id="test", data={"attempts": 0}, tenant_id="t1")
    
    async def failing_func(c: Context) -> Context:
        # Note: Context is immutable, but we are using data which is a Mapping.
        # However, the test uses ctx.with_data to create new versions.
        # For tracking attempts across retries in this test, we'll use a local counter.
        pass
    
    attempts = 0
    async def failing_logic(c: Context) -> Context:
        nonlocal attempts
        attempts += 1
        if attempts < 2:
            raise ValueError("First attempt fails")
        return c.with_data(attempts=attempts)
        
    result = await policy.execute(failing_logic, ctx)
    assert result.data["attempts"] == 2

@pytest.mark.asyncio
async def test_circuit_breaker():
    breaker = CircuitBreaker(failure_threshold=2, timeout=0.1)
    ctx = Context(id="test", data={}, tenant_id="t1")
    
    async def failing(c: Context) -> Context:
        raise ValueError("Fail")
        
    # First failure
    with pytest.raises(ValueError):
        await breaker.call(failing, ctx)
    assert breaker.state == CircuitState.CLOSED
    
    # Second failure - should open
    with pytest.raises(ValueError):
        await breaker.call(failing, ctx)
    assert breaker.state == CircuitState.OPEN
    
    # Try calling while open
    with pytest.raises(Exception, match="Circuit breaker is OPEN"):
        await breaker.call(failing, ctx)
        
    # Wait for timeout
    await asyncio.sleep(0.15)
    
    # Should be half-open on next call
    async def success(c: Context) -> Context:
        return c
        
    # This call should succeed and close the breaker
    await breaker.call(success, ctx)
    assert breaker.state == CircuitState.CLOSED

@pytest.mark.asyncio
async def test_conditional_workflow():
    ctx = Context(id="test", data={"value": 10}, tenant_id="t1")
    
    agent_hit = MockAgent("hit", lambda c: c.with_data(res="hit"))
    agent_miss = MockAgent("miss", lambda c: c.with_data(res="miss"))
        
    workflow = ConditionalWorkflow()
    workflow.when(lambda c: c.data["value"] > 5).then(agent_hit).otherwise(agent_miss)
    
    res = await workflow.execute(ctx)
    assert res.data["res"] == "hit"
    
    ctx_low = Context(id="test", data={"value": 2}, tenant_id="t1")
    res_low = await workflow.execute(ctx_low)
    assert res_low.data["res"] == "miss"

@pytest.mark.asyncio
async def test_saga_workflow():
    ctx = Context(id="test", data={"balance": 100}, tenant_id="t1")
    
    async def forward(c: Context) -> Context:
        return c.with_data(balance=c.data["balance"] - 50)
        
    async def compensate(c: Context) -> Context:
        return c.with_data(balance=c.data["balance"] + 50)
        
    saga = SagaWorkflow()
    saga.step(forward, compensate, name="payment")
    
    # Test successful saga
    res_ok = await saga.execute(ctx)
    assert res_ok.is_ok()
    assert res_ok.unwrap().data["balance"] == 50
    
    # Test failed saga with compensation
    async def failing_action(c: Context) -> Context:
        raise ValueError("Oops")
        
    comp_called = False
    async def compensating_spy(c: Context) -> Context:
        nonlocal comp_called
        comp_called = True
        return c.with_data(balance=c.data["balance"] + 50)
        
    saga2 = SagaWorkflow()
    saga2.step(forward, compensating_spy, name="step1")
    saga2.step(failing_action, name="step2")
    
    res_err = await saga2.execute(ctx)
    assert res_err.is_err()
    assert comp_called is True
    assert "Saga failed at step 'step2'" in res_err.unwrap_err()
