"""Tests for agent registry."""

import pytest
from unittest.mock import MagicMock

from cmp.registries.agent_registry import AgentRegistry, AgentMetadata
from cmp.sdk.agent import Agent


class MockAgent(Agent):
    """Mock agent for testing."""
    
    def __init__(self, agent_id: str):
        self.agent_id = agent_id
    
    async def process(self, context):
        """Mock process method."""
        return context


class TestAgentMetadata:
    """Test AgentMetadata class."""
    
    def test_agent_metadata_creation(self):
        """Test creating agent metadata."""
        metadata = AgentMetadata(
            agent_id="test-agent",
            agent_type="MockAgent",
            capabilities=["read", "write"],
            tenant_id="tenant-1"
        )
        
        assert metadata.agent_id == "test-agent"
        assert metadata.agent_type == "MockAgent"
        assert metadata.capabilities == ["read", "write"]
        assert metadata.tenant_id == "tenant-1"
    
    def test_agent_metadata_empty_capabilities(self):
        """Test creating agent metadata with empty capabilities."""
        metadata = AgentMetadata(
            agent_id="test-agent",
            agent_type="MockAgent",
            capabilities=[],
            tenant_id="tenant-1"
        )
        
        assert metadata.capabilities == []


class TestAgentRegistry:
    """Test AgentRegistry class."""
    
    @pytest.fixture
    def registry(self):
        """Create agent registry for testing."""
        return AgentRegistry()
    
    @pytest.fixture
    def mock_agent(self):
        """Create mock agent for testing."""
        return MockAgent("test-agent-1")
    
    @pytest.mark.asyncio
    async def test_register_agent(self, registry, mock_agent):
        """Test registering an agent."""
        tenant_id = "tenant-1"
        capabilities = ["read", "write", "execute"]
        
        await registry.register(mock_agent, tenant_id, capabilities)
        
        # Verify agent is registered
        metadata = await registry.get(mock_agent.agent_id, tenant_id)
        assert metadata is not None
        assert metadata.agent_id == mock_agent.agent_id
        assert metadata.agent_type == "MockAgent"
        assert metadata.capabilities == capabilities
        assert metadata.tenant_id == tenant_id
    
    @pytest.mark.asyncio
    async def test_register_agent_no_capabilities(self, registry, mock_agent):
        """Test registering an agent without capabilities."""
        tenant_id = "tenant-1"
        
        await registry.register(mock_agent, tenant_id)
        
        # Verify agent is registered with empty capabilities
        metadata = await registry.get(mock_agent.agent_id, tenant_id)
        assert metadata is not None
        assert metadata.capabilities == []
    
    @pytest.mark.asyncio
    async def test_register_multiple_agents_same_tenant(self, registry):
        """Test registering multiple agents for the same tenant."""
        tenant_id = "tenant-1"
        agent1 = MockAgent("agent-1")
        agent2 = MockAgent("agent-2")
        
        await registry.register(agent1, tenant_id, ["read"])
        await registry.register(agent2, tenant_id, ["write"])
        
        # Verify both agents are registered
        metadata1 = await registry.get(agent1.agent_id, tenant_id)
        metadata2 = await registry.get(agent2.agent_id, tenant_id)
        
        assert metadata1 is not None
        assert metadata2 is not None
        assert metadata1.agent_id == "agent-1"
        assert metadata2.agent_id == "agent-2"
    
    @pytest.mark.asyncio
    async def test_register_agents_different_tenants(self, registry):
        """Test registering agents for different tenants."""
        agent1 = MockAgent("agent-1")
        agent2 = MockAgent("agent-2")
        
        await registry.register(agent1, "tenant-1", ["read"])
        await registry.register(agent2, "tenant-2", ["write"])
        
        # Verify agents are isolated by tenant
        metadata1 = await registry.get(agent1.agent_id, "tenant-1")
        metadata2 = await registry.get(agent2.agent_id, "tenant-2")
        
        assert metadata1 is not None
        assert metadata2 is not None
        
        # Cross-tenant access should return None
        assert await registry.get(agent1.agent_id, "tenant-2") is None
        assert await registry.get(agent2.agent_id, "tenant-1") is None
    
    @pytest.mark.asyncio
    async def test_get_nonexistent_agent(self, registry):
        """Test getting a non-existent agent."""
        metadata = await registry.get("nonexistent", "tenant-1")
        assert metadata is None
    
    @pytest.mark.asyncio
    async def test_get_agent_nonexistent_tenant(self, registry, mock_agent):
        """Test getting an agent from a non-existent tenant."""
        await registry.register(mock_agent, "tenant-1")
        
        # Try to get from different tenant
        metadata = await registry.get(mock_agent.agent_id, "tenant-2")
        assert metadata is None
    
    @pytest.mark.asyncio
    async def test_list_agents_empty_tenant(self, registry):
        """Test listing agents for an empty tenant."""
        agents = await registry.list("nonexistent-tenant")
        assert agents == []
    
    @pytest.mark.asyncio
    async def test_list_agents_single_tenant(self, registry):
        """Test listing agents for a single tenant."""
        tenant_id = "tenant-1"
        agent1 = MockAgent("agent-1")
        agent2 = MockAgent("agent-2")
        
        await registry.register(agent1, tenant_id, ["read"])
        await registry.register(agent2, tenant_id, ["write"])
        
        agents = await registry.list(tenant_id)
        assert len(agents) == 2
        
        agent_ids = [agent.agent_id for agent in agents]
        assert "agent-1" in agent_ids
        assert "agent-2" in agent_ids
    
    @pytest.mark.asyncio
    async def test_list_agents_multiple_tenants(self, registry):
        """Test that listing agents is isolated by tenant."""
        agent1 = MockAgent("agent-1")
        agent2 = MockAgent("agent-2")
        agent3 = MockAgent("agent-3")
        
        await registry.register(agent1, "tenant-1", ["read"])
        await registry.register(agent2, "tenant-1", ["write"])
        await registry.register(agent3, "tenant-2", ["execute"])
        
        # List agents for tenant-1
        agents_t1 = await registry.list("tenant-1")
        assert len(agents_t1) == 2
        agent_ids_t1 = [agent.agent_id for agent in agents_t1]
        assert "agent-1" in agent_ids_t1
        assert "agent-2" in agent_ids_t1
        assert "agent-3" not in agent_ids_t1
        
        # List agents for tenant-2
        agents_t2 = await registry.list("tenant-2")
        assert len(agents_t2) == 1
        assert agents_t2[0].agent_id == "agent-3"
    
    @pytest.mark.asyncio
    async def test_unregister_agent(self, registry, mock_agent):
        """Test unregistering an agent."""
        tenant_id = "tenant-1"
        
        # Register agent
        await registry.register(mock_agent, tenant_id, ["read"])
        
        # Verify agent exists
        metadata = await registry.get(mock_agent.agent_id, tenant_id)
        assert metadata is not None
        
        # Unregister agent
        result = await registry.unregister(mock_agent.agent_id, tenant_id)
        assert result is True
        
        # Verify agent is gone
        metadata = await registry.get(mock_agent.agent_id, tenant_id)
        assert metadata is None
    
    @pytest.mark.asyncio
    async def test_unregister_nonexistent_agent(self, registry):
        """Test unregistering a non-existent agent."""
        result = await registry.unregister("nonexistent", "tenant-1")
        assert result is False
    
    @pytest.mark.asyncio
    async def test_unregister_agent_wrong_tenant(self, registry, mock_agent):
        """Test unregistering an agent from the wrong tenant."""
        # Register agent in tenant-1
        await registry.register(mock_agent, "tenant-1", ["read"])
        
        # Try to unregister from tenant-2
        result = await registry.unregister(mock_agent.agent_id, "tenant-2")
        assert result is False
        
        # Verify agent still exists in tenant-1
        metadata = await registry.get(mock_agent.agent_id, "tenant-1")
        assert metadata is not None
    
    @pytest.mark.asyncio
    async def test_concurrent_operations(self, registry):
        """Test concurrent registry operations."""
        import asyncio
        
        async def register_agent(agent_id, tenant_id):
            agent = MockAgent(agent_id)
            await registry.register(agent, tenant_id, ["test"])
        
        # Register multiple agents concurrently
        tasks = [
            register_agent(f"agent-{i}", "tenant-1")
            for i in range(10)
        ]
        await asyncio.gather(*tasks)
        
        # Verify all agents are registered
        agents = await registry.list("tenant-1")
        assert len(agents) == 10
        
        agent_ids = [agent.agent_id for agent in agents]
        for i in range(10):
            assert f"agent-{i}" in agent_ids
    
    @pytest.mark.asyncio
    async def test_agent_type_detection(self, registry):
        """Test that agent type is correctly detected."""
        class CustomAgent(Agent):
            def __init__(self, agent_id):
                self.agent_id = agent_id
            
            async def process(self, context):
                return context
        
        custom_agent = CustomAgent("custom-agent")
        await registry.register(custom_agent, "tenant-1")
        
        metadata = await registry.get("custom-agent", "tenant-1")
        assert metadata is not None
        assert metadata.agent_type == "CustomAgent"
    
    @pytest.mark.asyncio
    async def test_registry_isolation(self, registry):
        """Test that registry properly isolates tenants."""
        # Create two registries to ensure they don't interfere
        registry2 = AgentRegistry()
        
        agent1 = MockAgent("agent-1")
        agent2 = MockAgent("agent-2")
        
        await registry.register(agent1, "tenant-1")
        await registry2.register(agent2, "tenant-1")
        
        # Each registry should only see its own agents
        agents_r1 = await registry.list("tenant-1")
        agents_r2 = await registry2.list("tenant-1")
        
        assert len(agents_r1) == 1
        assert len(agents_r2) == 1
        assert agents_r1[0].agent_id == "agent-1"
        assert agents_r2[0].agent_id == "agent-2"
    
    @pytest.mark.asyncio
    async def test_overwrite_agent_registration(self, registry):
        """Test that re-registering an agent overwrites the previous registration."""
        agent = MockAgent("test-agent")
        tenant_id = "tenant-1"
        
        # Register with initial capabilities
        await registry.register(agent, tenant_id, ["read"])
        
        metadata = await registry.get(agent.agent_id, tenant_id)
        assert metadata.capabilities == ["read"]
        
        # Re-register with different capabilities
        await registry.register(agent, tenant_id, ["read", "write", "execute"])
        
        metadata = await registry.get(agent.agent_id, tenant_id)
        assert metadata.capabilities == ["read", "write", "execute"]