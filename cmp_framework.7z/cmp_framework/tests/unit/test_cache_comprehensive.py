"""Comprehensive tests for cache module."""

import pytest
import asyncio
import json
from unittest.mock import Mock, AsyncMock, patch, MagicMock

from cmp.core.cache import (
    InMemoryCache, RedisCache, CacheManager, 
    get_cache, set_cache, CacheBackend
)


class TestInMemoryCache:
    """Test InMemoryCache implementation."""
    
    @pytest.fixture
    async def cache(self):
        """Create in-memory cache for testing."""
        cache = InMemoryCache(maxsize=100, ttl=300)
        yield cache
        await cache.clear()
    
    @pytest.mark.asyncio
    async def test_set_and_get(self, cache):
        """Test basic set and get operations."""
        await cache.set("key1", "value1")
        value = await cache.get("key1")
        assert value == "value1"
        assert cache.sets == 1
        assert cache.hits == 1
    
    @pytest.mark.asyncio
    async def test_get_nonexistent_key(self, cache):
        """Test getting non-existent key."""
        value = await cache.get("nonexistent")
        assert value is None
        assert cache.misses == 1
    
    @pytest.mark.asyncio
    async def test_delete_key(self, cache):
        """Test deleting keys."""
        await cache.set("key1", "value1")
        await cache.delete("key1")
        
        value = await cache.get("key1")
        assert value is None
        assert cache.deletes == 1
    
    @pytest.mark.asyncio
    async def test_delete_nonexistent_key(self, cache):
        """Test deleting non-existent key."""
        await cache.delete("nonexistent")
        assert cache.deletes == 1
    
    @pytest.mark.asyncio
    async def test_exists(self, cache):
        """Test checking key existence."""
        assert await cache.exists("key1") is False
        
        await cache.set("key1", "value1")
        assert await cache.exists("key1") is True
        
        await cache.delete("key1")
        assert await cache.exists("key1") is False
    
    @pytest.mark.asyncio
    async def test_clear(self, cache):
        """Test clearing all cache entries."""
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        
        await cache.clear()
        
        assert await cache.get("key1") is None
        assert await cache.get("key2") is None
    
    @pytest.mark.asyncio
    async def test_complex_data_types(self, cache):
        """Test caching complex data types."""
        data = {
            "string": "value",
            "number": 42,
            "list": [1, 2, 3],
            "nested": {"key": "value"}
        }
        
        await cache.set("complex", data)
        retrieved = await cache.get("complex")
        
        assert retrieved == data
        assert retrieved["nested"]["key"] == "value"
    
    @pytest.mark.asyncio
    async def test_statistics(self, cache):
        """Test cache statistics."""
        # Initial stats
        stats = cache.get_stats()
        assert stats["hits"] == 0
        assert stats["misses"] == 0
        assert stats["sets"] == 0
        assert stats["deletes"] == 0
        assert stats["hit_rate"] == 0
        
        # Perform operations
        await cache.set("key1", "value1")
        await cache.get("key1")  # Hit
        await cache.get("key2")  # Miss
        await cache.delete("key1")
        
        stats = cache.get_stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["sets"] == 1
        assert stats["deletes"] == 1
        assert stats["hit_rate"] == 50.0  # 1 hit out of 2 requests
        assert stats["backend"] == "in-memory"
    
    @pytest.mark.asyncio
    async def test_concurrent_access(self, cache):
        """Test concurrent cache access."""
        async def set_value(key, value):
            await cache.set(key, value)
        
        async def get_value(key):
            return await cache.get(key)
        
        # Set values concurrently
        await asyncio.gather(
            set_value("key1", "value1"),
            set_value("key2", "value2"),
            set_value("key3", "value3")
        )
        
        # Get values concurrently
        results = await asyncio.gather(
            get_value("key1"),
            get_value("key2"),
            get_value("key3")
        )
        
        assert results == ["value1", "value2", "value3"]
    
    @pytest.mark.asyncio
    async def test_ttl_parameter_ignored(self, cache):
        """Test that TTL parameter is accepted but handled by TTLCache."""
        await cache.set("key1", "value1", ttl=60)
        value = await cache.get("key1")
        assert value == "value1"
    
    def test_cache_initialization(self):
        """Test cache initialization parameters."""
        cache = InMemoryCache(maxsize=500, ttl=600)
        assert cache.cache.maxsize == 500
        assert cache.default_ttl == 600
        
        stats = cache.get_stats()
        assert stats["maxsize"] == 500


class TestRedisCache:
    """Test RedisCache implementation."""
    
    @pytest.fixture
    def mock_redis(self):
        """Mock Redis client."""
        mock_redis = AsyncMock()
        mock_redis.get.return_value = None
        mock_redis.setex.return_value = None
        mock_redis.delete.return_value = None
        mock_redis.flushdb.return_value = None
        mock_redis.exists.return_value = 0
        mock_redis.close.return_value = None
        return mock_redis
    
    @pytest.fixture
    async def cache(self, mock_redis):
        """Create Redis cache with mocked Redis."""
        with patch('redis.asyncio.from_url') as mock_from_url:
            mock_from_url.return_value = mock_redis
            cache = RedisCache(redis_url="redis://localhost:6379", ttl=300)
            # Set the redis instance directly to avoid the async from_url call
            cache._redis = mock_redis
            yield cache
            await cache.close()
    
    @pytest.mark.asyncio
    async def test_redis_import_error(self):
        """Test Redis cache when redis package is not available."""
        with patch.dict('sys.modules', {'redis.asyncio': None}):
            with patch('builtins.__import__', side_effect=ImportError("No module named 'redis'")):
                cache = RedisCache()
                
                with pytest.raises(ImportError, match="redis package required"):
                    await cache.get("key")
    
    @pytest.mark.asyncio
    async def test_set_and_get(self, cache, mock_redis):
        """Test basic set and get operations."""
        # Mock successful get
        mock_redis.get.return_value = json.dumps("value1")
        
        await cache.set("key1", "value1")
        value = await cache.get("key1")
        
        assert value == "value1"
        mock_redis.setex.assert_called_once_with("key1", 300, json.dumps("value1"))
        mock_redis.get.assert_called_once_with("key1")
        assert cache.sets == 1
        assert cache.hits == 1
    
    @pytest.mark.asyncio
    async def test_get_nonexistent_key(self, cache, mock_redis):
        """Test getting non-existent key."""
        mock_redis.get.return_value = None
        
        value = await cache.get("nonexistent")
        assert value is None
        assert cache.misses == 1
    
    @pytest.mark.asyncio
    async def test_delete_key(self, cache, mock_redis):
        """Test deleting keys."""
        await cache.delete("key1")
        
        mock_redis.delete.assert_called_once_with("key1")
        assert cache.deletes == 1
    
    @pytest.mark.asyncio
    async def test_clear(self, cache, mock_redis):
        """Test clearing all cache entries."""
        await cache.clear()
        mock_redis.flushdb.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_exists(self, cache, mock_redis):
        """Test checking key existence."""
        mock_redis.exists.return_value = 1
        
        exists = await cache.exists("key1")
        assert exists is True
        mock_redis.exists.assert_called_once_with("key1")
        
        # Test non-existent key
        mock_redis.exists.return_value = 0
        exists = await cache.exists("key2")
        assert exists is False
    
    @pytest.mark.asyncio
    async def test_set_with_custom_ttl(self, cache, mock_redis):
        """Test setting value with custom TTL."""
        await cache.set("key1", "value1", ttl=600)
        mock_redis.setex.assert_called_once_with("key1", 600, json.dumps("value1"))
    
    @pytest.mark.asyncio
    async def test_complex_data_serialization(self, cache, mock_redis):
        """Test serialization of complex data types."""
        data = {"key": "value", "number": 42, "list": [1, 2, 3]}
        
        await cache.set("complex", data)
        
        # Verify serialization
        expected_json = json.dumps(data)
        mock_redis.setex.assert_called_once_with("complex", 300, expected_json)
        
        # Mock deserialization
        mock_redis.get.return_value = expected_json
        retrieved = await cache.get("complex")
        assert retrieved == data
    
    @pytest.mark.asyncio
    async def test_statistics(self, cache, mock_redis):
        """Test cache statistics."""
        # Initial stats
        stats = cache.get_stats()
        assert stats["backend"] == "redis"
        assert stats["hit_rate"] == 0
        
        # Perform operations
        mock_redis.get.return_value = json.dumps("value1")
        
        await cache.set("key1", "value1")
        await cache.get("key1")  # Hit
        
        # Reset mock for miss
        mock_redis.get.return_value = None
        await cache.get("key2")  # Miss
        
        stats = cache.get_stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["sets"] == 1
        assert stats["hit_rate"] == 50.0
    
    @pytest.mark.asyncio
    async def test_close_connection(self, cache, mock_redis):
        """Test closing Redis connection."""
        await cache.close()
        # The close should be called on the mock redis instance
        assert cache._redis is None or mock_redis.close.called
    
    @pytest.mark.asyncio
    async def test_close_without_connection(self):
        """Test closing when no connection exists."""
        cache = RedisCache()
        await cache.close()  # Should not raise


class TestCacheManager:
    """Test CacheManager implementation."""
    
    @pytest.mark.asyncio
    async def test_memory_backend_creation(self):
        """Test creating cache manager with memory backend."""
        manager = CacheManager(backend="memory", maxsize=500, ttl=600)
        assert manager.backend_type == "memory"
        assert isinstance(manager.backend, InMemoryCache)
        assert manager.backend.cache.maxsize == 500
        assert manager.backend.default_ttl == 600
        await manager.close()
    
    @pytest.mark.asyncio
    async def test_redis_backend_creation(self):
        """Test creating cache manager with Redis backend."""
        manager = CacheManager(
            backend="redis", 
            redis_url="redis://localhost:6379", 
            ttl=300
        )
        assert manager.backend_type == "redis"
        assert isinstance(manager.backend, RedisCache)
        assert manager.backend.redis_url == "redis://localhost:6379"
        assert manager.backend.default_ttl == 300
        await manager.close()
    
    def test_invalid_backend(self):
        """Test creating cache manager with invalid backend."""
        with pytest.raises(ValueError, match="Unknown cache backend: invalid"):
            CacheManager(backend="invalid")
    
    @pytest.mark.asyncio
    async def test_cache_operations_delegation(self):
        """Test that cache operations are properly delegated."""
        manager = CacheManager(backend="memory")
        
        # Test all operations
        await manager.set("key1", "value1")
        value = await manager.get("key1")
        assert value == "value1"
        
        exists = await manager.exists("key1")
        assert exists is True
        
        await manager.delete("key1")
        exists = await manager.exists("key1")
        assert exists is False
        
        await manager.set("key2", "value2")
        await manager.clear()
        exists = await manager.exists("key2")
        assert exists is False
        
        stats = manager.get_stats()
        assert "backend" in stats
        
        await manager.close()
    
    @pytest.mark.asyncio
    async def test_close_with_closeable_backend(self):
        """Test closing manager with closeable backend."""
        with patch('redis.asyncio.from_url', return_value=AsyncMock()):
            manager = CacheManager(backend="redis")
            await manager.close()
    
    @pytest.mark.asyncio
    async def test_close_with_non_closeable_backend(self):
        """Test closing manager with non-closeable backend."""
        manager = CacheManager(backend="memory")
        await manager.close()  # Should not raise


class TestGlobalCache:
    """Test global cache functions."""
    
    def teardown_method(self):
        """Reset global cache after each test."""
        import cmp.core.cache
        cmp.core.cache._global_cache = None
    
    @patch('cmp.config.get_config')
    def test_get_cache_default(self, mock_get_config):
        """Test getting default global cache."""
        # Mock config
        mock_config = Mock()
        mock_config.storage.backend = "memory"
        mock_get_config.return_value = mock_config
        
        cache = get_cache()
        assert isinstance(cache, CacheManager)
        assert cache.backend_type == "memory"
    
    @patch('cmp.config.get_config')
    def test_get_cache_redis_config(self, mock_get_config):
        """Test getting global cache with Redis config."""
        # Mock config
        mock_config = Mock()
        mock_config.storage.backend = "redis"
        mock_get_config.return_value = mock_config
        
        cache = get_cache()
        assert isinstance(cache, CacheManager)
        assert cache.backend_type == "redis"
    
    @patch('cmp.config.get_config')
    def test_get_cache_invalid_config_fallback(self, mock_get_config):
        """Test fallback to memory when config has invalid backend."""
        # Mock config with invalid backend
        mock_config = Mock()
        mock_config.storage.backend = "invalid"
        mock_get_config.return_value = mock_config
        
        cache = get_cache()
        assert isinstance(cache, CacheManager)
        assert cache.backend_type == "memory"
    
    def test_get_cache_singleton(self):
        """Test that get_cache returns the same instance."""
        with patch('cmp.config.get_config') as mock_get_config:
            mock_config = Mock()
            mock_config.storage.backend = "memory"
            mock_get_config.return_value = mock_config
            
            cache1 = get_cache()
            cache2 = get_cache()
            assert cache1 is cache2
    
    def test_set_cache(self):
        """Test setting custom global cache."""
        custom_cache = CacheManager(backend="memory", maxsize=200)
        set_cache(custom_cache)
        
        retrieved_cache = get_cache()
        assert retrieved_cache is custom_cache
        assert retrieved_cache.backend.cache.maxsize == 200


class TestCacheProtocol:
    """Test that cache backends implement the protocol correctly."""
    
    @pytest.mark.asyncio
    async def test_in_memory_cache_protocol(self):
        """Test that InMemoryCache implements CacheBackend protocol."""
        cache = InMemoryCache()
        
        # Test all protocol methods exist and work
        await cache.set("key", "value")
        value = await cache.get("key")
        assert value == "value"
        
        exists = await cache.exists("key")
        assert exists is True
        
        await cache.delete("key")
        exists = await cache.exists("key")
        assert exists is False
        
        await cache.clear()
    
    @pytest.mark.asyncio
    async def test_redis_cache_protocol(self):
        """Test that RedisCache implements CacheBackend protocol."""
        with patch('redis.asyncio.from_url', return_value=AsyncMock()):
            cache = RedisCache()
            
            # Test all protocol methods exist
            assert hasattr(cache, 'get')
            assert hasattr(cache, 'set')
            assert hasattr(cache, 'delete')
            assert hasattr(cache, 'clear')
            assert hasattr(cache, 'exists')
            
            await cache.close()


class TestCacheEdgeCases:
    """Test edge cases and error conditions."""
    
    @pytest.mark.asyncio
    async def test_cache_with_none_values(self):
        """Test caching None values."""
        cache = InMemoryCache()
        
        await cache.set("none_key", None)
        value = await cache.get("none_key")
        assert value is None
        
        # Should still count as a hit
        assert cache.hits == 1
    
    @pytest.mark.asyncio
    async def test_cache_with_empty_strings(self):
        """Test caching empty strings."""
        cache = InMemoryCache()
        
        await cache.set("empty", "")
        value = await cache.get("empty")
        assert value == ""
        assert cache.hits == 1
    
    @pytest.mark.asyncio
    async def test_cache_with_zero_values(self):
        """Test caching zero values."""
        cache = InMemoryCache()
        
        await cache.set("zero", 0)
        value = await cache.get("zero")
        assert value == 0
        assert cache.hits == 1
    
    @pytest.mark.asyncio
    async def test_cache_key_types(self):
        """Test different key types (should all be strings)."""
        cache = InMemoryCache()
        
        # All keys should be strings
        await cache.set("string_key", "value1")
        await cache.set("123", "value2")  # Numeric string
        
        assert await cache.get("string_key") == "value1"
        assert await cache.get("123") == "value2"
    
    @pytest.mark.asyncio
    async def test_large_data_caching(self):
        """Test caching large data structures."""
        cache = InMemoryCache()
        
        # Create large data structure
        large_data = {
            "items": [{"id": i, "data": f"item_{i}"} for i in range(1000)]
        }
        
        await cache.set("large", large_data)
        retrieved = await cache.get("large")
        
        assert len(retrieved["items"]) == 1000
        assert retrieved["items"][0]["id"] == 0
        assert retrieved["items"][999]["data"] == "item_999"
    
    @pytest.mark.asyncio
    async def test_concurrent_same_key_operations(self):
        """Test concurrent operations on the same key."""
        cache = InMemoryCache()
        
        async def set_value(value):
            await cache.set("concurrent_key", value)
        
        async def get_value():
            return await cache.get("concurrent_key")
        
        # Set different values concurrently
        await asyncio.gather(
            set_value("value1"),
            set_value("value2"),
            set_value("value3")
        )
        
        # One of the values should be set
        final_value = await get_value()
        assert final_value in ["value1", "value2", "value3"]
    
    def test_cache_stats_edge_cases(self):
        """Test cache statistics edge cases."""
        cache = InMemoryCache()
        
        # No operations - should not divide by zero
        stats = cache.get_stats()
        assert stats["hit_rate"] == 0
        
        # Only hits
        cache.hits = 5
        cache.misses = 0
        stats = cache.get_stats()
        assert stats["hit_rate"] == 100.0
        
        # Only misses
        cache.hits = 0
        cache.misses = 5
        stats = cache.get_stats()
        assert stats["hit_rate"] == 0.0