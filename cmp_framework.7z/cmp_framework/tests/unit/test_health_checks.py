"""
Tests for health checks.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timezone
import asyncio
import aiohttp

from cmp.monitoring.health_checks import (
    HealthCheck, HealthCheckResult, SystemHealth, HealthStatus,
    CheckError, check_service_url
)


class TestHealthStatus:
    """Test HealthStatus enum"""
    
    def test_health_status_values(self):
        """Test all health status values"""
        assert HealthStatus.HEALTHY == "healthy"
        assert HealthStatus.UNHEALTHY == "unhealthy"
        assert HealthStatus.DEGRADED == "degraded"


class TestHealthCheckResult:
    """Test HealthCheckResult dataclass"""
    
    def test_health_check_result_creation(self):
        """Test creating a health check result"""
        result = HealthCheckResult(
            name="test_check",
            status=HealthStatus.HEALTHY,
            message="All good",
            timestamp="2023-01-01T00:00:00Z",
            duration_ms=5.0
        )
        
        assert result.name == "test_check"
        assert result.status == HealthStatus.HEALTHY
        assert result.message == "All good"
        assert result.timestamp == "2023-01-01T00:00:00Z"
        assert result.duration_ms == 5.0
        assert result.metadata == {}
    
    def test_health_check_result_with_metadata(self):
        """Test health check result with metadata"""
        metadata = {"cpu_percent": 25.5, "memory_mb": 512}
        result = HealthCheckResult(
            name="system_check",
            status=HealthStatus.DEGRADED,
            message="High resource usage",
            timestamp="2023-01-01T00:00:00Z",
            duration_ms=10.0,
            metadata=metadata
        )
        
        assert result.metadata == metadata


class TestSystemHealth:
    """Test SystemHealth dataclass"""
    
    @pytest.fixture
    def sample_checks(self):
        """Create sample health check results"""
        return [
            HealthCheckResult(
                name="process",
                status=HealthStatus.HEALTHY,
                message="Process running",
                timestamp="2023-01-01T00:00:00Z",
                duration_ms=1.0
            ),
            HealthCheckResult(
                name="memory",
                status=HealthStatus.HEALTHY,
                message="Memory usage: 50%",
                timestamp="2023-01-01T00:00:00Z",
                duration_ms=2.0
            )
        ]
    
    def test_system_health_creation(self, sample_checks):
        """Test creating system health"""
        health = SystemHealth(
            status=HealthStatus.HEALTHY,
            checks=sample_checks,
            timestamp="2023-01-01T00:00:00Z",
            uptime_seconds=3600.0
        )
        
        assert health.status == HealthStatus.HEALTHY
        assert len(health.checks) == 2
        assert health.timestamp == "2023-01-01T00:00:00Z"
        assert health.uptime_seconds == 3600.0
    
    def test_is_healthy_property(self, sample_checks):
        """Test is_healthy property"""
        healthy_system = SystemHealth(
            status=HealthStatus.HEALTHY,
            checks=sample_checks,
            timestamp="2023-01-01T00:00:00Z",
            uptime_seconds=3600.0
        )
        assert healthy_system.is_healthy is True
        
        unhealthy_system = SystemHealth(
            status=HealthStatus.UNHEALTHY,
            checks=sample_checks,
            timestamp="2023-01-01T00:00:00Z",
            uptime_seconds=3600.0
        )
        assert unhealthy_system.is_healthy is False
    
    def test_is_ready_property(self, sample_checks):
        """Test is_ready property"""
        # Healthy system should be ready
        healthy_system = SystemHealth(
            status=HealthStatus.HEALTHY,
            checks=sample_checks,
            timestamp="2023-01-01T00:00:00Z",
            uptime_seconds=3600.0
        )
        assert healthy_system.is_ready is True
        
        # Degraded system should still be ready
        degraded_system = SystemHealth(
            status=HealthStatus.DEGRADED,
            checks=sample_checks,
            timestamp="2023-01-01T00:00:00Z",
            uptime_seconds=3600.0
        )
        assert degraded_system.is_ready is True
        
        # Unhealthy system should not be ready
        unhealthy_system = SystemHealth(
            status=HealthStatus.UNHEALTHY,
            checks=sample_checks,
            timestamp="2023-01-01T00:00:00Z",
            uptime_seconds=3600.0
        )
        assert unhealthy_system.is_ready is False


class TestHealthCheck:
    """Test HealthCheck class"""
    
    @pytest.fixture
    def health_check(self):
        """Create a health check instance"""
        return HealthCheck()
    
    def test_health_check_initialization(self, health_check):
        """Test health check initialization"""
        assert health_check._start_time is not None
        assert len(health_check._checks) >= 3  # Default checks: process, memory, cpu
        assert "process" in health_check._checks
        assert "memory" in health_check._checks
        assert "cpu" in health_check._checks
    
    def test_add_check(self, health_check):
        """Test adding custom health check"""
        async def custom_check():
            return HealthCheckResult(
                name="custom",
                status=HealthStatus.HEALTHY,
                message="Custom check passed",
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=1.0
            )
        
        health_check.add_check("custom", custom_check)
        
        assert "custom" in health_check._checks
        assert health_check._checks["custom"] is custom_check
    
    def test_remove_check(self, health_check):
        """Test removing health check"""
        # Add a custom check first
        async def custom_check():
            return HealthCheckResult(
                name="custom",
                status=HealthStatus.HEALTHY,
                message="Custom check",
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=1.0
            )
        
        health_check.add_check("custom", custom_check)
        assert "custom" in health_check._checks
        
        # Remove it
        health_check.remove_check("custom")
        assert "custom" not in health_check._checks
    
    def test_remove_nonexistent_check(self, health_check):
        """Test removing nonexistent check (should not raise error)"""
        initial_count = len(health_check._checks)
        health_check.remove_check("nonexistent")
        assert len(health_check._checks) == initial_count
    
    @pytest.mark.asyncio
    async def test_check_process_success(self, health_check):
        """Test process check success"""
        with patch('psutil.Process') as mock_process_class:
            mock_process = MagicMock()
            mock_process.status.return_value = "running"
            mock_process.pid = 1234
            mock_process_class.return_value = mock_process
            
            result = await health_check._check_process()
            
            assert result.name == "process"
            assert result.status == HealthStatus.HEALTHY
            assert "Process running" in result.message
            assert result.duration_ms >= 0
            assert result.metadata["pid"] == 1234
            assert result.metadata["status"] == "running"
    
    @pytest.mark.asyncio
    async def test_check_process_failure(self, health_check):
        """Test process check failure"""
        with patch('psutil.Process') as mock_process_class:
            mock_process_class.side_effect = Exception("Process not found")
            
            result = await health_check._check_process()
            
            assert result.name == "process"
            assert result.status == HealthStatus.UNHEALTHY
            assert "Process check failed" in result.message
            assert result.duration_ms >= 0
    
    @pytest.mark.asyncio
    async def test_check_memory_healthy(self, health_check):
        """Test memory check with healthy usage"""
        with patch('psutil.Process') as mock_process_class:
            mock_process = MagicMock()
            mock_memory_info = MagicMock()
            mock_memory_info.rss = 100 * 1024 * 1024  # 100 MB
            mock_memory_info.vms = 200 * 1024 * 1024  # 200 MB
            mock_process.memory_info.return_value = mock_memory_info
            mock_process.memory_percent.return_value = 50.0
            mock_process_class.return_value = mock_process
            
            result = await health_check._check_memory()
            
            assert result.name == "memory"
            assert result.status == HealthStatus.HEALTHY
            assert "Memory usage: 50.0%" in result.message
            assert result.metadata["percent"] == 50.0
            assert result.metadata["rss_mb"] == 100.0
            assert result.metadata["vms_mb"] == 200.0
    
    @pytest.mark.asyncio
    async def test_check_memory_degraded(self, health_check):
        """Test memory check with degraded usage"""
        with patch('psutil.Process') as mock_process_class:
            mock_process = MagicMock()
            mock_memory_info = MagicMock()
            mock_memory_info.rss = 800 * 1024 * 1024  # 800 MB
            mock_memory_info.vms = 1000 * 1024 * 1024  # 1000 MB
            mock_process.memory_info.return_value = mock_memory_info
            mock_process.memory_percent.return_value = 80.0
            mock_process_class.return_value = mock_process
            
            result = await health_check._check_memory()
            
            assert result.name == "memory"
            assert result.status == HealthStatus.DEGRADED
            assert "Elevated memory usage: 80.0%" in result.message
    
    @pytest.mark.asyncio
    async def test_check_memory_unhealthy(self, health_check):
        """Test memory check with unhealthy usage"""
        with patch('psutil.Process') as mock_process_class:
            mock_process = MagicMock()
            mock_memory_info = MagicMock()
            mock_memory_info.rss = 950 * 1024 * 1024  # 950 MB
            mock_memory_info.vms = 1200 * 1024 * 1024  # 1200 MB
            mock_process.memory_info.return_value = mock_memory_info
            mock_process.memory_percent.return_value = 95.0
            mock_process_class.return_value = mock_process
            
            result = await health_check._check_memory()
            
            assert result.name == "memory"
            assert result.status == HealthStatus.UNHEALTHY
            assert "High memory usage: 95.0%" in result.message
    
    @pytest.mark.asyncio
    async def test_check_memory_failure(self, health_check):
        """Test memory check failure"""
        with patch('psutil.Process') as mock_process_class:
            mock_process_class.side_effect = Exception("Memory check failed")
            
            result = await health_check._check_memory()
            
            assert result.name == "memory"
            assert result.status == HealthStatus.UNHEALTHY
            assert "Memory check failed" in result.message
    
    @pytest.mark.asyncio
    async def test_check_cpu_healthy(self, health_check):
        """Test CPU check with healthy usage"""
        with patch('psutil.Process') as mock_process_class:
            mock_process = MagicMock()
            mock_process.cpu_percent.return_value = 25.0
            mock_process_class.return_value = mock_process
            
            result = await health_check._check_cpu()
            
            assert result.name == "cpu"
            assert result.status == HealthStatus.HEALTHY
            assert "CPU usage: 25.0%" in result.message
            assert result.metadata["percent"] == 25.0
    
    @pytest.mark.asyncio
    async def test_check_cpu_degraded(self, health_check):
        """Test CPU check with degraded usage"""
        with patch('psutil.Process') as mock_process_class:
            mock_process = MagicMock()
            mock_process.cpu_percent.return_value = 95.0
            mock_process_class.return_value = mock_process
            
            result = await health_check._check_cpu()
            
            assert result.name == "cpu"
            assert result.status == HealthStatus.DEGRADED
            assert "High CPU usage: 95.0%" in result.message
    
    @pytest.mark.asyncio
    async def test_check_cpu_failure(self, health_check):
        """Test CPU check failure"""
        with patch('psutil.Process') as mock_process_class:
            mock_process_class.side_effect = Exception("CPU check failed")
            
            result = await health_check._check_cpu()
            
            assert result.name == "cpu"
            assert result.status == HealthStatus.UNHEALTHY
            assert "CPU check failed" in result.message
    
    @pytest.mark.asyncio
    async def test_get_health_all_healthy(self, health_check):
        """Test get_health with all checks healthy"""
        async def mock_process():
            return HealthCheckResult(
                "process", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_memory():
            return HealthCheckResult(
                "memory", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_cpu():
            return HealthCheckResult(
                "cpu", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        health_check._checks = {
            "process": mock_process,
            "memory": mock_memory,
            "cpu": mock_cpu
        }
        
        health = await health_check.get_health()
        
        assert health.status == HealthStatus.HEALTHY
        assert len(health.checks) == 3
        assert health.is_healthy is True
        assert health.is_ready is True
        assert health.uptime_seconds >= 0
    
    @pytest.mark.asyncio
    async def test_get_health_with_degraded(self, health_check):
        """Test get_health with one degraded check"""
        # Replace the actual check methods with mocks
        async def mock_process():
            return HealthCheckResult(
                "process", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_memory():
            return HealthCheckResult(
                "memory", HealthStatus.DEGRADED, "High usage", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_cpu():
            return HealthCheckResult(
                "cpu", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        health_check._checks = {
            "process": mock_process,
            "memory": mock_memory,
            "cpu": mock_cpu
        }
        
        health = await health_check.get_health()
        
        assert health.status == HealthStatus.DEGRADED
        assert health.is_healthy is False
        assert health.is_ready is True  # Degraded is still ready
    
    @pytest.mark.asyncio
    async def test_get_health_with_unhealthy(self, health_check):
        """Test get_health with one unhealthy check"""
        async def mock_process():
            return HealthCheckResult(
                "process", HealthStatus.UNHEALTHY, "Failed", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_memory():
            return HealthCheckResult(
                "memory", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_cpu():
            return HealthCheckResult(
                "cpu", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        health_check._checks = {
            "process": mock_process,
            "memory": mock_memory,
            "cpu": mock_cpu
        }
        
        health = await health_check.get_health()
        
        assert health.status == HealthStatus.UNHEALTHY
        assert health.is_healthy is False
        assert health.is_ready is False
    
    @pytest.mark.asyncio
    async def test_get_health_with_exception(self, health_check):
        """Test get_health when a check raises exception"""
        async def mock_process():
            raise RuntimeError("Process check failed")
        
        async def mock_memory():
            return HealthCheckResult(
                "memory", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_cpu():
            return HealthCheckResult(
                "cpu", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        health_check._checks = {
            "process": mock_process,
            "memory": mock_memory,
            "cpu": mock_cpu
        }
        
        health = await health_check.get_health()
        
        assert health.status == HealthStatus.UNHEALTHY
        assert len(health.checks) == 3
        
        # Find the failed check
        failed_check = next(c for c in health.checks if c.name == "process")
        assert failed_check.status == HealthStatus.UNHEALTHY
        assert "Check failed" in failed_check.message
    
    @pytest.mark.asyncio
    async def test_is_live_success(self, health_check):
        """Test liveness probe success"""
        with patch.object(health_check, '_check_process') as mock_process:
            mock_process.return_value = HealthCheckResult(
                "process", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
            
            is_live = await health_check.is_live()
            assert is_live is True
    
    @pytest.mark.asyncio
    async def test_is_live_failure(self, health_check):
        """Test liveness probe failure"""
        with patch.object(health_check, '_check_process') as mock_process:
            mock_process.return_value = HealthCheckResult(
                "process", HealthStatus.UNHEALTHY, "Failed", "2023-01-01T00:00:00Z", 1.0
            )
            
            is_live = await health_check.is_live()
            assert is_live is False
    
    @pytest.mark.asyncio
    async def test_is_live_exception(self, health_check):
        """Test liveness probe with exception"""
        with patch.object(health_check, '_check_process') as mock_process:
            mock_process.side_effect = Exception("Check failed")
            
            is_live = await health_check.is_live()
            assert is_live is False
    
    @pytest.mark.asyncio
    async def test_is_ready_success(self, health_check):
        """Test readiness probe success"""
        with patch.object(health_check, 'get_health') as mock_get_health:
            mock_health = SystemHealth(
                status=HealthStatus.HEALTHY,
                checks=[],
                timestamp="2023-01-01T00:00:00Z",
                uptime_seconds=3600.0
            )
            mock_get_health.return_value = mock_health
            
            is_ready = await health_check.is_ready()
            assert is_ready is True
    
    @pytest.mark.asyncio
    async def test_is_ready_degraded(self, health_check):
        """Test readiness probe with degraded status (should still be ready)"""
        with patch.object(health_check, 'get_health') as mock_get_health:
            mock_health = SystemHealth(
                status=HealthStatus.DEGRADED,
                checks=[],
                timestamp="2023-01-01T00:00:00Z",
                uptime_seconds=3600.0
            )
            mock_get_health.return_value = mock_health
            
            is_ready = await health_check.is_ready()
            assert is_ready is True
    
    @pytest.mark.asyncio
    async def test_is_ready_unhealthy(self, health_check):
        """Test readiness probe with unhealthy status"""
        with patch.object(health_check, 'get_health') as mock_get_health:
            mock_health = SystemHealth(
                status=HealthStatus.UNHEALTHY,
                checks=[],
                timestamp="2023-01-01T00:00:00Z",
                uptime_seconds=3600.0
            )
            mock_get_health.return_value = mock_health
            
            is_ready = await health_check.is_ready()
            assert is_ready is False


class TestCheckServiceUrl:
    """Test check_service_url function"""
    
    @pytest.mark.asyncio
    async def test_check_service_url_success(self):
        """Test successful service URL check"""
        with patch('aiohttp.ClientSession') as mock_session_class:
            # Create mock session and response
            mock_session = MagicMock()
            mock_response = MagicMock()
            mock_response.status = 200
            
            # Setup async context managers
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock(return_value=None)
            mock_response.__aenter__ = AsyncMock(return_value=mock_response)
            mock_response.__aexit__ = AsyncMock(return_value=None)
            
            # Setup session.get to return the response
            mock_session.get.return_value = mock_response
            mock_session_class.return_value = mock_session
            
            result = await check_service_url("test_service", "http://localhost:8080/health")
            
            assert result.name == "test_service"
            assert result.status == HealthStatus.HEALTHY
            assert "Service accessible (HTTP 200)" in result.message
            assert result.metadata["url"] == "http://localhost:8080/health"
            assert result.metadata["status_code"] == 200
            assert result.duration_ms >= 0
    
    @pytest.mark.asyncio
    async def test_check_service_url_degraded(self):
        """Test service URL check with non-200 status"""
        with patch('aiohttp.ClientSession') as mock_session_class:
            mock_session = MagicMock()
            mock_response = MagicMock()
            mock_response.status = 503
            
            # Setup async context managers
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock(return_value=None)
            mock_response.__aenter__ = AsyncMock(return_value=mock_response)
            mock_response.__aexit__ = AsyncMock(return_value=None)
            
            mock_session.get.return_value = mock_response
            mock_session_class.return_value = mock_session
            
            result = await check_service_url("test_service", "http://localhost:8080/health")
            
            assert result.name == "test_service"
            assert result.status == HealthStatus.DEGRADED
            assert "Service returned HTTP 503" in result.message
            assert result.metadata["status_code"] == 503
    
    @pytest.mark.asyncio
    async def test_check_service_url_timeout(self):
        """Test service URL check with timeout"""
        with patch('aiohttp.ClientSession') as mock_session_class:
            mock_session = MagicMock()
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock(return_value=None)
            mock_session.get.side_effect = asyncio.TimeoutError()
            mock_session_class.return_value = mock_session
            
            result = await check_service_url("test_service", "http://localhost:8080/health", timeout=1.0)
            
            assert result.name == "test_service"
            assert result.status == HealthStatus.UNHEALTHY
            assert "Service timeout after 1.0s" in result.message
            assert result.metadata["url"] == "http://localhost:8080/health"
    
    @pytest.mark.asyncio
    async def test_check_service_url_connection_error(self):
        """Test service URL check with connection error"""
        with patch('aiohttp.ClientSession') as mock_session_class:
            mock_session = MagicMock()
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock(return_value=None)
            
            # Use a simpler exception that doesn't require complex setup
            connection_error = Exception("Connection refused")
            mock_session.get.side_effect = connection_error
            mock_session_class.return_value = mock_session
            
            result = await check_service_url("test_service", "http://localhost:8080/health")
            
            assert result.name == "test_service"
            assert result.status == HealthStatus.UNHEALTHY
            assert "Service unreachable" in result.message
            assert "Connection refused" in result.metadata["error"]
    
    @pytest.mark.asyncio
    async def test_check_service_url_generic_exception(self):
        """Test service URL check with generic exception"""
        with patch('aiohttp.ClientSession') as mock_session_class:
            mock_session = MagicMock()
            mock_session.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session.__aexit__ = AsyncMock(return_value=None)
            mock_session.get.side_effect = Exception("Unexpected error")
            mock_session_class.return_value = mock_session
            
            result = await check_service_url("test_service", "http://localhost:8080/health")
            
            assert result.name == "test_service"
            assert result.status == HealthStatus.UNHEALTHY
            assert "Service unreachable: Unexpected error" in result.message
            assert result.metadata["error"] == "Unexpected error"


class TestCheckError:
    """Test CheckError exception"""
    
    def test_check_error_inheritance(self):
        """Test that CheckError inherits from CMPError"""
        from cmp.core.exceptions import CMPError
        error = CheckError("Test error")
        assert isinstance(error, CMPError)
        assert str(error) == "Test error"


class TestHealthCheckIntegration:
    """Integration tests for health check system"""
    
    @pytest.mark.asyncio
    async def test_custom_health_check_integration(self):
        """Test adding and using custom health checks"""
        health_check = HealthCheck()
        
        # Add custom database check
        async def check_database():
            return HealthCheckResult(
                name="database",
                status=HealthStatus.HEALTHY,
                message="Database connected",
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=5.0,
                metadata={"connection_pool": "active", "queries_per_sec": 100}
            )
        
        # Add custom cache check
        async def check_cache():
            return HealthCheckResult(
                name="cache",
                status=HealthStatus.DEGRADED,
                message="Cache hit ratio low",
                timestamp=datetime.now(timezone.utc).isoformat(),
                duration_ms=2.0,
                metadata={"hit_ratio": 0.65, "memory_usage": "80%"}
            )
        
        health_check.add_check("database", check_database)
        health_check.add_check("cache", check_cache)
        
        # Replace default checks with healthy mocks
        async def mock_process():
            return HealthCheckResult(
                "process", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_memory():
            return HealthCheckResult(
                "memory", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_cpu():
            return HealthCheckResult(
                "cpu", HealthStatus.HEALTHY, "OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        # Update the checks dictionary to include both default and custom checks
        health_check._checks.update({
            "process": mock_process,
            "memory": mock_memory,
            "cpu": mock_cpu
        })
        
        health = await health_check.get_health()
        
        # Should be degraded due to cache check
        assert health.status == HealthStatus.DEGRADED
        assert len(health.checks) == 5  # 3 default + 2 custom
        
        # Find custom checks
        db_check = next(c for c in health.checks if c.name == "database")
        cache_check = next(c for c in health.checks if c.name == "cache")
        
        assert db_check.status == HealthStatus.HEALTHY
        assert cache_check.status == HealthStatus.DEGRADED
        assert cache_check.metadata["hit_ratio"] == 0.65
    
    @pytest.mark.asyncio
    async def test_health_check_with_mixed_statuses(self):
        """Test health check system with mixed check statuses"""
        health_check = HealthCheck()
        
        # Replace checks with mocks that have different statuses
        async def mock_process():
            return HealthCheckResult(
                "process", HealthStatus.HEALTHY, "Process OK", "2023-01-01T00:00:00Z", 1.0
            )
        
        async def mock_memory():
            return HealthCheckResult(
                "memory", HealthStatus.DEGRADED, "Memory high", "2023-01-01T00:00:00Z", 2.0
            )
        
        async def mock_cpu():
            return HealthCheckResult(
                "cpu", HealthStatus.UNHEALTHY, "CPU overloaded", "2023-01-01T00:00:00Z", 3.0
            )
        
        health_check._checks = {
            "process": mock_process,
            "memory": mock_memory,
            "cpu": mock_cpu
        }
        
        health = await health_check.get_health()
        
        # Should be unhealthy due to CPU check
        assert health.status == HealthStatus.UNHEALTHY
        assert health.is_healthy is False
        assert health.is_ready is False
        
        # Verify individual check statuses
        process_check = next(c for c in health.checks if c.name == "process")
        memory_check = next(c for c in health.checks if c.name == "memory")
        cpu_check = next(c for c in health.checks if c.name == "cpu")
        
        assert process_check.status == HealthStatus.HEALTHY
        assert memory_check.status == HealthStatus.DEGRADED
        assert cpu_check.status == HealthStatus.UNHEALTHY