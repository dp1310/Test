import pytest
from unittest.mock import Mock, AsyncMock, patch

from cmp.orchestration.patterns.saga import SagaWorkflow, TwoPhaseCommit
from cmp.core.models import Context
from cmp.core.result import Ok, Err

# Mock Context
@pytest.fixture
def mock_context() -> Context:
    """Fixture for a mock context object."""
    return Mock(spec=Context)

class TestSagaWorkflow:
    """Tests for the SagaWorkflow class."""

    @pytest.mark.asyncio
    async def test_saga_successful_execution(self, mock_context):
        """Test a saga that executes all steps successfully."""
        # Mock functions
        action1 = AsyncMock(return_value=mock_context)
        action2 = AsyncMock(return_value=mock_context)
        compensate1 = AsyncMock()
        compensate2 = AsyncMock()

        # Build and execute saga
        saga = SagaWorkflow()
        saga.step(action=action1, compensate=compensate1, name="step1")
        saga.step(action=action2, compensate=compensate2, name="step2")
        
        result = await saga.execute(mock_context)

        # Assertions
        assert isinstance(result, Ok)
        action1.assert_called_once_with(mock_context)
        action2.assert_called_once_with(mock_context)
        compensate1.assert_not_called()
        compensate2.assert_not_called()

    @pytest.mark.asyncio
    async def test_saga_failure_and_compensation(self, mock_context):
        """Test a saga where a step fails and compensation is triggered."""
        # Mock functions
        action1 = AsyncMock(return_value=mock_context)
        action2 = AsyncMock(side_effect=Exception("Action 2 failed"))
        compensate1 = AsyncMock(return_value=mock_context)
        
        # Build and execute saga
        saga = SagaWorkflow()
        saga.step(action=action1, compensate=compensate1, name="step1")
        saga.step(action=action2, name="step2")
        
        result = await saga.execute(mock_context)

        # Assertions
        assert isinstance(result, Err)
        assert "Saga failed at step 'step2': Action 2 failed" in result.error
        action1.assert_called_once_with(mock_context)
        action2.assert_called_once_with(mock_context)
        compensate1.assert_called_once_with(mock_context)

    @pytest.mark.asyncio
    async def test_saga_compensation_failure(self, mock_context, capsys):
        """Test a saga where a compensation action fails."""
        # Mock functions
        action1 = AsyncMock(return_value=mock_context)
        action2 = AsyncMock(side_effect=Exception("Action 2 failed"))
        compensate1 = AsyncMock(side_effect=Exception("Compensation 1 failed"))

        # Build and execute saga
        saga = SagaWorkflow()
        saga.step(action=action1, compensate=compensate1, name="step1")
        saga.step(action=action2, name="step2")

        result = await saga.execute(mock_context)

        # Assertions
        assert isinstance(result, Err)
        compensate1.assert_called_once()
        
        # Check that compensation failure is logged
        captured = capsys.readouterr()
        assert "Compensation failed for step 'step1': Compensation 1 failed" in captured.out

    @pytest.mark.asyncio
    async def test_saga_unexpected_error(self, mock_context):
        """Test a saga with an unexpected error during execution."""
        # Mock functions
        action1 = AsyncMock(side_effect=Exception("Unexpected error"))
        
        saga = SagaWorkflow()
        saga.step(action=action1, name="step1")
        
        result = await saga.execute(mock_context)

        assert isinstance(result, Err)
        assert "Saga failed at step 'step1': Unexpected error" in result.error

    @pytest.mark.asyncio
    async def test_saga_step_failure_with_compensation_failure(self, mock_context):
        """Test a saga where a step fails and its compensation also fails."""
        # Mock functions
        action1 = AsyncMock(return_value=mock_context)
        action2 = AsyncMock(side_effect=Exception("Action 2 failed"))
        compensate1 = AsyncMock(side_effect=Exception("Compensation 1 failed"))
        
        saga = SagaWorkflow()
        saga.step(action=action1, compensate=compensate1, name="step1")
        saga.step(action=action2, name="step2")
        
        with patch.object(saga, '_compensate', new=AsyncMock(side_effect=Exception("Compensation failed"))) as mock_compensate:
            result = await saga.execute(mock_context)
            assert isinstance(result, Err)
            assert "Saga failed at step 'step2' ('Action 2 failed') and compensation also failed: Compensation failed" in result.error
            mock_compensate.assert_called_once()

    @pytest.mark.asyncio
    async def test_saga_with_no_steps(self, mock_context):
        """Test that a saga with no steps returns Ok."""
        saga = SagaWorkflow()
        result = await saga.execute(mock_context)
        assert isinstance(result, Ok)
        assert result.unwrap() is mock_context


class TestTwoPhaseCommit:
    """Tests for the TwoPhaseCommit class."""

    @pytest.mark.asyncio
    async def test_2pc_successful_commit(self, mock_context):
        """Test a successful two-phase commit."""
        # Mocks
        prepare1 = AsyncMock(return_value=True)
        commit1 = AsyncMock(return_value=mock_context)
        abort1 = AsyncMock()
        
        prepare2 = AsyncMock(return_value=True)
        commit2 = AsyncMock(return_value=mock_context)
        abort2 = AsyncMock()

        # Build and execute 2PC
        tpc = TwoPhaseCommit()
        tpc.add_participant(prepare=prepare1, commit=commit1, abort=abort1)
        tpc.add_participant(prepare=prepare2, commit=commit2, abort=abort2)
        
        result = await tpc.execute(mock_context)

        # Assertions
        assert isinstance(result, Ok)
        prepare1.assert_called_once_with(mock_context)
        prepare2.assert_called_once_with(mock_context)
        commit1.assert_called_once_with(mock_context)
        commit2.assert_called_once_with(mock_context)
        abort1.assert_not_called()
        abort2.assert_not_called()

    @pytest.mark.asyncio
    async def test_2pc_with_no_participants(self, mock_context):
        """Test that a 2PC with no participants returns Ok."""
        tpc = TwoPhaseCommit()
        result = await tpc.execute(mock_context)
        assert isinstance(result, Ok)
        assert result.unwrap() is mock_context

    @pytest.mark.asyncio
    async def test_2pc_prepare_failure_and_abort(self, mock_context):
        """Test 2PC where a participant fails to prepare."""
        # Mocks
        prepare1 = AsyncMock(return_value=True)
        commit1 = AsyncMock()
        abort1 = AsyncMock()
        
        prepare2 = AsyncMock(return_value=False)
        commit2 = AsyncMock()
        abort2 = AsyncMock()

        # Build and execute 2PC
        tpc = TwoPhaseCommit()
        tpc.add_participant(prepare=prepare1, commit=commit1, abort=abort1, name="p1")
        tpc.add_participant(prepare=prepare2, commit=commit2, abort=abort2, name="p2")
        
        result = await tpc.execute(mock_context)

        # Assertions
        assert isinstance(result, Err)
        assert "Participant 'p2' failed to prepare" in result.error
        prepare1.assert_called_once_with(mock_context)
        prepare2.assert_called_once_with(mock_context)
        commit1.assert_not_called()
        commit2.assert_not_called()
        abort1.assert_called_once_with(mock_context)
        abort2.assert_called_once_with(mock_context) # Should abort all

    @pytest.mark.asyncio
    async def test_2pc_abort_failure(self, mock_context, capsys):
        """Test 2PC with a failing abort action."""
        # Mocks
        prepare1 = AsyncMock(return_value=False)
        commit1 = AsyncMock()
        abort1 = AsyncMock(side_effect=Exception("Abort failed"))

        # Build and execute 2PC
        tpc = TwoPhaseCommit()
        tpc.add_participant(prepare=prepare1, commit=commit1, abort=abort1, name="p1")
        
        result = await tpc.execute(mock_context)
        
        assert isinstance(result, Err)
        
        # Check that abort failure is logged
        captured = capsys.readouterr()
        assert "Abort failed for 'p1': Abort failed" in captured.out

    @pytest.mark.asyncio
    async def test_2pc_prepare_exception(self, mock_context):
        """Test 2PC with an exception during the prepare phase."""
        # Mocks
        prepare1 = AsyncMock(side_effect=Exception("Prepare error"))
        commit1 = AsyncMock()
        abort1 = AsyncMock()
        
        tpc = TwoPhaseCommit()
        tpc.add_participant(prepare=prepare1, commit=commit1, abort=abort1, name="p1")
        
        result = await tpc.execute(mock_context)

        assert isinstance(result, Err)
        assert "Prepare failed for 'p1': Prepare error" in result.error
        abort1.assert_called_once()

    @pytest.mark.asyncio
    async def test_2pc_commit_exception(self, mock_context):
        """Test 2PC with an exception during the commit phase."""
        # Mocks
        prepare1 = AsyncMock(return_value=True)
        commit1 = AsyncMock(side_effect=Exception("Commit error"))
        abort1 = AsyncMock()
        
        tpc = TwoPhaseCommit()
        tpc.add_participant(prepare=prepare1, commit=commit1, abort=abort1)
        
        result = await tpc.execute(mock_context)

        assert isinstance(result, Err)
        assert "Commit failed: Commit error" in result.error
        abort1.assert_not_called() # In 2PC, commit failure doesn't automatically trigger abort
