
import pytest
from unittest.mock import MagicMock, AsyncMock
from cmp.services.orchestration_service import OrchestrationService
from cmp.orchestration.strategies import OrchestrationStrategy
from cmp.core.models import Context

class MockStrategy(OrchestrationStrategy):
    async def execute(self, context, agents, params):
        yield context

@pytest.mark.asyncio
async def test_orchestration_defaults():
    # Test initialization without policy service (covers lines 38-40)
    service = OrchestrationService()
    assert service._policy_service is not None
    # We can check if it's the MockPolicyService type or behaves like one
    assert hasattr(service._policy_service, "get_workflow_policy")

@pytest.mark.asyncio
async def test_register_strategy():
    service = OrchestrationService()
    strategy = MockStrategy()
    
    # Test register (covers line 59)
    service.register_strategy("custom", strategy)
    assert "custom" in service._strategies
    assert service._strategies["custom"] == strategy

@pytest.mark.asyncio
async def test_invalid_strategy():
    mock_policy_service = MagicMock()
    # Return policy that requests unknown strategy
    mock_policy_service.get_workflow_policy = AsyncMock(return_value={"strategy": "unknown_strat"})
    
    service = OrchestrationService(policy_service=mock_policy_service)
    
    context = MagicMock()
    agents = []
    
    # Execute workflow expecting ValueError (covers line 86)
    with pytest.raises(ValueError, match="Unknown orchestration strategy"):
        async for _ in service.execute_workflow("wf", context, agents):
            pass
