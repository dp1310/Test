"""Quick test of async Prefect integration."""

import sys
import os
import asyncio

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, agentic_spine_async_prefect, 
    Context, get_logger, setup_logging
)
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


async def main():
    """Quick test of async Prefect."""
    logger.info("🧪 Quick Async Prefect Test")
    logger.info("=" * 30)
    
    @perceive
    @task(name="test_async_perceive", cache_policy=NO_CACHE)
    async def test_async_perceive(ctx: dict) -> dict:
        """Simple async Prefect task."""
        text = ctx.get("input", {}).get("text", "")
        logger.info(f"[ASYNC PREFECT] Processing: {text}")
        await asyncio.sleep(0.05)  # Simulate async work
        return {"processed": True, "method": "async_prefect"}
    
    @reason
    def test_sync_reason(ctx: dict) -> dict:
        """Simple sync function."""
        processed = ctx.get("processed", False)
        method = ctx.get("method", "unknown")
        logger.info(f"[SYNC] Reasoning with method: {method}")
        return {"decision": "approve" if processed else "reject"}
    
    try:
        logger.info("Testing async Prefect workflow...")
        result = await agentic_spine_async_prefect(
            input_data={"text": "test message"},
            functions=[test_async_perceive, test_sync_reason]
        )
        
        logger.info(f"✅ Success! Result: {result.get('decision')} via {result.get('method')}")
        logger.info(f"Processed: {result.get('processed')}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Error: {e}")
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    if success:
        print("🎉 Async Prefect integration working!")
    else:
        print("❌ Async Prefect integration failed!")