"""Simple example demonstrating the agent SDK."""

import sys
import os
import asyncio

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, plan, act, Stage,
    agentic_spine, agentic_spine_async, 
    Context, get_logger, setup_logging
)

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# Synchronous example
@perceive
def analyze_text(ctx: Context) -> dict:
    """Analyze input text for basic properties."""
    text = ctx.get("input", {}).get("text", "")
    logger.info(f"Analyzing text: '{text}'")
    
    return {
        "word_count": len(text.split()),
        "char_count": len(text),
        "has_question": "?" in text,
        "has_exclamation": "!" in text
    }

@reason
def determine_urgency(ctx: Context) -> dict:
    """Determine urgency based on text analysis."""
    has_question = ctx.get("has_question", False)
    has_exclamation = ctx.get("has_exclamation", False)
    word_count = ctx.get("word_count", 0)
    
    urgency_score = 0
    if has_exclamation:
        urgency_score += 2
    if has_question:
        urgency_score += 1
    if word_count > 20:
        urgency_score += 1
    
    urgency = "high" if urgency_score >= 3 else "medium" if urgency_score >= 1 else "low"
    
    logger.info(f"Determined urgency: {urgency} (score: {urgency_score})")
    
    return {
        "urgency": urgency,
        "urgency_score": urgency_score
    }

@plan
def create_response_plan(ctx: Context) -> dict:
    """Create a response plan based on urgency."""
    urgency = ctx.get("urgency", "low")
    
    if urgency == "high":
        actions = ["immediate_response", "escalate_to_manager", "log_urgent"]
        response_time = "immediate"
    elif urgency == "medium":
        actions = ["standard_response", "log_medium"]
        response_time = "within_hour"
    else:
        actions = ["queue_response", "log_low"]
        response_time = "within_day"
    
    logger.info(f"Created plan with {len(actions)} actions for {urgency} urgency")
    
    return {
        "planned_actions": actions,
        "response_time": response_time
    }

@act
def execute_plan(ctx: Context) -> dict:
    """Execute the planned actions."""
    actions = ctx.get("planned_actions", [])
    response_time = ctx.get("response_time", "unknown")
    
    executed = []
    for action in actions:
        # Simulate action execution
        result = f"✓ {action}"
        executed.append(result)
        logger.info(f"Executed: {action}")
    
    return {
        "executed_actions": executed,
        "status": "completed",
        "target_response_time": response_time
    }


# Async example
@perceive
async def async_analyze_sentiment(ctx: Context) -> dict:
    """Asynchronously analyze sentiment."""
    text = ctx.get("input", {}).get("text", "")
    
    # Simulate async processing
    await asyncio.sleep(0.1)
    
    # Simple sentiment analysis
    positive_words = ["good", "great", "excellent", "amazing", "wonderful"]
    negative_words = ["bad", "terrible", "awful", "horrible", "worst"]
    
    text_lower = text.lower()
    positive_count = sum(1 for word in positive_words if word in text_lower)
    negative_count = sum(1 for word in negative_words if word in text_lower)
    
    if positive_count > negative_count:
        sentiment = "positive"
    elif negative_count > positive_count:
        sentiment = "negative"
    else:
        sentiment = "neutral"
    
    logger.info(f"Async sentiment analysis: {sentiment}")
    
    return {
        "sentiment": sentiment,
        "positive_indicators": positive_count,
        "negative_indicators": negative_count
    }

@reason
async def async_assess_response_needed(ctx: Context) -> dict:
    """Asynchronously assess if response is needed."""
    sentiment = ctx.get("sentiment", "neutral")
    urgency = ctx.get("urgency", "low")
    
    await asyncio.sleep(0.05)
    
    needs_response = (
        sentiment == "negative" or 
        urgency in ["high", "medium"]
    )
    
    priority = "high" if sentiment == "negative" and urgency == "high" else "normal"
    
    logger.info(f"Response needed: {needs_response}, priority: {priority}")
    
    return {
        "needs_response": needs_response,
        "priority": priority
    }


def sync_example():
    """Run synchronous example."""
    logger.info("=== Synchronous Example ===")
    
    test_inputs = [
        "Hello! This is an urgent request!",
        "Can you help me with this question?",
        "This is just a simple message."
    ]
    
    for i, text in enumerate(test_inputs, 1):
        logger.info(f"\n--- Test {i} ---")
        
        result = agentic_spine(
            input_data={"text": text},
            functions=[analyze_text, determine_urgency, create_response_plan, execute_plan]
        )
        
        logger.info(f"Final result: {result.get('status')} - {result.get('target_response_time')}")
        logger.info(f"Actions: {len(result.get('executed_actions', []))}")


async def async_example():
    """Run asynchronous example."""
    logger.info("\n=== Asynchronous Example ===")
    
    test_inputs = [
        "This is a great service!",
        "This is terrible and urgent!",
        "Just a normal message here."
    ]
    
    for i, text in enumerate(test_inputs, 1):
        logger.info(f"\n--- Async Test {i} ---")
        
        result = await agentic_spine_async(
            input_data={"text": text},
            functions=[
                analyze_text,  # sync
                async_analyze_sentiment,  # async
                determine_urgency,  # sync
                async_assess_response_needed,  # async
                create_response_plan,  # sync
                execute_plan  # sync
            ],
            concurrent={
                # Run perception stages concurrently
                # (analyze_text and async_analyze_sentiment will run in parallel)
                Stage.PERCEIVE: True
            }
        )
        
        logger.info(f"Sentiment: {result.get('sentiment')}")
        logger.info(f"Needs response: {result.get('needs_response')}")
        logger.info(f"Priority: {result.get('priority')}")


async def main():
    """Run both examples."""
    # Run sync example
    sync_example()
    
    # Run async example
    await async_example()
    
    logger.info("\n=== Examples completed ===")


if __name__ == "__main__":
    asyncio.run(main())