#!/usr/bin/env python3
"""
Simple API demo for stage monitoring system.

This example shows how to easily integrate monitoring into your workflows
with minimal code changes.
"""

import sys
import os
import asyncio
import time

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    agentic_spine_async, perceive, reason, plan, act,
    Context, Stage, get_logger, setup_logging
)
from agent_sdk.core.state import (
    configure_monitoring, get_workflow_status, get_metrics,
    StageStateObserver, StageExecution
)

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# =============================================================================
# SIMPLE MONITORING API
# =============================================================================

class SimpleMonitor:
    """Simple monitoring API for easy integration."""
    
    def __init__(self, enable_console_logs: bool = True, enable_metrics: bool = True):
        """Initialize monitoring with basic configuration."""
        self.state_manager = configure_monitoring(
            enable_logging=enable_console_logs,
            enable_metrics=enable_metrics
        )
        self.workflows = {}
    
    def get_status(self, workflow_id: str = "default") -> dict:
        """Get workflow status in a simple format."""
        status = get_workflow_status(workflow_id)
        return {
            "workflow_id": workflow_id,
            "status": status.get("status", "unknown"),
            "completed_stages": status.get("completed", 0),
            "total_stages": status.get("total_stages", 0),
            "errors": status.get("errors", 0),
            "duration": status.get("total_duration", 0),
            "success_rate": (status.get("completed", 0) / max(status.get("total_stages", 1), 1)) * 100
        }
    
    def get_performance_summary(self) -> dict:
        """Get overall performance metrics."""
        metrics = get_metrics()
        return {
            "total_executions": metrics.get("total_executions", 0),
            "success_rate": metrics.get("success_rate", 0),
            "total_duration": metrics.get("total_duration", 0),
            "failed_executions": metrics.get("failed_executions", 0),
            "average_stage_durations": metrics.get("average_durations", {})
        }
    
    def print_status(self, workflow_id: str = "default"):
        """Print workflow status in a readable format."""
        status = self.get_status(workflow_id)
        
        status_emoji = {
            "completed": "✅",
            "running": "🔄", 
            "failed": "❌",
            "unknown": "❓"
        }.get(status["status"], "❓")
        
        logger.info(f"{status_emoji} Workflow {workflow_id}:")
        logger.info(f"   Status: {status['status']}")
        logger.info(f"   Progress: {status['completed_stages']}/{status['total_stages']} stages")
        logger.info(f"   Duration: {status['duration']:.3f}s")
        logger.info(f"   Success Rate: {status['success_rate']:.1f}%")
        if status['errors'] > 0:
            logger.info(f"   Errors: {status['errors']}")
    
    def print_performance_summary(self):
        """Print overall performance summary."""
        perf = self.get_performance_summary()
        
        logger.info("📊 Performance Summary:")
        logger.info(f"   Total Executions: {perf['total_executions']}")
        logger.info(f"   Success Rate: {perf['success_rate']:.1f}%")
        logger.info(f"   Total Duration: {perf['total_duration']:.3f}s")
        
        if perf['average_stage_durations']:
            logger.info("   Average Stage Durations:")
            for stage, duration in perf['average_stage_durations'].items():
                logger.info(f"     • {stage}: {duration:.3f}s")


# =============================================================================
# DEMO FUNCTIONS
# =============================================================================

@perceive
async def load_user_data(ctx: Context) -> dict:
    """Load user data from input."""
    logger.info("📥 Loading user data...")
    await asyncio.sleep(0.1)
    
    user_input = ctx.get("input", {})
    return {
        "user_id": user_input.get("user_id", "unknown"),
        "request_type": user_input.get("type", "general"),
        "data_loaded": True
    }

@reason
async def analyze_request(ctx: Context) -> dict:
    """Analyze the user request."""
    logger.info("🔍 Analyzing request...")
    await asyncio.sleep(0.2)
    
    request_type = ctx.get("request_type", "general")
    
    if request_type == "urgent":
        priority = "high"
        complexity = "medium"
    elif request_type == "complex":
        priority = "medium"
        complexity = "high"
    else:
        priority = "normal"
        complexity = "low"
    
    return {
        "priority": priority,
        "complexity": complexity,
        "analysis_complete": True
    }

@plan
async def create_response_plan(ctx: Context) -> dict:
    """Create a response plan based on analysis."""
    logger.info("📋 Creating response plan...")
    await asyncio.sleep(0.15)
    
    priority = ctx.get("priority", "normal")
    complexity = ctx.get("complexity", "low")
    
    if priority == "high":
        actions = ["immediate_response", "escalate_to_manager", "follow_up"]
        timeline = "immediate"
    elif complexity == "high":
        actions = ["detailed_analysis", "expert_consultation", "comprehensive_response"]
        timeline = "extended"
    else:
        actions = ["standard_response", "basic_follow_up"]
        timeline = "normal"
    
    return {
        "actions": actions,
        "timeline": timeline,
        "plan_ready": True
    }

@act
async def execute_response(ctx: Context) -> dict:
    """Execute the response plan."""
    logger.info("⚡ Executing response...")
    
    actions = ctx.get("actions", ["default_action"])
    timeline = ctx.get("timeline", "normal")
    
    # Simulate different execution times based on timeline
    if timeline == "immediate":
        await asyncio.sleep(0.05)
    elif timeline == "extended":
        await asyncio.sleep(0.3)
    else:
        await asyncio.sleep(0.1)
    
    executed_actions = []
    for action in actions:
        executed_actions.append(f"✓ {action}")
        logger.info(f"   Executed: {action}")
    
    return {
        "executed_actions": executed_actions,
        "response_sent": True,
        "execution_complete": True
    }


# =============================================================================
# DEMO SCENARIOS
# =============================================================================

async def demo_normal_request(monitor: SimpleMonitor):
    """Demo a normal user request."""
    logger.info("\n🎯 DEMO: Normal Request")
    logger.info("-" * 30)
    
    result = await agentic_spine_async(
        input_data={
            "user_id": "user_123",
            "type": "general",
            "message": "I need help with my account"
        },
        functions=[load_user_data, analyze_request, create_response_plan, execute_response],
        workflow_id="normal_request"
    )
    
    monitor.print_status("normal_request")
    return result

async def demo_urgent_request(monitor: SimpleMonitor):
    """Demo an urgent user request."""
    logger.info("\n🚨 DEMO: Urgent Request")
    logger.info("-" * 30)
    
    result = await agentic_spine_async(
        input_data={
            "user_id": "user_456", 
            "type": "urgent",
            "message": "My account is locked and I can't access important data!"
        },
        functions=[load_user_data, analyze_request, create_response_plan, execute_response],
        workflow_id="urgent_request"
    )
    
    monitor.print_status("urgent_request")
    return result

async def demo_complex_request(monitor: SimpleMonitor):
    """Demo a complex user request."""
    logger.info("\n🧠 DEMO: Complex Request")
    logger.info("-" * 30)
    
    result = await agentic_spine_async(
        input_data={
            "user_id": "user_789",
            "type": "complex", 
            "message": "I need a detailed analysis of my usage patterns and recommendations"
        },
        functions=[load_user_data, analyze_request, create_response_plan, execute_response],
        workflow_id="complex_request"
    )
    
    monitor.print_status("complex_request")
    return result

async def demo_concurrent_requests(monitor: SimpleMonitor):
    """Demo multiple concurrent requests."""
    logger.info("\n🔀 DEMO: Concurrent Requests")
    logger.info("-" * 30)
    
    # Process multiple requests concurrently
    tasks = [
        agentic_spine_async(
            input_data={"user_id": f"user_{i}", "type": "general", "message": f"Request {i}"},
            functions=[load_user_data, analyze_request],
            workflow_id=f"concurrent_request_{i}"
        )
        for i in range(3)
    ]
    
    results = await asyncio.gather(*tasks)
    
    # Print status for each concurrent request
    for i in range(3):
        monitor.print_status(f"concurrent_request_{i}")
    
    return results


# =============================================================================
# MAIN DEMO
# =============================================================================

async def main():
    """Run the monitoring API demo."""
    logger.info("🚀 MONITORING API DEMO")
    logger.info("=" * 40)
    
    # Initialize simple monitor
    monitor = SimpleMonitor(enable_console_logs=True, enable_metrics=True)
    logger.info("✅ Monitoring initialized")
    
    # Run different scenarios
    await demo_normal_request(monitor)
    await demo_urgent_request(monitor)
    await demo_complex_request(monitor)
    await demo_concurrent_requests(monitor)
    
    # Show overall performance summary
    logger.info("\n" + "=" * 40)
    logger.info("📊 FINAL PERFORMANCE SUMMARY")
    logger.info("=" * 40)
    monitor.print_performance_summary()
    
    # Show individual workflow summaries
    logger.info("\n📋 Individual Workflow Status:")
    for workflow_id in ["normal_request", "urgent_request", "complex_request"]:
        monitor.print_status(workflow_id)
    
    logger.info("\n" + "=" * 40)
    logger.info("🎉 MONITORING API DEMO COMPLETE")
    logger.info("=" * 40)
    logger.info("✅ Easy Integration:")
    logger.info("   • SimpleMonitor() - One-line setup")
    logger.info("   • monitor.get_status() - Get workflow status")
    logger.info("   • monitor.get_performance_summary() - Get metrics")
    logger.info("   • monitor.print_status() - Pretty print status")
    
    logger.info("\n✅ Real-time Monitoring:")
    logger.info("   • Stage state tracking (STARTED → RUNNING → COMPLETED)")
    logger.info("   • Performance metrics collection")
    logger.info("   • Error detection and reporting")
    logger.info("   • Workflow-level status tracking")
    
    logger.info("\n✅ Production Ready:")
    logger.info("   • Thread-safe state management")
    logger.info("   • Configurable observers")
    logger.info("   • Comprehensive error handling")
    logger.info("   • Performance optimization")


if __name__ == "__main__":
    asyncio.run(main())