"""Comprehensive demo showcasing all features of the restored Agent SDK."""

import sys
import os
import time

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, plan, act, Stage,
    agentic_spine,        # Prefect-powered
    agentic_spine_simple, # Simple version
    Context, get_logger, setup_logging
)
from prefect import task

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


def main():
    """Comprehensive demonstration of all Agent SDK features."""
    logger.info("🚀 Agent SDK - Comprehensive Feature Demo")
    logger.info("=" * 60)
    
    # Demo 1: Original flow.py style with Prefect
    demo_original_style()
    
    # Demo 2: Enhanced features
    demo_enhanced_features()
    
    # Demo 3: Performance comparison
    demo_performance_comparison()
    
    # Demo 4: Error handling
    demo_error_handling()
    
    logger.info("\n🎉 All demos completed successfully!")
    logger.info("✅ Prefect integration fully restored and enhanced!")


def demo_original_style():
    """Demo the original flow.py style with Prefect restored."""
    logger.info("\n📋 Demo 1: Original flow.py Style (Prefect Restored)")
    logger.info("-" * 50)
    
    # Original style functions with Prefect tasks
    @perceive
    @task(name="see")
    def see(ctx: dict) -> dict:
        text = str(ctx["input"].get("text", ""))
        return {
            "len": len(text),
            "has_iban": "IBAN" in text.upper(),
            "has_amt": ("€" in text) or ("EUR" in text.upper())
        }

    @reason
    @task(name="think")
    def think(ctx: dict) -> dict:
        needs_review = (not ctx["has_iban"]) or (not ctx["has_amt"]) or (ctx["len"] < 10)
        return {"needs_review": needs_review}

    @plan
    @task(name="decide")
    def decide(ctx: dict) -> dict:
        if ctx["needs_review"]:
            return {"steps": ["route_review"]}
        else:
            return {"steps": ["auto_approve", "post_payment"]}

    @act
    @task(name="do")
    def do(ctx: dict) -> dict:
        return {"actions": [f"exec:: {s}" for s in ctx.get("steps", [])]}

    @perceive
    @task(name="detect_currency")
    def detect_currency(ctx: dict) -> dict:
        text = str(ctx["input"].get("text", ""))
        currency = "EUR" if ("€" in text or "EUR" in text.upper()) else "UNK"
        return {"currency": currency}
    
    # Test case 1: Valid payment (like original)
    logger.info("Test 1: Valid payment with concurrent perception")
    result1 = agentic_spine(
        input_data={"text": "Pay €1000 to IBAN DE89 3704 0044 0532 0130 00"},
        functions=[see, think, decide, do],
        concurrent={Stage.PERCEIVE: True}
    )
    logger.info(f"✅ Result: {result1.get('actions')}")
    
    # Test case 2: Multiple perceivers (like original)
    logger.info("Test 2: Multiple perception tasks running concurrently")
    result2 = agentic_spine(
        input_data={"text": "Pay €1000 to IBAN DE89 3704 0044 0532 0130 00"},
        functions=[see, detect_currency, think, decide, do],
        concurrent={Stage.PERCEIVE: True}
    )
    logger.info(f"✅ Result: Currency={result2.get('currency')}, Actions={result2.get('actions')}")


def demo_enhanced_features():
    """Demo enhanced features beyond the original."""
    logger.info("\n🔧 Demo 2: Enhanced Features")
    logger.info("-" * 50)
    
    # Enhanced functions with better error handling and logging
    @perceive
    @task(name="enhanced_analyze", retries=2)
    def enhanced_analyze(ctx: dict) -> dict:
        text = ctx.get("input", {}).get("text", "")
        logger.info(f"[ENHANCED] Analyzing: {text[:30]}...")
        
        return {
            "word_count": len(text.split()),
            "char_count": len(text),
            "has_urgent": "urgent" in text.lower(),
            "has_question": "?" in text,
            "analysis_version": "enhanced_v1"
        }
    
    @perceive
    @task(name="sentiment_analysis")
    def sentiment_analysis(ctx: dict) -> dict:
        text = ctx.get("input", {}).get("text", "")
        logger.info("[ENHANCED] Performing sentiment analysis...")
        
        positive_words = ["good", "great", "excellent", "amazing", "wonderful"]
        negative_words = ["bad", "terrible", "awful", "horrible", "urgent", "problem"]
        
        text_lower = text.lower()
        positive_score = sum(1 for word in positive_words if word in text_lower)
        negative_score = sum(1 for word in negative_words if word in text_lower)
        
        if positive_score > negative_score:
            sentiment = "positive"
        elif negative_score > positive_score:
            sentiment = "negative"
        else:
            sentiment = "neutral"
        
        return {
            "sentiment": sentiment,
            "positive_score": positive_score,
            "negative_score": negative_score
        }
    
    @reason
    @task(name="enhanced_reasoning")
    def enhanced_reasoning(ctx: dict) -> dict:
        word_count = ctx.get("word_count", 0)
        has_urgent = ctx.get("has_urgent", False)
        has_question = ctx.get("has_question", False)
        sentiment = ctx.get("sentiment", "neutral")
        
        # Complex reasoning logic
        urgency_score = 0
        if has_urgent:
            urgency_score += 3
        if has_question:
            urgency_score += 1
        if sentiment == "negative":
            urgency_score += 2
        if word_count > 50:
            urgency_score += 1
        
        priority = "critical" if urgency_score >= 5 else "high" if urgency_score >= 3 else "normal"
        
        logger.info(f"[ENHANCED] Reasoning: urgency_score={urgency_score}, priority={priority}")
        
        return {
            "priority": priority,
            "urgency_score": urgency_score,
            "reasoning_factors": {
                "has_urgent": has_urgent,
                "has_question": has_question,
                "sentiment": sentiment,
                "word_count": word_count
            }
        }
    
    # Test enhanced features
    test_messages = [
        "This is an urgent problem that needs immediate attention!",
        "Can you help me with this question?",
        "Everything is working great, thank you!",
        "This is just a normal message."
    ]
    
    for i, message in enumerate(test_messages, 1):
        logger.info(f"Enhanced Test {i}: '{message[:30]}...'")
        result = agentic_spine(
            input_data={"text": message},
            functions=[enhanced_analyze, sentiment_analysis, enhanced_reasoning],
            concurrent={Stage.PERCEIVE: True}  # Run analysis tasks concurrently
        )
        logger.info(f"  Priority: {result.get('priority')}")
        logger.info(f"  Sentiment: {result.get('sentiment')}")
        logger.info(f"  Urgency Score: {result.get('urgency_score')}")


def demo_performance_comparison():
    """Demo performance comparison between different execution modes."""
    logger.info("\n⚡ Demo 3: Performance Comparison")
    logger.info("-" * 50)
    
    # Create slow tasks for performance testing
    @perceive
    @task(name="slow_task_1")
    def slow_task_1(ctx: dict) -> dict:
        time.sleep(0.1)
        return {"task_1": "completed"}
    
    @perceive
    @task(name="slow_task_2")
    def slow_task_2(ctx: dict) -> dict:
        time.sleep(0.1)
        return {"task_2": "completed"}
    
    @perceive
    @task(name="slow_task_3")
    def slow_task_3(ctx: dict) -> dict:
        time.sleep(0.1)
        return {"task_3": "completed"}
    
    # Test 1: Sequential Prefect execution
    logger.info("Test 1: Sequential Prefect execution")
    start_time = time.time()
    result_seq = agentic_spine(
        input_data={"test": "performance"},
        functions=[slow_task_1, slow_task_2, slow_task_3],
        concurrent={Stage.PERCEIVE: False}
    )
    seq_time = time.time() - start_time
    logger.info(f"  Sequential time: {seq_time:.3f}s")
    
    # Test 2: Concurrent Prefect execution
    logger.info("Test 2: Concurrent Prefect execution")
    start_time = time.time()
    result_conc = agentic_spine(
        input_data={"test": "performance"},
        functions=[slow_task_1, slow_task_2, slow_task_3],
        concurrent={Stage.PERCEIVE: True}
    )
    conc_time = time.time() - start_time
    logger.info(f"  Concurrent time: {conc_time:.3f}s")
    
    # Test 3: Simple execution (no Prefect)
    @perceive
    def simple_slow_task(ctx: Context) -> dict:
        time.sleep(0.3)  # Equivalent to 3 x 0.1s tasks
        return {"simple_task": "completed"}
    
    logger.info("Test 3: Simple execution (no Prefect)")
    start_time = time.time()
    result_simple = agentic_spine_simple(
        input_data={"test": "performance"},
        functions=[simple_slow_task]
    )
    simple_time = time.time() - start_time
    logger.info(f"  Simple time: {simple_time:.3f}s")
    
    # Performance summary
    speedup = seq_time / conc_time if conc_time > 0 else 0
    logger.info(f"\n📊 Performance Summary:")
    logger.info(f"  Concurrent vs Sequential speedup: {speedup:.2f}x")
    logger.info(f"  Prefect overhead: {(seq_time - simple_time):.3f}s")
    logger.info(f"  Concurrent efficiency: {(simple_time / conc_time):.2f}x vs simple")


def demo_error_handling():
    """Demo error handling capabilities."""
    logger.info("\n🛡️ Demo 4: Error Handling")
    logger.info("-" * 50)
    
    @perceive
    @task(name="reliable_task")
    def reliable_task(ctx: dict) -> dict:
        return {"reliable": True}
    
    @perceive
    @task(name="failing_task", retries=2)
    def failing_task(ctx: dict) -> dict:
        # This will fail but Prefect will retry
        attempt = ctx.get("attempt", 0) + 1
        ctx["attempt"] = attempt
        
        if attempt < 3:
            logger.info(f"[RETRY] Attempt {attempt} failed, retrying...")
            raise Exception(f"Temporary failure on attempt {attempt}")
        
        logger.info(f"[SUCCESS] Succeeded on attempt {attempt}")
        return {"failed_but_recovered": True, "attempts": attempt}
    
    # Test error handling
    logger.info("Testing Prefect retry mechanism...")
    try:
        result = agentic_spine(
            input_data={"test": "error_handling"},
            functions=[reliable_task, failing_task]
        )
        logger.info(f"✅ Error handling successful: {result.get('failed_but_recovered')}")
        logger.info(f"  Recovery attempts: {result.get('attempts')}")
    except Exception as e:
        logger.error(f"❌ Error handling failed: {e}")


if __name__ == "__main__":
    main()