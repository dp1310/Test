"""Test that logging is working correctly throughout the system."""

import sys
import os

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, plan, act,
    agentic_spine_simple,
    Context, get_logger, setup_logging
)

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


@perceive
def test_perceive(ctx: Context) -> dict:
    """Test perception function with logging."""
    logger.info("[PERCEIVE] Processing input data")
    text = ctx.get("input", {}).get("text", "")
    logger.info(f"[PERCEIVE] Text length: {len(text)}")
    return {"perceived": True, "text_length": len(text)}


@reason
def test_reason(ctx: Context) -> dict:
    """Test reasoning function with logging."""
    logger.info("[REASON] Starting reasoning process")
    perceived = ctx.get("perceived", False)
    text_length = ctx.get("text_length", 0)
    
    decision = "approve" if perceived and text_length > 5 else "reject"
    logger.info(f"[REASON] Decision: {decision}")
    
    return {"decision": decision}


@plan
def test_plan(ctx: Context) -> dict:
    """Test planning function with logging."""
    logger.info("[PLAN] Creating action plan")
    decision = ctx.get("decision", "reject")
    
    if decision == "approve":
        actions = ["validate", "process", "complete"]
    else:
        actions = ["review", "reject"]
    
    logger.info(f"[PLAN] Planned actions: {actions}")
    return {"actions": actions}


@act
def test_act(ctx: Context) -> dict:
    """Test action function with logging."""
    logger.info("[ACT] Executing planned actions")
    actions = ctx.get("actions", [])
    
    executed = []
    for action in actions:
        logger.info(f"[ACT] Executing: {action}")
        executed.append(f"completed_{action}")
    
    logger.info(f"[ACT] All actions completed: {len(executed)}")
    return {"executed": executed}


def main():
    """Test logging throughout the entire workflow."""
    logger.info("🔍 LOGGING TEST - All Stages")
    logger.info("=" * 40)
    
    # Test with valid input
    logger.info("Test 1: Valid input (should approve)")
    result1 = agentic_spine_simple(
        input_data={"text": "This is a valid test message"},
        functions=[test_perceive, test_reason, test_plan, test_act]
    )
    logger.info(f"Result 1: {result1.get('decision')} - {len(result1.get('executed', []))} actions")
    
    logger.info("\n" + "-" * 40)
    
    # Test with invalid input
    logger.info("Test 2: Invalid input (should reject)")
    result2 = agentic_spine_simple(
        input_data={"text": "Hi"},
        functions=[test_perceive, test_reason, test_plan, test_act]
    )
    logger.info(f"Result 2: {result2.get('decision')} - {len(result2.get('executed', []))} actions")
    
    logger.info("\n" + "=" * 40)
    logger.info("✅ LOGGING TEST COMPLETED")
    logger.info("All log statements from all stages are visible!")
    logger.info("Logging system is working correctly.")


if __name__ == "__main__":
    main()