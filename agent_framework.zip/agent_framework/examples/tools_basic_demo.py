#!/usr/bin/env python3
"""
Basic tools system demo that works without external API keys.

This example demonstrates the core tools functionality using only
built-in tools that don't require external services.
"""

import sys
import os
import asyncio
import time
from typing import Dict, Any

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    agentic_spine_async, perceive, reason, plan, act,
    Context, Stage, get_logger, setup_logging
)
from agent_sdk.tools.hooks import tool_hook, get_available_tools, execute_tool
from agent_sdk.tools.base import get_tool_registry
from agent_sdk.tools.utils import FileTool
from agent_sdk.tools.api import HTTPTool

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# =============================================================================
# 1. MANUAL TOOL REGISTRATION (for demo without config files)
# =============================================================================

def setup_demo_tools():
    """Set up basic tools for demonstration."""
    registry = get_tool_registry()
    
    # Register file tool
    file_tool = FileTool("file_manager", {
        "base_path": "./demo_data",
        "max_file_size": 1024 * 1024,  # 1MB
        "timeout": 10
    })
    registry.register(file_tool, "utility")
    
    # Register HTTP tool
    http_tool = HTTPTool("http_client", {
        "timeout": 30,
        "verify_ssl": True,
        "headers": {"User-Agent": "Agent-SDK-Demo/1.0"}
    })
    registry.register(http_tool, "api")
    
    logger.info("✅ Demo tools registered:")
    logger.info(f"   Available tools: {registry.list_tools()}")
    logger.info(f"   Categories: {registry.list_categories()}")


# =============================================================================
# 2. TOOL-ENABLED WORKFLOW FUNCTIONS
# =============================================================================

@perceive
@tool_hook
async def collect_data(ctx: Context, tools) -> Dict[str, Any]:
    """Collect data using various tools."""
    logger.info("📥 Collecting data with tools...")
    
    text = ctx.get("input", {}).get("text", "")
    
    # Save input to file
    timestamp = int(time.time())
    filename = f"input_{timestamp}.txt"
    
    file_result = await tools.execute(
        'file_manager',
        operation='write',
        file_path=filename,
        content=f"Input received at {time.ctime()}:\n\n{text}"
    )
    
    # Get some external data via HTTP
    http_result = await tools.execute(
        'http_client',
        method='GET',
        url='https://httpbin.org/json'
    )
    
    # Collect results
    collected_data = {
        "original_text": text,
        "word_count": len(text.split()),
        "char_count": len(text),
        "file_saved": file_result.is_success,
        "filename": filename if file_result.is_success else None,
        "external_data_available": http_result.is_success,
        "collection_timestamp": timestamp
    }
    
    if http_result.is_success:
        collected_data["external_data"] = http_result.data.get('data', {})
    
    logger.info(f"✅ Data collection complete: {len(collected_data)} fields")
    return collected_data

@reason
@tool_hook
async def analyze_collected_data(ctx: Context, tools) -> Dict[str, Any]:
    """Analyze the collected data."""
    logger.info("🔍 Analyzing collected data...")
    
    word_count = ctx.get("word_count", 0)
    char_count = ctx.get("char_count", 0)
    external_data_available = ctx.get("external_data_available", False)
    
    # Perform analysis
    complexity_score = min(word_count / 100, 1.0)
    
    if complexity_score > 0.7:
        complexity = "high"
        recommended_actions = ["detailed_processing", "expert_review", "comprehensive_report"]
    elif complexity_score > 0.3:
        complexity = "medium"
        recommended_actions = ["standard_processing", "basic_report"]
    else:
        complexity = "low"
        recommended_actions = ["quick_processing", "summary"]
    
    # Save analysis to file
    analysis_data = {
        "complexity": complexity,
        "complexity_score": complexity_score,
        "word_count": word_count,
        "char_count": char_count,
        "external_data_available": external_data_available,
        "recommended_actions": recommended_actions,
        "analysis_timestamp": time.time()
    }
    
    analysis_filename = f"analysis_{int(time.time())}.txt"
    await tools.execute(
        'file_manager',
        operation='write',
        file_path=analysis_filename,
        content=f"Analysis Results:\n{analysis_data}"
    )
    
    logger.info(f"✅ Analysis complete: {complexity} complexity")
    return analysis_data

@plan
@tool_hook
async def create_execution_plan(ctx: Context, tools) -> Dict[str, Any]:
    """Create execution plan based on analysis."""
    logger.info("📋 Creating execution plan...")
    
    recommended_actions = ctx.get("recommended_actions", ["default_action"])
    complexity = ctx.get("complexity", "low")
    
    # Create detailed plan
    execution_plan = {
        "actions": recommended_actions,
        "complexity": complexity,
        "estimated_duration": len(recommended_actions) * 0.5,
        "parallel_execution": complexity in ["medium", "high"],
        "plan_timestamp": time.time()
    }
    
    # Save plan to file
    plan_filename = f"plan_{int(time.time())}.txt"
    await tools.execute(
        'file_manager',
        operation='write',
        file_path=plan_filename,
        content=f"Execution Plan:\n{execution_plan}"
    )
    
    logger.info(f"✅ Plan created: {len(recommended_actions)} actions")
    return execution_plan

@act
@tool_hook
async def execute_plan(ctx: Context, tools) -> Dict[str, Any]:
    """Execute the plan using tools."""
    logger.info("⚡ Executing plan with tools...")
    
    actions = ctx.get("actions", [])
    parallel_execution = ctx.get("parallel_execution", False)
    executed_actions = []
    
    if parallel_execution:
        # Execute actions concurrently
        async def execute_action(action):
            await asyncio.sleep(0.1)  # Simulate action execution
            
            # Log action to file
            await tools.execute(
                'file_manager',
                operation='append',
                file_path='execution_log.txt',
                content=f"\n{time.ctime()}: Executed {action}"
            )
            
            return f"✓ {action} (concurrent)"
        
        results = await asyncio.gather(*[execute_action(action) for action in actions])
        executed_actions.extend(results)
    
    else:
        # Execute actions sequentially
        for action in actions:
            await asyncio.sleep(0.1)  # Simulate action execution
            
            # Log action to file
            await tools.execute(
                'file_manager',
                operation='append',
                file_path='execution_log.txt',
                content=f"\n{time.ctime()}: Executed {action}"
            )
            
            executed_actions.append(f"✓ {action} (sequential)")
    
    # Create final report
    report = {
        "executed_actions": executed_actions,
        "total_actions": len(actions),
        "execution_method": "concurrent" if parallel_execution else "sequential",
        "completion_timestamp": time.time(),
        "success": True
    }
    
    # Save final report
    await tools.execute(
        'file_manager',
        operation='write',
        file_path=f'final_report_{int(time.time())}.txt',
        content=f"Execution Report:\n{report}"
    )
    
    logger.info(f"✅ Plan executed: {len(executed_actions)} actions completed")
    return report


# =============================================================================
# 3. DEMONSTRATION WORKFLOWS
# =============================================================================

async def demo_basic_workflow():
    """Demonstrate basic workflow with tools."""
    logger.info("\n🎯 DEMO: Basic Workflow with Tools")
    logger.info("-" * 50)
    
    result = await agentic_spine_async(
        input_data={
            "text": "This is a comprehensive example of how the tools system integrates with agentic workflows to provide powerful capabilities."
        },
        functions=[
            collect_data,
            analyze_collected_data,
            create_execution_plan,
            execute_plan
        ],
        workflow_id="basic_tools_workflow"
    )
    
    logger.info("✅ Basic workflow completed")
    logger.info(f"   Complexity: {result.data.get('complexity', 'unknown')}")
    logger.info(f"   Actions executed: {result.data.get('total_actions', 0)}")
    logger.info(f"   Execution method: {result.data.get('execution_method', 'unknown')}")
    
    return result

async def demo_concurrent_workflow():
    """Demonstrate concurrent workflow with tools."""
    logger.info("\n🔀 DEMO: Concurrent Workflow with Tools")
    logger.info("-" * 50)
    
    # Create multiple data collection tasks
    @perceive
    @tool_hook
    async def collect_web_data(ctx: Context, tools) -> Dict[str, Any]:
        """Collect data from web APIs."""
        logger.info("🌐 Collecting web data...")
        
        # Get data from multiple endpoints
        endpoints = [
            'https://httpbin.org/json',
            'https://httpbin.org/uuid',
            'https://httpbin.org/ip'
        ]
        
        collected = []
        for endpoint in endpoints:
            result = await tools.execute(
                'http_client',
                method='GET',
                url=endpoint
            )
            
            if result.is_success:
                collected.append({
                    "endpoint": endpoint,
                    "data": result.data.get('data', {}),
                    "status": result.data.get('status_code', 0)
                })
        
        return {"web_data": collected, "web_collection_done": True}
    
    @perceive
    @tool_hook
    async def collect_file_data(ctx: Context, tools) -> Dict[str, Any]:
        """Collect data from files."""
        logger.info("📁 Collecting file data...")
        
        # List files in demo directory
        result = await tools.execute(
            'file_manager',
            operation='list',
            file_path='.'
        )
        
        file_info = {"file_count": 0, "total_size": 0}
        
        if result.is_success:
            files = result.data.get('files', [])
            file_info = {
                "file_count": len(files),
                "total_size": sum(f.get('size', 0) or 0 for f in files if f.get('is_file')),
                "files": [f['name'] for f in files if f.get('is_file')][:10]  # First 10 files
            }
        
        return {"file_data": file_info, "file_collection_done": True}
    
    result = await agentic_spine_async(
        input_data={
            "text": "Concurrent data collection from multiple sources"
        },
        functions=[collect_web_data, collect_file_data, analyze_collected_data],
        concurrent={Stage.PERCEIVE: True},  # Run data collection concurrently
        workflow_id="concurrent_tools_workflow"
    )
    
    logger.info("✅ Concurrent workflow completed")
    logger.info(f"   Web data sources: {len(result.data.get('web_data', []))}")
    logger.info(f"   Files found: {result.data.get('file_data', {}).get('file_count', 0)}")
    
    return result

async def demo_tool_error_handling():
    """Demonstrate tool error handling."""
    logger.info("\n💥 DEMO: Tool Error Handling")
    logger.info("-" * 50)
    
    @perceive
    @tool_hook
    async def test_tool_errors(ctx: Context, tools) -> Dict[str, Any]:
        """Test various error scenarios with tools."""
        logger.info("🧪 Testing tool error scenarios...")
        
        error_tests = []
        
        # Test 1: Non-existent tool
        result = await tools.execute('non_existent_tool', param='value')
        error_tests.append({
            "test": "non_existent_tool",
            "success": not result.is_success,
            "error": str(result.error) if result.error else None
        })
        
        # Test 2: Invalid file operation
        result = await tools.execute(
            'file_manager',
            operation='read',
            file_path='/invalid/path/that/does/not/exist.txt'
        )
        error_tests.append({
            "test": "invalid_file_path",
            "success": not result.is_success,
            "error": str(result.error) if result.error else None
        })
        
        # Test 3: Invalid HTTP request
        result = await tools.execute(
            'http_client',
            method='GET',
            url='https://invalid-domain-that-does-not-exist.com'
        )
        error_tests.append({
            "test": "invalid_http_request",
            "success": not result.is_success,
            "error": str(result.error) if result.error else None
        })
        
        # Test 4: Valid operation (should succeed)
        result = await tools.execute(
            'file_manager',
            operation='write',
            file_path='error_test_success.txt',
            content='This should work!'
        )
        error_tests.append({
            "test": "valid_operation",
            "success": result.is_success,
            "error": str(result.error) if result.error else None
        })
        
        successful_tests = sum(1 for test in error_tests if test["success"])
        
        return {
            "error_tests": error_tests,
            "successful_tests": successful_tests,
            "total_tests": len(error_tests),
            "error_handling_complete": True
        }
    
    result = await agentic_spine_async(
        input_data={"text": "Error handling test"},
        functions=[test_tool_errors],
        workflow_id="error_handling_workflow"
    )
    
    logger.info("✅ Error handling test completed")
    logger.info(f"   Successful tests: {result.data.get('successful_tests', 0)}/{result.data.get('total_tests', 0)}")
    
    return result


# =============================================================================
# 4. TOOL SCHEMA AND INSPECTION
# =============================================================================

async def demo_tool_inspection():
    """Demonstrate tool inspection and schema."""
    logger.info("\n🔍 DEMO: Tool Inspection")
    logger.info("-" * 50)
    
    registry = get_tool_registry()
    
    # List all tools
    tools = registry.list_tools()
    logger.info(f"📋 Available tools ({len(tools)}):")
    for tool_name in tools:
        tool = registry.get_tool(tool_name)
        logger.info(f"   • {tool_name} ({tool.__class__.__name__})")
    
    # Show tool schemas
    logger.info("\n📖 Tool Schemas:")
    for tool_name in tools:
        tool = registry.get_tool(tool_name)
        schema = tool.get_schema()
        
        logger.info(f"\n   🔧 {tool_name}:")
        logger.info(f"      Description: {schema.get('description', 'N/A')}")
        logger.info(f"      Required params: {schema.get('required', [])}")
        
        examples = schema.get('examples', [])
        if examples:
            logger.info(f"      Example: {examples[0]}")
    
    # Test tool execution with schema validation
    logger.info("\n🧪 Testing tool execution:")
    
    for tool_name in tools:
        tool = registry.get_tool(tool_name)
        schema = tool.get_schema()
        examples = schema.get('examples', [])
        
        if examples:
            logger.info(f"   Testing {tool_name}...")
            try:
                result = await registry.execute_tool(tool_name, **examples[0])
                status = "✅ Success" if result.is_success else f"❌ Failed: {result.error}"
                logger.info(f"      {status}")
            except Exception as e:
                logger.info(f"      ❌ Exception: {e}")


# =============================================================================
# 5. MAIN DEMONSTRATION
# =============================================================================

async def main():
    """Run all tool system demonstrations."""
    logger.info("🚀 BASIC TOOLS SYSTEM DEMO")
    logger.info("=" * 60)
    
    # Setup demo tools
    setup_demo_tools()
    
    # Run demonstrations
    basic_result = await demo_basic_workflow()
    concurrent_result = await demo_concurrent_workflow()
    error_result = await demo_tool_error_handling()
    
    # Tool inspection
    await demo_tool_inspection()
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("🎉 BASIC TOOLS DEMO SUMMARY")
    logger.info("=" * 60)
    
    logger.info("✅ Core Features Demonstrated:")
    logger.info("   • @tool_hook decorator for automatic tool injection")
    logger.info("   • tools.execute(tool_name, **params) for tool execution")
    logger.info("   • File operations (read, write, append, list)")
    logger.info("   • HTTP requests with error handling")
    logger.info("   • Tool registry and schema inspection")
    logger.info("   • Error handling and graceful degradation")
    logger.info("   • Concurrent tool execution")
    
    logger.info("\n✅ Tool Integration:")
    logger.info("   • Seamless integration with agentic workflows")
    logger.info("   • Automatic tool context injection")
    logger.info("   • Stage-based tool usage")
    logger.info("   • Error recovery and fallback strategies")
    
    logger.info("\n📊 Results:")
    logger.info(f"   • Basic workflow success: {basic_result.data.get('success', False)}")
    logger.info(f"   • Concurrent workflow: {concurrent_result.data.get('file_collection_done', False)}")
    logger.info(f"   • Error handling: {error_result.data.get('error_handling_complete', False)}")
    
    logger.info("\n🎯 Key Benefits:")
    logger.info("   • No manual tool setup required")
    logger.info("   • Automatic error handling and retries")
    logger.info("   • Configurable via YAML and environment variables")
    logger.info("   • Extensible with custom tools")
    logger.info("   • Production-ready with comprehensive logging")
    
    logger.info("\n📁 Generated Files:")
    logger.info("   Check ./demo_data/ for generated files:")
    logger.info("   • input_*.txt - Original input data")
    logger.info("   • analysis_*.txt - Analysis results")
    logger.info("   • plan_*.txt - Execution plans")
    logger.info("   • final_report_*.txt - Final reports")
    logger.info("   • execution_log.txt - Action execution log")


if __name__ == "__main__":
    asyncio.run(main())