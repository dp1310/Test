"""Comparison between Prefect-powered and simple agentic workflows."""

import sys
import os
import time

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, plan, act, Stage,
    agentic_spine,        # Prefect-powered version
    agentic_spine_simple, # Simple version without Prefect
    Context, get_logger, setup_logging
)
from prefect import task

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# Functions that work with both Context and dict (unified interface)
@perceive
def analyze_input(ctx) -> dict:
    """Analyze input (works with both Context and dict)."""
    text = ctx.get("input", {}).get("text", "")
    
    logger.info(f"Analyzing: '{text}'")
    return {
        "word_count": len(text.split()),
        "has_urgent": "urgent" in text.lower(),
        "processor": "standard"
    }

@reason
def make_decision(ctx) -> dict:
    """Make decision based on analysis."""
    urgent = ctx.get("has_urgent", False)
    word_count = ctx.get("word_count", 0)
    
    priority = "high" if urgent else "normal"
    complexity = "high" if word_count > 10 else "low"
    
    logger.info(f"Decision: priority={priority}, complexity={complexity}")
    return {"priority": priority, "complexity": complexity}

@plan
def create_plan(ctx) -> dict:
    """Create action plan."""
    priority = ctx.get("priority", "normal")
    
    actions = ["immediate_action", "escalate"] if priority == "high" else ["standard_action"]
    logger.info(f"Plan created with {len(actions)} actions")
    return {"actions": actions}

@act
def execute_plan(ctx) -> dict:
    """Execute the plan."""
    actions = ctx.get("actions", [])
    
    completed = [f"✓ {action}" for action in actions]
    logger.info(f"Executed {len(completed)} actions")
    return {"completed": completed}


# Prefect-specific versions (decorated as tasks)
@perceive
@task(name="prefect_analyze")
def prefect_analyze_input(ctx: dict) -> dict:
    """Prefect task version of analyze_input."""
    text = ctx.get("input", {}).get("text", "")
    logger.info(f"[PREFECT TASK] Analyzing: '{text}'")
    
    # Simulate some processing time
    time.sleep(0.1)
    
    return {
        "word_count": len(text.split()),
        "has_urgent": "urgent" in text.lower(),
        "processor": "prefect_task"
    }

@perceive
@task(name="prefect_sentiment")
def prefect_analyze_sentiment(ctx: dict) -> dict:
    """Additional Prefect task for sentiment analysis."""
    text = ctx.get("input", {}).get("text", "")
    logger.info(f"[PREFECT TASK] Sentiment analysis: '{text}'")
    
    # Simulate processing time
    time.sleep(0.05)
    
    positive_words = ["good", "great", "excellent", "amazing"]
    negative_words = ["bad", "terrible", "awful", "urgent"]
    
    text_lower = text.lower()
    positive_count = sum(1 for word in positive_words if word in text_lower)
    negative_count = sum(1 for word in negative_words if word in text_lower)
    
    if positive_count > negative_count:
        sentiment = "positive"
    elif negative_count > positive_count:
        sentiment = "negative"
    else:
        sentiment = "neutral"
    
    return {"sentiment": sentiment}

@reason
@task(name="prefect_decision")
def prefect_make_decision(ctx: dict) -> dict:
    """Prefect task version of decision making."""
    urgent = ctx.get("has_urgent", False)
    word_count = ctx.get("word_count", 0)
    sentiment = ctx.get("sentiment", "neutral")
    
    priority = "high" if urgent or sentiment == "negative" else "normal"
    complexity = "high" if word_count > 10 else "low"
    
    logger.info(f"[PREFECT TASK] Decision: priority={priority}, complexity={complexity}")
    return {"priority": priority, "complexity": complexity}


def demo_simple_version():
    """Demo the simple (non-Prefect) version."""
    logger.info("=== SIMPLE VERSION (No Prefect) ===")
    
    start_time = time.time()
    
    result = agentic_spine_simple(
        input_data={"text": "This is an urgent message that needs immediate attention"},
        functions=[analyze_input, make_decision, create_plan, execute_plan]
    )
    
    end_time = time.time()
    
    logger.info(f"Simple version completed in {end_time - start_time:.3f} seconds")
    logger.info(f"Priority: {result.get('priority')}")
    logger.info(f"Processor: {result.get('processor')}")
    logger.info(f"Completed: {result.get('completed')}")
    
    return result, end_time - start_time


def demo_prefect_version():
    """Demo the Prefect-powered version."""
    logger.info("\n=== PREFECT VERSION (With Tasks & Flows) ===")
    
    start_time = time.time()
    
    result = agentic_spine(
        input_data={"text": "This is an urgent message that needs immediate attention"},
        functions=[
            prefect_analyze_input,
            prefect_analyze_sentiment,  # Additional concurrent task
            prefect_make_decision,
            create_plan,  # Can mix Prefect tasks with regular functions
            execute_plan
        ],
        concurrent={
            Stage.PERCEIVE: True,  # Run perception tasks concurrently
            Stage.REASON: False,   # Sequential reasoning
            Stage.PLAN: False,     # Sequential planning
            Stage.ACT: False       # Sequential actions
        }
    )
    
    end_time = time.time()
    
    logger.info(f"Prefect version completed in {end_time - start_time:.3f} seconds")
    logger.info(f"Priority: {result.get('priority')}")
    logger.info(f"Processor: {result.get('processor')}")
    logger.info(f"Sentiment: {result.get('sentiment')}")
    logger.info(f"Completed: {result.get('completed')}")
    
    return result, end_time - start_time


def demo_concurrent_benefits():
    """Demo the benefits of concurrent execution with Prefect."""
    logger.info("\n=== CONCURRENT EXECUTION DEMO ===")
    
    # Multiple perception tasks that can run concurrently
    @perceive
    @task(name="task_1")
    def slow_task_1(ctx: dict) -> dict:
        logger.info("[TASK 1] Starting...")
        time.sleep(0.2)  # Simulate slow operation
        logger.info("[TASK 1] Completed")
        return {"task_1_result": "done"}
    
    @perceive
    @task(name="task_2") 
    def slow_task_2(ctx: dict) -> dict:
        logger.info("[TASK 2] Starting...")
        time.sleep(0.15)  # Simulate slow operation
        logger.info("[TASK 2] Completed")
        return {"task_2_result": "done"}
    
    @perceive
    @task(name="task_3")
    def slow_task_3(ctx: dict) -> dict:
        logger.info("[TASK 3] Starting...")
        time.sleep(0.1)  # Simulate slow operation
        logger.info("[TASK 3] Completed")
        return {"task_3_result": "done"}
    
    # Sequential execution
    logger.info("--- Sequential Execution ---")
    start_time = time.time()
    result_seq = agentic_spine(
        input_data={"text": "test"},
        functions=[slow_task_1, slow_task_2, slow_task_3],
        concurrent={Stage.PERCEIVE: False}  # Sequential
    )
    seq_time = time.time() - start_time
    logger.info(f"Sequential time: {seq_time:.3f} seconds")
    
    # Concurrent execution
    logger.info("\n--- Concurrent Execution ---")
    start_time = time.time()
    result_conc = agentic_spine(
        input_data={"text": "test"},
        functions=[slow_task_1, slow_task_2, slow_task_3],
        concurrent={Stage.PERCEIVE: True}  # Concurrent
    )
    conc_time = time.time() - start_time
    logger.info(f"Concurrent time: {conc_time:.3f} seconds")
    
    speedup = seq_time / conc_time if conc_time > 0 else 0
    logger.info(f"Speedup: {speedup:.2f}x faster with concurrent execution")
    
    return seq_time, conc_time, speedup


def main():
    """Run all demos."""
    logger.info("🚀 Agent SDK: Prefect vs Simple Comparison")
    logger.info("=" * 60)
    
    # Demo simple version
    simple_result, simple_time = demo_simple_version()
    
    # Demo Prefect version
    prefect_result, prefect_time = demo_prefect_version()
    
    # Demo concurrent benefits
    seq_time, conc_time, speedup = demo_concurrent_benefits()
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("📊 SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Simple version time: {simple_time:.3f}s")
    logger.info(f"Prefect version time: {prefect_time:.3f}s")
    logger.info(f"Concurrent speedup: {speedup:.2f}x")
    logger.info("\n✅ Key Benefits of Prefect Integration:")
    logger.info("   • Task orchestration and dependency management")
    logger.info("   • Concurrent execution of independent tasks")
    logger.info("   • Built-in retry and error handling")
    logger.info("   • Workflow monitoring and observability")
    logger.info("   • Caching and memoization")
    logger.info("   • Distributed execution capabilities")
    
    logger.info("\n🎯 Use Cases:")
    logger.info("   • Simple workflows → use agentic_spine_simple()")
    logger.info("   • Complex workflows → use agentic_spine() with Prefect")
    logger.info("   • Concurrent processing → use concurrent={Stage.X: True}")
    logger.info("   • Production systems → use Prefect for reliability")


if __name__ == "__main__":
    main()