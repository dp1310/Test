#!/usr/bin/env python3
"""
Quick Reference Guide for Custom Decorators

This file provides quick copy-paste examples for using the custom decorators
in the agentic framework.
"""

import sys
import os
import asyncio

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk.core.decorators import stage_decorator, async_stage
from agent_sdk.core.stages import Stage

# =============================================================================
# QUICK REFERENCE - Copy these patterns for your own code
# =============================================================================

# 1. CREATE CUSTOM DECORATORS
# ============================

# Flexible decorators (work with both sync and async)
perceive = stage_decorator(Stage.PERCEIVE)
reason = stage_decorator(Stage.REASON)
plan = stage_decorator(Stage.PLAN)
act = stage_decorator(Stage.ACT)

# Async-only decorators (enforce async functions)
async_perceive = async_stage(Stage.PERCEIVE)
async_reason = async_stage(Stage.REASON)
async_plan = async_stage(Stage.PLAN)
async_act = async_stage(Stage.ACT)


# 2. SYNC FUNCTION EXAMPLES
# ==========================

@perceive
def load_data(ctx):
    """Sync data loading - fast, simple operations."""
    data = ctx.get("input", {})
    return {"loaded": True, "data": data}

@reason
def analyze_data(ctx):
    """Sync analysis - quick processing."""
    data = ctx.get("data", {})
    return {"analysis": "complete", "result": "processed"}

@plan
def create_plan(ctx):
    """Sync planning - simple decision making."""
    analysis = ctx.get("analysis")
    return {"plan": ["step1", "step2"], "ready": True}

@act
def execute_actions(ctx):
    """Sync execution - immediate actions."""
    plan = ctx.get("plan", [])
    return {"executed": len(plan), "success": True}


# 3. ASYNC FUNCTION EXAMPLES
# ===========================

@perceive
async def load_data_async(ctx):
    """Async data loading - I/O operations, API calls."""
    await asyncio.sleep(0.1)  # Simulate async I/O
    data = ctx.get("input", {})
    return {"loaded": True, "data": data, "method": "async"}

@reason
async def analyze_with_ml(ctx):
    """Async analysis - ML models, complex processing."""
    await asyncio.sleep(0.2)  # Simulate ML inference
    data = ctx.get("data", {})
    return {"analysis": "ml_complete", "confidence": 0.95}

@plan
async def strategic_planning(ctx):
    """Async planning - database queries, external APIs."""
    await asyncio.sleep(0.1)  # Simulate async operations
    analysis = ctx.get("analysis")
    return {"strategy": "optimal", "plan": ["async_step1", "async_step2"]}

@act
async def execute_concurrent(ctx):
    """Async execution - concurrent operations."""
    plan = ctx.get("plan", [])
    
    # Execute all items concurrently
    async def execute_item(item):
        await asyncio.sleep(0.05)
        return f"completed_{item}"
    
    results = await asyncio.gather(*[execute_item(item) for item in plan])
    return {"executed": results, "success": True}


# 4. ASYNC-ONLY FUNCTION EXAMPLES
# ================================

@async_perceive
async def guaranteed_async_load(ctx):
    """This MUST be async - enforced by async_stage decorator."""
    await asyncio.sleep(0.1)
    return {"loaded": True, "guaranteed_async": True}

@async_reason
async def ml_analysis_only(ctx):
    """Async-only analysis - type safety for ML workflows."""
    await asyncio.sleep(0.2)
    return {"ml_result": "processed", "async_only": True}


# 5. ERROR HANDLING EXAMPLES
# ===========================

def show_error_handling():
    """Examples of proper error handling with decorators."""
    
    try:
        # This will FAIL - async_stage requires async functions
        @async_stage(Stage.REASON)
        def sync_function(ctx):  # ❌ This will raise ValueError
            return {"error": "not_allowed"}
    except ValueError as e:
        print(f"✅ Caught expected error: {e}")
    
    # This works fine - stage_decorator accepts both
    @stage_decorator(Stage.REASON)
    def sync_function_ok(ctx):  # ✅ This works
        return {"success": True}
    
    @stage_decorator(Stage.REASON)
    async def async_function_ok(ctx):  # ✅ This also works
        return {"success": True}


# 6. METADATA INSPECTION
# ======================

def inspect_metadata():
    """Check the metadata added by decorators."""
    
    functions = [load_data, load_data_async, guaranteed_async_load]
    
    for func in functions:
        stage = getattr(func, '_agent_stage', None)
        is_async = getattr(func, '_is_async', None)
        print(f"{func.__name__}: Stage={stage.name if stage else 'None'}, Async={is_async}")


# 7. USAGE WITH AGENTIC SPINE
# ============================

async def example_workflow():
    """Example of using decorated functions with agentic spine."""
    from agent_sdk import agentic_spine_async
    
    # Mix sync and async functions as needed
    result = await agentic_spine_async(
        input_data={"text": "example input"},
        functions=[
            load_data,           # Sync loading
            analyze_with_ml,     # Async ML analysis
            strategic_planning,  # Async planning
            execute_actions      # Sync execution
        ]
    )
    
    return result


# 8. BEST PRACTICES SUMMARY
# ==========================

"""
🎯 WHEN TO USE EACH DECORATOR:

stage_decorator():
✅ Use for flexibility (both sync and async)
✅ Use when migrating from sync to async gradually
✅ Use when you have mixed workloads
✅ Use for automatic function type detection

async_stage():
✅ Use for type safety in async-heavy workflows
✅ Use when building pure async pipelines
✅ Use to enforce async patterns in your team
✅ Use when you need guaranteed async execution

🔧 COMMON PATTERNS:

1. Data Loading:
   - Sync: Simple file reading, in-memory data
   - Async: Database queries, API calls, large file I/O

2. Analysis:
   - Sync: Simple calculations, rule-based logic
   - Async: ML model inference, complex computations

3. Planning:
   - Sync: Simple decision trees, lookup tables
   - Async: Strategic planning with external data

4. Execution:
   - Sync: Simple actions, immediate operations
   - Async: Concurrent operations, I/O-heavy tasks

🚨 ERROR PREVENTION:

- Always handle ValueError from async_stage with sync functions
- Use metadata inspection to verify correct setup
- Test both sync and async paths in mixed workflows
- Prefer async_stage for consistency in async-heavy systems
"""

if __name__ == "__main__":
    print("🚀 Custom Decorators Quick Reference")
    print("=" * 50)
    
    show_error_handling()
    print()
    inspect_metadata()
    
    print("\n✅ Quick reference examples ready to use!")
    print("Copy the patterns above for your own agentic workflows.")