#!/usr/bin/env python3
"""
Comprehensive demo of custom decorators usage in the agentic framework.

This example demonstrates:
1. stage_decorator() - Generic decorator for both sync and async functions
2. async_stage() - Async-only decorator with type safety
3. Mixed workflows with different decorator types
4. Integration with agentic spine execution
5. Error handling and best practices
"""

import sys
import os
import asyncio
import time
import json
from typing import Dict, Any

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    agentic_spine_async, agentic_spine_async_prefect,
    Context, get_logger, setup_logging
)
from agent_sdk.core.decorators import stage_decorator, async_stage
from agent_sdk.core.stages import Stage
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# =============================================================================
# 1. BASIC DECORATOR USAGE - stage_decorator()
# =============================================================================

# Create custom decorators using stage_decorator factory
# This decorator automatically detects sync vs async functions
data_ingestion = stage_decorator(Stage.PERCEIVE)
data_analysis = stage_decorator(Stage.REASON)
action_planning = stage_decorator(Stage.PLAN)
task_execution = stage_decorator(Stage.ACT)

@data_ingestion
def load_data_sync(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Sync data loading function using stage_decorator.
    
    The stage_decorator automatically:
    - Detects this is a sync function
    - Adds logging for execution tracking
    - Sets _agent_stage = Stage.PERCEIVE
    - Sets _is_async = False
    """
    logger.info("🔄 [SYNC INGESTION] Loading data synchronously...")
    
    # Simulate data loading
    input_data = ctx.get("input", {})
    text = input_data.get("text", "")
    
    # Process data
    processed_data = {
        "raw_text": text,
        "word_count": len(text.split()),
        "char_count": len(text),
        "loaded_at": time.time(),
        "method": "sync_ingestion"
    }
    
    logger.info(f"✅ [SYNC INGESTION] Loaded {processed_data['word_count']} words")
    return processed_data

@data_ingestion
async def load_data_async(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Async data loading function using the SAME stage_decorator.
    
    The stage_decorator automatically:
    - Detects this is an async function
    - Uses async wrapper with proper await handling
    - Sets _agent_stage = Stage.PERCEIVE
    - Sets _is_async = True
    """
    logger.info("🔄 [ASYNC INGESTION] Loading data asynchronously...")
    
    # Simulate async I/O operation (database, API call, etc.)
    await asyncio.sleep(0.1)
    
    input_data = ctx.get("input", {})
    text = input_data.get("text", "")
    
    # Simulate more complex async processing
    processed_data = {
        "raw_text": text,
        "word_count": len(text.split()),
        "char_count": len(text),
        "sentiment_score": 0.8 if "good" in text.lower() else 0.3,
        "loaded_at": time.time(),
        "method": "async_ingestion"
    }
    
    logger.info(f"✅ [ASYNC INGESTION] Loaded {processed_data['word_count']} words with sentiment {processed_data['sentiment_score']}")
    return processed_data


# =============================================================================
# 2. ASYNC-ONLY DECORATOR USAGE - async_stage()
# =============================================================================

# Create async-only decorators using async_stage
# These decorators ENFORCE that functions must be async
ml_analysis = async_stage(Stage.REASON)
strategic_planning = async_stage(Stage.PLAN)

@ml_analysis
async def analyze_with_ml(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Async ML analysis function using async_stage decorator.
    
    The async_stage decorator:
    - REQUIRES the function to be async (raises ValueError if not)
    - Provides type safety for async-only workflows
    - Adds async-specific logging
    - Sets _agent_stage = Stage.REASON
    - Sets _is_async = True
    """
    logger.info("🧠 [ML ANALYSIS] Starting machine learning analysis...")
    
    # Simulate ML model inference (async operation)
    await asyncio.sleep(0.2)
    
    word_count = ctx.get("word_count", 0)
    sentiment_score = ctx.get("sentiment_score", 0.5)
    
    # Simulate complex ML analysis
    analysis_result = {
        "complexity_score": min(word_count / 10, 1.0),
        "sentiment_category": "positive" if sentiment_score > 0.6 else "neutral" if sentiment_score > 0.4 else "negative",
        "confidence": 0.95,
        "processing_time": 0.2,
        "model_version": "v2.1.0"
    }
    
    logger.info(f"✅ [ML ANALYSIS] Analysis complete - {analysis_result['sentiment_category']} sentiment with {analysis_result['confidence']} confidence")
    return analysis_result

@strategic_planning
async def create_strategic_plan(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Async strategic planning function using async_stage decorator.
    
    This demonstrates how async_stage ensures all planning functions
    are async, providing consistency in async-heavy workflows.
    """
    logger.info("📋 [STRATEGIC PLANNING] Creating strategic plan...")
    
    # Simulate async planning operations (database queries, external APIs)
    await asyncio.sleep(0.15)
    
    sentiment_category = ctx.get("sentiment_category", "neutral")
    complexity_score = ctx.get("complexity_score", 0.5)
    confidence = ctx.get("confidence", 0.5)
    
    # Create strategic plan based on analysis
    if sentiment_category == "positive" and confidence > 0.8:
        plan = {
            "strategy": "amplify_positive",
            "actions": ["share_content", "engage_audience", "create_similar"],
            "priority": "high",
            "timeline": "immediate"
        }
    elif sentiment_category == "negative" and confidence > 0.8:
        plan = {
            "strategy": "damage_control",
            "actions": ["review_content", "address_concerns", "improve_messaging"],
            "priority": "urgent",
            "timeline": "immediate"
        }
    else:
        plan = {
            "strategy": "monitor_and_optimize",
            "actions": ["collect_feedback", "analyze_trends", "gradual_improvement"],
            "priority": "medium",
            "timeline": "scheduled"
        }
    
    logger.info(f"✅ [STRATEGIC PLANNING] Plan created - {plan['strategy']} with {plan['priority']} priority")
    return plan


# =============================================================================
# 3. MIXED DECORATOR USAGE - Flexible Execution
# =============================================================================

@task_execution
def execute_sync_actions(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Sync execution function - demonstrates mixing sync and async in same workflow.
    
    Using stage_decorator allows flexibility to have both sync and async
    functions in the same stage, chosen based on the specific needs.
    """
    logger.info("⚡ [SYNC EXECUTION] Executing synchronous actions...")
    
    actions = ctx.get("actions", [])
    strategy = ctx.get("strategy", "unknown")
    
    # Execute actions synchronously
    executed_actions = []
    for action in actions:
        logger.info(f"🔧 [SYNC EXECUTION] Executing: {action}")
        executed_actions.append({
            "action": action,
            "status": "completed",
            "execution_time": 0.01,
            "method": "sync"
        })
    
    result = {
        "strategy_executed": strategy,
        "actions_completed": executed_actions,
        "total_actions": len(executed_actions),
        "execution_method": "synchronous",
        "success": True
    }
    
    logger.info(f"✅ [SYNC EXECUTION] Completed {len(executed_actions)} actions synchronously")
    return result

@task_execution
async def execute_async_actions(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Async execution function - demonstrates the same stage with async processing.
    
    This shows how stage_decorator provides flexibility to choose sync or async
    based on the specific requirements of each function.
    """
    logger.info("⚡ [ASYNC EXECUTION] Executing asynchronous actions...")
    
    actions = ctx.get("actions", [])
    strategy = ctx.get("strategy", "unknown")
    
    # Execute actions asynchronously with concurrent processing
    async def execute_single_action(action: str) -> Dict[str, Any]:
        await asyncio.sleep(0.05)  # Simulate async I/O
        logger.info(f"🔧 [ASYNC EXECUTION] Executed: {action}")
        return {
            "action": action,
            "status": "completed",
            "execution_time": 0.05,
            "method": "async"
        }
    
    # Execute all actions concurrently
    executed_actions = await asyncio.gather(*[
        execute_single_action(action) for action in actions
    ])
    
    result = {
        "strategy_executed": strategy,
        "actions_completed": executed_actions,
        "total_actions": len(executed_actions),
        "execution_method": "asynchronous_concurrent",
        "success": True
    }
    
    logger.info(f"✅ [ASYNC EXECUTION] Completed {len(executed_actions)} actions concurrently")
    return result


# =============================================================================
# 4. ERROR HANDLING DEMONSTRATION
# =============================================================================

def demonstrate_decorator_errors():
    """
    Demonstrate error handling with decorators.
    
    This shows what happens when you try to use async_stage with sync functions.
    """
    logger.info("🚨 [ERROR DEMO] Demonstrating decorator error handling...")
    
    try:
        # This will raise ValueError because async_stage requires async functions
        @async_stage(Stage.REASON)
        def sync_function_with_async_decorator(ctx):
            return {"error": "This should not work"}
        
    except ValueError as e:
        logger.info(f"✅ [ERROR DEMO] Caught expected error: {e}")
    
    logger.info("✅ [ERROR DEMO] Error handling demonstration complete")


# =============================================================================
# 5. METADATA INSPECTION
# =============================================================================

def inspect_decorator_metadata():
    """
    Inspect the metadata added by decorators.
    
    This shows how decorators add important metadata that the framework uses.
    """
    logger.info("🔍 [METADATA] Inspecting decorator metadata...")
    
    functions_to_inspect = [
        load_data_sync,
        load_data_async,
        analyze_with_ml,
        create_strategic_plan,
        execute_sync_actions,
        execute_async_actions
    ]
    
    for func in functions_to_inspect:
        stage = getattr(func, '_agent_stage', 'Unknown')
        is_async = getattr(func, '_is_async', 'Unknown')
        logger.info(f"📊 [METADATA] {func.__name__}: stage={stage.name if hasattr(stage, 'name') else stage}, async={is_async}")
    
    logger.info("✅ [METADATA] Metadata inspection complete")


# =============================================================================
# 6. WORKFLOW DEMONSTRATIONS
# =============================================================================

async def demo_sync_workflow():
    """Demonstrate workflow with sync functions using simple async spine."""
    logger.info("\n🔄 [SYNC WORKFLOW] Starting sync-focused workflow...")
    
    result = await agentic_spine_async(
        input_data={"text": "This is a good example of sync processing"},
        functions=[
            load_data_sync,      # Sync ingestion
            execute_sync_actions # Sync execution
        ]
    )
    
    logger.info(f"✅ [SYNC WORKFLOW] Result: {result.data.get('success', False)}")
    return result

async def demo_async_workflow():
    """Demonstrate workflow with async functions using async Prefect spine."""
    logger.info("\n🔄 [ASYNC WORKFLOW] Starting async-focused workflow...")
    
    # Convert to Prefect tasks for async Prefect spine
    @task(name="async_ingestion", cache_policy=NO_CACHE)
    async def prefect_load_data_async(ctx: dict) -> dict:
        return await load_data_async(ctx)
    
    @task(name="ml_analysis", cache_policy=NO_CACHE)
    async def prefect_analyze_with_ml(ctx: dict) -> dict:
        return await analyze_with_ml(ctx)
    
    @task(name="strategic_planning", cache_policy=NO_CACHE)
    async def prefect_create_strategic_plan(ctx: dict) -> dict:
        return await create_strategic_plan(ctx)
    
    @task(name="async_execution", cache_policy=NO_CACHE)
    async def prefect_execute_async_actions(ctx: dict) -> dict:
        return await execute_async_actions(ctx)
    
    result = await agentic_spine_async_prefect(
        input_data={"text": "This is a good example of async processing with ML analysis"},
        functions=[
            prefect_load_data_async,
            prefect_analyze_with_ml,
            prefect_create_strategic_plan,
            prefect_execute_async_actions
        ],
        concurrent={
            Stage.PERCEIVE: False,  # Sequential ingestion
            Stage.REASON: False,    # Sequential analysis
            Stage.PLAN: False,      # Sequential planning
            Stage.ACT: False        # Sequential execution
        }
    )
    
    logger.info(f"✅ [ASYNC WORKFLOW] Result: {result.data.get('success', False)}")
    return result

async def demo_mixed_workflow():
    """Demonstrate mixed sync/async workflow."""
    logger.info("\n🔄 [MIXED WORKFLOW] Starting mixed sync/async workflow...")
    
    result = await agentic_spine_async(
        input_data={"text": "This demonstrates mixed sync and async processing"},
        functions=[
            load_data_sync,        # Sync ingestion
            analyze_with_ml,       # Async analysis (will be awaited properly)
            execute_sync_actions   # Sync execution
        ]
    )
    
    logger.info(f"✅ [MIXED WORKFLOW] Result: {result.data.get('success', False)}")
    return result


# =============================================================================
# 7. MAIN DEMONSTRATION
# =============================================================================

async def main():
    """Run all decorator usage demonstrations."""
    logger.info("🚀 DECORATOR USAGE DEMONSTRATION")
    logger.info("=" * 60)
    
    # 1. Error handling demonstration
    demonstrate_decorator_errors()
    
    # 2. Metadata inspection
    inspect_decorator_metadata()
    
    # 3. Workflow demonstrations
    sync_result = await demo_sync_workflow()
    async_result = await demo_async_workflow()
    mixed_result = await demo_mixed_workflow()
    
    # 4. Summary
    logger.info("\n" + "=" * 60)
    logger.info("🎉 DECORATOR DEMONSTRATION SUMMARY")
    logger.info("=" * 60)
    logger.info("✅ stage_decorator() - Flexible sync/async detection")
    logger.info("✅ async_stage() - Type-safe async-only functions")
    logger.info("✅ Mixed workflows - Sync and async in same pipeline")
    logger.info("✅ Error handling - Proper validation and feedback")
    logger.info("✅ Metadata inspection - Framework integration")
    logger.info("✅ Multiple spine types - Simple async and Prefect async")
    
    logger.info(f"\n📊 RESULTS:")
    logger.info(f"   • Sync workflow success: {sync_result.data.get('success', False)}")
    logger.info(f"   • Async workflow success: {async_result.data.get('success', False)}")
    logger.info(f"   • Mixed workflow success: {mixed_result.data.get('success', False)}")
    
    logger.info("\n🎯 KEY TAKEAWAYS:")
    logger.info("   • Use stage_decorator() for flexibility and gradual migration")
    logger.info("   • Use async_stage() for type safety in async-heavy workflows")
    logger.info("   • Both decorators add essential metadata for the framework")
    logger.info("   • Mix sync and async functions based on specific needs")
    logger.info("   • Proper error handling prevents runtime issues")


if __name__ == "__main__":
    asyncio.run(main())