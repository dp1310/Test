"""Tests for demo implementations."""

import pytest
import asyncio
from agent_framework.demo import PaymentProcessor, AsyncPaymentProcessor


class TestPaymentProcessor:
    """Test synchronous payment processor."""
    
    def test_valid_payment_processing(self):
        """Test processing of valid payment."""
        processor = PaymentProcessor()
        result = processor.process_payment("Pay €1000 to IBAN DE89 3704 0044 0532 0130 00")
        
        assert result.get("has_iban") is True
        assert result.get("has_amount") is True
        assert result.get("currency") == "EUR"
        assert result.get("needs_review") is False
        assert result.get("execution_status") == "COMPLETED"
        assert "auto_approve" in str(result.get("action_steps", []))
    
    def test_invalid_payment_processing(self):
        """Test processing of invalid payment."""
        processor = PaymentProcessor()
        result = processor.process_payment("Pay money")
        
        assert result.get("has_iban") is False
        assert result.get("has_amount") is False
        assert result.get("needs_review") is True
        assert result.get("execution_status") == "COMPLETED"
        assert "route_to_manual_review" in str(result.get("action_steps", []))
    
    def test_partial_payment_info(self):
        """Test processing of payment with partial information."""
        processor = PaymentProcessor()
        result = processor.process_payment("€500 payment")
        
        assert result.get("has_iban") is False
        assert result.get("has_amount") is True
        assert result.get("currency") == "EUR"
        assert result.get("needs_review") is True
    
    def test_different_currencies(self):
        """Test currency detection for different currencies."""
        processor = PaymentProcessor()
        
        # Test USD
        result_usd = processor.process_payment("Pay $500 USD to account")
        assert result_usd.get("currency") == "USD"
        
        # Test GBP
        result_gbp = processor.process_payment("Pay £300 GBP to account")
        assert result_gbp.get("currency") == "GBP"
        
        # Test unknown currency
        result_unknown = processor.process_payment("Pay 500 to account")
        assert result_unknown.get("currency") == "UNKNOWN"


class TestAsyncPaymentProcessor:
    """Test asynchronous payment processor."""
    
    @pytest.mark.asyncio
    async def test_async_valid_payment_processing(self):
        """Test async processing of valid payment."""
        processor = AsyncPaymentProcessor()
        result = await processor.process_payment_async("Pay €1000 to IBAN DE89 3704 0044 0532 0130 00")
        
        assert result.get("has_iban") is True
        assert result.get("has_amount") is True
        assert result.get("currency") == "EUR"
        assert result.get("extracted_amount") == 1000.0
        assert result.get("amount_found") is True
        assert result.get("processing_mode") == "async"
        assert result.get("execution_status") == "ALL_COMPLETED"
    
    @pytest.mark.asyncio
    async def test_async_invalid_payment_processing(self):
        """Test async processing of invalid payment."""
        processor = AsyncPaymentProcessor()
        result = await processor.process_payment_async("Invalid payment")
        
        assert result.get("has_iban") is False
        assert result.get("has_amount") is False
        assert result.get("currency") == "UNKNOWN"
        assert result.get("extracted_amount") is None
        assert result.get("needs_review") is True
        assert len(result.get("risk_factors", [])) > 0
    
    @pytest.mark.asyncio
    async def test_async_high_amount_payment(self):
        """Test async processing of high amount payment."""
        processor = AsyncPaymentProcessor()
        result = await processor.process_payment_async("Pay €15000 to IBAN DE89 3704 0044 0532 0130 00")
        
        assert result.get("extracted_amount") == 15000.0
        assert "high_amount" in result.get("risk_factors", [])
        assert result.get("risk_score", 0) > 0.5
        assert "additional_verification" in str(result.get("action_steps", []))
    
    @pytest.mark.asyncio
    async def test_async_concurrent_processing(self):
        """Test concurrent processing of multiple payments."""
        processor = AsyncPaymentProcessor()
        
        payments = [
            "Pay €1000 to IBAN DE89 3704 0044 0532 0130 00",
            "Pay $500 USD to account",
            "Invalid payment"
        ]
        
        # Process all payments concurrently
        tasks = [processor.process_payment_async(payment) for payment in payments]
        results = await asyncio.gather(*tasks)
        
        assert len(results) == 3
        
        # First payment should be valid
        assert results[0].get("currency") == "EUR"
        assert results[0].get("needs_review") is False
        
        # Second payment should have missing IBAN
        assert results[1].get("currency") == "USD"
        assert results[1].get("needs_review") is True
        
        # Third payment should be invalid
        assert results[2].get("needs_review") is True
        assert len(results[2].get("risk_factors", [])) > 2
    
    @pytest.mark.asyncio
    async def test_async_timing_attributes(self):
        """Test that async processor includes timing information."""
        processor = AsyncPaymentProcessor()
        result = await processor.process_payment_async("Pay €1000 to IBAN DE89 3704 0044 0532 0130 00")
        
        # Check for timing attributes
        assert "assessment_timestamp" in result.data
        assert "plan_created_at" in result.data
        assert "completion_timestamp" in result.data
        assert "total_execution_time" in result.data
        
        # Verify timing makes sense
        assert result.get("total_execution_time", 0) > 0
    
    @pytest.mark.asyncio
    async def test_async_currency_confidence(self):
        """Test currency confidence scoring in async processor."""
        processor = AsyncPaymentProcessor()
        
        # Test with clear currency
        result_clear = await processor.process_payment_async("Pay €1000 to account")
        assert result_clear.get("currency_confidence", 0) > 0.9
        
        # Test with unclear currency
        result_unclear = await processor.process_payment_async("Pay 1000 to account")
        assert result_unclear.get("currency_confidence", 1) < 0.2


class TestProcessorComparison:
    """Test comparison between sync and async processors."""
    
    @pytest.mark.asyncio
    async def test_sync_vs_async_results_consistency(self):
        """Test that sync and async processors produce consistent results."""
        sync_processor = PaymentProcessor()
        async_processor = AsyncPaymentProcessor()
        
        test_payment = "Pay €1000 to IBAN DE89 3704 0044 0532 0130 00"
        
        sync_result = sync_processor.process_payment(test_payment)
        async_result = await async_processor.process_payment_async(test_payment)
        
        # Both should detect the same basic features
        assert sync_result.get("has_iban") == async_result.get("has_iban")
        assert sync_result.get("has_amount") == async_result.get("has_amount")
        assert sync_result.get("currency") == async_result.get("currency")
        
        # Both should reach similar conclusions about review necessity
        # (may differ slightly due to different risk assessment logic)
        sync_needs_review = sync_result.get("needs_review", True)
        async_needs_review = async_result.get("needs_review", True)
        
        # For a valid payment, both should generally not need review
        assert sync_needs_review is False
        # Async might be more strict, but should still be reasonable
        assert isinstance(async_needs_review, bool)