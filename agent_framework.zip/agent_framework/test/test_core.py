"""Tests for core agent SDK functionality."""

import pytest
import asyncio
from typing import Dict, Any

from agent_framework.agent_sdk import (
    Stage, perceive, reason, plan, act,
    agentic_spine, agentic_spine_async,
    Context, merge_context
)


class TestStages:
    """Test stage decorators and functionality."""
    
    def test_stage_decorator_assignment(self):
        """Test that stage decorators assign correct stage."""
        @perceive
        def test_perceive_fn(ctx: Context) -> Dict[str, Any]:
            return {"perceived": True}
        
        @reason
        def test_reason_fn(ctx: Context) -> Dict[str, Any]:
            return {"reasoned": True}
        
        assert hasattr(test_perceive_fn, "_agent_stage")
        assert test_perceive_fn._agent_stage == Stage.PERCEIVE
        assert test_reason_fn._agent_stage == Stage.REASON
    
    def test_stage_function_execution(self):
        """Test that decorated functions execute correctly."""
        @perceive
        def test_fn(ctx: Context) -> Dict[str, Any]:
            return {"test": "value"}
        
        ctx = Context(data={"input": "test"})
        result = test_fn(ctx)
        
        assert result == {"test": "value"}


class TestContext:
    """Test Context class functionality."""
    
    def test_context_creation(self):
        """Test context creation and access."""
        ctx = Context(data={"key": "value"})
        
        assert ctx.get("key") == "value"
        assert ctx.get("missing", "default") == "default"
        assert ctx["key"] == "value"
        assert "key" in ctx
        assert "missing" not in ctx
    
    def test_context_immutability(self):
        """Test that context operations return new instances."""
        ctx1 = Context(data={"key": "value"})
        ctx2 = ctx1.with_data(new_key="new_value")
        
        assert ctx1.get("new_key") is None
        assert ctx2.get("new_key") == "new_value"
        assert ctx2.get("key") == "value"
    
    def test_context_merge(self):
        """Test context merging functionality."""
        ctx1 = Context(data={"key1": "value1"})
        ctx2 = merge_context(ctx1, {"key2": "value2"})
        
        assert ctx2.get("key1") == "value1"
        assert ctx2.get("key2") == "value2"
        assert ctx1.get("key2") is None  # Original unchanged
    
    def test_context_merge_non_dict(self):
        """Test merging non-dict values into context."""
        ctx1 = Context(data={"key": "value"})
        ctx2 = merge_context(ctx1, "string_value")
        
        assert ctx2.get("result_str") == "string_value"
        assert ctx2.get("key") == "value"


class TestSpine:
    """Test agentic spine functionality."""
    
    def test_sync_spine_execution(self):
        """Test synchronous spine execution."""
        @perceive
        def perceive_fn(ctx: Context) -> Dict[str, Any]:
            return {"perceived": True}
        
        @reason
        def reason_fn(ctx: Context) -> Dict[str, Any]:
            return {"reasoned": ctx.get("perceived", False)}
        
        @plan
        def plan_fn(ctx: Context) -> Dict[str, Any]:
            return {"planned": ctx.get("reasoned", False)}
        
        @act
        def act_fn(ctx: Context) -> Dict[str, Any]:
            return {"acted": ctx.get("planned", False)}
        
        result = agentic_spine(
            input_data={"test": "data"},
            functions=[perceive_fn, reason_fn, plan_fn, act_fn]
        )
        
        assert result.get("perceived") is True
        assert result.get("reasoned") is True
        assert result.get("planned") is True
        assert result.get("acted") is True
        assert result.get("input") == {"test": "data"}
    
    def test_sync_spine_with_multiple_perceive(self):
        """Test spine with multiple functions in same stage."""
        @perceive
        def perceive1(ctx: Context) -> Dict[str, Any]:
            return {"p1": "value1"}
        
        @perceive
        def perceive2(ctx: Context) -> Dict[str, Any]:
            return {"p2": "value2"}
        
        @reason
        def reason_fn(ctx: Context) -> Dict[str, Any]:
            return {"combined": f"{ctx.get('p1')}-{ctx.get('p2')}"}
        
        result = agentic_spine(
            input_data={"test": "data"},
            functions=[perceive1, perceive2, reason_fn]
        )
        
        assert result.get("p1") == "value1"
        assert result.get("p2") == "value2"
        assert result.get("combined") == "value1-value2"
    
    @pytest.mark.asyncio
    async def test_async_spine_execution(self):
        """Test asynchronous spine execution."""
        @perceive
        async def async_perceive(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.01)
            return {"async_perceived": True}
        
        @reason
        def sync_reason(ctx: Context) -> Dict[str, Any]:
            return {"reasoned": ctx.get("async_perceived", False)}
        
        result = await agentic_spine_async(
            input_data={"test": "async_data"},
            functions=[async_perceive, sync_reason]
        )
        
        assert result.get("async_perceived") is True
        assert result.get("reasoned") is True
    
    @pytest.mark.asyncio
    async def test_async_spine_concurrent_execution(self):
        """Test concurrent execution in async spine."""
        execution_order = []
        
        @perceive
        async def perceive1(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.02)
            execution_order.append("p1")
            return {"p1": "done"}
        
        @perceive
        async def perceive2(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.01)
            execution_order.append("p2")
            return {"p2": "done"}
        
        result = await agentic_spine_async(
            input_data={"test": "concurrent"},
            functions=[perceive1, perceive2],
            concurrent={Stage.PERCEIVE: True}
        )
        
        # p2 should complete before p1 due to shorter sleep
        assert execution_order == ["p2", "p1"]
        assert result.get("p1") == "done"
        assert result.get("p2") == "done"
    
    def test_spine_with_initial_context(self):
        """Test spine execution with initial context."""
        @perceive
        def perceive_fn(ctx: Context) -> Dict[str, Any]:
            return {"multiplier": ctx.get("initial_value", 1) * 2}
        
        result = agentic_spine(
            input_data={"test": "data"},
            functions=[perceive_fn],
            initial_context={"initial_value": 5}
        )
        
        assert result.get("multiplier") == 10
        assert result.get("initial_value") == 5
    
    def test_spine_empty_functions(self):
        """Test spine execution with empty function list."""
        result = agentic_spine(
            input_data={"test": "data"},
            functions=[]
        )
        
        assert result.get("input") == {"test": "data"}
    
    def test_spine_missing_stage_functions(self):
        """Test spine execution when some stages have no functions."""
        @perceive
        def perceive_fn(ctx: Context) -> Dict[str, Any]:
            return {"perceived": True}
        
        @act
        def act_fn(ctx: Context) -> Dict[str, Any]:
            return {"acted": True}
        
        # Missing REASON and PLAN stages
        result = agentic_spine(
            input_data={"test": "data"},
            functions=[perceive_fn, act_fn]
        )
        
        assert result.get("perceived") is True
        assert result.get("acted") is True


class TestErrorHandling:
    """Test error handling in the framework."""
    
    def test_function_without_stage_decorator(self):
        """Test handling of functions without stage decorators."""
        def undecorated_fn(ctx: Context) -> Dict[str, Any]:
            return {"undecorated": True}
        
        @perceive
        def decorated_fn(ctx: Context) -> Dict[str, Any]:
            return {"decorated": True}
        
        # Should work but log warning for undecorated function
        result = agentic_spine(
            input_data={"test": "data"},
            functions=[undecorated_fn, decorated_fn]
        )
        
        assert result.get("decorated") is True
        # Undecorated function should be ignored
        assert result.get("undecorated") is None
    
    def test_function_exception_handling(self):
        """Test that exceptions in functions are properly raised."""
        @perceive
        def failing_fn(ctx: Context) -> Dict[str, Any]:
            raise ValueError("Test error")
        
        with pytest.raises(ValueError, match="Test error"):
            agentic_spine(
                input_data={"test": "data"},
                functions=[failing_fn]
            )
    
    @pytest.mark.asyncio
    async def test_async_function_exception_handling(self):
        """Test exception handling in async functions."""
        @perceive
        async def failing_async_fn(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.01)
            raise RuntimeError("Async test error")
        
        with pytest.raises(RuntimeError, match="Async test error"):
            await agentic_spine_async(
                input_data={"test": "data"},
                functions=[failing_async_fn]
            )