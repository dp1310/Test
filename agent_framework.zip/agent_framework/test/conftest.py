"""Pytest configuration and fixtures."""

import pytest
import logging
from agent_framework.agent_sdk.utils.logging import setup_logging


@pytest.fixture(scope="session", autouse=True)
def setup_test_logging():
    """Setup logging for tests."""
    setup_logging(level="WARNING")  # Reduce noise during tests


@pytest.fixture
def sample_payment_texts():
    """Sample payment texts for testing."""
    return {
        "valid_eur": "Pay €1000 to IBAN DE89 3704 0044 0532 0130 00",
        "valid_usd": "Transfer $2500 USD to IBAN US12 3456 7890 1234 5678 90",
        "valid_gbp": "Send £750 GBP to IBAN GB82 WEST 1234 5698 7654 32",
        "missing_iban": "Pay €500 to John Doe",
        "missing_amount": "Transfer to IBAN DE89 3704 0044 0532 0130 00",
        "high_amount": "Pay €50000 to IBAN DE89 3704 0044 0532 0130 00",
        "invalid": "Invalid payment request",
        "empty": "",
        "short": "Pay €10"
    }


@pytest.fixture
def sample_contexts():
    """Sample contexts for testing."""
    from agent_framework.agent_sdk import Context
    
    return {
        "empty": Context(),
        "basic": Context(data={"input": {"text": "test"}}),
        "with_payment": Context(data={
            "input": {"text": "Pay €1000 to IBAN DE89 3704 0044 0532 0130 00"},
            "has_iban": True,
            "has_amount": True,
            "currency": "EUR"
        }),
        "needs_review": Context(data={
            "input": {"text": "Pay money"},
            "has_iban": False,
            "has_amount": False,
            "currency": "UNKNOWN",
            "needs_review": True
        })
    }