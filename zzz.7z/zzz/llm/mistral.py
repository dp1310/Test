"""Mistral AI LLM tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional
from ..base import ToolError
from .base import BaseLLMTool, _extract_chunk_content

logger = logging.getLogger(__name__)


# Pure functions for Mistral operations
def _create_mistral_messages(prompt: str, system_prompt: Optional[str] = None):
    """Create message list for Mistral API."""
    try:
        from mistralai.models.chat_completion import ChatMessage
        messages = []
        if system_prompt:
            messages.append(ChatMessage(role="system", content=system_prompt))
        messages.append(ChatMessage(role="user", content=prompt))
        return messages
    except ImportError:
        raise ToolError("Mistral AI library not installed. Run: pip install mistralai")


def _extract_mistral_response(response: Any) -> tuple:
    """Extract content and metadata from Mistral response."""
    if hasattr(response, 'choices'):
        # Real API response
        content = response.choices[0].message.content
        usage = {
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens
        }
        finish_reason = response.choices[0].finish_reason
    elif isinstance(response, dict) and 'choices' in response:
        # Mock dictionary response
        content = response['choices'][0]['message']['content']
        usage = response.get('usage', {})
        finish_reason = response['choices'][0].get('finish_reason')
    else:
        raise ValueError(f"Unexpected response format: {type(response)}")
    
    return content, usage, finish_reason


async def _process_mistral_stream(client, model: str, messages, max_tokens: int, temperature: float) -> str:
    """Process streaming response from Mistral."""
    response_text = ""
    async for chunk in client.chat_stream(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature
    ):
        content = _extract_chunk_content(chunk)
        if content:
            response_text += content
    return response_text


class MistralTool(BaseLLMTool):
    """Mistral AI tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        # Set default model if not provided
        if not self.model:
            self.model = 'mistral-medium'
        
    async def execute(self, prompt: str, system_prompt: str = None,
                     max_tokens: int = None, temperature: float = None,
                     stream: bool = False, **kwargs):
        """Execute Mistral API call with functional approach."""
        try:
            # Import Mistral client
            try:
                from mistralai.async_client import MistralAsyncClient
            except ImportError:
                raise ToolError("Mistral AI library not installed. Run: pip install mistralai", self.name)
            
            # Initialize client
            client = MistralAsyncClient(api_key=self.api_key)
            
            # Get standardized parameters
            request_max_tokens, request_temperature = self._get_request_params(max_tokens, temperature)
            
            # Prepare request using pure functions
            messages = _create_mistral_messages(prompt, system_prompt)
            
            # Make API call
            if stream:
                response_text = await _process_mistral_stream(
                    client, self.model, messages, request_max_tokens, request_temperature
                )
                return self._create_success_result(response_text, stream=True)
            else:
                response = await client.chat(
                    model=self.model,
                    messages=messages,
                    max_tokens=request_max_tokens,
                    temperature=request_temperature
                )
                
                content, usage, finish_reason = _extract_mistral_response(response)
                return self._create_success_result(content, usage, finish_reason)
            
        except Exception as e:
            return self._create_error_result(e, "Mistral")