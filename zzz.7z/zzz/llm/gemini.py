"""Google Gemini LLM tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional
from ..base import ToolError
from .base import BaseLLMTool

logger = logging.getLogger(__name__)


# Pure functions for Gemini operations
def _create_full_prompt(prompt: str, system_prompt: Optional[str] = None) -> str:
    """Create full prompt for Gemini API."""
    if system_prompt:
        return f"System: {system_prompt}\n\nUser: {prompt}"
    return prompt


def _create_generation_config(max_tokens: int, temperature: float, top_p: float):
    """Create generation configuration for Gemini."""
    try:
        import google.generativeai as genai
        return genai.types.GenerationConfig(
            max_output_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p
        )
    except ImportError:
        raise ToolError("Google AI library not installed. Run: pip install google-generativeai")


def _extract_api_response(response: Any) -> tuple:
    """Extract content from real API response."""
    text = response.text
    usage = _extract_usage_metadata(response) if hasattr(response, 'usage_metadata') else {}
    finish_reason = response.candidates[0].finish_reason.name if response.candidates else None
    return text, usage, finish_reason


def _extract_usage_metadata(response: Any) -> Dict[str, Optional[int]]:
    """Extract usage metadata from API response."""
    metadata = response.usage_metadata
    return {
        "prompt_tokens": metadata.prompt_token_count,
        "completion_tokens": metadata.candidates_token_count,
        "total_tokens": metadata.total_token_count
    }


def _extract_dict_response(response: Dict) -> tuple:
    """Extract content from dictionary response."""
    candidates = response.get('candidates', [])
    
    if not candidates:
        return "", response.get('usage_metadata', {}), None
    
    candidate = candidates[0]
    finish_reason = candidate.get('finish_reason')
    
    # Check for safety filter
    if finish_reason == 'SAFETY':
        raise ToolError("Content blocked by safety filter")
    
    # Extract text content
    text = _extract_text_from_candidate(candidate)
    usage = response.get('usage_metadata', {})
    
    return text, usage, finish_reason


def _extract_text_from_candidate(candidate: Dict) -> str:
    """Extract text from candidate object."""
    content = candidate.get('content')
    if content and content.get('parts'):
        return content['parts'][0].get('text', '')
    return ""


def _extract_gemini_response(response: Any) -> tuple:
    """Extract content and metadata from Gemini response."""
    # Dispatch to appropriate handler based on response type
    if hasattr(response, 'text'):
        return _extract_api_response(response)
    elif isinstance(response, dict):
        return _extract_dict_response(response)
    else:
        raise ValueError(f"Unexpected response format: {type(response)}")


class GeminiTool(BaseLLMTool):
    """Google Gemini tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        # Set default model if not provided
        if not self.model:
            self.model = 'gemini-pro'
        
    async def execute(self, prompt: str, system_prompt: str = None,
                     max_tokens: int = None, temperature: float = None,
                     **kwargs):
        """Execute Gemini API call with functional approach."""
        try:
            # Import Google AI client
            try:
                import google.generativeai as genai
            except ImportError:
                raise ToolError("Google AI library not installed. Run: pip install google-generativeai", self.name)
            
            # Configure API
            genai.configure(api_key=self.api_key)
            
            # Initialize model
            model = genai.GenerativeModel(self.model)
            
            # Get standardized parameters
            request_max_tokens, request_temperature = self._get_request_params(max_tokens, temperature)
            
            # Prepare request using pure functions
            full_prompt = _create_full_prompt(prompt, system_prompt)
            generation_config = _create_generation_config(
                request_max_tokens, request_temperature, self.top_p
            )
            
            # Generate response
            response = await model.generate_content_async(
                full_prompt,
                generation_config=generation_config
            )
            
            # Extract response using pure function
            content, usage, finish_reason = _extract_gemini_response(response)
            return self._create_success_result(content, usage, finish_reason)
            
        except Exception as e:
            return self._create_error_result(e, "Gemini")