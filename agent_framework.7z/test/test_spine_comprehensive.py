"""Comprehensive tests for spine module functionality."""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from typing import Dict, Any, List

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from agent_sdk.core.spine import (
    _collect_functions, _wrap_as_task, _as_task, _merge_context_dict,
    _execute_sequential, _execute_concurrent, _execute_stage_sync,
    _execute_stage_async, agentic_spine, agentic_spine_async,
    agentic_spine_async_prefect, agentic_spine_simple
)
from agent_sdk.core.stages import Stage, perceive, reason, plan, act
from agent_sdk.core.context import Context


class TestSpineHelperFunctions:
    """Test spine helper functions."""
    
    def test_collect_functions_with_stages(self):
        """Test collecting functions by stage."""
        @perceive
        def perceive_func(ctx): return {"perceived": True}
        
        @reason
        def reason_func(ctx): return {"reasoned": True}
        
        @plan
        def plan_func(ctx): return {"planned": True}
        
        functions = [perceive_func, reason_func, plan_func]
        stage_map = _collect_functions(functions)
        
        assert Stage.PERCEIVE in stage_map
        assert Stage.REASON in stage_map
        assert Stage.PLAN in stage_map
        assert len(stage_map[Stage.PERCEIVE]) == 1
        assert len(stage_map[Stage.REASON]) == 1
        assert len(stage_map[Stage.PLAN]) == 1
    
    def test_collect_functions_without_stages(self):
        """Test collecting functions without stage decorators."""
        def undecorated_func(ctx): return {"result": True}
        
        functions = [undecorated_func]
        stage_map = _collect_functions(functions)
        
        # Should be empty since function has no stage
        assert len(stage_map) == 0
    
    def test_wrap_as_task_regular_function(self):
        """Test wrapping regular function as Prefect task."""
        def regular_func(ctx): return {"result": True}
        
        with patch('agent_sdk.core.execution.function_utils.task') as mock_task:
            mock_task.return_value = lambda f: f  # Simple mock
            
            wrapped = _wrap_as_task(regular_func)
            
            mock_task.assert_called_once()
            call_args = mock_task.call_args[1]
            assert call_args['name'] == 'regular_func'
    
    def test_wrap_as_task_existing_task(self):
        """Test wrapping function that's already a task."""
        mock_task = Mock()
        mock_task.fn = lambda ctx: {"result": True}
        mock_task.name = "existing_task"
        
        with patch('agent_sdk.core.execution.function_utils.task') as mock_task_decorator:
            mock_task_decorator.return_value = lambda f: f
            
            wrapped = _wrap_as_task(mock_task)
            
            mock_task_decorator.assert_called_once()
    
    def test_as_task_with_submit_method(self):
        """Test _as_task with function that has submit method."""
        mock_task = Mock()
        mock_task.submit = Mock()
        
        result = _as_task(mock_task)
        
        assert result == mock_task
    
    def test_as_task_without_submit_method(self):
        """Test _as_task with regular function."""
        def regular_func(ctx): return {"result": True}
        
        with patch('agent_sdk.core.execution.function_utils.wrap_as_task') as mock_wrap:
            mock_wrap.return_value = Mock()
            
            result = _as_task(regular_func)
            
            mock_wrap.assert_called_once_with(regular_func)
            assert result == mock_wrap.return_value
    
    def test_merge_context_dict_with_dict(self):
        """Test merging dictionary output into context."""
        ctx = {"existing": "value"}
        output = {"new": "data", "updated": "info"}
        
        result = _merge_context_dict(ctx, output)
        
        assert result["existing"] == "value"
        assert result["new"] == "data"
        assert result["updated"] == "info"
    
    def test_merge_context_dict_with_non_dict(self):
        """Test merging non-dictionary output into context."""
        ctx = {"existing": "value"}
        output = "string result"
        
        result = _merge_context_dict(ctx, output)
        
        assert result["existing"] == "value"
        assert result["result_str"] == "string result"
    
    def test_execute_sequential_success(self):
        """Test sequential execution of functions."""
        def func1(ctx): return {"step1": "done"}
        def func2(ctx): return {"step2": "done"}
        
        functions = [func1, func2]
        ctx = Context({"initial": "data"})
        
        results = _execute_sequential(functions, ctx)
        
        assert len(results) == 2
        assert results[0] == {"step1": "done"}
        assert results[1] == {"step2": "done"}
    
    def test_execute_sequential_with_exception(self):
        """Test sequential execution with exception."""
        def func1(ctx): return {"step1": "done"}
        def func2(ctx): raise ValueError("Test error")
        
        functions = [func1, func2]
        ctx = Context()
        
        with pytest.raises(ValueError, match="Test error"):
            _execute_sequential(functions, ctx)
    
    @pytest.mark.asyncio
    async def test_execute_concurrent_success(self):
        """Test concurrent execution of functions."""
        async def async_func1(ctx): 
            await asyncio.sleep(0.01)
            return {"async1": "done"}
        
        def sync_func2(ctx): 
            return {"sync2": "done"}
        
        functions = [async_func1, sync_func2]
        ctx = Context()
        
        results = await _execute_concurrent(functions, ctx)
        
        assert len(results) == 2
        assert {"async1": "done"} in results
        assert {"sync2": "done"} in results
    
    @pytest.mark.asyncio
    async def test_execute_concurrent_with_exception(self):
        """Test concurrent execution with exception."""
        async def failing_func(ctx):
            await asyncio.sleep(0.01)
            raise RuntimeError("Concurrent error")
        
        def success_func(ctx):
            return {"success": True}
        
        functions = [failing_func, success_func]
        ctx = Context()
        
        with pytest.raises(RuntimeError, match="Concurrent error"):
            await _execute_concurrent(functions, ctx)


class TestStageExecution:
    """Test stage execution functions."""
    
    def test_execute_stage_sync_sequential(self):
        """Test synchronous stage execution sequentially."""
        @perceive
        def func1(ctx): return {"result1": "value1"}
        
        @perceive  
        def func2(ctx): return {"result2": "value2"}
        
        functions = [func1, func2]
        ctx = Context({"initial": "data"})
        
        result_ctx = _execute_stage_sync(functions, ctx, concurrent=False)
        
        assert result_ctx.get("initial") == "data"
        assert result_ctx.get("result1") == "value1"
        assert result_ctx.get("result2") == "value2"
    
    def test_execute_stage_sync_concurrent_fallback(self):
        """Test sync stage execution falls back from concurrent to sequential."""
        @perceive
        def func1(ctx): return {"result1": "value1"}
        
        functions = [func1]
        ctx = Context()
        
        with patch('agent_sdk.core.execution.sync_executor.logger') as mock_logger:
            result_ctx = _execute_stage_sync(functions, ctx, concurrent=True)
            
            # Should log warning about concurrent fallback
            mock_logger.warning.assert_called_once()
            assert "Concurrent execution requested in sync mode" in mock_logger.warning.call_args[0][0]
    
    def test_execute_stage_sync_empty_functions(self):
        """Test sync stage execution with empty function list."""
        ctx = Context({"data": "value"})
        
        result_ctx = _execute_stage_sync([], ctx)
        
        assert result_ctx == ctx
    
    @pytest.mark.asyncio
    async def test_execute_stage_async_sequential(self):
        """Test asynchronous stage execution sequentially."""
        @perceive
        async def async_func(ctx): 
            await asyncio.sleep(0.01)
            return {"async_result": "done"}
        
        @perceive
        def sync_func(ctx): 
            return {"sync_result": "done"}
        
        functions = [async_func, sync_func]
        ctx = Context()
        
        result_ctx = await _execute_stage_async(functions, ctx, concurrent=False)
        
        assert result_ctx.get("async_result") == "done"
        assert result_ctx.get("sync_result") == "done"
    
    @pytest.mark.asyncio
    async def test_execute_stage_async_concurrent(self):
        """Test asynchronous stage execution concurrently."""
        @perceive
        async def async_func1(ctx): 
            await asyncio.sleep(0.01)
            return {"async1": "done"}
        
        @perceive
        async def async_func2(ctx): 
            await asyncio.sleep(0.01)
            return {"async2": "done"}
        
        functions = [async_func1, async_func2]
        ctx = Context()
        
        result_ctx = await _execute_stage_async(functions, ctx, concurrent=True)
        
        assert result_ctx.get("async1") == "done"
        assert result_ctx.get("async2") == "done"
    
    @pytest.mark.asyncio
    async def test_execute_stage_async_empty_functions(self):
        """Test async stage execution with empty function list."""
        ctx = Context({"data": "value"})
        
        result_ctx = await _execute_stage_async([], ctx)
        
        assert result_ctx == ctx


class TestSpineMainFunctions:
    """Test main spine execution functions."""
    
    def test_agentic_spine_simple_basic(self):
        """Test simple agentic spine execution."""
        @perceive
        def perceive_func(ctx): return {"perceived": "data"}
        
        @reason
        def reason_func(ctx): return {"reasoned": ctx.get("perceived")}
        
        functions = [perceive_func, reason_func]
        
        result = agentic_spine_simple(
            input_data={"input": "test"},
            functions=functions
        )
        
        assert isinstance(result, Context)
        # Input data is wrapped in "input" key by the spine
        assert result.get("input") == {"input": "test"}
        assert result.get("perceived") == "data"
        assert result.get("reasoned") == "data"
    
    def test_agentic_spine_simple_with_initial_context(self):
        """Test simple spine with initial context."""
        @perceive
        def perceive_func(ctx): return {"perceived": ctx.get("config")}
        
        functions = [perceive_func]
        
        result = agentic_spine_simple(
            input_data={"input": "test"},
            functions=functions,
            initial_context={"config": "value"}
        )
        
        assert result.get("config") == "value"
        assert result.get("perceived") == "value"
    
    def test_agentic_spine_simple_with_concurrent_config(self):
        """Test simple spine with concurrent configuration."""
        @perceive
        def perceive_func(ctx): return {"perceived": True}
        
        functions = [perceive_func]
        
        # Concurrent config should be ignored in simple mode
        result = agentic_spine_simple(
            input_data={"input": "test"},
            functions=functions,
            concurrent={Stage.PERCEIVE: True}
        )
        
        assert result.get("perceived") is True
    
    @pytest.mark.asyncio
    async def test_agentic_spine_async_basic(self):
        """Test async agentic spine execution."""
        @perceive
        async def async_perceive(ctx): 
            await asyncio.sleep(0.01)
            return {"perceived": "async_data"}
        
        @reason
        def sync_reason(ctx): 
            return {"reasoned": ctx.get("perceived")}
        
        functions = [async_perceive, sync_reason]
        
        result = await agentic_spine_async(
            input_data={"input": "test"},
            functions=functions
        )
        
        assert isinstance(result, Context)
        assert result.get("perceived") == "async_data"
        assert result.get("reasoned") == "async_data"
    
    @pytest.mark.asyncio
    async def test_agentic_spine_async_concurrent(self):
        """Test async spine with concurrent execution."""
        @perceive
        async def perceive1(ctx): 
            await asyncio.sleep(0.01)
            return {"perceive1": "done"}
        
        @perceive
        async def perceive2(ctx): 
            await asyncio.sleep(0.01)
            return {"perceive2": "done"}
        
        functions = [perceive1, perceive2]
        
        result = await agentic_spine_async(
            input_data={"input": "test"},
            functions=functions,
            concurrent={Stage.PERCEIVE: True}
        )
        
        assert result.get("perceive1") == "done"
        assert result.get("perceive2") == "done"
    
    def test_agentic_spine_prefect_sync(self):
        """Test Prefect synchronous spine execution."""
        @perceive
        def perceive_func(ctx): return {"perceived": "prefect_data"}
        
        functions = [perceive_func]
        
        with patch('agent_sdk.core.spine._collect_functions') as mock_collect:
            mock_collect.return_value = {Stage.PERCEIVE: functions}
            
            with patch('agent_sdk.core.execution.prefect_executor.PrefectExecutor.execute_sequential_monitored') as mock_exec:
                mock_exec.return_value = [{"perceived": "prefect_data"}]
                
                result = agentic_spine(
                    input_data={"input": "test"},
                    functions=functions
                )
                
                assert isinstance(result, Context)
                mock_collect.assert_called_once_with(functions)
    
    @pytest.mark.asyncio
    async def test_agentic_spine_async_prefect(self):
        """Test Prefect async spine execution."""
        @perceive
        async def async_perceive(ctx): 
            return {"perceived": "async_prefect_data"}
        
        functions = [async_perceive]
        
        with patch('agent_sdk.core.spine._collect_functions') as mock_collect:
            mock_collect.return_value = {Stage.PERCEIVE: functions}
            
            with patch('agent_sdk.core.execution.prefect_executor.PrefectExecutor.execute_async_tasks_monitored') as mock_exec:
                mock_exec.return_value = [{"perceived": "async_prefect_data"}]
                
                result = await agentic_spine_async_prefect(
                    input_data={"input": "test"},
                    functions=functions
                )
                
                assert isinstance(result, Context)
                mock_collect.assert_called_once_with(functions)


class TestSpineErrorHandling:
    """Test error handling in spine functions."""
    
    def test_spine_function_exception_propagation(self):
        """Test that exceptions in functions are properly propagated."""
        @perceive
        def failing_func(ctx):
            raise ValueError("Function failed")
        
        functions = [failing_func]
        
        with pytest.raises(ValueError, match="Function failed"):
            agentic_spine_simple(
                input_data={"input": "test"},
                functions=functions
            )
    
    @pytest.mark.asyncio
    async def test_async_spine_exception_propagation(self):
        """Test exception propagation in async spine."""
        @perceive
        async def failing_async_func(ctx):
            await asyncio.sleep(0.01)
            raise RuntimeError("Async function failed")
        
        functions = [failing_async_func]
        
        with pytest.raises(RuntimeError, match="Async function failed"):
            await agentic_spine_async(
                input_data={"input": "test"},
                functions=functions
            )
    
    def test_spine_with_invalid_input_data(self):
        """Test spine with various input data types."""
        @perceive
        def perceive_func(ctx): 
            return {"input_type": type(ctx.get("input")).__name__}
        
        functions = [perceive_func]
        
        # Test with string input
        result = agentic_spine_simple("string_input", functions)
        assert result.get("input") == "string_input"
        
        # Test with None input
        result = agentic_spine_simple(None, functions)
        assert result.get("input") is None
        
        # Test with list input
        result = agentic_spine_simple([1, 2, 3], functions)
        assert result.get("input") == [1, 2, 3]


class TestSpineEdgeCases:
    """Test edge cases for spine functionality."""
    
    def test_spine_with_no_functions(self):
        """Test spine execution with no functions."""
        result = agentic_spine_simple(
            input_data={"input": "test"},
            functions=[]
        )
        
        assert isinstance(result, Context)
        # Input data is wrapped in "input" key by the spine
        assert result.get("input") == {"input": "test"}
    
    def test_spine_with_mixed_stage_functions(self):
        """Test spine with functions from different stages."""
        @perceive
        def perceive_func(ctx): return {"perceived": True}
        
        @act
        def act_func(ctx): return {"acted": True}
        
        # Skip reason and plan stages
        functions = [perceive_func, act_func]
        
        result = agentic_spine_simple(
            input_data={"input": "test"},
            functions=functions
        )
        
        assert result.get("perceived") is True
        assert result.get("acted") is True
    
    @pytest.mark.asyncio
    async def test_async_spine_with_sync_functions_only(self):
        """Test async spine with only synchronous functions."""
        @perceive
        def sync_perceive(ctx): return {"sync_perceived": True}
        
        @reason
        def sync_reason(ctx): return {"sync_reasoned": True}
        
        functions = [sync_perceive, sync_reason]
        
        result = await agentic_spine_async(
            input_data={"input": "test"},
            functions=functions
        )
        
        assert result.get("sync_perceived") is True
        assert result.get("sync_reasoned") is True
    
    def test_spine_context_preservation(self):
        """Test that context is properly preserved across stages."""
        @perceive
        def perceive_func(ctx): 
            # Should preserve existing context
            assert ctx.get("initial_value") == "preserved"
            return {"perceived": True}
        
        @reason
        def reason_func(ctx):
            # Should have both initial and perceived values
            assert ctx.get("initial_value") == "preserved"
            assert ctx.get("perceived") is True
            return {"reasoned": True}
        
        functions = [perceive_func, reason_func]
        
        result = agentic_spine_simple(
            input_data={"input": "test"},
            functions=functions,
            initial_context={"initial_value": "preserved"}
        )
        
        assert result.get("initial_value") == "preserved"
        assert result.get("perceived") is True
        assert result.get("reasoned") is True