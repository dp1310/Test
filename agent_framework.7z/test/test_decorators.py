"""Tests for additional decorators functionality."""

import pytest
import asyncio
from typing import Dict, Any

from agent_sdk.core.decorators import stage_decorator, async_stage
from agent_sdk.core.stages import Stage
from agent_sdk.core.context import Context


class TestStageDecorator:
    """Test generic stage_decorator function."""
    
    def test_stage_decorator_sync_function(self):
        """Test stage_decorator with synchronous function."""
        @stage_decorator(Stage.PERCEIVE)
        def sync_function(ctx: Context) -> Dict[str, Any]:
            return {"sync": True}
        
        assert hasattr(sync_function, "_agent_stage")
        assert sync_function._agent_stage == Stage.PERCEIVE
        assert hasattr(sync_function, "_is_async")
        assert sync_function._is_async is False
        
        ctx = Context()
        result = sync_function(ctx)
        assert result == {"sync": True}
    
    @pytest.mark.asyncio
    async def test_stage_decorator_async_function(self):
        """Test stage_decorator with asynchronous function."""
        @stage_decorator(Stage.REASON)
        async def async_function(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"async": True}
        
        assert hasattr(async_function, "_agent_stage")
        assert async_function._agent_stage == Stage.REASON
        assert hasattr(async_function, "_is_async")
        assert async_function._is_async is True
        
        ctx = Context()
        result = await async_function(ctx)
        assert result == {"async": True}
    
    def test_stage_decorator_all_stages(self):
        """Test stage_decorator with all stage types."""
        @stage_decorator(Stage.PERCEIVE)
        def perceive_fn(ctx: Context) -> Dict[str, Any]:
            return {"stage": "perceive"}
        
        @stage_decorator(Stage.REASON)
        def reason_fn(ctx: Context) -> Dict[str, Any]:
            return {"stage": "reason"}
        
        @stage_decorator(Stage.PLAN)
        def plan_fn(ctx: Context) -> Dict[str, Any]:
            return {"stage": "plan"}
        
        @stage_decorator(Stage.ACT)
        def act_fn(ctx: Context) -> Dict[str, Any]:
            return {"stage": "act"}
        
        ctx = Context()
        
        assert perceive_fn._agent_stage == Stage.PERCEIVE
        assert reason_fn._agent_stage == Stage.REASON
        assert plan_fn._agent_stage == Stage.PLAN
        assert act_fn._agent_stage == Stage.ACT
        
        assert perceive_fn(ctx) == {"stage": "perceive"}
        assert reason_fn(ctx) == {"stage": "reason"}
        assert plan_fn(ctx) == {"stage": "plan"}
        assert act_fn(ctx) == {"stage": "act"}
    
    def test_stage_decorator_preserves_metadata(self):
        """Test that stage_decorator preserves function metadata."""
        @stage_decorator(Stage.PLAN)
        def documented_function(ctx: Context) -> Dict[str, Any]:
            """This function has documentation."""
            return {"documented": True}
        
        assert documented_function.__name__ == "documented_function"
        assert documented_function.__doc__ == "This function has documentation."
    
    def test_stage_decorator_with_args_kwargs(self):
        """Test stage_decorator with various function signatures."""
        @stage_decorator(Stage.ACT)
        def flexible_function(*args, **kwargs):
            return {"args_count": len(args), "kwargs_count": len(kwargs)}
        
        result = flexible_function("arg1", "arg2", key1="value1", key2="value2")
        assert result == {"args_count": 2, "kwargs_count": 2}
    
    @pytest.mark.asyncio
    async def test_stage_decorator_mixed_execution(self):
        """Test that stage_decorator handles both sync and async correctly."""
        @stage_decorator(Stage.PERCEIVE)
        def sync_fn(value: int) -> int:
            return value * 2
        
        @stage_decorator(Stage.PERCEIVE)
        async def async_fn(value: int) -> int:
            await asyncio.sleep(0.001)
            return value * 3
        
        # Test sync function
        sync_result = sync_fn(5)
        assert sync_result == 10
        
        # Test async function
        async_result = await async_fn(5)
        assert async_result == 15
        
        # Both should have the same stage
        assert sync_fn._agent_stage == async_fn._agent_stage == Stage.PERCEIVE
        assert sync_fn._is_async is False
        assert async_fn._is_async is True


class TestAsyncStage:
    """Test async_stage decorator."""
    
    @pytest.mark.asyncio
    async def test_async_stage_valid_function(self):
        """Test async_stage with valid async function."""
        @async_stage(Stage.REASON)
        async def async_function(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"async_stage": True}
        
        assert hasattr(async_function, "_agent_stage")
        assert async_function._agent_stage == Stage.REASON
        assert hasattr(async_function, "_is_async")
        assert async_function._is_async is True
        
        ctx = Context()
        result = await async_function(ctx)
        assert result == {"async_stage": True}
    
    def test_async_stage_invalid_function(self):
        """Test async_stage with non-async function raises error."""
        with pytest.raises(ValueError, match="must be async for async_stage decorator"):
            @async_stage(Stage.PLAN)
            def sync_function(ctx: Context) -> Dict[str, Any]:
                return {"sync": True}
    
    @pytest.mark.asyncio
    async def test_async_stage_all_stages(self):
        """Test async_stage with all stage types."""
        @async_stage(Stage.PERCEIVE)
        async def perceive_fn(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"stage": "perceive"}
        
        @async_stage(Stage.REASON)
        async def reason_fn(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"stage": "reason"}
        
        @async_stage(Stage.PLAN)
        async def plan_fn(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"stage": "plan"}
        
        @async_stage(Stage.ACT)
        async def act_fn(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"stage": "act"}
        
        ctx = Context()
        
        assert perceive_fn._agent_stage == Stage.PERCEIVE
        assert reason_fn._agent_stage == Stage.REASON
        assert plan_fn._agent_stage == Stage.PLAN
        assert act_fn._agent_stage == Stage.ACT
        
        assert await perceive_fn(ctx) == {"stage": "perceive"}
        assert await reason_fn(ctx) == {"stage": "reason"}
        assert await plan_fn(ctx) == {"stage": "plan"}
        assert await act_fn(ctx) == {"stage": "act"}
    
    @pytest.mark.asyncio
    async def test_async_stage_preserves_metadata(self):
        """Test that async_stage preserves function metadata."""
        @async_stage(Stage.ACT)
        async def documented_async_function(ctx: Context) -> Dict[str, Any]:
            """This async function has documentation."""
            await asyncio.sleep(0.001)
            return {"documented": True}
        
        assert documented_async_function.__name__ == "documented_async_function"
        assert documented_async_function.__doc__ == "This async function has documentation."
    
    @pytest.mark.asyncio
    async def test_async_stage_with_args_kwargs(self):
        """Test async_stage with various function signatures."""
        @async_stage(Stage.PERCEIVE)
        async def flexible_async_function(*args, **kwargs):
            await asyncio.sleep(0.001)
            return {"args_count": len(args), "kwargs_count": len(kwargs)}
        
        result = await flexible_async_function("arg1", "arg2", key1="value1", key2="value2")
        assert result == {"args_count": 2, "kwargs_count": 2}


class TestDecoratorEdgeCases:
    """Test edge cases for decorators."""
    
    def test_decorator_on_lambda_functions(self):
        """Test decorators on lambda functions."""
        # stage_decorator with lambda
        decorated_lambda = stage_decorator(Stage.PERCEIVE)(lambda x: x * 2)
        assert hasattr(decorated_lambda, "_agent_stage")
        assert decorated_lambda._agent_stage == Stage.PERCEIVE
        assert decorated_lambda(5) == 10
    
    def test_decorator_on_class_methods(self):
        """Test decorators on class methods."""
        class TestClass:
            @stage_decorator(Stage.PERCEIVE)
            def instance_method(self, ctx: Context) -> Dict[str, Any]:
                return {"method": "instance"}
            
            @classmethod
            @stage_decorator(Stage.REASON)
            def class_method(cls, ctx: Context) -> Dict[str, Any]:
                return {"method": "class"}
            
            @staticmethod
            @stage_decorator(Stage.PLAN)
            def static_method(ctx: Context) -> Dict[str, Any]:
                return {"method": "static"}
        
        obj = TestClass()
        ctx = Context()
        
        # Test instance method
        assert obj.instance_method._agent_stage == Stage.PERCEIVE
        assert obj.instance_method(ctx) == {"method": "instance"}
        
        # Test class method
        assert TestClass.class_method._agent_stage == Stage.REASON
        assert TestClass.class_method(ctx) == {"method": "class"}
        
        # Test static method
        assert TestClass.static_method._agent_stage == Stage.PLAN
        assert TestClass.static_method(ctx) == {"method": "static"}
    
    def test_multiple_decorators_order(self):
        """Test behavior with multiple decorators."""
        def add_attribute(name, value):
            def decorator(func):
                setattr(func, name, value)
                return func
            return decorator
        
        @add_attribute("first", "first_value")
        @stage_decorator(Stage.ACT)
        @add_attribute("second", "second_value")
        def multi_decorated_function(ctx: Context) -> Dict[str, Any]:
            return {"multi": True}
        
        assert hasattr(multi_decorated_function, "_agent_stage")
        assert multi_decorated_function._agent_stage == Stage.ACT
        assert hasattr(multi_decorated_function, "first")
        assert multi_decorated_function.first == "first_value"
        assert hasattr(multi_decorated_function, "second")
        assert multi_decorated_function.second == "second_value"
        
        ctx = Context()
        result = multi_decorated_function(ctx)
        assert result == {"multi": True}
    
    def test_decorator_exception_handling(self):
        """Test that decorators don't interfere with exception handling."""
        @stage_decorator(Stage.PERCEIVE)
        def failing_function(ctx: Context) -> Dict[str, Any]:
            raise ValueError("Test error")
        
        ctx = Context()
        with pytest.raises(ValueError, match="Test error"):
            failing_function(ctx)
    
    @pytest.mark.asyncio
    async def test_async_decorator_exception_handling(self):
        """Test that async decorators don't interfere with exception handling."""
        @async_stage(Stage.REASON)
        async def failing_async_function(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            raise RuntimeError("Async test error")
        
        ctx = Context()
        with pytest.raises(RuntimeError, match="Async test error"):
            await failing_async_function(ctx)
    
    def test_decorator_with_generator_function(self):
        """Test decorator behavior with generator functions."""
        @stage_decorator(Stage.PLAN)
        def generator_function(ctx: Context):
            yield {"first": True}
            yield {"second": True}
        
        assert hasattr(generator_function, "_agent_stage")
        assert generator_function._agent_stage == Stage.PLAN
        
        ctx = Context()
        gen = generator_function(ctx)
        assert next(gen) == {"first": True}
        assert next(gen) == {"second": True}
    
    @pytest.mark.asyncio
    async def test_async_stage_with_async_generator(self):
        """Test async_stage with async generator functions."""
        @async_stage(Stage.ACT)
        async def async_generator_function(ctx: Context):
            await asyncio.sleep(0.001)
            yield {"first": True}
            await asyncio.sleep(0.001)
            yield {"second": True}
        
        assert hasattr(async_generator_function, "_agent_stage")
        assert async_generator_function._agent_stage == Stage.ACT
        
        ctx = Context()
        gen = async_generator_function(ctx)
        assert await gen.__anext__() == {"first": True}
        assert await gen.__anext__() == {"second": True}


class TestDecoratorCompatibility:
    """Test decorator compatibility with different Python features."""
    
    def test_decorator_with_type_hints(self):
        """Test decorators work correctly with type hints."""
        @stage_decorator(Stage.PERCEIVE)
        def typed_function(ctx: Context, value: int) -> Dict[str, int]:
            return {"doubled": value * 2}
        
        assert hasattr(typed_function, "_agent_stage")
        assert typed_function._agent_stage == Stage.PERCEIVE
        
        ctx = Context()
        result = typed_function(ctx, 5)
        assert result == {"doubled": 10}
    
    def test_decorator_with_default_arguments(self):
        """Test decorators with functions that have default arguments."""
        @stage_decorator(Stage.REASON)
        def function_with_defaults(ctx: Context, multiplier: int = 2, prefix: str = "result") -> Dict[str, Any]:
            return {prefix: ctx.get("value", 1) * multiplier}
        
        ctx = Context(data={"value": 5})
        
        # Test with defaults
        result1 = function_with_defaults(ctx)
        assert result1 == {"result": 10}
        
        # Test with custom values
        result2 = function_with_defaults(ctx, multiplier=3, prefix="custom")
        assert result2 == {"custom": 15}
    
    @pytest.mark.asyncio
    async def test_async_stage_with_type_hints_and_defaults(self):
        """Test async_stage with type hints and default arguments."""
        @async_stage(Stage.PLAN)
        async def async_typed_function(ctx: Context, delay: float = 0.001, multiplier: int = 2) -> Dict[str, int]:
            await asyncio.sleep(delay)
            return {"result": ctx.get("value", 1) * multiplier}
        
        ctx = Context(data={"value": 3})
        
        # Test with defaults
        result1 = await async_typed_function(ctx)
        assert result1 == {"result": 6}
        
        # Test with custom values
        result2 = await async_typed_function(ctx, delay=0.002, multiplier=4)
        assert result2 == {"result": 12}