"""Tests for logging utilities."""

import pytest
import logging
import sys
from io import StringIO
from unittest.mock import Mock, patch

from agent_sdk.utils.logging import setup_logging, get_logger


class TestSetupLogging:
    """Test setup_logging function."""
    
    def test_setup_logging_default(self):
        """Test setup_logging with default parameters."""
        # Capture the original state
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            setup_logging()
            
            root_logger = logging.getLogger()
            assert root_logger.level == logging.INFO
            assert len(root_logger.handlers) >= 1
            
            # Check that handler is StreamHandler to stdout
            handler = root_logger.handlers[0]
            assert isinstance(handler, logging.StreamHandler)
            assert handler.stream == sys.stdout
            
        finally:
            # Restore original state
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_setup_logging_custom_level(self):
        """Test setup_logging with custom log level."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            setup_logging(level="DEBUG")
            
            root_logger = logging.getLogger()
            assert root_logger.level == logging.DEBUG
            
            setup_logging(level="WARNING")
            assert root_logger.level == logging.WARNING
            
            setup_logging(level="ERROR")
            assert root_logger.level == logging.ERROR
            
            setup_logging(level="CRITICAL")
            assert root_logger.level == logging.CRITICAL
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_setup_logging_custom_format(self):
        """Test setup_logging with custom format string."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            custom_format = "%(levelname)s - %(message)s"
            setup_logging(format_string=custom_format)
            
            root_logger = logging.getLogger()
            handler = root_logger.handlers[0]
            assert handler.formatter._fmt == custom_format
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_setup_logging_custom_handler(self):
        """Test setup_logging with custom handler."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            # Create custom handler
            stream = StringIO()
            custom_handler = logging.StreamHandler(stream)
            custom_format = "CUSTOM: %(message)s"
            custom_handler.setFormatter(logging.Formatter(custom_format))
            
            setup_logging(handler=custom_handler)
            
            root_logger = logging.getLogger()
            assert custom_handler in root_logger.handlers
            
            # Test that logging works with custom handler
            test_logger = logging.getLogger("test")
            test_logger.info("test message")
            
            output = stream.getvalue()
            assert "CUSTOM: test message" in output
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_setup_logging_removes_existing_handlers(self):
        """Test that setup_logging removes existing handlers."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            # Add some handlers first
            root_logger = logging.getLogger()
            handler1 = logging.StreamHandler()
            handler2 = logging.StreamHandler()
            root_logger.addHandler(handler1)
            root_logger.addHandler(handler2)
            
            initial_count = len(root_logger.handlers)
            assert initial_count >= 2
            
            # Setup logging should remove existing handlers
            setup_logging()
            
            # Should have only the new handler
            assert len(root_logger.handlers) == 1
            assert handler1 not in root_logger.handlers
            assert handler2 not in root_logger.handlers
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_setup_logging_case_insensitive_level(self):
        """Test that log level is case insensitive."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            setup_logging(level="debug")
            assert logging.getLogger().level == logging.DEBUG
            
            setup_logging(level="Info")
            assert logging.getLogger().level == logging.INFO
            
            setup_logging(level="WARNING")
            assert logging.getLogger().level == logging.WARNING
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    @patch('logging.basicConfig')
    def test_setup_logging_basicconfig_fallback(self, mock_basicconfig):
        """Test that basicConfig is called as fallback."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            # Make basicConfig raise an exception to test fallback behavior
            mock_basicconfig.side_effect = Exception("basicConfig failed")
            
            # This should not raise an exception despite basicConfig failing
            setup_logging()
            
            # Should still have configured the root logger directly
            root_logger = logging.getLogger()
            assert root_logger.level == logging.INFO
            assert len(root_logger.handlers) >= 1
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)


class TestGetLogger:
    """Test get_logger function."""
    
    def test_get_logger_basic(self):
        """Test basic get_logger functionality."""
        logger = get_logger("test_logger")
        
        assert isinstance(logger, logging.Logger)
        assert logger.name == "test_logger"
    
    def test_get_logger_different_names(self):
        """Test get_logger with different names."""
        logger1 = get_logger("logger1")
        logger2 = get_logger("logger2")
        logger3 = get_logger("logger1")  # Same name as logger1
        
        assert logger1.name == "logger1"
        assert logger2.name == "logger2"
        assert logger3.name == "logger1"
        
        # Same name should return same logger instance
        assert logger1 is logger3
        assert logger1 is not logger2
    
    def test_get_logger_with_module_name(self):
        """Test get_logger with __name__ pattern."""
        logger = get_logger(__name__)
        
        assert isinstance(logger, logging.Logger)
        assert logger.name == __name__
    
    def test_get_logger_hierarchical_names(self):
        """Test get_logger with hierarchical names."""
        parent_logger = get_logger("parent")
        child_logger = get_logger("parent.child")
        grandchild_logger = get_logger("parent.child.grandchild")
        
        assert parent_logger.name == "parent"
        assert child_logger.name == "parent.child"
        assert grandchild_logger.name == "parent.child.grandchild"
        
        # Check hierarchy
        assert child_logger.parent == parent_logger
        assert grandchild_logger.parent == child_logger
    
    def test_get_logger_empty_name(self):
        """Test get_logger with empty name."""
        logger = get_logger("")
        
        assert isinstance(logger, logging.Logger)
        assert logger.name == ""
    
    def test_get_logger_special_characters(self):
        """Test get_logger with special characters in name."""
        special_names = [
            "logger-with-dashes",
            "logger_with_underscores",
            "logger.with.dots",
            "logger with spaces",
            "logger123",
            "UPPERCASE_LOGGER"
        ]
        
        for name in special_names:
            logger = get_logger(name)
            assert isinstance(logger, logging.Logger)
            assert logger.name == name


class TestLoggingIntegration:
    """Test integration between setup_logging and get_logger."""
    
    def test_logger_uses_setup_configuration(self):
        """Test that loggers created with get_logger use setup_logging configuration."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            # Setup logging with specific configuration
            stream = StringIO()
            handler = logging.StreamHandler(stream)
            custom_format = "TEST: %(name)s - %(levelname)s - %(message)s"
            handler.setFormatter(logging.Formatter(custom_format))
            
            setup_logging(level="DEBUG", handler=handler)
            
            # Create logger and test logging
            logger = get_logger("test.integration")
            logger.debug("debug message")
            logger.info("info message")
            logger.warning("warning message")
            logger.error("error message")
            
            output = stream.getvalue()
            
            # All messages should appear (DEBUG level)
            assert "TEST: test.integration - DEBUG - debug message" in output
            assert "TEST: test.integration - INFO - info message" in output
            assert "TEST: test.integration - WARNING - warning message" in output
            assert "TEST: test.integration - ERROR - error message" in output
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_logger_level_filtering(self):
        """Test that log level filtering works correctly."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            # Setup logging with WARNING level
            stream = StringIO()
            handler = logging.StreamHandler(stream)
            setup_logging(level="WARNING", handler=handler)
            
            logger = get_logger("test.filtering")
            logger.debug("debug message")
            logger.info("info message")
            logger.warning("warning message")
            logger.error("error message")
            
            output = stream.getvalue()
            
            # Only WARNING and ERROR should appear
            assert "debug message" not in output
            assert "info message" not in output
            assert "warning message" in output
            assert "error message" in output
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_multiple_loggers_same_configuration(self):
        """Test that multiple loggers share the same configuration."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            stream = StringIO()
            handler = logging.StreamHandler(stream)
            setup_logging(level="INFO", handler=handler)
            
            logger1 = get_logger("module1")
            logger2 = get_logger("module2")
            logger3 = get_logger("module1.submodule")
            
            logger1.info("message from module1")
            logger2.info("message from module2")
            logger3.info("message from submodule")
            
            output = stream.getvalue()
            
            assert "message from module1" in output
            assert "message from module2" in output
            assert "message from submodule" in output
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)


class TestLoggingEdgeCases:
    """Test edge cases for logging utilities."""
    
    def test_setup_logging_invalid_level(self):
        """Test setup_logging with invalid log level."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            # This should raise AttributeError when trying to get invalid level
            with pytest.raises(AttributeError):
                setup_logging(level="INVALID_LEVEL")
                
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_get_logger_none_name(self):
        """Test get_logger with None name."""
        # This should work as logging.getLogger(None) returns root logger
        logger = get_logger(None)
        assert isinstance(logger, logging.Logger)
        # Root logger has empty name
        assert logger.name == "root"
    
    def test_logging_with_unicode_messages(self):
        """Test logging with unicode messages."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            stream = StringIO()
            handler = logging.StreamHandler(stream)
            setup_logging(handler=handler)
            
            logger = get_logger("unicode.test")
            
            # Test various unicode messages
            logger.info("Hello 世界")
            logger.info("Emoji test: 🚀 🎉 ✅")
            logger.info("Accented: café, naïve, résumé")
            
            output = stream.getvalue()
            
            assert "Hello 世界" in output
            assert "🚀 🎉 ✅" in output
            assert "café, naïve, résumé" in output
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)
    
    def test_logging_with_exception_info(self):
        """Test logging with exception information."""
        original_handlers = logging.getLogger().handlers[:]
        original_level = logging.getLogger().level
        
        try:
            stream = StringIO()
            handler = logging.StreamHandler(stream)
            setup_logging(handler=handler)
            
            logger = get_logger("exception.test")
            
            try:
                raise ValueError("Test exception")
            except ValueError:
                logger.exception("An error occurred")
            
            output = stream.getvalue()
            
            assert "An error occurred" in output
            assert "ValueError: Test exception" in output
            assert "Traceback" in output
            
        finally:
            root_logger = logging.getLogger()
            root_logger.handlers.clear()
            root_logger.handlers.extend(original_handlers)
            root_logger.setLevel(original_level)