"""Tests for tools configuration management."""

import pytest
import os
import tempfile
import yaml
from pathlib import Path
from unittest.mock import Mock, patch, mock_open

from agent_sdk.tools.config import (
    ToolConfig, ToolsConfigManager, load_tools_config, get_tool_config, get_config_manager
)


class TestToolConfig:
    """Test ToolConfig dataclass."""
    
    def test_tool_config_creation(self):
        """Test creating ToolConfig instance."""
        config = ToolConfig(
            name="test_tool",
            type="test_type",
            enabled=True,
            config={"key": "value"},
            category="test_category"
        )
        
        assert config.name == "test_tool"
        assert config.type == "test_type"
        assert config.enabled is True
        assert config.config == {"key": "value"}
        assert config.category == "test_category"
    
    def test_tool_config_defaults(self):
        """Test ToolConfig with default values."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        assert config.name == "test_tool"
        assert config.type == "test_type"
        assert config.enabled is True  # Default
        assert config.config == {}  # Default
        assert config.category == "general"  # Default
    
    @patch.dict(os.environ, {"TEST_TOOL_API_KEY": "env_value"})
    def test_tool_config_get_env_value(self):
        """Test getting environment variable values."""
        config = ToolConfig(
            name="test_tool",
            type="test_type",
            config={"api_key": "config_value"}
        )
        
        # Should get environment variable (with tool name prefix)
        env_value = config.get_env_value("api_key", "default_value")
        assert env_value == "env_value"
        
        # Should fall back to config value
        config_value = config.get_env_value("other_key", "default_value")
        assert config_value == "default_value"
    
    @patch.dict(os.environ, {"TEST_TOOL_ENABLED": "false"})
    def test_tool_config_get_env_value_boolean(self):
        """Test getting boolean environment variable values."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        # Test boolean conversion
        assert config.get_env_value("enabled", True) is False
        
        # Test various boolean representations
        with patch.dict(os.environ, {"TEST_TOOL_ENABLED": "true"}):
            assert config.get_env_value("enabled", False) is True
        
        with patch.dict(os.environ, {"TEST_TOOL_ENABLED": "1"}):
            assert config.get_env_value("enabled", False) is True
        
        with patch.dict(os.environ, {"TEST_TOOL_ENABLED": "yes"}):
            assert config.get_env_value("enabled", False) is True
        
        with patch.dict(os.environ, {"TEST_TOOL_ENABLED": "on"}):
            assert config.get_env_value("enabled", False) is True
    
    @patch.dict(os.environ, {"TEST_TOOL_PORT": "8080"})
    def test_tool_config_get_env_value_integer(self):
        """Test getting integer environment variable values."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        port = config.get_env_value("port", 3000)
        assert port == 8080
        assert isinstance(port, int)
    
    @patch.dict(os.environ, {"TEST_TOOL_TIMEOUT": "30.5"})
    def test_tool_config_get_env_value_float(self):
        """Test getting float environment variable values."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        timeout = config.get_env_value("timeout", 10.0)
        assert timeout == 30.5
        assert isinstance(timeout, float)
    
    @patch.dict(os.environ, {"TEST_TOOL_INVALID_INT": "not_a_number"})
    def test_tool_config_get_env_value_invalid_conversion(self):
        """Test handling of invalid type conversions."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        # Should fall back to string value when conversion fails
        value = config.get_env_value("invalid_int", 42)
        assert value == "not_a_number"
        assert isinstance(value, str)


class TestToolsConfigManager:
    """Test ToolsConfigManager class."""
    
    def test_config_manager_creation(self):
        """Test creating ToolsConfigManager."""
        manager = ToolsConfigManager()
        
        assert manager.config_dir == Path.cwd() / "config"
        assert manager.tools_config == {}
    
    def test_config_manager_custom_dir(self):
        """Test creating ToolsConfigManager with custom directory."""
        custom_dir = "/custom/config/dir"
        manager = ToolsConfigManager(custom_dir)
        
        assert manager.config_dir == Path(custom_dir)
    
    def test_load_config_file_not_found(self):
        """Test loading config when file doesn't exist."""
        with tempfile.TemporaryDirectory() as temp_dir:
            manager = ToolsConfigManager(temp_dir)
            
            with patch.object(manager, '_load_default_config') as mock_default:
                mock_default.return_value = {"default": "config"}
                
                result = manager.load_config("nonexistent.yaml")
                
                assert result == {"default": "config"}
                mock_default.assert_called_once()
    
    def test_load_config_valid_file(self):
        """Test loading valid configuration file."""
        config_data = {
            "tools": {
                "test_tool": {
                    "type": "test_type",
                    "enabled": True,
                    "category": "test_category",
                    "config": {"key": "value"}
                }
            }
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "tools.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("tools.yaml")
            
            assert "test_tool" in result
            tool_config = result["test_tool"]
            assert tool_config.name == "test_tool"
            assert tool_config.type == "test_type"
            assert tool_config.enabled is True
            assert tool_config.category == "test_category"
            assert tool_config.config == {"key": "value"}
    
    def test_load_config_invalid_yaml(self):
        """Test loading invalid YAML file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "invalid.yaml"
            with open(config_file, 'w') as f:
                f.write("invalid: yaml: content: [")
            
            manager = ToolsConfigManager(temp_dir)
            
            with patch.object(manager, '_load_default_config') as mock_default:
                mock_default.return_value = {"default": "config"}
                
                result = manager.load_config("invalid.yaml")
                
                assert result == {"default": "config"}
                mock_default.assert_called_once()
    
    def test_load_default_config(self):
        """Test loading default configuration."""
        manager = ToolsConfigManager()
        result = manager._load_default_config()
        
        # Should return empty dict when no config file is found
        assert result == {}
    
    def test_get_tool_config(self):
        """Test getting specific tool configuration."""
        manager = ToolsConfigManager()
        manager.tools_config = {
            "test_tool": ToolConfig("test_tool", "test_type")
        }
        
        config = manager.get_tool_config("test_tool")
        assert config is not None
        assert config.name == "test_tool"
        
        missing_config = manager.get_tool_config("missing_tool")
        assert missing_config is None
    
    def test_list_enabled_tools(self):
        """Test listing enabled tools."""
        manager = ToolsConfigManager()
        manager.tools_config = {
            "enabled_tool": ToolConfig("enabled_tool", "test", enabled=True),
            "disabled_tool": ToolConfig("disabled_tool", "test", enabled=False),
            "another_enabled": ToolConfig("another_enabled", "test", enabled=True)
        }
        
        enabled_tools = manager.list_enabled_tools()
        
        assert set(enabled_tools) == {"enabled_tool", "another_enabled"}
    
    def test_get_tools_by_category(self):
        """Test getting tools by category."""
        manager = ToolsConfigManager()
        manager.tools_config = {
            "llm_tool": ToolConfig("llm_tool", "llm", category="llm"),
            "db_tool": ToolConfig("db_tool", "database", category="database"),
            "another_llm": ToolConfig("another_llm", "llm", category="llm")
        }
        
        llm_tools = manager.get_tools_by_category("llm")
        assert len(llm_tools) == 2
        assert all(tool.category == "llm" for tool in llm_tools)
        
        db_tools = manager.get_tools_by_category("database")
        assert len(db_tools) == 1
        assert db_tools[0].name == "db_tool"
        
        empty_tools = manager.get_tools_by_category("nonexistent")
        assert empty_tools == []
    
    def test_save_config(self):
        """Test saving configuration to file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            manager = ToolsConfigManager(temp_dir)
            manager.tools_config = {
                "test_tool": ToolConfig(
                    name="test_tool",
                    type="test_type",
                    enabled=True,
                    category="test_category",
                    config={"key": "value"}
                )
            }
            
            manager.save_config("test_tools.yaml")
            
            # Verify file was created and has correct content
            config_file = Path(temp_dir) / "test_tools.yaml"
            assert config_file.exists()
            
            with open(config_file, 'r') as f:
                saved_data = yaml.safe_load(f)
            
            assert "tools" in saved_data
            assert "test_tool" in saved_data["tools"]
            tool_data = saved_data["tools"]["test_tool"]
            assert tool_data["type"] == "test_type"
            assert tool_data["enabled"] is True
            assert tool_data["category"] == "test_category"
            assert tool_data["config"] == {"key": "value"}
    
    def test_save_config_creates_directory(self):
        """Test that save_config creates directory if it doesn't exist."""
        with tempfile.TemporaryDirectory() as temp_dir:
            nested_dir = Path(temp_dir) / "nested" / "config"
            manager = ToolsConfigManager(str(nested_dir))
            manager.tools_config = {
                "test_tool": ToolConfig("test_tool", "test_type")
            }
            
            manager.save_config("tools.yaml")
            
            # Directory should be created
            assert nested_dir.exists()
            assert (nested_dir / "tools.yaml").exists()


class TestGlobalConfigFunctions:
    """Test global configuration functions."""
    
    def test_load_tools_config_default(self):
        """Test load_tools_config with default parameters."""
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            mock_instance = Mock()
            mock_instance.load_config.return_value = {"test": "config"}
            mock_manager.load_config.return_value = {"test": "config"}
            
            result = load_tools_config()
            
            assert result == {"test": "config"}
    
    def test_load_tools_config_custom_dir(self):
        """Test load_tools_config with custom directory."""
        with patch('agent_sdk.tools.config.ToolsConfigManager') as mock_class:
            mock_instance = Mock()
            mock_instance.load_config.return_value = {"custom": "config"}
            mock_class.return_value = mock_instance
            
            result = load_tools_config(config_dir="/custom/dir", config_file="custom.yaml")
            
            mock_class.assert_called_once_with("/custom/dir")
            mock_instance.load_config.assert_called_once_with("custom.yaml")
            assert result == {"custom": "config"}
    
    def test_get_tool_config_function(self):
        """Test get_tool_config global function."""
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            mock_config = ToolConfig("test_tool", "test_type")
            mock_manager.get_tool_config.return_value = mock_config
            
            result = get_tool_config("test_tool")
            
            assert result == mock_config
            mock_manager.get_tool_config.assert_called_once_with("test_tool")
    
    def test_get_config_manager_function(self):
        """Test get_config_manager global function."""
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            result = get_config_manager()
            
            assert result == mock_manager


class TestConfigEdgeCases:
    """Test edge cases for configuration management."""
    
    def test_tool_config_empty_name(self):
        """Test ToolConfig with empty name."""
        config = ToolConfig(name="", type="test_type")
        
        assert config.name == ""
        assert config.type == "test_type"
    
    def test_tool_config_special_characters(self):
        """Test ToolConfig with special characters in name."""
        config = ToolConfig(name="tool-with_special.chars", type="test_type")
        
        assert config.name == "tool-with_special.chars"
    
    @patch.dict(os.environ, {"TOOL_WITH_SPECIAL_CHARS_VALUE": "special_value"})
    def test_tool_config_env_var_special_chars(self):
        """Test environment variable lookup with special characters."""
        config = ToolConfig(name="tool-with_special.chars", type="test_type")
        
        # Environment variable should be normalized
        value = config.get_env_value("value", "default")
        assert value == "special_value"
    
    def test_config_manager_empty_tools_section(self):
        """Test loading config with empty tools section."""
        config_data = {"tools": {}}
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "empty_tools.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("empty_tools.yaml")
            
            assert result == {}
    
    def test_config_manager_missing_tools_section(self):
        """Test loading config without tools section."""
        config_data = {"other_section": {"key": "value"}}
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "no_tools.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("no_tools.yaml")
            
            assert result == {}
    
    def test_config_manager_partial_tool_config(self):
        """Test loading config with partial tool configuration."""
        config_data = {
            "tools": {
                "minimal_tool": {
                    "type": "test_type"
                    # Missing enabled, category, config
                }
            }
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "partial.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("partial.yaml")
            
            assert "minimal_tool" in result
            tool_config = result["minimal_tool"]
            assert tool_config.name == "minimal_tool"
            assert tool_config.type == "test_type"
            assert tool_config.enabled is True  # Default
            assert tool_config.category == "general"  # Default
            assert tool_config.config == {}  # Default
    
    @patch('builtins.open', side_effect=PermissionError("Permission denied"))
    def test_save_config_permission_error(self, mock_open):
        """Test save_config with permission error."""
        manager = ToolsConfigManager()
        manager.tools_config = {"test": ToolConfig("test", "type")}
        
        # Should not raise exception, but should log error
        with patch('agent_sdk.tools.config.logger') as mock_logger:
            manager.save_config("test.yaml")
            mock_logger.error.assert_called()
    
    def test_load_config_with_unicode_content(self):
        """Test loading config with unicode content."""
        config_data = {
            "tools": {
                "unicode_tool": {
                    "type": "test_type",
                    "config": {
                        "message": "Hello 世界",
                        "emoji": "🚀",
                        "accented": "café"
                    }
                }
            }
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "unicode.yaml"
            with open(config_file, 'w', encoding='utf-8') as f:
                yaml.dump(config_data, f, allow_unicode=True)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("unicode.yaml")
            
            assert "unicode_tool" in result
            tool_config = result["unicode_tool"]
            assert tool_config.config["message"] == "Hello 世界"
            assert tool_config.config["emoji"] == "🚀"
            assert tool_config.config["accented"] == "café"