"""Tests for tools configuration management."""

import pytest
import os
import tempfile
import yaml
from pathlib import Path
from unittest.mock import Mock, patch, mock_open

from agent_sdk.tools.config import (
    ToolConfig, ToolsConfigManager, load_tools_config, get_tool_config, get_config_manager
)


class TestToolConfig:
    """Test ToolConfig dataclass."""
    
    def test_tool_config_creation(self):
        """Test creating ToolConfig instance."""
        config = ToolConfig(
            name="test_tool",
            type="test_type",
            enabled=True,
            config={"key": "value"},
            category="test_category"
        )
        
        assert config.name == "test_tool"
        assert config.type == "test_type"
        assert config.enabled is True
        assert config.config == {"key": "value"}
        assert config.category == "test_category"
    
    def test_tool_config_defaults(self):
        """Test ToolConfig with default values."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        assert config.name == "test_tool"
        assert config.type == "test_type"
        assert config.enabled is True  # Default
        assert config.config == {}  # Default
        assert config.category == "general"  # Default
    
    @patch.dict(os.environ, {"TEST_TOOL_API_KEY": "env_value"})
    def test_tool_config_get_env_value(self):
        """Test getting environment variable values."""
        config = ToolConfig(
            name="test_tool",
            type="test_type",
            config={"api_key": "config_value"}
        )
        
        # Should get environment variable (with tool name prefix)
        env_value = config.get_env_value("api_key", "default_value")
        assert env_value == "env_value"
        
        # Should fall back to config value
        config_value = config.get_env_value("other_key", "default_value")
        assert config_value == "default_value"
    
    @patch.dict(os.environ, {"TEST_TOOL_ENABLED": "false"})
    def test_tool_config_get_env_value_boolean(self):
        """Test getting boolean environment variable values."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        # Test boolean conversion
        assert config.get_env_value("enabled", True) is False
        
        # Test various boolean representations
        with patch.dict(os.environ, {"TEST_TOOL_ENABLED": "true"}):
            assert config.get_env_value("enabled", False) is True
        
        with patch.dict(os.environ, {"TEST_TOOL_ENABLED": "1"}):
            assert config.get_env_value("enabled", False) is True
        
        with patch.dict(os.environ, {"TEST_TOOL_ENABLED": "yes"}):
            assert config.get_env_value("enabled", False) is True
        
        with patch.dict(os.environ, {"TEST_TOOL_ENABLED": "on"}):
            assert config.get_env_value("enabled", False) is True
    
    @patch.dict(os.environ, {"TEST_TOOL_PORT": "8080"})
    def test_tool_config_get_env_value_integer(self):
        """Test getting integer environment variable values."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        port = config.get_env_value("port", 3000)
        assert port == 8080
        assert isinstance(port, int)
    
    @patch.dict(os.environ, {"TEST_TOOL_TIMEOUT": "30.5"})
    def test_tool_config_get_env_value_float(self):
        """Test getting float environment variable values."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        timeout = config.get_env_value("timeout", 10.0)
        assert timeout == 30.5
        assert isinstance(timeout, float)
    
    @patch.dict(os.environ, {"TEST_TOOL_INVALID_INT": "not_a_number"})
    def test_tool_config_get_env_value_invalid_conversion(self):
        """Test handling of invalid type conversions."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        # Should fall back to string value when conversion fails
        value = config.get_env_value("invalid_int", 42)
        assert value == "not_a_number"
        assert isinstance(value, str)
    
    @patch.dict(os.environ, {"TEST_TOOL_INVALID_FLOAT": "not_a_float"})
    def test_tool_config_get_env_value_invalid_float_conversion(self):
        """Test handling of invalid float conversions."""
        config = ToolConfig(name="test_tool", type="test_type")
        
        # Should fall back to string value when float conversion fails
        value = config.get_env_value("invalid_float", 3.14)
        assert value == "not_a_float"
        assert isinstance(value, str)


class TestToolsConfigManager:
    """Test ToolsConfigManager class."""
    
    def test_config_manager_creation(self):
        """Test creating ToolsConfigManager."""
        manager = ToolsConfigManager()
        
        assert manager.config_dir == Path.cwd() / "config"
        assert manager.tools_config == {}
    
    def test_config_manager_custom_dir(self):
        """Test creating ToolsConfigManager with custom directory."""
        custom_dir = "/custom/config/dir"
        manager = ToolsConfigManager(custom_dir)
        
        assert manager.config_dir == Path(custom_dir)
    
    def test_load_config_file_not_found(self):
        """Test loading config when file doesn't exist."""
        with tempfile.TemporaryDirectory() as temp_dir:
            manager = ToolsConfigManager(temp_dir)
            
            with patch.object(manager, '_load_default_config') as mock_default:
                mock_default.return_value = {"default": "config"}
                
                result = manager.load_config("nonexistent.yaml")
                
                assert result == {"default": "config"}
                mock_default.assert_called_once()
    
    def test_load_config_valid_file(self):
        """Test loading valid configuration file."""
        config_data = {
            "tools": {
                "test_tool": {
                    "type": "test_type",
                    "enabled": True,
                    "category": "test_category",
                    "config": {"key": "value"}
                }
            }
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "tools.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("tools.yaml")
            
            assert "test_tool" in result
            tool_config = result["test_tool"]
            assert tool_config.name == "test_tool"
            assert tool_config.type == "test_type"
            assert tool_config.enabled is True
            assert tool_config.category == "test_category"
            assert tool_config.config == {"key": "value"}
    
    def test_load_config_invalid_yaml(self):
        """Test loading invalid YAML file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "invalid.yaml"
            with open(config_file, 'w') as f:
                f.write("invalid: yaml: content: [")
            
            manager = ToolsConfigManager(temp_dir)
            
            with patch.object(manager, '_load_default_config') as mock_default:
                mock_default.return_value = {"default": "config"}
                
                result = manager.load_config("invalid.yaml")
                
                assert result == {"default": "config"}
                mock_default.assert_called_once()
    
    def test_load_default_config(self):
        """Test loading default configuration."""
        manager = ToolsConfigManager()
        result = manager._load_default_config()
        
        # Should return empty dict when no config file is found
        assert result == {}
    
    def test_get_tool_config(self):
        """Test getting specific tool configuration."""
        manager = ToolsConfigManager()
        manager.tools_config = {
            "test_tool": ToolConfig("test_tool", "test_type")
        }
        
        config = manager.get_tool_config("test_tool")
        assert config is not None
        assert config.name == "test_tool"
        
        missing_config = manager.get_tool_config("missing_tool")
        assert missing_config is None
    
    def test_list_enabled_tools(self):
        """Test listing enabled tools."""
        manager = ToolsConfigManager()
        manager.tools_config = {
            "enabled_tool": ToolConfig("enabled_tool", "test", enabled=True),
            "disabled_tool": ToolConfig("disabled_tool", "test", enabled=False),
            "another_enabled": ToolConfig("another_enabled", "test", enabled=True)
        }
        
        enabled_tools = manager.list_enabled_tools()
        
        assert set(enabled_tools) == {"enabled_tool", "another_enabled"}
    
    def test_get_tools_by_category(self):
        """Test getting tools by category."""
        manager = ToolsConfigManager()
        manager.tools_config = {
            "llm_tool": ToolConfig("llm_tool", "llm", category="llm"),
            "db_tool": ToolConfig("db_tool", "database", category="database"),
            "another_llm": ToolConfig("another_llm", "llm", category="llm")
        }
        
        llm_tools = manager.get_tools_by_category("llm")
        assert len(llm_tools) == 2
        assert all(tool.category == "llm" for tool in llm_tools)
        
        db_tools = manager.get_tools_by_category("database")
        assert len(db_tools) == 1
        assert db_tools[0].name == "db_tool"
        
        empty_tools = manager.get_tools_by_category("nonexistent")
        assert empty_tools == []
    
    def test_save_config(self):
        """Test saving configuration to file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            manager = ToolsConfigManager(temp_dir)
            manager.tools_config = {
                "test_tool": ToolConfig(
                    name="test_tool",
                    type="test_type",
                    enabled=True,
                    category="test_category",
                    config={"key": "value"}
                )
            }
            
            manager.save_config("test_tools.yaml")
            
            # Verify file was created and has correct content
            config_file = Path(temp_dir) / "test_tools.yaml"
            assert config_file.exists()
            
            with open(config_file, 'r') as f:
                saved_data = yaml.safe_load(f)
            
            assert "tools" in saved_data
            assert "test_tool" in saved_data["tools"]
            tool_data = saved_data["tools"]["test_tool"]
            assert tool_data["type"] == "test_type"
            assert tool_data["enabled"] is True
            assert tool_data["category"] == "test_category"
            assert tool_data["config"] == {"key": "value"}
    
    def test_save_config_creates_directory(self):
        """Test that save_config creates directory if it doesn't exist."""
        with tempfile.TemporaryDirectory() as temp_dir:
            nested_dir = Path(temp_dir) / "nested" / "config"
            manager = ToolsConfigManager(str(nested_dir))
            manager.tools_config = {
                "test_tool": ToolConfig("test_tool", "test_type")
            }
            
            manager.save_config("tools.yaml")
            
            # Directory should be created
            assert nested_dir.exists()
            assert (nested_dir / "tools.yaml").exists()


class TestGlobalConfigFunctions:
    """Test global configuration functions."""
    
    def test_load_tools_config_default(self):
        """Test load_tools_config with default parameters."""
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            mock_instance = Mock()
            mock_instance.load_config.return_value = {"test": "config"}
            mock_manager.load_config.return_value = {"test": "config"}
            
            result = load_tools_config()
            
            assert result == {"test": "config"}
    
    def test_load_tools_config_custom_dir(self):
        """Test load_tools_config with custom directory."""
        with patch('agent_sdk.tools.config.ToolsConfigManager') as mock_class:
            mock_instance = Mock()
            mock_instance.load_config.return_value = {"custom": "config"}
            mock_class.return_value = mock_instance
            
            result = load_tools_config(config_dir="/custom/dir", config_file="custom.yaml")
            
            mock_class.assert_called_once_with("/custom/dir")
            mock_instance.load_config.assert_called_once_with("custom.yaml")
            assert result == {"custom": "config"}
    
    def test_get_tool_config_function(self):
        """Test get_tool_config global function."""
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            mock_config = ToolConfig("test_tool", "test_type")
            mock_manager.get_tool_config.return_value = mock_config
            
            result = get_tool_config("test_tool")
            
            assert result == mock_config
            mock_manager.get_tool_config.assert_called_once_with("test_tool")
    
    def test_get_config_manager_function(self):
        """Test get_config_manager global function."""
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            result = get_config_manager()
            
            assert result == mock_manager


class TestConfigEdgeCases:
    """Test edge cases for configuration management."""
    
    def test_tool_config_empty_name(self):
        """Test ToolConfig with empty name."""
        config = ToolConfig(name="", type="test_type")
        
        assert config.name == ""
        assert config.type == "test_type"
    
    def test_tool_config_special_characters(self):
        """Test ToolConfig with special characters in name."""
        config = ToolConfig(name="tool-with_special.chars", type="test_type")
        
        assert config.name == "tool-with_special.chars"
    
    @patch.dict(os.environ, {"TOOL_WITH_SPECIAL_CHARS_VALUE": "special_value"})
    def test_tool_config_env_var_special_chars(self):
        """Test environment variable lookup with special characters."""
        config = ToolConfig(name="tool-with_special.chars", type="test_type")
        
        # Environment variable should be normalized
        value = config.get_env_value("value", "default")
        assert value == "special_value"
    
    def test_config_manager_empty_tools_section(self):
        """Test loading config with empty tools section."""
        config_data = {"tools": {}}
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "empty_tools.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("empty_tools.yaml")
            
            assert result == {}
    
    def test_config_manager_missing_tools_section(self):
        """Test loading config without tools section."""
        config_data = {"other_section": {"key": "value"}}
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "no_tools.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("no_tools.yaml")
            
            assert result == {}
    
    def test_config_manager_partial_tool_config(self):
        """Test loading config with partial tool configuration."""
        config_data = {
            "tools": {
                "minimal_tool": {
                    "type": "test_type"
                    # Missing enabled, category, config
                }
            }
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "partial.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("partial.yaml")
            
            assert "minimal_tool" in result
            tool_config = result["minimal_tool"]
            assert tool_config.name == "minimal_tool"
            assert tool_config.type == "test_type"
            assert tool_config.enabled is True  # Default
            assert tool_config.category == "general"  # Default
            assert tool_config.config == {}  # Default
    
    @patch('builtins.open', side_effect=PermissionError("Permission denied"))
    def test_save_config_permission_error(self, mock_open):
        """Test save_config with permission error."""
        manager = ToolsConfigManager()
        manager.tools_config = {"test": ToolConfig("test", "type")}
        
        # Should not raise exception, but should log error
        with patch('agent_sdk.tools.config.logger') as mock_logger:
            manager.save_config("test.yaml")
            mock_logger.error.assert_called()
    
    def test_load_config_with_unicode_content(self):
        """Test loading config with unicode content."""
        config_data = {
            "tools": {
                "unicode_tool": {
                    "type": "test_type",
                    "config": {
                        "message": "Hello 世界",
                        "emoji": "🚀",
                        "accented": "café"
                    }
                }
            }
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "unicode.yaml"
            with open(config_file, 'w', encoding='utf-8') as f:
                yaml.dump(config_data, f, allow_unicode=True)
            
            manager = ToolsConfigManager(temp_dir)
            result = manager.load_config("unicode.yaml")
            
            assert "unicode_tool" in result
            tool_config = result["unicode_tool"]
            assert tool_config.config["message"] == "Hello 世界"
            assert tool_config.config["emoji"] == "🚀"
            assert tool_config.config["accented"] == "café"


class TestFactoryConfiguration:
    """Test factory configuration loading."""
    
    def test_load_factory_config_file_not_found(self):
        """Test loading factory config when file doesn't exist."""
        with tempfile.TemporaryDirectory() as temp_dir:
            manager = ToolsConfigManager(temp_dir)
            
            with patch.object(manager, '_load_default_factories') as mock_default:
                mock_default.return_value = ({}, [])
                
                factories, basic_tools = manager.load_factory_config("nonexistent.yaml")
                
                assert factories == {}
                assert basic_tools == []
                mock_default.assert_called_once()
    
    def test_load_factory_config_valid_file(self):
        """Test loading valid factory configuration file."""
        config_data = {
            "tool_factories": {
                "llm": {
                    "openai": {
                        "module_path": "agent_sdk.tools.llm.openai",
                        "class_name": "OpenAITool",
                        "category": "llm"
                    },
                    "gemini": {
                        "module_path": "agent_sdk.tools.llm.gemini", 
                        "class_name": "GeminiTool"
                    }
                },
                "database": {
                    "sqlite": {
                        "module_path": "agent_sdk.tools.database.sqlite",
                        "class_name": "SQLiteTool",
                        "category": "database"
                    }
                }
            },
            "basic_tools": {
                "default_llm": {
                    "factory_type": "llm",
                    "factory_name": "openai",
                    "config": {
                        "api_key": "test_key",
                        "model": "gpt-3.5-turbo"
                    }
                },
                "default_db": {
                    "factory_type": "database",
                    "factory_name": "sqlite",
                    "config": {
                        "database_path": ":memory:"
                    }
                }
            }
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "tool_factories.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            factories, basic_tools = manager.load_factory_config("tool_factories.yaml")
            
            # Check factories
            assert "llm" in factories
            assert "database" in factories
            assert "openai" in factories["llm"]
            assert "gemini" in factories["llm"]
            assert "sqlite" in factories["database"]
            
            # Check factory details
            openai_factory = factories["llm"]["openai"]
            assert openai_factory.module_path == "agent_sdk.tools.llm.openai"
            assert openai_factory.class_name == "OpenAITool"
            assert openai_factory.category == "llm"
            
            gemini_factory = factories["llm"]["gemini"]
            assert gemini_factory.category == "llm"  # Default to tool_type
            
            # Check basic tools
            assert len(basic_tools) == 2
            
            # Find default_llm tool
            default_llm = next((tool for tool in basic_tools if tool[0] == "default_llm"), None)
            assert default_llm is not None
            tool_name, factory, config = default_llm
            assert tool_name == "default_llm"
            assert factory.class_name == "OpenAITool"
            assert config["api_key"] == "test_key"
            assert config["model"] == "gpt-3.5-turbo"
    
    def test_load_factory_config_missing_factory_for_basic_tool(self):
        """Test loading factory config with missing factory for basic tool."""
        config_data = {
            "tool_factories": {
                "llm": {
                    "openai": {
                        "module_path": "agent_sdk.tools.llm.openai",
                        "class_name": "OpenAITool"
                    }
                }
            },
            "basic_tools": {
                "missing_factory_tool": {
                    "factory_type": "nonexistent",
                    "factory_name": "missing",
                    "config": {}
                },
                "valid_tool": {
                    "factory_type": "llm",
                    "factory_name": "openai",
                    "config": {}
                }
            }
        }
        
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "tool_factories.yaml"
            with open(config_file, 'w') as f:
                yaml.dump(config_data, f)
            
            manager = ToolsConfigManager(temp_dir)
            
            with patch('agent_sdk.tools.config.logger') as mock_logger:
                factories, basic_tools = manager.load_factory_config("tool_factories.yaml")
                
                # Should log warning for missing factory
                mock_logger.warning.assert_called()
                
                # Should only include valid tool
                assert len(basic_tools) == 1
                assert basic_tools[0][0] == "valid_tool"
    
    def test_load_factory_config_invalid_yaml(self):
        """Test loading invalid factory YAML file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "invalid_factories.yaml"
            with open(config_file, 'w') as f:
                f.write("invalid: yaml: content: [")
            
            manager = ToolsConfigManager(temp_dir)
            
            with patch.object(manager, '_load_default_factories') as mock_default:
                mock_default.return_value = ({}, [])
                
                factories, basic_tools = manager.load_factory_config("invalid_factories.yaml")
                
                assert factories == {}
                assert basic_tools == []
                mock_default.assert_called_once()
    
    def test_load_default_factories(self):
        """Test loading default factory configuration."""
        manager = ToolsConfigManager()
        factories, basic_tools = manager._load_default_factories()
        
        # Should return empty structures
        assert factories == {}
        assert basic_tools == []
        assert manager.tool_factories == {}
        assert manager.basic_tools == []
    
    def test_get_tool_factories(self):
        """Test getting tool factories."""
        manager = ToolsConfigManager()
        mock_factory = Mock()
        manager.tool_factories = {"test": {"factory": mock_factory}}
        
        factories = manager.get_tool_factories()
        assert factories == {"test": {"factory": mock_factory}}
    
    def test_get_basic_tools(self):
        """Test getting basic tools."""
        manager = ToolsConfigManager()
        basic_tools = [("tool1", Mock(), {}), ("tool2", Mock(), {})]
        manager.basic_tools = basic_tools
        
        result = manager.get_basic_tools()
        assert result == basic_tools
    
    def test_find_tool_factory_exact_match(self):
        """Test finding tool factory with exact match."""
        from agent_sdk.tools.config import ToolFactory
        
        manager = ToolsConfigManager()
        factory = ToolFactory("test.module", "TestClass")
        manager.tool_factories = {
            "llm": {
                "openai": factory
            }
        }
        
        result = manager.find_tool_factory("llm", "openai")
        assert result == factory
    
    def test_find_tool_factory_partial_match(self):
        """Test finding tool factory with partial match."""
        from agent_sdk.tools.config import ToolFactory
        
        manager = ToolsConfigManager()
        factory = ToolFactory("test.module", "TestClass")
        manager.tool_factories = {
            "llm": {
                "gpt": factory
            }
        }
        
        result = manager.find_tool_factory("llm", "gpt-3.5-turbo")
        assert result == factory
    
    def test_find_tool_factory_not_found(self):
        """Test finding tool factory when not found."""
        manager = ToolsConfigManager()
        manager.tool_factories = {
            "llm": {
                "openai": Mock()
            }
        }
        
        result = manager.find_tool_factory("llm", "nonexistent")
        assert result is None
        
        result = manager.find_tool_factory("nonexistent_type", "openai")
        assert result is None
    
    def test_find_tool_factory_case_insensitive(self):
        """Test finding tool factory with case insensitive matching."""
        from agent_sdk.tools.config import ToolFactory
        
        manager = ToolsConfigManager()
        factory = ToolFactory("test.module", "TestClass")
        manager.tool_factories = {
            "llm": {
                "openai": factory
            }
        }
        
        result = manager.find_tool_factory("LLM", "OpenAI")
        assert result == factory


class TestGlobalFactoryFunctions:
    """Test global factory configuration functions."""
    
    def test_load_factory_config_function(self):
        """Test load_factory_config global function."""
        from agent_sdk.tools.config import load_factory_config
        
        with patch('agent_sdk.tools.config.ToolsConfigManager') as mock_class:
            mock_instance = Mock()
            mock_instance.load_factory_config.return_value = ({"test": "factories"}, [("tool", Mock(), {})])
            mock_class.return_value = mock_instance
            
            factories, basic_tools = load_factory_config(config_dir="/custom/dir", config_file="custom_factories.yaml")
            
            mock_class.assert_called_once_with("/custom/dir")
            mock_instance.load_factory_config.assert_called_once_with("custom_factories.yaml")
            assert factories == {"test": "factories"}
            assert len(basic_tools) == 1
    
    def test_get_tool_factories_function(self):
        """Test get_tool_factories global function."""
        from agent_sdk.tools.config import get_tool_factories
        
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            mock_manager.get_tool_factories.return_value = {"test": "factories"}
            
            result = get_tool_factories()
            
            assert result == {"test": "factories"}
            mock_manager.get_tool_factories.assert_called_once()
    
    def test_get_basic_tools_function(self):
        """Test get_basic_tools global function."""
        from agent_sdk.tools.config import get_basic_tools
        
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            mock_manager.get_basic_tools.return_value = [("tool", Mock(), {})]
            
            result = get_basic_tools()
            
            assert len(result) == 1
            mock_manager.get_basic_tools.assert_called_once()
    
    def test_find_tool_factory_function(self):
        """Test find_tool_factory global function."""
        from agent_sdk.tools.config import find_tool_factory
        
        with patch('agent_sdk.tools.config._config_manager') as mock_manager:
            mock_factory = Mock()
            mock_manager.find_tool_factory.return_value = mock_factory
            
            result = find_tool_factory("llm", "openai")
            
            assert result == mock_factory
            mock_manager.find_tool_factory.assert_called_once_with("llm", "openai")


class TestToolFactory:
    """Test ToolFactory dataclass."""
    
    def test_tool_factory_creation(self):
        """Test creating ToolFactory instance."""
        from agent_sdk.tools.config import ToolFactory
        
        factory = ToolFactory(
            module_path="test.module",
            class_name="TestClass",
            category="test_category"
        )
        
        assert factory.module_path == "test.module"
        assert factory.class_name == "TestClass"
        assert factory.category == "test_category"
    
    def test_tool_factory_default_category(self):
        """Test ToolFactory with default category."""
        from agent_sdk.tools.config import ToolFactory
        
        factory = ToolFactory(
            module_path="test.module",
            class_name="TestClass"
        )
        
        assert factory.module_path == "test.module"
        assert factory.class_name == "TestClass"
        assert factory.category == "general"
    
    def test_tool_factory_immutable(self):
        """Test that ToolFactory is immutable."""
        from agent_sdk.tools.config import ToolFactory
        
        factory = ToolFactory("test.module", "TestClass")
        
        # Should not be able to modify frozen dataclass
        with pytest.raises(AttributeError):
            factory.module_path = "new.module"


class TestResetConfigManager:
    """Test reset_config_manager function."""
    
    def test_reset_config_manager(self):
        """Test resetting the global config manager."""
        from agent_sdk.tools.config import reset_config_manager, get_config_manager
        
        # Get original manager
        original_manager = get_config_manager()
        
        # Reset manager
        reset_config_manager()
        
        # Should be a new instance
        new_manager = get_config_manager()
        assert new_manager is not original_manager
        assert isinstance(new_manager, ToolsConfigManager)