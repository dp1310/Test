"""Comprehensive tests for state management module."""

import pytest
import time
from datetime import timedelta
from unittest.mock import Mock, patch
from typing import Dict, Any, List

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from agent_sdk.core.state import (
    StageState, StageExecution, StageStateObserver, LoggingObserver,
    MetricsObserver, StageStateManager, stage_execution_context,
    get_state_manager, get_metrics, get_workflow_status, configure_monitoring
)
from agent_sdk.core.stages import Stage


class TestStageExecutionComprehensive:
    """Comprehensive tests for StageExecution."""
    
    def test_stage_execution_initialization_complete(self):
        """Test complete StageExecution initialization."""
        execution = StageExecution(
            stage=Stage.PERCEIVE,
            function_name="test_function",
            workflow_id="test_workflow",
            metadata={"custom": "data"}
        )
        
        assert execution.stage == Stage.PERCEIVE
        assert execution.function_name == "test_function"
        assert execution.workflow_id == "test_workflow"
        assert execution.state == StageState.CREATED
        assert execution.metadata == {"custom": "data"}
        assert execution.result is None
        assert execution.error is None
        assert execution.start_time is not None
        assert execution.end_time is None
    
    def test_stage_execution_duration_not_finished(self):
        """Test duration calculation when execution is not finished."""
        execution = StageExecution(Stage.PERCEIVE, "test", "workflow")
        
        # Should return None when not finished
        assert execution.duration is None
    
    def test_stage_execution_duration_finished(self):
        """Test duration calculation when execution is finished."""
        from datetime import timedelta
        execution = StageExecution(Stage.PERCEIVE, "test", "workflow")
        execution.end_time = execution.start_time + timedelta(seconds=1.5)
        
        duration = execution.duration
        assert duration is not None
        assert abs(duration - 1.5) < 0.01  # Allow small floating point differences
    
    def test_stage_execution_is_finished_states(self):
        """Test is_finished property for different states."""
        execution = StageExecution(Stage.PERCEIVE, "test", "workflow")
        
        # Not finished states
        for state in [StageState.CREATED, StageState.STARTED, StageState.RUNNING]:
            execution.state = state
            assert not execution.is_finished
        
        # Finished states
        for state in [StageState.COMPLETED, StageState.ERROR, StageState.CANCELLED]:
            execution.state = state
            assert execution.is_finished
    
    def test_stage_execution_to_dict_complete(self):
        """Test complete to_dict conversion."""
        from datetime import datetime
        execution = StageExecution(
            stage=Stage.REASON,
            function_name="reason_func",
            workflow_id="test_workflow",
            metadata={"key": "value"}
        )
        execution.state = StageState.COMPLETED
        execution.result = {"output": "data"}
        execution.error = None
        execution.start_time = datetime.now()
        execution.end_time = execution.start_time + timedelta(seconds=2.0)
        
        result_dict = execution.to_dict()
        
        assert result_dict["stage"] == "REASON"
        assert result_dict["function_name"] == "reason_func"
        assert result_dict["workflow_id"] == "test_workflow"
        assert result_dict["state"] == "completed"
        assert result_dict["result"] == {"output": "data"}
        assert result_dict["error"] is None
        assert result_dict["metadata"] == {"key": "value"}
        assert abs(result_dict["duration"] - 2.0) < 0.01
    
    def test_stage_execution_to_dict_with_error(self):
        """Test to_dict with error state."""
        from datetime import timedelta, datetime
        execution = StageExecution(Stage.ACT, "act_func", "workflow")
        execution.state = StageState.ERROR
        execution.error = ValueError("Test error")
        execution.start_time = datetime.now()
        execution.end_time = execution.start_time + timedelta(seconds=0.5)
        
        result_dict = execution.to_dict()
        
        assert result_dict["state"] == "error"
        assert result_dict["error"] == "Test error"
        assert result_dict["result"] is None


class TestLoggingObserverComprehensive:
    """Comprehensive tests for LoggingObserver."""
    
    def test_logging_observer_initialization_levels(self):
        """Test LoggingObserver initialization with different log levels."""
        # Test default level
        observer = LoggingObserver()
        assert observer.logger.level == 20  # INFO level
        
        # Test custom level
        observer = LoggingObserver(log_level="DEBUG")
        assert observer.logger.level == 10  # DEBUG level
        
        observer = LoggingObserver(log_level="ERROR")
        assert observer.logger.level == 40  # ERROR level
    
    def test_logging_observer_stage_state_changed(self):
        """Test logging on stage state changes."""
        observer = LoggingObserver(log_level="DEBUG")
        execution = StageExecution(Stage.PERCEIVE, "test_func", "workflow")
        
        with patch.object(observer.logger, 'info') as mock_info:
            observer.on_stage_state_changed(execution)
            
            mock_info.assert_called_once()
            log_message = mock_info.call_args[0][0]
            assert "test_func" in log_message
            assert "PERCEIVE" in log_message
            assert "CREATED" in log_message
    
    def test_logging_observer_workflow_started(self):
        """Test logging on workflow start."""
        observer = LoggingObserver()
        
        with patch.object(observer.logger, 'info') as mock_info:
            observer.on_workflow_started("test_workflow")
            
            mock_info.assert_called_once()
            log_message = mock_info.call_args[0][0]
            assert "Workflow started" in log_message
            assert "test_workflow" in log_message
    
    def test_logging_observer_workflow_completed(self):
        """Test logging on workflow completion."""
        observer = LoggingObserver()
        executions = [
            StageExecution(Stage.PERCEIVE, "func1", "workflow"),
            StageExecution(Stage.REASON, "func2", "workflow")
        ]
        
        with patch.object(observer.logger, 'info') as mock_info:
            observer.on_workflow_completed("test_workflow", executions)
            
            mock_info.assert_called_once()
            log_message = mock_info.call_args[0][0]
            assert "Workflow completed" in log_message
            assert "test_workflow" in log_message
            assert "2 executions" in log_message
    
    def test_logging_observer_workflow_error(self):
        """Test logging on workflow error."""
        observer = LoggingObserver()
        error = RuntimeError("Workflow failed")
        
        with patch.object(observer.logger, 'error') as mock_error:
            observer.on_workflow_error("test_workflow", error)
            
            mock_error.assert_called_once()
            log_message = mock_error.call_args[0][0]
            assert "Workflow error" in log_message
            assert "test_workflow" in log_message
            assert "Workflow failed" in log_message


class TestMetricsObserverComprehensive:
    """Comprehensive tests for MetricsObserver."""
    
    def test_metrics_observer_initialization(self):
        """Test MetricsObserver initialization."""
        observer = MetricsObserver()
        
        assert observer.execution_counts == {}
        assert observer.execution_times == {}
        assert observer.error_counts == {}
        assert observer.workflow_counts == {}
    
    def test_metrics_observer_stage_state_tracking(self):
        """Test metrics tracking for stage state changes."""
        observer = MetricsObserver()
        execution = StageExecution(Stage.PERCEIVE, "test_func", "workflow")
        
        # Track state changes
        execution.state = StageState.STARTED
        observer.on_stage_state_changed(execution)
        
        execution.state = StageState.RUNNING
        observer.on_stage_state_changed(execution)
        
        execution.state = StageState.COMPLETED
        execution.end_time = execution.start_time + timedelta(seconds=1.5)
        observer.on_stage_state_changed(execution)
        
        # Check metrics
        assert observer.execution_counts[Stage.PERCEIVE] == 1
        assert len(observer.execution_times[Stage.PERCEIVE]) == 1
        assert abs(observer.execution_times[Stage.PERCEIVE][0] - 1.5) < 0.01
    
    def test_metrics_observer_error_tracking(self):
        """Test error metrics tracking."""
        observer = MetricsObserver()
        execution = StageExecution(Stage.REASON, "failing_func", "workflow")
        
        execution.state = StageState.ERROR
        execution.error = ValueError("Test error")
        execution.end_time = execution.start_time + timedelta(seconds=0.5)
        observer.on_stage_state_changed(execution)
        
        assert observer.error_counts[Stage.REASON] == 1
        # Should still track execution time even for errors
        assert len(observer.execution_times[Stage.REASON]) == 1
    
    def test_metrics_observer_workflow_tracking(self):
        """Test workflow metrics tracking."""
        observer = MetricsObserver()
        
        # Track workflow completion
        executions = [
            StageExecution(Stage.PERCEIVE, "func1", "workflow1"),
            StageExecution(Stage.REASON, "func2", "workflow1")
        ]
        observer.on_workflow_completed("workflow1", executions)
        
        # Track workflow error
        observer.on_workflow_error("workflow2", RuntimeError("Error"))
        
        assert observer.workflow_counts["completed"] == 1
        assert observer.workflow_counts["errors"] == 1
    
    def test_metrics_observer_get_metrics(self):
        """Test getting comprehensive metrics."""
        observer = MetricsObserver()
        
        # Add some test data
        observer.execution_counts[Stage.PERCEIVE] = 5
        observer.execution_counts[Stage.REASON] = 3
        observer.execution_times[Stage.PERCEIVE] = [1.0, 1.5, 2.0, 1.2, 0.8]
        observer.execution_times[Stage.REASON] = [2.5, 3.0, 2.2]
        observer.error_counts[Stage.PERCEIVE] = 1
        observer.workflow_counts["completed"] = 2
        observer.workflow_counts["errors"] = 1
        
        metrics = observer.get_metrics()
        
        # Check structure
        assert "execution_counts" in metrics
        assert "execution_times" in metrics
        assert "error_counts" in metrics
        assert "workflow_counts" in metrics
        assert "summary" in metrics
        
        # Check summary calculations
        summary = metrics["summary"]
        assert summary["total_executions"] == 8
        assert summary["total_errors"] == 1
        assert summary["average_execution_time"] == pytest.approx(1.775, rel=1e-2)
        assert summary["total_workflows"] == 3


class TestStageStateManagerComprehensive:
    """Comprehensive tests for StageStateManager."""
    
    def test_stage_state_manager_initialization(self):
        """Test StageStateManager initialization."""
        manager = StageStateManager()
        
        assert manager.executions == {}
        assert manager.observers == []
    
    def test_stage_state_manager_observer_management(self):
        """Test adding and removing observers."""
        manager = StageStateManager()
        observer1 = LoggingObserver()
        observer2 = MetricsObserver()
        
        # Add observers
        manager.add_observer(observer1)
        manager.add_observer(observer2)
        
        assert len(manager.observers) == 2
        assert observer1 in manager.observers
        assert observer2 in manager.observers
        
        # Remove observer
        manager.remove_observer(observer1)
        
        assert len(manager.observers) == 1
        assert observer1 not in manager.observers
        assert observer2 in manager.observers
    
    def test_stage_state_manager_create_execution(self):
        """Test creating stage executions."""
        manager = StageStateManager()
        
        execution = manager.create_execution(
            Stage.PERCEIVE, 
            "test_function", 
            "test_workflow"
        )
        
        assert isinstance(execution, StageExecution)
        assert execution.stage == Stage.PERCEIVE
        assert execution.function_name == "test_function"
        assert execution.workflow_id == "test_workflow"
        assert execution.state == StageState.CREATED
        
        # Should be stored in manager
        workflow_executions = manager.executions.get("test_workflow", [])
        assert execution in workflow_executions
    
    def test_stage_state_manager_update_state(self):
        """Test updating execution state."""
        manager = StageStateManager()
        observer = Mock(spec=StageStateObserver)
        manager.add_observer(observer)
        
        execution = manager.create_execution(Stage.REASON, "func", "workflow")
        
        # Update state
        manager.update_state(
            execution, 
            StageState.RUNNING,
            result={"data": "value"},
            metadata={"info": "extra"}
        )
        
        assert execution.state == StageState.RUNNING
        assert execution.result == {"data": "value"}
        assert execution.metadata == {"info": "extra"}
        
        # Observer should be notified
        observer.on_stage_state_changed.assert_called_once_with(execution)
    
    def test_stage_state_manager_update_state_with_error(self):
        """Test updating state with error."""
        manager = StageStateManager()
        execution = manager.create_execution(Stage.ACT, "func", "workflow")
        
        error = ValueError("Test error")
        manager.update_state(execution, StageState.ERROR, error=error)
        
        assert execution.state == StageState.ERROR
        assert execution.error == error
        assert execution.end_time is not None
    
    def test_stage_state_manager_workflow_lifecycle(self):
        """Test complete workflow lifecycle management."""
        manager = StageStateManager()
        observer = Mock(spec=StageStateObserver)
        manager.add_observer(observer)
        
        workflow_id = "test_workflow"
        
        # Start workflow
        manager.start_workflow(workflow_id)
        observer.on_workflow_started.assert_called_once_with(workflow_id)
        
        # Create and complete some executions
        exec1 = manager.create_execution(Stage.PERCEIVE, "func1", workflow_id)
        exec2 = manager.create_execution(Stage.REASON, "func2", workflow_id)
        
        manager.update_state(exec1, StageState.COMPLETED)
        manager.update_state(exec2, StageState.COMPLETED)
        
        # Complete workflow
        manager.complete_workflow(workflow_id)
        observer.on_workflow_completed.assert_called_once()
        
        # Check call arguments
        call_args = observer.on_workflow_completed.call_args
        assert call_args[0][0] == workflow_id
        assert len(call_args[0][1]) == 2  # Two executions
    
    def test_stage_state_manager_workflow_error(self):
        """Test workflow error handling."""
        manager = StageStateManager()
        observer = Mock(spec=StageStateObserver)
        manager.add_observer(observer)
        
        workflow_id = "error_workflow"
        error = RuntimeError("Workflow failed")
        
        manager.error_workflow(workflow_id, error)
        
        observer.on_workflow_error.assert_called_once_with(workflow_id, error)
    
    def test_stage_state_manager_get_executions(self):
        """Test getting executions for a workflow."""
        manager = StageStateManager()
        
        workflow_id = "test_workflow"
        exec1 = manager.create_execution(Stage.PERCEIVE, "func1", workflow_id)
        exec2 = manager.create_execution(Stage.REASON, "func2", workflow_id)
        
        executions = manager.get_executions(workflow_id)
        
        assert len(executions) == 2
        assert exec1 in executions
        assert exec2 in executions
    
    def test_stage_state_manager_get_execution_summary(self):
        """Test getting execution summary."""
        manager = StageStateManager()
        
        workflow_id = "summary_workflow"
        exec1 = manager.create_execution(Stage.PERCEIVE, "func1", workflow_id)
        exec2 = manager.create_execution(Stage.REASON, "func2", workflow_id)
        
        # Complete one, error the other
        manager.update_state(exec1, StageState.COMPLETED)
        manager.update_state(exec2, StageState.ERROR, error=ValueError("Error"))
        
        summary = manager.get_execution_summary(workflow_id)
        
        assert summary["total"] == 2
        assert summary["completed"] == 1
        assert summary["errors"] == 1
        assert summary["running"] == 0


class TestStageExecutionContext:
    """Test stage execution context manager."""
    
    def test_stage_execution_context_success(self):
        """Test successful execution context."""
        with patch('agent_sdk.core.state.functions.get_state_manager') as mock_get_manager:
            mock_manager = Mock()
            mock_execution = Mock()
            mock_get_manager.return_value = mock_manager
            mock_manager.create_execution.return_value = mock_execution
            
            with stage_execution_context(Stage.PERCEIVE, "test_func", "workflow") as execution:
                assert execution == mock_execution
                execution.result = {"success": True}
            
            # Should update state to completed
            mock_manager.update_state.assert_called_with(
                mock_execution, 
                StageState.COMPLETED, 
                result={"success": True}
            )
    
    def test_stage_execution_context_with_exception(self):
        """Test execution context with exception."""
        with patch('agent_sdk.core.state.functions.get_state_manager') as mock_get_manager:
            mock_manager = Mock()
            mock_execution = Mock()
            mock_get_manager.return_value = mock_manager
            mock_manager.create_execution.return_value = mock_execution
            
            test_error = ValueError("Test error")
            
            with pytest.raises(ValueError):
                with stage_execution_context(Stage.REASON, "func", "workflow") as execution:
                    raise test_error
            
            # Should update state to error
            mock_manager.update_state.assert_called_with(
                mock_execution, 
                StageState.ERROR, 
                error=test_error
            )


class TestGlobalStateFunctions:
    """Test global state management functions."""
    
    def test_get_state_manager_singleton(self):
        """Test that get_state_manager returns singleton."""
        manager1 = get_state_manager()
        manager2 = get_state_manager()
        
        assert manager1 is manager2
        assert isinstance(manager1, StageStateManager)
    
    def test_get_metrics_function(self):
        """Test global get_metrics function."""
        # Clear any existing state
        with patch('agent_sdk.core.state.functions._state_manager', None):
            # Should return empty metrics when no manager exists
            metrics = get_metrics()
            assert metrics == {}
    
    def test_get_workflow_status_function(self):
        """Test global get_workflow_status function."""
        with patch('agent_sdk.core.state.functions.get_state_manager') as mock_get_manager:
            mock_manager = Mock()
            mock_manager.get_execution_summary.return_value = {"total": 5}
            mock_get_manager.return_value = mock_manager
            
            status = get_workflow_status("test_workflow")
            
            assert status == {"total": 5}
            mock_manager.get_execution_summary.assert_called_once_with("test_workflow")
    
    def test_configure_monitoring_function(self):
        """Test configure_monitoring function."""
        with patch('agent_sdk.core.state.functions.get_state_manager') as mock_get_manager:
            mock_manager = Mock()
            mock_get_manager.return_value = mock_manager
            
            # Test with default settings
            configure_monitoring()
            
            # Should add default observers
            assert mock_manager.add_observer.call_count >= 2  # Logging + Metrics
            
            # Test with custom observers
            custom_observer = Mock(spec=StageStateObserver)
            configure_monitoring(
                enable_logging=False,
                enable_metrics=False,
                custom_observers=[custom_observer]
            )
            
            # Should add custom observer
            mock_manager.add_observer.assert_called_with(custom_observer)


class TestStateEdgeCases:
    """Test edge cases for state management."""
    
    def test_stage_execution_with_none_values(self):
        """Test StageExecution with None values."""
        execution = StageExecution(
            stage=Stage.PERCEIVE,
            function_name="test",
            workflow_id="workflow",
            metadata=None
        )
        
        assert execution.metadata is None
        
        # to_dict should handle None values
        result_dict = execution.to_dict()
        assert result_dict["metadata"] is None
    
    def test_metrics_observer_with_no_executions(self):
        """Test MetricsObserver with no execution data."""
        observer = MetricsObserver()
        
        metrics = observer.get_metrics()
        
        assert metrics["summary"]["total_executions"] == 0
        assert metrics["summary"]["total_errors"] == 0
        assert metrics["summary"]["average_execution_time"] == 0
        assert metrics["summary"]["total_workflows"] == 0
    
    def test_stage_state_manager_nonexistent_workflow(self):
        """Test getting executions for non-existent workflow."""
        manager = StageStateManager()
        
        executions = manager.get_executions("nonexistent_workflow")
        
        assert executions == []
    
    def test_stage_state_manager_summary_empty_workflow(self):
        """Test getting summary for empty workflow."""
        manager = StageStateManager()
        
        summary = manager.get_execution_summary("empty_workflow")
        
        assert summary["total"] == 0
        assert summary["completed"] == 0
        assert summary["errors"] == 0
        assert summary["running"] == 0