"""Tests for stage decorators and functionality."""

import pytest
import asyncio
from typing import Dict, Any

from agent_sdk.core.stages import Stage, perceive, reason, plan, act, _create_stage_decorator
from agent_sdk.core.context import Context


class TestStageEnum:
    """Test Stage enumeration."""
    
    def test_stage_values(self):
        """Test that all expected stages exist."""
        assert Stage.PERCEIVE
        assert Stage.REASON
        assert Stage.PLAN
        assert Stage.ACT
        
        # Test that stages have unique values
        stages = [Stage.PERCEIVE, Stage.REASON, Stage.PLAN, Stage.ACT]
        assert len(set(stages)) == len(stages)


class TestStageDecorators:
    """Test stage decorators."""
    
    def test_perceive_decorator_sync(self):
        """Test perceive decorator on sync function."""
        @perceive
        def sync_perceive(ctx: Context) -> Dict[str, Any]:
            return {"perceived": True}
        
        assert hasattr(sync_perceive, "_agent_stage")
        assert sync_perceive._agent_stage == Stage.PERCEIVE
        
        ctx = Context(data={"input": "test"})
        result = sync_perceive(ctx)
        assert result == {"perceived": True}
    
    @pytest.mark.asyncio
    async def test_perceive_decorator_async(self):
        """Test perceive decorator on async function."""
        @perceive
        async def async_perceive(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"async_perceived": True}
        
        assert hasattr(async_perceive, "_agent_stage")
        assert async_perceive._agent_stage == Stage.PERCEIVE
        
        ctx = Context(data={"input": "test"})
        result = await async_perceive(ctx)
        assert result == {"async_perceived": True}
    
    def test_reason_decorator(self):
        """Test reason decorator."""
        @reason
        def test_reason(ctx: Context) -> Dict[str, Any]:
            return {"reasoned": True}
        
        assert hasattr(test_reason, "_agent_stage")
        assert test_reason._agent_stage == Stage.REASON
    
    def test_plan_decorator(self):
        """Test plan decorator."""
        @plan
        def test_plan(ctx: Context) -> Dict[str, Any]:
            return {"planned": True}
        
        assert hasattr(test_plan, "_agent_stage")
        assert test_plan._agent_stage == Stage.PLAN
    
    def test_act_decorator(self):
        """Test act decorator."""
        @act
        def test_act(ctx: Context) -> Dict[str, Any]:
            return {"acted": True}
        
        assert hasattr(test_act, "_agent_stage")
        assert test_act._agent_stage == Stage.ACT
    
    def test_decorator_preserves_function_metadata(self):
        """Test that decorators preserve function metadata."""
        @perceive
        def documented_function(ctx: Context) -> Dict[str, Any]:
            """This is a documented function."""
            return {"result": True}
        
        assert documented_function.__name__ == "documented_function"
        assert documented_function.__doc__ == "This is a documented function."
    
    def test_decorator_with_args_kwargs(self):
        """Test decorator works with various function signatures."""
        @reason
        def flexible_function(*args, **kwargs):
            return {"args": len(args), "kwargs": len(kwargs)}
        
        result = flexible_function("arg1", "arg2", key1="value1", key2="value2")
        assert result == {"args": 2, "kwargs": 2}
    
    @pytest.mark.asyncio
    async def test_mixed_sync_async_decorators(self):
        """Test that sync and async functions can be decorated together."""
        @perceive
        def sync_func(ctx: Context) -> Dict[str, Any]:
            return {"sync": True}
        
        @perceive
        async def async_func(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"async": True}
        
        ctx = Context()
        
        sync_result = sync_func(ctx)
        async_result = await async_func(ctx)
        
        assert sync_result == {"sync": True}
        assert async_result == {"async": True}
        
        # Both should have the same stage
        assert sync_func._agent_stage == async_func._agent_stage == Stage.PERCEIVE


class TestStageDecoratorFactory:
    """Test the stage decorator factory function."""
    
    def test_create_stage_decorator(self):
        """Test creating custom stage decorators."""
        custom_decorator = _create_stage_decorator(Stage.REASON)
        
        @custom_decorator
        def custom_function(ctx: Context) -> Dict[str, Any]:
            return {"custom": True}
        
        assert hasattr(custom_function, "_agent_stage")
        assert custom_function._agent_stage == Stage.REASON
        
        ctx = Context()
        result = custom_function(ctx)
        assert result == {"custom": True}
    
    @pytest.mark.asyncio
    async def test_create_stage_decorator_async(self):
        """Test creating custom stage decorators for async functions."""
        custom_decorator = _create_stage_decorator(Stage.PLAN)
        
        @custom_decorator
        async def custom_async_function(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            return {"custom_async": True}
        
        assert hasattr(custom_async_function, "_agent_stage")
        assert custom_async_function._agent_stage == Stage.PLAN
        
        ctx = Context()
        result = await custom_async_function(ctx)
        assert result == {"custom_async": True}


class TestStageDecoratorEdgeCases:
    """Test edge cases for stage decorators."""
    
    def test_decorator_on_lambda(self):
        """Test decorator on lambda function."""
        decorated_lambda = perceive(lambda ctx: {"lambda": True})
        
        assert hasattr(decorated_lambda, "_agent_stage")
        assert decorated_lambda._agent_stage == Stage.PERCEIVE
        
        ctx = Context()
        result = decorated_lambda(ctx)
        assert result == {"lambda": True}
    
    def test_decorator_on_class_method(self):
        """Test decorator on class methods."""
        class TestClass:
            @perceive
            def method(self, ctx: Context) -> Dict[str, Any]:
                return {"method": True}
            
            @classmethod
            @reason
            def class_method(cls, ctx: Context) -> Dict[str, Any]:
                return {"class_method": True}
            
            @staticmethod
            @plan
            def static_method(ctx: Context) -> Dict[str, Any]:
                return {"static_method": True}
        
        obj = TestClass()
        ctx = Context()
        
        # Test instance method
        assert hasattr(obj.method, "_agent_stage")
        assert obj.method._agent_stage == Stage.PERCEIVE
        result = obj.method(ctx)
        assert result == {"method": True}
        
        # Test class method
        assert hasattr(TestClass.class_method, "_agent_stage")
        assert TestClass.class_method._agent_stage == Stage.REASON
        result = TestClass.class_method(ctx)
        assert result == {"class_method": True}
        
        # Test static method
        assert hasattr(TestClass.static_method, "_agent_stage")
        assert TestClass.static_method._agent_stage == Stage.PLAN
        result = TestClass.static_method(ctx)
        assert result == {"static_method": True}
    
    def test_multiple_decorators(self):
        """Test function with multiple decorators."""
        def other_decorator(func):
            func.other_attribute = "other"
            return func
        
        @other_decorator
        @act
        def multi_decorated(ctx: Context) -> Dict[str, Any]:
            return {"multi": True}
        
        assert hasattr(multi_decorated, "_agent_stage")
        assert multi_decorated._agent_stage == Stage.ACT
        assert hasattr(multi_decorated, "other_attribute")
        assert multi_decorated.other_attribute == "other"
        
        ctx = Context()
        result = multi_decorated(ctx)
        assert result == {"multi": True}
    
    def test_decorator_exception_handling(self):
        """Test that exceptions in decorated functions are properly propagated."""
        @perceive
        def failing_function(ctx: Context) -> Dict[str, Any]:
            raise ValueError("Test error")
        
        ctx = Context()
        with pytest.raises(ValueError, match="Test error"):
            failing_function(ctx)
    
    @pytest.mark.asyncio
    async def test_async_decorator_exception_handling(self):
        """Test that exceptions in async decorated functions are properly propagated."""
        @reason
        async def failing_async_function(ctx: Context) -> Dict[str, Any]:
            await asyncio.sleep(0.001)
            raise RuntimeError("Async test error")
        
        ctx = Context()
        with pytest.raises(RuntimeError, match="Async test error"):
            await failing_async_function(ctx)