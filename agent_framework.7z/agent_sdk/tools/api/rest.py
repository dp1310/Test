"""REST API tool with functional programming approach."""

import logging
from typing import Any, Dict, List, Optional, Union
from ..base import ToolResult, ToolStatus, ToolError
from .http import HTTPTool

logger = logging.getLogger(__name__)


# Pure functions for REST API operations
def _build_versioned_endpoint(endpoint: str, api_version: str) -> str:
    """Build endpoint with API version prefix."""
    if api_version and not endpoint.startswith(f'/{api_version}'):
        return f"/{api_version}/{endpoint.lstrip('/')}"
    return endpoint


def _extract_pagination_data(response_data: Any) -> tuple:
    """Extract items and pagination info from API response."""
    if isinstance(response_data, dict):
        items = response_data.get('items', response_data.get('results', []))
        total_pages = response_data.get('total_pages', 1)
    else:
        items = response_data if isinstance(response_data, list) else []
        total_pages = 1
    
    return items, total_pages


def _create_page_params(base_params: Optional[Dict], page: int, page_size: int) -> Dict:
    """Create pagination parameters for API request."""
    page_params = (base_params or {}).copy()
    page_params.update({
        'page': page,
        'page_size': page_size
    })
    return page_params


def _should_continue_pagination(page: int, total_pages: int, max_pages: int, items_count: int, page_size: int) -> bool:
    """Determine if pagination should continue."""
    return page < total_pages and page < max_pages and items_count >= page_size


def _create_paginated_result(all_data: List, pages_fetched: int) -> Dict[str, Any]:
    """Create result data for paginated response."""
    return {
        "data": all_data,
        "total_items": len(all_data),
        "pages_fetched": pages_fetched,
        "paginated": True
    }


class RestAPITool(HTTPTool):
    """REST API client tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.api_version = config.get('api_version', 'v1')
        self.rate_limit = config.get('rate_limit', {})
        self.retry_config = config.get('retry_config', {})
        # Add missing attributes expected by tests
        self.api_key = config.get('api_key')
        self.auth_header = config.get('auth_header', 'Authorization')
        
    def validate_config(self) -> bool:
        """Validate REST API tool configuration."""
        # Check if base_url is provided
        if not self.base_url:
            return False
        return super().validate_config()
        
    async def execute(self, endpoint: str, method: str = "GET",
                     params: Dict = None, data: Any = None,
                     paginate: bool = False, **kwargs) -> ToolResult:
        """Execute REST API request with functional approach."""
        try:
            # Prepare endpoint using pure function
            versioned_endpoint = _build_versioned_endpoint(endpoint, self.api_version)
            
            # Handle pagination if requested
            if paginate and method.upper() == "GET":
                return await self._paginated_request(versioned_endpoint, params, **kwargs)
            
            # Make single request
            return await super().execute(
                method=method,
                url=versioned_endpoint,
                params=params,
                json_data=data if isinstance(data, dict) else None,
                data=data if not isinstance(data, dict) else None,
                **kwargs
            )
            
        except Exception as e:
            logger.error(f"REST API error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"REST API error: {e}", self.name, e)
            )
    
    async def _paginated_request(self, endpoint: str, params: Dict = None, **kwargs) -> ToolResult:
        """Handle paginated API requests using functional approach."""
        all_data = []
        page = 1
        page_size = params.get('page_size', 100) if params else 100
        max_pages = kwargs.get('max_pages', 10)
        
        while page <= max_pages:
            # Prepare pagination parameters using pure function
            page_params = _create_page_params(params, page, page_size)
            
            # Make request
            result = await super().execute(
                method="GET",
                url=endpoint,
                params=page_params,
                **{k: v for k, v in kwargs.items() if k != 'max_pages'}
            )
            
            if not result.is_success:
                return result
            
            # Extract data using pure function
            response_data = result.data.get('data', {})
            items, total_pages = _extract_pagination_data(response_data)
            all_data.extend(items)
            
            # Check if we should continue using pure function
            if not _should_continue_pagination(page, total_pages, max_pages, len(items), page_size):
                break
            
            page += 1
        
        # Return combined result using pure function
        result_data = _create_paginated_result(all_data, page)
        return ToolResult(
            tool_name=self.name,
            status=ToolStatus.SUCCESS,
            data=result_data
        )
    
    async def get(self, endpoint: str, **kwargs) -> ToolResult:
        """Convenience method for GET requests."""
        return await self.execute(endpoint, "GET", **kwargs)
    
    async def post(self, endpoint: str, data: Dict = None, **kwargs) -> ToolResult:
        """Convenience method for POST requests."""
        return await self.execute(endpoint, "POST", data=data, **kwargs)
    
    async def put(self, endpoint: str, data: Dict = None, **kwargs) -> ToolResult:
        """Convenience method for PUT requests."""
        return await self.execute(endpoint, "PUT", data=data, **kwargs)
    
    async def delete(self, endpoint: str, **kwargs) -> ToolResult:
        """Convenience method for DELETE requests."""
        return await self.execute(endpoint, "DELETE", **kwargs)
    
    def get_schema(self) -> Dict[str, Any]:
        """Get REST API tool schema."""
        return {
            "name": self.name,
            "description": "REST API client tool with pagination and enhanced features",
            "parameters": {
                "endpoint": {
                    "type": "string",
                    "description": "API endpoint path",
                    "required": True
                },
                "method": {
                    "type": "string",
                    "description": "HTTP method",
                    "default": "GET",
                    "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"]
                },
                "params": {
                    "type": "object",
                    "description": "Request parameters",
                    "required": False
                },
                "data": {
                    "type": "object",
                    "description": "Request data",
                    "required": False
                },
                "paginate": {
                    "type": "boolean",
                    "description": "Enable automatic pagination",
                    "default": False
                },
                "max_pages": {
                    "type": "integer",
                    "description": "Maximum pages to fetch when paginating",
                    "default": 10
                }
            },
            "required": ["endpoint"],
            "examples": [
                {
                    "endpoint": "/users",
                    "method": "GET",
                    "params": {"status": "active"},
                    "paginate": True
                },
                {
                    "endpoint": "/users",
                    "method": "POST",
                    "data": {"name": "John Doe", "email": "john@example.com"}
                }
            ]
        }