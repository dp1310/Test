"""Email tool with functional programming approach."""

import logging
from typing import Any, Dict, List, Union
from ..base import Tool, ToolResult, ToolStatus, ToolError

logger = logging.getLogger(__name__)


# Pure functions for email operations
def _validate_email_config(smtp_server: str, username: str, password: str) -> bool:
    """Validate email configuration parameters."""
    return all([smtp_server, username, password])


def _normalize_recipients(recipients: Union[str, List[str]]) -> List[str]:
    """Normalize recipients to list format."""
    if isinstance(recipients, str):
        return [recipients]
    return recipients


def _create_recipient_list(to_email: List[str], cc: List[str] = None, bcc: List[str] = None) -> List[str]:
    """Create complete recipient list for email sending."""
    recipients = to_email[:]
    if cc:
        recipients.extend(cc)
    if bcc:
        recipients.extend(bcc)
    return recipients


def _create_email_message(from_email: str, to_email: List[str], subject: str, 
                         body: str, html_body: str = None, cc: List[str] = None):
    """Create email message object."""
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    
    msg = MIMEMultipart('alternative')
    msg['From'] = from_email
    msg['Subject'] = subject
    msg['To'] = ', '.join(to_email)
    
    if cc:
        msg['Cc'] = ', '.join(cc)
    
    # Add body parts
    msg.attach(MIMEText(body, 'plain'))
    
    if html_body:
        msg.attach(MIMEText(html_body, 'html'))
    
    return msg


def _create_email_result(to_email: List[str], subject: str, total_recipients: int) -> Dict[str, Any]:
    """Create result data for email sending."""
    return {
        "sent": True,
        "recipients": total_recipients,
        "to": to_email,
        "subject": subject
    }


class EmailTool(Tool):
    """Email sending tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.smtp_server = config.get('smtp_server')
        self.smtp_port = config.get('smtp_port', 587)
        self.username = config.get('username')
        self.password = config.get('password')
        self.use_tls = config.get('use_tls', True)
        self.from_email = config.get('from_email', config.get('username'))
        
    def validate_config(self) -> bool:
        """Validate email configuration using pure function."""
        if not _validate_email_config(self.smtp_server, self.username, self.password):
            logger.error(f"Missing required email configuration for {self.name}")
            return False
        return True
    
    async def execute(self, to_email: Union[str, List[str]], subject: str,
                     body: str, html_body: str = None,
                     cc: Union[str, List[str]] = None,
                     bcc: Union[str, List[str]] = None,
                     **kwargs) -> ToolResult:
        """Send email with functional approach."""
        try:
            # Import email libraries
            import smtplib
            
            # Normalize recipients using pure functions
            to_list = _normalize_recipients(to_email)
            cc_list = _normalize_recipients(cc) if cc else None
            bcc_list = _normalize_recipients(bcc) if bcc else None
            
            # Create message using pure function
            msg = _create_email_message(
                self.from_email, to_list, subject, body, html_body, cc_list
            )
            
            # Create recipient list using pure function
            recipients = _create_recipient_list(to_list, cc_list, bcc_list)
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                if self.use_tls:
                    server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg, to_addrs=recipients)
            
            # Create result using pure function
            result_data = _create_email_result(to_list, subject, len(recipients))
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=result_data
            )
            
        except Exception as e:
            logger.error(f"Email send error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"Email send error: {e}", self.name, e)
            )
    
    def get_schema(self) -> Dict[str, Any]:
        """Get email tool schema."""
        return {
            "name": self.name,
            "description": "Email sending tool",
            "parameters": {
                "to_email": {
                    "type": ["string", "array"],
                    "description": "Recipient email address(es)",
                    "required": True
                },
                "subject": {
                    "type": "string",
                    "description": "Email subject",
                    "required": True
                },
                "body": {
                    "type": "string",
                    "description": "Plain text email body",
                    "required": True
                },
                "html_body": {
                    "type": "string",
                    "description": "HTML email body",
                    "required": False
                },
                "cc": {
                    "type": ["string", "array"],
                    "description": "CC recipients",
                    "required": False
                },
                "bcc": {
                    "type": ["string", "array"],
                    "description": "BCC recipients",
                    "required": False
                }
            },
            "required": ["to_email", "subject", "body"],
            "examples": [
                {
                    "to_email": "user@example.com",
                    "subject": "Test Email",
                    "body": "This is a test email."
                }
            ]
        }