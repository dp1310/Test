"""File operations tool with functional programming approach."""

import logging
from pathlib import Path
from typing import Any, Dict, List
from ..base import Tool, ToolResult, ToolStatus, ToolError

logger = logging.getLogger(__name__)


# Pure functions for file operations
def _validate_path_security(path: Path, base_path: Path) -> bool:
    """Validate that path is within allowed base directory."""
    try:
        path.resolve().relative_to(base_path.resolve())
        return True
    except ValueError:
        return False


def _validate_file_extension(path: Path, allowed_extensions: List[str]) -> bool:
    """Validate file extension against allowed list."""
    if not allowed_extensions:
        return True
    return path.suffix in allowed_extensions


def _validate_file_size(content: str, encoding: str, max_size: int) -> bool:
    """Validate file size against maximum allowed."""
    return len(content.encode(encoding)) <= max_size


def _resolve_file_path(file_path: str, base_path: Path) -> Path:
    """Resolve file path relative to base path."""
    path = Path(file_path)
    if not path.is_absolute():
        path = base_path / path
    return path


def _create_file_info(item: Path) -> Dict[str, Any]:
    """Create file information dictionary."""
    return {
        "name": item.name,
        "path": str(item),
        "is_file": item.is_file(),
        "is_dir": item.is_dir(),
        "size": item.stat().st_size if item.is_file() else None
    }


def _create_read_result(content: str, path: Path) -> Dict[str, Any]:
    """Create result data for read operation."""
    return {
        "content": content,
        "size": len(content),
        "path": str(path)
    }


def _create_write_result(content: str, encoding: str, path: Path) -> Dict[str, Any]:
    """Create result data for write operation."""
    return {
        "bytes_written": len(content.encode(encoding)),
        "path": str(path)
    }


def _create_append_result(content: str, encoding: str, path: Path) -> Dict[str, Any]:
    """Create result data for append operation."""
    return {
        "bytes_appended": len(content.encode(encoding)),
        "path": str(path)
    }


def _create_delete_result(path: Path) -> Dict[str, Any]:
    """Create result data for delete operation."""
    return {"deleted": str(path)}


def _create_exists_result(path: Path) -> Dict[str, Any]:
    """Create result data for exists operation."""
    return {
        "exists": path.exists(),
        "path": str(path)
    }


def _create_list_result(files: List[Dict], path: Path) -> Dict[str, Any]:
    """Create result data for list operation."""
    return {
        "files": files,
        "count": len(files),
        "path": str(path)
    }


class FileTool(Tool):
    """File system operations tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.base_path = Path(config.get('base_path', '.'))
        self.allowed_extensions = config.get('allowed_extensions', [])
        self.max_file_size = config.get('max_file_size', 10 * 1024 * 1024)  # 10MB
        
    def validate_config(self) -> bool:
        """Validate file tool configuration."""
        if not self.base_path.exists():
            logger.warning(f"Base path does not exist: {self.base_path}")
        return True
    
    def _validate_path(self, file_path: str) -> Path:
        """Validate and resolve file path using pure functions."""
        path = _resolve_file_path(file_path, self.base_path)
        
        # Security check
        if not _validate_path_security(path, self.base_path):
            raise ToolError(f"Path outside allowed directory: {file_path}", self.name)
        
        # Extension check
        if not _validate_file_extension(path, self.allowed_extensions):
            raise ToolError(f"File extension {path.suffix} not allowed", self.name)
        
        return path
    
    async def execute(self, operation: str, file_path: str,
                     content: str = None, encoding: str = 'utf-8',
                     **kwargs) -> ToolResult:
        """Execute file operation with functional approach."""
        try:
            path = self._validate_path(file_path)
            
            # Route to appropriate operation handler
            operation_handlers = {
                "read": self._handle_read,
                "write": self._handle_write,
                "append": self._handle_append,
                "delete": self._handle_delete,
                "exists": self._handle_exists,
                "list": self._handle_list
            }
            
            if operation not in operation_handlers:
                raise ToolError(f"Unknown operation: {operation}", self.name)
            
            data = await operation_handlers[operation](path, content, encoding)
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=data
            )
            
        except Exception as e:
            logger.error(f"File operation error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"File operation error: {e}", self.name, e)
            )
    
    async def _handle_read(self, path: Path, content: str, encoding: str) -> Dict[str, Any]:
        """Handle read operation using pure functions."""
        if not path.exists():
            raise ToolError(f"File not found: {path}", self.name)
        
        file_content = path.read_text(encoding=encoding)
        return _create_read_result(file_content, path)
    
    async def _handle_write(self, path: Path, content: str, encoding: str) -> Dict[str, Any]:
        """Handle write operation using pure functions."""
        if content is None:
            raise ToolError("Content required for write operation", self.name)
        
        # Validate file size
        if not _validate_file_size(content, encoding, self.max_file_size):
            raise ToolError(f"File size exceeds limit: {self.max_file_size}", self.name)
        
        # Create parent directories
        path.parent.mkdir(parents=True, exist_ok=True)
        
        path.write_text(content, encoding=encoding)
        return _create_write_result(content, encoding, path)
    
    async def _handle_append(self, path: Path, content: str, encoding: str) -> Dict[str, Any]:
        """Handle append operation using pure functions."""
        if content is None:
            raise ToolError("Content required for append operation", self.name)
        
        # Create file if it doesn't exist
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.touch()
        
        with open(path, 'a', encoding=encoding) as f:
            f.write(content)
        
        return _create_append_result(content, encoding, path)
    
    async def _handle_delete(self, path: Path, content: str, encoding: str) -> Dict[str, Any]:
        """Handle delete operation using pure functions."""
        if not path.exists():
            raise ToolError(f"File not found: {path}", self.name)
        
        path.unlink()
        return _create_delete_result(path)
    
    async def _handle_exists(self, path: Path, content: str, encoding: str) -> Dict[str, Any]:
        """Handle exists operation using pure functions."""
        return _create_exists_result(path)
    
    async def _handle_list(self, path: Path, content: str, encoding: str) -> Dict[str, Any]:
        """Handle list operation using pure functions."""
        if not path.exists():
            raise ToolError(f"Directory not found: {path}", self.name)
        
        if not path.is_dir():
            raise ToolError(f"Path is not a directory: {path}", self.name)
        
        files = [_create_file_info(item) for item in path.iterdir()]
        return _create_list_result(files, path)
    
    def get_schema(self) -> Dict[str, Any]:
        """Get file tool schema."""
        return {
            "name": self.name,
            "description": "File system operations tool",
            "parameters": {
                "operation": {
                    "type": "string",
                    "description": "File operation type",
                    "required": True,
                    "enum": ["read", "write", "append", "delete", "exists", "list"]
                },
                "file_path": {
                    "type": "string",
                    "description": "Path to the file or directory",
                    "required": True
                },
                "content": {
                    "type": "string",
                    "description": "Content for write/append operations",
                    "required": False
                },
                "encoding": {
                    "type": "string",
                    "description": "File encoding",
                    "default": "utf-8"
                }
            },
            "required": ["operation", "file_path"],
            "examples": [
                {
                    "operation": "read",
                    "file_path": "data/example.txt"
                },
                {
                    "operation": "write",
                    "file_path": "output/result.txt",
                    "content": "Hello, World!"
                }
            ]
        }