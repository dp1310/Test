"""OpenAI LLM tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional
from ..base import ToolResult, ToolStatus, ToolError
from .base import BaseLLMTool

logger = logging.getLogger(__name__)


# Pure functions for OpenAI operations
def _create_messages(prompt: str, system_prompt: Optional[str] = None) -> list:
    """Create message list for OpenAI API."""
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})
    return messages


def _create_api_params(model: str, messages: list, max_tokens: int, 
                      temperature: float, top_p: float, stream: bool, **kwargs) -> Dict[str, Any]:
    """Create API parameters for OpenAI request."""
    params = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "top_p": top_p,
        "stream": stream
    }
    params.update(kwargs)
    return params


def _extract_response_content(response: Any) -> tuple:
    """Extract content and metadata from OpenAI response."""
    if hasattr(response, 'choices'):
        # Real API response
        content = response.choices[0].message.content
        usage = {
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens
        }
        finish_reason = response.choices[0].finish_reason
    elif isinstance(response, dict) and 'choices' in response:
        # Mock dictionary response
        content = response['choices'][0]['message']['content']
        usage = response.get('usage', {})
        finish_reason = response['choices'][0].get('finish_reason')
    else:
        raise ValueError(f"Unexpected response format: {type(response)}")
    
    return content, usage, finish_reason


def _create_result_data(content: str, model: str, usage: Dict = None, 
                       finish_reason: str = None, stream: bool = False) -> Dict[str, Any]:
    """Create formatted result data for OpenAI response."""
    result_data = {
        "content": content,
        "response": content,  # Keep both for backward compatibility
        "model": model
    }
    
    if stream:
        result_data.update({"stream": True, "streamed": True})
    else:
        result_data.update({
            "usage": usage,
            "finish_reason": finish_reason
        })
    
    return result_data


async def _process_stream_response(stream) -> str:
    """Process streaming response from OpenAI."""
    response_text = ""
    async for chunk in stream:
        if hasattr(chunk, 'choices') and chunk.choices and hasattr(chunk.choices[0], 'delta'):
            if hasattr(chunk.choices[0].delta, 'content') and chunk.choices[0].delta.content:
                response_text += chunk.choices[0].delta.content
        elif isinstance(chunk, dict) and 'choices' in chunk:
            if chunk['choices'] and 'delta' in chunk['choices'][0]:
                if 'content' in chunk['choices'][0]['delta'] and chunk['choices'][0]['delta']['content']:
                    response_text += chunk['choices'][0]['delta']['content']
    return response_text


class OpenAITool(BaseLLMTool):
    """OpenAI GPT tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.base_url = config.get('base_url', 'https://api.openai.com/v1')
        self.organization = config.get('organization')
        # Set default model if not provided
        if not self.model:
            self.model = 'gpt-3.5-turbo'
    
    def get_schema(self) -> Dict[str, Any]:
        """Get OpenAI tool schema."""
        schema = super().get_schema()
        schema["description"] = "OpenAI GPT tool for text generation and completion"
        return schema
        
    async def execute(self, prompt: str, system_prompt: str = None, 
                     max_tokens: int = None, temperature: float = None,
                     stream: bool = False, **kwargs) -> ToolResult:
        """Execute OpenAI API call with functional approach."""
        try:
            # Import OpenAI client
            try:
                from openai import AsyncOpenAI
            except ImportError:
                raise ToolError("OpenAI library not installed. Run: pip install openai", self.name)
            
            # Initialize client
            client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                organization=self.organization
            )
            
            # Prepare request using pure functions
            messages = _create_messages(prompt, system_prompt)
            params = _create_api_params(
                self.model, messages, max_tokens or self.max_tokens,
                temperature if temperature is not None else self.temperature,
                self.top_p, stream, **kwargs
            )
            
            # Make API call
            if stream:
                stream_response = await client.chat.completions.create(**params)
                response_text = await _process_stream_response(stream_response)
                result_data = _create_result_data(response_text, self.model, stream=True)
            else:
                response = await client.chat.completions.create(**params)
                content, usage, finish_reason = _extract_response_content(response)
                result_data = _create_result_data(content, self.model, usage, finish_reason)
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=result_data
            )
            
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"OpenAI API error: {e}", self.name, e)
            )