"""Anthropic Claude LLM tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional
from ..base import ToolResult, ToolStatus, ToolError
from .base import BaseLLMTool

logger = logging.getLogger(__name__)


# Pure functions for Anthropic operations
def _create_anthropic_params(model: str, prompt: str, max_tokens: int, 
                           temperature: float, system_prompt: Optional[str] = None, **kwargs) -> Dict[str, Any]:
    """Create API parameters for Anthropic request."""
    params = {
        "model": model,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "messages": [{"role": "user", "content": prompt}]
    }
    
    if system_prompt:
        params["system"] = system_prompt
    
    params.update(kwargs)
    return params


def _extract_anthropic_response(response: Any) -> tuple:
    """Extract content and metadata from Anthropic response."""
    if hasattr(response, 'content'):
        # Real API response
        content = response.content[0].text
        usage = {
            "prompt_tokens": response.usage.input_tokens,
            "completion_tokens": response.usage.output_tokens,
            "total_tokens": response.usage.input_tokens + response.usage.output_tokens
        }
        stop_reason = response.stop_reason
    elif isinstance(response, dict) and 'content' in response:
        # Mock dictionary response
        content = response['content'][0]['text']
        usage = response.get('usage', {})
        stop_reason = response.get('stop_reason')
    else:
        raise ValueError(f"Unexpected response format: {type(response)}")
    
    return content, usage, stop_reason


def _create_anthropic_result_data(content: str, model: str, usage: Dict = None, 
                                stop_reason: str = None, stream: bool = False) -> Dict[str, Any]:
    """Create formatted result data for Anthropic response."""
    result_data = {
        "content": content,
        "response": content,  # Keep both for backward compatibility
        "model": model
    }
    
    if stream:
        result_data["stream"] = True
    else:
        result_data.update({
            "usage": usage,
            "stop_reason": stop_reason
        })
    
    return result_data


async def _process_anthropic_stream(client, params: Dict[str, Any]) -> str:
    """Process streaming response from Anthropic."""
    response_text = ""
    async with client.messages.stream(**params) as stream:
        async for text in stream.text_stream:
            response_text += text
    return response_text


class AnthropicTool(BaseLLMTool):
    """Anthropic Claude tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        # Set default model if not provided
        if not self.model:
            self.model = 'claude-3-sonnet'
        
    async def execute(self, prompt: str, system_prompt: str = None,
                     max_tokens: int = None, temperature: float = None,
                     stream: bool = False, **kwargs) -> ToolResult:
        """Execute Anthropic API call with functional approach."""
        try:
            # Import Anthropic client
            try:
                from anthropic import AsyncAnthropic
            except ImportError:
                raise ToolError("Anthropic library not installed. Run: pip install anthropic", self.name)
            
            # Initialize client
            client = AsyncAnthropic(api_key=self.api_key)
            
            # Prepare request using pure functions
            params = _create_anthropic_params(
                self.model, prompt, max_tokens or self.max_tokens,
                temperature if temperature is not None else self.temperature,
                system_prompt, **kwargs
            )
            
            # Make API call
            if stream:
                response_text = await _process_anthropic_stream(client, params)
                result_data = _create_anthropic_result_data(response_text, self.model, stream=True)
            else:
                response = await client.messages.create(**params)
                content, usage, stop_reason = _extract_anthropic_response(response)
                result_data = _create_anthropic_result_data(content, self.model, usage, stop_reason)
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=result_data
            )
            
        except Exception as e:
            logger.error(f"Anthropic API error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"Anthropic API error: {e}", self.name, e)
            )