"""Base LLM tool with functional programming principles."""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict
from ..base import Tool

logger = logging.getLogger(__name__)


# Pure functions for LLM operations
def _validate_llm_config(api_key: str, model: str) -> bool:
    """Validate basic LLM configuration."""
    return bool(api_key and model)


def _create_base_schema(name: str, max_tokens: int, temperature: float) -> Dict[str, Any]:
    """Create base LLM tool schema."""
    return {
        "name": name,
        "description": f"LLM tool for {name}",
        "parameters": {
            "prompt": {
                "type": "string",
                "description": "The prompt to send to the LLM",
                "required": True
            },
            "system_prompt": {
                "type": "string", 
                "description": "System prompt for context",
                "required": False
            },
            "max_tokens": {
                "type": "integer",
                "description": "Maximum tokens to generate",
                "default": max_tokens
            },
            "temperature": {
                "type": "number",
                "description": "Sampling temperature (0-2)",
                "default": temperature
            },
            "stream": {
                "type": "boolean",
                "description": "Whether to stream the response",
                "default": False
            }
        },
        "required": ["prompt"],
        "examples": [
            {
                "prompt": "Explain quantum computing in simple terms",
                "max_tokens": 200,
                "temperature": 0.7
            }
        ]
    }


class BaseLLMTool(Tool, ABC):
    """Base class for LLM tools with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.api_key = config.get('api_key')
        self.model = config.get('model')
        self.max_tokens = config.get('max_tokens', 1000)
        self.temperature = config.get('temperature', 0.7)
        self.top_p = config.get('top_p', 1.0)
        
    def validate_config(self) -> bool:
        """Validate LLM configuration using pure function."""
        if not _validate_llm_config(self.api_key, self.model):
            logger.error(f"Invalid configuration for {self.name}: missing API key or model")
            return False
        return True
    
    def get_schema(self) -> Dict[str, Any]:
        """Get LLM tool schema using pure function."""
        return _create_base_schema(self.name, self.max_tokens, self.temperature)
    
    @abstractmethod
    async def execute(self, **kwargs):
        """Execute the LLM tool."""
        pass