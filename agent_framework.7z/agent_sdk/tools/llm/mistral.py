"""Mistral AI LLM tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional
from ..base import ToolResult, ToolStatus, ToolError
from .base import BaseLLMTool

logger = logging.getLogger(__name__)


# Pure functions for Mistral operations
def _create_mistral_messages(prompt: str, system_prompt: Optional[str] = None):
    """Create message list for Mistral API."""
    try:
        from mistralai.models.chat_completion import ChatMessage
        messages = []
        if system_prompt:
            messages.append(ChatMessage(role="system", content=system_prompt))
        messages.append(ChatMessage(role="user", content=prompt))
        return messages
    except ImportError:
        raise ToolError("Mistral AI library not installed. Run: pip install mistralai")


def _extract_mistral_response(response: Any) -> tuple:
    """Extract content and metadata from Mistral response."""
    if hasattr(response, 'choices'):
        # Real API response
        content = response.choices[0].message.content
        usage = {
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens
        }
        finish_reason = response.choices[0].finish_reason
    elif isinstance(response, dict) and 'choices' in response:
        # Mock dictionary response
        content = response['choices'][0]['message']['content']
        usage = response.get('usage', {})
        finish_reason = response['choices'][0].get('finish_reason')
    else:
        raise ValueError(f"Unexpected response format: {type(response)}")
    
    return content, usage, finish_reason


def _create_mistral_result_data(content: str, model: str, usage: Dict = None, 
                               finish_reason: str = None, stream: bool = False) -> Dict[str, Any]:
    """Create formatted result data for Mistral response."""
    result_data = {
        "content": content,
        "response": content,  # Keep both for backward compatibility
        "model": model
    }
    
    if stream:
        result_data["stream"] = True
    else:
        result_data.update({
            "usage": usage,
            "finish_reason": finish_reason
        })
    
    return result_data


async def _process_mistral_stream(client, model: str, messages, max_tokens: int, temperature: float) -> str:
    """Process streaming response from Mistral."""
    response_text = ""
    async for chunk in client.chat_stream(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature
    ):
        if hasattr(chunk, 'choices') and chunk.choices and hasattr(chunk.choices[0], 'delta'):
            if hasattr(chunk.choices[0].delta, 'content') and chunk.choices[0].delta.content:
                response_text += chunk.choices[0].delta.content
        elif isinstance(chunk, dict) and 'choices' in chunk:
            if chunk['choices'] and 'delta' in chunk['choices'][0]:
                if 'content' in chunk['choices'][0]['delta'] and chunk['choices'][0]['delta']['content']:
                    response_text += chunk['choices'][0]['delta']['content']
    return response_text


class MistralTool(BaseLLMTool):
    """Mistral AI tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        # Set default model if not provided
        if not self.model:
            self.model = 'mistral-medium'
        
    async def execute(self, prompt: str, system_prompt: str = None,
                     max_tokens: int = None, temperature: float = None,
                     stream: bool = False, **kwargs) -> ToolResult:
        """Execute Mistral API call with functional approach."""
        try:
            # Import Mistral client
            try:
                from mistralai.async_client import MistralAsyncClient
            except ImportError:
                raise ToolError("Mistral AI library not installed. Run: pip install mistralai", self.name)
            
            # Initialize client
            client = MistralAsyncClient(api_key=self.api_key)
            
            # Prepare request using pure functions
            messages = _create_mistral_messages(prompt, system_prompt)
            request_max_tokens = max_tokens or self.max_tokens
            request_temperature = temperature if temperature is not None else self.temperature
            
            # Make API call
            if stream:
                response_text = await _process_mistral_stream(
                    client, self.model, messages, request_max_tokens, request_temperature
                )
                result_data = _create_mistral_result_data(response_text, self.model, stream=True)
            else:
                response = await client.chat(
                    model=self.model,
                    messages=messages,
                    max_tokens=request_max_tokens,
                    temperature=request_temperature
                )
                
                content, usage, finish_reason = _extract_mistral_response(response)
                result_data = _create_mistral_result_data(content, self.model, usage, finish_reason)
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=result_data
            )
            
        except Exception as e:
            logger.error(f"Mistral API error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"Mistral API error: {e}", self.name, e)
            )