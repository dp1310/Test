"""Base database tool using functional programming principles."""

from abc import abstractmethod
from typing import Any, Dict
from ..base import Tool


class BaseDatabaseTool(Tool):
    """Base class for database tools."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.connection = None
        
    async def connect(self):
        """Establish database connection."""
        pass
    
    async def disconnect(self):
        """Close database connection."""
        pass
    
    @abstractmethod
    async def execute(self, **kwargs):
        """Execute database operation."""
        pass
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()