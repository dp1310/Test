"""Agent factory for creating different types of agents."""

from typing import Any, List, Callable, Dict, Optional, Type, Union
from enum import Enum

from .base_agent import BaseAgent
from .simple_sync_agent import SimpleSyncAgent
from .simple_async_agent import SimpleAsyncAgent
from .prefect_sync_agent import PrefectSyncAgent
from .prefect_async_agent import PrefectAsyncAgent
from ..core.stages import Stage
from ..utils.logging import get_logger

logger = get_logger(__name__)


class AgentType(Enum):
    """Enumeration of available agent types."""
    SIMPLE_SYNC = "simple_sync"
    SIMPLE_ASYNC = "simple_async"
    PREFECT_SYNC = "prefect_sync"
    PREFECT_ASYNC = "prefect_async"


class AgentFactory:
    """
    Factory class for creating agents following the Factory pattern.
    
    This class provides a centralized way to create different types of agents
    with consistent configuration and validation.
    """
    
    _agent_classes: Dict[AgentType, Type[BaseAgent]] = {
        AgentType.SIMPLE_SYNC: SimpleSyncAgent,
        AgentType.SIMPLE_ASYNC: SimpleAsyncAgent,
        AgentType.PREFECT_SYNC: PrefectSyncAgent,
        AgentType.PREFECT_ASYNC: PrefectAsyncAgent,
    }
    
    @classmethod
    def create_agent(
        cls,
        agent_type: Union[AgentType, str],
        functions: Optional[List[Callable]] = None,
        initial_context: Optional[Dict[str, Any]] = None,
        concurrent: Optional[Dict[Stage, bool]] = None,
        workflow_id: Optional[str] = None
    ) -> BaseAgent:
        """
        Create an agent of the specified type.
        
        Args:
            agent_type: Type of agent to create
            functions: List of stage functions
            initial_context: Initial context data
            concurrent: Stage-level concurrency settings
            workflow_id: Unique identifier for workflow monitoring
            
        Returns:
            Configured agent instance
            
        Raises:
            ValueError: If agent_type is not supported
        """
        # Convert string to enum if needed
        if isinstance(agent_type, str):
            try:
                agent_type = AgentType(agent_type)
            except ValueError:
                raise ValueError(f"Unsupported agent type: {agent_type}")
        
        if agent_type not in cls._agent_classes:
            raise ValueError(f"Unsupported agent type: {agent_type}")
        
        agent_class = cls._agent_classes[agent_type]
        
        logger.info(f"Creating {agent_type.value} agent")
        
        return agent_class(
            functions=functions,
            initial_context=initial_context,
            concurrent=concurrent,
            workflow_id=workflow_id
        )
    
    @classmethod
    def create_simple_sync_agent(
        cls,
        functions: Optional[List[Callable]] = None,
        **kwargs
    ) -> SimpleSyncAgent:
        """Create a simple synchronous agent."""
        return cls.create_agent(AgentType.SIMPLE_SYNC, functions, **kwargs)
    
    @classmethod
    def create_simple_async_agent(
        cls,
        functions: Optional[List[Callable]] = None,
        **kwargs
    ) -> SimpleAsyncAgent:
        """Create a simple asynchronous agent."""
        return cls.create_agent(AgentType.SIMPLE_ASYNC, functions, **kwargs)
    
    @classmethod
    def create_prefect_sync_agent(
        cls,
        functions: Optional[List[Callable]] = None,
        **kwargs
    ) -> PrefectSyncAgent:
        """Create a Prefect synchronous agent."""
        return cls.create_agent(AgentType.PREFECT_SYNC, functions, **kwargs)
    
    @classmethod
    def create_prefect_async_agent(
        cls,
        functions: Optional[List[Callable]] = None,
        **kwargs
    ) -> PrefectAsyncAgent:
        """Create a Prefect asynchronous agent."""
        return cls.create_agent(AgentType.PREFECT_ASYNC, functions, **kwargs)
    
    @classmethod
    def get_available_types(cls) -> List[str]:
        """Get list of available agent types."""
        return [agent_type.value for agent_type in AgentType]
    
    @classmethod
    def register_agent_type(
        cls,
        agent_type: AgentType,
        agent_class: Type[BaseAgent]
    ) -> None:
        """
        Register a new agent type (for extensibility).
        
        Args:
            agent_type: Agent type identifier
            agent_class: Agent class to register
        """
        if not issubclass(agent_class, BaseAgent):
            raise ValueError("Agent class must inherit from BaseAgent")
        
        cls._agent_classes[agent_type] = agent_class
        logger.info(f"Registered new agent type: {agent_type.value}")


# Convenience functions for direct agent creation
def create_agent(agent_type: Union[AgentType, str], **kwargs) -> BaseAgent:
    """Convenience function to create an agent."""
    return AgentFactory.create_agent(agent_type, **kwargs)


def create_simple_sync_agent(**kwargs) -> SimpleSyncAgent:
    """Convenience function to create a simple sync agent."""
    return AgentFactory.create_simple_sync_agent(**kwargs)


def create_simple_async_agent(**kwargs) -> SimpleAsyncAgent:
    """Convenience function to create a simple async agent."""
    return AgentFactory.create_simple_async_agent(**kwargs)


def create_prefect_sync_agent(**kwargs) -> PrefectSyncAgent:
    """Convenience function to create a Prefect sync agent."""
    return AgentFactory.create_prefect_sync_agent(**kwargs)


def create_prefect_async_agent(**kwargs) -> PrefectAsyncAgent:
    """Convenience function to create a Prefect async agent."""
    return AgentFactory.create_prefect_async_agent(**kwargs)