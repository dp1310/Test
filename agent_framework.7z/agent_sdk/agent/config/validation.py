"""Agent validation utilities following functional programming principles."""

from typing import List, Callable
from ...utils.logging import get_logger

logger = get_logger(__name__)


class AgentValidator:
    """Static methods for agent validation following functional programming principles."""
    
    @staticmethod
    def validate_functions(functions: List[Callable]) -> None:
        """
        Validate that all functions have proper stage decorators.
        
        Args:
            functions: List of functions to validate
        """
        for fn in functions:
            AgentValidator.validate_function(fn)

    @staticmethod
    def validate_function(function: Callable) -> None:
        """
        Validate that a single function has proper stage decorator.
        
        Args:
            function: Function to validate
        """
        if not AgentValidator.has_stage_decorator(function):
            func_name = AgentValidator.get_function_name(function)
            logger.warning(f"Function {func_name} missing stage decorator")

    @staticmethod
    def has_stage_decorator(function: Callable) -> bool:
        """
        Check if function has stage decorator.
        
        Args:
            function: Function to check
            
        Returns:
            True if function has _agent_stage attribute
        """
        return hasattr(function, "_agent_stage")

    @staticmethod
    def get_function_name(function: Callable) -> str:
        """
        Get function name safely.
        
        Args:
            function: Function to get name from
            
        Returns:
            Function name or '<unknown>' if not available
        """
        return getattr(function, '__name__', '<unknown>')