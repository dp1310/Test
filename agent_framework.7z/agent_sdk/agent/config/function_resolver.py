"""Function resolution utilities following functional programming principles."""

import importlib
import inspect
import sys
from typing import Callable, List, Optional, Any
from ...utils.logging import get_logger

logger = get_logger(__name__)


class FunctionResolver:
    """Functional approach to resolving string function references."""
    
    def __init__(self):
        self._last_import_error: Optional[Exception] = None
    
    def resolve_functions(self, functions_config: List[str]) -> List[Callable]:
        """
        Resolve list of function strings to callables.
        
        Args:
            functions_config: List of function name strings
            
        Returns:
            List of resolved callable functions
        """
        return [self.resolve_function(func_name) for func_name in functions_config]
    
    def resolve_function(self, func_name: str) -> Callable:
        """
        Resolve a function string to a callable using functional approach.
        
        Args:
            func_name: Function name in format 'module.function' or just 'function'
            
        Returns:
            Callable function
        """
        return (self._resolve_qualified_function(func_name) 
                if '.' in func_name 
                else self._resolve_simple_function(func_name))
    
    def _resolve_qualified_function(self, func_name: str) -> Callable:
        """Resolve module.function format using strategy pattern."""
        module_name, function_name = func_name.rsplit('.', 1)
        
        strategies = [
            lambda: self._try_direct_import(module_name, function_name),
            lambda: self._try_relative_import(module_name, function_name),
            lambda: self._try_common_locations(module_name, function_name)
        ]
        
        return self._try_strategies(strategies, func_name)
    
    def _resolve_simple_function(self, func_name: str) -> Callable:
        """Resolve simple function name using strategy pattern."""
        strategies = [
            lambda: self._try_main_module(func_name),
            lambda: self._try_caller_globals(func_name)
        ]
        
        return self._try_strategies(strategies, func_name)
    
    def _try_strategies(self, strategies: List[Callable], func_name: str) -> Callable:
        """Try resolution strategies in order until one succeeds."""
        last_exception = None
        
        for strategy in strategies:
            try:
                result = strategy()
                if result:
                    return result
            except Exception as e:
                last_exception = e
                continue
        
        # Provide specific error messages based on context
        if '.' in func_name:
            if self._last_import_error:
                raise ValueError(f"Cannot import {func_name}: {self._last_import_error}. "
                               f"Tried common locations: {self._get_common_locations(func_name)}")
            elif last_exception and "not callable" in str(last_exception):
                raise last_exception
            else:
                raise ValueError(f"Cannot resolve function '{func_name}'. "
                               "Use 'module.function' format for better resolution.")
        else:
            raise ValueError(f"Simple function name '{func_name}' not found. "
                           "Use 'module.function' format for better resolution.")
    
    def _get_common_locations(self, func_name: str) -> List[str]:
        """Get list of common locations tried for a qualified function name."""
        module_name = func_name.rsplit('.', 1)[0]
        return [
            f"agent_sdk.examples.{module_name}",
            f"examples.{module_name}",
            "__main__" if module_name == "__main__" else f"__main__.{module_name}"
        ]
    
    def _try_direct_import(self, module_name: str, function_name: str) -> Optional[Callable]:
        """Try direct module import."""
        try:
            module = importlib.import_module(module_name)
            return self._extract_callable(module, function_name, f"{module_name}.{function_name}")
        except ImportError as e:
            self._last_import_error = e
            return None
    
    def _try_relative_import(self, module_name: str, function_name: str) -> Optional[Callable]:
        """Try relative import from current package."""
        try:
            relative_module = f".{module_name}"
            module = importlib.import_module(relative_module, package="agent_sdk")
            return self._extract_callable(module, function_name, 
                                        f"{module_name}.{function_name}", "relative import")
        except (ImportError, AttributeError):
            return None
    
    def _try_common_locations(self, module_name: str, function_name: str) -> Optional[Callable]:
        """Try common module locations."""
        locations = [
            f"agent_sdk.examples.{module_name}",
            f"examples.{module_name}",
            "__main__" if module_name == "__main__" else f"__main__.{module_name}"
        ]
        
        for location in locations:
            try:
                if location == "__main__":
                    return self._try_main_module_with_function(function_name)
                else:
                    module = importlib.import_module(location)
                    result = self._extract_callable(module, function_name, 
                                                  f"{module_name}.{function_name}", location)
                    if result:
                        return result
            except (ImportError, AttributeError):
                continue
        
        return None
    
    def _try_main_module(self, func_name: str) -> Optional[Callable]:
        """Try to find function in __main__ module."""
        return self._try_main_module_with_function(func_name)
    
    def _try_main_module_with_function(self, function_name: str) -> Optional[Callable]:
        """Extract function from __main__ module."""
        main_module = sys.modules.get("__main__")
        
        if main_module and hasattr(main_module, function_name):
            func = getattr(main_module, function_name)
            if callable(func):
                logger.debug(f"Successfully resolved function '{function_name}' from __main__")
                return func
        
        return None
    
    def _try_caller_globals(self, func_name: str) -> Optional[Callable]:
        """Try to find function in caller's global scope."""
        frame = inspect.currentframe()
        try:
            # Check up to 5 frames up the call stack
            for _ in range(5):
                frame = frame.f_back
                if frame and func_name in frame.f_globals:
                    func = frame.f_globals[func_name]
                    if callable(func):
                        logger.debug(f"Successfully resolved function '{func_name}' from caller globals")
                        return func
        finally:
            del frame
        
        return None
    
    def _extract_callable(self, module: Any, function_name: str, full_name: str, 
                         source: str = "") -> Callable:
        """Extract and validate callable from module."""
        if not hasattr(module, function_name):
            raise AttributeError(f"Module '{getattr(module, '__name__', 'module')}' "
                               f"has no attribute '{function_name}'")
        
        func = getattr(module, function_name)
        if not callable(func):
            raise ValueError(f"'{full_name}' is not callable")
        
        source_info = f" via {source}" if source else ""
        logger.debug(f"Successfully resolved function '{full_name}'{source_info}")
        return func