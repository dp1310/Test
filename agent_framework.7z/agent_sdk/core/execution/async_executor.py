"""Asynchronous execution engine for agentic workflows."""

import asyncio
from typing import Callable, List, Any

from ..context import Context, merge_context
from ..stages import Stage
from ..state import get_state_manager, stage_execution_context, StageState, StageExecution
from ...utils.logging import get_logger

logger = get_logger(__name__)


class AsyncExecutor:
    """Asynchronous execution engine."""
    
    @staticmethod
    async def execute_concurrent(functions: List[Callable], ctx: Context) -> List[Any]:
        """Execute functions concurrently."""
        async def run_function(fn: Callable) -> Any:
            try:
                if asyncio.iscoroutinefunction(fn):
                    result = await fn(ctx)
                else:
                    result = fn(ctx)
                logger.debug(f"Concurrent execution of {fn.__name__} completed")
                return result
            except Exception as e:
                logger.error(f"Error in concurrent execution of {fn.__name__}: {e}")
                raise
        
        tasks = [run_function(fn) for fn in functions]
        return await asyncio.gather(*tasks)
    
    @staticmethod
    async def execute_sequential_monitored(
        functions: List[Callable], 
        ctx: Context, 
        stage: Stage, 
        workflow_id: str
    ) -> List[Any]:
        """Execute functions sequentially in async mode with state monitoring."""
        results = []
        get_state_manager()
        
        for fn in functions:
            function_name = getattr(fn, '__name__', 'unknown')
            
            with stage_execution_context(stage, function_name, workflow_id) as execution:
                try:
                    if asyncio.iscoroutinefunction(fn):
                        result = await fn(ctx)
                    else:
                        result = fn(ctx)
                    
                    execution.result = result
                    results.append(result)
                    logger.debug(f"Sequential async execution of {function_name} completed")
                    
                except Exception as e:
                    logger.error(f"Error in sequential async execution of {function_name}: {e}")
                    raise
        
        return results
    
    @staticmethod
    async def execute_concurrent_monitored(
        functions: List[Callable], 
        ctx: Context, 
        stage: Stage, 
        workflow_id: str
    ) -> List[Any]:
        """Execute functions concurrently with state monitoring."""
        state_manager = get_state_manager()
        executions = []
        
        # Create execution trackers for all functions
        for fn in functions:
            function_name = getattr(fn, '__name__', 'unknown')
            execution = state_manager.create_execution(stage, function_name, workflow_id)
            executions.append(execution)
        
        async def run_function_monitored(fn: Callable, execution: StageExecution) -> Any:
            try:
                # Mark as started and running
                state_manager.update_state(execution, StageState.STARTED)
                state_manager.update_state(execution, StageState.RUNNING)
                
                if asyncio.iscoroutinefunction(fn):
                    result = await fn(ctx)
                else:
                    result = fn(ctx)
                
                # Mark as completed
                execution.result = result
                state_manager.update_state(execution, StageState.COMPLETED, result=result)
                logger.debug(f"Concurrent execution of {fn.__name__} completed")
                return result
                
            except Exception as e:
                # Mark as error
                state_manager.update_state(execution, StageState.ERROR, error=e)
                logger.error(f"Error in concurrent execution of {fn.__name__}: {e}")
                raise
        
        # Execute all functions concurrently
        tasks = [run_function_monitored(fn, execution) for fn, execution in zip(functions, executions)]
        return await asyncio.gather(*tasks)
    
    @staticmethod
    async def execute_stage(
        functions: List[Callable], 
        ctx: Context, 
        concurrent: bool = False
    ) -> Context:
        """Execute a stage asynchronously."""
        if not functions:
            return ctx
        
        if concurrent:
            results = await AsyncExecutor.execute_concurrent(functions, ctx)
        else:
            results = []
            for fn in functions:
                if asyncio.iscoroutinefunction(fn):
                    result = await fn(ctx)
                else:
                    result = fn(ctx)
                results.append(result)
        
        # Apply results sequentially to avoid deepcopy issues
        current_ctx = ctx
        for result in results:
            current_ctx = merge_context(current_ctx, result)
        
        return current_ctx
    
    @staticmethod
    async def execute_stage_monitored(
        functions: List[Callable], 
        ctx: Context, 
        concurrent: bool = False,
        stage: Stage = None,
        workflow_id: str = "default"
    ) -> Context:
        """Execute a stage asynchronously with state monitoring."""
        if not functions:
            return ctx
        
        if concurrent:
            results = await AsyncExecutor.execute_concurrent_monitored(functions, ctx, stage, workflow_id)
        else:
            results = await AsyncExecutor.execute_sequential_monitored(functions, ctx, stage, workflow_id)
        
        # Apply results sequentially to avoid deepcopy issues
        current_ctx = ctx
        for result in results:
            current_ctx = merge_context(current_ctx, result)
        
        return current_ctx