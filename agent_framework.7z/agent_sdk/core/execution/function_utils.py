"""Function utilities for agentic workflows."""

from typing import Callable, List, Dict
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

from ..stages import Stage
from ...utils.logging import get_logger

logger = get_logger(__name__)


def collect_functions(functions: List[Callable]) -> Dict[Stage, List[Callable]]:
    """Collect functions by their stage type."""
    stage_map: Dict[Stage, List[Callable]] = {}
    
    for fn in functions:
        stage = getattr(fn, "_agent_stage", None)
        if stage is not None:
            stage_map.setdefault(stage, []).append(fn)
        else:
            logger.warning(f"Function {fn.__name__} has no stage decorator")
    
    return stage_map


def wrap_as_task(fn: Callable) -> Callable:
    """Wrap function as Prefect task if not already a task."""
    # Check if it's already a Prefect task by looking for submit method and checking it's callable
    if hasattr(fn, 'submit') and callable(getattr(fn, 'submit', None)):
        # Additional check: make sure it's not just a Mock object
        if not str(type(fn)).startswith("<class 'unittest.mock."):
            return fn
    
    # Get the original function and task name
    if hasattr(fn, 'fn'):
        # It's already wrapped but not a proper Prefect task
        original_fn = fn.fn
        task_name = getattr(fn, 'name', getattr(original_fn, "__name__", "stage"))
    else:
        # It's a regular function
        original_fn = fn
        task_name = getattr(fn, "__name__", "stage")
    
    # Create Prefect task
    prefect_task = task(
        name=task_name,
        cache_policy=NO_CACHE  # Disable caching to avoid serialization issues
    )(original_fn)
    
    return prefect_task


def as_task(fn: Callable) -> Callable:
    """Convert function to Prefect task if needed."""
    # Check if already a Prefect task (has submit method)
    if hasattr(fn, "submit"):
        return fn
    else:
        return wrap_as_task(fn)