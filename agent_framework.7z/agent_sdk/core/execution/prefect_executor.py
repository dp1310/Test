"""Prefect execution engine for agentic workflows."""

import asyncio
from typing import Callable, List, Any, Dict

from prefect.futures import PrefectFuture

from ..stages import Stage
from ..state import get_state_manager, stage_execution_context, StageState
from .function_utils import as_task
from ...utils.logging import get_logger

logger = get_logger(__name__)


class PrefectExecutor:
    """Prefect execution engine."""
    
    @staticmethod
    def execute_sequential(tasks: List[Callable], ctx: Dict[str, Any]) -> List[Any]:
        """Execute Prefect tasks sequentially."""
        return [task.submit(ctx).result() for task in tasks]
    
    @staticmethod
    def execute_concurrent(tasks: List[Callable], ctx: Dict[str, Any]) -> List[Any]:
        """Execute Prefect tasks concurrently."""
        futures: List[PrefectFuture] = [task.submit(ctx) for task in tasks]
        return [future.result() for future in futures]
    
    @staticmethod
    def execute_sequential_monitored(
        tasks: List[Callable], 
        ctx: Dict[str, Any], 
        stage: Stage, 
        workflow_id: str
    ) -> List[Any]:
        """Execute Prefect tasks sequentially with state monitoring."""
        results = []
        get_state_manager()
        
        for task in tasks:
            function_name = getattr(task, 'name', getattr(task, '__name__', 'unknown'))
            
            with stage_execution_context(stage, function_name, workflow_id) as execution:
                try:
                    result = task.submit(ctx).result()
                    execution.result = result
                    results.append(result)
                except Exception as e:
                    logger.error(f"Task {function_name} failed: {e}")
                    raise
        
        return results
    
    @staticmethod
    def execute_concurrent_monitored(
        tasks: List[Callable], 
        ctx: Dict[str, Any], 
        stage: Stage, 
        workflow_id: str
    ) -> List[Any]:
        """Execute Prefect tasks concurrently with state monitoring."""
        state_manager = get_state_manager()
        executions = []
        
        # Create execution trackers for all tasks
        for task in tasks:
            function_name = getattr(task, 'name', getattr(task, '__name__', 'unknown'))
            execution = state_manager.create_execution(stage, function_name, workflow_id)
            executions.append(execution)
        
        try:
            # Mark all as started
            for execution in executions:
                state_manager.update_state(execution, StageState.STARTED)
                state_manager.update_state(execution, StageState.RUNNING)
            
            # Execute concurrently
            futures: List[PrefectFuture] = [task.submit(ctx) for task in tasks]
            results = [future.result() for future in futures]
            
            # Mark all as completed and store results
            for execution, result in zip(executions, results):
                execution.result = result
                state_manager.update_state(execution, StageState.COMPLETED, result=result)
            
            return results
            
        except Exception as e:
            # Mark any unfinished executions as error
            for execution in executions:
                if not execution.is_finished:
                    state_manager.update_state(execution, StageState.ERROR, error=e)
            raise
    
    @staticmethod
    async def execute_async_tasks(tasks: List[Callable], ctx_dict: Dict[str, Any]) -> List[Any]:
        """Execute Prefect tasks asynchronously."""
        results = []
        for task in tasks:
            logger.debug(f"Executing async Prefect task: {task.name}")
            # Check if the original function (before Prefect wrapping) is async
            original_fn = getattr(task, 'fn', task)
            # Check if the task is async using Prefect's isasync attribute or function inspection
            task_isasync = getattr(task, 'isasync', False)
            fn_is_coroutine = asyncio.iscoroutinefunction(original_fn)
            is_async_task = task_isasync or fn_is_coroutine
            
            logger.debug(f"Task {task.name} async detection:")
            logger.debug(f"  - task.isasync: {task_isasync}")
            logger.debug(f"  - fn is coroutine: {fn_is_coroutine}")
            logger.debug(f"  - final is_async_task: {is_async_task}")
            
            if is_async_task:
                # For async functions, we need to call the original function directly
                logger.debug(f"Task {task.name} is async, calling original function directly")
                logger.debug(f"Original function: {original_fn}")
                logger.debug(f"Is coroutine function: {asyncio.iscoroutinefunction(original_fn)}")
                result = await original_fn(ctx_dict)
                logger.debug(f"Async task {task.name} result: {result}")
                logger.debug(f"Result type: {type(result)}")
            else:
                # For sync functions, use normal Prefect submission
                logger.debug(f"Task {task.name} is sync, using Prefect submission")
                future = task.submit(ctx_dict)
                result = future.result()
                logger.debug(f"Sync task {task.name} result: {result}")
            results.append(result)
        return results
    
    @staticmethod
    async def execute_concurrent_async_tasks(tasks: List[Callable], ctx_dict: Dict[str, Any]) -> List[Any]:
        """Execute Prefect tasks concurrently in async mode."""
        async def run_task(task):
            logger.debug(f"Running concurrent async Prefect task: {task.name}")
            # Check if the original function is async
            original_fn = getattr(task, 'fn', task)
            task_isasync = getattr(task, 'isasync', False)
            fn_is_coroutine = asyncio.iscoroutinefunction(original_fn)
            is_async_task = task_isasync or fn_is_coroutine
            
            logger.debug(f"Concurrent task {task.name} async detection:")
            logger.debug(f"  - task.isasync: {task_isasync}")
            logger.debug(f"  - fn is coroutine: {fn_is_coroutine}")
            logger.debug(f"  - final is_async_task: {is_async_task}")
            
            if is_async_task:
                # For async functions, call original function directly
                logger.debug(f"Concurrent task {task.name} is async, calling original function directly")
                result = await original_fn(ctx_dict)
                logger.debug(f"Concurrent async task {task.name} result: {result}")
                return result
            else:
                # For sync functions, use Prefect submission
                logger.debug(f"Concurrent task {task.name} is sync, using Prefect submission")
                future = task.submit(ctx_dict)
                result = future.result()
                logger.debug(f"Concurrent sync task {task.name} result: {result}")
                return result
        
        # Run all tasks concurrently
        return await asyncio.gather(*[run_task(task) for task in tasks])
    
    @staticmethod
    async def execute_async_tasks_monitored(
        tasks: List[Callable], 
        ctx_dict: Dict[str, Any], 
        stage: Stage, 
        workflow_id: str
    ) -> List[Any]:
        """Execute Prefect tasks asynchronously with state monitoring."""
        results = []
        get_state_manager()
        
        for task in tasks:
            function_name = getattr(task, 'name', getattr(task, '__name__', 'unknown'))
            
            with stage_execution_context(stage, function_name, workflow_id) as execution:
                try:
                    logger.debug(f"Executing async Prefect task: {task.name}")
                    # Check if the original function (before Prefect wrapping) is async
                    original_fn = getattr(task, 'fn', task)
                    # Check if the task is async using Prefect's isasync attribute or function inspection
                    task_isasync = getattr(task, 'isasync', False)
                    fn_is_coroutine = asyncio.iscoroutinefunction(original_fn)
                    is_async_task = task_isasync or fn_is_coroutine
                    
                    if is_async_task:
                        # For async functions, we need to call the original function directly
                        logger.debug(f"Task {task.name} is async, calling original function directly")
                        result = await original_fn(ctx_dict)
                        logger.debug(f"Async task {task.name} result: {result}")
                    else:
                        # For sync functions, use normal Prefect submission
                        logger.debug(f"Task {task.name} is sync, using Prefect submission")
                        future = task.submit(ctx_dict)
                        result = future.result()
                        logger.debug(f"Sync task {task.name} result: {result}")
                    
                    execution.result = result
                    results.append(result)
                    
                except Exception as e:
                    logger.error(f"Async Prefect task {function_name} failed: {e}")
                    raise
        
        return results
    
    @staticmethod
    async def execute_concurrent_async_tasks_monitored(
        tasks: List[Callable], 
        ctx_dict: Dict[str, Any], 
        stage: Stage, 
        workflow_id: str
    ) -> List[Any]:
        """Execute Prefect tasks concurrently in async mode with state monitoring."""
        state_manager = get_state_manager()
        executions = []
        
        # Create execution trackers for all tasks
        for task in tasks:
            function_name = getattr(task, 'name', getattr(task, '__name__', 'unknown'))
            execution = state_manager.create_execution(stage, function_name, workflow_id)
            executions.append(execution)
        
        async def run_task_monitored(task, execution):
            try:
                # Mark as started and running
                state_manager.update_state(execution, StageState.STARTED)
                state_manager.update_state(execution, StageState.RUNNING)
                
                logger.debug(f"Running concurrent async Prefect task: {task.name}")
                # Check if the original function is async
                original_fn = getattr(task, 'fn', task)
                task_isasync = getattr(task, 'isasync', False)
                fn_is_coroutine = asyncio.iscoroutinefunction(original_fn)
                is_async_task = task_isasync or fn_is_coroutine
                
                if is_async_task:
                    # For async functions, call original function directly
                    logger.debug(f"Concurrent task {task.name} is async, calling original function directly")
                    result = await original_fn(ctx_dict)
                    logger.debug(f"Concurrent async task {task.name} result: {result}")
                else:
                    # For sync functions, use Prefect submission
                    logger.debug(f"Concurrent task {task.name} is sync, using Prefect submission")
                    future = task.submit(ctx_dict)
                    result = future.result()
                    logger.debug(f"Concurrent sync task {task.name} result: {result}")
                
                # Mark as completed
                execution.result = result
                state_manager.update_state(execution, StageState.COMPLETED, result=result)
                return result
                
            except Exception as e:
                # Mark as error
                state_manager.update_state(execution, StageState.ERROR, error=e)
                logger.error(f"Concurrent async Prefect task {task.name} failed: {e}")
                raise
        
        # Run all tasks concurrently
        return await asyncio.gather(*[run_task_monitored(task, execution) for task, execution in zip(tasks, executions)])