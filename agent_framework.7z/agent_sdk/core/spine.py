"""Core spine implementation for agentic workflows."""

import uuid
from typing import Callable, List, Dict, Any, Optional

from prefect import flow

from .context import Context
from .stages import Stage
from .state import get_state_manager
from .execution.function_utils import (
    collect_functions as _collect_functions,
    wrap_as_task as _wrap_as_task,
    as_task as _as_task
)
from .execution.context_utils import merge_context_dict as _merge_context_dict
from .execution.sync_executor import SyncExecutor
from .execution.async_executor import AsyncExecutor
from .execution.prefect_executor import PrefectExecutor
from ..utils.logging import get_logger

logger = get_logger(__name__)

# Re-export only the private functions actually used in tests for backward compatibility
_collect_functions = _collect_functions
_wrap_as_task = _wrap_as_task
_as_task = _as_task
_merge_context_dict = _merge_context_dict
_execute_sequential = SyncExecutor.execute_sequential
_execute_concurrent = AsyncExecutor.execute_concurrent
_execute_stage_sync = SyncExecutor.execute_stage
_execute_stage_async = AsyncExecutor.execute_stage


@flow(name="AgenticSpine")
def agentic_spine(
    input_data: Any,
    functions: List[Callable],
    initial_context: Optional[Dict[str, Any]] = None,
    concurrent: Optional[Dict[Stage, bool]] = None,
    workflow_id: Optional[str] = None,
) -> Context:
    """
    Execute agentic workflow using Prefect flow.
    
    Args:
        input_data: Input data for the workflow
        functions: List of stage functions
        initial_context: Additional initial context
        concurrent: Stage-level concurrency settings
        workflow_id: Unique identifier for workflow monitoring
        
    Returns:
        Final context after all stages
    """
    # Generate workflow ID if not provided
    if workflow_id is None:
        workflow_id = f"prefect_sync_{uuid.uuid4().hex[:8]}"
    
    state_manager = get_state_manager()
    
    try:
        logger.info(f"Starting Prefect agentic spine execution - {workflow_id}")
        state_manager.start_workflow(workflow_id)
        
        # Initialize context as dict for Prefect compatibility
        ctx_dict = {"input": input_data, **(initial_context or {})}
        
        # Collect functions by stage
        stage_map = _collect_functions(functions)
        concurrent_settings = concurrent or {}
        
        # Execute stages in order using Prefect tasks
        stage_order = [Stage.PERCEIVE, Stage.REASON, Stage.PLAN, Stage.ACT]
        
        for stage in stage_order:
            stage_functions = stage_map.get(stage, [])
            if stage_functions:
                logger.info(f"Executing {stage.name} stage with {len(stage_functions)} functions")
                
                # Convert to Prefect tasks
                tasks = [_as_task(fn) for fn in stage_functions]
                
                # Choose execution strategy
                is_concurrent = concurrent_settings.get(stage, False)
                if is_concurrent:
                    results = PrefectExecutor.execute_concurrent_monitored(tasks, ctx_dict, stage, workflow_id)
                else:
                    results = PrefectExecutor.execute_sequential_monitored(tasks, ctx_dict, stage, workflow_id)
                
                # Merge results into context
                for result in results:
                    ctx_dict = _merge_context_dict(ctx_dict, result)
        
        logger.info(f"Prefect agentic spine execution completed - {workflow_id}")
        state_manager.complete_workflow(workflow_id)
        return Context(data=ctx_dict)
        
    except Exception as e:
        logger.error(f"Prefect agentic spine execution failed - {workflow_id}: {e}")
        state_manager.error_workflow(workflow_id, e)
        raise


def agentic_spine_simple(
    input_data: Any,
    functions: List[Callable],
    initial_context: Optional[Dict[str, Any]] = None,
    concurrent: Optional[Dict[Stage, bool]] = None,
    workflow_id: Optional[str] = None,
) -> Context:
    """
    Execute agentic workflow without Prefect (simple version).
    
    Args:
        input_data: Input data for the workflow
        functions: List of stage functions
        initial_context: Additional initial context
        concurrent: Stage-level concurrency settings
        workflow_id: Unique identifier for workflow monitoring
        
    Returns:
        Final context after all stages
    """
    # Generate workflow ID if not provided
    if workflow_id is None:
        workflow_id = f"simple_sync_{uuid.uuid4().hex[:8]}"
    
    state_manager = get_state_manager()
    
    try:
        logger.info(f"Starting simple agentic spine execution - {workflow_id}")
        state_manager.start_workflow(workflow_id)
        
        # Initialize context
        ctx_data = {"input": input_data, **(initial_context or {})}
        ctx = Context(data=ctx_data)
        
        # Collect functions by stage
        stage_map = _collect_functions(functions)
        concurrent_settings = concurrent or {}
        
        # Execute stages in order
        stage_order = [Stage.PERCEIVE, Stage.REASON, Stage.PLAN, Stage.ACT]
        
        for stage in stage_order:
            stage_functions = stage_map.get(stage, [])
            if stage_functions:
                logger.info(f"Executing {stage.name} stage with {len(stage_functions)} functions")
                is_concurrent = concurrent_settings.get(stage, False)
                ctx = SyncExecutor.execute_stage_monitored(stage_functions, ctx, is_concurrent, stage, workflow_id)
        
        logger.info(f"Simple agentic spine execution completed - {workflow_id}")
        state_manager.complete_workflow(workflow_id)
        return ctx
        
    except Exception as e:
        logger.error(f"Simple agentic spine execution failed - {workflow_id}: {e}")
        state_manager.error_workflow(workflow_id, e)
        raise


async def agentic_spine_async(
    input_data: Any,
    functions: List[Callable],
    initial_context: Optional[Dict[str, Any]] = None,
    concurrent: Optional[Dict[Stage, bool]] = None,
    workflow_id: Optional[str] = None,
) -> Context:
    """
    Execute agentic workflow asynchronously (simple version).
    
    Args:
        input_data: Input data for the workflow
        functions: List of stage functions
        initial_context: Additional initial context
        concurrent: Stage-level concurrency settings
        workflow_id: Unique identifier for workflow monitoring
        
    Returns:
        Final context after all stages
    """
    # Generate workflow ID if not provided
    if workflow_id is None:
        workflow_id = f"simple_async_{uuid.uuid4().hex[:8]}"
    
    state_manager = get_state_manager()
    
    try:
        logger.info(f"Starting asynchronous agentic spine execution - {workflow_id}")
        state_manager.start_workflow(workflow_id)
        
        # Initialize context
        ctx_data = {"input": input_data, **(initial_context or {})}
        ctx = Context(data=ctx_data)
        
        # Collect functions by stage
        stage_map = _collect_functions(functions)
        concurrent_settings = concurrent or {}
        
        # Execute stages in order
        stage_order = [Stage.PERCEIVE, Stage.REASON, Stage.PLAN, Stage.ACT]
        
        for stage in stage_order:
            stage_functions = stage_map.get(stage, [])
            if stage_functions:
                logger.info(f"Executing {stage.name} stage with {len(stage_functions)} functions")
                is_concurrent = concurrent_settings.get(stage, False)
                ctx = await AsyncExecutor.execute_stage_monitored(stage_functions, ctx, is_concurrent, stage, workflow_id)
        
        logger.info(f"Asynchronous agentic spine execution completed - {workflow_id}")
        state_manager.complete_workflow(workflow_id)
        return ctx
        
    except Exception as e:
        logger.error(f"Asynchronous agentic spine execution failed - {workflow_id}: {e}")
        state_manager.error_workflow(workflow_id, e)
        raise


@flow(name="AgenticSpineAsync")
async def agentic_spine_async_prefect(
    input_data: Any,
    functions: List[Callable],
    initial_context: Optional[Dict[str, Any]] = None,
    concurrent: Optional[Dict[Stage, bool]] = None,
    workflow_id: Optional[str] = None,
) -> Context:
    """
    Execute agentic workflow asynchronously using Prefect flow.
    
    Args:
        input_data: Input data for the workflow
        functions: List of stage functions
        initial_context: Additional initial context
        concurrent: Stage-level concurrency settings
        workflow_id: Unique identifier for workflow monitoring
        
    Returns:
        Final context after all stages
    """
    # Generate workflow ID if not provided
    if workflow_id is None:
        workflow_id = f"prefect_async_{uuid.uuid4().hex[:8]}"
    
    state_manager = get_state_manager()
    
    try:
        logger.info(f"Starting async Prefect agentic spine execution - {workflow_id}")
        state_manager.start_workflow(workflow_id)
        
        # Initialize context as dict for Prefect compatibility
        ctx_dict = {"input": input_data, **(initial_context or {})}
        
        # Collect functions by stage
        stage_map = _collect_functions(functions)
        concurrent_settings = concurrent or {}
        
        # Execute stages in order using Prefect tasks
        stage_order = [Stage.PERCEIVE, Stage.REASON, Stage.PLAN, Stage.ACT]
        
        for stage in stage_order:
            stage_functions = stage_map.get(stage, [])
            if stage_functions:
                logger.info(f"Executing {stage.name} stage with {len(stage_functions)} functions")
                
                # Convert to Prefect tasks
                tasks = [_as_task(fn) for fn in stage_functions]
                
                # Choose execution strategy
                is_concurrent = concurrent_settings.get(stage, False)
                if is_concurrent:
                    results = await PrefectExecutor.execute_concurrent_async_tasks_monitored(tasks, ctx_dict, stage, workflow_id)
                else:
                    results = await PrefectExecutor.execute_async_tasks_monitored(tasks, ctx_dict, stage, workflow_id)
                
                # Merge results into context
                logger.debug(f"Merging {len(results)} results into context for stage {stage.name}")
                for i, result in enumerate(results):
                    logger.debug(f"Merging result {i}: {result}")
                    ctx_dict = _merge_context_dict(ctx_dict, result)
                    logger.debug(f"Context after merge {i}: {list(ctx_dict.keys())}")
        
        logger.info(f"Async Prefect agentic spine execution completed - {workflow_id}")
        state_manager.complete_workflow(workflow_id)
        return Context(data=ctx_dict)
        
    except Exception as e:
        logger.error(f"Async Prefect agentic spine execution failed - {workflow_id}: {e}")
        state_manager.error_workflow(workflow_id, e)
        raise