"""
Context manager for stage execution tracking.
"""

from contextlib import contextmanager

from .enums import StageState
# Import moved inside function to avoid circular import
from ..stages import Stage


@contextmanager
def stage_execution_context(stage: Stage, function_name: str, workflow_id: str = "default"):
    """Context manager for tracking stage execution."""
    from .functions import get_state_manager
    state_manager = get_state_manager()
    execution = state_manager.create_execution(stage, function_name, workflow_id)
    
    try:
        # Mark as started
        state_manager.update_state(execution, StageState.STARTED)
        state_manager.update_state(execution, StageState.RUNNING)
        
        yield execution
        
        # Mark as completed if no exception, pass result if set
        state_manager.update_state(execution, StageState.COMPLETED, result=execution.result)
        
    except Exception as e:
        # Mark as error
        state_manager.update_state(execution, StageState.ERROR, error=e)
        raise