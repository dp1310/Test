"""
State manager for coordinating stage execution tracking.
"""

from typing import Dict, List, Optional, Any
import threading
from datetime import datetime

from .enums import StageState
from .execution import StageExecution
from .observers import StageStateObserver
from ..stages import Stage
from ...utils.logging import get_logger

logger = get_logger(__name__)


class StageStateManager:
    """Manages stage state tracking and observer notifications."""
    
    def __init__(self):
        self.observers: List[StageStateObserver] = []
        self.executions: Dict[str, List[StageExecution]] = {}
        self._lock = threading.Lock()
        self._execution_counter = 0
    
    def add_observer(self, observer: StageStateObserver) -> None:
        """Add a state observer."""
        self.observers.append(observer)
    
    def remove_observer(self, observer: StageStateObserver) -> None:
        """Remove a state observer."""
        if observer in self.observers:
            self.observers.remove(observer)
    
    def create_execution(self, stage: Stage, function_name: str, workflow_id: str = "default") -> StageExecution:
        """Create a new stage execution tracker."""
        with self._lock:
            self._execution_counter += 1
            execution_id = f"{workflow_id}_{stage.name}_{self._execution_counter}"
        
        execution = StageExecution(
            stage=stage,
            state=StageState.CREATED,
            function_name=function_name,
            execution_id=execution_id,
            workflow_id=workflow_id
        )
        
        with self._lock:
            if workflow_id not in self.executions:
                self.executions[workflow_id] = []
            self.executions[workflow_id].append(execution)
        
        return execution
    
    def update_state(self, execution: StageExecution, new_state: StageState, 
                    error: Optional[Exception] = None, result: Optional[Any] = None,
                    metadata: Optional[Dict[str, Any]] = None) -> None:
        """Update the state of a stage execution."""
        execution.state = new_state
        
        if new_state == StageState.STARTED:
            execution.start_time = datetime.now()
        elif new_state in {StageState.COMPLETED, StageState.ERROR, StageState.CANCELLED}:
            execution.end_time = datetime.now()
        
        if error:
            execution.error = error
        if result is not None:
            execution.result = result
        if metadata:
            execution.metadata.update(metadata)
        
        # Notify observers
        for observer in self.observers:
            try:
                observer.on_stage_state_changed(execution)
            except Exception as e:
                logger.error(f"Observer {observer} failed to handle state change: {e}")
    
    def start_workflow(self, workflow_id: str) -> None:
        """Mark the start of a workflow."""
        for observer in self.observers:
            try:
                observer.on_workflow_started(workflow_id)
            except Exception as e:
                logger.error(f"Observer {observer} failed to handle workflow start: {e}")
    
    def complete_workflow(self, workflow_id: str) -> None:
        """Mark the completion of a workflow."""
        executions = self.executions.get(workflow_id, [])
        for observer in self.observers:
            try:
                observer.on_workflow_completed(workflow_id, executions)
            except Exception as e:
                logger.error(f"Observer {observer} failed to handle workflow completion: {e}")
    
    def error_workflow(self, workflow_id: str, error: Exception) -> None:
        """Mark a workflow error."""
        for observer in self.observers:
            try:
                observer.on_workflow_error(workflow_id, error)
            except Exception as e:
                logger.error(f"Observer {observer} failed to handle workflow error: {e}")
    
    def get_executions(self, workflow_id: str) -> List[StageExecution]:
        """Get all executions for a workflow."""
        return self.executions.get(workflow_id, [])
    
    def get_execution_summary(self, workflow_id: str) -> Dict[str, Any]:
        """Get a summary of workflow execution."""
        executions = self.get_executions(workflow_id)
        
        if not executions:
            return {"workflow_id": workflow_id, "status": "not_found", "total": 0, "completed": 0, "errors": 0, "failed": 0, "running": 0}
        
        total_duration = sum(e.duration or 0 for e in executions if e.duration)
        completed = [e for e in executions if e.state == StageState.COMPLETED]
        errors = [e for e in executions if e.state == StageState.ERROR]
        running = [e for e in executions if e.state in {StageState.STARTED, StageState.RUNNING}]
        
        return {
            "workflow_id": workflow_id,
            "total": len(executions),
            "total_stages": len(executions),
            "completed": len(completed),
            "errors": len(errors),
            "failed": len(errors),
            "running": len(running),
            "total_duration": total_duration,
            "status": "running" if running else "completed" if not errors else "failed",
            "executions": [e.to_dict() for e in executions]
        }