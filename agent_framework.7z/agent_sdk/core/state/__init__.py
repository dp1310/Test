"""
State management and monitoring system for agentic workflows.

This module provides comprehensive state tracking for agentic workflow stages,
allowing real-time monitoring of stage execution states using functional programming principles.
"""

from .enums import StageState
from .execution import StageExecution
from .observers import StageStateObserver, LoggingObserver, MetricsObserver
from .manager import StageStateManager
from .context import stage_execution_context
from .functions import (
    get_state_manager, configure_monitoring, get_workflow_status, get_metrics
)

__all__ = [
    # Core types
    "StageState",
    "StageExecution",
    
    # Observer pattern
    "StageStateObserver",
    "LoggingObserver", 
    "MetricsObserver",
    
    # State management
    "StageStateManager",
    
    # Context management
    "stage_execution_context",
    
    # Global functions
    "get_state_manager",
    "configure_monitoring", 
    "get_workflow_status",
    "get_metrics"
]