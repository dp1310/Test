# Agent SDK

A functional programming framework for building agentic workflows with async support and modular stage-based processing.

## Features

- **🚀 Async Prefect Integration**: Full async Prefect task and flow support with concurrent execution
- **🔧 Comprehensive Tools System**: LLM providers, databases, APIs, and utilities with @tool_hook integration
- **🎯 Custom Decorators**: Flexible `stage_decorator()` and type-safe `async_stage()` decorators
- **⚡ Multiple Execution Modes**: Choose between simple async, Prefect sync, or Prefect async execution
- **🔄 Functional Programming Style**: Pure functions, immutable contexts, and composable workflows
- **🌊 Full Async Support**: Complete async/await support with concurrent execution capabilities
- **📋 Stage-Based Architecture**: Organize workflows into PERCEIVE → REASON → PLAN → ACT stages
- **🔀 Concurrent Task Execution**: Run independent tasks concurrently using Prefect futures or asyncio
- **🔒 Immutable Context**: Thread-safe context management with functional updates
- **🧩 Modular Design**: Clean separation of concerns with extensible architecture
- **🛡️ Type Safety**: Full type hints and mypy compatibility
- **✅ Comprehensive Testing**: Extensive test suite with pytest and async testing

## 🆕 What's New in v0.2.1

### 🔗 Dynamic Configuration & String Function Resolution
- **Dynamic Function Override**: Runtime function replacement via input data
- **String Function References**: Use `"module.function"` strings instead of callable objects
- **Mixed Format Support**: Combine callable functions and string references
- **Cross-Module Resolution**: Reference functions from any importable module
- **Backward Compatibility**: All existing code continues to work unchanged

### 🚀 Async Prefect Integration
- **Full async support** with Prefect tasks and flows
- **Concurrent async execution** across all stages
- **Production-ready** async workflows with monitoring

### 🔧 Comprehensive Tools System
- **LLM Integration**: OpenAI, Gemini, Mistral, Anthropic with unified interface
- **Database Tools**: PostgreSQL, Neo4j, MongoDB with async support
- **API Tools**: HTTP client, REST API with pagination and authentication
- **Utility Tools**: File operations, Email, Slack notifications
- **@tool_hook Decorator**: Automatic tool injection into any function
- **YAML + .env Configuration**: Easy setup and environment management

### 🎯 Custom Decorators & Agent Extensions
- **`stage_decorator()`**: Flexible decorator that auto-detects sync/async functions
- **`async_stage()`**: Type-safe decorator that enforces async-only functions
- **Custom Agent Classes**: Extend base agents with enhanced features
- **Execution Metrics**: Built-in performance tracking and monitoring
- **Fluent Interface**: Method chaining for elegant configuration

### 📚 Comprehensive Examples
- **Simple demos** for quick learning
- **Advanced workflows** with ML pipelines
- **Tools integration** with Prefect orchestration
- **Custom agent examples** with enhanced features
- **Quick reference** for copy-paste usage
- **Performance comparisons** between execution modes

## Quick Start

### Installation

```bash
# Clone and install
git clone <repository-url>
cd agent_framework
pip install -e .

# Verify installation
python verify_setup.py
```

For detailed installation options, see [INSTALL.md](INSTALL.md).

### 🎯 Choose Your Execution Mode

| Need | Use | Best For |
|------|-----|----------|
| **Simple & Fast** | `agentic_spine_async()` | Development, simple workflows |
| **Production Ready** | `agentic_spine()` | Production systems, monitoring |
| **Advanced Async** | `agentic_spine_async_prefect()` | Complex async systems, ML pipelines |
| **Custom Decorators** | `stage_decorator()` / `async_stage()` | Type safety, better DX |
| **AI Integration** | `@tool_hook` + LLM tools | AI-powered workflows |
| **Full Stack** | Prefect + Tools + Agentic | Enterprise AI applications |

### Basic Usage (Prefect-Powered)

```python
from agent_sdk import perceive, reason, plan, act, agentic_spine, Context, Stage
from prefect import task

@perceive
@task(name="analyze_input")
def analyze_input(ctx: dict) -> dict:
    text = ctx.get("input", {}).get("text", "")
    return {"length": len(text), "has_keywords": "urgent" in text.lower()}

@reason
@task(name="assess_priority")
def assess_priority(ctx: dict) -> dict:
    is_urgent = ctx.get("has_keywords", False)
    length = ctx.get("length", 0)
    return {"priority": "high" if is_urgent or length > 100 else "normal"}

@plan
def create_plan(ctx: dict) -> dict:
    priority = ctx.get("priority", "normal")
    steps = ["validate", "process"] if priority == "normal" else ["escalate", "fast_track"]
    return {"action_steps": steps}

@act
def execute_plan(ctx: dict) -> dict:
    steps = ctx.get("action_steps", [])
    return {"executed": [f"completed: {step}" for step in steps]}

# Execute Prefect-powered workflow
result = agentic_spine(
    input_data={"text": "This is an urgent request"},
    functions=[analyze_input, assess_priority, create_plan, execute_plan],
    concurrent={Stage.PERCEIVE: True}  # Run perception tasks concurrently
)

print(result.get("priority"))  # "high"
print(result.get("executed"))  # ["completed: escalate", "completed: fast_track"]
```

### 🔗 Dynamic Configuration & String Functions

```python
from agent_sdk.agent import create_simple_sync_agent

# Define functions in a module
@perceive
def my_perceive_func(context):
    return {"perceived": "data"}

@reason  
def my_reason_func(context):
    return {"reasoning": "complete"}

# Create agent
agent = create_simple_sync_agent(
    functions=[my_perceive_func],
    workflow_id="dynamic_demo"
)

# BEFORE: Callable functions (still supported)
result1 = agent.execute({
    "input": "test",
    "functions": [my_perceive_func, my_reason_func]  # Callable objects
})

# NEW: String function references
result2 = agent.execute({
    "input": "test", 
    "functions": ["mymodule.my_perceive_func", "mymodule.my_reason_func"]  # String references
})

# NEW: Mixed format
result3 = agent.execute({
    "input": "test",
    "functions": [my_perceive_func, "mymodule.my_reason_func"]  # Mixed format
})

# NEW: Dynamic concurrency override
result4 = agent.execute({
    "input": "test",
    "functions": [my_perceive_func, my_reason_func],
    "concurrent": {
        "PERCEIVE": True,   # Override concurrency settings
        "REASON": False
    }
})
```

### Simple Usage (Without Prefect)

```python
from agent_sdk import perceive, reason, plan, act, agentic_spine_simple, Context

@perceive
def analyze_input(ctx: Context) -> dict:
    text = ctx.get("input", {}).get("text", "")
    return {"length": len(text), "has_keywords": "urgent" in text.lower()}

@reason
def assess_priority(ctx: Context) -> dict:
    is_urgent = ctx.get("has_keywords", False)
    length = ctx.get("length", 0)
    return {"priority": "high" if is_urgent or length > 100 else "normal"}

# Execute simple workflow (no Prefect)
result = agentic_spine_simple(
    input_data={"text": "This is an urgent request"},
    functions=[analyze_input, assess_priority]
)
```

### Async Usage (Simple)

```python
import asyncio
from agent_sdk import perceive, reason, agentic_spine_async, Context

@perceive
async def async_analyze(ctx: Context) -> dict:
    # Simulate async API call
    await asyncio.sleep(0.1)
    text = ctx.get("input", {}).get("text", "")
    return {"analyzed": True, "word_count": len(text.split())}

@reason
async def async_reason(ctx: Context) -> dict:
    await asyncio.sleep(0.05)
    word_count = ctx.get("word_count", 0)
    return {"complexity": "high" if word_count > 50 else "low"}

async def main():
    result = await agentic_spine_async(
        input_data={"text": "This is a sample text for analysis"},
        functions=[async_analyze, async_reason],
        concurrent={Stage.PERCEIVE: True}  # Run perception stages concurrently
    )
    print(result.get("complexity"))

asyncio.run(main())
```

### Async Prefect Integration

```python
import asyncio
from agent_sdk import agentic_spine_async_prefect, Context
from agent_sdk.core.decorators import stage_decorator, async_stage
from agent_sdk.core.stages import Stage
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

# Create custom decorators
perceive = stage_decorator(Stage.PERCEIVE)
reason = async_stage(Stage.REASON)  # Enforces async-only

@perceive
@task(name="load_data", cache_policy=NO_CACHE)
async def load_data(ctx: dict) -> dict:
    """Async data loading with Prefect task."""
    await asyncio.sleep(0.1)  # Simulate async I/O
    text = ctx.get("input", {}).get("text", "")
    return {"text": text, "word_count": len(text.split())}

@reason
@task(name="ml_analysis", cache_policy=NO_CACHE)
async def ml_analysis(ctx: dict) -> dict:
    """Async ML analysis - enforced by async_stage decorator."""
    await asyncio.sleep(0.2)  # Simulate ML inference
    word_count = ctx.get("word_count", 0)
    return {"complexity": "high" if word_count > 50 else "low", "confidence": 0.95}

async def main():
    result = await agentic_spine_async_prefect(
        input_data={"text": "This is advanced async Prefect processing"},
        functions=[load_data, ml_analysis],
        concurrent={Stage.PERCEIVE: True}  # Concurrent async execution
    )
    print(f"Complexity: {result.data.get('complexity')}")
    print(f"Confidence: {result.data.get('confidence')}")

asyncio.run(main())
```

### 🔧 Comprehensive Tools System

The Agent SDK includes a powerful tools system that allows any task to execute external tools including LLM providers, databases, APIs, and utilities.

#### Basic Tools Usage

```python
from agent_sdk.tools import tool_hook

@perceive
@tool_hook
async def analyze_with_tools(ctx, tools):
    """Task with automatic tool injection."""
    
    # Use LLM for analysis
    llm_result = await tools.execute('openai',
        prompt="Analyze this data for insights",
        max_tokens=200,
        temperature=0.7
    )
    
    # Store results in database
    if llm_result.is_success:
        db_result = await tools.execute('postgresql',
            query="INSERT INTO analyses (result) VALUES ($1)",
            params=[llm_result.data['response']]
        )
    
    # Send notification
    await tools.execute('slack_notifier',
        message="Analysis completed!",
        channel="#alerts"
    )
    
    return {"analysis": llm_result.data, "stored": True}
```

#### Prefect + Tools Integration

```python
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

@perceive                                    # Agentic stage
@task(name="ai_task", cache_policy=NO_CACHE) # Prefect task
@tool_hook                                   # Tools integration
async def ai_analysis_task(ctx: dict, tools) -> dict:
    """Triple decorator pattern: Agentic + Prefect + Tools."""
    
    text = ctx.get("input", {}).get("text", "")
    
    # Get available tools dynamically
    llm_tools = tools.get_available_tools('llm')
    db_tools = tools.get_available_tools('database')
    
    # Use first available LLM
    if llm_tools:
        result = await tools.execute(llm_tools[0],
            prompt=f"Analyze: {text}",
            max_tokens=150
        )
        
        # Store if database available
        if db_tools and result.is_success:
            await tools.execute(db_tools[0],
                query="INSERT INTO results (analysis) VALUES ($1)",
                params=[result.data['response']]
            )
    
    return {"analysis_complete": True}

# Execute with full orchestration
result = await agentic_spine_async_prefect(
    input_data={"text": "Process this with AI"},
    functions=[ai_analysis_task],
    workflow_id="ai_workflow"
)
```

#### Available Tools

**🤖 LLM Tools:**
- **OpenAI GPT**: `openai` - GPT-3.5, GPT-4 with streaming support
- **Google Gemini**: `gemini` - Gemini Pro with multimodal capabilities
- **Mistral AI**: `mistral` - Mistral models with function calling
- **Anthropic Claude**: `anthropic` - Claude 3 with large context

**💾 Database Tools:**
- **PostgreSQL**: `postgresql` - Async connection pooling, parameterized queries
- **Neo4j**: `neo4j` - Graph database with Cypher queries
- **MongoDB**: `mongodb` - Document operations with Motor async driver

**🌐 API Tools:**
- **HTTP Client**: `http_client` - Full HTTP methods with authentication
- **REST API**: `rest_api` - Enhanced with pagination and rate limiting

**📁 Utility Tools:**
- **File Manager**: `file_manager` - Secure file operations
- **Email Sender**: `email_sender` - SMTP with HTML support
- **Slack Notifier**: `slack_notifier` - Webhook and Bot API

#### Configuration

**1. Environment Variables** (`.env`):
```bash
# LLM API Keys
OPENAI_API_KEY=your_openai_key
GEMINI_API_KEY=your_gemini_key
ANTHROPIC_API_KEY=your_anthropic_key

# Database URLs
POSTGRES_URL=postgresql://user:pass@host:port/db
NEO4J_URI=bolt://localhost:7687
MONGODB_URI=mongodb://localhost:27017/db

# Notification Services
SLACK_WEBHOOK_URL=https://hooks.slack.com/...
SMTP_SERVER=smtp.gmail.com
```

**2. Tools Configuration** (`config/tools.yaml`):
```yaml
tools:
  openai:
    type: llm
    enabled: true
    config:
      api_key: ${OPENAI_API_KEY}
      model: ${OPENAI_MODEL:gpt-3.5-turbo}
      max_tokens: ${OPENAI_MAX_TOKENS:1000}
  
  postgresql:
    type: database
    enabled: true
    config:
      url: ${POSTGRES_URL}
      pool_size: ${POSTGRES_POOL_SIZE:10}
```

#### Tools Demos

```bash
# Basic tools demonstration
python agent_framework/examples/tools_basic_demo.py

# Working tools with file operations
python agent_framework/examples/tools_working_demo.py

# Comprehensive tools system
python agent_framework/examples/tools_system_demo.py

# Prefect + Tools integration
python agent_framework/examples/tools_prefect_integration_demo.py
```

### Custom Decorators Usage

```python
from agent_sdk.core.decorators import stage_decorator, async_stage
from agent_sdk.core.stages import Stage

# Flexible decorators (work with both sync and async)
data_loader = stage_decorator(Stage.PERCEIVE)
analyzer = stage_decorator(Stage.REASON)

# Async-only decorators (enforce type safety)
ml_processor = async_stage(Stage.REASON)
async_executor = async_stage(Stage.ACT)

@data_loader
def sync_load(ctx):
    """Sync function - automatically detected."""
    return {"loaded": True, "method": "sync"}

@data_loader
async def async_load(ctx):
    """Async function - automatically detected."""
    await asyncio.sleep(0.1)
    return {"loaded": True, "method": "async"}

@ml_processor
async def ml_analysis(ctx):
    """Must be async - enforced by async_stage."""
    await asyncio.sleep(0.2)
    return {"analysis": "complete", "model": "v2.1"}

# This would raise ValueError:
# @ml_processor
# def sync_analysis(ctx):  # ❌ Error: must be async!
#     return {"error": "not_allowed"}
```

### Stage Monitoring Integration

```python
from agent_sdk import agentic_spine_async
from agent_sdk.core.state import configure_monitoring, get_workflow_status

# Setup monitoring
configure_monitoring(enable_logging=True, enable_metrics=True)

# Run workflow with monitoring
result = await agentic_spine_async(
    input_data={"text": "monitored workflow"},
    functions=[data_loader, ml_processor],
    workflow_id="my_workflow"  # Enable workflow tracking
)

# Check status
status = get_workflow_status("my_workflow")
print(f"✅ Workflow completed: {status['completed']}/{status['total_stages']} stages")
print(f"⏱️ Duration: {status['total_duration']:.3f}s")
print(f"📊 Success rate: {(status['completed']/status['total_stages']*100):.1f}%")
```

## Architecture

### Stage-Based Processing

The framework organizes workflows into four sequential stages:

1. **PERCEIVE**: Gather and analyze input data
2. **REASON**: Process information and make assessments  
3. **PLAN**: Create action plans based on reasoning
4. **ACT**: Execute the planned actions

### Dynamic Configuration System

The framework supports runtime configuration through input data:

```python
# Dynamic function override
dynamic_input = {
    "input": "actual_data",
    "functions": ["module.func1", "module.func2"],  # String references
    "concurrent": {"PERCEIVE": True, "REASON": False}  # Runtime concurrency
}

result = agent.execute(dynamic_input)
```

**Key Features:**
- **String Function Resolution**: Reference functions as `"module.function"` strings
- **Cross-Module Support**: Import functions from any accessible module
- **Mixed Format**: Combine callable objects and string references
- **Runtime Override**: Change functions and concurrency per execution
- **Backward Compatibility**: All existing code continues to work

### Functional Context Management

```python
from agent_sdk import Context, merge_context

# Immutable context operations
ctx1 = Context(data={"key": "value"})
ctx2 = ctx1.with_data(new_key="new_value")  # Returns new context
ctx3 = merge_context(ctx1, {"another": "value"})  # Functional merge

# Dict-like access
value = ctx1["key"]
has_key = "key" in ctx1
safe_get = ctx1.get("missing", "default")
```

### Concurrent Execution with Prefect

```python
from prefect import task

@perceive
@task(name="task_1")
def concurrent_task_1(ctx: dict) -> dict:
    # This will run concurrently with other PERCEIVE tasks
    return {"task_1": "completed"}

@perceive
@task(name="task_2") 
def concurrent_task_2(ctx: dict) -> dict:
    # This will run concurrently with task_1
    return {"task_2": "completed"}

# Configure stage-level concurrency using Prefect futures
result = agentic_spine(
    input_data=data,
    functions=[concurrent_task_1, concurrent_task_2, reason_task],
    concurrent={
        Stage.PERCEIVE: True,   # Run PERCEIVE tasks concurrently using Prefect
        Stage.REASON: False,    # Run REASON tasks sequentially
        Stage.PLAN: False,      # Run PLAN tasks sequentially
        Stage.ACT: False,       # Run ACT tasks sequentially
    }
)
```

## Examples

### 🎯 Custom Decorators Demo

See `examples/decorators_simple_demo.py` for a comprehensive demonstration:

```bash
python agent_framework/examples/decorators_simple_demo.py
```

Key features demonstrated:
- **Flexible decorators** that auto-detect sync vs async functions
- **Type-safe async-only** decorators with error handling
- **Mixed workflows** combining sync and async functions
- **Metadata inspection** and debugging capabilities

### 🚀 Async Prefect Integration Demo

See `examples/async_prefect_demo.py` for advanced async workflows:

```bash
python agent_framework/examples/async_prefect_demo.py
```

Features showcased:
- **Full async Prefect integration** with proper task execution
- **Concurrent async processing** across multiple stages
- **Performance comparisons** between execution modes
- **Real-world ML pipeline** with strategic planning

### 🔗 Dynamic Configuration Examples

See `examples/string_resolution_demo.py` and `examples/dynamic_config_example.py`:

```bash
# String function resolution demo
python agent_framework/examples/string_resolution_demo.py

# Dynamic configuration examples
python agent_framework/examples/dynamic_config_example.py

# Custom agent with enhanced features
python agent_framework/examples/custom_agent_example.py
```

Features demonstrated:
- **String function references** with cross-module support
- **Dynamic function override** at runtime
- **Mixed callable and string formats**
- **Custom agent extensions** with metrics and validation
- **Enhanced fluent interface** for configuration

### 📚 Quick Reference Guide

See `examples/decorators_quick_reference.py` for copy-paste examples:

```bash
python agent_framework/examples/decorators_quick_reference.py
```

Includes:
- **Ready-to-use patterns** for immediate implementation
- **Best practices** and common usage scenarios
- **Error handling** templates and debugging tips
- **Performance optimization** guidelines

### 📊 Stage Monitoring System

See `examples/stage_monitoring_demo.py` for comprehensive monitoring:

```bash
python agent_framework/examples/stage_monitoring_demo.py
```

Features demonstrated:
- **Real-time stage state tracking** (PENDING → STARTED → RUNNING → COMPLETED/ERROR)
- **Custom observers** for dashboards, webhooks, and metrics
- **Performance monitoring** with detailed statistics
- **Error detection and alerting** system
- **Workflow-level monitoring** and reporting

### 🎛️ Simple Monitoring API

See `examples/monitoring_api_demo.py` for easy integration:

```bash
python agent_framework/examples/monitoring_api_demo.py
```

Simple one-line setup:
```python
from agent_sdk.core.state import configure_monitoring, get_workflow_status

# Easy setup
monitor = configure_monitoring(enable_logging=True, enable_metrics=True)

# Get status
status = get_workflow_status("my_workflow")
print(f"Status: {status['status']}, Progress: {status['completed']}/{status['total_stages']}")
```

### 💳 Payment Processing Demo

See `demo/payment_processor.py` for a complete example of building a payment processing system:

```python
from agent_framework.demo import PaymentProcessor

processor = PaymentProcessor()
result = processor.process_payment("Pay €1000 to IBAN DE89 3704 0044 0532 0130 00")

print(f"Needs review: {result.get('needs_review')}")
print(f"Actions: {result.get('executed_actions')}")
```

### ⚡ Async Payment Processing

See `demo/async_payment_processor.py` for async processing with concurrent stages:

```python
import asyncio
from agent_framework.demo import AsyncPaymentProcessor

async def main():
    processor = AsyncPaymentProcessor()
    result = await processor.process_payment_async("Pay €1000 to IBAN DE89...")
    print(f"Risk score: {result.get('risk_score')}")

asyncio.run(main())
```

## Development

### Setup Development Environment

```bash
# Clone repository
git clone <repository-url>
cd agent-framework

# Install in development mode
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=agent_sdk

# Run only async tests
pytest -m asyncio

# Run specific test file
pytest test/test_core.py
```

### Code Quality

```bash
# Format code
black agent_sdk/ demo/ test/

# Lint code
flake8 agent_sdk/ demo/ test/

# Type checking
mypy agent_sdk/
```

## Execution Modes Comparison

| Feature | Simple Async | Prefect Sync | Prefect Async |
|---------|-------------|--------------|---------------|
| **Function** | `agentic_spine_async()` | `agentic_spine()` | `agentic_spine_async_prefect()` |
| **Async Support** | ✅ Native | ❌ Sync only | ✅ Full async |
| **Prefect Integration** | ❌ None | ✅ Tasks & Flows | ✅ Async Tasks & Flows |
| **Concurrent Execution** | ✅ asyncio.gather | ✅ Prefect futures | ✅ Async + Prefect |
| **Performance** | 🚀 Fastest | ⚡ Good | ⚡ Good (with overhead) |
| **Monitoring** | ❌ Basic logging | ✅ Full Prefect UI | ✅ Full Prefect UI |
| **Error Handling** | ✅ Basic | ✅ Advanced | ✅ Advanced |
| **Scalability** | ✅ Good | ✅ Excellent | ✅ Excellent |
| **Use Case** | Simple workflows | Production systems | Complex async systems |

## Agent Framework & Dynamic Configuration

### 🏗️ Agent Factory Pattern

The framework provides multiple agent types through a factory pattern:

```python
from agent_sdk.agent import create_simple_sync_agent, create_prefect_async_agent

# Simple synchronous agent
sync_agent = create_simple_sync_agent(
    functions=[perceive_func, reason_func],
    workflow_id="sync_workflow"
)

# Advanced async Prefect agent
async_agent = create_prefect_async_agent(
    functions=[async_perceive, async_reason],
    concurrent={Stage.PERCEIVE: True},
    workflow_id="async_workflow"
)
```

### 🔗 Dynamic Configuration System

**Runtime Function Override:**
```python
# Override functions at execution time
dynamic_input = {
    "input": "test_data",
    "functions": ["mymodule.perceive_func", "mymodule.reason_func"],  # String references
    "concurrent": {"PERCEIVE": True, "REASON": False}  # Runtime concurrency
}

result = agent.execute(dynamic_input)
```

**String Function Resolution:**
- **Module.Function Format**: `"mymodule.my_function"`
- **Cross-Module Support**: Import from any accessible module
- **Smart Resolution**: Tries multiple import strategies
- **Error Handling**: Clear messages for invalid references

**Mixed Format Support:**
```python
# Combine callable objects and string references
mixed_functions = [
    my_callable_func,           # Direct callable
    "module.string_func",       # String reference
    another_callable_func       # Another callable
]
```

### 🏗️ Custom Agent Extensions

Create enhanced agents by extending base classes:

```python
from agent_sdk.agent.base_agent import BaseAgent

class EnhancedAgent(BaseAgent):
    def __init__(self, enable_metrics=True, max_execution_time=None, **kwargs):
        super().__init__(**kwargs)
        self.enable_metrics = enable_metrics
        self.max_execution_time = max_execution_time
        self.execution_metrics = {}
    
    def execute(self, input_data):
        # Add custom pre-execution logic
        start_time = time.time()
        
        # Execute with base agent logic
        result = super().execute(input_data)
        
        # Add custom post-execution logic
        if self.enable_metrics:
            self.execution_metrics = {
                "execution_time": time.time() - start_time,
                "success": True,
                "function_count": len(self._functions)
            }
        
        return result
    
    def get_execution_metrics(self):
        return self.execution_metrics.copy()
```

## Custom Decorators Guide

### `stage_decorator(stage: Stage)`
- **Flexible**: Works with both sync and async functions
- **Auto-detection**: Automatically detects function type
- **Migration-friendly**: Perfect for gradual async adoption
- **Logging**: Adds automatic execution logging

### `async_stage(stage: Stage)`
- **Type-safe**: Enforces async-only functions
- **Error prevention**: Raises `ValueError` for sync functions
- **Consistency**: Ensures uniform async patterns
- **Performance**: Optimized for async workflows

## Stage Monitoring System

### 🔍 **Real-time State Tracking**
Every stage execution goes through these states:
```
PENDING → STARTED → RUNNING → COMPLETED/ERROR/CANCELLED
```

### 📊 **Built-in Observers**
- **LoggingObserver**: Real-time console output with emojis
- **MetricsObserver**: Performance statistics and success rates
- **Custom Observers**: Build your own monitoring dashboards

### 🎛️ **Simple API**
```python
from agent_sdk.core.state import configure_monitoring, get_workflow_status, get_metrics

# One-line setup
configure_monitoring(enable_logging=True, enable_metrics=True)

# Get workflow status
status = get_workflow_status("my_workflow")
# Returns: {"status": "completed", "completed": 4, "total_stages": 4, "duration": 1.23}

# Get performance metrics
metrics = get_metrics()
# Returns: {"total_executions": 10, "success_rate": 95.0, "average_durations": {...}}
```

### 🚨 **Error Detection & Alerting**
- Automatic error capture and reporting
- Performance alerts for long-running stages
- Configurable alert thresholds
- Webhook integration for external systems

## Project Structure

```
agent_framework/
├── agent_sdk/              # Core SDK
│   ├── core/               # Core framework components
│   │   ├── stages.py       # Stage definitions and decorators
│   │   ├── spine.py        # Main workflow execution engine
│   │   ├── context.py      # Context management
│   │   ├── decorators.py   # Custom decorators
│   │   └── state/          # State management and monitoring
│   ├── tools/              # Comprehensive tools system (NEW)
│   │   ├── __init__.py     # Tools exports
│   │   ├── base.py         # Base tool classes and registry
│   │   ├── hooks.py        # @tool_hook decorator system
│   │   ├── config.py       # Configuration management
│   │   ├── llm.py          # LLM tools (OpenAI, Gemini, etc.)
│   │   ├── database.py     # Database tools (PostgreSQL, Neo4j, etc.)
│   │   ├── api.py          # HTTP and REST API tools
│   │   └── utils.py        # Utility tools (File, Email, Slack)
│   └── utils/              # Utility modules
│       └── logging.py      # Logging utilities
├── examples/               # Example implementations (NEW)
│   ├── decorators_simple_demo.py      # Simple decorators demo
│   ├── decorators_usage_demo.py       # Comprehensive demo
│   ├── decorators_quick_reference.py  # Quick reference guide
│   ├── async_prefect_demo.py          # Async Prefect integration
│   ├── stage_monitoring_demo.py       # Comprehensive monitoring demo
│   ├── monitoring_api_demo.py         # Simple monitoring API
│   ├── tools_basic_demo.py            # Basic tools system demo
│   ├── tools_system_demo.py           # Comprehensive tools demo
│   ├── tools_working_demo.py          # Working tools demonstration
│   ├── tools_prefect_integration_demo.py  # Prefect + Tools integration
│   ├── string_resolution_demo.py      # String function resolution demo (NEW)
│   ├── dynamic_config_example.py      # Dynamic configuration examples (NEW)
│   ├── custom_agent_example.py        # Custom agent extensions (NEW)
│   ├── agent_usage_example.py         # Agent factory usage examples (NEW)
│   └── prefect_vs_simple.py           # Performance comparison
├── config/                 # Configuration files (NEW)
│   └── tools.yaml          # Tools configuration
├── demo/                   # Legacy examples
│   ├── payment_processor.py           # Sync payment processing demo
│   └── async_payment_processor.py     # Async payment processing demo
├── test/                   # Test suite
│   ├── test_core.py        # Core functionality tests
│   ├── test_demo.py        # Demo implementation tests
│   └── conftest.py         # Pytest configuration
├── .env.example           # Environment variables template (NEW)
├── INSTALL.md             # Detailed installation guide (NEW)
├── verify_setup.py        # Setup verification script (NEW)
├── requirements.txt        # Dependencies (UPDATED)
├── pyproject.toml         # Project configuration (UPDATED)
└── README.md              # This file
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass (`pytest`)
6. Format code (`black .`)
7. Commit changes (`git commit -m 'Add amazing feature'`)
8. Push to branch (`git push origin feature/amazing-feature`)
9. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## API Reference

### Core Functions

```python
# Simple async execution
agentic_spine_async(input_data, functions, initial_context=None, concurrent=None)

# Prefect sync execution  
agentic_spine(input_data, functions, initial_context=None, concurrent=None)

# Prefect async execution (NEW)
agentic_spine_async_prefect(input_data, functions, initial_context=None, concurrent=None)

# Simple sync execution
agentic_spine_simple(input_data, functions, initial_context=None, concurrent=None)
```

### Custom Decorators

```python
# Flexible decorator factory
stage_decorator(stage: Stage) -> Callable

# Async-only decorator factory  
async_stage(stage: Stage) -> Callable

# Built-in stage decorators
@perceive  # Stage.PERCEIVE
@reason    # Stage.REASON  
@plan      # Stage.PLAN
@act       # Stage.ACT
```

### Context Management

```python
# Immutable context operations
Context(data: dict)
ctx.with_data(**kwargs) -> Context
ctx.get(key, default=None) -> Any
merge_context(ctx: Context, data: dict) -> Context
```

## Performance Tips

1. **Choose the right execution mode**:
   - Use `agentic_spine_async()` for simple, fast workflows
   - Use `agentic_spine_async_prefect()` for complex async systems
   - Use `agentic_spine()` for production systems with monitoring needs

2. **Optimize concurrency**:
   ```python
   concurrent={
       Stage.PERCEIVE: True,   # I/O-heavy tasks benefit from concurrency
       Stage.REASON: False,    # CPU-heavy tasks may not benefit
       Stage.PLAN: True,       # Planning often involves external calls
       Stage.ACT: True         # Actions are often independent
   }
   ```

3. **Use appropriate decorators**:
   - Use `stage_decorator()` for flexibility during development
   - Use `async_stage()` for type safety in production async systems

4. **Prefect optimization**:
   ```python
   from prefect.cache_policies import NONE as NO_CACHE
   
   @task(name="my_task", cache_policy=NO_CACHE)  # Disable caching for better performance
   async def my_async_task(ctx: dict) -> dict:
       return await process_data(ctx)
   ```

## Changelog

### v0.2.1 (Dynamic Configuration & Agent Extensions)

- **🔗 NEW**: Dynamic function configuration via input data
- **📝 NEW**: String function resolution - use `"module.function"` format
- **🔄 NEW**: Mixed format support - combine callables and strings
- **🌐 NEW**: Cross-module function references with smart import resolution
- **⚙️ NEW**: Runtime concurrency override through input data
- **🏗️ NEW**: Custom agent classes with enhanced features
- **📊 NEW**: Built-in execution metrics and performance tracking
- **🔧 NEW**: Enhanced fluent interface for agent configuration
- **🎯 NEW**: Agent factory pattern with multiple agent types
- **📚 NEW**: Comprehensive examples for all new features
- **🔄 IMPROVED**: Backward compatibility maintained for all existing code
- **✅ ADDED**: Extensive test coverage for dynamic configuration
- **📖 UPDATED**: Complete documentation with usage examples

### v0.2.0 (Async Prefect Integration, Monitoring & Tools System)

- **🚀 NEW**: Full async Prefect integration with `agentic_spine_async_prefect()`
- **🎯 NEW**: Custom decorators - `stage_decorator()` and `async_stage()`
- **📊 NEW**: Comprehensive stage monitoring system with real-time state tracking
- **🔍 NEW**: Built-in observers for logging, metrics, and custom dashboards
- **🚨 NEW**: Error detection and alerting system
- **🔧 NEW**: Comprehensive tools system with hooks integration
- **🤖 NEW**: LLM tools (OpenAI, Gemini, Mistral, Anthropic)
- **💾 NEW**: Database tools (PostgreSQL, Neo4j, MongoDB)
- **🌐 NEW**: API tools (HTTP client, REST API with pagination)
- **📁 NEW**: Utility tools (File operations, Email, Slack)
- **⚙️ NEW**: YAML and .env configuration system
- **🔗 NEW**: Prefect + Tools integration with triple decorator pattern
- **📚 NEW**: Comprehensive examples and documentation
- **⚡ IMPROVED**: Better async task detection and execution
- **🔧 FIXED**: Async function wrapping issues in Prefect tasks
- **✅ ADDED**: Extensive test coverage for async workflows
- **📖 UPDATED**: Complete documentation with performance comparisons

**🎉 Major Achievement**: Complete production-ready platform combining agentic workflows, Prefect orchestration, and comprehensive tools integration!

### v0.1.0 (Initial Release)

- Core agentic workflow framework
- Sync and async execution support
- Stage-based architecture (PERCEIVE/REASON/PLAN/ACT)
- Immutable context management
- Concurrent execution capabilities
- Comprehensive test suite
- Payment processing demos
- Full type safety and documentation

---

## 🚀 **Complete AI Platform Ready!**

The Agent SDK now provides a **comprehensive, production-ready platform** for building sophisticated AI applications:

### 🎯 **Three-Layer Architecture**
1. **🧠 Agentic Workflows**: Structured PERCEIVE → REASON → PLAN → ACT stages
2. **🔧 Prefect Orchestration**: Task scheduling, monitoring, retries, and scalability
3. **🛠️ Tools Integration**: LLMs, databases, APIs, and utilities with unified interface

### 🔥 **Key Capabilities**
- ✅ **AI-Powered Workflows**: Integrate any LLM provider with simple `@tool_hook`
- ✅ **Production Orchestration**: Full Prefect integration with monitoring and retries
- ✅ **External Integrations**: Databases, APIs, notifications, and file operations
- ✅ **Concurrent Execution**: Parallel processing at both task and tool levels
- ✅ **Configuration Management**: YAML + environment variables for easy deployment
- ✅ **Error Handling**: Graceful degradation and fallback strategies
- ✅ **Full Observability**: Comprehensive logging, monitoring, and state tracking

### 🎉 **Perfect For**
- **🤖 AI Applications**: LLM-powered workflows with external data integration
- **📊 Data Pipelines**: ETL processes with AI analysis and smart routing
- **🔄 Automation Systems**: Intelligent workflows with decision-making capabilities
- **🏢 Enterprise Solutions**: Scalable, monitored, and fault-tolerant AI systems
- **🔗 Dynamic Workflows**: Runtime function configuration and cross-module integration
- **🏗️ Custom Agents**: Extended functionality with metrics, validation, and enhanced features

### 🚀 **Latest Enhancements (v0.2.1)**

**🔗 Dynamic Configuration Revolution:**
- **String Function References**: No more import hassles - use `"module.function"` strings
- **Runtime Override**: Change functions and concurrency per execution
- **Cross-Module Magic**: Reference functions from any accessible module
- **Mixed Format Freedom**: Combine callables and strings seamlessly

**🏗️ Agent Framework Power:**
- **Multiple Agent Types**: Choose from 4 different execution strategies
- **Custom Extensions**: Build enhanced agents with metrics and validation
- **Factory Pattern**: Consistent agent creation with type safety
- **Fluent Interface**: Elegant method chaining for configuration

**🔄 Backward Compatibility Promise:**
- **Zero Breaking Changes**: All existing code continues to work
- **Gradual Migration**: Adopt new features at your own pace
- **Future-Proof**: Built for extensibility and long-term stability

**Ready to build the future of AI applications! 🚀**