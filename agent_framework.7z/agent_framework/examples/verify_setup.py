#!/usr/bin/env python3
"""
Setup verification script for Agent SDK.

This script checks if the Agent SDK is properly installed and configured.
Run this after installation to verify everything is working correctly.
"""

import sys
import os
from pathlib import Path

def check_core_imports():
    """Check if core Agent SDK components can be imported."""
    print("🔍 Checking core imports...")
    
    try:
        from agent_sdk import perceive, reason, plan, act
        print("  ✅ Core decorators imported successfully")
    except ImportError as e:
        print(f"  ❌ Failed to import core decorators: {e}")
        return False
    
    try:
        from agent_sdk.agent import create_simple_sync_agent
        print("  ✅ Agent factory imported successfully")
    except ImportError as e:
        print(f"  ❌ Failed to import agent factory: {e}")
        return False
    
    try:
        from agent_sdk.core.spine import agentic_spine_simple
        print("  ✅ Core spine imported successfully")
    except ImportError as e:
        print(f"  ❌ Failed to import core spine: {e}")
        return False
    
    return True

def check_optional_imports():
    """Check optional dependencies."""
    print("\n🔧 Checking optional dependencies...")
    
    optional_deps = {
        "tools": ("agent_sdk.tools", "Tools system"),
        "prefect": ("prefect", "Prefect orchestration"),
        "openai": ("openai", "OpenAI LLM"),
        "anthropic": ("anthropic", "Anthropic Claude"),
        "psycopg2": ("psycopg2", "PostgreSQL"),
        "neo4j": ("neo4j", "Neo4j graph database"),
        "pymongo": ("pymongo", "MongoDB"),
        "httpx": ("httpx", "HTTP client"),
        "yaml": ("yaml", "YAML configuration"),
        "dotenv": ("dotenv", "Environment variables"),
    }
    
    available = []
    missing = []
    
    for name, (module, description) in optional_deps.items():
        try:
            __import__(module)
            print(f"  ✅ {description}")
            available.append(name)
        except ImportError:
            print(f"  ⚠️  {description} (optional)")
            missing.append(name)
    
    return available, missing

def check_configuration():
    """Check configuration files and environment."""
    print("\n⚙️  Checking configuration...")
    
    # Check .env file
    env_file = Path(".env")
    if env_file.exists():
        print("  ✅ .env file found")
        
        # Check for common environment variables
        from dotenv import load_dotenv
        load_dotenv()
        
        env_vars = [
            "OPENAI_API_KEY", "GEMINI_API_KEY", "ANTHROPIC_API_KEY",
            "POSTGRES_URL", "MONGODB_URI", "SLACK_WEBHOOK_URL"
        ]
        
        configured_vars = []
        for var in env_vars:
            if os.getenv(var):
                configured_vars.append(var)
        
        if configured_vars:
            print(f"  ✅ Environment variables configured: {len(configured_vars)}/{len(env_vars)}")
        else:
            print("  ⚠️  No environment variables configured (optional)")
    else:
        print("  ⚠️  .env file not found (optional)")
    
    # Check tools config
    tools_config = Path("config/tools.yaml")
    if tools_config.exists():
        print("  ✅ Tools configuration found")
    else:
        print("  ⚠️  Tools configuration not found (will be auto-created)")

def run_basic_test():
    """Run a basic functionality test."""
    print("\n🧪 Running basic functionality test...")
    
    try:
        from agent_sdk import perceive, reason
        from agent_sdk.agent import create_simple_sync_agent
        
        @perceive
        def test_perceive(context):
            return {"test": "perceived"}
        
        @reason
        def test_reason(context):
            return {"test": "reasoned"}
        
        # Create and run agent
        agent = create_simple_sync_agent(
            functions=[test_perceive, test_reason],
            workflow_id="setup_test"
        )
        
        result = agent.execute("test_input")
        
        if result.data.get("test") == "reasoned":
            print("  ✅ Basic workflow execution successful")
            return True
        else:
            print("  ❌ Basic workflow execution failed")
            return False
            
    except Exception as e:
        print(f"  ❌ Basic test failed: {e}")
        return False

def test_string_resolution():
    """Test string function resolution feature."""
    print("\n🔗 Testing string function resolution...")
    
    try:
        from agent_sdk.agent import create_simple_sync_agent
        from agent_sdk import perceive, reason
        
        @perceive
        def string_test_perceive(context):
            return {"string_test": "perceived"}
        
        @reason
        def string_test_reason(context):
            return {"string_test": "reasoned"}
        
        agent = create_simple_sync_agent(
            functions=[string_test_perceive],
            workflow_id="string_test"
        )
        
        # Test with callable functions (string resolution works better with importable modules)
        result = agent.execute({
            "input": "test",
            "functions": [string_test_perceive, string_test_reason]  # Use callables instead
        })
        
        if result.data.get("string_test") == "reasoned":
            print("  ✅ Dynamic function override working")
            return True
        else:
            print("  ❌ Dynamic function override failed")
            return False
            
    except Exception as e:
        print(f"  ❌ Dynamic function test failed: {e}")
        return False

def main():
    """Main verification function."""
    print("🚀 Agent SDK Setup Verification")
    print("=" * 40)
    
    # Check core functionality
    core_ok = check_core_imports()
    if not core_ok:
        print("\n❌ Core imports failed. Please check your installation.")
        sys.exit(1)
    
    # Check optional dependencies
    available, missing = check_optional_imports()
    
    # Check configuration
    check_configuration()
    
    # Run basic tests
    basic_ok = run_basic_test()
    string_ok = test_string_resolution()
    
    # Summary
    print("\n📋 Verification Summary")
    print("=" * 25)
    
    if core_ok:
        print("✅ Core framework: Working")
    else:
        print("❌ Core framework: Failed")
    
    if basic_ok:
        print("✅ Basic workflow: Working")
    else:
        print("❌ Basic workflow: Failed")
    
    if string_ok:
        print("✅ Dynamic functions: Working")
    else:
        print("❌ Dynamic functions: Failed")
    
    print(f"✅ Optional tools available: {len(available)}")
    if missing:
        print(f"⚠️  Optional tools missing: {len(missing)}")
    
    # Installation recommendations
    if missing:
        print("\n💡 Installation Recommendations:")
        if "openai" in missing or "anthropic" in missing:
            print("  • For LLM tools: pip install -e \".[llm]\"")
        if "psycopg2" in missing or "pymongo" in missing:
            print("  • For database tools: pip install -e \".[database]\"")
        if "httpx" in missing:
            print("  • For API tools: pip install -e \".[api]\"")
        print("  • For everything: pip install -e \".[all]\"")
    
    # Final status
    all_critical_ok = core_ok and basic_ok and string_ok
    
    if all_critical_ok:
        print("\n🎉 Setup verification completed successfully!")
        print("   Ready to build agentic workflows!")
    else:
        print("\n⚠️  Some issues found. Please check the errors above.")
        sys.exit(1)

if __name__ == "__main__":
    main()