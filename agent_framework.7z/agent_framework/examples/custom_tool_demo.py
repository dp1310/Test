#!/usr/bin/env python3
"""
Custom Tool Creation and Execution Demo

This example demonstrates how to:
1. Create custom tools by extending the base Tool class
2. Register custom tools with the tool registry
3. Use the @tool_hook decorator to access tools in workflows
4. Execute custom tools within agentic workflows

The demo includes:
- A custom weather tool that simulates weather data
- A custom calculator tool with advanced operations
- A custom notification tool for alerts
- Integration with agentic workflows using @tool_hook
"""

import sys
import os
import asyncio
import time
import random
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import perceive, reason, plan, act, agentic_spine_async, Context, get_logger, setup_logging
from agent_sdk.tools import Tool, ToolResult, ToolError, tool_hook
from agent_sdk.tools.base import ToolStatus, get_tool_registry

# Setup logging
setup_logging(level="INFO")

logger = get_logger(__name__)


# ============================================================================
# CUSTOM TOOL IMPLEMENTATIONS
# ============================================================================

class WeatherTool(Tool):
    """Custom weather tool that simulates weather data retrieval."""
    
    def __init__(self, name: str, config: Dict[str, Any] = None):
        super().__init__(name, config or {})
        self.api_key = config.get('api_key', 'demo_key') if config else 'demo_key'
        self.default_location = config.get('default_location', 'New York') if config else 'New York'
    
    async def execute(self, location: str = None, units: str = "celsius", **kwargs) -> ToolResult:
        """
        Get weather data for a location.
        
        Args:
            location: Location to get weather for
            units: Temperature units (celsius/fahrenheit)
            **kwargs: Additional parameters
            
        Returns:
            ToolResult with weather data
        """
        try:
            location = location or self.default_location
            
            # Simulate API call delay
            await asyncio.sleep(0.1)
            
            # Generate realistic weather data
            temp_c = random.randint(-10, 35)
            temp_f = (temp_c * 9/5) + 32
            
            conditions = random.choice([
                "sunny", "cloudy", "rainy", "snowy", "foggy", "windy"
            ])
            
            humidity = random.randint(30, 90)
            wind_speed = random.randint(0, 25)
            
            weather_data = {
                "location": location,
                "temperature": {
                    "celsius": temp_c,
                    "fahrenheit": round(temp_f, 1),
                    "display": f"{temp_c}°C" if units == "celsius" else f"{temp_f:.1f}°F"
                },
                "conditions": conditions,
                "humidity": f"{humidity}%",
                "wind_speed": f"{wind_speed} km/h",
                "timestamp": time.time(),
                "source": "WeatherTool Simulator"
            }
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=weather_data
            )
            
        except Exception as e:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"Weather tool error: {e}", self.name, e)
            )
    
    def get_schema(self) -> Dict[str, Any]:
        """Get weather tool schema."""
        return {
            "name": self.name,
            "description": "Get weather information for any location",
            "parameters": {
                "location": {
                    "type": "string",
                    "description": "Location to get weather for",
                    "required": False,
                    "default": self.default_location
                },
                "units": {
                    "type": "string",
                    "description": "Temperature units",
                    "enum": ["celsius", "fahrenheit"],
                    "default": "celsius"
                }
            },
            "examples": [
                {
                    "location": "London",
                    "units": "celsius"
                },
                {
                    "location": "Tokyo",
                    "units": "fahrenheit"
                }
            ]
        }


class AdvancedCalculatorTool(Tool):
    """Custom calculator tool with advanced mathematical operations."""
    
    def __init__(self, name: str, config: Dict[str, Any] = None):
        super().__init__(name, config or {})
        self.precision = config.get('precision', 4) if config else 4
        self.max_operations = config.get('max_operations', 100) if config else 100
        self.operation_count = 0
    
    async def execute(self, operation: str, **kwargs) -> ToolResult:
        """
        Perform advanced mathematical operations.
        
        Args:
            operation: Mathematical operation to perform
            **kwargs: Additional parameters
            
        Returns:
            ToolResult with calculation result
        """
        try:
            if self.operation_count >= self.max_operations:
                raise ToolError("Maximum operations limit reached", self.name)
            
            self.operation_count += 1
            
            # Simulate processing time for complex operations
            await asyncio.sleep(0.05)
            
            # Parse and evaluate the operation safely
            result = self._safe_eval(operation)
            
            # Round to specified precision
            if isinstance(result, float):
                result = round(result, self.precision)
            
            calculation_data = {
                "operation": operation,
                "result": result,
                "precision": self.precision,
                "operation_count": self.operation_count,
                "timestamp": time.time()
            }
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=calculation_data
            )
            
        except Exception as e:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"Calculator error: {e}", self.name, e)
            )
    
    def _safe_eval(self, expression: str) -> float:
        """Safely evaluate mathematical expressions."""
        import math
        
        # Define allowed operations
        allowed_names = {
            "abs": abs, "round": round, "min": min, "max": max,
            "sum": sum, "pow": pow, "sqrt": math.sqrt, "sin": math.sin,
            "cos": math.cos, "tan": math.tan, "log": math.log,
            "pi": math.pi, "e": math.e
        }
        
        # Remove any potentially dangerous operations
        expression = expression.replace("__", "").replace("import", "")
        
        try:
            # Use eval with restricted globals
            result = eval(expression, {"__builtins__": {}}, allowed_names)
            return result
        except Exception as e:
            raise ValueError(f"Invalid mathematical expression: {expression}")
    
    def get_schema(self) -> Dict[str, Any]:
        """Get calculator tool schema."""
        return {
            "name": self.name,
            "description": "Advanced calculator for mathematical operations",
            "parameters": {
                "operation": {
                    "type": "string",
                    "description": "Mathematical expression to evaluate",
                    "required": True
                }
            },
            "examples": [
                {"operation": "2 + 3 * 4"},
                {"operation": "sqrt(16) + pow(2, 3)"},
                {"operation": "sin(pi/2) + cos(0)"}
            ]
        }


class NotificationTool(Tool):
    """Custom notification tool for sending alerts and messages."""
    
    def __init__(self, name: str, config: Dict[str, Any] = None):
        super().__init__(name, config or {})
        self.default_channel = config.get('default_channel', 'console') if config else 'console'
        self.notification_history = []
    
    async def execute(self, message: str, channel: str = None, priority: str = "normal", **kwargs) -> ToolResult:
        """
        Send a notification message.
        
        Args:
            message: Message to send
            channel: Channel to send to (console, email, slack)
            priority: Message priority (low, normal, high, urgent)
            **kwargs: Additional parameters
            
        Returns:
            ToolResult with notification status
        """
        try:
            channel = channel or self.default_channel
            
            # Simulate sending delay based on channel
            channel_delays = {
                "console": 0.01,
                "email": 0.2,
                "slack": 0.1,
                "sms": 0.3
            }
            
            await asyncio.sleep(channel_delays.get(channel, 0.1))
            
            # Create notification record
            notification = {
                "message": message,
                "channel": channel,
                "priority": priority,
                "timestamp": time.time(),
                "status": "sent",
                "id": len(self.notification_history) + 1
            }
            
            # Store in history
            self.notification_history.append(notification)
            
            # Actually send the notification (simulate)
            self._send_notification(notification)
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data={
                    "notification": notification,
                    "total_sent": len(self.notification_history)
                }
            )
            
        except Exception as e:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"Notification error: {e}", self.name, e)
            )
    
    def _send_notification(self, notification: Dict[str, Any]):
        """Actually send the notification (simulated)."""
        priority_icons = {
            "low": "ℹ️",
            "normal": "📢",
            "high": "⚠️",
            "urgent": "🚨"
        }
        
        icon = priority_icons.get(notification["priority"], "📢")
        channel = notification["channel"].upper()
        
        print(f"{icon} [{channel}] {notification['message']}")
    
    def get_schema(self) -> Dict[str, Any]:
        """Get notification tool schema."""
        return {
            "name": self.name,
            "description": "Send notifications through various channels",
            "parameters": {
                "message": {
                    "type": "string",
                    "description": "Message to send",
                    "required": True
                },
                "channel": {
                    "type": "string",
                    "description": "Channel to send notification",
                    "enum": ["console", "email", "slack", "sms"],
                    "default": self.default_channel
                },
                "priority": {
                    "type": "string",
                    "description": "Message priority level",
                    "enum": ["low", "normal", "high", "urgent"],
                    "default": "normal"
                }
            },
            "examples": [
                {
                    "message": "Task completed successfully",
                    "channel": "console",
                    "priority": "normal"
                },
                {
                    "message": "Critical error detected!",
                    "channel": "slack",
                    "priority": "urgent"
                }
            ]
        }


# ============================================================================
# TOOL REGISTRATION AND SETUP
# ============================================================================

def setup_custom_tools():
    """Register custom tools with the tool registry."""
    logger.info("🔧 Setting up custom tools...")
    
    registry = get_tool_registry()
    
    # Create and register weather tool
    weather_tool = WeatherTool("weather_service", {
        "api_key": "demo_weather_key",
        "default_location": "San Francisco"
    })
    registry.register(weather_tool, "utility")
    
    # Create and register calculator tool
    calc_tool = AdvancedCalculatorTool("advanced_calculator", {
        "precision": 6,
        "max_operations": 1000
    })
    registry.register(calc_tool, "utility")
    
    # Create and register notification tool
    notification_tool = NotificationTool("notification_service", {
        "default_channel": "console"
    })
    registry.register(notification_tool, "communication")
    
    logger.info("✅ Custom tools registered:")
    logger.info(f"   Available tools: {registry.list_tools()}")
    logger.info(f"   Categories: {registry.list_categories()}")


# ============================================================================
# AGENTIC WORKFLOW WITH CUSTOM TOOLS
# ============================================================================

@perceive
@tool_hook
async def gather_environmental_data(ctx: Context, tools) -> Dict[str, Any]:
    """Gather environmental data using custom weather tool."""
    logger.info("🌤️ Gathering environmental data...")
    
    location = ctx.get("input", {}).get("location", "New York")
    
    # Use custom weather tool
    weather_result = await tools.execute(
        'weather_service',
        location=location,
        units="celsius"
    )
    
    if weather_result.is_success:
        weather_data = weather_result.data
        logger.info(f"Weather for {location}: {weather_data['temperature']['display']}, {weather_data['conditions']}")
        
        return {
            "location": location,
            "weather": weather_data,
            "data_quality": "high",
            "collection_timestamp": time.time()
        }
    else:
        logger.warning(f"Weather data collection failed: {weather_result.error}")
        return {
            "location": location,
            "weather": None,
            "data_quality": "low",
            "collection_timestamp": time.time()
        }


@reason
@tool_hook
async def analyze_environmental_conditions(ctx: Context, tools) -> Dict[str, Any]:
    """Analyze environmental conditions and calculate comfort index."""
    logger.info("🧠 Analyzing environmental conditions...")
    
    weather = ctx.get("weather")
    location = ctx.get("location", "Unknown")
    
    if not weather:
        return {
            "analysis": "No weather data available for analysis",
            "comfort_index": 0,
            "recommendations": ["Retry data collection"]
        }
    
    # Use custom calculator for comfort index calculation
    temp_c = weather["temperature"]["celsius"]
    humidity_val = int(weather["humidity"].replace("%", ""))
    
    # Calculate comfort index using advanced calculator
    comfort_formula = f"100 - abs({temp_c} - 22) * 2 - abs({humidity_val} - 50) * 0.5"
    
    calc_result = await tools.execute(
        'advanced_calculator',
        operation=comfort_formula
    )
    
    if calc_result.is_success:
        comfort_index = max(0, min(100, calc_result.data["result"]))
        
        # Determine comfort level
        if comfort_index >= 80:
            comfort_level = "excellent"
            recommendations = ["Perfect conditions for outdoor activities"]
        elif comfort_index >= 60:
            comfort_level = "good"
            recommendations = ["Good conditions with minor adjustments needed"]
        elif comfort_index >= 40:
            comfort_level = "fair"
            recommendations = ["Consider indoor activities or protective measures"]
        else:
            comfort_level = "poor"
            recommendations = ["Stay indoors", "Use climate control if available"]
        
        analysis = f"Weather analysis for {location}: {comfort_level} conditions with {comfort_index:.1f}% comfort index"
        
        return {
            "analysis": analysis,
            "comfort_index": comfort_index,
            "comfort_level": comfort_level,
            "recommendations": recommendations,
            "calculation_details": calc_result.data
        }
    else:
        logger.warning(f"Comfort calculation failed: {calc_result.error}")
        return {
            "analysis": f"Basic analysis for {location}: {weather['conditions']} conditions",
            "comfort_index": 50,  # Default neutral value
            "comfort_level": "unknown",
            "recommendations": ["Manual assessment needed"]
        }


@plan
@tool_hook
async def create_action_plan(ctx: Context, tools) -> Dict[str, Any]:
    """Create action plan based on environmental analysis."""
    logger.info("📋 Creating action plan...")
    
    comfort_level = ctx.get("comfort_level", "unknown")
    recommendations = ctx.get("recommendations", [])
    location = ctx.get("location", "Unknown")
    
    # Create detailed action plan
    actions = []
    
    if comfort_level == "excellent":
        actions.extend([
            "send_positive_notification",
            "schedule_outdoor_activities",
            "share_weather_update"
        ])
    elif comfort_level == "good":
        actions.extend([
            "send_normal_notification",
            "suggest_light_outdoor_activities"
        ])
    elif comfort_level == "fair":
        actions.extend([
            "send_caution_notification",
            "suggest_indoor_alternatives"
        ])
    else:
        actions.extend([
            "send_warning_notification",
            "recommend_staying_indoors"
        ])
    
    # Always include summary action
    actions.append("generate_summary_report")
    
    plan = {
        "location": location,
        "comfort_level": comfort_level,
        "planned_actions": actions,
        "recommendations": recommendations,
        "execution_priority": "high" if comfort_level in ["poor", "excellent"] else "normal",
        "estimated_duration": len(actions) * 0.5
    }
    
    return plan


@act
@tool_hook
async def execute_action_plan(ctx: Context, tools) -> Dict[str, Any]:
    """Execute the action plan using custom notification tool."""
    logger.info("⚡ Executing action plan...")
    
    planned_actions = ctx.get("planned_actions", [])
    comfort_level = ctx.get("comfort_level", "unknown")
    location = ctx.get("location", "Unknown")
    comfort_index = ctx.get("comfort_index", 0)
    
    executed_actions = []
    
    for action in planned_actions:
        try:
            if "notification" in action:
                # Determine notification details
                if "positive" in action:
                    message = f"Excellent weather conditions in {location}! Comfort index: {comfort_index:.1f}%"
                    priority = "normal"
                elif "warning" in action:
                    message = f"Poor weather conditions in {location}. Comfort index: {comfort_index:.1f}%"
                    priority = "urgent"
                elif "caution" in action:
                    message = f"Fair weather conditions in {location}. Take precautions. Comfort index: {comfort_index:.1f}%"
                    priority = "high"
                else:
                    message = f"Weather update for {location}: {comfort_level} conditions"
                    priority = "normal"
                
                # Send notification using custom tool
                notification_result = await tools.execute(
                    'notification_service',
                    message=message,
                    channel="console",
                    priority=priority
                )
                
                if notification_result.is_success:
                    executed_actions.append({
                        "action": action,
                        "status": "completed",
                        "notification_id": notification_result.data["notification"]["id"]
                    })
                else:
                    executed_actions.append({
                        "action": action,
                        "status": "failed",
                        "error": str(notification_result.error)
                    })
            
            elif action == "generate_summary_report":
                # Generate summary using calculator for statistics
                total_actions = len(planned_actions)
                success_rate_calc = f"({len([a for a in executed_actions if a.get('status') == 'completed'])} / {total_actions}) * 100"
                
                calc_result = await tools.execute(
                    'advanced_calculator',
                    operation=success_rate_calc
                )
                
                success_rate = calc_result.data["result"] if calc_result.is_success else 0
                
                summary_message = f"Action plan completed for {location}. Success rate: {success_rate:.1f}%"
                
                summary_result = await tools.execute(
                    'notification_service',
                    message=summary_message,
                    channel="console",
                    priority="low"
                )
                
                executed_actions.append({
                    "action": action,
                    "status": "completed" if summary_result.is_success else "failed",
                    "success_rate": success_rate
                })
            
            else:
                # Simulate other actions
                await asyncio.sleep(0.1)
                executed_actions.append({
                    "action": action,
                    "status": "simulated"
                })
        
        except Exception as e:
            logger.error(f"Error executing action {action}: {e}")
            executed_actions.append({
                "action": action,
                "status": "error",
                "error": str(e)
            })
    
    return {
        "executed_actions": executed_actions,
        "total_actions": len(planned_actions),
        "successful_actions": len([a for a in executed_actions if a.get("status") == "completed"]),
        "execution_complete": True
    }


# ============================================================================
# DEMONSTRATION FUNCTIONS
# ============================================================================

async def demo_custom_tools_direct():
    """Demonstrate direct usage of custom tools."""
    logger.info("\n🎯 DEMO: Direct Custom Tool Usage")
    logger.info("-" * 50)
    
    registry = get_tool_registry()
    
    # Test weather tool directly
    logger.info("Testing weather tool...")
    weather_result = await registry.execute_tool('weather_service', location="Tokyo", units="fahrenheit")
    if weather_result.is_success:
        weather = weather_result.data
        logger.info(f"✅ Weather: {weather['location']} - {weather['temperature']['display']}, {weather['conditions']}")
    
    # Test calculator tool directly
    logger.info("Testing calculator tool...")
    calc_result = await registry.execute_tool('advanced_calculator', operation="sqrt(144) + pow(2, 4)")
    if calc_result.is_success:
        calc = calc_result.data
        logger.info(f"✅ Calculation: {calc['operation']} = {calc['result']}")
    
    # Test notification tool directly
    logger.info("Testing notification tool...")
    notif_result = await registry.execute_tool(
        'notification_service',
        message="Direct tool test completed!",
        priority="high"
    )
    if notif_result.is_success:
        logger.info(f"✅ Notification sent with ID: {notif_result.data['notification']['id']}")


async def demo_custom_tools_workflow():
    """Demonstrate custom tools in agentic workflow."""
    logger.info("\n🎯 DEMO: Custom Tools in Agentic Workflow")
    logger.info("-" * 50)
    
    start_time = time.time()
    
    result = await agentic_spine_async(
        input_data={
            "location": "London"
        },
        functions=[
            gather_environmental_data,
            analyze_environmental_conditions,
            create_action_plan,
            execute_action_plan
        ],
        workflow_id="custom_tools_workflow"
    )
    
    end_time = time.time()
    
    logger.info("✅ Custom tools workflow completed")
    logger.info(f"   Duration: {end_time - start_time:.3f}s")
    logger.info(f"   Location: {result.data.get('location', 'Unknown')}")
    logger.info(f"   Comfort Level: {result.data.get('comfort_level', 'Unknown')}")
    logger.info(f"   Actions Executed: {result.data.get('successful_actions', 0)}/{result.data.get('total_actions', 0)}")
    
    return result


async def demo_tool_error_handling():
    """Demonstrate error handling with custom tools."""
    logger.info("\n💥 DEMO: Custom Tool Error Handling")
    logger.info("-" * 50)
    
    registry = get_tool_registry()
    
    # Test invalid calculator operation
    logger.info("Testing invalid calculator operation...")
    calc_result = await registry.execute_tool('advanced_calculator', operation="invalid_function(123)")
    logger.info(f"Calculator error result: {calc_result.status.value}")
    if calc_result.error:
        logger.info(f"Error message: {str(calc_result.error)}")
    
    # Test notification with invalid parameters
    logger.info("Testing notification with missing message...")
    notif_result = await registry.execute_tool('notification_service', channel="console")
    logger.info(f"Notification error result: {notif_result.status.value}")
    
    logger.info("✅ Error handling demonstration completed")


async def demo_tool_schemas():
    """Demonstrate tool schema inspection."""
    logger.info("\n📋 DEMO: Custom Tool Schemas")
    logger.info("-" * 50)
    
    registry = get_tool_registry()
    
    for tool_name in ['weather_service', 'advanced_calculator', 'notification_service']:
        tool = registry.get_tool(tool_name)
        if tool:
            schema = tool.get_schema()
            logger.info(f"\n🔧 {tool_name.upper()} SCHEMA:")
            logger.info(f"   Description: {schema['description']}")
            logger.info(f"   Parameters: {list(schema['parameters'].keys())}")
            
            if 'examples' in schema:
                logger.info(f"   Examples: {len(schema['examples'])} provided")


# ============================================================================
# MAIN DEMONSTRATION
# ============================================================================

async def main():
    """Main demonstration function."""
    logger.info("Custom Tool Creation and Execution Demo")
    logger.info("=" * 60)
    
    # Setup custom tools
    setup_custom_tools()
    
    # Run demonstrations
    await demo_custom_tools_direct()
    await demo_custom_tools_workflow()
    await demo_tool_error_handling()
    await demo_tool_schemas()
    
    logger.info("\n=== Custom Tool Demo Complete ===")


if __name__ == "__main__":
    asyncio.run(main())