"""Test dynamic configuration functionality."""

import sys
import os
sys.path.append(os.path.dirname(__file__))

from agent_sdk.agent import create_simple_sync_agent
from agent_sdk.core.stages import perceive, reason, plan, act, Stage
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


@perceive
def test_perceive_1(context):
    return {"perceived": "test_1"}


@perceive
def test_perceive_2(context):
    return {"perceived": "test_2"}


@reason
def test_reason(context):
    return {"reasoning": "test_analysis"}


@plan
def test_plan(context):
    return {"plan": "test_plan"}


@act
def test_act(context):
    return {"action": "test_result"}


def test_dynamic_functions():
    """Test dynamic function override."""
    logger.info("Testing dynamic function override...")
    
    # Create agent with one perceive function
    agent = create_simple_sync_agent(
        functions=[test_perceive_1, test_reason],
        workflow_id="dynamic_test"
    )
    
    # Test with dynamic function override
    dynamic_input = {
        "input": "test_data",
        "functions": [test_perceive_2, test_reason, test_plan, test_act]
    }
    
    result = agent.execute(dynamic_input)
    
    # Verify the dynamic function was used
    assert result.data.get("perceived") == "test_2"
    assert result.data.get("action") == "test_result"
    
    logger.info("✅ Dynamic function override test passed!")


def test_dynamic_concurrent():
    """Test dynamic concurrent override."""
    logger.info("Testing dynamic concurrent override...")
    
    agent = create_simple_sync_agent(
        functions=[test_perceive_1, test_reason, test_plan, test_act],
        concurrent={},  # No concurrency by default
        workflow_id="concurrent_test"
    )
    
    # Test with dynamic concurrent override
    dynamic_input = {
        "input": "test_data",
        "concurrent": {
            "PERCEIVE": True,
            "REASON": True
        }
    }
    
    result = agent.execute(dynamic_input)
    
    # Verify execution completed successfully
    assert result.data.get("action") == "test_result"
    
    logger.info("✅ Dynamic concurrent override test passed!")


def test_normal_input_passthrough():
    """Test that normal inputs work without dynamic config."""
    logger.info("Testing normal input passthrough...")
    
    agent = create_simple_sync_agent(
        functions=[test_perceive_1, test_reason, test_plan, test_act],
        workflow_id="passthrough_test"
    )
    
    # Test string input
    result1 = agent.execute("simple_string")
    assert result1.data.get("action") == "test_result"
    
    # Test dict input without dynamic config
    normal_dict = {
        "input": "dict_input",
        "metadata": {"version": "1.0"}
    }
    
    result2 = agent.execute(normal_dict)
    assert result2.data.get("action") == "test_result"
    
    logger.info("✅ Normal input passthrough test passed!")


def test_error_handling():
    """Test error handling for invalid dynamic config."""
    logger.info("Testing error handling...")
    
    agent = create_simple_sync_agent(
        functions=[test_perceive_1, test_reason],
        workflow_id="error_test"
    )
    
    # Test invalid stage name
    try:
        invalid_input = {
            "input": "test",
            "concurrent": {"INVALID_STAGE": True}
        }
        agent.execute(invalid_input)
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "Invalid stage name" in str(e)
        logger.info("✅ Error handling test passed!")


if __name__ == "__main__":
    logger.info("Running Dynamic Configuration Tests")
    logger.info("=" * 40)
    
    try:
        test_dynamic_functions()
        test_dynamic_concurrent()
        test_normal_input_passthrough()
        test_error_handling()
        
        logger.info("\n🎉 All dynamic configuration tests passed!")
        
    except Exception as e:
        logger.error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()