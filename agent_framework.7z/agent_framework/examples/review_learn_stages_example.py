"""Example demonstrating REVIEW and LEARN stages in the agent SDK.

This example shows how to use the new REVIEW and LEARN stages to create
a self-improving agent that evaluates its actions and learns from outcomes.
"""

import sys
import os
import asyncio
from typing import Dict, Any

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, plan, act, review, learn, Stage,
    agentic_spine, agentic_spine_simple, agentic_spine_async,
    Context, get_logger, setup_logging
)
from prefect import task

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


def demo_review_learn_sync():
    """Demo REVIEW and LEARN stages with synchronous execution."""
    logger.info("\n📋 Demo 1: REVIEW and LEARN Stages (Sync)")
    logger.info("-" * 60)
    
    # Define stage functions
    @perceive
    @task(name="analyze_request")
    def analyze_request(ctx: dict) -> dict:
        """Analyze incoming request."""
        request = ctx.get("input", {})
        logger.info(f"[PERCEIVE] Analyzing request: {request}")
        
        return {
            "request_type": request.get("type", "unknown"),
            "complexity": request.get("complexity", "medium"),
            "user_id": request.get("user_id", "anonymous")
        }
    
    @reason
    @task(name="evaluate_approach")
    def evaluate_approach(ctx: dict) -> dict:
        """Reason about the best approach."""
        complexity = ctx.get("complexity", "medium")
        logger.info(f"[REASON] Evaluating approach for complexity: {complexity}")
        
        if complexity == "high":
            approach = "detailed_analysis"
            confidence = 0.7
        elif complexity == "low":
            approach = "quick_response"
            confidence = 0.9
        else:
            approach = "standard_process"
            confidence = 0.8
        
        return {
            "approach": approach,
            "confidence": confidence
        }
    
    @plan
    @task(name="create_action_plan")
    def create_action_plan(ctx: dict) -> dict:
        """Create an action plan."""
        approach = ctx.get("approach", "standard_process")
        logger.info(f"[PLAN] Creating action plan for: {approach}")
        
        plans = {
            "detailed_analysis": ["gather_data", "deep_analysis", "validate_results", "generate_report"],
            "quick_response": ["quick_check", "respond"],
            "standard_process": ["analyze", "process", "respond"]
        }
        
        return {
            "action_steps": plans.get(approach, plans["standard_process"]),
            "estimated_time": len(plans.get(approach, [])) * 10
        }
    
    @act
    @task(name="execute_actions")
    def execute_actions(ctx: dict) -> dict:
        """Execute the planned actions."""
        steps = ctx.get("action_steps", [])
        logger.info(f"[ACT] Executing {len(steps)} action steps")
        
        results = []
        for step in steps:
            result = f"completed_{step}"
            results.append(result)
            logger.info(f"  - Executed: {step}")
        
        return {
            "execution_results": results,
            "execution_status": "completed"
        }
    
    @review
    @task(name="review_execution")
    def review_execution(ctx: dict) -> dict:
        """Review the execution results."""
        logger.info("[REVIEW] Reviewing execution results")
        
        execution_status = ctx.get("execution_status", "unknown")
        confidence = ctx.get("confidence", 0.5)
        results = ctx.get("execution_results", [])
        
        # Evaluate quality
        quality_score = 0.0
        if execution_status == "completed":
            quality_score += 0.5
        if confidence > 0.8:
            quality_score += 0.3
        if len(results) > 0:
            quality_score += 0.2
        
        issues_found = []
        if quality_score < 0.7:
            issues_found.append("low_quality_score")
        if confidence < 0.75:
            issues_found.append("low_confidence")
        
        review_result = {
            "quality_score": quality_score,
            "issues_found": issues_found,
            "review_status": "passed" if quality_score >= 0.7 else "needs_improvement",
            "recommendations": []
        }
        
        if issues_found:
            review_result["recommendations"].append("Consider more detailed analysis")
        
        logger.info(f"  Quality Score: {quality_score:.2f}")
        logger.info(f"  Review Status: {review_result['review_status']}")
        logger.info(f"  Issues Found: {len(issues_found)}")
        
        return review_result
    
    @learn
    @task(name="learn_from_execution")
    def learn_from_execution(ctx: dict) -> dict:
        """Learn from the execution and review."""
        logger.info("[LEARN] Learning from execution")
        
        quality_score = ctx.get("quality_score", 0.0)
        issues = ctx.get("issues_found", [])
        approach = ctx.get("approach", "unknown")
        
        # Generate learnings
        learnings = {
            "approach_effectiveness": quality_score,
            "identified_patterns": [],
            "improvement_suggestions": [],
            "knowledge_updates": {}
        }
        
        # Pattern identification
        if quality_score > 0.8:
            learnings["identified_patterns"].append(f"{approach}_works_well")
        elif quality_score < 0.6:
            learnings["identified_patterns"].append(f"{approach}_needs_improvement")
        
        # Improvement suggestions
        if "low_confidence" in issues:
            learnings["improvement_suggestions"].append("increase_analysis_depth")
        if "low_quality_score" in issues:
            learnings["improvement_suggestions"].append("add_validation_steps")
        
        # Knowledge updates
        learnings["knowledge_updates"][approach] = {
            "success_rate": quality_score,
            "last_execution": "current",
            "recommended": quality_score > 0.7
        }
        
        logger.info(f"  Approach Effectiveness: {quality_score:.2f}")
        logger.info(f"  Patterns Identified: {len(learnings['identified_patterns'])}")
        logger.info(f"  Improvement Suggestions: {len(learnings['improvement_suggestions'])}")
        
        return learnings
    
    # Test cases
    test_cases = [
        {"type": "analysis", "complexity": "high", "user_id": "user_001"},
        {"type": "query", "complexity": "low", "user_id": "user_002"},
        {"type": "processing", "complexity": "medium", "user_id": "user_003"}
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        logger.info(f"\n{'='*60}")
        logger.info(f"Test Case {i}: {test_case}")
        logger.info(f"{'='*60}")
        
        result = agentic_spine(
            input_data=test_case,
            functions=[
                analyze_request,
                evaluate_approach,
                create_action_plan,
                execute_actions,
                review_execution,
                learn_from_execution
            ]
        )
        
        logger.info(f"\n✅ Final Results:")
        logger.info(f"  Approach: {result.get('approach')}")
        logger.info(f"  Quality Score: {result.get('quality_score', 0):.2f}")
        logger.info(f"  Review Status: {result.get('review_status')}")
        logger.info(f"  Learnings: {len(result.get('improvement_suggestions', []))} suggestions")


async def demo_review_learn_async():
    """Demo REVIEW and LEARN stages with asynchronous execution."""
    logger.info("\n📋 Demo 2: REVIEW and LEARN Stages (Async)")
    logger.info("-" * 60)
    
    @perceive
    async def async_analyze(ctx: dict) -> dict:
        """Async perception."""
        await asyncio.sleep(0.1)
        logger.info("[PERCEIVE] Async analysis")
        return {"analyzed": True, "data_points": 100}
    
    @reason
    async def async_reason(ctx: dict) -> dict:
        """Async reasoning."""
        await asyncio.sleep(0.1)
        logger.info("[REASON] Async reasoning")
        return {"decision": "proceed", "confidence": 0.85}
    
    @plan
    async def async_plan(ctx: dict) -> dict:
        """Async planning."""
        await asyncio.sleep(0.1)
        logger.info("[PLAN] Async planning")
        return {"plan": ["step1", "step2", "step3"]}
    
    @act
    async def async_act(ctx: dict) -> dict:
        """Async action."""
        await asyncio.sleep(0.1)
        logger.info("[ACT] Async execution")
        return {"executed": True, "results": ["r1", "r2", "r3"]}
    
    @review
    async def async_review(ctx: dict) -> dict:
        """Async review."""
        await asyncio.sleep(0.1)
        logger.info("[REVIEW] Async review")
        
        confidence = ctx.get("confidence", 0.5)
        executed = ctx.get("executed", False)
        
        quality = 0.9 if executed and confidence > 0.8 else 0.6
        
        return {
            "review_quality": quality,
            "review_passed": quality > 0.7,
            "review_notes": "Async execution successful" if quality > 0.7 else "Needs improvement"
        }
    
    @learn
    async def async_learn(ctx: dict) -> dict:
        """Async learning."""
        await asyncio.sleep(0.1)
        logger.info("[LEARN] Async learning")
        
        quality = ctx.get("review_quality", 0.0)
        
        return {
            "learned_patterns": ["async_pattern_1", "async_pattern_2"],
            "effectiveness": quality,
            "next_steps": ["apply_learnings", "optimize_process"]
        }
    
    result = await agentic_spine_async(
        input_data={"async_test": True},
        functions=[
            async_analyze,
            async_reason,
            async_plan,
            async_act,
            async_review,
            async_learn
        ]
    )
    
    logger.info(f"\n✅ Async Results:")
    logger.info(f"  Review Quality: {result.get('review_quality', 0):.2f}")
    logger.info(f"  Review Passed: {result.get('review_passed')}")
    logger.info(f"  Learned Patterns: {len(result.get('learned_patterns', []))}")
    logger.info(f"  Effectiveness: {result.get('effectiveness', 0):.2f}")


def demo_concurrent_review_learn():
    """Demo concurrent execution in REVIEW and LEARN stages."""
    logger.info("\n📋 Demo 3: Concurrent REVIEW and LEARN")
    logger.info("-" * 60)
    
    @perceive
    @task(name="perceive_data")
    def perceive_data(ctx: dict) -> dict:
        return {"data": "collected"}
    
    @act
    @task(name="execute_task")
    def execute_task(ctx: dict) -> dict:
        return {"task_results": ["result1", "result2", "result3"]}
    
    @review
    @task(name="review_quality")
    def review_quality(ctx: dict) -> dict:
        """Review quality aspects."""
        logger.info("[REVIEW] Checking quality")
        return {"quality_check": "passed", "quality_score": 0.85}
    
    @review
    @task(name="review_performance")
    def review_performance(ctx: dict) -> dict:
        """Review performance aspects."""
        logger.info("[REVIEW] Checking performance")
        return {"performance_check": "passed", "performance_score": 0.90}
    
    @review
    @task(name="review_security")
    def review_security(ctx: dict) -> dict:
        """Review security aspects."""
        logger.info("[REVIEW] Checking security")
        return {"security_check": "passed", "security_score": 0.95}
    
    @learn
    @task(name="learn_quality_patterns")
    def learn_quality_patterns(ctx: dict) -> dict:
        """Learn from quality review."""
        logger.info("[LEARN] Learning quality patterns")
        quality_score = ctx.get("quality_score", 0.0)
        return {"quality_learnings": f"quality_pattern_{quality_score}"}
    
    @learn
    @task(name="learn_performance_patterns")
    def learn_performance_patterns(ctx: dict) -> dict:
        """Learn from performance review."""
        logger.info("[LEARN] Learning performance patterns")
        perf_score = ctx.get("performance_score", 0.0)
        return {"performance_learnings": f"perf_pattern_{perf_score}"}
    
    # Execute with concurrent REVIEW and LEARN stages
    logger.info("Executing with concurrent REVIEW and LEARN stages...")
    result = agentic_spine(
        input_data={"test": "concurrent"},
        functions=[
            perceive_data,
            execute_task,
            review_quality,
            review_performance,
            review_security,
            learn_quality_patterns,
            learn_performance_patterns
        ],
        concurrent={
            Stage.REVIEW: True,  # Run all review tasks concurrently
            Stage.LEARN: True    # Run all learn tasks concurrently
        }
    )
    
    logger.info(f"\n✅ Concurrent Results:")
    logger.info(f"  Quality Check: {result.get('quality_check')}")
    logger.info(f"  Performance Check: {result.get('performance_check')}")
    logger.info(f"  Security Check: {result.get('security_check')}")
    logger.info(f"  Quality Learnings: {result.get('quality_learnings')}")
    logger.info(f"  Performance Learnings: {result.get('performance_learnings')}")


def main():
    """Run all REVIEW and LEARN stage demos."""
    logger.info("🚀 REVIEW and LEARN Stages Demo")
    logger.info("=" * 60)
    
    # Demo 1: Synchronous execution
    demo_review_learn_sync()
    
    # Demo 2: Asynchronous execution
    logger.info("\n" + "=" * 60)
    asyncio.run(demo_review_learn_async())
    
    # Demo 3: Concurrent execution
    logger.info("\n" + "=" * 60)
    demo_concurrent_review_learn()
    
    logger.info("\n" + "=" * 60)
    logger.info("🎉 All REVIEW and LEARN demos completed successfully!")
    logger.info("✅ All 6 stages (PERCEIVE, REASON, PLAN, ACT, REVIEW, LEARN) are working!")


if __name__ == "__main__":
    main()