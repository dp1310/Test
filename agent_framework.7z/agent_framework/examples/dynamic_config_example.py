"""Example demonstrating dynamic configuration of agents at runtime."""

import sys
import os
from typing import Dict, Any

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from agent_sdk.agent import create_simple_sync_agent, create_prefect_sync_agent
from agent_sdk.core.stages import perceive, reason, plan, act, Stage
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging to see output
setup_logging(level="INFO")
logger = get_logger(__name__)


# Define some stage functions for testing
@perceive
def basic_perceive(context: Dict[str, Any]) -> Dict[str, Any]:
    """Basic perception function."""
    input_data = context.get("input", "")
    logger.info(f"Basic perceiving: {input_data}")
    return {"perceived": f"basic_perceived_{input_data}"}


@perceive
def advanced_perceive(context: Dict[str, Any]) -> Dict[str, Any]:
    """Advanced perception function."""
    input_data = context.get("input", "")
    logger.info(f"Advanced perceiving: {input_data}")
    return {"perceived": f"advanced_perceived_{input_data}", "quality": "high"}


@reason
def basic_reason(context: Dict[str, Any]) -> Dict[str, Any]:
    """Basic reasoning function."""
    perceived = context.get("perceived", "")
    logger.info(f"Basic reasoning on: {perceived}")
    return {"reasoning": f"basic_analysis_{perceived}"}


@reason
def advanced_reason(context: Dict[str, Any]) -> Dict[str, Any]:
    """Advanced reasoning function."""
    perceived = context.get("perceived", "")
    quality = context.get("quality", "normal")
    logger.info(f"Advanced reasoning on: {perceived} (quality: {quality})")
    return {"reasoning": f"advanced_analysis_{perceived}", "confidence": 0.9}


@plan
def basic_plan(context: Dict[str, Any]) -> Dict[str, Any]:
    """Basic planning function."""
    reasoning = context.get("reasoning", "")
    logger.info(f"Basic planning based on: {reasoning}")
    return {"plan": f"basic_plan_{reasoning}"}


@act
def basic_act(context: Dict[str, Any]) -> Dict[str, Any]:
    """Basic action function."""
    plan = context.get("plan", "")
    logger.info(f"Basic executing: {plan}")
    return {"result": f"basic_executed_{plan}"}


def demonstrate_static_configuration():
    """Demonstrate normal static configuration."""
    logger.info("\n=== Static Configuration Demo ===")
    
    # Create agent with static configuration
    agent = create_simple_sync_agent(
        functions=[basic_perceive, basic_reason, basic_plan, basic_act],
        concurrent={Stage.PERCEIVE: False, Stage.REASON: False},
        workflow_id="static_demo"
    )
    
    # Execute with simple input
    result = agent.execute("static_test_input")
    logger.info(f"Static result: {result.data.get('result')}")


def demonstrate_dynamic_function_override():
    """Demonstrate dynamic function override at runtime."""
    logger.info("\n=== Dynamic Function Override Demo ===")
    
    # Create agent with basic functions
    agent = create_simple_sync_agent(
        functions=[basic_perceive, basic_reason],
        workflow_id="dynamic_functions_demo"
    )
    
    # Execute with dynamic function override
    dynamic_input = {
        "input": "dynamic_test_input",
        "functions": [advanced_perceive, advanced_reason, basic_plan, basic_act]
    }
    
    result = agent.execute(dynamic_input)
    logger.info(f"Dynamic functions result: {result.data.get('result')}")
    logger.info(f"Quality from advanced perceive: {result.data.get('quality')}")
    logger.info(f"Confidence from advanced reason: {result.data.get('confidence')}")


def demonstrate_dynamic_concurrent_override():
    """Demonstrate dynamic concurrent settings override."""
    logger.info("\n=== Dynamic Concurrent Override Demo ===")
    
    # Create agent with no concurrency
    agent = create_simple_sync_agent(
        functions=[basic_perceive, basic_reason, basic_plan, basic_act],
        concurrent={},  # No concurrency by default
        workflow_id="dynamic_concurrent_demo"
    )
    
    # Execute with dynamic concurrent override
    dynamic_input = {
        "input": "concurrent_test_input",
        "concurrent": {
            "PERCEIVE": True,
            "REASON": True,
            "PLAN": False,
            "ACT": False
        }
    }
    
    result = agent.execute(dynamic_input)
    logger.info(f"Dynamic concurrent result: {result.data.get('result')}")


def demonstrate_combined_dynamic_config():
    """Demonstrate both functions and concurrent overrides together."""
    logger.info("\n=== Combined Dynamic Configuration Demo ===")
    
    # Create minimal agent
    agent = create_simple_sync_agent(
        functions=[basic_perceive, basic_reason],
        workflow_id="combined_dynamic_demo"
    )
    
    # Execute with both function and concurrent overrides
    dynamic_input = {
        "input": "combined_test_input",
        "functions": [advanced_perceive, advanced_reason, basic_plan, basic_act],
        "concurrent": {
            "PERCEIVE": True,
            "REASON": True
        }
    }
    
    result = agent.execute(dynamic_input)
    logger.info(f"Combined dynamic result: {result.data.get('result')}")


def demonstrate_prefect_agent_dynamic_config():
    """Demonstrate dynamic configuration with Prefect agent."""
    logger.info("\n=== Prefect Agent Dynamic Configuration Demo ===")
    
    # Create Prefect agent with basic setup
    agent = create_prefect_sync_agent(
        functions=[basic_perceive, basic_reason],
        workflow_id="prefect_dynamic_demo"
    )
    
    # Execute with dynamic configuration
    dynamic_input = {
        "input": "prefect_dynamic_test",
        "functions": [advanced_perceive, advanced_reason, basic_plan, basic_act],
        "concurrent": {
            "REASON": True,
            "PLAN": True
        }
    }
    
    result = agent.execute(dynamic_input)
    logger.info(f"Prefect dynamic result: {result.data.get('result')}")


def demonstrate_error_handling():
    """Demonstrate error handling for invalid dynamic configuration."""
    logger.info("\n=== Error Handling Demo ===")
    
    agent = create_simple_sync_agent(
        functions=[basic_perceive, basic_reason],
        workflow_id="error_demo"
    )
    
    # Test invalid stage name
    try:
        invalid_input = {
            "input": "error_test",
            "concurrent": {
                "INVALID_STAGE": True  # This should cause an error
            }
        }
        result = agent.execute(invalid_input)
    except ValueError as e:
        logger.info(f"Caught expected error for invalid stage: {e}")
    
    # Test invalid function (this would fail in a real scenario with string functions)
    logger.info("Note: String function resolution requires proper module paths")


def demonstrate_normal_input_passthrough():
    """Demonstrate that normal inputs still work without dynamic config."""
    logger.info("\n=== Normal Input Passthrough Demo ===")
    
    agent = create_simple_sync_agent(
        functions=[basic_perceive, basic_reason, basic_plan, basic_act],
        workflow_id="passthrough_demo"
    )
    
    # Test with string input (no dynamic config)
    result1 = agent.execute("simple_string_input")
    logger.info(f"String input result: {result1.data.get('result')}")
    
    # Test with dict input but no dynamic config keys
    normal_dict_input = {
        "input": "normal_dict_input",
        "metadata": {"version": "1.0"},
        "config": {"debug": True}
    }
    
    result2 = agent.execute(normal_dict_input)
    logger.info(f"Normal dict input result: {result2.data.get('result')}")
    logger.info(f"Metadata preserved: {result2.data.get('metadata')}")
    logger.info(f"Config preserved: {result2.data.get('config')}")


def main():
    """Main demonstration function."""
    logger.info("Dynamic Configuration Example")
    logger.info("=" * 40)
    
    demonstrate_static_configuration()
    demonstrate_dynamic_function_override()
    demonstrate_dynamic_concurrent_override()
    demonstrate_combined_dynamic_config()
    demonstrate_prefect_agent_dynamic_config()
    demonstrate_error_handling()
    demonstrate_normal_input_passthrough()
    
    logger.info("\n=== Dynamic Configuration Demo Complete ===")


if __name__ == "__main__":
    main()