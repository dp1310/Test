"""Example demonstrating custom async agent implementation by extending PrefectAsyncAgent."""

import sys
import os
import time
import asyncio
from typing import Any, Dict, List, Callable, Optional

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from agent_sdk.agent import PrefectAsyncAgent, AgentFactory, AgentType
from agent_sdk.core.stages import perceive, reason, plan, act, Stage
from agent_sdk.core.context import Context
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging to see output
setup_logging(level="INFO")
logger = get_logger(__name__)


class EnhancedPrefectAsyncAgent(PrefectAsyncAgent):
    """
    Custom async agent extending PrefectAsyncAgent with additional features.
    
    This agent adds:
    - Execution timing and metrics
    - Custom validation
    - Enhanced logging
    - Pre/post execution hooks
    - Async-specific optimizations
    """
    
    def __init__(
        self,
        functions: Optional[List[Callable]] = None,
        initial_context: Optional[Dict[str, Any]] = None,
        concurrent: Optional[Dict[Stage, bool]] = None,
        workflow_id: Optional[str] = None,
        enable_metrics: bool = True,
        max_execution_time: Optional[float] = None,
        enable_async_optimizations: bool = True
    ):
        """
        Initialize enhanced async agent with additional configuration.
        
        Args:
            functions: List of stage functions
            initial_context: Initial context data
            concurrent: Stage-level concurrency settings
            workflow_id: Unique identifier for workflow monitoring
            enable_metrics: Whether to collect execution metrics
            max_execution_time: Maximum allowed execution time in seconds
            enable_async_optimizations: Whether to enable async-specific optimizations
        """
        super().__init__(functions, initial_context, concurrent, workflow_id)
        self._enable_metrics = enable_metrics
        self._max_execution_time = max_execution_time
        self._enable_async_optimizations = enable_async_optimizations
        self._execution_metrics = {}
        
        # Add custom validation
        self._validate_custom_configuration()
    
    def _validate_custom_configuration(self) -> None:
        """Validate custom agent configuration."""
        if self._max_execution_time is not None and self._max_execution_time <= 0:
            raise ValueError("max_execution_time must be positive")
        
        # Validate that we have functions for all stages if metrics are enabled
        if self._enable_metrics and self._functions:
            stages_present = set()
            for fn in self._functions:
                stage = getattr(fn, "_agent_stage", None)
                if stage:
                    stages_present.add(stage)
            
            logger.info(f"Async agent configured with stages: {[s.name for s in stages_present]}")
    
    async def _pre_execution_hook(self, input_data: Any) -> None:
        """Hook called before execution starts."""
        logger.info(f"Enhanced async agent starting execution with input: {type(input_data).__name__}")
        
        if self._enable_metrics:
            self._execution_metrics = {
                "start_time": time.time(),
                "input_type": type(input_data).__name__,
                "function_count": len(self._functions),
                "stages": [],
                "async_optimizations": self._enable_async_optimizations
            }
    
    async def _post_execution_hook(self, result: Context) -> None:
        """Hook called after execution completes."""
        if self._enable_metrics:
            end_time = time.time()
            execution_time = end_time - self._execution_metrics["start_time"]
            
            self._execution_metrics.update({
                "end_time": end_time,
                "execution_time": execution_time,
                "result_keys": list(result.data.keys()),
                "success": True
            })
            
            logger.info(f"Enhanced async agent execution completed in {execution_time:.3f}s")
            
            # Check execution time limit
            if (self._max_execution_time is not None and 
                execution_time > self._max_execution_time):
                logger.warning(
                    f"Async execution time {execution_time:.3f}s exceeded limit "
                    f"{self._max_execution_time}s"
                )
    
    async def execute(self, input_data: Any) -> Context:
        """
        Execute the agentic workflow asynchronously with enhanced features.
        
        Args:
            input_data: Input data for the workflow (may contain dynamic configuration)
            
        Returns:
            Final context after all stages
            
        Raises:
            TimeoutError: If execution exceeds max_execution_time
        """
        # Pre-execution hook
        await self._pre_execution_hook(input_data)
        
        try:
            # Apply timeout if specified
            if self._max_execution_time is not None:
                result = await asyncio.wait_for(
                    super().execute(input_data),
                    timeout=self._max_execution_time
                )
            else:
                result = await super().execute(input_data)
            
            # Post-execution hook
            await self._post_execution_hook(result)
            
            return result
            
        except asyncio.TimeoutError:
            error_msg = f"Async execution exceeded timeout of {self._max_execution_time}s"
            if self._enable_metrics:
                self._execution_metrics["success"] = False
                self._execution_metrics["error"] = error_msg
            
            logger.error(f"Enhanced async agent execution timed out: {error_msg}")
            raise TimeoutError(error_msg)
            
        except Exception as e:
            if self._enable_metrics:
                self._execution_metrics["success"] = False
                self._execution_metrics["error"] = str(e)
            
            logger.error(f"Enhanced async agent execution failed: {e}")
            raise
    
    def get_execution_metrics(self) -> Dict[str, Any]:
        """Get execution metrics from the last run."""
        return self._execution_metrics.copy()
    
    def get_execution_type(self) -> str:
        """Get the execution type identifier."""
        return "enhanced_prefect_async"
    
    def set_max_execution_time(self, max_time: float) -> "EnhancedPrefectAsyncAgent":
        """Set maximum execution time (fluent interface)."""
        if max_time <= 0:
            raise ValueError("max_execution_time must be positive")
        self._max_execution_time = max_time
        return self
    
    def enable_metrics(self, enabled: bool = True) -> "EnhancedPrefectAsyncAgent":
        """Enable or disable metrics collection (fluent interface)."""
        self._enable_metrics = enabled
        return self
    
    def enable_async_optimizations(self, enabled: bool = True) -> "EnhancedPrefectAsyncAgent":
        """Enable or disable async optimizations (fluent interface)."""
        self._enable_async_optimizations = enabled
        return self
    
    async def execute_batch(self, input_batch: List[Any]) -> List[Context]:
        """
        Execute multiple workflows concurrently.
        
        Args:
            input_batch: List of input data for concurrent execution
            
        Returns:
            List of final contexts from each execution
        """
        logger.info(f"Executing batch of {len(input_batch)} workflows concurrently")
        
        if self._enable_async_optimizations:
            # Execute all workflows concurrently
            tasks = [self.execute(input_data) for input_data in input_batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Handle any exceptions
            final_results = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error(f"Batch execution {i} failed: {result}")
                    raise result
                final_results.append(result)
            
            return final_results
        else:
            # Execute sequentially
            results = []
            for input_data in input_batch:
                result = await self.execute(input_data)
                results.append(result)
            return results
    
    def __str__(self) -> str:
        """String representation."""
        return (
            f"EnhancedPrefectAsyncAgent("
            f"functions={len(self._functions)}, "
            f"metrics={self._enable_metrics}, "
            f"max_time={self._max_execution_time}, "
            f"async_opts={self._enable_async_optimizations})"
        )


# Example async stage functions for demonstration
@perceive
async def enhanced_async_perceive(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced async perceive stage with detailed logging."""
    input_data = context.get("input", {})
    logger.info(f"Enhanced async perceiving: {input_data}")
    
    # Simulate async I/O operation
    await asyncio.sleep(0.1)
    
    return {
        "perceived_data": f"async_processed_{input_data}",
        "perception_timestamp": time.time(),
        "perception_quality": "high",
        "async_processing": True
    }


@perceive
def enhanced_sync_perceive(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced SYNC perceive stage mixed with async workflow."""
    input_data = context.get("input", {})
    logger.info(f"Enhanced SYNC perceiving: {input_data}")
    
    # Simulate sync processing
    time.sleep(0.1)
    
    return {
        "perceived_data": f"sync_processed_{input_data}",
        "perception_timestamp": time.time(),
        "perception_quality": "high",
        "sync_processing": True
    }


@reason
async def enhanced_async_reason(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced async reason stage with analysis metrics."""
    perceived = context.get("perceived_data", "")
    quality = context.get("perception_quality", "unknown")
    
    logger.info(f"Enhanced async reasoning on: {perceived} (quality: {quality})")
    
    # Simulate async reasoning with concurrent operations
    analysis_task = asyncio.create_task(asyncio.sleep(0.1))
    confidence_task = asyncio.create_task(asyncio.sleep(0.05))
    
    await asyncio.gather(analysis_task, confidence_task)
    
    confidence = 0.95 if quality == "high" else 0.7
    
    return {
        "analysis": f"async_analyzed_{perceived}",
        "confidence": confidence,
        "reasoning_method": "async_enhanced_algorithm",
        "analysis_timestamp": time.time(),
        "concurrent_processing": True
    }


@reason
def enhanced_sync_reason(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced SYNC reason stage mixed with async workflow."""
    perceived = context.get("perceived_data", "")
    quality = context.get("perception_quality", "unknown")
    
    logger.info(f"Enhanced SYNC reasoning on: {perceived} (quality: {quality})")
    
    # Simulate sync reasoning
    time.sleep(0.15)
    
    confidence = 0.95 if quality == "high" else 0.7
    
    return {
        "analysis": f"sync_analyzed_{perceived}",
        "confidence": confidence,
        "reasoning_method": "sync_enhanced_algorithm",
        "analysis_timestamp": time.time(),
        "sync_processing": True
    }


@plan
async def enhanced_async_plan(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced async plan stage with strategy selection."""
    analysis = context.get("analysis", "")
    confidence = context.get("confidence", 0.5)
    
    logger.info(f"Enhanced async planning based on: {analysis} (confidence: {confidence})")
    
    # Simulate async planning with multiple strategy evaluations
    strategies = ["aggressive", "conservative", "balanced"]
    strategy_tasks = [asyncio.sleep(0.03) for _ in strategies]
    await asyncio.gather(*strategy_tasks)
    
    # Choose strategy based on confidence
    strategy = "aggressive" if confidence > 0.8 else "conservative"
    
    return {
        "plan": f"async_plan_for_{analysis}",
        "strategy": strategy,
        "plan_confidence": confidence,
        "plan_timestamp": time.time(),
        "strategies_evaluated": len(strategies)
    }


@plan
def enhanced_sync_plan(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced SYNC plan stage mixed with async workflow."""
    analysis = context.get("analysis", "")
    confidence = context.get("confidence", 0.5)
    
    logger.info(f"Enhanced SYNC planning based on: {analysis} (confidence: {confidence})")
    
    # Simulate sync planning
    time.sleep(0.1)
    
    # Choose strategy based on confidence
    strategy = "aggressive" if confidence > 0.8 else "conservative"
    
    return {
        "plan": f"sync_plan_for_{analysis}",
        "strategy": strategy,
        "plan_confidence": confidence,
        "plan_timestamp": time.time(),
        "sync_planning": True
    }


@act
async def enhanced_async_act(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced async act stage with execution tracking."""
    plan = context.get("plan", "")
    strategy = context.get("strategy", "default")
    
    logger.info(f"Enhanced async executing: {plan} (strategy: {strategy})")
    
    # Simulate async execution with parallel operations
    execution_time = 0.15 if strategy == "aggressive" else 0.08
    
    # Simulate multiple async operations
    ops = [asyncio.sleep(execution_time / 3) for _ in range(3)]
    await asyncio.gather(*ops)
    
    return {
        "result": f"async_executed_{plan}",
        "execution_strategy": strategy,
        "execution_duration": execution_time,
        "execution_timestamp": time.time(),
        "success": True,
        "parallel_operations": len(ops)
    }


@act
def enhanced_sync_act(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced SYNC act stage mixed with async workflow."""
    plan = context.get("plan", "")
    strategy = context.get("strategy", "default")
    
    logger.info(f"Enhanced SYNC executing: {plan} (strategy: {strategy})")
    
    # Simulate sync execution
    execution_time = 0.2 if strategy == "aggressive" else 0.1
    time.sleep(execution_time)
    
    return {
        "result": f"sync_executed_{plan}",
        "execution_strategy": strategy,
        "execution_duration": execution_time,
        "execution_timestamp": time.time(),
        "success": True,
        "sync_execution": True
    }


async def demonstrate_custom_async_agent():
    """Demonstrate the custom enhanced async agent."""
    logger.info("\n=== Custom Enhanced Async Agent Demo ===")
    
    # Create enhanced async agent with custom configuration
    agent = EnhancedPrefectAsyncAgent(
        functions=[enhanced_async_perceive, enhanced_async_reason, enhanced_async_plan, enhanced_async_act],
        initial_context={"mode": "async_enhanced", "version": "1.0"},
        concurrent={Stage.REASON: True, Stage.PLAN: True},
        workflow_id="async_enhanced_demo",
        enable_metrics=True,
        max_execution_time=30.0,  # Increased timeout for server startup
        enable_async_optimizations=True
    )
    
    logger.info(f"Created async agent: {agent}")
    logger.info(f"Agent type: {agent.get_execution_type()}")
    
    # Execute workflow
    result = await agent.execute("async_test_input")
    
    logger.info(f"\nAsync execution result keys: {list(result.data.keys())}")
    logger.info(f"Final result: {result.data.get('result')}")
    logger.info(f"Strategy used: {result.data.get('execution_strategy')}")
    logger.info(f"Success: {result.data.get('success')}")
    logger.info(f"Async processing: {result.data.get('async_processing')}")
    
    # Show metrics
    metrics = agent.get_execution_metrics()
    logger.info(f"\nAsync Execution Metrics:")
    logger.info(f"  Execution time: {metrics.get('execution_time', 0):.3f}s")
    logger.info(f"  Function count: {metrics.get('function_count')}")
    logger.info(f"  Success: {metrics.get('success')}")
    logger.info(f"  Async optimizations: {metrics.get('async_optimizations')}")
    logger.info(f"  Result keys: {metrics.get('result_keys')}")


async def demonstrate_fluent_async_configuration():
    """Demonstrate fluent interface configuration for async agent."""
    logger.info("\n=== Fluent Async Configuration Demo ===")
    
    # Create agent using fluent interface
    agent = (EnhancedPrefectAsyncAgent()
             .add_function(enhanced_async_perceive)
             .add_function(enhanced_async_reason)
             .add_function(enhanced_async_plan)
             .add_function(enhanced_async_act)
             .set_initial_context({"fluent": True, "async": True})
             .set_stage_concurrent(Stage.PERCEIVE, True)
             .set_max_execution_time(20.0)
             .enable_metrics(True)
             .enable_async_optimizations(True)
             .set_workflow_id("fluent_async_enhanced"))
    
    logger.info(f"Fluent configured async agent: {agent}")
    
    # Execute
    result = await agent.execute("fluent_async_input")
    metrics = agent.get_execution_metrics()
    
    logger.info(f"Fluent async execution time: {metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Fluent async result success: {metrics.get('success')}")


async def demonstrate_batch_execution():
    """Demonstrate batch execution with async agent."""
    logger.info("\n=== Async Batch Execution Demo ===")
    
    agent = EnhancedPrefectAsyncAgent(
        functions=[enhanced_async_perceive, enhanced_async_reason],
        enable_metrics=True,
        enable_async_optimizations=True,
        workflow_id="batch_demo"
    )
    
    # Execute batch of workflows
    batch_inputs = [f"batch_input_{i}" for i in range(3)]
    start_time = time.time()
    
    results = await agent.execute_batch(batch_inputs)
    
    batch_time = time.time() - start_time
    logger.info(f"Batch execution completed in {batch_time:.3f}s")
    logger.info(f"Processed {len(results)} workflows concurrently")
    
    for i, result in enumerate(results):
        logger.info(f"  Batch {i}: {result.data.get('perceived_data')}")


async def demonstrate_timeout_handling():
    """Demonstrate timeout handling in async agent."""
    logger.info("\n=== Async Timeout Handling Demo ===")
    
    # Simple timeout demo without Prefect overhead
    logger.info("Testing basic async timeout functionality...")
    
    async def slow_operation():
        await asyncio.sleep(2.0)
        return "completed"
    
    try:
        # This should timeout after 1 second
        result = await asyncio.wait_for(slow_operation(), timeout=1.0)
        logger.info(f"Operation completed: {result}")
    except asyncio.TimeoutError:
        logger.info("Caught expected asyncio timeout - basic timeout handling works!")
    
    # Note: Full Prefect agent timeout testing requires longer timeouts due to server startup
    logger.info("Note: Prefect agent timeouts need longer limits due to server initialization time")


async def demonstrate_mixed_sync_async():
    """Demonstrate mixed sync/async stage functions in async workflow."""
    logger.info("\n=== Mixed Sync/Async Stages Demo ===")
    
    # Test 1: All async stages
    logger.info("Test 1: Pure async workflow")
    async_agent = EnhancedPrefectAsyncAgent(
        functions=[enhanced_async_perceive, enhanced_async_reason, enhanced_async_plan, enhanced_async_act],
        workflow_id="pure_async_demo",
        enable_metrics=True,
        max_execution_time=30.0
    )
    
    result_async = await async_agent.execute("pure_async_input")
    metrics_async = async_agent.get_execution_metrics()
    logger.info(f"Pure async execution time: {metrics_async.get('execution_time', 0):.3f}s")
    logger.info(f"Async processing: {result_async.data.get('async_processing')}")
    logger.info(f"Concurrent processing: {result_async.data.get('concurrent_processing')}")
    
    # Test 2: Mixed sync/async stages
    logger.info("\nTest 2: Mixed sync/async workflow")
    mixed_agent = EnhancedPrefectAsyncAgent(
        functions=[enhanced_sync_perceive, enhanced_async_reason, enhanced_sync_plan, enhanced_async_act],
        workflow_id="mixed_demo",
        enable_metrics=True,
        max_execution_time=30.0
    )
    
    result_mixed = await mixed_agent.execute("mixed_input")
    metrics_mixed = mixed_agent.get_execution_metrics()
    logger.info(f"Mixed execution time: {metrics_mixed.get('execution_time', 0):.3f}s")
    logger.info(f"Sync processing: {result_mixed.data.get('sync_processing')}")
    logger.info(f"Sync planning: {result_mixed.data.get('sync_planning')}")
    logger.info(f"Concurrent processing: {result_mixed.data.get('concurrent_processing')}")
    
    # Test 3: All sync stages in async agent
    logger.info("\nTest 3: Pure sync stages in async workflow")
    sync_in_async_agent = EnhancedPrefectAsyncAgent(
        functions=[enhanced_sync_perceive, enhanced_sync_reason, enhanced_sync_plan, enhanced_sync_act],
        workflow_id="sync_in_async_demo",
        enable_metrics=True,
        max_execution_time=30.0
    )
    
    result_sync_in_async = await sync_in_async_agent.execute("sync_in_async_input")
    metrics_sync_in_async = sync_in_async_agent.get_execution_metrics()
    logger.info(f"Sync-in-async execution time: {metrics_sync_in_async.get('execution_time', 0):.3f}s")
    logger.info(f"Sync processing: {result_sync_in_async.data.get('sync_processing')}")
    logger.info(f"Sync execution: {result_sync_in_async.data.get('sync_execution')}")


async def demonstrate_concurrent_mixed_execution():
    """Demonstrate concurrent execution with mixed sync/async stages."""
    logger.info("\n=== Concurrent Mixed Execution Demo ===")
    
    # Create agents with different sync/async combinations
    agents = [
        ("Pure Async", EnhancedPrefectAsyncAgent(
            functions=[enhanced_async_perceive, enhanced_async_reason],
            workflow_id="concurrent_async",
            enable_metrics=True,
            max_execution_time=30.0
        )),
        ("Mixed 1", EnhancedPrefectAsyncAgent(
            functions=[enhanced_sync_perceive, enhanced_async_reason],
            workflow_id="concurrent_mixed1",
            enable_metrics=True,
            max_execution_time=30.0
        )),
        ("Mixed 2", EnhancedPrefectAsyncAgent(
            functions=[enhanced_async_perceive, enhanced_sync_reason],
            workflow_id="concurrent_mixed2",
            enable_metrics=True,
            max_execution_time=30.0
        )),
        ("Pure Sync", EnhancedPrefectAsyncAgent(
            functions=[enhanced_sync_perceive, enhanced_sync_reason],
            workflow_id="concurrent_sync",
            enable_metrics=True,
            max_execution_time=30.0
        ))
    ]
    
    # Execute all agents concurrently
    start_time = time.time()
    tasks = [agent.execute(f"concurrent_input_{name.lower().replace(' ', '_')}") 
             for name, agent in agents]
    
    results = await asyncio.gather(*tasks)
    total_time = time.time() - start_time
    
    logger.info(f"All 4 mixed workflows completed concurrently in {total_time:.3f}s")
    
    # Show individual results
    for i, (name, agent) in enumerate(agents):
        metrics = agent.get_execution_metrics()
        result = results[i]
        logger.info(f"  {name}: {metrics.get('execution_time', 0):.3f}s - "
                   f"Result: {result.data.get('analysis', 'N/A')[:50]}...")


async def demonstrate_async_agent_cloning():
    """Demonstrate cloning the custom async agent."""
    logger.info("\n=== Custom Async Agent Cloning Demo ===")
    
    # Create base enhanced async agent with mixed stages
    base_agent = EnhancedPrefectAsyncAgent(
        functions=[enhanced_sync_perceive, enhanced_async_reason],  # Mixed base
        initial_context={"base": "async_enhanced"},
        enable_metrics=True,
        max_execution_time=15.0
    )
    
    # Clone and extend with more mixed stages
    extended_agent = (base_agent.clone()
                     .add_function(enhanced_sync_plan)      # Add sync
                     .add_function(enhanced_async_act)      # Add async
                     .set_max_execution_time(20.0)
                     .enable_async_optimizations(True)
                     .update_initial_context({"extended": True}))
    
    logger.info(f"Base async agent functions: {len(base_agent.functions)}")
    logger.info(f"Extended async agent functions: {len(extended_agent.functions)}")
    
    # Execute both concurrently
    base_task = base_agent.execute("base_mixed_input")
    extended_task = extended_agent.execute("extended_mixed_input")
    
    base_result, extended_result = await asyncio.gather(base_task, extended_task)
    
    base_metrics = base_agent.get_execution_metrics()
    extended_metrics = extended_agent.get_execution_metrics()
    
    logger.info(f"Base mixed execution time: {base_metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Extended mixed execution time: {extended_metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Base result keys: {len(base_result.data)}")
    logger.info(f"Extended result keys: {len(extended_result.data)}")
    logger.info(f"Base has sync processing: {'sync_processing' in base_result.data}")
    logger.info(f"Extended has sync planning: {'sync_planning' in extended_result.data}")


async def main():
    """Main async demonstration function."""
    logger.info("Custom Async Agent Framework Demonstration")
    logger.info("=" * 50)
    
    await demonstrate_custom_async_agent()
    await demonstrate_fluent_async_configuration()
    await demonstrate_batch_execution()
    await demonstrate_timeout_handling()
    await demonstrate_mixed_sync_async()
    await demonstrate_concurrent_mixed_execution()
    await demonstrate_async_agent_cloning()
    
    logger.info("\n=== Custom Async Agent Demo Complete ===")


if __name__ == "__main__":
    asyncio.run(main())