#!/usr/bin/env python3
"""
Comprehensive demo of the tools system.

This example demonstrates:
1. Tool hooks integration with agentic workflows
2. LLM tools usage (OpenAI, Gemini, etc.)
3. Database tools usage (PostgreSQL, Neo4j, MongoDB)
4. API tools for HTTP requests
5. Utility tools (File, Email, Slack)
6. Configuration via YAML and .env files
7. Error handling and retries
8. Tool result processing
"""

import sys
import os
import asyncio
import time
from typing import Dict, Any

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    agentic_spine_async, perceive, reason, plan, act,
    Context, Stage, get_logger, setup_logging
)
from agent_sdk.tools import (
    tool_hook, get_available_tools, execute_tool,
    load_tools_config
)

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# =============================================================================
# 1. BASIC TOOL USAGE WITHOUT HOOKS
# =============================================================================

async def demo_direct_tool_usage():
    """Demonstrate direct tool usage without hooks."""
    logger.info("\n🔧 DEMO: Direct Tool Usage")
    logger.info("-" * 40)
    
    # Load tool configurations
    configs = load_tools_config(config_dir="config")
    logger.info(f"Loaded {len(configs)} tool configurations")
    
    # List available tools
    available_tools = get_available_tools()
    logger.info(f"Available tools: {available_tools}")
    
    # Test file tool (should always be available)
    if 'file_manager' in available_tools:
        logger.info("Testing file manager tool...")
        
        # Write a test file
        result = await execute_tool(
            'file_manager',
            operation='write',
            file_path='test_output.txt',
            content='Hello from the tools system!'
        )
        
        if result.is_success:
            logger.info(f"✅ File written: {result.data}")
        else:
            logger.error(f"❌ File write failed: {result.error}")
        
        # Read the file back
        result = await execute_tool(
            'file_manager',
            operation='read',
            file_path='test_output.txt'
        )
        
        if result.is_success:
            logger.info(f"✅ File content: {result.data['content']}")
        else:
            logger.error(f"❌ File read failed: {result.error}")
    
    # Test HTTP tool
    if 'http_client' in available_tools:
        logger.info("Testing HTTP client tool...")
        
        result = await execute_tool(
            'http_client',
            method='GET',
            url='https://httpbin.org/json'
        )
        
        if result.is_success:
            logger.info(f"✅ HTTP request successful: {result.data['status_code']}")
        else:
            logger.error(f"❌ HTTP request failed: {result.error}")


# =============================================================================
# 2. TOOL HOOKS WITH AGENTIC WORKFLOWS
# =============================================================================

@perceive
@tool_hook
async def analyze_text_with_llm(ctx: Context, tools) -> Dict[str, Any]:
    """Analyze text using available LLM tools."""
    logger.info("🧠 Analyzing text with LLM...")
    
    text = ctx.get("input", {}).get("text", "")
    
    # Try different LLM tools in order of preference
    llm_tools = ['openai', 'gemini', 'mistral', 'anthropic']
    available = tools.get_available_tools('llm')
    
    for llm_tool in llm_tools:
        if llm_tool in available:
            logger.info(f"Using LLM tool: {llm_tool}")
            
            result = await tools.execute(
                llm_tool,
                prompt=f"Analyze the following text and provide insights: {text}",
                max_tokens=200,
                temperature=0.7
            )
            
            if result.is_success:
                return {
                    "llm_analysis": result.data.get('response', ''),
                    "llm_tool_used": llm_tool,
                    "word_count": len(text.split()),
                    "analysis_complete": True
                }
            else:
                logger.warning(f"LLM tool {llm_tool} failed: {result.error}")
    
    # Fallback to simple analysis if no LLM available
    logger.info("No LLM tools available, using simple analysis")
    return {
        "llm_analysis": f"Simple analysis: Text has {len(text.split())} words and {len(text)} characters.",
        "llm_tool_used": "none",
        "word_count": len(text.split()),
        "analysis_complete": True
    }

@reason
@tool_hook
async def store_analysis_results(ctx: Context, tools) -> Dict[str, Any]:
    """Store analysis results using available database tools."""
    logger.info("💾 Storing analysis results...")
    
    analysis = ctx.get("llm_analysis", "")
    word_count = ctx.get("word_count", 0)
    llm_tool = ctx.get("llm_tool_used", "none")
    
    # Try database tools
    db_tools = ['postgresql', 'mongodb', 'neo4j']
    available = tools.get_available_tools('database')
    
    for db_tool in db_tools:
        if db_tool in available:
            logger.info(f"Using database tool: {db_tool}")
            
            try:
                if db_tool == 'postgresql':
                    result = await tools.execute(
                        db_tool,
                        query="""
                        INSERT INTO analysis_results (text_analysis, word_count, llm_tool, created_at)
                        VALUES ($1, $2, $3, NOW())
                        """,
                        params=[analysis, word_count, llm_tool],
                        fetch='none'
                    )
                
                elif db_tool == 'mongodb':
                    result = await tools.execute(
                        db_tool,
                        operation='insert_one',
                        collection='analysis_results',
                        document={
                            'text_analysis': analysis,
                            'word_count': word_count,
                            'llm_tool': llm_tool,
                            'created_at': time.time()
                        }
                    )
                
                elif db_tool == 'neo4j':
                    result = await tools.execute(
                        db_tool,
                        query="""
                        CREATE (a:Analysis {
                            text_analysis: $analysis,
                            word_count: $word_count,
                            llm_tool: $llm_tool,
                            created_at: datetime()
                        })
                        RETURN a
                        """,
                        params={
                            'analysis': analysis,
                            'word_count': word_count,
                            'llm_tool': llm_tool
                        }
                    )
                
                if result.is_success:
                    return {
                        "stored": True,
                        "database_tool": db_tool,
                        "storage_complete": True
                    }
                else:
                    logger.warning(f"Database tool {db_tool} failed: {result.error}")
            
            except Exception as e:
                logger.warning(f"Database tool {db_tool} error: {e}")
    
    # Fallback to file storage
    logger.info("No database tools available, using file storage")
    result = await tools.execute(
        'file_manager',
        operation='append',
        file_path='analysis_log.txt',
        content=f"\n{time.time()}: {analysis[:100]}... (Tool: {llm_tool}, Words: {word_count})"
    )
    
    return {
        "stored": result.is_success,
        "database_tool": "file_manager",
        "storage_complete": True
    }

@plan
@tool_hook
async def create_action_plan(ctx: Context, tools) -> Dict[str, Any]:
    """Create action plan based on analysis."""
    logger.info("📋 Creating action plan...")
    
    analysis = ctx.get("llm_analysis", "")
    word_count = ctx.get("word_count", 0)
    stored = ctx.get("stored", False)
    
    # Determine actions based on analysis
    actions = []
    
    if word_count > 50:
        actions.append("detailed_review")
    else:
        actions.append("quick_review")
    
    if stored:
        actions.append("send_confirmation")
    else:
        actions.append("retry_storage")
    
    if "positive" in analysis.lower():
        actions.append("celebrate")
    elif "negative" in analysis.lower():
        actions.append("investigate")
    
    return {
        "actions": actions,
        "plan_ready": True,
        "estimated_time": len(actions) * 0.5
    }

@act
@tool_hook
async def execute_actions(ctx: Context, tools) -> Dict[str, Any]:
    """Execute the planned actions using various tools."""
    logger.info("⚡ Executing actions...")
    
    actions = ctx.get("actions", [])
    analysis = ctx.get("llm_analysis", "")
    executed_actions = []
    
    for action in actions:
        logger.info(f"Executing action: {action}")
        
        if action == "send_confirmation":
            # Try to send notification
            available = tools.get_available_tools('utility')
            
            if 'slack_notifier' in available:
                result = await tools.execute(
                    'slack_notifier',
                    message=f"Analysis completed: {analysis[:100]}...",
                    icon_emoji=":robot_face:"
                )
                if result.is_success:
                    executed_actions.append(f"✓ {action} (Slack)")
                else:
                    executed_actions.append(f"✗ {action} (Slack failed)")
            
            elif 'email_sender' in available:
                result = await tools.execute(
                    'email_sender',
                    to_email="admin@example.com",
                    subject="Analysis Completed",
                    body=f"Analysis results:\n\n{analysis}"
                )
                if result.is_success:
                    executed_actions.append(f"✓ {action} (Email)")
                else:
                    executed_actions.append(f"✗ {action} (Email failed)")
            
            else:
                # Fallback to file notification
                result = await tools.execute(
                    'file_manager',
                    operation='append',
                    file_path='notifications.txt',
                    content=f"\n{time.time()}: Analysis completed - {analysis[:50]}..."
                )
                executed_actions.append(f"✓ {action} (File)")
        
        elif action == "detailed_review":
            # Save detailed report
            result = await tools.execute(
                'file_manager',
                operation='write',
                file_path=f'detailed_report_{int(time.time())}.txt',
                content=f"Detailed Analysis Report\n\n{analysis}\n\nGenerated at: {time.ctime()}"
            )
            executed_actions.append(f"✓ {action}")
        
        else:
            # Generic action execution
            await asyncio.sleep(0.1)  # Simulate action execution
            executed_actions.append(f"✓ {action}")
    
    return {
        "executed_actions": executed_actions,
        "total_actions": len(actions),
        "execution_complete": True,
        "success": True
    }


# =============================================================================
# 3. WORKFLOW DEMONSTRATIONS
# =============================================================================

async def demo_simple_workflow():
    """Demonstrate simple workflow with tools."""
    logger.info("\n🎯 DEMO: Simple Workflow with Tools")
    logger.info("-" * 50)
    
    result = await agentic_spine_async(
        input_data={
            "text": "This is a positive example of how the tools system can enhance agentic workflows with powerful integrations."
        },
        functions=[
            analyze_text_with_llm,
            store_analysis_results,
            create_action_plan,
            execute_actions
        ],
        workflow_id="simple_tools_workflow"
    )
    
    logger.info("✅ Simple workflow completed")
    logger.info(f"   LLM Tool Used: {result.data.get('llm_tool_used', 'none')}")
    logger.info(f"   Storage: {result.data.get('database_tool', 'none')}")
    logger.info(f"   Actions: {len(result.data.get('executed_actions', []))}")
    
    return result

async def demo_concurrent_workflow():
    """Demonstrate concurrent workflow with tools."""
    logger.info("\n🔀 DEMO: Concurrent Workflow with Tools")
    logger.info("-" * 50)
    
    # Create multiple analysis tasks
    @perceive
    @tool_hook
    async def analyze_sentiment(ctx: Context, tools) -> Dict[str, Any]:
        """Analyze sentiment using LLM."""
        text = ctx.get("input", {}).get("text", "")
        
        available = tools.get_available_tools('llm')
        if available:
            result = await tools.execute(
                available[0],
                prompt=f"Analyze the sentiment of this text (positive/negative/neutral): {text}",
                max_tokens=50
            )
            
            if result.is_success:
                sentiment = result.data.get('response', 'neutral').lower()
                return {"sentiment": sentiment, "sentiment_analysis_done": True}
        
        return {"sentiment": "neutral", "sentiment_analysis_done": True}
    
    @perceive
    @tool_hook
    async def extract_keywords(ctx: Context, tools) -> Dict[str, Any]:
        """Extract keywords using LLM."""
        text = ctx.get("input", {}).get("text", "")
        
        available = tools.get_available_tools('llm')
        if available:
            result = await tools.execute(
                available[0],
                prompt=f"Extract 5 key words from this text: {text}",
                max_tokens=50
            )
            
            if result.is_success:
                keywords = result.data.get('response', '').split()[:5]
                return {"keywords": keywords, "keyword_extraction_done": True}
        
        return {"keywords": [], "keyword_extraction_done": True}
    
    result = await agentic_spine_async(
        input_data={
            "text": "The innovative tools system provides seamless integration with multiple AI services and databases."
        },
        functions=[analyze_sentiment, extract_keywords, create_action_plan],
        concurrent={Stage.PERCEIVE: True},  # Run perception tasks concurrently
        workflow_id="concurrent_tools_workflow"
    )
    
    logger.info("✅ Concurrent workflow completed")
    logger.info(f"   Sentiment: {result.data.get('sentiment', 'unknown')}")
    logger.info(f"   Keywords: {result.data.get('keywords', [])}")
    
    return result

async def demo_error_handling():
    """Demonstrate error handling with tools."""
    logger.info("\n💥 DEMO: Error Handling with Tools")
    logger.info("-" * 50)
    
    @perceive
    @tool_hook
    async def test_error_handling(ctx: Context, tools) -> Dict[str, Any]:
        """Test error handling with invalid tool calls."""
        
        # Test 1: Non-existent tool
        result = await tools.execute('non_existent_tool', param='value')
        logger.info(f"Non-existent tool result: {result.status.value}")
        
        # Test 2: Invalid parameters
        result = await tools.execute('file_manager', invalid_param='value')
        logger.info(f"Invalid parameters result: {result.status.value}")
        
        # Test 3: Valid tool call
        result = await tools.execute(
            'file_manager',
            operation='write',
            file_path='error_test.txt',
            content='Error handling test'
        )
        logger.info(f"Valid tool call result: {result.status.value}")
        
        return {
            "error_handling_tested": True,
            "valid_call_success": result.is_success
        }
    
    result = await agentic_spine_async(
        input_data={"text": "Error handling test"},
        functions=[test_error_handling],
        workflow_id="error_handling_workflow"
    )
    
    logger.info("✅ Error handling test completed")
    return result


# =============================================================================
# 4. CONFIGURATION DEMONSTRATION
# =============================================================================

def demo_configuration():
    """Demonstrate configuration management."""
    logger.info("\n⚙️ DEMO: Configuration Management")
    logger.info("-" * 50)
    
    # Load configurations
    configs = load_tools_config(config_dir="config")
    
    logger.info("📋 Tool Configurations:")
    for name, config in configs.items():
        status = "✅ Enabled" if config.enabled else "❌ Disabled"
        logger.info(f"   {name} ({config.type}): {status}")
    
    # Show environment variable usage
    logger.info("\n🔧 Environment Variable Examples:")
    logger.info("   OPENAI_API_KEY=your_key_here")
    logger.info("   POSTGRES_URL=postgresql://user:pass@host:port/db")
    logger.info("   SLACK_WEBHOOK_URL=https://hooks.slack.com/...")
    
    # Show tool categories
    categories = {}
    for config in configs.values():
        if config.category not in categories:
            categories[config.category] = []
        categories[config.category].append(config.name)
    
    logger.info("\n📂 Tool Categories:")
    for category, tools in categories.items():
        logger.info(f"   {category}: {', '.join(tools)}")


# =============================================================================
# 5. MAIN DEMONSTRATION
# =============================================================================

async def main():
    """Run all tool system demonstrations."""
    logger.info("🚀 TOOLS SYSTEM COMPREHENSIVE DEMO")
    logger.info("=" * 60)
    
    # Configuration demo
    demo_configuration()
    
    # Direct tool usage
    await demo_direct_tool_usage()
    
    # Workflow demonstrations
    simple_result = await demo_simple_workflow()
    concurrent_result = await demo_concurrent_workflow()
    error_result = await demo_error_handling()
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("🎉 TOOLS SYSTEM DEMO SUMMARY")
    logger.info("=" * 60)
    
    logger.info("✅ Features Demonstrated:")
    logger.info("   • Tool hooks integration (@tool_hook)")
    logger.info("   • LLM tools (OpenAI, Gemini, Mistral, Anthropic)")
    logger.info("   • Database tools (PostgreSQL, Neo4j, MongoDB)")
    logger.info("   • API tools (HTTP client, REST API)")
    logger.info("   • Utility tools (File, Email, Slack)")
    logger.info("   • YAML and .env configuration")
    logger.info("   • Error handling and retries")
    logger.info("   • Concurrent tool execution")
    
    logger.info("\n✅ Configuration:")
    logger.info("   • YAML config: config/tools.yaml")
    logger.info("   • Environment: .env file")
    logger.info("   • Tool-specific overrides: TOOLNAME_SETTING")
    
    logger.info("\n✅ Usage Patterns:")
    logger.info("   • @tool_hook decorator for automatic injection")
    logger.info("   • tools.execute(tool_name, **params)")
    logger.info("   • tools.get_available_tools(category)")
    logger.info("   • Fallback strategies for missing tools")
    
    logger.info("\n📊 Results:")
    logger.info(f"   • Simple workflow: {simple_result.data.get('success', False)}")
    logger.info(f"   • Concurrent workflow: {concurrent_result.data.get('keyword_extraction_done', False)}")
    logger.info(f"   • Error handling: {error_result.data.get('error_handling_tested', False)}")
    
    logger.info("\n🎯 Next Steps:")
    logger.info("   1. Copy .env.example to .env and configure your API keys")
    logger.info("   2. Enable desired tools in config/tools.yaml")
    logger.info("   3. Use @tool_hook in your agentic workflows")
    logger.info("   4. Build custom tools by extending the Tool base class")


if __name__ == "__main__":
    asyncio.run(main())