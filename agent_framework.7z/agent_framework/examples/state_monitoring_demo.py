#!/usr/bin/env python3
"""
Comprehensive demo of stage state monitoring system.

This example demonstrates:
1. Real-time stage state tracking (started, running, completed, error)
2. Custom observers for logging and metrics collection
3. Workflow monitoring across different execution modes
4. Error handling and state transitions
5. Performance metrics and analytics
"""

import sys
import os
import asyncio
import time
import json
from typing import Dict, Any

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    agentic_spine_async, agentic_spine_async_prefect, agentic_spine_simple,
    perceive, reason, plan, act, Stage, Context,
    StageState, StageStateObserver, LoggingObserver, MetricsObserver,
    get_state_manager, configure_monitoring, get_workflow_status, get_metrics,
    get_logger, setup_logging
)
from agent_sdk.core.decorators import stage_decorator, async_stage
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# =============================================================================
# 1. CUSTOM OBSERVERS FOR MONITORING
# =============================================================================

class CustomDashboardObserver(StageStateObserver):
    """Custom observer that simulates a real-time dashboard."""
    
    def __init__(self):
        self.dashboard_data = {
            "active_workflows": {},
            "stage_history": [],
            "error_log": [],
            "performance_stats": {}
        }
    
    def on_stage_state_changed(self, execution) -> None:
        """Update dashboard with stage state changes."""
        stage_info = {
            "timestamp": time.time(),
            "workflow_id": execution.execution_id.split('_')[0] if execution.execution_id else "unknown",
            "stage": execution.stage.name,
            "function": execution.function_name,
            "state": execution.state.value,
            "duration": execution.duration
        }
        
        self.dashboard_data["stage_history"].append(stage_info)
        
        if execution.state == StageState.ERROR:
            self.dashboard_data["error_log"].append({
                "timestamp": time.time(),
                "workflow_id": stage_info["workflow_id"],
                "stage": execution.stage.name,
                "function": execution.function_name,
                "error": str(execution.error)
            })
        
        # Keep only last 50 entries
        if len(self.dashboard_data["stage_history"]) > 50:
            self.dashboard_data["stage_history"] = self.dashboard_data["stage_history"][-50:]
    
    def on_workflow_started(self, workflow_id: str) -> None:
        """Track workflow start."""
        self.dashboard_data["active_workflows"][workflow_id] = {
            "start_time": time.time(),
            "status": "running",
            "stages_completed": 0
        }
        logger.info(f"📊 [DASHBOARD] Workflow {workflow_id} started")
    
    def on_workflow_completed(self, workflow_id: str, executions) -> None:
        """Track workflow completion."""
        if workflow_id in self.dashboard_data["active_workflows"]:
            workflow_info = self.dashboard_data["active_workflows"][workflow_id]
            workflow_info["status"] = "completed"
            workflow_info["end_time"] = time.time()
            workflow_info["total_duration"] = workflow_info["end_time"] - workflow_info["start_time"]
            workflow_info["stages_completed"] = len([e for e in executions if e.state == StageState.COMPLETED])
        
        logger.info(f"📊 [DASHBOARD] Workflow {workflow_id} completed")
    
    def on_workflow_error(self, workflow_id: str, error) -> None:
        """Track workflow errors."""
        if workflow_id in self.dashboard_data["active_workflows"]:
            self.dashboard_data["active_workflows"][workflow_id]["status"] = "failed"
            self.dashboard_data["active_workflows"][workflow_id]["error"] = str(error)
        
        logger.error(f"📊 [DASHBOARD] Workflow {workflow_id} failed: {error}")
    
    def get_dashboard_summary(self) -> Dict[str, Any]:
        """Get current dashboard summary."""
        active_count = len([w for w in self.dashboard_data["active_workflows"].values() if w["status"] == "running"])
        completed_count = len([w for w in self.dashboard_data["active_workflows"].values() if w["status"] == "completed"])
        failed_count = len([w for w in self.dashboard_data["active_workflows"].values() if w["status"] == "failed"])
        
        return {
            "active_workflows": active_count,
            "completed_workflows": completed_count,
            "failed_workflows": failed_count,
            "total_stages_executed": len(self.dashboard_data["stage_history"]),
            "recent_errors": len(self.dashboard_data["error_log"][-10:]),
            "recent_activity": self.dashboard_data["stage_history"][-5:]
        }


class AlertingObserver(StageStateObserver):
    """Observer that generates alerts for specific conditions."""
    
    def __init__(self, slow_threshold: float = 2.0, error_threshold: int = 3):
        self.slow_threshold = slow_threshold
        self.error_threshold = error_threshold
        self.error_count = 0
        self.alerts = []
    
    def on_stage_state_changed(self, execution) -> None:
        """Generate alerts based on stage execution."""
        if execution.state == StageState.COMPLETED and execution.duration:
            if execution.duration > self.slow_threshold:
                alert = {
                    "type": "SLOW_EXECUTION",
                    "timestamp": time.time(),
                    "message": f"Stage {execution.stage.name} took {execution.duration:.2f}s (threshold: {self.slow_threshold}s)",
                    "workflow_id": execution.execution_id.split('_')[0] if execution.execution_id else "unknown",
                    "stage": execution.stage.name,
                    "function": execution.function_name,
                    "duration": execution.duration
                }
                self.alerts.append(alert)
                logger.warning(f"🚨 [ALERT] {alert['message']}")
        
        elif execution.state == StageState.ERROR:
            self.error_count += 1
            if self.error_count >= self.error_threshold:
                alert = {
                    "type": "HIGH_ERROR_RATE",
                    "timestamp": time.time(),
                    "message": f"High error rate detected: {self.error_count} errors",
                    "error_count": self.error_count
                }
                self.alerts.append(alert)
                logger.error(f"🚨 [ALERT] {alert['message']}")
    
    def get_alerts(self) -> list:
        """Get all generated alerts."""
        return self.alerts


# =============================================================================
# 2. DEMO FUNCTIONS WITH DIFFERENT BEHAVIORS
# =============================================================================

# Create custom decorators
data_processor = stage_decorator(Stage.PERCEIVE)
analyzer = stage_decorator(Stage.REASON)
planner = async_stage(Stage.PLAN)
executor = stage_decorator(Stage.ACT)

@data_processor
def fast_data_load(ctx):
    """Fast data loading function."""
    logger.info("⚡ [FAST LOAD] Processing data quickly...")
    time.sleep(0.1)  # Fast processing
    text = ctx.get("input", {}).get("text", "")
    return {"data": text, "load_type": "fast", "word_count": len(text.split())}

@data_processor
async def slow_data_load(ctx):
    """Slow data loading function to trigger alerts."""
    logger.info("🐌 [SLOW LOAD] Processing data slowly...")
    await asyncio.sleep(2.5)  # Slow processing (will trigger alert)
    text = ctx.get("input", {}).get("text", "")
    return {"data": text, "load_type": "slow", "word_count": len(text.split())}

@analyzer
def reliable_analysis(ctx):
    """Reliable analysis function."""
    logger.info("🔍 [RELIABLE] Analyzing data reliably...")
    time.sleep(0.2)
    word_count = ctx.get("word_count", 0)
    return {"analysis": "reliable", "complexity": "high" if word_count > 10 else "low"}

@analyzer
def unreliable_analysis(ctx):
    """Unreliable analysis function that sometimes fails."""
    logger.info("💥 [UNRELIABLE] Analyzing data unreliably...")
    time.sleep(0.1)
    
    # Simulate random failures
    import random
    if random.random() < 0.7:  # 70% chance of failure
        raise Exception("Simulated analysis failure")
    
    word_count = ctx.get("word_count", 0)
    return {"analysis": "unreliable", "complexity": "medium"}

@planner
async def strategic_planning(ctx):
    """Strategic planning function."""
    logger.info("📋 [PLANNING] Creating strategic plan...")
    await asyncio.sleep(0.3)
    
    complexity = ctx.get("complexity", "low")
    analysis = ctx.get("analysis", "unknown")
    
    if complexity == "high":
        plan = ["detailed_review", "expert_consultation", "implementation"]
    elif complexity == "medium":
        plan = ["standard_review", "implementation"]
    else:
        plan = ["quick_review", "direct_implementation"]
    
    return {"plan": plan, "strategy": f"{analysis}_strategy"}

@executor
def execute_plan(ctx):
    """Execute the planned actions."""
    logger.info("⚡ [EXECUTION] Executing planned actions...")
    plan = ctx.get("plan", [])
    
    executed = []
    for action in plan:
        time.sleep(0.05)  # Simulate execution time
        executed.append(f"✓ {action}")
        logger.info(f"   Executed: {action}")
    
    return {"executed": executed, "success": True, "total_actions": len(executed)}


# =============================================================================
# 3. DEMO WORKFLOWS
# =============================================================================

async def demo_successful_workflow():
    """Demonstrate a successful workflow with monitoring."""
    logger.info("\n🎯 [DEMO] Running successful workflow...")
    
    result = await agentic_spine_async(
        input_data={"text": "This is a successful workflow demonstration with multiple stages"},
        functions=[fast_data_load, reliable_analysis, strategic_planning, execute_plan],
        workflow_id="success_demo"
    )
    
    logger.info(f"✅ [DEMO] Successful workflow result: {result.data.get('success')}")
    return result

async def demo_slow_workflow():
    """Demonstrate a slow workflow that triggers alerts."""
    logger.info("\n🐌 [DEMO] Running slow workflow...")
    
    result = await agentic_spine_async(
        input_data={"text": "This workflow will be slow and trigger performance alerts"},
        functions=[slow_data_load, reliable_analysis, strategic_planning, execute_plan],
        workflow_id="slow_demo"
    )
    
    logger.info(f"✅ [DEMO] Slow workflow result: {result.data.get('success')}")
    return result

async def demo_error_workflow():
    """Demonstrate a workflow with errors."""
    logger.info("\n💥 [DEMO] Running error-prone workflow...")
    
    try:
        result = await agentic_spine_async(
            input_data={"text": "This workflow will likely fail"},
            functions=[fast_data_load, unreliable_analysis, strategic_planning, execute_plan],
            workflow_id="error_demo"
        )
        logger.info(f"✅ [DEMO] Error workflow unexpectedly succeeded: {result.data.get('success')}")
        return result
    except Exception as e:
        logger.error(f"❌ [DEMO] Error workflow failed as expected: {e}")
        return None

async def demo_prefect_async_workflow():
    """Demonstrate async Prefect workflow with monitoring."""
    logger.info("\n🚀 [DEMO] Running async Prefect workflow...")
    
    @task(name="prefect_fast_load", cache_policy=NO_CACHE)
    async def prefect_fast_load(ctx: dict) -> dict:
        return await fast_data_load(ctx)
    
    @task(name="prefect_reliable_analysis", cache_policy=NO_CACHE)
    def prefect_reliable_analysis(ctx: dict) -> dict:
        return reliable_analysis(ctx)
    
    @task(name="prefect_strategic_planning", cache_policy=NO_CACHE)
    async def prefect_strategic_planning(ctx: dict) -> dict:
        return await strategic_planning(ctx)
    
    @task(name="prefect_execute_plan", cache_policy=NO_CACHE)
    def prefect_execute_plan(ctx: dict) -> dict:
        return execute_plan(ctx)
    
    result = await agentic_spine_async_prefect(
        input_data={"text": "Async Prefect workflow with comprehensive monitoring"},
        functions=[prefect_fast_load, prefect_reliable_analysis, prefect_strategic_planning, prefect_execute_plan],
        workflow_id="prefect_async_demo"
    )
    
    logger.info(f"✅ [DEMO] Prefect async workflow result: {result.data.get('success')}")
    return result


# =============================================================================
# 4. MONITORING DASHBOARD FUNCTIONS
# =============================================================================

def print_workflow_status(workflow_id: str):
    """Print detailed workflow status."""
    status = get_workflow_status(workflow_id)
    
    logger.info(f"\n📊 [STATUS] Workflow: {workflow_id}")
    logger.info(f"   Status: {status.get('status', 'unknown')}")
    logger.info(f"   Total stages: {status.get('total_stages', 0)}")
    logger.info(f"   Completed: {status.get('completed', 0)}")
    logger.info(f"   Errors: {status.get('errors', 0)}")
    logger.info(f"   Running: {status.get('running', 0)}")
    logger.info(f"   Duration: {status.get('total_duration', 0):.3f}s")
    
    if status.get('executions'):
        logger.info("   Stage details:")
        for exec_info in status['executions']:
            state_emoji = {
                "completed": "✅",
                "error": "❌", 
                "running": "⚡",
                "started": "🚀",
                "pending": "⏳"
            }.get(exec_info['state'], "❓")
            
            duration_str = f" ({exec_info['duration']:.3f}s)" if exec_info['duration'] else ""
            logger.info(f"     {state_emoji} {exec_info['stage']}: {exec_info['function_name']}{duration_str}")

def print_metrics_summary():
    """Print comprehensive metrics summary."""
    metrics = get_metrics()
    
    logger.info(f"\n📈 [METRICS] Performance Summary")
    logger.info(f"   Total executions: {metrics.get('total_executions', 0)}")
    logger.info(f"   Completed: {metrics.get('completed_executions', 0)}")
    logger.info(f"   Failed: {metrics.get('failed_executions', 0)}")
    logger.info(f"   Success rate: {metrics.get('success_rate', 0):.1f}%")
    logger.info(f"   Total duration: {metrics.get('total_duration', 0):.3f}s")
    
    if metrics.get('average_durations'):
        logger.info("   Average durations by stage:")
        for stage, avg_duration in metrics['average_durations'].items():
            logger.info(f"     {stage}: {avg_duration:.3f}s")
    
    if metrics.get('error_counts'):
        logger.info("   Error types:")
        for error_type, count in metrics['error_counts'].items():
            logger.info(f"     {error_type}: {count}")


# =============================================================================
# 5. MAIN DEMONSTRATION
# =============================================================================

async def main():
    """Run comprehensive state monitoring demonstration."""
    logger.info("🚀 STAGE STATE MONITORING DEMONSTRATION")
    logger.info("=" * 60)
    
    # Setup custom monitoring
    dashboard_observer = CustomDashboardObserver()
    alerting_observer = AlertingObserver(slow_threshold=2.0, error_threshold=2)
    
    # Configure monitoring with custom observers
    state_manager = configure_monitoring(
        enable_logging=True,
        enable_metrics=True,
        custom_observers=[dashboard_observer, alerting_observer]
    )
    
    logger.info("✅ Monitoring configured with custom observers")
    
    # Run different types of workflows
    workflows = []
    
    # 1. Successful workflow
    result1 = await demo_successful_workflow()
    workflows.append("success_demo")
    
    # 2. Slow workflow (triggers performance alerts)
    result2 = await demo_slow_workflow()
    workflows.append("slow_demo")
    
    # 3. Error-prone workflow (triggers error alerts)
    result3 = await demo_error_workflow()
    workflows.append("error_demo")
    
    # 4. Async Prefect workflow
    result4 = await demo_prefect_async_workflow()
    workflows.append("prefect_async_demo")
    
    # Print detailed status for each workflow
    logger.info("\n" + "=" * 60)
    logger.info("📊 WORKFLOW STATUS REPORTS")
    logger.info("=" * 60)
    
    for workflow_id in workflows:
        print_workflow_status(workflow_id)
    
    # Print comprehensive metrics
    print_metrics_summary()
    
    # Print dashboard summary
    dashboard_summary = dashboard_observer.get_dashboard_summary()
    logger.info(f"\n📊 [DASHBOARD] Summary")
    logger.info(f"   Active workflows: {dashboard_summary['active_workflows']}")
    logger.info(f"   Completed workflows: {dashboard_summary['completed_workflows']}")
    logger.info(f"   Failed workflows: {dashboard_summary['failed_workflows']}")
    logger.info(f"   Total stages executed: {dashboard_summary['total_stages_executed']}")
    logger.info(f"   Recent errors: {dashboard_summary['recent_errors']}")
    
    # Print alerts
    alerts = alerting_observer.get_alerts()
    if alerts:
        logger.info(f"\n🚨 [ALERTS] Generated {len(alerts)} alerts:")
        for alert in alerts:
            logger.info(f"   {alert['type']}: {alert['message']}")
    else:
        logger.info(f"\n✅ [ALERTS] No alerts generated")
    
    # Final summary
    logger.info("\n" + "=" * 60)
    logger.info("🎉 STATE MONITORING DEMONSTRATION SUMMARY")
    logger.info("=" * 60)
    logger.info("✅ Real-time stage state tracking")
    logger.info("✅ Custom observers for logging and metrics")
    logger.info("✅ Performance monitoring and alerting")
    logger.info("✅ Error tracking and reporting")
    logger.info("✅ Workflow status monitoring")
    logger.info("✅ Multi-execution mode support")
    
    logger.info(f"\n📋 Key Features Demonstrated:")
    logger.info(f"   • Stage states: PENDING → STARTED → RUNNING → COMPLETED/ERROR")
    logger.info(f"   • Real-time monitoring with custom observers")
    logger.info(f"   • Performance alerts for slow executions")
    logger.info(f"   • Error tracking and aggregation")
    logger.info(f"   • Workflow-level status reporting")
    logger.info(f"   • Metrics collection and analysis")
    logger.info(f"   • Dashboard-style data aggregation")


if __name__ == "__main__":
    asyncio.run(main())