"""Test string-based function resolution."""

import sys
import os
sys.path.append(os.path.dirname(__file__))

from agent_sdk.agent import create_simple_sync_agent
from agent_sdk.core.stages import perceive, reason, plan, act, Stage
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# Define test functions in this module
@perceive
def module_perceive(context):
    """Test perceive function defined in this module."""
    input_data = context.get("input", "")
    logger.info(f"Module perceive processing: {input_data}")
    return {"perceived": f"module_perceived_{input_data}"}


@reason
def module_reason(context):
    """Test reason function defined in this module."""
    perceived = context.get("perceived", "")
    logger.info(f"Module reason analyzing: {perceived}")
    return {"reasoning": f"module_analyzed_{perceived}"}


@plan
def module_plan(context):
    """Test plan function defined in this module."""
    reasoning = context.get("reasoning", "")
    logger.info(f"Module plan creating: {reasoning}")
    return {"plan": f"module_plan_{reasoning}"}


@act
def module_act(context):
    """Test act function defined in this module."""
    plan = context.get("plan", "")
    logger.info(f"Module act executing: {plan}")
    return {"action": f"module_executed_{plan}"}


def test_string_function_resolution():
    """Test resolving functions from string references."""
    logger.info("Testing string function resolution...")
    
    # Create agent with minimal functions
    agent = create_simple_sync_agent(
        functions=[module_perceive],  # Just one function initially
        workflow_id="string_resolution_test"
    )
    
    # Test with string function references
    dynamic_input = {
        "input": "string_test_data",
        "functions": [
            "__main__.module_perceive",
            "__main__.module_reason", 
            "__main__.module_plan",
            "__main__.module_act"
        ]
    }
    
    try:
        result = agent.execute(dynamic_input)
        
        # Verify the string functions were resolved and executed
        assert result.data.get("action") is not None
        assert "module_executed" in result.data.get("action", "")
        
        logger.info("✅ String function resolution test passed!")
        logger.info(f"Final result: {result.data.get('action')}")
        
    except Exception as e:
        logger.error(f"String function resolution failed: {e}")
        raise


def test_module_dot_notation():
    """Test module.function notation."""
    logger.info("Testing module.function notation...")
    
    agent = create_simple_sync_agent(
        functions=[module_perceive],
        workflow_id="module_notation_test"
    )
    
    # Create a test module reference
    # Note: This will work if we can import the current module
    current_module = __name__
    
    dynamic_input = {
        "input": "module_test_data",
        "functions": [
            f"{current_module}.module_perceive",
            f"{current_module}.module_reason",
            f"{current_module}.module_plan", 
            f"{current_module}.module_act"
        ]
    }
    
    try:
        result = agent.execute(dynamic_input)
        
        # Verify execution
        assert result.data.get("action") is not None
        assert "module_executed" in result.data.get("action", "")
        
        logger.info("✅ Module.function notation test passed!")
        logger.info(f"Final result: {result.data.get('action')}")
        
    except Exception as e:
        logger.info(f"Module.function notation test failed (expected): {e}")
        # This might fail depending on how the module is imported


def test_mixed_callable_and_string():
    """Test mixing callable functions and string references."""
    logger.info("Testing mixed callable and string functions...")
    
    agent = create_simple_sync_agent(
        functions=[module_perceive],
        workflow_id="mixed_test"
    )
    
    # Mix callable and string references
    dynamic_input = {
        "input": "mixed_test_data",
        "functions": [
            module_perceive,  # Callable
            "__main__.module_reason",  # String
            module_plan,  # Callable
            "__main__.module_act"  # String
        ]
    }
    
    try:
        result = agent.execute(dynamic_input)
        
        # Verify execution
        assert result.data.get("action") is not None
        
        logger.info("✅ Mixed callable and string test passed!")
        logger.info(f"Final result: {result.data.get('action')}")
        
    except Exception as e:
        logger.error(f"Mixed test failed: {e}")
        raise


def test_error_handling_for_invalid_strings():
    """Test error handling for invalid string function references."""
    logger.info("Testing error handling for invalid strings...")
    
    agent = create_simple_sync_agent(
        functions=[module_perceive],
        workflow_id="error_test"
    )
    
    # Test invalid module
    try:
        invalid_input = {
            "input": "error_test",
            "functions": ["nonexistent_module.some_function"]
        }
        agent.execute(invalid_input)
        assert False, "Should have raised ValueError"
    except ValueError as e:
        logger.info(f"✅ Caught expected error for invalid module: {e}")
    
    # Test invalid function name
    try:
        invalid_input = {
            "input": "error_test",
            "functions": ["__main__.nonexistent_function"]
        }
        agent.execute(invalid_input)
        assert False, "Should have raised ValueError"
    except ValueError as e:
        logger.info(f"✅ Caught expected error for invalid function: {e}")


def test_backward_compatibility():
    """Test that existing callable-based usage still works."""
    logger.info("Testing backward compatibility...")
    
    agent = create_simple_sync_agent(
        functions=[module_perceive, module_reason],
        workflow_id="backward_test"
    )
    
    # Test normal execution (no dynamic config)
    result1 = agent.execute("backward_test_1")
    assert result1.data.get("reasoning") is not None
    
    # Test with callable functions in dynamic config
    dynamic_input = {
        "input": "backward_test_2",
        "functions": [module_perceive, module_reason, module_plan, module_act]
    }
    
    result2 = agent.execute(dynamic_input)
    assert result2.data.get("action") is not None
    
    logger.info("✅ Backward compatibility test passed!")


if __name__ == "__main__":
    logger.info("Running String Function Resolution Tests")
    logger.info("=" * 45)
    
    try:
        test_string_function_resolution()
        test_module_dot_notation()
        test_mixed_callable_and_string()
        test_error_handling_for_invalid_strings()
        test_backward_compatibility()
        
        logger.info("\n🎉 All string function resolution tests passed!")
        
    except Exception as e:
        logger.error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()