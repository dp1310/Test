"""Demonstration of string-based function resolution support."""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from agent_sdk.agent import create_simple_sync_agent
from agent_sdk.core.stages import perceive, reason, plan, act
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# Define some example functions
@perceive
def my_perceive_func(context):
    """Example perceive function."""
    input_data = context.get("input", "")
    logger.info(f"Perceiving: {input_data}")
    return {"perceived": f"perceived_{input_data}"}


@reason
def my_reason_func(context):
    """Example reason function."""
    perceived = context.get("perceived", "")
    logger.info(f"Reasoning: {perceived}")
    return {"reasoning": f"reasoned_{perceived}"}


@plan
def my_plan_func(context):
    """Example plan function."""
    reasoning = context.get("reasoning", "")
    logger.info(f"Planning: {reasoning}")
    return {"plan": f"planned_{reasoning}"}


@act
def my_act_func(context):
    """Example act function."""
    plan = context.get("plan", "")
    logger.info(f"Acting: {plan}")
    return {"action": f"executed_{plan}"}


def demo_callable_functions():
    """Demo using callable function objects (original format)."""
    logger.info("\n=== Demo 1: Callable Functions ===")
    
    agent = create_simple_sync_agent(
        functions=[my_perceive_func],
        workflow_id="callable_demo"
    )
    
    # Original format - callable functions
    dynamic_input = {
        "input": "test_data",
        "functions": [my_perceive_func, my_reason_func, my_plan_func, my_act_func]
    }
    
    result = agent.execute(dynamic_input)
    logger.info(f"✅ Result: {result.data.get('action')}")


def demo_string_functions():
    """Demo using string function references (new format)."""
    logger.info("\n=== Demo 2: String Function References ===")
    
    agent = create_simple_sync_agent(
        functions=[my_perceive_func],
        workflow_id="string_demo"
    )
    
    # New format - string references to functions
    current_module = __name__
    dynamic_input = {
        "input": "test_data",
        "functions": [
            f"{current_module}.my_perceive_func",
            f"{current_module}.my_reason_func", 
            f"{current_module}.my_plan_func",
            f"{current_module}.my_act_func"
        ]
    }
    
    result = agent.execute(dynamic_input)
    logger.info(f"✅ Result: {result.data.get('action')}")


def demo_mixed_format():
    """Demo mixing callable and string references."""
    logger.info("\n=== Demo 3: Mixed Format ===")
    
    agent = create_simple_sync_agent(
        functions=[my_perceive_func],
        workflow_id="mixed_demo"
    )
    
    # Mixed format - some callable, some string
    current_module = __name__
    dynamic_input = {
        "input": "test_data",
        "functions": [
            my_perceive_func,  # Callable
            f"{current_module}.my_reason_func",  # String
            my_plan_func,  # Callable
            f"{current_module}.my_act_func"  # String
        ]
    }
    
    result = agent.execute(dynamic_input)
    logger.info(f"✅ Result: {result.data.get('action')}")


def demo_cross_module_references():
    """Demo referencing functions from other modules."""
    logger.info("\n=== Demo 4: Cross-Module References ===")
    
    try:
        # Import functions from another example module
        from dynamic_config_example import basic_perceive, basic_reason, basic_plan, basic_act
        
        agent = create_simple_sync_agent(
            functions=[basic_perceive],
            workflow_id="cross_module_demo"
        )
        
        # Reference functions from another module using strings
        dynamic_input = {
            "input": "test_data",
            "functions": [
                "dynamic_config_example.basic_perceive",
                "dynamic_config_example.basic_reason",
                "dynamic_config_example.basic_plan",
                "dynamic_config_example.basic_act"
            ]
        }
        
        result = agent.execute(dynamic_input)
        logger.info(f"✅ Cross-module result: {result.data.get('action')}")
        
    except ImportError as e:
        logger.info(f"Cross-module demo skipped: {e}")


def main():
    """Run all demonstrations."""
    logger.info("String Function Resolution Demonstration")
    logger.info("=" * 45)
    
    demo_callable_functions()
    demo_string_functions()
    demo_mixed_format()
    demo_cross_module_references()
    
    logger.info("\n📋 Summary:")
    logger.info("✅ Both formats are now supported:")
    logger.info("   • Callable functions: [my_func1, my_func2]")
    logger.info("   • String references: ['module.my_func1', 'module.my_func2']")
    logger.info("   • Mixed format: [my_func1, 'module.my_func2']")
    logger.info("✅ Cross-module references work with string format")
    logger.info("✅ Backward compatibility maintained")


if __name__ == "__main__":
    main()