"""Example demonstrating custom agent implementation by extending PrefectSyncAgent."""

import sys
import os
import time
from typing import Any, Dict, List, Callable, Optional

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from agent_sdk.agent import PrefectSyncAgent, AgentFactory, AgentType
from agent_sdk.core.stages import perceive, reason, plan, act, Stage
from agent_sdk.core.context import Context
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging to see output
setup_logging(level="INFO")
logger = get_logger(__name__)


class EnhancedPrefectAgent(PrefectSyncAgent):
    """
    Custom agent extending PrefectSyncAgent with additional features.
    
    This agent adds:
    - Execution timing and metrics
    - Custom validation
    - Enhanced logging
    - Pre/post execution hooks
    """
    
    def __init__(
        self,
        functions: Optional[List[Callable]] = None,
        initial_context: Optional[Dict[str, Any]] = None,
        concurrent: Optional[Dict[Stage, bool]] = None,
        workflow_id: Optional[str] = None,
        enable_metrics: bool = True,
        max_execution_time: Optional[float] = None
    ):
        """
        Initialize enhanced agent with additional configuration.
        
        Args:
            functions: List of stage functions
            initial_context: Initial context data
            concurrent: Stage-level concurrency settings
            workflow_id: Unique identifier for workflow monitoring
            enable_metrics: Whether to collect execution metrics
            max_execution_time: Maximum allowed execution time in seconds
        """
        super().__init__(functions, initial_context, concurrent, workflow_id)
        self._enable_metrics = enable_metrics
        self._max_execution_time = max_execution_time
        self._execution_metrics = {}
        
        # Add custom validation
        self._validate_custom_configuration()
    
    def _validate_custom_configuration(self) -> None:
        """Validate custom agent configuration."""
        if self._max_execution_time is not None and self._max_execution_time <= 0:
            raise ValueError("max_execution_time must be positive")
        
        # Validate that we have functions for all stages if metrics are enabled
        if self._enable_metrics and self._functions:
            stages_present = set()
            for fn in self._functions:
                stage = getattr(fn, "_agent_stage", None)
                if stage:
                    stages_present.add(stage)
            
            logger.info(f"Agent configured with stages: {[s.name for s in stages_present]}")
    
    def _pre_execution_hook(self, input_data: Any) -> None:
        """Hook called before execution starts."""
        logger.info(f"Enhanced agent starting execution with input: {type(input_data).__name__}")
        
        if self._enable_metrics:
            self._execution_metrics = {
                "start_time": time.time(),
                "input_type": type(input_data).__name__,
                "function_count": len(self._functions),
                "stages": []
            }
    
    def _post_execution_hook(self, result: Context) -> None:
        """Hook called after execution completes."""
        if self._enable_metrics:
            end_time = time.time()
            execution_time = end_time - self._execution_metrics["start_time"]
            
            self._execution_metrics.update({
                "end_time": end_time,
                "execution_time": execution_time,
                "result_keys": list(result.data.keys()),
                "success": True
            })
            
            logger.info(f"Enhanced agent execution completed in {execution_time:.3f}s")
            
            # Check execution time limit
            if (self._max_execution_time is not None and 
                execution_time > self._max_execution_time):
                logger.warning(
                    f"Execution time {execution_time:.3f}s exceeded limit "
                    f"{self._max_execution_time}s"
                )
    
    def execute(self, input_data: Any) -> Context:
        """
        Execute the agentic workflow with enhanced features.
        
        Args:
            input_data: Input data for the workflow (may contain dynamic configuration)
            
        Returns:
            Final context after all stages
            
        Raises:
            TimeoutError: If execution exceeds max_execution_time
        """
        # Pre-execution hook (use original input_data for logging)
        self._pre_execution_hook(input_data)
        
        try:
            # Execute using parent implementation (which handles dynamic config)
            result = super().execute(input_data)
            
            # Post-execution hook
            self._post_execution_hook(result)
            
            return result
            
        except Exception as e:
            if self._enable_metrics:
                self._execution_metrics["success"] = False
                self._execution_metrics["error"] = str(e)
            
            logger.error(f"Enhanced agent execution failed: {e}")
            raise
    
    def get_execution_metrics(self) -> Dict[str, Any]:
        """Get execution metrics from the last run."""
        return self._execution_metrics.copy()
    
    def get_execution_type(self) -> str:
        """Get the execution type identifier."""
        return "enhanced_prefect_sync"
    
    def set_max_execution_time(self, max_time: float) -> "EnhancedPrefectAgent":
        """Set maximum execution time (fluent interface)."""
        if max_time <= 0:
            raise ValueError("max_execution_time must be positive")
        self._max_execution_time = max_time
        return self
    
    def enable_metrics(self, enabled: bool = True) -> "EnhancedPrefectAgent":
        """Enable or disable metrics collection (fluent interface)."""
        self._enable_metrics = enabled
        return self
    
    def __str__(self) -> str:
        """String representation."""
        return (
            f"EnhancedPrefectAgent("
            f"functions={len(self._functions)}, "
            f"metrics={self._enable_metrics}, "
            f"max_time={self._max_execution_time})"
        )


# Example stage functions for demonstration
@perceive
def enhanced_perceive(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced perceive stage with detailed logging."""
    input_data = context.get("input", {})
    logger.info(f"Enhanced perceiving: {input_data}")
    
    # Simulate some processing time
    time.sleep(0.1)
    
    return {
        "perceived_data": f"enhanced_processed_{input_data}",
        "perception_timestamp": time.time(),
        "perception_quality": "high"
    }


@reason
def enhanced_reason(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced reason stage with analysis metrics."""
    perceived = context.get("perceived_data", "")
    quality = context.get("perception_quality", "unknown")
    
    logger.info(f"Enhanced reasoning on: {perceived} (quality: {quality})")
    
    # Simulate reasoning time
    time.sleep(0.15)
    
    confidence = 0.95 if quality == "high" else 0.7
    
    return {
        "analysis": f"enhanced_analyzed_{perceived}",
        "confidence": confidence,
        "reasoning_method": "enhanced_algorithm",
        "analysis_timestamp": time.time()
    }


@plan
def enhanced_plan(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced plan stage with strategy selection."""
    analysis = context.get("analysis", "")
    confidence = context.get("confidence", 0.5)
    
    logger.info(f"Enhanced planning based on: {analysis} (confidence: {confidence})")
    
    # Simulate planning time
    time.sleep(0.1)
    
    # Choose strategy based on confidence
    strategy = "aggressive" if confidence > 0.8 else "conservative"
    
    return {
        "plan": f"enhanced_plan_for_{analysis}",
        "strategy": strategy,
        "plan_confidence": confidence,
        "plan_timestamp": time.time()
    }


@act
def enhanced_act(context: Dict[str, Any]) -> Dict[str, Any]:
    """Enhanced act stage with execution tracking."""
    plan = context.get("plan", "")
    strategy = context.get("strategy", "default")
    
    logger.info(f"Enhanced executing: {plan} (strategy: {strategy})")
    
    # Simulate execution time based on strategy
    execution_time = 0.2 if strategy == "aggressive" else 0.1
    time.sleep(execution_time)
    
    return {
        "result": f"enhanced_executed_{plan}",
        "execution_strategy": strategy,
        "execution_duration": execution_time,
        "execution_timestamp": time.time(),
        "success": True
    }


def demonstrate_custom_agent():
    """Demonstrate the custom enhanced agent."""
    logger.info("\n=== Custom Enhanced Agent Demo ===")
    
    # Create enhanced agent with custom configuration
    agent = EnhancedPrefectAgent(
        functions=[enhanced_perceive, enhanced_reason, enhanced_plan, enhanced_act],
        initial_context={"mode": "enhanced", "version": "1.0"},
        concurrent={Stage.REASON: True, Stage.PLAN: True},
        workflow_id="enhanced_demo",
        enable_metrics=True,
        max_execution_time=2.0
    )
    
    logger.info(f"Created agent: {agent}")
    logger.info(f"Agent type: {agent.get_execution_type()}")
    
    # Execute workflow
    result = agent.execute("enhanced_test_input")
    
    logger.info(f"\nExecution result keys: {list(result.data.keys())}")
    logger.info(f"Final result: {result.data.get('result')}")
    logger.info(f"Strategy used: {result.data.get('execution_strategy')}")
    logger.info(f"Success: {result.data.get('success')}")
    
    # Show metrics
    metrics = agent.get_execution_metrics()
    logger.info(f"\nExecution Metrics:")
    logger.info(f"  Execution time: {metrics.get('execution_time', 0):.3f}s")
    logger.info(f"  Function count: {metrics.get('function_count')}")
    logger.info(f"  Success: {metrics.get('success')}")
    logger.info(f"  Result keys: {metrics.get('result_keys')}")


def demonstrate_fluent_configuration():
    """Demonstrate fluent interface configuration."""
    logger.info("\n=== Fluent Configuration Demo ===")
    
    # Create agent using fluent interface
    agent = (EnhancedPrefectAgent()
             .add_function(enhanced_perceive)
             .add_function(enhanced_reason)
             .add_function(enhanced_plan)
             .add_function(enhanced_act)
             .set_initial_context({"fluent": True})
             .set_stage_concurrent(Stage.PERCEIVE, True)
             .set_max_execution_time(1.5)
             .enable_metrics(True)
             .set_workflow_id("fluent_enhanced"))
    
    logger.info(f"Fluent configured agent: {agent}")
    
    # Execute
    result = agent.execute("fluent_input")
    metrics = agent.get_execution_metrics()
    
    logger.info(f"Fluent execution time: {metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Fluent result success: {metrics.get('success')}")


def demonstrate_agent_cloning():
    """Demonstrate cloning the custom agent."""
    logger.info("\n=== Custom Agent Cloning Demo ===")
    
    # Create base enhanced agent
    base_agent = EnhancedPrefectAgent(
        functions=[enhanced_perceive, enhanced_reason],
        initial_context={"base": "enhanced"},
        enable_metrics=True,
        max_execution_time=1.0
    )
    
    # Clone and extend
    extended_agent = (base_agent.clone()
                     .add_function(enhanced_plan)
                     .add_function(enhanced_act)
                     .set_max_execution_time(2.0)
                     .update_initial_context({"extended": True}))
    
    logger.info(f"Base agent functions: {len(base_agent.functions)}")
    logger.info(f"Extended agent functions: {len(extended_agent.functions)}")
    
    # Execute both
    base_result = base_agent.execute("base_input")
    extended_result = extended_agent.execute("extended_input")
    
    base_metrics = base_agent.get_execution_metrics()
    extended_metrics = extended_agent.get_execution_metrics()
    
    logger.info(f"Base execution time: {base_metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Extended execution time: {extended_metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Base result keys: {len(base_result.data)}")
    logger.info(f"Extended result keys: {len(extended_result.data)}")


def demonstrate_error_handling():
    """Demonstrate error handling in custom agent."""
    logger.info("\n=== Error Handling Demo ===")
    
    @perceive
    def failing_perceive(context: Dict[str, Any]) -> Dict[str, Any]:
        """A perceive function that fails."""
        raise ValueError("Simulated perception failure")
    
    # Create agent with failing function
    agent = EnhancedPrefectAgent(
        functions=[failing_perceive, enhanced_reason],
        enable_metrics=True,
        workflow_id="error_demo"
    )
    
    try:
        result = agent.execute("error_input")
    except Exception as e:
        logger.info(f"Caught expected error: {e}")
        
        # Check metrics recorded the failure
        metrics = agent.get_execution_metrics()
        logger.info(f"Error recorded in metrics: {metrics.get('success')}")
        logger.info(f"Error message: {metrics.get('error')}")


def demonstrate_factory_registration():
    """Demonstrate registering custom agent with factory."""
    logger.info("\n=== Factory Registration Demo ===")
    
    # Create a custom agent type enum value
    class CustomAgentType:
        ENHANCED_PREFECT = "enhanced_prefect_sync"
    
    # Register the custom agent type (if we had extended the enum)
    # For demo purposes, we'll show how it would work
    logger.info(f"Available agent types before: {AgentFactory.get_available_types()}")
    
    # Create custom agent directly
    custom_agent = EnhancedPrefectAgent(
        functions=[enhanced_perceive, enhanced_reason, enhanced_plan, enhanced_act],
        enable_metrics=True,
        max_execution_time=1.0,
        workflow_id="factory_demo"
    )
    
    logger.info(f"Custom agent type: {custom_agent.get_execution_type()}")
    
    # Execute and show it works like any other agent
    result = custom_agent.execute("factory_test")
    metrics = custom_agent.get_execution_metrics()
    
    logger.info(f"Factory demo execution time: {metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Factory demo success: {metrics.get('success')}")


def main():
    """Main demonstration function."""
    logger.info("Custom Agent Framework Demonstration")
    logger.info("=" * 45)
    
    demonstrate_custom_agent()
    demonstrate_fluent_configuration()
    demonstrate_agent_cloning()
    demonstrate_error_handling()
    demonstrate_factory_registration()
    
    logger.info("\n=== Custom Agent Demo Complete ===")


if __name__ == "__main__":
    main()