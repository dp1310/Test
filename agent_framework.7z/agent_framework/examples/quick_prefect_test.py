"""Quick test of Prefect integration."""

import sys
import os
import logging

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, plan, act,
    agentic_spine, agentic_spine_simple,
    Context, get_logger, setup_logging
)
from prefect import task

# Fix logging setup - ensure logs are visible
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)

# Setup agent SDK logging
setup_logging(level="INFO")
logger = get_logger(__name__)

# Also set up root logger to ensure all logs are visible
root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)


@perceive
@task(name="prefect_analyze")
def prefect_analyze(ctx: dict) -> dict:
    """Prefect task for analysis."""
    text = ctx.get("input", {}).get("text", "")
    logger.info(f"[PREFECT TASK] Analyzing: {text}")
    return {"analyzed": True, "method": "prefect"}


@reason
def simple_reason(ctx) -> dict:
    """Simple reasoning function."""
    if isinstance(ctx, Context):
        analyzed = ctx.get("analyzed", False)
        method = ctx.get("method", "unknown")
    else:
        analyzed = ctx.get("analyzed", False)
        method = ctx.get("method", "unknown")
    
    logger.info(f"Reasoning with method: {method}")
    return {"decision": "approve" if analyzed else "reject"}


def main():
    """Quick test of both versions."""
    logger.info("🧪 Quick Prefect Integration Test")
    logger.info("=" * 40)
    
    # Test 1: Simple version
    logger.info("1. Testing simple version...")
    simple_result = agentic_spine_simple(
        input_data={"text": "test message"},
        functions=[
            lambda ctx: {"analyzed": True, "method": "simple"},
            simple_reason
        ]
    )
    logger.info(f"Simple result: {simple_result.get('decision')} via {simple_result.get('method')}")
    
    # Test 2: Prefect version
    logger.info("2. Testing Prefect version...")
    prefect_result = agentic_spine(
        input_data={"text": "test message"},
        functions=[prefect_analyze, simple_reason]
    )
    logger.info(f"Prefect result: {prefect_result.get('decision')} via {prefect_result.get('method')}")
    
    # Verification
    logger.info("✅ Verification:")
    logger.info(f"Both versions work: {simple_result.get('decision') == prefect_result.get('decision')}")
    logger.info(f"Prefect tasks executed: {prefect_result.get('method') == 'prefect'}")
    logger.info(f"Simple functions executed: {simple_result.get('method') == 'simple'}")
    
    logger.info("🎉 Prefect integration test completed successfully!")


if __name__ == "__main__":
    main()