# Installation Guide

## Quick Start

### Basic Installation

```bash
# Clone the repository
git clone <repository-url>
cd agent_framework

# Install core framework
pip install -e .
```

### Installation Options

#### 1. Core Framework Only
```bash
pip install -e .
```
Includes: Basic agentic workflows, Prefect integration, dynamic configuration

#### 2. With Development Tools
```bash
pip install -e ".[dev]"
```
Includes: Core + pytest, black, flake8, mypy, pre-commit

#### 3. With All Tools
```bash
pip install -e ".[all]"
```
Includes: Everything (LLMs, databases, APIs, notifications, dev tools)

#### 4. Selective Installation
```bash
# Just LLM tools
pip install -e ".[llm]"

# Just database tools  
pip install -e ".[database]"

# Just API tools
pip install -e ".[api]"

# Custom combination
pip install -e ".[llm,database,dev]"
```

## Available Optional Dependencies

### 🤖 LLM Tools (`[llm]`)
- **OpenAI**: GPT-3.5, GPT-4 with streaming
- **Google Gemini**: Gemini Pro with multimodal
- **Anthropic**: Claude 3 with large context
- **Mistral AI**: Mistral models with function calling

### 💾 Database Tools (`[database]`)
- **PostgreSQL**: Async connection pooling
- **Neo4j**: Graph database with Cypher
- **MongoDB**: Document operations with Motor

### 🌐 API Tools (`[api]`)
- **HTTP Client**: Full HTTP methods with auth
- **File Operations**: Async file handling

### 📢 Notification Tools (`[notifications]`)
- **Email**: SMTP with HTML support
- **Slack**: Webhook and Bot API

### 🛠️ Development Tools (`[dev]`)
- **Testing**: pytest, pytest-asyncio, pytest-cov
- **Code Quality**: black, flake8, mypy
- **Git Hooks**: pre-commit

## Configuration

### 1. Environment Variables

Create a `.env` file:

```bash
# Copy example file
cp .env.example .env

# Edit with your API keys
nano .env
```

Example `.env`:
```bash
# LLM API Keys
OPENAI_API_KEY=your_openai_key
GEMINI_API_KEY=your_gemini_key
ANTHROPIC_API_KEY=your_anthropic_key

# Database URLs
POSTGRES_URL=postgresql://user:pass@host:port/db
NEO4J_URI=bolt://localhost:7687
MONGODB_URI=mongodb://localhost:27017/db

# Notification Services
SLACK_WEBHOOK_URL=https://hooks.slack.com/...
SMTP_SERVER=smtp.gmail.com
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password
```

### 2. Tools Configuration

The framework will automatically create `config/tools.yaml` on first run, or you can create it manually:

```yaml
tools:
  openai:
    type: llm
    enabled: true
    config:
      api_key: ${OPENAI_API_KEY}
      model: gpt-3.5-turbo
      max_tokens: 1000
  
  postgresql:
    type: database
    enabled: true
    config:
      url: ${POSTGRES_URL}
      pool_size: 10
```

## Verification

### Test Installation

```bash
# Test core framework
python -c "from agent_sdk import perceive, reason, plan, act; print('✅ Core framework installed')"

# Test tools (if installed)
python -c "from agent_sdk.tools import tool_hook; print('✅ Tools system installed')"

# Run example
python examples/simple_string_usage.py
```

### Run Tests

```bash
# Install with dev dependencies first
pip install -e ".[dev]"

# Run all tests
pytest

# Run with coverage
pytest --cov=agent_sdk --cov-report=html

# Run specific test categories
pytest -m "not tools"  # Skip tools tests
pytest -m "not llm"    # Skip LLM tests
```

## Troubleshooting

### Common Issues

#### 1. Import Errors
```bash
# Make sure you're in the right directory
cd agent_framework

# Install in editable mode
pip install -e .
```

#### 2. Missing Dependencies
```bash
# Install specific tool dependencies
pip install -e ".[llm]"  # For LLM tools
pip install -e ".[database]"  # For database tools
```

#### 3. Environment Variables Not Loading
```bash
# Check .env file exists
ls -la .env

# Test loading
python -c "from dotenv import load_dotenv; load_dotenv(); import os; print(os.getenv('OPENAI_API_KEY'))"
```

#### 4. Tools Configuration Issues
```bash
# Check config directory
ls -la config/

# Validate YAML syntax
python -c "import yaml; yaml.safe_load(open('config/tools.yaml'))"
```

### Getting Help

1. **Check Examples**: Look at `examples/` directory for working code
2. **Read Documentation**: See README.md for comprehensive guide
3. **Run Tests**: Use `pytest -v` to see detailed test output
4. **Check Logs**: Enable debug logging in your code

### Development Setup

```bash
# Full development setup
git clone <repository-url>
cd agent_framework

# Install with all dependencies
pip install -e ".[all]"

# Install pre-commit hooks
pre-commit install

# Run tests to verify setup
pytest

# Format code
black .

# Type check
mypy agent_sdk/
```

## Next Steps

1. **Read the README**: Comprehensive guide with examples
2. **Try Examples**: Start with `examples/simple_string_usage.py`
3. **Configure Tools**: Set up API keys for the tools you need
4. **Build Your First Agent**: Follow the quick start guide

Happy building! 🚀