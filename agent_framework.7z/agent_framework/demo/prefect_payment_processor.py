"""Payment processing demo using Prefect-powered agent SDK."""

from typing import Dict, Any
from prefect import task

import sys
import os
# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import perceive, reason, plan, act, agentic_spine, Context, get_logger, Stage

logger = get_logger(__name__)


class PrefectPaymentProcessor:
    """Payment processor using Prefect-powered agentic workflow."""
    
    @staticmethod
    @perceive
    @task(name="analyze_payment_text")
    def analyze_text(ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze payment text for key information (Prefect task)."""
        text = str(ctx.get("input", {}).get("text", ""))
        logger.info(f"[PREFECT TASK] Analyzing payment text: {text[:50]}...")
        
        return {
            "text_length": len(text),
            "has_iban": "IBAN" in text.upper(),
            "has_amount": ("€" in text) or ("EUR" in text.upper()),
            "original_text": text,
            "processed_by": "prefect_task"
        }
    
    @staticmethod
    @perceive
    @task(name="detect_currency")
    def detect_currency(ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Detect currency in payment text (Prefect task)."""
        text = str(ctx.get("input", {}).get("text", ""))
        
        currency_map = {
            "€": "EUR",
            "EUR": "EUR", 
            "$": "USD",
            "USD": "USD",
            "£": "GBP",
            "GBP": "GBP"
        }
        
        detected_currency = "UNKNOWN"
        for symbol, code in currency_map.items():
            if symbol in text.upper():
                detected_currency = code
                break
                
        logger.info(f"[PREFECT TASK] Detected currency: {detected_currency}")
        return {
            "currency": detected_currency,
            "currency_confidence": 0.95 if detected_currency != "UNKNOWN" else 0.1
        }
    
    @staticmethod
    @perceive
    @task(name="extract_amount")
    def extract_amount(ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Extract amount from payment text (Prefect task)."""
        text = str(ctx.get("input", {}).get("text", ""))
        
        import re
        
        # Simple amount extraction patterns
        patterns = [
            r'€(\d+(?:\.\d{2})?)',
            r'(\d+(?:\.\d{2})?) EUR',
            r'\$(\d+(?:\.\d{2})?)',
            r'(\d+(?:\.\d{2})?) USD'
        ]
        
        extracted_amount = None
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                extracted_amount = float(match.group(1))
                break
        
        logger.info(f"[PREFECT TASK] Extracted amount: {extracted_amount}")
        return {
            "extracted_amount": extracted_amount,
            "amount_found": extracted_amount is not None
        }
    
    @staticmethod
    @reason
    @task(name="assess_payment_risk")
    def assess_payment(ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Assess if payment needs review (Prefect task)."""
        has_iban = ctx.get("has_iban", False)
        has_amount = ctx.get("has_amount", False) 
        text_length = ctx.get("text_length", 0)
        currency = ctx.get("currency", "UNKNOWN")
        extracted_amount = ctx.get("extracted_amount", 0)
        
        risk_factors = []
        if not has_iban:
            risk_factors.append("missing_iban")
        if not has_amount:
            risk_factors.append("missing_amount")
        if text_length < 10:
            risk_factors.append("text_too_short")
        if currency == "UNKNOWN":
            risk_factors.append("unknown_currency")
        if extracted_amount and extracted_amount > 10000:
            risk_factors.append("high_amount")
        
        needs_review = len(risk_factors) > 0
        risk_score = len(risk_factors) * 0.25
        confidence = 1.0 - risk_score
        
        logger.info(f"[PREFECT TASK] Risk assessment - score: {risk_score}, needs_review: {needs_review}")
        
        return {
            "needs_review": needs_review,
            "risk_score": risk_score,
            "risk_factors": risk_factors,
            "confidence": confidence,
            "assessment_reason": _get_assessment_reason(risk_factors)
        }
    
    @staticmethod
    @plan
    @task(name="create_action_plan")
    def create_action_plan(ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Create action plan based on assessment (Prefect task)."""
        needs_review = ctx.get("needs_review", True)
        risk_score = ctx.get("risk_score", 1.0)
        confidence = ctx.get("confidence", 0.0)
        extracted_amount = ctx.get("extracted_amount", 0)
        
        if needs_review:
            if risk_score > 0.75:
                steps = ["escalate_to_senior_reviewer", "freeze_transaction", "notify_compliance"]
                priority = "CRITICAL"
            elif risk_score > 0.5:
                steps = ["route_to_manual_review", "request_additional_info"]
                priority = "HIGH"
            else:
                steps = ["route_to_standard_review"]
                priority = "MEDIUM"
        else:
            steps = ["validate_iban_format", "check_blacklist", "auto_approve", "queue_for_processing"]
            priority = "LOW"
        
        # Add amount-specific steps
        if extracted_amount and extracted_amount > 5000:
            steps.insert(-1, "additional_verification")
        
        logger.info(f"[PREFECT TASK] Created plan with {len(steps)} steps, priority: {priority}")
        
        return {
            "action_steps": steps,
            "priority": priority,
            "estimated_processing_time": len(steps) * 30,  # seconds
            "plan_confidence": confidence
        }
    
    @staticmethod
    @act
    @task(name="execute_actions")
    def execute_actions(ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the planned actions (Prefect task)."""
        steps = ctx.get("action_steps", [])
        priority = ctx.get("priority", "MEDIUM")
        
        executed_actions = []
        for step in steps:
            action_result = {
                "step": step,
                "status": "COMPLETED",
                "timestamp": "2024-01-01T00:00:00Z",  # In real implementation, use actual timestamp
                "executor": "prefect_task"
            }
            executed_actions.append(action_result)
            logger.info(f"[PREFECT TASK] Executed action: {step}")
        
        return {
            "executed_actions": executed_actions,
            "execution_status": "ALL_COMPLETED",
            "final_priority": priority,
            "total_actions": len(executed_actions)
        }
    
    def process_payment(self, payment_text: str) -> Context:
        """Process a payment using the Prefect-powered agentic workflow."""
        logger.info("Starting Prefect-powered payment processing workflow")
        
        functions = [
            self.analyze_text,
            self.detect_currency,
            self.extract_amount,
            self.assess_payment,
            self.create_action_plan,
            self.execute_actions
        ]
        
        # Use Prefect-powered agentic spine
        result = agentic_spine(
            input_data={"text": payment_text},
            functions=functions,
            concurrent={
                Stage.PERCEIVE: True,  # Run all perception tasks concurrently using Prefect
                Stage.REASON: False,   # Sequential reasoning
                Stage.PLAN: False,     # Sequential planning
                Stage.ACT: False       # Sequential actions
            }
        )
        
        logger.info("Prefect-powered payment processing workflow completed")
        return result


def _get_assessment_reason(risk_factors: list) -> str:
    """Get human-readable assessment reason."""
    if not risk_factors:
        return "all checks passed"
    
    return f"failed checks: {', '.join(risk_factors)}"


# Demo usage
if __name__ == "__main__":
    from agent_sdk.utils.logging import setup_logging
    
    setup_logging(level="INFO")
    
    processor = PrefectPaymentProcessor()
    
    # Test case 1: Valid payment with concurrent perception
    logger.info("=== Test 1: Valid Payment (Concurrent Perception) ===")
    result1 = processor.process_payment("Pay €1000 to IBAN DE89 3704 0044 0532 0130 00")
    logger.info(f"Result 1 - Status: {result1.get('execution_status')}")
    logger.info(f"Result 1 - Priority: {result1.get('final_priority')}")
    logger.info(f"Result 1 - Risk Score: {result1.get('risk_score')}")
    logger.info(f"Result 1 - Actions: {len(result1.get('executed_actions', []))}")
    
    logger.info("\n" + "="*50)
    
    # Test case 2: Invalid payment
    logger.info("=== Test 2: Invalid Payment ===")
    result2 = processor.process_payment("Pay money")
    logger.info(f"Result 2 - Status: {result2.get('execution_status')}")
    logger.info(f"Result 2 - Priority: {result2.get('final_priority')}")
    logger.info(f"Result 2 - Risk Factors: {result2.get('risk_factors')}")
    logger.info(f"Result 2 - Actions: {len(result2.get('executed_actions', []))}")
    
    logger.info("\n" + "="*50)
    
    # Test case 3: High amount payment
    logger.info("=== Test 3: High Amount Payment ===")
    result3 = processor.process_payment("Pay €15000 to IBAN DE89 3704 0044 0532 0130 00")
    logger.info(f"Result 3 - Status: {result3.get('execution_status')}")
    logger.info(f"Result 3 - Priority: {result3.get('final_priority')}")
    logger.info(f"Result 3 - Risk Score: {result3.get('risk_score')}")
    logger.info(f"Result 3 - Has Additional Verification: {'additional_verification' in str(result3.get('action_steps', []))}")
    
    logger.info("\n=== Prefect Demo Completed ===")
    logger.info("All payments processed using Prefect tasks with concurrent execution!")