"""Async payment processing demo using the agent SDK."""

import asyncio
from typing import Dict, Any
import sys
import os

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)


from agent_sdk import perceive, reason, plan, act, agentic_spine_async, Context, get_logger, Stage

logger = get_logger(__name__)


class AsyncPaymentProcessor:
    """Async demo payment processor using agentic workflow."""
    
    @staticmethod
    @perceive
    async def analyze_text_async(ctx: Context) -> Dict[str, Any]:
        """Asynchronously analyze payment text."""
        text = str(ctx.get("input", {}).get("text", ""))
        logger.info(f"Async analyzing payment text: {text[:50]}...")
        
        # Simulate async processing
        await asyncio.sleep(0.1)
        
        return {
            "text_length": len(text),
            "has_iban": "IBAN" in text.upper(),
            "has_amount": ("€" in text) or ("EUR" in text.upper()),
            "original_text": text,
            "processing_mode": "async"
        }
    
    @staticmethod
    @perceive
    async def detect_currency_async(ctx: Context) -> Dict[str, Any]:
        """Asynchronously detect currency."""
        text = str(ctx.get("input", {}).get("text", ""))
        
        # Simulate async API call
        await asyncio.sleep(0.05)
        
        currency_patterns = {
            "€": "EUR", "EUR": "EUR",
            "$": "USD", "USD": "USD", 
            "£": "GBP", "GBP": "GBP"
        }
        
        detected_currency = "UNKNOWN"
        for pattern, code in currency_patterns.items():
            if pattern in text.upper():
                detected_currency = code
                break
        
        logger.info(f"Async detected currency: {detected_currency}")
        return {
            "currency": detected_currency,
            "currency_confidence": 0.95 if detected_currency != "UNKNOWN" else 0.1
        }
    
    @staticmethod
    @perceive
    async def extract_amount_async(ctx: Context) -> Dict[str, Any]:
        """Asynchronously extract amount from text."""
        text = str(ctx.get("input", {}).get("text", ""))
        
        # Simulate async processing
        await asyncio.sleep(0.08)
        
        import re
        
        # Simple amount extraction patterns
        patterns = [
            r'€(\d+(?:\.\d{2})?)',
            r'(\d+(?:\.\d{2})?) EUR',
            r'\$(\d+(?:\.\d{2})?)',
            r'(\d+(?:\.\d{2})?) USD'
        ]
        
        extracted_amount = None
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                extracted_amount = float(match.group(1))
                break
        
        logger.info(f"Async extracted amount: {extracted_amount}")
        return {
            "extracted_amount": extracted_amount,
            "amount_found": extracted_amount is not None
        }
    
    @staticmethod
    @reason
    async def assess_payment_async(ctx: Context) -> Dict[str, Any]:
        """Asynchronously assess payment risk."""
        has_iban = ctx.get("has_iban", False)
        has_amount = ctx.get("has_amount", False)
        amount_found = ctx.get("amount_found", False)
        extracted_amount = ctx.get("extracted_amount", 0)
        currency = ctx.get("currency", "UNKNOWN")
        
        # Simulate async risk assessment
        await asyncio.sleep(0.2)
        
        risk_factors = []
        if not has_iban:
            risk_factors.append("missing_iban")
        if not has_amount or not amount_found:
            risk_factors.append("missing_amount")
        if extracted_amount and extracted_amount > 10000:
            risk_factors.append("high_amount")
        if currency == "UNKNOWN":
            risk_factors.append("unknown_currency")
        
        risk_score = len(risk_factors) * 0.25
        needs_review = risk_score > 0.5
        
        logger.info(f"Async risk assessment - score: {risk_score}, needs_review: {needs_review}")
        
        return {
            "risk_score": risk_score,
            "risk_factors": risk_factors,
            "needs_review": needs_review,
            "assessment_timestamp": asyncio.get_event_loop().time()
        }
    
    @staticmethod
    @plan
    async def create_action_plan_async(ctx: Context) -> Dict[str, Any]:
        """Asynchronously create action plan."""
        needs_review = ctx.get("needs_review", True)
        risk_score = ctx.get("risk_score", 1.0)
        extracted_amount = ctx.get("extracted_amount", 0)
        
        # Simulate async planning
        await asyncio.sleep(0.1)
        
        if needs_review:
            if risk_score > 0.75:
                steps = ["escalate_to_senior_reviewer", "freeze_transaction", "notify_compliance"]
                priority = "CRITICAL"
            else:
                steps = ["route_to_manual_review", "request_additional_info"]
                priority = "HIGH"
        else:
            steps = ["validate_iban_format", "check_blacklist", "auto_approve", "queue_for_processing"]
            priority = "NORMAL"
        
        # Add amount-specific steps
        if extracted_amount and extracted_amount > 5000:
            steps.insert(-1, "additional_verification")
        
        logger.info(f"Async created plan with {len(steps)} steps, priority: {priority}")
        
        return {
            "action_steps": steps,
            "priority": priority,
            "estimated_completion_time": len(steps) * 45,
            "plan_created_at": asyncio.get_event_loop().time()
        }
    
    @staticmethod
    @act
    async def execute_actions_async(ctx: Context) -> Dict[str, Any]:
        """Asynchronously execute planned actions."""
        steps = ctx.get("action_steps", [])
        priority = ctx.get("priority", "NORMAL")
        
        executed_actions = []
        execution_times = []
        
        for i, step in enumerate(steps):
            # Simulate async execution with varying delays
            delay = 0.05 * (i + 1)
            await asyncio.sleep(delay)
            
            execution_time = asyncio.get_event_loop().time()
            action_result = {
                "step": step,
                "status": "COMPLETED",
                "execution_time": execution_time,
                "delay": delay
            }
            
            executed_actions.append(action_result)
            execution_times.append(execution_time)
            logger.info(f"Async executed: {step}")
        
        return {
            "executed_actions": executed_actions,
            "execution_status": "ALL_COMPLETED",
            "total_execution_time": sum(execution_times),
            "final_priority": priority,
            "completion_timestamp": asyncio.get_event_loop().time()
        }
    
    async def process_payment_async(self, payment_text: str) -> Context:
        """Asynchronously process a payment using the agentic workflow."""
        logger.info("Starting async payment processing workflow")
        
        functions = [
            self.analyze_text_async,
            self.detect_currency_async,
            self.extract_amount_async,
            self.assess_payment_async,
            self.create_action_plan_async,
            self.execute_actions_async
        ]
        
        result = await agentic_spine_async(
            input_data={"text": payment_text},
            functions=functions,
            concurrent={
                Stage.PERCEIVE: True,  # Run all perception stages concurrently
                Stage.REASON: False,     # Reasoning should be sequential
                Stage.PLAN: False,         # Planning should be sequential  
                Stage.ACT: False            # Actions should be sequential
            }
        )
        
        logger.info("Async payment processing workflow completed")
        return result


# Demo usage
async def main():
    """Demo async payment processing."""
    from agent_sdk.utils.logging import setup_logging
    
    setup_logging(level="INFO")
    
    processor = AsyncPaymentProcessor()
    
    # Test concurrent processing of multiple payments
    payments = [
        "Pay €1000 to IBAN DE89 3704 0044 0532 0130 00",
        "Transfer $5000 USD to account",
        "Send £250 to IBAN GB82 WEST 1234 5698 7654 32",
        "Invalid payment request"
    ]
    
    # Process all payments concurrently
    tasks = [processor.process_payment_async(payment) for payment in payments]
    results = await asyncio.gather(*tasks)
    
    for i, result in enumerate(results):
        logger.info(f"Payment {i+1} result: {result.get('execution_status', 'UNKNOWN')}")
        logger.info(f"Priority: {result.get('final_priority', 'UNKNOWN')}")


if __name__ == "__main__":
    asyncio.run(main())