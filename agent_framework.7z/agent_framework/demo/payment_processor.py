"""Payment processing demo using the agent SDK."""

from typing import Dict, Any
import sys
import os
import asyncio

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)


from agent_sdk import perceive, reason, plan, act, agentic_spine_simple, Context, get_logger, Stage

logger = get_logger(__name__)


class PaymentProcessor:
    """Demo payment processor using agentic workflow."""
    
    @staticmethod
    @perceive
    def analyze_text(ctx: Context) -> Dict[str, Any]:
        """Analyze payment text for key information."""
        text = str(ctx.get("input", {}).get("text", ""))
        logger.info(f"Analyzing payment text: {text[:50]}...")
        
        return {
            "text_length": len(text),
            "has_iban": "IBAN" in text.upper(),
            "has_amount": ("€" in text) or ("EUR" in text.upper()),
            "original_text": text
        }
    
    @staticmethod
    @perceive  
    def detect_currency(ctx: Context) -> Dict[str, Any]:
        """Detect currency in payment text."""
        text = str(ctx.get("input", {}).get("text", ""))
        
        currency_map = {
            "€": "EUR",
            "EUR": "EUR", 
            "$": "USD",
            "USD": "USD",
            "£": "GBP",
            "GBP": "GBP"
        }
        
        detected_currency = "UNKNOWN"
        for symbol, code in currency_map.items():
            if symbol in text.upper():
                detected_currency = code
                break
                
        logger.info(f"Detected currency: {detected_currency}")
        return {"currency": detected_currency}
    
    @staticmethod
    @reason
    def assess_payment(ctx: Context) -> Dict[str, Any]:
        """Assess if payment needs review."""
        has_iban = ctx.get("has_iban", False)
        has_amount = ctx.get("has_amount", False) 
        text_length = ctx.get("text_length", 0)
        currency = ctx.get("currency", "UNKNOWN")
        
        needs_review = (
            not has_iban or 
            not has_amount or 
            text_length < 10 or
            currency == "UNKNOWN"
        )
        
        confidence = 0.9 if not needs_review else 0.3
        
        logger.info(f"Payment assessment - needs_review: {needs_review}, confidence: {confidence}")
        
        return {
            "needs_review": needs_review,
            "confidence": confidence,
            "assessment_reason": _get_assessment_reason(has_iban, has_amount, text_length, currency)
        }
    
    @staticmethod
    @plan
    def create_action_plan(ctx: Context) -> Dict[str, Any]:
        """Create action plan based on assessment."""
        needs_review = ctx.get("needs_review", True)
        confidence = ctx.get("confidence", 0.0)
        
        if needs_review:
            steps = ["route_to_manual_review", "notify_compliance_team"]
            priority = "HIGH" if confidence < 0.2 else "MEDIUM"
        else:
            steps = ["validate_iban", "check_fraud_rules", "auto_approve", "initiate_payment"]
            priority = "LOW"
        
        logger.info(f"Created action plan with {len(steps)} steps, priority: {priority}")
        
        return {
            "action_steps": steps,
            "priority": priority,
            "estimated_processing_time": len(steps) * 30  # seconds
        }
    
    @staticmethod
    @act
    def execute_actions(ctx: Context) -> Dict[str, Any]:
        """Execute the planned actions."""
        steps = ctx.get("action_steps", [])
        priority = ctx.get("priority", "MEDIUM")
        
        executed_actions = []
        for step in steps:
            action_result = f"EXECUTED: {step}"
            executed_actions.append(action_result)
            logger.info(f"Executed action: {step}")
        
        return {
            "executed_actions": executed_actions,
            "execution_status": "COMPLETED",
            "final_priority": priority
        }
    
    def process_payment(self, payment_text: str) -> Context:
        """Process a payment using the agentic workflow."""
        logger.info("Starting payment processing workflow")
        
        functions = [
            self.analyze_text,
            self.detect_currency, 
            self.assess_payment,
            self.create_action_plan,
            self.execute_actions
        ]
        
        result = agentic_spine_simple(
            input_data={"text": payment_text},
            functions=functions,
            concurrent={Stage.PERCEIVE: True}  # Run perception stages concurrently
        )
        
        logger.info("Payment processing workflow completed")
        return result


def _get_assessment_reason(has_iban: bool, has_amount: bool, text_length: int, currency: str) -> str:
    """Get human-readable assessment reason."""
    reasons = []
    
    if not has_iban:
        reasons.append("missing IBAN")
    if not has_amount:
        reasons.append("missing amount")
    if text_length < 10:
        reasons.append("text too short")
    if currency == "UNKNOWN":
        reasons.append("unknown currency")
    
    if not reasons:
        return "all checks passed"
    
    return f"failed checks: {', '.join(reasons)}"


# Demo usage
if __name__ == "__main__":
    from agent_sdk.utils.logging import setup_logging
    
    setup_logging(level="INFO")
    
    processor = PaymentProcessor()
    
    # Test case 1: Valid payment
    result1 = processor.process_payment("Pay €1000 to IBAN DE89 3704 0044 0532 0130 00")
    logger.info(f"Result 1: {result1.data}")
    
    # Test case 2: Invalid payment
    result2 = processor.process_payment("Pay money")
    logger.info(f"Result 2: {result2.data}")