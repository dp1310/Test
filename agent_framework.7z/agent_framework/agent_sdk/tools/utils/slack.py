"""Slack tool with functional programming approach."""

import json
import logging
from typing import Any, Dict, List, Optional
from ..base import Tool, ToolResult, ToolStatus, ToolError

logger = logging.getLogger(__name__)

# Constants
AIOHTTP_MISSING_ERROR = "aiohttp library not installed. Run: pip install aiohttp"


# Pure functions for Slack operations
def _validate_slack_config(webhook_url: str, bot_token: str, token: str) -> bool:
    """Validate Slack configuration parameters."""
    return bool(webhook_url or bot_token or token)


def _create_webhook_payload(message: str, username: str = None, 
                           icon_emoji: str = None, attachments: List[Dict] = None) -> Dict[str, Any]:
    """Create payload for Slack webhook."""
    payload = {
        "text": message,
        "username": username,
        "icon_emoji": icon_emoji,
        "attachments": attachments
    }
    # Remove None values
    return {k: v for k, v in payload.items() if v is not None}


def _create_bot_api_data(channel: str, message: str, username: str = None,
                        icon_emoji: str = None, attachments: List[Dict] = None) -> Dict[str, Any]:
    """Create data for Slack Bot API."""
    data = {
        "channel": channel,
        "text": message,
        "username": username,
        "icon_emoji": icon_emoji,
        "attachments": json.dumps(attachments) if attachments else None
    }
    # Remove None values
    return {k: v for k, v in data.items() if v is not None}


def _create_auth_headers(token: str) -> Dict[str, str]:
    """Create authorization headers for Slack API."""
    return {"Authorization": f"Bearer {token}"}


def _create_webhook_result() -> Dict[str, Any]:
    """Create result data for webhook send."""
    return {"sent": True, "method": "webhook"}


def _create_bot_api_result(ts: str = None) -> Dict[str, Any]:
    """Create result data for bot API send."""
    result = {"sent": True, "method": "bot_api"}
    if ts:
        result["ts"] = ts
    return result


async def _send_via_webhook(webhook_url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Send message via Slack webhook."""
    try:
        import aiohttp
    except ImportError:
        raise ToolError(AIOHTTP_MISSING_ERROR)
    
    async with aiohttp.ClientSession() as session:
        async with session.post(webhook_url, json=payload) as response:
            if response.status == 200:
                return _create_webhook_result()
            else:
                error_text = await response.text()
                raise ToolError(f"Slack webhook error: {response.status} - {error_text}")


async def _send_via_bot_api(token: str, data: Dict[str, Any]) -> Dict[str, Any]:
    """Send message via Slack Bot API."""
    try:
        import aiohttp
    except ImportError:
        raise ToolError(AIOHTTP_MISSING_ERROR)
    
    url = "https://slack.com/api/chat.postMessage"
    headers = _create_auth_headers(token)
    
    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, data=data) as response:
            result = await response.json()
            
            if result.get("ok"):
                return _create_bot_api_result(result.get("ts"))
            else:
                raise ToolError(f"Slack API error: {result.get('error')}")


class SlackTool(Tool):
    """Slack messaging tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.webhook_url = config.get('webhook_url')
        self.bot_token = config.get('bot_token')
        self.token = config.get('token')  # For backward compatibility
        self.default_channel = config.get('default_channel', '#general')
        self.default_username = config.get('default_username', 'Agent')
        
    def validate_config(self) -> bool:
        """Validate Slack configuration using pure function."""
        if not _validate_slack_config(self.webhook_url, self.bot_token, self.token):
            logger.error(f"Either webhook_url or bot_token required for {self.name}")
            return False
        return True
    
    async def execute(self, message: str, channel: str = None,
                     username: str = None, icon_emoji: str = None,
                     attachments: List[Dict] = None, **kwargs) -> ToolResult:
        """Send Slack message with functional approach."""
        try:
            if not (hasattr(self, '_aiohttp_available') and self._aiohttp_available):
                try:
                    import aiohttp
                    self._aiohttp_available = True
                except ImportError:
                    raise ToolError(AIOHTTP_MISSING_ERROR, self.name)
            
            # Route to appropriate sending method
            if self.webhook_url:
                payload = _create_webhook_payload(message, username, icon_emoji, attachments)
                result_data = await _send_via_webhook(self.webhook_url, payload)
            elif self.bot_token or self.token:
                token = self.bot_token or self.token
                data = _create_bot_api_data(
                    channel or self.default_channel, message, username, icon_emoji, attachments
                )
                result_data = await _send_via_bot_api(token, data)
            else:
                raise ToolError("No valid Slack configuration found", self.name)
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=result_data
            )
            
        except Exception as e:
            logger.error(f"Slack send error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"Slack send error: {e}", self.name, e)
            )
    
    def get_schema(self) -> Dict[str, Any]:
        """Get Slack tool schema."""
        return {
            "name": self.name,
            "description": "Slack messaging tool",
            "parameters": {
                "message": {
                    "type": "string",
                    "description": "Message text to send",
                    "required": True
                },
                "channel": {
                    "type": "string",
                    "description": "Slack channel (required for bot API)",
                    "required": False
                },
                "username": {
                    "type": "string",
                    "description": "Bot username",
                    "required": False
                },
                "icon_emoji": {
                    "type": "string",
                    "description": "Bot icon emoji",
                    "required": False
                },
                "attachments": {
                    "type": "array",
                    "description": "Message attachments",
                    "required": False
                }
            },
            "required": ["message"],
            "examples": [
                {
                    "message": "Hello from the agent!",
                    "channel": "#general",
                    "icon_emoji": ":robot_face:"
                }
            ]
        }