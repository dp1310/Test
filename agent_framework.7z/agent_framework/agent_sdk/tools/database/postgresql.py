"""PostgreSQL database tool with functional programming approach."""

import logging
from typing import Any, Dict, List, Optional
from ..base import ToolResult, ToolStatus, ToolError
from .base import BaseDatabaseTool

logger = logging.getLogger(__name__)


# Pure functions for configuration validation
def _validate_url_config(url: str) -> bool:
    """Validate URL-based configuration."""
    return bool(url)


def _validate_params_config(host: str, database: str, username: str, password: str) -> bool:
    """Validate parameter-based configuration."""
    return all([host, database, username, password])


def _create_connection_params(config: Dict[str, Any]) -> Dict[str, Any]:
    """Create connection parameters from config."""
    url = config.get('url')
    if url:
        return {'dsn': url}
    
    return {
        'host': config.get('host', 'localhost'),
        'port': config.get('port', 5432),
        'database': config.get('database'),
        'user': config.get('username'),
        'password': config.get('password')
    }


def _create_pool_params(config: Dict[str, Any]) -> Dict[str, Any]:
    """Create connection pool parameters."""
    return {
        'min_size': 1,
        'max_size': config.get('pool_size', 5)
    }


def _format_query_result(records: List, query: str) -> Dict[str, Any]:
    """Format query results for response."""
    return {
        "records": [dict(record) for record in records],
        "query": query,
        "record_count": len(records)
    }


class PostgreSQLTool(BaseDatabaseTool):
    """PostgreSQL database tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.url = config.get('url')
        self.host = config.get('host', 'localhost')
        self.port = config.get('port', 5432)
        self.database = config.get('database')
        self.username = config.get('username')
        self.password = config.get('password')
        self.pool_size = config.get('pool_size', 5)
        self.pool = None
    
    def validate_config(self) -> bool:
        """Validate PostgreSQL configuration using pure functions."""
        return (_validate_url_config(self.url) if self.url 
                else _validate_params_config(self.host, self.database, self.username, self.password))
    
    async def connect(self):
        """Establish PostgreSQL connection pool."""
        try:
            import asyncpg
        except ImportError:
            raise ToolError("asyncpg library not installed. Run: pip install asyncpg", self.name)
        
        try:
            connection_params = _create_connection_params(self.config)
            pool_params = _create_pool_params(self.config)
            
            if 'dsn' in connection_params:
                self.pool = await asyncpg.create_pool(connection_params['dsn'], **pool_params)
            else:
                self.pool = await asyncpg.create_pool(**connection_params, **pool_params)
            
            self.connection = self.pool
            logger.info(f"Connected to PostgreSQL: {self.name}")
        except Exception as e:
            raise ToolError(f"Failed to connect to PostgreSQL: {e}", self.name, e)
    
    async def disconnect(self):
        """Close PostgreSQL connection pool."""
        if self.pool:
            self.pool.close()
            await self.pool.wait_closed()
            self.pool = None
            self.connection = None
            logger.info(f"Disconnected from PostgreSQL: {self.name}")
    
    async def execute(self, query: str, params: List = None, fetch: str = "all", **kwargs) -> ToolResult:
        """Execute PostgreSQL query with functional approach."""
        if not self.connection:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError("Not connected to PostgreSQL", self.name)
            )
        
        try:
            async with self.pool.acquire() as conn:
                if fetch == "none":
                    await conn.execute(query, *(params or []))
                    result_data = {"query": query, "affected_rows": "unknown"}
                elif fetch == "one":
                    record = await conn.fetchrow(query, *(params or []))
                    result_data = {
                        "record": dict(record) if record else None,
                        "row": dict(record) if record else None,  # Keep backward compatibility
                        "query": query
                    }
                else:  # fetch == "all"
                    records = await conn.fetch(query, *(params or []))
                    result_data = _format_query_result(records, query)
                    # Add backward compatibility field
                    result_data["rows"] = result_data["records"]
                
                return ToolResult(
                    tool_name=self.name,
                    status=ToolStatus.SUCCESS,
                    data=result_data
                )
                
        except Exception as e:
            logger.error(f"PostgreSQL query error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"PostgreSQL query error: {e}", self.name, e)
            )
    
    def get_schema(self) -> Dict[str, Any]:
        """Get PostgreSQL tool schema."""
        return {
            "name": self.name,
            "description": "PostgreSQL database tool for executing SQL queries",
            "parameters": {
                "query": {
                    "type": "string",
                    "description": "SQL query to execute",
                    "required": True
                },
                "params": {
                    "type": "array",
                    "description": "Query parameters",
                    "required": False
                },
                "fetch": {
                    "type": "string",
                    "description": "Fetch mode: 'all', 'one', or 'none'",
                    "default": "all",
                    "enum": ["all", "one", "none"]
                }
            },
            "required": ["query"],
            "examples": [
                {
                    "query": "SELECT * FROM users WHERE age > $1",
                    "params": [25],
                    "fetch": "all"
                },
                {
                    "query": "INSERT INTO users (name, email) VALUES ($1, $2)",
                    "params": ["John Doe", "john@example.com"],
                    "fetch": "none"
                }
            ]
        }