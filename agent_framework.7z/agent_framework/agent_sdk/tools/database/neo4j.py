"""Neo4j database tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional
from ..base import ToolResult, ToolStatus, ToolError
from .base import BaseDatabaseTool

logger = logging.getLogger(__name__)


# Pure functions for Neo4j operations
def _validate_neo4j_config(uri: str, username: str, password: str) -> bool:
    """Validate Neo4j configuration parameters."""
    return all([uri, username, password])


def _create_auth_tuple(username: str, password: str) -> tuple:
    """Create authentication tuple for Neo4j driver."""
    return (username, password)


def _format_neo4j_records(records: list) -> list:
    """Format Neo4j records for JSON serialization."""
    return [record.data() for record in records] if hasattr(records[0], 'data') else records


def _create_result_data(records: list, query: str) -> Dict[str, Any]:
    """Create formatted result data for Neo4j query."""
    return {
        "records": records,
        "query": query,
        "record_count": len(records)
    }


class Neo4jTool(BaseDatabaseTool):
    """Neo4j graph database tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.uri = config.get('uri', 'bolt://localhost:7687')
        self.username = config.get('username', 'neo4j')
        self.password = config.get('password')
        self.database = config.get('database', 'neo4j')
        self.driver = None
    
    def validate_config(self) -> bool:
        """Validate Neo4j configuration using pure function."""
        return _validate_neo4j_config(self.uri, self.username, self.password)
    
    async def connect(self):
        """Establish Neo4j connection."""
        try:
            from neo4j import AsyncGraphDatabase
        except ImportError:
            raise ToolError("neo4j library not installed. Run: pip install neo4j", self.name)
        
        try:
            auth = _create_auth_tuple(self.username, self.password)
            self.driver = AsyncGraphDatabase.driver(self.uri, auth=auth)
            
            # Test connection
            await self.driver.verify_connectivity()
            self.connection = self.driver
            logger.info(f"Connected to Neo4j: {self.name}")
        except Exception as e:
            raise ToolError(f"Failed to connect to Neo4j: {e}", self.name, e)
    
    async def disconnect(self):
        """Close Neo4j connection."""
        if self.driver:
            await self.driver.close()
            self.driver = None
            self.connection = None
            logger.info(f"Disconnected from Neo4j: {self.name}")
    
    async def execute(self, query: str, params: Dict = None, **kwargs) -> ToolResult:
        """Execute Neo4j Cypher query with functional approach."""
        if not self.connection:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError("Not connected to Neo4j", self.name)
            )
        
        try:
            async with self.driver.session(database=self.database) as session:
                result = await session.run(query, params or {})
                records = await result.data()
                
                result_data = _create_result_data(records, query)
                
                return ToolResult(
                    tool_name=self.name,
                    status=ToolStatus.SUCCESS,
                    data=result_data
                )
                
        except Exception as e:
            logger.error(f"Neo4j query error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"Neo4j query error: {e}", self.name, e)
            )
    
    def get_schema(self) -> Dict[str, Any]:
        """Get Neo4j tool schema."""
        return {
            "name": self.name,
            "description": "Neo4j graph database tool for executing Cypher queries",
            "parameters": {
                "query": {
                    "type": "string",
                    "description": "Cypher query to execute",
                    "required": True
                },
                "params": {
                    "type": "object",
                    "description": "Query parameters",
                    "required": False
                }
            },
            "required": ["query"],
            "examples": [
                {
                    "query": "MATCH (n:Person) WHERE n.age > $age RETURN n",
                    "params": {"age": 25}
                },
                {
                    "query": "CREATE (n:Person {name: $name, email: $email}) RETURN n",
                    "params": {"name": "John Doe", "email": "john@example.com"}
                }
            ]
        }