"""MongoDB database tool with functional programming approach."""

import logging
from typing import Any, Dict, List, Optional
from ..base import ToolResult, ToolStatus, ToolError
from .base import BaseDatabaseTool

logger = logging.getLogger(__name__)


# Pure functions for MongoDB operations
def _validate_mongodb_config(uri: str, database: str) -> bool:
    """Validate MongoDB configuration."""
    return bool(uri or database)


def _create_connection_string(config: Dict[str, Any]) -> str:
    """Create MongoDB connection string from config."""
    uri = config.get('uri') or config.get('url')
    if uri:
        return uri
    
    host = config.get('host', 'localhost')
    port = config.get('port', 27017)
    username = config.get('username')
    password = config.get('password')
    
    connection_string = "mongodb://"
    if username and password:
        connection_string += f"{username}:{password}@"
    connection_string += f"{host}:{port}"
    
    return connection_string


def _format_mongodb_result(result: Any, operation: str) -> Dict[str, Any]:
    """Format MongoDB operation result."""
    if operation in ["find", "find_one"]:
        if operation == "find":
            return {"documents": list(result), "count": len(list(result))}
        else:
            return {"document": result}
    elif operation in ["insert_one", "insert_many"]:
        if hasattr(result, 'inserted_id'):
            return {"inserted_id": str(result.inserted_id)}
        elif hasattr(result, 'inserted_ids'):
            return {"inserted_ids": [str(id) for id in result.inserted_ids]}
        else:
            return {"acknowledged": getattr(result, 'acknowledged', True)}
    elif operation in ["update_one", "update_many"]:
        return {
            "matched_count": getattr(result, 'matched_count', 0),
            "modified_count": getattr(result, 'modified_count', 0),
            "acknowledged": getattr(result, 'acknowledged', True)
        }
    elif operation in ["delete_one", "delete_many"]:
        return {
            "deleted_count": getattr(result, 'deleted_count', 0),
            "acknowledged": getattr(result, 'acknowledged', True)
        }
    else:
        return {"result": str(result)}


async def _execute_mongodb_operation(collection, operation: str, query: Dict = None, 
                                   document: Dict = None, documents: List[Dict] = None) -> Any:
    """Execute MongoDB operation based on type."""
    operations = {
        "find": lambda: collection.find(query or {}),
        "find_one": lambda: collection.find_one(query or {}),
        "insert_one": lambda: collection.insert_one(document),
        "insert_many": lambda: collection.insert_many(documents),
        "update_one": lambda: collection.update_one(query or {}, document),
        "update_many": lambda: collection.update_many(query or {}, document),
        "delete_one": lambda: collection.delete_one(query or {}),
        "delete_many": lambda: collection.delete_many(query or {})
    }
    
    if operation not in operations:
        raise ValueError(f"Unsupported operation: {operation}")
    
    result = operations[operation]()
    
    # Handle async cursor for find operations
    if operation == "find":
        # Check if result has to_list method (Motor cursor)
        if hasattr(result, 'to_list'):
            return await result.to_list(length=None)
        # Fallback for async iteration
        elif hasattr(result, '__aiter__'):
            return [doc async for doc in result]
        else:
            # For testing with mocks, return the result as-is
            return result
    elif operation == "find_one":
        return await result
    else:
        return await result


class MongoDBTool(BaseDatabaseTool):
    """MongoDB database tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.uri = config.get('uri') or config.get('url')
        self.url = self.uri  # Alias for backward compatibility
        self.host = config.get('host', 'localhost')
        self.port = config.get('port', 27017)
        self.database = config.get('database')
        self.username = config.get('username')
        self.password = config.get('password')
        self.client = None
        self.db = None
    
    def validate_config(self) -> bool:
        """Validate MongoDB configuration using pure function."""
        return _validate_mongodb_config(self.uri, self.database)
    
    async def connect(self):
        """Establish MongoDB connection."""
        try:
            from motor.motor_asyncio import AsyncIOMotorClient
        except ImportError:
            raise ToolError("motor library not installed. Run: pip install motor", self.name)
        
        try:
            connection_string = _create_connection_string(self.config)
            self.client = AsyncIOMotorClient(connection_string)
            self.db = self.client[self.database]
            self.connection = self.client
            
            # Test connection
            await self.client.admin.command('ping')
            logger.info(f"Connected to MongoDB: {self.name}")
        except Exception as e:
            raise ToolError(f"Failed to connect to MongoDB: {e}", self.name, e)
    
    async def disconnect(self):
        """Close MongoDB connection."""
        if self.client:
            self.client.close()
            self.client = None
            self.connection = None
            self.db = None
            logger.info(f"Disconnected from MongoDB: {self.name}")
    
    async def execute(self, operation: str, collection: str, 
                     query: Dict = None, document: Dict = None,
                     documents: List[Dict] = None, **kwargs) -> ToolResult:
        """Execute MongoDB operation with functional approach."""
        if not self.connection:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError("Not connected to MongoDB", self.name)
            )
        
        try:
            coll = self.db[collection]
            result = await _execute_mongodb_operation(coll, operation, query, document, documents)
            result_data = _format_mongodb_result(result, operation)
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=result_data
            )
            
        except Exception as e:
            logger.error(f"MongoDB operation error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"MongoDB operation error: {e}", self.name, e)
            )
    
    def get_schema(self) -> Dict[str, Any]:
        """Get MongoDB tool schema."""
        return {
            "name": self.name,
            "description": "MongoDB database tool for document operations",
            "parameters": {
                "operation": {
                    "type": "string",
                    "description": "Operation type",
                    "required": True,
                    "enum": ["find", "find_one", "insert_one", "insert_many", 
                            "update_one", "update_many", "delete_one", "delete_many"]
                },
                "collection": {
                    "type": "string",
                    "description": "Collection name",
                    "required": True
                },
                "query": {
                    "type": "object",
                    "description": "Query filter",
                    "required": False
                },
                "document": {
                    "type": "object",
                    "description": "Document for operations",
                    "required": False
                },
                "documents": {
                    "type": "array",
                    "description": "Documents for bulk operations",
                    "required": False
                }
            },
            "required": ["operation", "collection"],
            "examples": [
                {
                    "operation": "find",
                    "collection": "users",
                    "query": {"age": {"$gt": 25}}
                },
                {
                    "operation": "insert_one",
                    "collection": "users",
                    "document": {"name": "John Doe", "email": "john@example.com"}
                }
            ]
        }