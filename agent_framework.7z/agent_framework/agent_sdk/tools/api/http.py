"""HTTP tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional, Union
from ..base import Tool, ToolResult, ToolStatus, ToolError

logger = logging.getLogger(__name__)

# Constants
AIOHTTP_MISSING_ERROR = "aiohttp library not installed. Run: pip install aiohttp"


# Pure functions for HTTP operations
def _build_url(base_url: str, url: str) -> str:
    """Build complete URL from base and relative parts."""
    if url.startswith('http'):
        return url
    return base_url.rstrip('/') + '/' + url.lstrip('/')


def _prepare_headers(base_headers: Dict[str, str], additional_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """Prepare request headers by merging base and additional headers."""
    headers = base_headers.copy()
    if additional_headers:
        headers.update(additional_headers)
    return headers


def _create_auth_object(auth_config: Dict[str, Any]):
    """Create authentication object based on configuration."""
    try:
        import aiohttp
    except ImportError:
        raise ToolError(AIOHTTP_MISSING_ERROR)
    
    auth_type = auth_config.get('type', '').lower()
    
    if auth_type == 'basic':
        return aiohttp.BasicAuth(auth_config['username'], auth_config['password'])
    return None


def _add_auth_header(headers: Dict[str, str], auth_config: Dict[str, Any]) -> Dict[str, str]:
    """Add authentication header to request headers."""
    auth_type = auth_config.get('type', '').lower()
    
    if auth_type == 'bearer':
        headers['Authorization'] = f"Bearer {auth_config['token']}"
    elif auth_type == 'api_key':
        key_name = auth_config.get('key_name', 'X-API-Key')
        headers[key_name] = auth_config['api_key']
    
    return headers


def _create_request_params(method: str, url: str, params: Optional[Dict] = None,
                          headers: Optional[Dict] = None, auth_obj: Any = None,
                          timeout: float = 30, verify_ssl: bool = True,
                          json_data: Optional[Dict] = None, data: Any = None) -> Dict[str, Any]:
    """Create request parameters for aiohttp."""
    try:
        import aiohttp
        request_params = {
            'method': method.upper(),
            'url': url,
            'params': params,
            'headers': headers,
            'auth': auth_obj,
            'timeout': aiohttp.ClientTimeout(total=timeout),
            'ssl': verify_ssl
        }
        
        # Add body data
        if json_data is not None:
            request_params['json'] = json_data
        elif data is not None:
            request_params['data'] = data
        
        return request_params
    except ImportError:
        raise ToolError(AIOHTTP_MISSING_ERROR)


async def _get_response_content(response) -> Any:
    """Extract content from HTTP response based on content type."""
    content_type = response.headers.get('content-type', '').lower()
    
    if 'application/json' in content_type:
        return await response.json()
    else:
        return await response.text()


def _create_result_data(status_code: int, headers: Dict, data: Any, url: str, method: str) -> Dict[str, Any]:
    """Create formatted result data for HTTP response."""
    return {
        "status_code": status_code,
        "headers": dict(headers),
        "data": data,
        "url": str(url),
        "method": method.upper()
    }


class HTTPTool(Tool):
    """HTTP client tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.base_url = config.get('base_url', '')
        self.headers = config.get('headers', {})
        self.auth = config.get('auth', {})
        self.verify_ssl = config.get('verify_ssl', True)
        
    def validate_config(self) -> bool:
        """Validate HTTP tool configuration."""
        return True  # HTTP tool has minimal requirements
    
    async def execute(self, method: str, url: str, params: Dict = None,
                     data: Any = None, json_data: Dict = None,
                     headers: Dict = None, auth: Dict = None,
                     timeout: float = None, **kwargs) -> ToolResult:
        """Execute HTTP request with functional approach."""
        try:
            # Import aiohttp
            try:
                import aiohttp
            except ImportError:
                raise ToolError(AIOHTTP_MISSING_ERROR, self.name)
            
            # Prepare request using pure functions
            complete_url = _build_url(self.base_url, url)
            request_headers = _prepare_headers(self.headers, headers)
            
            # Handle authentication
            auth_config = auth or self.auth
            auth_obj = None
            
            if auth_config:
                auth_obj = _create_auth_object(auth_config)
                if not auth_obj:  # Handle non-basic auth types
                    request_headers = _add_auth_header(request_headers, auth_config)
            
            # Create request parameters
            request_params = _create_request_params(
                method, complete_url, params, request_headers, auth_obj,
                timeout or self.timeout, self.verify_ssl, json_data, data
            )
            
            # Make request
            async with aiohttp.ClientSession() as session:
                async with session.request(**request_params) as response:
                    response_data = await _get_response_content(response)
                    result_data = _create_result_data(
                        response.status, response.headers, response_data,
                        response.url, method
                    )
                    
                    return ToolResult(
                        tool_name=self.name,
                        status=ToolStatus.SUCCESS,
                        data=result_data
                    )
                    
        except Exception as e:
            logger.error(f"HTTP request error: {e}")
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"HTTP request error: {e}", self.name, e)
            )
    
    def get_schema(self) -> Dict[str, Any]:
        """Get HTTP tool schema."""
        return {
            "name": self.name,
            "description": "HTTP client tool for making web requests",
            "parameters": {
                "method": {
                    "type": "string",
                    "description": "HTTP method",
                    "required": True,
                    "enum": ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]
                },
                "url": {
                    "type": "string",
                    "description": "Request URL",
                    "required": True
                },
                "params": {
                    "type": "object",
                    "description": "URL parameters",
                    "required": False
                },
                "json_data": {
                    "type": "object",
                    "description": "JSON request body",
                    "required": False
                },
                "headers": {
                    "type": "object",
                    "description": "Request headers",
                    "required": False
                },
                "timeout": {
                    "type": "number",
                    "description": "Request timeout in seconds",
                    "required": False
                }
            },
            "required": ["method", "url"],
            "examples": [
                {
                    "method": "GET",
                    "url": "https://api.example.com/users",
                    "params": {"page": 1, "limit": 10}
                },
                {
                    "method": "POST",
                    "url": "https://api.example.com/users",
                    "json_data": {"name": "John Doe", "email": "john@example.com"}
                }
            ]
        }