"""OpenAI LLM tool with functional programming approach."""

import logging
from typing import Any, Dict, Optional
from ..base import ToolError
from .base import BaseLLMTool, _extract_chunk_content, _extract_common_response

logger = logging.getLogger(__name__)


# Pure functions for OpenAI operations
def _create_messages(prompt: str, system_prompt: Optional[str] = None) -> list:
    """Create message list for OpenAI API."""
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})
    return messages


def _create_api_params(model: str, messages: list, max_tokens: int, 
                      temperature: float, top_p: float, stream: bool, **kwargs) -> Dict[str, Any]:
    """Create API parameters for OpenAI request."""
    params = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "top_p": top_p,
        "stream": stream
    }
    params.update(kwargs)
    return params


async def _process_stream_response(stream) -> str:
    """Process streaming response from OpenAI."""
    response_text = ""
    async for chunk in stream:
        content = _extract_chunk_content(chunk)
        if content:
            response_text += content
    return response_text


class OpenAITool(BaseLLMTool):
    """OpenAI GPT tool with functional approach."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        super().__init__(name, config)
        self.base_url = config.get('base_url', 'https://api.openai.com/v1')
        self.organization = config.get('organization')
        # Set default model if not provided
        if not self.model:
            self.model = 'gpt-3.5-turbo'
    
    def get_schema(self) -> Dict[str, Any]:
        """Get OpenAI tool schema."""
        schema = super().get_schema()
        schema["description"] = "OpenAI GPT tool for text generation and completion"
        return schema
        
    async def execute(self, prompt: str, system_prompt: str = None, 
                     max_tokens: int = None, temperature: float = None,
                     stream: bool = False, **kwargs):
        """Execute OpenAI API call with functional approach."""
        try:
            # Import OpenAI client
            try:
                from openai import AsyncOpenAI
            except ImportError:
                raise ToolError("OpenAI library not installed. Run: pip install openai", self.name)
            
            # Initialize client
            client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                organization=self.organization
            )
            
            # Get standardized parameters
            request_max_tokens, request_temperature = self._get_request_params(max_tokens, temperature)
            
            # Prepare request using pure functions
            messages = _create_messages(prompt, system_prompt)
            params = _create_api_params(
                self.model, messages, request_max_tokens, request_temperature,
                self.top_p, stream, **kwargs
            )
            
            # Make API call
            if stream:
                stream_response = await client.chat.completions.create(**params)
                response_text = await _process_stream_response(stream_response)
                return self._create_success_result(response_text, stream=True)
            else:
                response = await client.chat.completions.create(**params)
                content, usage, finish_reason = _extract_common_response(response)
                return self._create_success_result(content, usage, finish_reason)
            
        except Exception as e:
            return self._create_error_result(e, "OpenAI")