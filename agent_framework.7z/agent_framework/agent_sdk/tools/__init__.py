"""
Agent SDK Tools System

This module provides a comprehensive tools system that allows any task to execute
various tools including LLM providers, databases, APIs, and custom tools.

Features:
- Configurable tools via YAML and .env files
- Built-in LLM tools (OpenAI, Gemini, Mistral, etc.)
- Database tools (PostgreSQL, Neo4j, etc.)
- API tools and HTTP clients
- Custom tool registration
- Tool hooks for automatic integration
- Async and sync tool execution
- Error handling and retries
- Tool result caching
"""

from .base import Tool, ToolResult, ToolError, ToolStatus, ToolRegistry, get_tool_registry
from .config import ToolConfig, load_tools_config
from .hooks import tool_hook, get_available_tools, execute_tool
from .llm import OpenAITool, GeminiTool, MistralTool, AnthropicTool
from .database import PostgreSQLTool, Neo4jTool, MongoDBTool
from .api import HTTPTool, RestAPITool
from .utils import FileTool, EmailTool, SlackTool

__all__ = [
    # Base classes
    'Tool', 'ToolResult', 'ToolError', 'ToolStatus', 'ToolRegistry', 'get_tool_registry',
    
    # Configuration
    'ToolConfig', 'load_tools_config',
    
    # Hooks
    'tool_hook', 'get_available_tools', 'execute_tool',
    
    # LLM Tools
    'OpenAITool', 'GeminiTool', 'MistralTool', 'AnthropicTool',
    
    # Database Tools
    'PostgreSQLTool', 'Neo4jTool', 'MongoDBTool',
    
    # API Tools
    'HTTPTool', 'RestAPITool',
    
    # Utility Tools
    'FileTool', 'EmailTool', 'SlackTool'
]