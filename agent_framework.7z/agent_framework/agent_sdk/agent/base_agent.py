"""Base agent abstract class following prototype and ABC patterns."""

from abc import ABC, abstractmethod
from typing import Any, List, Callable, Dict, Optional, Union
from copy import deepcopy

from ..core.stages import Stage
from ..core.context import Context
from ..utils.logging import get_logger
from .config import DynamicConfigParser, AgentValidator

logger = get_logger(__name__)


class BaseAgent(ABC):
    """
    Abstract base agent following prototype pattern and SOLID principles.
    
    This class defines the interface for all agent implementations and provides
    common functionality while allowing concrete implementations to define
    their specific execution strategies.
    """
    
    def __init__(
        self,
        functions: Optional[List[Callable]] = None,
        initial_context: Optional[Dict[str, Any]] = None,
        concurrent: Optional[Dict[Stage, bool]] = None,
        workflow_id: Optional[str] = None
    ):
        """
        Initialize base agent with configuration.
        
        Args:
            functions: List of stage functions to execute
            initial_context: Initial context data
            concurrent: Stage-level concurrency settings
            workflow_id: Unique identifier for workflow monitoring
        """
        self._functions = functions or []
        self._initial_context = initial_context or {}
        self._concurrent = concurrent or {}
        self._dynamic_config_parser = DynamicConfigParser()
        
        # Generate default workflow ID if not provided
        if workflow_id is None:
            import uuid
            execution_type = getattr(self, '_execution_type', 'agent')
            self._workflow_id = f"{execution_type}_{uuid.uuid4().hex[:8]}"
        else:
            self._workflow_id = workflow_id
        
        # Validate functions have proper stage decorators
        AgentValidator.validate_functions(self._functions)
    
    def clone(self) -> "BaseAgent":
        """
        Create a deep copy of the agent (prototype pattern).
        
        Returns:
            New agent instance with copied configuration
        """
        return self.__class__(
            functions=deepcopy(self._functions),
            initial_context=deepcopy(self._initial_context),
            concurrent=deepcopy(self._concurrent),
            workflow_id=self._workflow_id
        )
    
    def add_function(self, function: Callable) -> "BaseAgent":
        """
        Add a function to the agent (fluent interface).
        
        Args:
            function: Stage function to add
            
        Returns:
            Self for method chaining
        """
        AgentValidator.validate_function(function)
        self._functions.append(function)
        return self
    
    def add_functions(self, functions: List[Callable]) -> "BaseAgent":
        """
        Add multiple functions to the agent (fluent interface).
        
        Args:
            functions: List of stage functions to add
            
        Returns:
            Self for method chaining
        """
        for fn in functions:
            self.add_function(fn)
        return self
    
    def set_initial_context(self, context: Dict[str, Any]) -> "BaseAgent":
        """
        Set initial context (fluent interface).
        
        Args:
            context: Initial context data
            
        Returns:
            Self for method chaining
        """
        self._initial_context = context
        return self
    
    def update_initial_context(self, context: Dict[str, Any]) -> "BaseAgent":
        """
        Update initial context (fluent interface).
        
        Args:
            context: Context data to merge
            
        Returns:
            Self for method chaining
        """
        self._initial_context.update(context)
        return self
    
    def set_concurrent(self, concurrent: Dict[Stage, bool]) -> "BaseAgent":
        """
        Set concurrency settings (fluent interface).
        
        Args:
            concurrent: Stage-level concurrency settings
            
        Returns:
            Self for method chaining
        """
        self._concurrent = concurrent
        return self
    
    def set_stage_concurrent(self, stage: Stage, concurrent: bool) -> "BaseAgent":
        """
        Set concurrency for a specific stage (fluent interface).
        
        Args:
            stage: Stage to configure
            concurrent: Whether to run stage concurrently
            
        Returns:
            Self for method chaining
        """
        self._concurrent[stage] = concurrent
        return self
    
    def set_workflow_id(self, workflow_id: str) -> "BaseAgent":
        """
        Set workflow ID (fluent interface).
        
        Args:
            workflow_id: Unique identifier for workflow monitoring
            
        Returns:
            Self for method chaining
        """
        self._workflow_id = workflow_id
        return self
    
    @property
    def functions(self) -> List[Callable]:
        """Get list of functions."""
        return self._functions.copy()
    
    @property
    def initial_context(self) -> Dict[str, Any]:
        """Get initial context."""
        return self._initial_context.copy()
    
    @property
    def concurrent(self) -> Dict[Stage, bool]:
        """Get concurrency settings."""
        return self._concurrent.copy()
    
    @property
    def workflow_id(self) -> Optional[str]:
        """Get workflow ID."""
        return self._workflow_id
    
    @abstractmethod
    def execute(self, input_data: Any) -> Union[Context, Any]:
        """
        Execute the agentic workflow.
        
        Note: For async agents, this method will be async.
        
        Args:
            input_data: Input data for the workflow
            
        Returns:
            Final context or result after all stages (may be awaitable for async agents)
        """
        pass
    
    @abstractmethod
    def get_execution_type(self) -> str:
        """
        Get the execution type identifier.
        
        Returns:
            String identifier for the execution type
        """
        pass
    
    def _parse_dynamic_config(self, input_data: Any) -> tuple[Any, Optional[List[Callable]], Optional[Dict[Stage, bool]]]:
        """
        Parse dynamic configuration from input_data if it's a dictionary.
        
        Args:
            input_data: Input data that may contain dynamic configuration
            
        Returns:
            Tuple of (actual_input_data, override_functions, override_concurrent)
        """
        return self._dynamic_config_parser.parse_dynamic_config(input_data)


    def __repr__(self) -> str:
        """String representation of the agent."""
        return (
            f"{self.__class__.__name__}("
            f"functions={len(self._functions)}, "
            f"concurrent={self._concurrent}, "
            f"workflow_id={self._workflow_id})"
        )