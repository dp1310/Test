"""Base agent abstract class following prototype and ABC patterns."""

from abc import ABC, abstractmethod
from typing import Any, List, Callable, Dict, Optional, Union
from copy import deepcopy
import importlib

from ..core.stages import Stage
from ..core.context import Context
from ..utils.logging import get_logger

logger = get_logger(__name__)


class BaseAgent(ABC):
    """
    Abstract base agent following prototype pattern and SOLID principles.
    
    This class defines the interface for all agent implementations and provides
    common functionality while allowing concrete implementations to define
    their specific execution strategies.
    """
    
    def __init__(
        self,
        functions: Optional[List[Callable]] = None,
        initial_context: Optional[Dict[str, Any]] = None,
        concurrent: Optional[Dict[Stage, bool]] = None,
        workflow_id: Optional[str] = None
    ):
        """
        Initialize base agent with configuration.
        
        Args:
            functions: List of stage functions to execute
            initial_context: Initial context data
            concurrent: Stage-level concurrency settings
            workflow_id: Unique identifier for workflow monitoring
        """
        self._functions = functions or []
        self._initial_context = initial_context or {}
        self._concurrent = concurrent or {}
        
        # Generate default workflow ID if not provided
        if workflow_id is None:
            import uuid
            execution_type = getattr(self, '_execution_type', 'agent')
            self._workflow_id = f"{execution_type}_{uuid.uuid4().hex[:8]}"
        else:
            self._workflow_id = workflow_id
        
        # Validate functions have proper stage decorators
        self._validate_functions()
    
    def _validate_functions(self) -> None:
        """Validate that all functions have proper stage decorators."""
        for fn in self._functions:
            if not hasattr(fn, "_agent_stage"):
                func_name = getattr(fn, '__name__', '<unknown>')
                logger.warning(f"Function {func_name} missing stage decorator")
    
    def clone(self) -> "BaseAgent":
        """
        Create a deep copy of the agent (prototype pattern).
        
        Returns:
            New agent instance with copied configuration
        """
        return self.__class__(
            functions=deepcopy(self._functions),
            initial_context=deepcopy(self._initial_context),
            concurrent=deepcopy(self._concurrent),
            workflow_id=self._workflow_id
        )
    
    def add_function(self, function: Callable) -> "BaseAgent":
        """
        Add a function to the agent (fluent interface).
        
        Args:
            function: Stage function to add
            
        Returns:
            Self for method chaining
        """
        if not hasattr(function, "_agent_stage"):
            func_name = getattr(function, '__name__', '<unknown>')
            logger.warning(f"Function {func_name} missing stage decorator")
        
        self._functions.append(function)
        return self
    
    def add_functions(self, functions: List[Callable]) -> "BaseAgent":
        """
        Add multiple functions to the agent (fluent interface).
        
        Args:
            functions: List of stage functions to add
            
        Returns:
            Self for method chaining
        """
        for fn in functions:
            self.add_function(fn)
        return self
    
    def set_initial_context(self, context: Dict[str, Any]) -> "BaseAgent":
        """
        Set initial context (fluent interface).
        
        Args:
            context: Initial context data
            
        Returns:
            Self for method chaining
        """
        self._initial_context = context
        return self
    
    def update_initial_context(self, context: Dict[str, Any]) -> "BaseAgent":
        """
        Update initial context (fluent interface).
        
        Args:
            context: Context data to merge
            
        Returns:
            Self for method chaining
        """
        self._initial_context.update(context)
        return self
    
    def set_concurrent(self, concurrent: Dict[Stage, bool]) -> "BaseAgent":
        """
        Set concurrency settings (fluent interface).
        
        Args:
            concurrent: Stage-level concurrency settings
            
        Returns:
            Self for method chaining
        """
        self._concurrent = concurrent
        return self
    
    def set_stage_concurrent(self, stage: Stage, concurrent: bool) -> "BaseAgent":
        """
        Set concurrency for a specific stage (fluent interface).
        
        Args:
            stage: Stage to configure
            concurrent: Whether to run stage concurrently
            
        Returns:
            Self for method chaining
        """
        self._concurrent[stage] = concurrent
        return self
    
    def set_workflow_id(self, workflow_id: str) -> "BaseAgent":
        """
        Set workflow ID (fluent interface).
        
        Args:
            workflow_id: Unique identifier for workflow monitoring
            
        Returns:
            Self for method chaining
        """
        self._workflow_id = workflow_id
        return self
    
    @property
    def functions(self) -> List[Callable]:
        """Get list of functions."""
        return self._functions.copy()
    
    @property
    def initial_context(self) -> Dict[str, Any]:
        """Get initial context."""
        return self._initial_context.copy()
    
    @property
    def concurrent(self) -> Dict[Stage, bool]:
        """Get concurrency settings."""
        return self._concurrent.copy()
    
    @property
    def workflow_id(self) -> Optional[str]:
        """Get workflow ID."""
        return self._workflow_id
    
    @abstractmethod
    def execute(self, input_data: Any) -> Union[Context, Any]:
        """
        Execute the agentic workflow.
        
        Note: For async agents, this method will be async.
        
        Args:
            input_data: Input data for the workflow
            
        Returns:
            Final context or result after all stages (may be awaitable for async agents)
        """
        pass
    
    @abstractmethod
    def get_execution_type(self) -> str:
        """
        Get the execution type identifier.
        
        Returns:
            String identifier for the execution type
        """
        pass
    
    def _parse_dynamic_config(self, input_data: Any) -> tuple[Any, Optional[List[Callable]], Optional[Dict[Stage, bool]]]:
        """
        Parse dynamic configuration from input_data if it's a dictionary.
        
        Args:
            input_data: Input data that may contain dynamic configuration
            
        Returns:
            Tuple of (actual_input_data, override_functions, override_concurrent)
        """
        if not isinstance(input_data, dict):
            return input_data, None, None
        
        # Check for dynamic configuration in _agent_config key
        agent_config = input_data.get('_agent_config', {})
        
        # Check for dynamic configuration keys (both direct and in _agent_config)
        functions_override = agent_config.get('functions') or input_data.get('functions')
        concurrent_override = agent_config.get('concurrent') or input_data.get('concurrent')
        
        # If no overrides, return as-is
        if functions_override is None and concurrent_override is None:
            return input_data, None, None
        
        # Extract actual input data (everything except override keys and _agent_config)
        actual_input = {k: v for k, v in input_data.items() 
                       if k not in ['functions', 'concurrent', '_agent_config']}
        
        # Convert functions from strings to callables
        parsed_functions = None
        if functions_override is not None:
            parsed_functions = self._parse_functions(functions_override)
        
        # Convert concurrent from strings to Stage enum
        parsed_concurrent = None
        if concurrent_override is not None:
            parsed_concurrent = self._parse_concurrent(concurrent_override)
        
        logger.info(f"Dynamic configuration detected - functions: {len(parsed_functions) if parsed_functions else 'None'}, "
                   f"concurrent: {parsed_concurrent if parsed_concurrent else 'None'}")
        
        return actual_input, parsed_functions, parsed_concurrent
    
    def _parse_functions(self, functions_config: Union[List[str], List[Callable]]) -> List[Callable]:
        """
        Parse functions from string list to callable list.
        
        Args:
            functions_config: List of function names (strings) or callables
            
        Returns:
            List of callable functions
        """
        if not isinstance(functions_config, list):
            raise ValueError("Functions must be provided as a list")
        
        parsed_functions = []
        
        for func_item in functions_config:
            if callable(func_item):
                # Already a callable
                parsed_functions.append(func_item)
            elif isinstance(func_item, str):
                # String reference - try to resolve it
                try:
                    # Try to import from common locations
                    callable_func = self._resolve_function_string(func_item)
                    parsed_functions.append(callable_func)
                except Exception as e:
                    logger.error(f"Failed to resolve function '{func_item}': {e}")
                    raise ValueError(f"Cannot resolve function '{func_item}'")
            else:
                raise ValueError(f"Function must be callable or string, got {type(func_item)}")
        
        return parsed_functions
    
    def _resolve_function_string(self, func_name: str) -> Callable:
        """
        Resolve a function string to a callable.
        
        Args:
            func_name: Function name in format 'module.function' or just 'function'
            
        Returns:
            Callable function
        """
        # If it contains a dot, treat as module.function
        if '.' in func_name:
            module_name, function_name = func_name.rsplit('.', 1)
            try:
                # Try to import the module
                module = importlib.import_module(module_name)
                func = getattr(module, function_name)
                
                if not callable(func):
                    raise ValueError(f"'{func_name}' is not callable")
                
                logger.debug(f"Successfully resolved function string '{func_name}' to {func}")
                return func
                
            except ImportError as e:
                # Try relative imports or common patterns
                try:
                    # Try importing as a relative module from current package
                    relative_module = f".{module_name}"
                    module = importlib.import_module(relative_module, package=__package__)
                    func = getattr(module, function_name)
                    
                    if not callable(func):
                        raise ValueError(f"'{func_name}' is not callable")
                    
                    logger.debug(f"Successfully resolved function string '{func_name}' via relative import to {func}")
                    return func
                    
                except (ImportError, AttributeError):
                    # Try common locations
                    common_locations = [
                        f"agent_sdk.examples.{module_name}",
                        f"examples.{module_name}",
                        f"__main__.{module_name}" if module_name != "__main__" else "__main__"
                    ]
                    
                    for location in common_locations:
                        try:
                            if location == "__main__":
                                # Special handling for __main__ module
                                import sys
                                main_module = sys.modules.get("__main__")
                                if main_module and hasattr(main_module, function_name):
                                    func = getattr(main_module, function_name)
                                    if callable(func):
                                        logger.debug(f"Successfully resolved function string '{func_name}' from __main__ to {func}")
                                        return func
                            else:
                                module = importlib.import_module(location)
                                func = getattr(module, function_name)
                                
                                if not callable(func):
                                    continue
                                
                                logger.debug(f"Successfully resolved function string '{func_name}' from {location} to {func}")
                                return func
                                
                        except (ImportError, AttributeError):
                            continue
                    
                    raise ValueError(f"Cannot import {func_name}: {e}. Tried common locations: {common_locations}")
                    
            except AttributeError as e:
                raise ValueError(f"Module '{module_name}' has no attribute '{function_name}': {e}")
        else:
            # Try to find in current globals/locals or __main__
            try:
                import sys
                
                # Check __main__ module first
                main_module = sys.modules.get("__main__")
                if main_module and hasattr(main_module, func_name):
                    func = getattr(main_module, func_name)
                    if callable(func):
                        logger.debug(f"Successfully resolved simple function name '{func_name}' from __main__ to {func}")
                        return func
                
                # Check current frame's globals
                import inspect
                frame = inspect.currentframe()
                try:
                    # Go up the call stack to find the function in caller's context
                    for _ in range(5):  # Check up to 5 frames up
                        frame = frame.f_back
                        if frame and func_name in frame.f_globals:
                            func = frame.f_globals[func_name]
                            if callable(func):
                                logger.debug(f"Successfully resolved simple function name '{func_name}' from caller globals to {func}")
                                return func
                finally:
                    del frame
                
                raise ValueError(f"Simple function name '{func_name}' not found. Use 'module.function' format for better resolution.")
                
            except Exception as e:
                raise ValueError(f"Cannot resolve function '{func_name}': {e}. Use 'module.function' format.")
    
    def _parse_concurrent(self, concurrent_config: Union[Dict[str, bool], Dict[Stage, bool]]) -> Dict[Stage, bool]:
        """
        Parse concurrent configuration from strings to Stage enum.
        
        Args:
            concurrent_config: Dictionary with stage names (strings) or Stage enums as keys
            
        Returns:
            Dictionary with Stage enum keys and boolean values
        """
        if not isinstance(concurrent_config, dict):
            raise ValueError("Concurrent configuration must be a dictionary")
        
        parsed_concurrent = {}
        
        for stage_key, concurrent_value in concurrent_config.items():
            if isinstance(stage_key, Stage):
                # Already a Stage enum
                parsed_concurrent[stage_key] = bool(concurrent_value)
            elif isinstance(stage_key, str):
                # String stage name - convert to enum
                try:
                    stage_enum = Stage[stage_key.upper()]
                    parsed_concurrent[stage_enum] = bool(concurrent_value)
                except KeyError:
                    logger.error(f"Invalid stage name: {stage_key}")
                    raise ValueError(f"Invalid stage name: {stage_key}. Valid stages: {[s.name for s in Stage]}")
            else:
                raise ValueError(f"Stage key must be Stage enum or string, got {type(stage_key)}")
        
        return parsed_concurrent

    def __repr__(self) -> str:
        """String representation of the agent."""
        return (
            f"{self.__class__.__name__}("
            f"functions={len(self._functions)}, "
            f"concurrent={self._concurrent}, "
            f"workflow_id={self._workflow_id})"
        )