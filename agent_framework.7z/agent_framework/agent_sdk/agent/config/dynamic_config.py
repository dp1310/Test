"""Dynamic configuration parsing utilities following functional programming principles."""

from typing import Any, Dict, List, Callable, Optional, Union, Tuple
from ...core.stages import Stage
from ...utils.logging import get_logger
from .function_resolver import FunctionResolver

logger = get_logger(__name__)


class DynamicConfigParser:
    """Functional approach to parsing dynamic agent configuration."""
    
    def __init__(self):
        self.function_resolver = FunctionResolver()
    
    def parse_dynamic_config(self, input_data: Any) -> Tuple[Any, Optional[List[Callable]], Optional[Dict[Stage, bool]]]:
        """
        Parse dynamic configuration from input_data if it's a dictionary.
        
        Args:
            input_data: Input data that may contain dynamic configuration
            
        Returns:
            Tuple of (actual_input_data, override_functions, override_concurrent)
        """
        if not isinstance(input_data, dict):
            return input_data, None, None
        
        # Check for dynamic configuration in _agent_config key
        agent_config = input_data.get('_agent_config', {})
        
        # Check for dynamic configuration keys (both direct and in _agent_config)
        functions_override = agent_config.get('functions') or input_data.get('functions')
        concurrent_override = agent_config.get('concurrent') or input_data.get('concurrent')
        
        # If no overrides, return as-is
        if functions_override is None and concurrent_override is None:
            return input_data, None, None
        
        # Extract actual input data (everything except override keys and _agent_config)
        actual_input = {k: v for k, v in input_data.items() 
                       if k not in ['functions', 'concurrent', '_agent_config']}
        
        # Convert functions from strings to callables
        parsed_functions = None
        if functions_override is not None:
            parsed_functions = self.parse_functions(functions_override)
        
        # Convert concurrent from strings to Stage enum
        parsed_concurrent = None
        if concurrent_override is not None:
            parsed_concurrent = self.parse_concurrent(concurrent_override)
        
        logger.info(f"Dynamic configuration detected - functions: {len(parsed_functions) if parsed_functions else 'None'}, "
                   f"concurrent: {parsed_concurrent if parsed_concurrent else 'None'}")
        
        return actual_input, parsed_functions, parsed_concurrent
    
    def parse_functions(self, functions_config: Union[List[str], List[Callable]]) -> List[Callable]:
        """
        Parse functions from string list to callable list.
        
        Args:
            functions_config: List of function names (strings) or callables
            
        Returns:
            List of callable functions
        """
        if not isinstance(functions_config, list):
            raise ValueError("Functions must be provided as a list")
        
        parsed_functions = []
        
        for func_item in functions_config:
            if callable(func_item):
                # Already a callable
                parsed_functions.append(func_item)
            elif isinstance(func_item, str):
                # String reference - try to resolve it
                try:
                    callable_func = self.function_resolver.resolve_function(func_item)
                    parsed_functions.append(callable_func)
                except Exception as e:
                    logger.error(f"Failed to resolve function '{func_item}': {e}")
                    raise ValueError(f"Cannot resolve function '{func_item}'")
            else:
                raise ValueError(f"Function must be callable or string, got {type(func_item)}")
        
        return parsed_functions
    
    def parse_concurrent(self, concurrent_config: Union[Dict[str, bool], Dict[Stage, bool]]) -> Dict[Stage, bool]:
        """
        Parse concurrent configuration from strings to Stage enum.
        
        Args:
            concurrent_config: Dictionary with stage names (strings) or Stage enums as keys
            
        Returns:
            Dictionary with Stage enum keys and boolean values
        """
        if not isinstance(concurrent_config, dict):
            raise ValueError("Concurrent configuration must be a dictionary")
        
        parsed_concurrent = {}
        
        for stage_key, concurrent_value in concurrent_config.items():
            if isinstance(stage_key, Stage):
                # Already a Stage enum
                parsed_concurrent[stage_key] = bool(concurrent_value)
            elif isinstance(stage_key, str):
                # String stage name - convert to enum
                try:
                    stage_enum = Stage[stage_key.upper()]
                    parsed_concurrent[stage_enum] = bool(concurrent_value)
                except KeyError:
                    logger.error(f"Invalid stage name: {stage_key}")
                    raise ValueError(f"Invalid stage name: {stage_key}. "
                                   f"Valid stages: {[s.name for s in Stage]}")
            else:
                raise ValueError(f"Stage key must be Stage enum or string, got {type(stage_key)}")
        
        return parsed_concurrent