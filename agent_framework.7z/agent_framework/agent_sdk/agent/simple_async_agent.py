"""Simple asynchronous agent implementation."""

import asyncio
from typing import Any, List, Callable, Dict, Optional

from .base_agent import BaseAgent
from ..core.context import Context
from ..core.spine import agentic_spine_async
from ..utils.logging import get_logger

logger = get_logger(__name__)


class SimpleAsyncAgent(BaseAgent):
    """
    Simple asynchronous agent implementation.
    
    This agent executes workflows asynchronously without Prefect,
    providing async execution with concurrency support.
    """

    _execution_type = "simple_async"
    
    async def execute(self, input_data: Any) -> Context:
        """
        Execute the agentic workflow asynchronously.
        
        Args:
            input_data: Input data for the workflow (may contain dynamic configuration)
            
        Returns:
            Final context after all stages
        """
        # Parse dynamic configuration from input_data
        actual_input, override_functions, override_concurrent = self._parse_dynamic_config(input_data)
        
        # Use overrides if provided, otherwise use instance defaults
        functions_to_use = override_functions if override_functions is not None else self._functions
        concurrent_to_use = override_concurrent if override_concurrent is not None else self._concurrent
        
        logger.info(f"Executing simple async workflow with {len(functions_to_use)} functions")
        if override_functions is not None:
            logger.info("Using dynamically provided functions")
        if override_concurrent is not None:
            logger.info(f"Using dynamic concurrent settings: {override_concurrent}")
        
        return await agentic_spine_async(
            input_data=actual_input,
            functions=functions_to_use,
            initial_context=self._initial_context,
            concurrent=concurrent_to_use,
            workflow_id=self._workflow_id
        )
    
    def get_execution_type(self) -> str:
        """Get the execution type identifier."""
        return self._execution_type
    
    def __str__(self) -> str:
        """String representation."""
        return f"SimpleAsyncAgent(functions={len(self._functions)})"