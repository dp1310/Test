"""Synchronous execution engine for agentic workflows."""

import asyncio
from typing import Callable, List, Any

from ..context import Context, merge_context
from ..stages import Stage
from ..state import get_state_manager, stage_execution_context
from ...utils.logging import get_logger

logger = get_logger(__name__)


class SyncExecutor:
    """Synchronous execution engine."""
    
    @staticmethod
    def execute_sequential(functions: List[Callable], ctx: Context) -> List[Any]:
        """Execute functions sequentially."""
        results = []
        for fn in functions:
            try:
                result = fn(ctx)
                results.append(result)
                logger.debug(f"Sequential execution of {fn.__name__} completed")
            except Exception as e:
                logger.error(f"Error in sequential execution of {fn.__name__}: {e}")
                raise
        return results
    
    @staticmethod
    def execute_sequential_monitored(
        functions: List[Callable], 
        ctx: Context, 
        stage: Stage, 
        workflow_id: str
    ) -> List[Any]:
        """Execute functions sequentially with state monitoring."""
        results = []
        get_state_manager()
        
        for fn in functions:
            function_name = getattr(fn, '__name__', 'unknown')
            
            with stage_execution_context(stage, function_name, workflow_id) as execution:
                try:
                    if asyncio.iscoroutinefunction(fn):
                        logger.warning(f"Async function {function_name} called in sync context")
                        result = fn(ctx)  # This will return a coroutine, which is not ideal
                    else:
                        result = fn(ctx)
                    
                    execution.result = result
                    results.append(result)
                    logger.debug(f"Sequential execution of {function_name} completed")
                    
                except Exception as e:
                    logger.error(f"Error in sequential execution of {function_name}: {e}")
                    raise
        
        return results
    
    @staticmethod
    def execute_stage(
        functions: List[Callable], 
        ctx: Context, 
        concurrent: bool = False
    ) -> Context:
        """Execute a stage synchronously."""
        if not functions:
            return ctx
        
        if concurrent:
            logger.warning("Concurrent execution requested in sync mode, falling back to sequential")
        
        results = SyncExecutor.execute_sequential(functions, ctx)
        
        # Apply results sequentially to avoid issues
        current_ctx = ctx
        for result in results:
            current_ctx = merge_context(current_ctx, result)
        
        return current_ctx
    
    @staticmethod
    def execute_stage_monitored(
        functions: List[Callable], 
        ctx: Context, 
        concurrent: bool = False,
        stage: Stage = None,
        workflow_id: str = "default"
    ) -> Context:
        """Execute a stage synchronously with state monitoring."""
        if not functions:
            return ctx
        
        if concurrent:
            logger.warning("Concurrent execution requested in sync mode, falling back to sequential")
        
        results = SyncExecutor.execute_sequential_monitored(functions, ctx, stage, workflow_id)
        
        # Apply results sequentially to avoid issues
        current_ctx = ctx
        for result in results:
            current_ctx = merge_context(current_ctx, result)
        
        return current_ctx