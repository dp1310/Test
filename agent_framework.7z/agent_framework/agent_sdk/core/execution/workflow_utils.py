"""Workflow execution utilities for agentic workflows."""

import uuid
from typing import Callable, List, Dict, Any, Optional, Union

from ..context import Context
from ..stages import Stage
from ..state import get_state_manager
from .function_utils import as_task as _as_task
from .context_utils import merge_context_dict as _merge_context_dict
from .prefect_executor import PrefectExecutor
from ...utils.logging import get_logger

logger = get_logger(__name__)


def generate_workflow_id(prefix: str) -> str:
    """Generate a unique workflow ID with given prefix."""
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def initialize_context(input_data: Any, initial_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Initialize context dictionary from input data and initial context."""
    return {"input": input_data, **(initial_context or {})}


def execute_workflow_stages(
    stage_map: Dict[Stage, List[Callable]],
    ctx_data: Union[Dict[str, Any], Context],
    concurrent_settings: Dict[Stage, bool],
    workflow_id: str,
    executor_func: Callable
) -> Union[Dict[str, Any], Context]:
    """Execute workflow stages using provided executor function."""
    stage_order = [Stage.PERCEIVE, Stage.REASON, Stage.PLAN, Stage.ACT, Stage.REVIEW, Stage.LEARN]
    current_ctx = ctx_data
    
    for stage in stage_order:
        stage_functions = stage_map.get(stage, [])
        if stage_functions:
            logger.info(f"Executing {stage.name} stage with {len(stage_functions)} functions")
            is_concurrent = concurrent_settings.get(stage, False)
            current_ctx = executor_func(stage_functions, current_ctx, is_concurrent, stage, workflow_id)
    
    return current_ctx


async def execute_async_workflow_stages(
    stage_map: Dict[Stage, List[Callable]],
    ctx: Context,
    concurrent_settings: Dict[Stage, bool],
    workflow_id: str,
    executor_func: Callable
) -> Context:
    """Execute workflow stages asynchronously using provided executor function."""
    stage_order = [Stage.PERCEIVE, Stage.REASON, Stage.PLAN, Stage.ACT, Stage.REVIEW, Stage.LEARN]
    current_ctx = ctx
    
    for stage in stage_order:
        stage_functions = stage_map.get(stage, [])
        if stage_functions:
            logger.info(f"Executing {stage.name} stage with {len(stage_functions)} functions")
            is_concurrent = concurrent_settings.get(stage, False)
            current_ctx = await executor_func(stage_functions, current_ctx, is_concurrent, stage, workflow_id)
    
    return current_ctx


def handle_workflow_execution(
    workflow_id: str,
    execution_func: Callable,
    *args,
    **kwargs
) -> Any:
    """Handle workflow execution with proper state management and error handling."""
    state_manager = get_state_manager()
    
    try:
        logger.info(f"Starting workflow execution - {workflow_id}")
        state_manager.start_workflow(workflow_id)
        
        result = execution_func(*args, **kwargs)
        
        logger.info(f"Workflow execution completed - {workflow_id}")
        state_manager.complete_workflow(workflow_id)
        return result
        
    except Exception as e:
        logger.error(f"Workflow execution failed - {workflow_id}: {e}")
        state_manager.error_workflow(workflow_id, e)
        raise


async def handle_async_workflow_execution(
    workflow_id: str,
    execution_func: Callable,
    *args,
    **kwargs
) -> Any:
    """Handle async workflow execution with proper state management and error handling."""
    state_manager = get_state_manager()
    
    try:
        logger.info(f"Starting async workflow execution - {workflow_id}")
        state_manager.start_workflow(workflow_id)
        
        result = await execution_func(*args, **kwargs)
        
        logger.info(f"Async workflow execution completed - {workflow_id}")
        state_manager.complete_workflow(workflow_id)
        return result
        
    except Exception as e:
        logger.error(f"Async workflow execution failed - {workflow_id}: {e}")
        state_manager.error_workflow(workflow_id, e)
        raise


def execute_prefect_stage(
    stage_functions: List[Callable],
    ctx_dict: Dict[str, Any],
    is_concurrent: bool,
    stage: Stage,
    workflow_id: str
) -> Dict[str, Any]:
    """Execute a single stage using Prefect tasks."""
    # Convert to Prefect tasks
    tasks = [_as_task(fn) for fn in stage_functions]
    
    # Choose execution strategy
    if is_concurrent:
        results = PrefectExecutor.execute_concurrent_monitored(tasks, ctx_dict, stage, workflow_id)
    else:
        results = PrefectExecutor.execute_sequential_monitored(tasks, ctx_dict, stage, workflow_id)
    
    # Merge results into context
    current_ctx = ctx_dict
    for result in results:
        current_ctx = _merge_context_dict(current_ctx, result)
    
    return current_ctx


async def execute_async_prefect_stage(
    stage_functions: List[Callable],
    ctx_dict: Dict[str, Any],
    is_concurrent: bool,
    stage: Stage,
    workflow_id: str
) -> Dict[str, Any]:
    """Execute a single stage using async Prefect tasks."""
    # Convert to Prefect tasks
    tasks = [_as_task(fn) for fn in stage_functions]
    
    # Choose execution strategy
    if is_concurrent:
        results = await PrefectExecutor.execute_concurrent_async_tasks_monitored(tasks, ctx_dict, stage, workflow_id)
    else:
        results = await PrefectExecutor.execute_async_tasks_monitored(tasks, ctx_dict, stage, workflow_id)
    
    # Merge results into context
    current_ctx = ctx_dict
    logger.debug(f"Merging {len(results)} results into context for stage {stage.name}")
    for i, result in enumerate(results):
        logger.debug(f"Merging result {i}: {result}")
        current_ctx = _merge_context_dict(current_ctx, result)
        logger.debug(f"Context after merge {i}: {list(current_ctx.keys())}")
    
    return current_ctx