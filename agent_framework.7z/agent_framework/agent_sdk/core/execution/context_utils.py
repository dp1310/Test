"""Context utilities for agentic workflows."""

from typing import Dict, Any


def merge_context_dict(ctx: Dict[str, Any], output: Any) -> Dict[str, Any]:
    """Merge output into context dictionary (for Prefect compatibility)."""
    if isinstance(output, dict):
        ctx.update(output)
        return ctx
    else:
        # Store non-dict outputs under a type-based key
        key = f"result_{output.__class__.__name__}"
        ctx[key] = output
        return ctx