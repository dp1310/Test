"""
Observer pattern implementations for stage state monitoring.
"""

from typing import List, Dict, Any
import threading

from .enums import StageState
from .execution import StageExecution
from ...utils.logging import get_logger


class StageStateObserver:
    """Observer interface for stage state changes."""
    
    def on_stage_state_changed(self, execution: StageExecution) -> None:
        """Called when a stage state changes."""
        pass
    
    def on_workflow_started(self, workflow_id: str) -> None:
        """Called when a workflow starts."""
        pass
    
    def on_workflow_completed(self, workflow_id: str, executions: List[StageExecution]) -> None:
        """Called when a workflow completes."""
        pass
    
    def on_workflow_error(self, workflow_id: str, error: Exception) -> None:
        """Called when a workflow encounters an error."""
        pass


class LoggingObserver(StageStateObserver):
    """Observer that logs stage state changes."""
    
    def __init__(self, log_level: str = "INFO"):
        self.logger = get_logger(f"{__name__}.LoggingObserver")
        # Set the logger level properly
        import logging
        level_num = getattr(logging, log_level.upper(), 20)  # Default to INFO level
        self.logger.setLevel(level_num)
        
    def on_stage_state_changed(self, execution: StageExecution) -> None:
        """Log stage state changes."""
        # Log all state changes for testing - include uppercase state name
        self.logger.info(f"Stage {execution.stage.name} {execution.state.value.upper()} - {execution.function_name}")
        
        if execution.state == StageState.STARTED:
            self.logger.info(f"🚀 Stage {execution.stage.name} started - {execution.function_name}")
        elif execution.state == StageState.RUNNING:
            self.logger.info(f"⚡ Stage {execution.stage.name} running - {execution.function_name}")
        elif execution.state == StageState.COMPLETED:
            duration = execution.duration or 0
            self.logger.info(f"✅ Stage {execution.stage.name} completed in {duration:.3f}s - {execution.function_name}")
        elif execution.state == StageState.ERROR:
            self.logger.error(f"❌ Stage {execution.stage.name} failed - {execution.function_name}: {execution.error}")
        elif execution.state == StageState.CANCELLED:
            self.logger.warning(f"⏹️ Stage {execution.stage.name} cancelled - {execution.function_name}")
        elif execution.state == StageState.SKIPPED:
            self.logger.info(f"⏭️ Stage {execution.stage.name} skipped - {execution.function_name}")
    
    def on_workflow_started(self, workflow_id: str) -> None:
        """Log workflow start."""
        self.logger.info(f"Workflow started: {workflow_id}")
    
    def on_workflow_completed(self, workflow_id: str, executions: List[StageExecution]) -> None:
        """Log workflow completion."""
        total_duration = sum(e.duration or 0 for e in executions if e.duration)
        completed_count = sum(1 for e in executions if e.state == StageState.COMPLETED)
        error_count = sum(1 for e in executions if e.state == StageState.ERROR)
        
        self.logger.info(f"Workflow completed: {workflow_id} with {len(executions)} executions")
        self.logger.info(f"Total duration: {total_duration:.3f}s, Completed executions: {completed_count}, Failed executions: {error_count}")
    
    def on_workflow_error(self, workflow_id: str, error: Exception) -> None:
        """Log workflow error."""
        self.logger.error(f"Workflow error: {workflow_id} - {error}")


class MetricsObserver(StageStateObserver):
    """Observer that collects metrics and statistics."""
    
    def __init__(self):
        self.execution_counts = {}
        self.execution_times = {}
        self.error_counts = {}
        self.workflow_counts = {}
        self._lock = threading.Lock()
        self._execution_counter = 0  # Simple counter for unique IDs
        
        # Initialize metrics dict for compatibility with tests
        self.metrics = {
            "total_executions": 0,
            "completed_executions": 0,
            "failed_executions": 0,
            "stage_counts": {},
            "average_durations": {},
            "success_rate": 0.0,
            "error_counts": {}
        }
    
    def on_stage_state_changed(self, execution: StageExecution) -> None:
        """Collect metrics from stage state changes."""
        with self._lock:
            self._ensure_execution_id(execution)
            
            # Map state to handler functions
            state_handlers = {
                StageState.STARTED: self._handle_started,
                StageState.COMPLETED: self._handle_completed,
                StageState.ERROR: self._handle_error
            }
            
            handler = state_handlers.get(execution.state)
            if handler:
                handler(execution)
                self._update_success_rate()
    
    def _ensure_execution_id(self, execution: StageExecution) -> None:
        """Assign unique ID to execution if needed."""
        if not hasattr(execution, '_metrics_id'):
            self._execution_counter += 1
            execution._metrics_id = self._execution_counter
    
    def _handle_started(self, execution: StageExecution) -> None:
        """Handle STARTED state."""
        stage_name = execution.stage.name
        self.metrics["stage_counts"][stage_name] = self.metrics["stage_counts"].get(stage_name, 0) + 1
        self.metrics["total_executions"] += 1
    
    def _handle_completed(self, execution: StageExecution) -> None:
        """Handle COMPLETED state."""
        stage = execution.stage
        stage_name = stage.name
        
        # Update counts
        self.execution_counts[stage] = self.execution_counts.get(stage, 0) + 1
        self.metrics["completed_executions"] += 1
        
        # Track execution time
        if execution.duration is not None:
            self._record_execution_time(stage, stage_name, execution.duration)
    
    def _handle_error(self, execution: StageExecution) -> None:
        """Handle ERROR state."""
        stage = execution.stage
        
        # Update error counts
        self.error_counts[stage] = self.error_counts.get(stage, 0) + 1
        self.metrics["failed_executions"] += 1
        
        # Track error by type
        if execution.error:
            error_type = type(execution.error).__name__
            self.metrics["error_counts"][error_type] = self.metrics["error_counts"].get(error_type, 0) + 1
        
        # Track execution time for errors too
        if execution.duration is not None:
            self._record_execution_time(stage, stage.name, execution.duration)
    
    def _record_execution_time(self, stage, stage_name: str, duration: float) -> None:
        """Record execution time and update averages."""
        if stage not in self.execution_times:
            self.execution_times[stage] = []
        
        self.execution_times[stage].append(duration)
        times = self.execution_times[stage]
        self.metrics["average_durations"][stage_name] = sum(times) / len(times)
    
    def _update_success_rate(self) -> None:
        """Update success rate calculation."""
        total_finished = self.metrics["completed_executions"] + self.metrics["failed_executions"]
        self.metrics["success_rate"] = (
            (self.metrics["completed_executions"] / total_finished) * 100 
            if total_finished > 0 else 0.0
        )
    
    def on_workflow_completed(self, workflow_id: str, executions: List[StageExecution]) -> None:
        """Track workflow completion."""
        with self._lock:
            self.workflow_counts["completed"] = self.workflow_counts.get("completed", 0) + 1
    
    def on_workflow_error(self, workflow_id: str, error: Exception) -> None:
        """Track workflow error."""
        with self._lock:
            self.workflow_counts["errors"] = self.workflow_counts.get("errors", 0) + 1
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics snapshot."""
        with self._lock:
            total_executions = sum(self.execution_counts.values())
            total_errors = sum(self.error_counts.values())
            
            # Calculate average execution time
            all_times = []
            for times in self.execution_times.values():
                all_times.extend(times)
            avg_time = sum(all_times) / len(all_times) if all_times else 0
            
            total_workflows = self.workflow_counts.get("completed", 0) + self.workflow_counts.get("errors", 0)
            
            # Return both the new metrics format and the legacy format for compatibility
            result = {
                "execution_counts": self.execution_counts,
                "execution_times": self.execution_times,
                "error_counts": self.error_counts,
                "workflow_counts": self.workflow_counts,
                "summary": {
                    "total_executions": total_executions,
                    "total_errors": total_errors,
                    "average_execution_time": avg_time,
                    "total_workflows": total_workflows
                }
            }
            
            # Add the metrics that tests expect
            result.update(self.metrics)
            
            return result