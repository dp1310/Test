"""
Stage execution tracking and data structures.
"""

from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime

from .enums import StageState
from ..stages import Stage


@dataclass
class StageExecution:
    """Information about a single stage execution."""
    stage: Stage
    function_name: Optional[str] = None
    workflow_id: Optional[str] = None
    state: StageState = StageState.CREATED
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    error: Optional[Exception] = None
    result: Optional[Any] = None
    execution_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Set start_time if state is CREATED and start_time is None."""
        if self.state == StageState.CREATED and self.start_time is None:
            self.start_time = datetime.now()
    
    @property
    def duration(self) -> Optional[float]:
        """Calculate execution duration in seconds."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return None
    
    @property
    def is_finished(self) -> bool:
        """Check if the stage execution is finished."""
        return self.state in {StageState.COMPLETED, StageState.ERROR, StageState.CANCELLED, StageState.SKIPPED}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        duration = self.duration
        return {
            "stage": self.stage.name,
            "state": self.state.value,  # Use .value for lowercase enum values
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "duration": duration,
            "error": str(self.error) if self.error else None,
            "result": self.result,
            "function_name": self.function_name,
            "execution_id": self.execution_id,
            "workflow_id": self.workflow_id,
            "metadata": self.metadata,
            "is_finished": self.is_finished
        }