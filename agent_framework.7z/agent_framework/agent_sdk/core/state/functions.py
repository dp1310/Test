"""
Global functions for state management using functional programming principles.
"""

from typing import Dict, Any, Optional, List

from .manager import StageStateManager
from .observers import StageStateObserver, LoggingObserver, MetricsObserver

# Global state manager instance
_state_manager = None


def get_state_manager() -> StageStateManager:
    """Get the global stage state manager."""
    global _state_manager
    if _state_manager is None:
        _state_manager = StageStateManager()
        # Add default logging observer
        _state_manager.add_observer(LoggingObserver())
    return _state_manager


def configure_monitoring(enable_logging: bool = True, enable_metrics: bool = True,
                        custom_observers: Optional[List[StageStateObserver]] = None) -> StageStateManager:
    """Configure stage monitoring with observers."""
    state_manager = get_state_manager()
    
    # Clear existing observers
    state_manager.observers.clear()
    
    # Add default observers
    if enable_logging:
        state_manager.add_observer(LoggingObserver())
    
    if enable_metrics:
        state_manager.add_observer(MetricsObserver())
    
    # Add custom observers
    if custom_observers:
        for observer in custom_observers:
            state_manager.add_observer(observer)
    
    return state_manager


def get_workflow_status(workflow_id: str = "default") -> Dict[str, Any]:
    """Get the current status of a workflow."""
    return get_state_manager().get_execution_summary(workflow_id)


def get_metrics() -> Dict[str, Any]:
    """Get current execution metrics."""
    state_manager = get_state_manager()
    metrics_observer = next(
        (obs for obs in state_manager.observers if isinstance(obs, MetricsObserver)),
        None
    )
    return metrics_observer.get_metrics() if metrics_observer else {}