"""
Enumeration types for stage state management.
"""

from enum import Enum


class StageState(Enum):
    """Enumeration of possible stage states."""
    CREATED = "created"
    PENDING = "pending"
    STARTED = "started"
    RUNNING = "running"
    COMPLETED = "completed"
    ERROR = "error"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"