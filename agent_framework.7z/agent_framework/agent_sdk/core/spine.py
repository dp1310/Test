"""Core spine implementation for agentic workflows."""

from typing import Callable, List, Dict, Any, Optional

from prefect import flow

from .context import Context
from .stages import Stage
from .execution.function_utils import (
    collect_functions as _collect_functions,
    wrap_as_task as _wrap_as_task,
    as_task as _as_task
)
from .execution.context_utils import merge_context_dict as _merge_context_dict
from .execution.sync_executor import SyncExecutor
from .execution.async_executor import AsyncExecutor
from .execution.workflow_utils import (
    generate_workflow_id,
    initialize_context,
    execute_workflow_stages,
    execute_async_workflow_stages,
    handle_workflow_execution,
    handle_async_workflow_execution,
    execute_prefect_stage,
    execute_async_prefect_stage
)

# Re-export only the private functions actually used in tests for backward compatibility
_collect_functions = _collect_functions
_wrap_as_task = _wrap_as_task
_as_task = _as_task
_merge_context_dict = _merge_context_dict
_execute_sequential = SyncExecutor.execute_sequential
_execute_concurrent = AsyncExecutor.execute_concurrent
_execute_stage_sync = SyncExecutor.execute_stage
_execute_stage_async = AsyncExecutor.execute_stage


@flow(name="AgenticSpine")
def agentic_spine(
    input_data: Any,
    functions: List[Callable],
    initial_context: Optional[Dict[str, Any]] = None,
    concurrent: Optional[Dict[Stage, bool]] = None,
    workflow_id: Optional[str] = None,
) -> Context:
    """
    Execute agentic workflow using Prefect flow.
    
    Args:
        input_data: Input data for the workflow
        functions: List of stage functions
        initial_context: Additional initial context
        concurrent: Stage-level concurrency settings
        workflow_id: Unique identifier for workflow monitoring
        
    Returns:
        Final context after all stages
    """
    workflow_id = workflow_id or generate_workflow_id("prefect_sync")
    
    def execute_workflow():
        ctx_dict = initialize_context(input_data, initial_context)
        stage_map = _collect_functions(functions)
        concurrent_settings = concurrent or {}
        
        final_ctx = execute_workflow_stages(
            stage_map, ctx_dict, concurrent_settings, workflow_id, execute_prefect_stage
        )
        return Context(data=final_ctx)
    
    return handle_workflow_execution(workflow_id, execute_workflow)


def agentic_spine_simple(
    input_data: Any,
    functions: List[Callable],
    initial_context: Optional[Dict[str, Any]] = None,
    concurrent: Optional[Dict[Stage, bool]] = None,
    workflow_id: Optional[str] = None,
) -> Context:
    """
    Execute agentic workflow without Prefect (simple version).
    
    Args:
        input_data: Input data for the workflow
        functions: List of stage functions
        initial_context: Additional initial context
        concurrent: Stage-level concurrency settings
        workflow_id: Unique identifier for workflow monitoring
        
    Returns:
        Final context after all stages
    """
    workflow_id = workflow_id or generate_workflow_id("simple_sync")
    
    def execute_workflow():
        ctx_data = initialize_context(input_data, initial_context)
        ctx = Context(data=ctx_data)
        stage_map = _collect_functions(functions)
        concurrent_settings = concurrent or {}
        
        return execute_workflow_stages(
            stage_map, ctx, concurrent_settings, workflow_id, 
            SyncExecutor.execute_stage_monitored
        )
    
    return handle_workflow_execution(workflow_id, execute_workflow)


async def agentic_spine_async(
    input_data: Any,
    functions: List[Callable],
    initial_context: Optional[Dict[str, Any]] = None,
    concurrent: Optional[Dict[Stage, bool]] = None,
    workflow_id: Optional[str] = None,
) -> Context:
    """
    Execute agentic workflow asynchronously (simple version).
    
    Args:
        input_data: Input data for the workflow
        functions: List of stage functions
        initial_context: Additional initial context
        concurrent: Stage-level concurrency settings
        workflow_id: Unique identifier for workflow monitoring
        
    Returns:
        Final context after all stages
    """
    workflow_id = workflow_id or generate_workflow_id("simple_async")
    
    async def execute_workflow():
        ctx_data = initialize_context(input_data, initial_context)
        ctx = Context(data=ctx_data)
        stage_map = _collect_functions(functions)
        concurrent_settings = concurrent or {}
        
        return await execute_async_workflow_stages(
            stage_map, ctx, concurrent_settings, workflow_id,
            AsyncExecutor.execute_stage_monitored
        )
    
    return await handle_async_workflow_execution(workflow_id, execute_workflow)


@flow(name="AgenticSpineAsync")
async def agentic_spine_async_prefect(
    input_data: Any,
    functions: List[Callable],
    initial_context: Optional[Dict[str, Any]] = None,
    concurrent: Optional[Dict[Stage, bool]] = None,
    workflow_id: Optional[str] = None,
) -> Context:
    """
    Execute agentic workflow asynchronously using Prefect flow.
    
    Args:
        input_data: Input data for the workflow
        functions: List of stage functions
        initial_context: Additional initial context
        concurrent: Stage-level concurrency settings
        workflow_id: Unique identifier for workflow monitoring
        
    Returns:
        Final context after all stages
    """
    workflow_id = workflow_id or generate_workflow_id("prefect_async")
    
    async def execute_workflow():
        ctx_dict = initialize_context(input_data, initial_context)
        stage_map = _collect_functions(functions)
        concurrent_settings = concurrent or {}
        
        final_ctx = await execute_async_workflow_stages(
            stage_map, ctx_dict, concurrent_settings, workflow_id, execute_async_prefect_stage
        )
        return Context(data=final_ctx)
    
    return await handle_async_workflow_execution(workflow_id, execute_workflow)