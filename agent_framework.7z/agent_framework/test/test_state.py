"""Tests for stage state management and monitoring system."""

import pytest
import asyncio
import time
from datetime import datetime
from typing import Dict, Any
from unittest.mock import Mock, patch

from agent_sdk.core.state import (
    StageState, StageExecution, StageStateObserver, LoggingObserver, MetricsObserver,
    StageStateManager, get_state_manager, stage_execution_context, configure_monitoring,
    get_workflow_status, get_metrics
)
from agent_sdk.core.stages import Stage


class TestStageState:
    """Test StageState enumeration."""
    
    def test_stage_state_values(self):
        """Test that all expected stage states exist."""
        assert StageState.PENDING
        assert StageState.STARTED
        assert StageState.RUNNING
        assert StageState.COMPLETED
        assert StageState.ERROR
        assert StageState.CANCELLED
        assert StageState.SKIPPED
        
        # Test string values
        assert StageState.PENDING.value == "pending"
        assert StageState.STARTED.value == "started"
        assert StageState.RUNNING.value == "running"
        assert StageState.COMPLETED.value == "completed"
        assert StageState.ERROR.value == "error"
        assert StageState.CANCELLED.value == "cancelled"
        assert StageState.SKIPPED.value == "skipped"


class TestStageExecution:
    """Test StageExecution dataclass."""
    
    def test_stage_execution_creation(self):
        """Test creating StageExecution instance."""
        execution = StageExecution(
            stage=Stage.PERCEIVE,
            state=StageState.PENDING,
            function_name="test_function"
        )
        
        assert execution.stage == Stage.PERCEIVE
        assert execution.state == StageState.PENDING
        assert execution.function_name == "test_function"
        assert execution.start_time is None
        assert execution.end_time is None
        assert execution.error is None
        assert execution.result is None
        assert execution.execution_id is None
        assert execution.metadata == {}
    
    def test_stage_execution_duration_calculation(self):
        """Test duration calculation."""
        execution = StageExecution(
            stage=Stage.REASON,
            state=StageState.RUNNING
        )
        
        # No duration when times are None
        assert execution.duration is None
        
        # Set times
        start_time = datetime.now()
        end_time = datetime.now()
        execution.start_time = start_time
        execution.end_time = end_time
        
        # Duration should be calculated
        duration = execution.duration
        assert duration is not None
        assert duration >= 0
    
    def test_stage_execution_is_finished(self):
        """Test is_finished property."""
        execution = StageExecution(
            stage=Stage.PLAN,
            state=StageState.PENDING
        )
        
        # Not finished states
        assert not execution.is_finished
        
        execution.state = StageState.STARTED
        assert not execution.is_finished
        
        execution.state = StageState.RUNNING
        assert not execution.is_finished
        
        # Finished states
        execution.state = StageState.COMPLETED
        assert execution.is_finished
        
        execution.state = StageState.ERROR
        assert execution.is_finished
        
        execution.state = StageState.CANCELLED
        assert execution.is_finished
        
        execution.state = StageState.SKIPPED
        assert execution.is_finished
    
    def test_stage_execution_to_dict(self):
        """Test converting StageExecution to dictionary."""
        start_time = datetime.now()
        end_time = datetime.now()
        error = ValueError("Test error")
        
        execution = StageExecution(
            stage=Stage.ACT,
            state=StageState.ERROR,
            start_time=start_time,
            end_time=end_time,
            error=error,
            result={"test": "result"},
            function_name="test_function",
            execution_id="test_id",
            metadata={"key": "value"}
        )
        
        result_dict = execution.to_dict()
        
        assert result_dict["stage"] == "ACT"
        assert result_dict["state"] == "error"
        assert result_dict["start_time"] == start_time.isoformat()
        assert result_dict["end_time"] == end_time.isoformat()
        assert result_dict["duration"] is not None
        assert result_dict["error"] == "Test error"
        assert result_dict["function_name"] == "test_function"
        assert result_dict["execution_id"] == "test_id"
        assert result_dict["metadata"] == {"key": "value"}
        assert result_dict["is_finished"] is True


class TestStageStateObserver:
    """Test StageStateObserver base class."""
    
    def test_observer_interface(self):
        """Test that observer interface methods exist and can be called."""
        observer = StageStateObserver()
        execution = StageExecution(stage=Stage.PERCEIVE, state=StageState.PENDING)
        
        # Should not raise exceptions
        observer.on_stage_state_changed(execution)
        observer.on_workflow_started("test_workflow")
        observer.on_workflow_completed("test_workflow", [execution])
        observer.on_workflow_error("test_workflow", ValueError("test"))


class TestLoggingObserver:
    """Test LoggingObserver implementation."""
    
    def test_logging_observer_creation(self):
        """Test creating LoggingObserver."""
        observer = LoggingObserver()
        assert observer.logger is not None
        
        observer_with_level = LoggingObserver(log_level="DEBUG")
        assert observer_with_level.logger is not None
    
    @patch('agent_sdk.core.state.get_logger')
    def test_logging_observer_stage_state_changes(self, mock_get_logger):
        """Test logging of stage state changes."""
        mock_logger = Mock()
        mock_get_logger.return_value = mock_logger
        
        observer = LoggingObserver()
        execution = StageExecution(
            stage=Stage.PERCEIVE,
            state=StageState.STARTED,
            function_name="test_function"
        )
        
        # Test different state changes
        observer.on_stage_state_changed(execution)
        mock_logger.info.assert_called()
        
        execution.state = StageState.RUNNING
        observer.on_stage_state_changed(execution)
        mock_logger.info.assert_called()
        
        execution.state = StageState.COMPLETED
        execution.start_time = datetime.now()
        execution.end_time = datetime.now()
        observer.on_stage_state_changed(execution)
        mock_logger.info.assert_called()
        
        execution.state = StageState.ERROR
        execution.error = ValueError("Test error")
        observer.on_stage_state_changed(execution)
        mock_logger.error.assert_called()
        
        execution.state = StageState.CANCELLED
        observer.on_stage_state_changed(execution)
        mock_logger.warning.assert_called()
        
        execution.state = StageState.SKIPPED
        observer.on_stage_state_changed(execution)
        mock_logger.info.assert_called()
    
    @patch('agent_sdk.core.state.get_logger')
    def test_logging_observer_workflow_events(self, mock_get_logger):
        """Test logging of workflow events."""
        mock_logger = Mock()
        mock_get_logger.return_value = mock_logger
        
        observer = LoggingObserver()
        
        # Test workflow started
        observer.on_workflow_started("test_workflow")
        mock_logger.info.assert_called()
        
        # Test workflow completed
        executions = [
            StageExecution(stage=Stage.PERCEIVE, state=StageState.COMPLETED),
            StageExecution(stage=Stage.REASON, state=StageState.ERROR)
        ]
        observer.on_workflow_completed("test_workflow", executions)
        mock_logger.info.assert_called()
        
        # Test workflow error
        observer.on_workflow_error("test_workflow", ValueError("Test error"))
        mock_logger.error.assert_called()


class TestMetricsObserver:
    """Test MetricsObserver implementation."""
    
    def test_metrics_observer_creation(self):
        """Test creating MetricsObserver."""
        observer = MetricsObserver()
        assert observer.metrics is not None
        assert observer.metrics["total_executions"] == 0
        assert observer.metrics["completed_executions"] == 0
        assert observer.metrics["failed_executions"] == 0
    
    def test_metrics_observer_stage_tracking(self):
        """Test metrics collection for stage executions."""
        observer = MetricsObserver()
        
        # Test started execution
        execution = StageExecution(
            stage=Stage.PERCEIVE,
            state=StageState.STARTED,
            function_name="test_function"
        )
        observer.on_stage_state_changed(execution)
        
        metrics = observer.get_metrics()
        assert metrics["total_executions"] == 1
        assert metrics["stage_counts"]["PERCEIVE"] == 1
        
        # Test completed execution
        execution.state = StageState.COMPLETED
        execution.start_time = datetime.now()
        execution.end_time = datetime.now()
        observer.on_stage_state_changed(execution)
        
        metrics = observer.get_metrics()
        assert metrics["completed_executions"] == 1
        assert "PERCEIVE" in metrics["average_durations"]
        
        # Test failed execution
        execution2 = StageExecution(
            stage=Stage.REASON,
            state=StageState.ERROR,
            error=ValueError("Test error")
        )
        observer.on_stage_state_changed(execution2)
        
        metrics = observer.get_metrics()
        assert metrics["failed_executions"] == 1
        assert metrics["error_counts"]["ValueError"] == 1
    
    def test_metrics_observer_success_rate(self):
        """Test success rate calculation."""
        observer = MetricsObserver()
        
        # Add some executions
        for i in range(3):
            execution = StageExecution(
                stage=Stage.PERCEIVE,
                state=StageState.STARTED
            )
            observer.on_stage_state_changed(execution)
            
            if i < 2:  # First two succeed
                execution.state = StageState.COMPLETED
                observer.on_stage_state_changed(execution)
            else:  # Last one fails
                execution.state = StageState.ERROR
                execution.error = ValueError("Test")
                observer.on_stage_state_changed(execution)
        
        metrics = observer.get_metrics()
        assert metrics["success_rate"] == pytest.approx(66.67, rel=1e-2)
    
    def test_metrics_observer_thread_safety(self):
        """Test that metrics observer is thread-safe."""
        observer = MetricsObserver()
        
        def add_execution():
            execution = StageExecution(
                stage=Stage.PERCEIVE,
                state=StageState.STARTED
            )
            observer.on_stage_state_changed(execution)
            execution.state = StageState.COMPLETED
            observer.on_stage_state_changed(execution)
        
        # Run multiple threads
        import threading
        threads = [threading.Thread(target=add_execution) for _ in range(10)]
        
        for thread in threads:
            thread.start()
        
        for thread in threads:
            thread.join()
        
        metrics = observer.get_metrics()
        assert metrics["total_executions"] == 10
        assert metrics["completed_executions"] == 10


class TestStageStateManager:
    """Test StageStateManager implementation."""
    
    def test_state_manager_creation(self):
        """Test creating StageStateManager."""
        manager = StageStateManager()
        assert manager.observers == []
        assert manager.executions == {}
    
    def test_state_manager_observer_management(self):
        """Test adding and removing observers."""
        manager = StageStateManager()
        observer1 = LoggingObserver()
        observer2 = MetricsObserver()
        
        # Add observers
        manager.add_observer(observer1)
        manager.add_observer(observer2)
        assert len(manager.observers) == 2
        assert observer1 in manager.observers
        assert observer2 in manager.observers
        
        # Remove observer
        manager.remove_observer(observer1)
        assert len(manager.observers) == 1
        assert observer1 not in manager.observers
        assert observer2 in manager.observers
        
        # Remove non-existent observer (should not raise)
        manager.remove_observer(observer1)
        assert len(manager.observers) == 1
    
    def test_state_manager_execution_creation(self):
        """Test creating stage executions."""
        manager = StageStateManager()
        
        execution = manager.create_execution(
            stage=Stage.PERCEIVE,
            function_name="test_function",
            workflow_id="test_workflow"
        )
        
        assert execution.stage == Stage.PERCEIVE
        assert execution.function_name == "test_function"
        assert execution.state == StageState.CREATED
        assert execution.execution_id is not None
        assert "test_workflow" in execution.execution_id
        
        # Check that execution is stored
        executions = manager.get_executions("test_workflow")
        assert len(executions) == 1
        assert executions[0] == execution
    
    def test_state_manager_state_updates(self):
        """Test updating execution states."""
        manager = StageStateManager()
        mock_observer = Mock(spec=StageStateObserver)
        manager.add_observer(mock_observer)
        
        execution = manager.create_execution(
            stage=Stage.REASON,
            function_name="test_function"
        )
        
        # Update state
        manager.update_state(
            execution,
            StageState.STARTED,
            metadata={"key": "value"}
        )
        
        assert execution.state == StageState.STARTED
        assert execution.start_time is not None
        assert execution.metadata["key"] == "value"
        mock_observer.on_stage_state_changed.assert_called_with(execution)
        
        # Update to completed
        result = {"result": "data"}
        manager.update_state(execution, StageState.COMPLETED, result=result)
        
        assert execution.state == StageState.COMPLETED
        assert execution.end_time is not None
        assert execution.result == result
    
    def test_state_manager_workflow_events(self):
        """Test workflow event notifications."""
        manager = StageStateManager()
        mock_observer = Mock(spec=StageStateObserver)
        manager.add_observer(mock_observer)
        
        # Test workflow started
        manager.start_workflow("test_workflow")
        mock_observer.on_workflow_started.assert_called_with("test_workflow")
        
        # Test workflow completed
        execution = manager.create_execution(Stage.PERCEIVE, "test_function", "test_workflow")
        manager.complete_workflow("test_workflow")
        mock_observer.on_workflow_completed.assert_called_with("test_workflow", [execution])
        
        # Test workflow error
        error = ValueError("Test error")
        manager.error_workflow("test_workflow", error)
        mock_observer.on_workflow_error.assert_called_with("test_workflow", error)
    
    def test_state_manager_execution_summary(self):
        """Test getting execution summary."""
        manager = StageStateManager()
        
        # Test non-existent workflow
        summary = manager.get_execution_summary("non_existent")
        assert summary["status"] == "not_found"
        
        # Create some executions
        workflow_id = "test_workflow"
        exec1 = manager.create_execution(Stage.PERCEIVE, "func1", workflow_id)
        exec2 = manager.create_execution(Stage.REASON, "func2", workflow_id)
        exec3 = manager.create_execution(Stage.PLAN, "func3", workflow_id)
        
        # Update states
        manager.update_state(exec1, StageState.COMPLETED)
        manager.update_state(exec2, StageState.ERROR, error=ValueError("Test"))
        manager.update_state(exec3, StageState.RUNNING)
        
        summary = manager.get_execution_summary(workflow_id)
        
        assert summary["workflow_id"] == workflow_id
        assert summary["total_stages"] == 3
        assert summary["completed"] == 1
        assert summary["errors"] == 1
        assert summary["running"] == 1
        assert summary["status"] == "running"  # Has running stages
        assert len(summary["executions"]) == 3
    
    def test_state_manager_observer_exception_handling(self):
        """Test that observer exceptions don't break the manager."""
        manager = StageStateManager()
        
        # Create a failing observer
        failing_observer = Mock(spec=StageStateObserver)
        failing_observer.on_stage_state_changed.side_effect = Exception("Observer failed")
        
        working_observer = Mock(spec=StageStateObserver)
        
        manager.add_observer(failing_observer)
        manager.add_observer(working_observer)
        
        execution = manager.create_execution(Stage.PERCEIVE, "test_function")
        
        # This should not raise an exception
        manager.update_state(execution, StageState.STARTED)
        
        # Working observer should still be called
        working_observer.on_stage_state_changed.assert_called_with(execution)


class TestStageExecutionContext:
    """Test stage_execution_context context manager."""
    
    def test_stage_execution_context_success(self):
        """Test successful execution context."""
        with patch('agent_sdk.core.state.get_state_manager') as mock_get_manager:
            mock_manager = Mock()
            mock_execution = Mock()
            mock_manager.create_execution.return_value = mock_execution
            mock_get_manager.return_value = mock_manager
            
            with stage_execution_context(Stage.PERCEIVE, "test_function", "test_workflow") as execution:
                assert execution == mock_execution
            
            # Check that states were updated correctly
            mock_manager.create_execution.assert_called_with(Stage.PERCEIVE, "test_function", "test_workflow")
            
            # Should have been called with STARTED, RUNNING, and COMPLETED
            assert mock_manager.update_state.call_count == 3
            calls = mock_manager.update_state.call_args_list
            assert calls[0][0] == (mock_execution, StageState.STARTED)
            assert calls[1][0] == (mock_execution, StageState.RUNNING)
            assert calls[2][0] == (mock_execution, StageState.COMPLETED)
    
    def test_stage_execution_context_exception(self):
        """Test execution context with exception."""
        with patch('agent_sdk.core.state.get_state_manager') as mock_get_manager:
            mock_manager = Mock()
            mock_execution = Mock()
            mock_manager.create_execution.return_value = mock_execution
            mock_get_manager.return_value = mock_manager
            
            test_error = ValueError("Test error")
            
            with pytest.raises(ValueError):
                with stage_execution_context(Stage.REASON, "test_function") as execution:
                    raise test_error
            
            # Should have been called with STARTED, RUNNING, and ERROR
            assert mock_manager.update_state.call_count == 3
            calls = mock_manager.update_state.call_args_list
            assert calls[0][0] == (mock_execution, StageState.STARTED)
            assert calls[1][0] == (mock_execution, StageState.RUNNING)
            assert calls[2][0] == (mock_execution, StageState.ERROR)
            assert calls[2][1]["error"] == test_error


class TestGlobalFunctions:
    """Test global state management functions."""
    
    def test_get_state_manager(self):
        """Test getting global state manager."""
        manager1 = get_state_manager()
        manager2 = get_state_manager()
        
        # Should return the same instance
        assert manager1 is manager2
        assert isinstance(manager1, StageStateManager)
    
    def test_configure_monitoring(self):
        """Test configuring monitoring."""
        # Test with default settings
        manager = configure_monitoring()
        assert isinstance(manager, StageStateManager)
        assert len(manager.observers) >= 1  # Should have at least logging observer
        
        # Test with custom settings
        custom_observer = Mock(spec=StageStateObserver)
        manager = configure_monitoring(
            enable_logging=False,
            enable_metrics=True,
            custom_observers=[custom_observer]
        )
        
        # Should have metrics observer and custom observer
        observer_types = [type(obs).__name__ for obs in manager.observers]
        assert "MetricsObserver" in observer_types
        assert custom_observer in manager.observers
        assert "LoggingObserver" not in observer_types
    
    def test_get_workflow_status(self):
        """Test getting workflow status."""
        # This should use the global state manager
        status = get_workflow_status("test_workflow")
        assert isinstance(status, dict)
        assert "workflow_id" in status
    
    def test_get_metrics(self):
        """Test getting metrics."""
        # Configure with metrics enabled
        configure_monitoring(enable_metrics=True)
        
        metrics = get_metrics()
        assert isinstance(metrics, dict)
        
        # Should have basic metrics structure
        if "error" not in metrics:  # If MetricsObserver is found
            assert "total_executions" in metrics
            assert "completed_executions" in metrics
            assert "failed_executions" in metrics