"""Tests for context management functionality."""

import pytest
from typing import Dict, Any

from agent_sdk.core.context import Context, merge_context


class TestContext:
    """Test Context class functionality."""
    
    def test_context_creation_empty(self):
        """Test creating empty context."""
        ctx = Context()
        assert ctx.data == {}
        assert len(ctx.data) == 0
    
    def test_context_creation_with_data(self):
        """Test creating context with initial data."""
        data = {"key1": "value1", "key2": 42}
        ctx = Context(data=data)
        
        assert ctx.data == data
        assert ctx.get("key1") == "value1"
        assert ctx.get("key2") == 42
    
    def test_context_get_method(self):
        """Test context get method."""
        ctx = Context(data={"existing": "value"})
        
        # Test existing key
        assert ctx.get("existing") == "value"
        
        # Test missing key with default
        assert ctx.get("missing", "default") == "default"
        
        # Test missing key without default
        assert ctx.get("missing") is None
    
    def test_context_dict_access(self):
        """Test dictionary-like access to context."""
        ctx = Context(data={"key": "value"})
        
        # Test __getitem__
        assert ctx["key"] == "value"
        
        # Test __contains__
        assert "key" in ctx
        assert "missing" not in ctx
        
        # Test KeyError for missing key
        with pytest.raises(KeyError):
            _ = ctx["missing"]
    
    def test_context_with_data(self):
        """Test creating new context with additional data."""
        ctx1 = Context(data={"original": "value"})
        ctx2 = ctx1.with_data(new_key="new_value", another="data")
        
        # Original context unchanged
        assert ctx1.get("new_key") is None
        assert ctx1.get("another") is None
        assert ctx1.get("original") == "value"
        
        # New context has all data
        assert ctx2.get("original") == "value"
        assert ctx2.get("new_key") == "new_value"
        assert ctx2.get("another") == "data"
        
        # Contexts are different objects
        assert ctx1 is not ctx2
        assert ctx1.data is not ctx2.data
    
    def test_context_with_data_override(self):
        """Test that with_data can override existing keys."""
        ctx1 = Context(data={"key": "original"})
        ctx2 = ctx1.with_data(key="overridden")
        
        assert ctx1.get("key") == "original"
        assert ctx2.get("key") == "overridden"
    
    def test_context_merge_with_context(self):
        """Test merging context with another context."""
        ctx1 = Context(data={"key1": "value1"})
        ctx2 = Context(data={"key2": "value2"})
        
        merged = ctx1.merge(ctx2)
        
        assert merged.get("key1") == "value1"
        assert merged.get("key2") == "value2"
        
        # Original contexts unchanged
        assert ctx1.get("key2") is None
        assert ctx2.get("key1") is None
    
    def test_context_merge_with_dict(self):
        """Test merging context with dictionary."""
        ctx = Context(data={"existing": "value"})
        data = {"new": "data", "another": 123}
        
        merged = ctx.merge(data)
        
        assert merged.get("existing") == "value"
        assert merged.get("new") == "data"
        assert merged.get("another") == 123
        
        # Original context unchanged
        assert ctx.get("new") is None
    
    def test_context_merge_override(self):
        """Test that merge can override existing keys."""
        ctx1 = Context(data={"key": "original", "other": "unchanged"})
        ctx2 = Context(data={"key": "overridden"})
        
        merged = ctx1.merge(ctx2)
        
        assert merged.get("key") == "overridden"
        assert merged.get("other") == "unchanged"
    
    def test_context_immutability(self):
        """Test that context operations maintain immutability."""
        original_data = {"key": "value"}
        ctx1 = Context(data=original_data)
        ctx2 = ctx1.with_data(new_key="new_value")
        
        # Modifying original data shouldn't affect contexts
        original_data["key"] = "modified"
        original_data["new_key"] = "should_not_appear"
        
        assert ctx1.get("key") == "value"  # Should be unchanged
        assert ctx2.get("key") == "value"  # Should be unchanged
        assert ctx2.get("new_key") == "new_value"  # Should be unchanged
    
    def test_context_complex_data_types(self):
        """Test context with complex data types."""
        complex_data = {
            "list": [1, 2, 3],
            "dict": {"nested": "value"},
            "tuple": (1, 2, 3),
            "set": {1, 2, 3},
            "none": None,
            "bool": True
        }
        
        ctx = Context(data=complex_data)
        
        assert ctx.get("list") == [1, 2, 3]
        assert ctx.get("dict") == {"nested": "value"}
        assert ctx.get("tuple") == (1, 2, 3)
        assert ctx.get("set") == {1, 2, 3}
        assert ctx.get("none") is None
        assert ctx.get("bool") is True


class TestMergeContext:
    """Test merge_context function."""
    
    def test_merge_context_with_dict(self):
        """Test merging context with dictionary output."""
        ctx = Context(data={"existing": "value"})
        output = {"new": "data", "number": 42}
        
        merged = merge_context(ctx, output)
        
        assert merged.get("existing") == "value"
        assert merged.get("new") == "data"
        assert merged.get("number") == 42
        
        # Original context unchanged
        assert ctx.get("new") is None
    
    def test_merge_context_with_non_dict(self):
        """Test merging context with non-dictionary output."""
        ctx = Context(data={"existing": "value"})
        
        # Test with string
        merged_str = merge_context(ctx, "string_output")
        assert merged_str.get("existing") == "value"
        assert merged_str.get("result_str") == "string_output"
        
        # Test with number
        merged_int = merge_context(ctx, 42)
        assert merged_int.get("existing") == "value"
        assert merged_int.get("result_int") == 42
        
        # Test with list
        merged_list = merge_context(ctx, [1, 2, 3])
        assert merged_list.get("existing") == "value"
        assert merged_list.get("result_list") == [1, 2, 3]
        
        # Test with custom object
        class CustomObject:
            pass
        
        obj = CustomObject()
        merged_obj = merge_context(ctx, obj)
        assert merged_obj.get("existing") == "value"
        assert merged_obj.get("result_CustomObject") == obj
    
    def test_merge_context_with_none(self):
        """Test merging context with None output."""
        ctx = Context(data={"existing": "value"})
        merged = merge_context(ctx, None)
        
        assert merged.get("existing") == "value"
        assert merged.get("result_NoneType") is None
    
    def test_merge_context_empty_dict(self):
        """Test merging context with empty dictionary."""
        ctx = Context(data={"existing": "value"})
        merged = merge_context(ctx, {})
        
        assert merged.get("existing") == "value"
        # Empty dict should not add any new keys
        assert len(merged.data) == 1
    
    def test_merge_context_override_existing(self):
        """Test that merge_context can override existing keys."""
        ctx = Context(data={"key": "original", "other": "unchanged"})
        output = {"key": "overridden"}
        
        merged = merge_context(ctx, output)
        
        assert merged.get("key") == "overridden"
        assert merged.get("other") == "unchanged"
    
    def test_merge_context_preserves_original(self):
        """Test that merge_context doesn't modify original context."""
        original_data = {"key": "value"}
        ctx = Context(data=original_data)
        output = {"new": "data"}
        
        merged = merge_context(ctx, output)
        
        # Original context and data unchanged
        assert ctx.get("new") is None
        assert "new" not in original_data
        assert ctx.data is not merged.data
    
    def test_merge_context_nested_structures(self):
        """Test merging with nested data structures."""
        ctx = Context(data={
            "level1": {
                "level2": "original"
            }
        })
        
        output = {
            "level1": {
                "level2": "overridden",
                "new_level2": "added"
            },
            "new_level1": "new"
        }
        
        merged = merge_context(ctx, output)
        
        # The entire level1 dict should be replaced, not merged
        assert merged.get("level1") == {
            "level2": "overridden",
            "new_level2": "added"
        }
        assert merged.get("new_level1") == "new"
    
    def test_merge_context_type_consistency(self):
        """Test that merge_context maintains type consistency."""
        ctx = Context(data={"key": "string_value"})
        
        # Override with different type
        output = {"key": 42}
        merged = merge_context(ctx, output)
        
        assert merged.get("key") == 42
        assert isinstance(merged.get("key"), int)


class TestContextEdgeCases:
    """Test edge cases for context functionality."""
    
    def test_context_with_special_keys(self):
        """Test context with special key names."""
        special_data = {
            "": "empty_string_key",
            " ": "space_key",
            "key with spaces": "spaced_key",
            "key-with-dashes": "dashed_key",
            "key_with_underscores": "underscored_key",
            "123": "numeric_string_key",
            "key.with.dots": "dotted_key"
        }
        
        ctx = Context(data=special_data)
        
        assert ctx.get("") == "empty_string_key"
        assert ctx.get(" ") == "space_key"
        assert ctx.get("key with spaces") == "spaced_key"
        assert ctx.get("key-with-dashes") == "dashed_key"
        assert ctx.get("key_with_underscores") == "underscored_key"
        assert ctx.get("123") == "numeric_string_key"
        assert ctx.get("key.with.dots") == "dotted_key"
    
    def test_context_large_data(self):
        """Test context with large amounts of data."""
        large_data = {f"key_{i}": f"value_{i}" for i in range(1000)}
        ctx = Context(data=large_data)
        
        assert len(ctx.data) == 1000
        assert ctx.get("key_0") == "value_0"
        assert ctx.get("key_999") == "value_999"
        assert ctx.get("key_1000") is None
    
    def test_context_circular_references(self):
        """Test context behavior with circular references."""
        # Create circular reference
        data = {"key": "value"}
        data["self"] = data
        
        ctx = Context(data=data)
        
        assert ctx.get("key") == "value"
        assert ctx.get("self") is data
        assert ctx.get("self")["key"] == "value"