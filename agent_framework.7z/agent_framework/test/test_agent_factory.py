"""Tests for agent factory functionality."""

import pytest
from typing import List, Callable, Dict, Any, Optional
from unittest.mock import Mock, patch

from agent_sdk.agent.agent_factory import (
    AgentType, AgentFactory, create_agent, create_simple_sync_agent,
    create_simple_async_agent, create_prefect_sync_agent, create_prefect_async_agent
)
from agent_sdk.agent.base_agent import BaseAgent
from agent_sdk.core.stages import Stage


class MockAgent(BaseAgent):
    """Mock agent for testing."""
    
    def __init__(self, functions=None, initial_context=None, concurrent=None, workflow_id=None):
        super().__init__(functions, initial_context, concurrent, workflow_id)
        self.execution_calls = []
    
    def execute(self, input_data):
        self.execution_calls.append(input_data)
        return {"mock": True, "input": input_data}
    
    def get_execution_type(self):
        return "mock"


class TestAgentType:
    """Test AgentType enumeration."""
    
    def test_agent_type_values(self):
        """Test that all expected agent types exist."""
        assert AgentType.SIMPLE_SYNC
        assert AgentType.SIMPLE_ASYNC
        assert AgentType.PREFECT_SYNC
        assert AgentType.PREFECT_ASYNC
        
        # Test string values
        assert AgentType.SIMPLE_SYNC.value == "simple_sync"
        assert AgentType.SIMPLE_ASYNC.value == "simple_async"
        assert AgentType.PREFECT_SYNC.value == "prefect_sync"
        assert AgentType.PREFECT_ASYNC.value == "prefect_async"
    
    def test_agent_type_uniqueness(self):
        """Test that all agent types have unique values."""
        types = [AgentType.SIMPLE_SYNC, AgentType.SIMPLE_ASYNC, 
                AgentType.PREFECT_SYNC, AgentType.PREFECT_ASYNC]
        values = [t.value for t in types]
        assert len(set(values)) == len(values)


class TestAgentFactory:
    """Test AgentFactory class."""
    
    def test_agent_factory_has_agent_classes(self):
        """Test that factory has all expected agent classes."""
        assert AgentType.SIMPLE_SYNC in AgentFactory._agent_classes
        assert AgentType.SIMPLE_ASYNC in AgentFactory._agent_classes
        assert AgentType.PREFECT_SYNC in AgentFactory._agent_classes
        assert AgentType.PREFECT_ASYNC in AgentFactory._agent_classes
        
        # All should be BaseAgent subclasses
        for agent_class in AgentFactory._agent_classes.values():
            assert issubclass(agent_class, BaseAgent)
    
    def test_create_agent_with_enum(self):
        """Test creating agent with AgentType enum."""
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.SIMPLE_SYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = mock_agent_class
            
            functions = [Mock()]
            initial_context = {"key": "value"}
            concurrent = {Stage.PERCEIVE: True}
            workflow_id = "test_workflow"
            
            result = AgentFactory.create_agent(
                AgentType.SIMPLE_SYNC,
                functions=functions,
                initial_context=initial_context,
                concurrent=concurrent,
                workflow_id=workflow_id
            )
            
            assert result == mock_instance
            mock_agent_class.assert_called_once_with(
                functions=functions,
                initial_context=initial_context,
                concurrent=concurrent,
                workflow_id=workflow_id
            )
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = original_class
    
    def test_create_agent_with_string(self):
        """Test creating agent with string type."""
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC] = mock_agent_class
            
            result = AgentFactory.create_agent("simple_async")
            
            assert result == mock_instance
            mock_agent_class.assert_called_once_with(
                functions=None,
                initial_context=None,
                concurrent=None,
                workflow_id=None
            )
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC] = original_class
    
    def test_create_agent_invalid_string(self):
        """Test creating agent with invalid string type."""
        with pytest.raises(ValueError, match="Unsupported agent type: invalid_type"):
            AgentFactory.create_agent("invalid_type")
    
    def test_create_agent_invalid_enum(self):
        """Test creating agent with invalid enum (hypothetically)."""
        # Create a mock enum that's not in the registry
        class FakeAgentType:
            value = "fake_type"
        
        fake_type = FakeAgentType()
        
        with pytest.raises(ValueError, match="Unsupported agent type"):
            AgentFactory.create_agent(fake_type)
    
    def test_create_simple_sync_agent(self):
        """Test create_simple_sync_agent method."""
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.SIMPLE_SYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = mock_agent_class
            
            functions = [Mock()]
            result = AgentFactory.create_simple_sync_agent(functions=functions)
            
            assert result == mock_instance
            mock_agent_class.assert_called_once_with(
                functions=functions,
                initial_context=None,
                concurrent=None,
                workflow_id=None
            )
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = original_class
    
    def test_create_simple_async_agent(self):
        """Test create_simple_async_agent method."""
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC] = mock_agent_class
            
            initial_context = {"test": "context"}
            result = AgentFactory.create_simple_async_agent(initial_context=initial_context)
            
            assert result == mock_instance
            mock_agent_class.assert_called_once_with(
                functions=None,
                initial_context=initial_context,
                concurrent=None,
                workflow_id=None
            )
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC] = original_class
    
    def test_create_prefect_sync_agent(self):
        """Test create_prefect_sync_agent method."""
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.PREFECT_SYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.PREFECT_SYNC] = mock_agent_class
            
            concurrent = {Stage.PERCEIVE: True}
            result = AgentFactory.create_prefect_sync_agent(concurrent=concurrent)
            
            assert result == mock_instance
            mock_agent_class.assert_called_once_with(
                functions=None,
                initial_context=None,
                concurrent=concurrent,
                workflow_id=None
            )
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.PREFECT_SYNC] = original_class
    
    def test_create_prefect_async_agent(self):
        """Test create_prefect_async_agent method."""
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.PREFECT_ASYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.PREFECT_ASYNC] = mock_agent_class
            
            workflow_id = "test_workflow"
            result = AgentFactory.create_prefect_async_agent(workflow_id=workflow_id)
            
            assert result == mock_instance
            mock_agent_class.assert_called_once_with(
                functions=None,
                initial_context=None,
                concurrent=None,
                workflow_id=workflow_id
            )
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.PREFECT_ASYNC] = original_class
    
    def test_get_available_types(self):
        """Test getting available agent types."""
        available_types = AgentFactory.get_available_types()
        
        expected_types = ["simple_sync", "simple_async", "prefect_sync", "prefect_async"]
        assert set(available_types) == set(expected_types)
        assert len(available_types) == len(expected_types)
    
    def test_register_agent_type(self):
        """Test registering new agent type."""
        # Create a new agent type enum value (simulate extending the enum)
        class CustomAgentType:
            value = "custom"
        
        custom_type = CustomAgentType()
        
        # Register the new type
        AgentFactory.register_agent_type(custom_type, MockAgent)
        
        # Should be able to create agent of new type
        assert custom_type in AgentFactory._agent_classes
        assert AgentFactory._agent_classes[custom_type] == MockAgent
        
        # Clean up
        del AgentFactory._agent_classes[custom_type]
    
    def test_register_agent_type_invalid_class(self):
        """Test registering agent type with invalid class."""
        class NotAnAgent:
            pass
        
        class CustomAgentType:
            value = "invalid"
        
        custom_type = CustomAgentType()
        
        with pytest.raises(ValueError, match="Agent class must inherit from BaseAgent"):
            AgentFactory.register_agent_type(custom_type, NotAnAgent)
    
    @patch('agent_sdk.agent.agent_factory.logger')
    def test_create_agent_logging(self, mock_logger):
        """Test that agent creation is logged."""
        with patch('agent_sdk.agent.agent_factory.SimpleSyncAgent') as mock_agent_class:
            mock_agent_class.return_value = Mock()
            
            AgentFactory.create_agent(AgentType.SIMPLE_SYNC)
            
            mock_logger.info.assert_called_with("Creating simple_sync agent")
    
    @patch('agent_sdk.agent.agent_factory.logger')
    def test_register_agent_type_logging(self, mock_logger):
        """Test that agent type registration is logged."""
        class CustomAgentType:
            value = "custom_logged"
        
        custom_type = CustomAgentType()
        
        try:
            AgentFactory.register_agent_type(custom_type, MockAgent)
            mock_logger.info.assert_called_with("Registered new agent type: custom_logged")
        finally:
            # Clean up
            if custom_type in AgentFactory._agent_classes:
                del AgentFactory._agent_classes[custom_type]


class TestConvenienceFunctions:
    """Test convenience functions for agent creation."""
    
    @patch('agent_sdk.agent.agent_factory.AgentFactory.create_agent')
    def test_create_agent_function(self, mock_create_agent):
        """Test create_agent convenience function."""
        mock_agent = Mock()
        mock_create_agent.return_value = mock_agent
        
        functions = [Mock()]
        result = create_agent(AgentType.SIMPLE_SYNC, functions=functions)
        
        assert result == mock_agent
        mock_create_agent.assert_called_once_with(AgentType.SIMPLE_SYNC, functions=functions)
    
    @patch('agent_sdk.agent.agent_factory.AgentFactory.create_simple_sync_agent')
    def test_create_simple_sync_agent_function(self, mock_create):
        """Test create_simple_sync_agent convenience function."""
        mock_agent = Mock()
        mock_create.return_value = mock_agent
        
        initial_context = {"test": "context"}
        result = create_simple_sync_agent(initial_context=initial_context)
        
        assert result == mock_agent
        mock_create.assert_called_once_with(initial_context=initial_context)
    
    @patch('agent_sdk.agent.agent_factory.AgentFactory.create_simple_async_agent')
    def test_create_simple_async_agent_function(self, mock_create):
        """Test create_simple_async_agent convenience function."""
        mock_agent = Mock()
        mock_create.return_value = mock_agent
        
        concurrent = {Stage.REASON: True}
        result = create_simple_async_agent(concurrent=concurrent)
        
        assert result == mock_agent
        mock_create.assert_called_once_with(concurrent=concurrent)
    
    @patch('agent_sdk.agent.agent_factory.AgentFactory.create_prefect_sync_agent')
    def test_create_prefect_sync_agent_function(self, mock_create):
        """Test create_prefect_sync_agent convenience function."""
        mock_agent = Mock()
        mock_create.return_value = mock_agent
        
        workflow_id = "test_workflow"
        result = create_prefect_sync_agent(workflow_id=workflow_id)
        
        assert result == mock_agent
        mock_create.assert_called_once_with(workflow_id=workflow_id)
    
    @patch('agent_sdk.agent.agent_factory.AgentFactory.create_prefect_async_agent')
    def test_create_prefect_async_agent_function(self, mock_create):
        """Test create_prefect_async_agent convenience function."""
        mock_agent = Mock()
        mock_create.return_value = mock_agent
        
        functions = [Mock(), Mock()]
        result = create_prefect_async_agent(functions=functions)
        
        assert result == mock_agent
        mock_create.assert_called_once_with(functions=functions)


class TestAgentFactoryEdgeCases:
    """Test edge cases for agent factory."""
    
    def test_create_agent_with_all_parameters(self):
        """Test creating agent with all possible parameters."""
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.SIMPLE_SYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = mock_agent_class
            
            functions = [Mock(), Mock()]
            initial_context = {"key1": "value1", "key2": "value2"}
            concurrent = {Stage.PERCEIVE: True, Stage.REASON: False}
            workflow_id = "comprehensive_test"
            
            result = AgentFactory.create_agent(
                AgentType.SIMPLE_SYNC,
                functions=functions,
                initial_context=initial_context,
                concurrent=concurrent,
                workflow_id=workflow_id
            )
            
            assert result == mock_instance
            mock_agent_class.assert_called_once_with(
                functions=functions,
                initial_context=initial_context,
                concurrent=concurrent,
                workflow_id=workflow_id
            )
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = original_class
    
    def test_create_agent_with_no_parameters(self):
        """Test creating agent with no optional parameters."""
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC] = mock_agent_class
            
            result = AgentFactory.create_agent(AgentType.SIMPLE_ASYNC)
            
            assert result == mock_instance
            mock_agent_class.assert_called_once_with(
                functions=None,
                initial_context=None,
                concurrent=None,
                workflow_id=None
            )
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.SIMPLE_ASYNC] = original_class
    
    def test_factory_state_isolation(self):
        """Test that factory state changes don't affect other tests."""
        # Get initial state
        initial_classes = AgentFactory._agent_classes.copy()
        initial_types = AgentFactory.get_available_types()
        
        # Register a temporary agent type
        class TempAgentType:
            value = "temporary"
        
        temp_type = TempAgentType()
        AgentFactory.register_agent_type(temp_type, MockAgent)
        
        # Verify it was added to _agent_classes
        assert temp_type in AgentFactory._agent_classes
        # Note: get_available_types() only returns enum values, not dynamically registered ones
        # This is correct behavior since it's based on the AgentType enum
        assert set(AgentFactory.get_available_types()) == set(initial_types)
        
        # Clean up
        del AgentFactory._agent_classes[temp_type]
        
        # Verify state is restored
        assert AgentFactory._agent_classes == initial_classes
        assert set(AgentFactory.get_available_types()) == set(initial_types)
    
    def test_create_agent_string_case_sensitivity(self):
        """Test that string agent types are case sensitive."""
        with pytest.raises(ValueError, match="Unsupported agent type: SIMPLE_SYNC"):
            AgentFactory.create_agent("SIMPLE_SYNC")
        
        with pytest.raises(ValueError, match="Unsupported agent type: Simple_Sync"):
            AgentFactory.create_agent("Simple_Sync")
        
        # But correct case should work
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.SIMPLE_SYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = mock_agent_class
            
            result = AgentFactory.create_agent("simple_sync")
            assert result == mock_instance
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = original_class
    
    def test_agent_factory_thread_safety(self):
        """Test that agent factory operations are thread-safe."""
        import threading
        import time
        
        results = []
        errors = []
        
        # Store original class
        original_class = AgentFactory._agent_classes[AgentType.SIMPLE_SYNC]
        
        try:
            # Replace with mock
            mock_agent_class = Mock()
            mock_instance = Mock()
            mock_agent_class.return_value = mock_instance
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = mock_agent_class
            
            def create_agents():
                try:
                    for _ in range(10):
                        agent = AgentFactory.create_agent(AgentType.SIMPLE_SYNC)
                        results.append(agent)
                        time.sleep(0.001)  # Small delay to encourage race conditions
                except Exception as e:
                    errors.append(e)
            
            # Run multiple threads
            threads = [threading.Thread(target=create_agents) for _ in range(3)]
            
            for thread in threads:
                thread.start()
            
            for thread in threads:
                thread.join()
            
            # Should have no errors and expected number of results
            assert len(errors) == 0
            assert len(results) == 30  # 3 threads * 10 agents each
        finally:
            # Restore original class
            AgentFactory._agent_classes[AgentType.SIMPLE_SYNC] = original_class