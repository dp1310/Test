"""Tests for Prefect integration in the agent SDK."""

import pytest
from typing import Dict, Any
from prefect import task

import sys
import os
# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    Stage, perceive, reason, plan, act,
    agentic_spine, agentic_spine_simple,
    Context
)


class TestPrefectIntegration:
    """Test Prefect integration functionality."""
    
    def test_prefect_task_decoration(self):
        """Test that functions can be decorated as both stage and Prefect task."""
        @perceive
        @task(name="test_prefect_task")
        def test_function(ctx: Dict[str, Any]) -> Dict[str, Any]:
            return {"test": "value"}
        
        # Should have both stage and task attributes
        assert hasattr(test_function, "_agent_stage")
        assert test_function._agent_stage == Stage.PERCEIVE
        assert hasattr(test_function, "submit")  # Prefect task method
    
    def test_prefect_spine_execution(self):
        """Test Prefect-powered spine execution."""
        @perceive
        @task(name="prefect_perceive")
        def prefect_perceive_fn(ctx: Dict[str, Any]) -> Dict[str, Any]:
            return {"perceived": True, "processor": "prefect"}
        
        @reason
        def regular_reason_fn(ctx: Dict[str, Any]) -> Dict[str, Any]:
            return {"reasoned": ctx.get("perceived", False)}
        
        result = agentic_spine(
            input_data={"test": "data"},
            functions=[prefect_perceive_fn, regular_reason_fn]
        )
        
        assert result.get("perceived") is True
        assert result.get("reasoned") is True
        assert result.get("processor") == "prefect"
        assert result.get("input") == {"test": "data"}
    
    def test_prefect_vs_simple_comparison(self):
        """Test that both Prefect and simple versions produce similar results."""
        @perceive
        def perceive_fn(ctx) -> Dict[str, Any]:
            # Works with both Context and dict
            if isinstance(ctx, Context):
                text = ctx.get("input", {}).get("text", "")
            else:
                text = ctx.get("input", {}).get("text", "")
            return {"analyzed": True, "text_length": len(text)}
        
        @reason
        def reason_fn(ctx) -> Dict[str, Any]:
            if isinstance(ctx, Context):
                analyzed = ctx.get("analyzed", False)
            else:
                analyzed = ctx.get("analyzed", False)
            return {"decision": "approve" if analyzed else "reject"}
        
        # Test simple version
        simple_result = agentic_spine_simple(
            input_data={"text": "test message"},
            functions=[perceive_fn, reason_fn]
        )
        
        # Test Prefect version
        prefect_result = agentic_spine(
            input_data={"text": "test message"},
            functions=[perceive_fn, reason_fn]
        )
        
        # Both should produce similar core results
        assert simple_result.get("analyzed") == prefect_result.get("analyzed")
        assert simple_result.get("decision") == prefect_result.get("decision")
        assert simple_result.get("text_length") == prefect_result.get("text_length")
    
    def test_prefect_concurrent_execution(self):
        """Test concurrent execution with Prefect tasks."""
        execution_order = []
        
        @perceive
        @task(name="task_1")
        def task_1(ctx: Dict[str, Any]) -> Dict[str, Any]:
            execution_order.append("task_1")
            return {"task_1": "completed"}
        
        @perceive
        @task(name="task_2")
        def task_2(ctx: Dict[str, Any]) -> Dict[str, Any]:
            execution_order.append("task_2")
            return {"task_2": "completed"}
        
        @reason
        def reason_task(ctx: Dict[str, Any]) -> Dict[str, Any]:
            execution_order.append("reason")
            return {"reasoning": "done"}
        
        result = agentic_spine(
            input_data={"test": "concurrent"},
            functions=[task_1, task_2, reason_task],
            concurrent={Stage.PERCEIVE: True}
        )
        
        # Both perception tasks should complete
        assert result.get("task_1") == "completed"
        assert result.get("task_2") == "completed"
        assert result.get("reasoning") == "done"
        
        # Reason should execute after perception tasks
        assert "reason" in execution_order
        assert execution_order.index("reason") > max(
            execution_order.index("task_1"),
            execution_order.index("task_2")
        )
    
    def test_mixed_prefect_and_regular_functions(self):
        """Test mixing Prefect tasks with regular functions."""
        @perceive
        @task(name="prefect_task")
        def prefect_task(ctx: Dict[str, Any]) -> Dict[str, Any]:
            return {"prefect_processed": True}
        
        @perceive
        def regular_function(ctx) -> Dict[str, Any]:
            return {"regular_processed": True}
        
        @reason
        def combine_results(ctx) -> Dict[str, Any]:
            if isinstance(ctx, Context):
                prefect_done = ctx.get("prefect_processed", False)
                regular_done = ctx.get("regular_processed", False)
            else:
                prefect_done = ctx.get("prefect_processed", False)
                regular_done = ctx.get("regular_processed", False)
            
            return {"both_completed": prefect_done and regular_done}
        
        result = agentic_spine(
            input_data={"test": "mixed"},
            functions=[prefect_task, regular_function, combine_results]
        )
        
        assert result.get("prefect_processed") is True
        assert result.get("regular_processed") is True
        assert result.get("both_completed") is True
    
    def test_prefect_task_error_handling(self):
        """Test error handling in Prefect tasks."""
        @perceive
        @task(name="failing_task")
        def failing_task(ctx: Dict[str, Any]) -> Dict[str, Any]:
            raise ValueError("Prefect task error")
        
        with pytest.raises(ValueError, match="Prefect task error"):
            agentic_spine(
                input_data={"test": "error"},
                functions=[failing_task]
            )
    
    def test_prefect_context_compatibility(self):
        """Test that Prefect tasks work with dict contexts."""
        @perceive
        @task(name="dict_context_task")
        def dict_context_task(ctx: Dict[str, Any]) -> Dict[str, Any]:
            # Prefect tasks receive dict context, not Context objects
            assert isinstance(ctx, dict)
            assert "input" in ctx
            return {"context_type": type(ctx).__name__}
        
        result = agentic_spine(
            input_data={"test": "context"},
            functions=[dict_context_task]
        )
        
        assert result.get("context_type") == "dict"


class TestPrefectFeatures:
    """Test specific Prefect features integration."""
    
    def test_task_naming(self):
        """Test that Prefect tasks have proper names."""
        @perceive
        @task(name="custom_task_name")
        def named_task(ctx: Dict[str, Any]) -> Dict[str, Any]:
            return {"named": True}
        
        # Task should have the custom name
        assert named_task.name == "custom_task_name"
    
    def test_task_with_retries(self):
        """Test Prefect task with retry configuration."""
        attempt_count = 0
        
        @perceive
        @task(name="retry_task", retries=2)
        def retry_task(ctx: Dict[str, Any]) -> Dict[str, Any]:
            nonlocal attempt_count
            attempt_count += 1
            if attempt_count < 2:
                raise Exception("Temporary failure")
            return {"attempts": attempt_count}
        
        result = agentic_spine(
            input_data={"test": "retry"},
            functions=[retry_task]
        )
        
        # Should succeed after retry
        assert result.get("attempts") == 2
    
    def test_sequential_vs_concurrent_timing(self):
        """Test that concurrent execution is faster than sequential."""
        import time
        
        @perceive
        @task(name="slow_task_1")
        def slow_task_1(ctx: Dict[str, Any]) -> Dict[str, Any]:
            time.sleep(0.1)
            return {"task_1": "done"}
        
        @perceive
        @task(name="slow_task_2")
        def slow_task_2(ctx: Dict[str, Any]) -> Dict[str, Any]:
            time.sleep(0.1)
            return {"task_2": "done"}
        
        # Sequential execution
        start_time = time.time()
        result_seq = agentic_spine(
            input_data={"test": "timing"},
            functions=[slow_task_1, slow_task_2],
            concurrent={Stage.PERCEIVE: False}
        )
        sequential_time = time.time() - start_time
        
        # Concurrent execution
        start_time = time.time()
        result_conc = agentic_spine(
            input_data={"test": "timing"},
            functions=[slow_task_1, slow_task_2],
            concurrent={Stage.PERCEIVE: True}
        )
        concurrent_time = time.time() - start_time
        
        # Both should produce same results
        assert result_seq.get("task_1") == result_conc.get("task_1")
        assert result_seq.get("task_2") == result_conc.get("task_2")
        
        # Concurrent should be faster (with some tolerance for test environment)
        # In some environments, overhead might make this less predictable
        assert concurrent_time < sequential_time * 1.1  # Allow for some overhead