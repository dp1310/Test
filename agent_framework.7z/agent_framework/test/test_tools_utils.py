"""Tests for utility tools module."""

import pytest
import asyncio
import tempfile
import os
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch, MagicMock, mock_open
from typing import Dict, Any, List

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from agent_sdk.tools.utils import FileTool, EmailTool, SlackTool
from agent_sdk.tools.base import ToolResult, ToolStatus, ToolError


class TestFileTool:
    """Test FileTool functionality."""
    
    def test_file_tool_initialization(self):
        """Test FileTool initialization."""
        config = {
            'base_path': '/tmp/test',
            'allowed_extensions': ['.txt', '.json'],
            'max_file_size': 5 * 1024 * 1024  # 5MB
        }
        
        tool = FileTool("file_manager", config)
        
        assert tool.name == "file_manager"
        assert tool.base_path == Path('/tmp/test')
        assert tool.allowed_extensions == ['.txt', '.json']
        assert tool.max_file_size == 5 * 1024 * 1024
    
    def test_file_tool_default_values(self):
        """Test FileTool with default values."""
        tool = FileTool("file_manager", {})
        
        assert tool.base_path == Path('.')
        assert tool.allowed_extensions == []
        assert tool.max_file_size == 10 * 1024 * 1024  # 10MB
    
    def test_validate_config_existing_path(self):
        """Test configuration validation with existing path."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            assert tool.validate_config() is True
    
    def test_validate_config_nonexistent_path(self):
        """Test configuration validation with non-existent path."""
        tool = FileTool("test", {'base_path': '/nonexistent/path'})
        # Should still return True but log a warning
        assert tool.validate_config() is True
    
    def test_validate_path_relative(self):
        """Test path validation with relative path."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            validated_path = tool._validate_path('test.txt')
            expected_path = Path(temp_dir) / 'test.txt'
            
            assert validated_path == expected_path
    
    def test_validate_path_absolute_within_base(self):
        """Test path validation with absolute path within base."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            test_path = Path(temp_dir) / 'subdir' / 'test.txt'
            validated_path = tool._validate_path(str(test_path))
            
            assert validated_path == test_path
    
    def test_validate_path_outside_base(self):
        """Test path validation with path outside base directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            with pytest.raises(ToolError, match="Path outside allowed directory"):
                tool._validate_path('/etc/passwd')
    
    def test_validate_path_traversal_attack(self):
        """Test path validation against directory traversal."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            with pytest.raises(ToolError, match="Path outside allowed directory"):
                tool._validate_path('../../../etc/passwd')
    
    @pytest.mark.asyncio
    async def test_execute_read_operation(self):
        """Test executing read operation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create test file
            test_file = Path(temp_dir) / 'test.txt'
            test_content = 'Hello, World!'
            test_file.write_text(test_content)
            
            tool = FileTool("test", {'base_path': temp_dir})
            
            result = await tool.execute(
                operation='read',
                file_path='test.txt'
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['content'] == test_content
            assert result.data['size'] == len(test_content)
    
    @pytest.mark.asyncio
    async def test_execute_write_operation(self):
        """Test executing write operation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            test_content = 'This is test content'
            result = await tool.execute(
                operation='write',
                file_path='new_file.txt',
                content=test_content
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['bytes_written'] == len(test_content)
            
            # Verify file was created
            test_file = Path(temp_dir) / 'new_file.txt'
            assert test_file.exists()
            assert test_file.read_text() == test_content
    
    @pytest.mark.asyncio
    async def test_execute_append_operation(self):
        """Test executing append operation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create initial file
            test_file = Path(temp_dir) / 'test.txt'
            initial_content = 'Initial content\n'
            test_file.write_text(initial_content)
            
            tool = FileTool("test", {'base_path': temp_dir})
            
            append_content = 'Appended content'
            result = await tool.execute(
                operation='append',
                file_path='test.txt',
                content=append_content
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['bytes_appended'] == len(append_content)
            
            # Verify content was appended
            final_content = test_file.read_text()
            assert final_content == initial_content + append_content
    
    @pytest.mark.asyncio
    async def test_execute_delete_operation(self):
        """Test executing delete operation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create test file
            test_file = Path(temp_dir) / 'to_delete.txt'
            test_file.write_text('Delete me')
            
            tool = FileTool("test", {'base_path': temp_dir})
            
            result = await tool.execute(
                operation='delete',
                file_path='to_delete.txt'
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert 'to_delete.txt' in result.data['deleted']
            assert not test_file.exists()
    
    @pytest.mark.asyncio
    async def test_execute_list_operation(self):
        """Test executing list operation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create test files and directories
            (Path(temp_dir) / 'file1.txt').write_text('content1')
            (Path(temp_dir) / 'file2.json').write_text('{"key": "value"}')
            (Path(temp_dir) / 'subdir').mkdir()
            (Path(temp_dir) / 'subdir' / 'file3.txt').write_text('content3')
            
            tool = FileTool("test", {'base_path': temp_dir})
            
            result = await tool.execute(
                operation='list',
                file_path='.'
            )
            
            assert result.status == ToolStatus.SUCCESS
            files = result.data['files']
            
            # Should have 3 items (2 files + 1 directory)
            assert len(files) == 3
            
            # Check file information
            file_names = [f['name'] for f in files]
            assert 'file1.txt' in file_names
            assert 'file2.json' in file_names
            assert 'subdir' in file_names
    
    @pytest.mark.asyncio
    async def test_execute_exists_operation(self):
        """Test executing exists operation."""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create test file
            test_file = Path(temp_dir) / 'exists.txt'
            test_file.write_text('I exist')
            
            tool = FileTool("test", {'base_path': temp_dir})
            
            # Test existing file
            result = await tool.execute(
                operation='exists',
                file_path='exists.txt'
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['exists'] is True
            
            # Test non-existing file
            result = await tool.execute(
                operation='exists',
                file_path='nonexistent.txt'
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['exists'] is False
    
    @pytest.mark.asyncio
    async def test_execute_unsupported_operation(self):
        """Test executing unsupported operation."""
        tool = FileTool("test", {})
        
        result = await tool.execute(
            operation='unsupported',
            file_path='test.txt'
        )
        
        assert result.status == ToolStatus.ERROR
        assert "Unknown operation" in str(result.error)
    
    @pytest.mark.asyncio
    async def test_execute_read_nonexistent_file(self):
        """Test reading non-existent file."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            result = await tool.execute(
                operation='read',
                file_path='nonexistent.txt'
            )
            
            assert result.status == ToolStatus.ERROR
            assert "not found" in str(result.error).lower()
    
    @pytest.mark.asyncio
    async def test_execute_write_with_encoding(self):
        """Test writing file with specific encoding."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            # Test with UTF-8 encoding (default)
            result = await tool.execute(
                operation='write',
                file_path='utf8.txt',
                content='Hello 世界',
                encoding='utf-8'
            )
            
            assert result.status == ToolStatus.SUCCESS
            
            # Verify file content
            test_file = Path(temp_dir) / 'utf8.txt'
            assert test_file.read_text(encoding='utf-8') == 'Hello 世界'
    
    @pytest.mark.asyncio
    async def test_file_size_limit(self):
        """Test file size limit enforcement."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {
                'base_path': temp_dir,
                'max_file_size': 100  # Very small limit
            })
            
            large_content = 'x' * 200  # Exceeds limit
            
            result = await tool.execute(
                operation='write',
                file_path='large.txt',
                content=large_content
            )
            
            assert result.status == ToolStatus.ERROR
            assert "size exceeds limit" in str(result.error).lower()
    
    @pytest.mark.asyncio
    async def test_allowed_extensions(self):
        """Test allowed extensions enforcement."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {
                'base_path': temp_dir,
                'allowed_extensions': ['.txt', '.json']
            })
            
            # Test allowed extension
            result = await tool.execute(
                operation='write',
                file_path='allowed.txt',
                content='This is allowed'
            )
            
            assert result.status == ToolStatus.SUCCESS
            
            # Test disallowed extension
            result = await tool.execute(
                operation='write',
                file_path='disallowed.exe',
                content='This should fail'
            )
            
            assert result.status == ToolStatus.ERROR
            assert "not allowed" in str(result.error).lower()
    
    def test_get_schema(self):
        """Test getting file tool schema."""
        tool = FileTool("test", {})
        schema = tool.get_schema()
        
        assert schema['name'] == 'test'
        assert 'description' in schema
        assert 'parameters' in schema
        assert 'operation' in schema['parameters']
        assert 'file_path' in schema['parameters']


class TestEmailTool:
    """Test EmailTool functionality."""
    
    def test_email_tool_initialization(self):
        """Test EmailTool initialization."""
        config = {
            'smtp_server': 'smtp.gmail.com',
            'smtp_port': 587,
            'username': 'test@example.com',
            'password': 'password123',
            'use_tls': True,
            'from_email': 'sender@example.com'
        }
        
        tool = EmailTool("email", config)
        
        assert tool.name == "email"
        assert tool.smtp_server == 'smtp.gmail.com'
        assert tool.smtp_port == 587
        assert tool.username == 'test@example.com'
        assert tool.password == 'password123'
        assert tool.use_tls is True
        assert tool.from_email == 'sender@example.com'
    
    def test_email_tool_default_values(self):
        """Test EmailTool with default values."""
        tool = EmailTool("email", {
            'smtp_server': 'smtp.gmail.com',
            'username': 'test@example.com',
            'password': 'password'
        })
        
        assert tool.smtp_port == 587
        assert tool.use_tls is True
        assert tool.from_email == 'test@example.com'  # Same as username
    
    def test_validate_config_valid(self):
        """Test configuration validation with valid config."""
        config = {
            'smtp_server': 'smtp.gmail.com',
            'username': 'test@example.com',
            'password': 'password'
        }
        tool = EmailTool("test", config)
        assert tool.validate_config() is True
    
    def test_validate_config_missing_server(self):
        """Test configuration validation with missing SMTP server."""
        config = {
            'username': 'test@example.com',
            'password': 'password'
        }
        tool = EmailTool("test", config)
        assert tool.validate_config() is False
    
    def test_validate_config_missing_credentials(self):
        """Test configuration validation with missing credentials."""
        config = {
            'smtp_server': 'smtp.gmail.com'
        }
        tool = EmailTool("test", config)
        assert tool.validate_config() is False
    
    @pytest.mark.asyncio
    async def test_execute_send_simple_email(self):
        """Test sending simple email."""
        tool = EmailTool("email", {
            'smtp_server': 'smtp.gmail.com',
            'username': 'test@example.com',
            'password': 'password'
        })
        
        with patch('smtplib.SMTP') as mock_smtp:
            mock_server = Mock()
            mock_server.__enter__ = Mock(return_value=mock_server)
            mock_server.__exit__ = Mock(return_value=None)
            mock_smtp.return_value = mock_server
            
            result = await tool.execute(
                to_email='recipient@example.com',
                subject='Test Subject',
                body='This is a test email.'
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['sent'] is True
            assert result.data['recipients'] == 1
            assert result.data['to'] == ['recipient@example.com']
            
            # Verify SMTP calls
            mock_server.starttls.assert_called_once()
            mock_server.login.assert_called_once_with('test@example.com', 'password')
            mock_server.send_message.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_execute_send_html_email(self):
        """Test sending HTML email."""
        tool = EmailTool("email", {
            'smtp_server': 'smtp.gmail.com',
            'username': 'test@example.com',
            'password': 'password'
        })
        
        with patch('smtplib.SMTP') as mock_smtp:
            mock_server = Mock()
            mock_server.__enter__ = Mock(return_value=mock_server)
            mock_server.__exit__ = Mock(return_value=None)
            mock_smtp.return_value = mock_server
            
            result = await tool.execute(
                to_email='recipient@example.com',
                subject='HTML Test',
                body='Plain text body',
                html_body='<h1>HTML Body</h1>'
            )
            
            assert result.status == ToolStatus.SUCCESS
            
            # Verify that send_message was called with HTML content
            mock_server.send_message.assert_called_once()
            sent_message = mock_server.send_message.call_args[0][0]
            assert sent_message.is_multipart()
    
    @pytest.mark.asyncio
    async def test_execute_send_multiple_recipients(self):
        """Test sending email to multiple recipients."""
        tool = EmailTool("email", {
            'smtp_server': 'smtp.gmail.com',
            'username': 'test@example.com',
            'password': 'password'
        })
        
        with patch('smtplib.SMTP') as mock_smtp:
            mock_server = Mock()
            mock_server.__enter__ = Mock(return_value=mock_server)
            mock_server.__exit__ = Mock(return_value=None)
            mock_smtp.return_value = mock_server
            
            recipients = ['user1@example.com', 'user2@example.com']
            result = await tool.execute(
                to_email=recipients,
                subject='Multiple Recipients',
                body='This goes to multiple people.',
                cc=['cc@example.com'],
                bcc=['bcc@example.com']
            )
            
            assert result.status == ToolStatus.SUCCESS
            # recipients includes to + cc + bcc = 2 + 1 + 1 = 4
            assert result.data['recipients'] == 4
            assert result.data['to'] == recipients
            assert result.data['subject'] == 'Multiple Recipients'
    
    @pytest.mark.asyncio
    async def test_execute_smtp_error(self):
        """Test handling SMTP errors."""
        tool = EmailTool("email", {
            'smtp_server': 'smtp.gmail.com',
            'username': 'test@example.com',
            'password': 'wrong_password'
        })
        
        with patch('smtplib.SMTP') as mock_smtp:
            mock_server = Mock()
            mock_server.__enter__ = Mock(return_value=mock_server)
            mock_server.__exit__ = Mock(return_value=None)
            mock_server.login.side_effect = Exception("Authentication failed")
            mock_smtp.return_value = mock_server
            
            result = await tool.execute(
                to_email='recipient@example.com',
                subject='Test',
                body='Test body'
            )
            
            assert result.status == ToolStatus.ERROR
            assert "Authentication failed" in str(result.error)
    
    def test_get_schema(self):
        """Test getting email tool schema."""
        tool = EmailTool("test", {})
        schema = tool.get_schema()
        
        assert schema['name'] == 'test'
        assert 'description' in schema
        assert 'parameters' in schema
        assert 'to_email' in schema['parameters']
        assert 'subject' in schema['parameters']
        assert 'body' in schema['parameters']


class TestSlackTool:
    """Test SlackTool functionality."""
    
    def test_slack_tool_initialization(self):
        """Test SlackTool initialization."""
        config = {
            'webhook_url': 'https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX',
            'token': 'xoxb-token',
            'default_channel': '#general',
            'default_username': 'Bot'
        }
        
        tool = SlackTool("slack", config)
        
        assert tool.name == "slack"
        assert tool.webhook_url == config['webhook_url']
        assert tool.token == 'xoxb-token'
        assert tool.default_channel == '#general'
        assert tool.default_username == 'Bot'
    
    def test_slack_tool_default_values(self):
        """Test SlackTool with default values."""
        tool = SlackTool("slack", {
            'webhook_url': 'https://hooks.slack.com/test'
        })
        
        assert tool.default_channel == '#general'
        assert tool.default_username == 'Agent'
    
    def test_validate_config_with_webhook(self):
        """Test configuration validation with webhook URL."""
        tool = SlackTool("test", {
            'webhook_url': 'https://hooks.slack.com/services/test'
        })
        assert tool.validate_config() is True
    
    def test_validate_config_with_token(self):
        """Test configuration validation with bot token."""
        tool = SlackTool("test", {
            'token': 'xoxb-token'
        })
        assert tool.validate_config() is True
    
    def test_validate_config_missing_both(self):
        """Test configuration validation with missing webhook and token."""
        tool = SlackTool("test", {})
        assert tool.validate_config() is False
    
    @pytest.mark.asyncio
    async def test_execute_webhook_message(self):
        """Test sending message via webhook."""
        tool = SlackTool("slack", {
            'webhook_url': 'https://hooks.slack.com/services/test'
        })
        
        with patch('aiohttp.ClientSession') as mock_session:
            mock_response = AsyncMock()
            mock_response.status = 200
            mock_response.text = AsyncMock(return_value='ok')
            
            # Create a proper async context manager for the post response
            mock_post_context = AsyncMock()
            mock_post_context.__aenter__ = AsyncMock(return_value=mock_response)
            mock_post_context.__aexit__ = AsyncMock(return_value=None)
            
            # Create a proper async context manager for the session
            mock_session_instance = AsyncMock()
            mock_session_instance.post = Mock(return_value=mock_post_context)
            mock_session_instance.__aenter__ = AsyncMock(return_value=mock_session_instance)
            mock_session_instance.__aexit__ = AsyncMock(return_value=None)
            
            mock_session.return_value = mock_session_instance
            
            result = await tool.execute(
                message='Hello from the agent!',
                channel='#test',
                username='TestBot'
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['sent'] is True
            assert result.data['method'] == 'webhook'
            
            # Verify webhook was called
            mock_session.return_value.__aenter__.return_value.post.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_execute_with_attachments(self):
        """Test sending message with attachments."""
        tool = SlackTool("slack", {
            'webhook_url': 'https://hooks.slack.com/services/test'
        })
        
        attachments = [{
            'color': 'good',
            'title': 'Test Attachment',
            'text': 'This is an attachment'
        }]
        
        with patch('agent_sdk.tools.utils.aiohttp.ClientSession') as mock_session_class:
            # Create a proper async context manager mock
            mock_response = Mock()
            mock_response.status = 200
            mock_response.text = AsyncMock(return_value='ok')
            
            # Create async context manager for post response
            mock_post_cm = AsyncMock()
            mock_post_cm.__aenter__ = AsyncMock(return_value=mock_response)
            mock_post_cm.__aexit__ = AsyncMock(return_value=None)
            
            # Create async context manager for session
            mock_session = Mock()
            mock_session.post = Mock(return_value=mock_post_cm)
            
            mock_session_cm = AsyncMock()
            mock_session_cm.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session_cm.__aexit__ = AsyncMock(return_value=None)
            
            mock_session_class.return_value = mock_session_cm
            
            result = await tool.execute(
                message='Message with attachment',
                attachments=attachments
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['sent'] is True
            assert result.data['method'] == 'webhook'
    
    @pytest.mark.asyncio
    async def test_execute_bot_token_message(self):
        """Test sending message via bot token."""
        tool = SlackTool("slack", {
            'token': 'xoxb-token'
        })
        
        with patch('agent_sdk.tools.utils.aiohttp.ClientSession') as mock_session_class:
            # Create a proper async context manager mock
            mock_response = Mock()
            mock_response.status = 200
            mock_response.json = AsyncMock(return_value={'ok': True, 'ts': '1234567890.123456'})
            
            # Create async context manager for post response
            mock_post_cm = AsyncMock()
            mock_post_cm.__aenter__ = AsyncMock(return_value=mock_response)
            mock_post_cm.__aexit__ = AsyncMock(return_value=None)
            
            # Create async context manager for session
            mock_session = Mock()
            mock_session.post = Mock(return_value=mock_post_cm)
            
            mock_session_cm = AsyncMock()
            mock_session_cm.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session_cm.__aexit__ = AsyncMock(return_value=None)
            
            mock_session_class.return_value = mock_session_cm
            
            result = await tool.execute(
                message='Hello via bot token!',
                channel='C1234567890'
            )
            
            assert result.status == ToolStatus.SUCCESS
            assert result.data['sent'] is True
            assert result.data['ts'] == '1234567890.123456'
    
    @pytest.mark.asyncio
    async def test_execute_slack_api_error(self):
        """Test handling Slack API errors."""
        tool = SlackTool("slack", {
            'webhook_url': 'https://hooks.slack.com/services/test'
        })
        
        with patch('agent_sdk.tools.utils.aiohttp.ClientSession') as mock_session_class:
            # Create a proper async context manager mock
            mock_response = Mock()
            mock_response.status = 400
            mock_response.text = AsyncMock(return_value='invalid_payload')
            
            # Create async context manager for post response
            mock_post_cm = AsyncMock()
            mock_post_cm.__aenter__ = AsyncMock(return_value=mock_response)
            mock_post_cm.__aexit__ = AsyncMock(return_value=None)
            
            # Create async context manager for session
            mock_session = Mock()
            mock_session.post = Mock(return_value=mock_post_cm)
            
            mock_session_cm = AsyncMock()
            mock_session_cm.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session_cm.__aexit__ = AsyncMock(return_value=None)
            
            mock_session_class.return_value = mock_session_cm
            
            result = await tool.execute(
                message='This will fail'
            )
            
            assert result.status == ToolStatus.ERROR
            assert 'invalid_payload' in str(result.error)
    
    @pytest.mark.asyncio
    async def test_execute_network_error(self):
        """Test handling network errors."""
        tool = SlackTool("slack", {
            'webhook_url': 'https://hooks.slack.com/services/test'
        })
        
        with patch('agent_sdk.tools.utils.aiohttp.ClientSession') as mock_session_class:
            # Create async context manager for session that raises error on post
            mock_session = Mock()
            mock_session.post.side_effect = Exception("Network error")
            
            mock_session_cm = AsyncMock()
            mock_session_cm.__aenter__ = AsyncMock(return_value=mock_session)
            mock_session_cm.__aexit__ = AsyncMock(return_value=None)
            
            mock_session_class.return_value = mock_session_cm
            
            result = await tool.execute(
                message='Network will fail'
            )
            
            assert result.status == ToolStatus.ERROR
            assert 'Network error' in str(result.error)
    
    def test_get_schema(self):
        """Test getting Slack tool schema."""
        tool = SlackTool("test", {})
        schema = tool.get_schema()
        
        assert schema['name'] == 'test'
        assert 'description' in schema
        assert 'parameters' in schema
        assert 'message' in schema['parameters']
        assert 'channel' in schema['parameters']


class TestUtilityToolsEdgeCases:
    """Test edge cases for utility tools."""
    
    @pytest.mark.asyncio
    async def test_file_tool_concurrent_operations(self):
        """Test concurrent file operations."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            # Perform multiple concurrent write operations
            tasks = []
            for i in range(5):
                task = tool.execute(
                    operation='write',
                    file_path=f'concurrent_{i}.txt',
                    content=f'Content {i}'
                )
                tasks.append(task)
            
            results = await asyncio.gather(*tasks)
            
            # All operations should succeed
            for result in results:
                assert result.status == ToolStatus.SUCCESS
            
            # Verify all files were created
            for i in range(5):
                file_path = Path(temp_dir) / f'concurrent_{i}.txt'
                assert file_path.exists()
                assert file_path.read_text() == f'Content {i}'
    
    @pytest.mark.asyncio
    async def test_email_tool_without_tls(self):
        """Test email tool without TLS."""
        tool = EmailTool("email", {
            'smtp_server': 'smtp.example.com',
            'smtp_port': 25,
            'username': 'test@example.com',
            'password': 'password',
            'use_tls': False
        })
        
        with patch('smtplib.SMTP') as mock_smtp:
            mock_server = Mock()
            mock_server.__enter__ = Mock(return_value=mock_server)
            mock_server.__exit__ = Mock(return_value=None)
            mock_smtp.return_value = mock_server
            
            result = await tool.execute(
                to_email='recipient@example.com',
                subject='No TLS Test',
                body='This email uses no TLS.'
            )
            
            assert result.status == ToolStatus.SUCCESS
            
            # Verify TLS was not started
            mock_server.starttls.assert_not_called()
    
    def test_utility_tools_inheritance(self):
        """Test that utility tools properly inherit from Tool."""
        file_tool = FileTool("file", {})
        email_tool = EmailTool("email", {
            'smtp_server': 'smtp.example.com',
            'username': 'test@example.com',
            'password': 'password'
        })
        slack_tool = SlackTool("slack", {'webhook_url': 'https://hooks.slack.com/test'})
        
        # All should inherit from Tool
        from agent_sdk.tools.base import Tool
        for tool in [file_tool, email_tool, slack_tool]:
            assert isinstance(tool, Tool)
            assert hasattr(tool, 'name')
            assert hasattr(tool, 'config')
            assert hasattr(tool, 'validate_config')
            assert hasattr(tool, 'get_schema')
            assert hasattr(tool, 'execute')
    
    @pytest.mark.asyncio
    async def test_file_tool_binary_operations(self):
        """Test file tool with binary data."""
        with tempfile.TemporaryDirectory() as temp_dir:
            tool = FileTool("test", {'base_path': temp_dir})
            
            # Test binary data (should be handled as text for now)
            binary_content = b'\x00\x01\x02\x03\x04\x05'
            
            # This should fail gracefully since we're treating as text
            result = await tool.execute(
                operation='write',
                file_path='binary.dat',
                content=binary_content.decode('latin1')  # Force decode for test
            )
            
            # Should succeed with proper encoding handling
            assert result.status == ToolStatus.SUCCESS