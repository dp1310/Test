"""Tests for agent configuration utilities."""

import pytest
from unittest.mock import Mock, patch, MagicMock

from agent_sdk.agent.config import DynamicConfigParser, FunctionResolver, AgentValidator
from agent_sdk.core.stages import Stage


class TestAgentValidator:
    """Test AgentValidator functionality."""
    
    def test_validate_functions_with_stage_decorator(self):
        """Test function validation with proper stage decorators."""
        mock_func = Mock()
        mock_func.__name__ = "test_func"
        mock_func._agent_stage = Stage.PERCEIVE
        
        with patch('agent_sdk.agent.config.validation.logger') as mock_logger:
            AgentValidator.validate_functions([mock_func])
            # Should not log warning for properly decorated function
            mock_logger.warning.assert_not_called()
    
    def test_validate_functions_without_stage_decorator(self):
        """Test function validation without stage decorators."""
        mock_func = Mock(spec=[])  # Empty spec prevents automatic attribute creation
        mock_func.__name__ = "test_func"
        # No _agent_stage attribute
        
        with patch('agent_sdk.agent.config.validation.logger') as mock_logger:
            AgentValidator.validate_functions([mock_func])
            mock_logger.warning.assert_called_with("Function test_func missing stage decorator")
    
    def test_validate_function_without_decorator_warning(self):
        """Test validating single function without stage decorator logs warning."""
        mock_func = Mock(spec=[])  # Empty spec prevents automatic attribute creation
        mock_func.__name__ = "test_func"
        # No _agent_stage attribute
        
        with patch('agent_sdk.agent.config.validation.logger') as mock_logger:
            AgentValidator.validate_function(mock_func)
            mock_logger.warning.assert_called_with("Function test_func missing stage decorator")
    
    def test_function_validation_with_none_name(self):
        """Test function validation when function has no __name__."""
        mock_func = Mock(spec=[])  # Empty spec prevents automatic attribute creation
        del mock_func.__name__  # Remove __name__ attribute
        
        with patch('agent_sdk.agent.config.validation.logger') as mock_logger:
            AgentValidator.validate_function(mock_func)
            # Should handle missing __name__ gracefully
            mock_logger.warning.assert_called()


class TestDynamicConfigParser:
    """Test DynamicConfigParser functionality."""
    
    def test_parse_dynamic_config_no_overrides(self):
        """Test parsing input data without dynamic configuration."""
        parser = DynamicConfigParser()
        
        # Non-dict input
        result = parser.parse_dynamic_config("simple_input")
        assert result == ("simple_input", None, None)
        
        # Dict without override keys
        input_data = {"text": "test", "value": 42}
        result = parser.parse_dynamic_config(input_data)
        assert result == (input_data, None, None)
    
    def test_parse_dynamic_config_with_functions_override(self):
        """Test parsing input data with functions override."""
        parser = DynamicConfigParser()
        
        mock_func = Mock()
        mock_func.__name__ = "test_func"
        
        input_data = {
            "text": "test",
            "functions": [mock_func],
            "other": "data"
        }
        
        with patch.object(parser, 'parse_functions', return_value=[mock_func]) as mock_parse:
            actual_input, functions, concurrent = parser.parse_dynamic_config(input_data)
            
            assert actual_input == {"text": "test", "other": "data"}
            assert functions == [mock_func]
            assert concurrent is None
            mock_parse.assert_called_once_with([mock_func])
    
    def test_parse_dynamic_config_with_concurrent_override(self):
        """Test parsing input data with concurrent override."""
        parser = DynamicConfigParser()
        
        input_data = {
            "text": "test",
            "concurrent": {"perceive": True},
            "other": "data"
        }
        
        with patch.object(parser, 'parse_concurrent', return_value={Stage.PERCEIVE: True}) as mock_parse:
            actual_input, functions, concurrent = parser.parse_dynamic_config(input_data)
            
            assert actual_input == {"text": "test", "other": "data"}
            assert functions is None
            assert concurrent == {Stage.PERCEIVE: True}
            mock_parse.assert_called_once_with({"perceive": True})
    
    def test_parse_functions_with_callables(self):
        """Test parsing functions that are already callables."""
        parser = DynamicConfigParser()
        
        func1 = Mock()
        func2 = Mock()
        functions_config = [func1, func2]
        
        result = parser.parse_functions(functions_config)
        
        assert result == [func1, func2]
    
    def test_parse_functions_with_strings(self):
        """Test parsing functions from string references."""
        parser = DynamicConfigParser()
        
        with patch.object(parser.function_resolver, 'resolve_function') as mock_resolve:
            mock_func = Mock()
            mock_resolve.return_value = mock_func
            
            functions_config = ["module.function"]
            result = parser.parse_functions(functions_config)
            
            assert result == [mock_func]
            mock_resolve.assert_called_once_with("module.function")
    
    def test_parse_functions_invalid_type(self):
        """Test parsing functions with invalid types."""
        parser = DynamicConfigParser()
        
        with pytest.raises(ValueError, match="Functions must be provided as a list"):
            parser.parse_functions("not_a_list")
        
        with pytest.raises(ValueError, match="Function must be callable or string"):
            parser.parse_functions([123])
    
    def test_parse_functions_string_resolution_failure(self):
        """Test parsing functions when string resolution fails."""
        parser = DynamicConfigParser()
        
        with patch.object(parser.function_resolver, 'resolve_function', side_effect=ValueError("Cannot resolve")):
            with pytest.raises(ValueError, match="Cannot resolve function 'invalid.function'"):
                parser.parse_functions(["invalid.function"])
    
    def test_parse_concurrent_with_stage_enums(self):
        """Test parsing concurrent config with Stage enums."""
        parser = DynamicConfigParser()
        
        concurrent_config = {Stage.PERCEIVE: True, Stage.REASON: False}
        result = parser.parse_concurrent(concurrent_config)
        
        assert result == concurrent_config
    
    def test_parse_concurrent_with_strings(self):
        """Test parsing concurrent config with string stage names."""
        parser = DynamicConfigParser()
        
        concurrent_config = {"perceive": True, "reason": False}
        result = parser.parse_concurrent(concurrent_config)
        
        expected = {Stage.PERCEIVE: True, Stage.REASON: False}
        assert result == expected
    
    def test_parse_concurrent_invalid_stage_name(self):
        """Test parsing concurrent config with invalid stage name."""
        parser = DynamicConfigParser()
        
        concurrent_config = {"invalid_stage": True}
        
        with pytest.raises(ValueError, match="Invalid stage name: invalid_stage"):
            parser.parse_concurrent(concurrent_config)
    
    def test_parse_concurrent_invalid_type(self):
        """Test parsing concurrent config with invalid type."""
        parser = DynamicConfigParser()
        
        with pytest.raises(ValueError, match="Concurrent configuration must be a dictionary"):
            parser.parse_concurrent("not_a_dict")
        
        with pytest.raises(ValueError, match="Stage key must be Stage enum or string"):
            parser.parse_concurrent({123: True})


class TestFunctionResolver:
    """Test FunctionResolver functionality."""
    
    def test_resolve_function_string_module_dot_function(self):
        """Test resolving function string with module.function format."""
        resolver = FunctionResolver()
        
        mock_func = Mock()
        mock_module = Mock()
        mock_module.test_function = mock_func
        
        with patch('importlib.import_module', return_value=mock_module):
            result = resolver.resolve_function("test_module.test_function")
            assert result == mock_func
    
    def test_resolve_function_string_not_callable(self):
        """Test resolving function string that's not callable."""
        resolver = FunctionResolver()
        
        mock_module = Mock()
        mock_module.not_callable = "not_a_function"
        
        with patch('importlib.import_module', return_value=mock_module):
            with pytest.raises(ValueError, match="'test_module.not_callable' is not callable"):
                resolver.resolve_function("test_module.not_callable")
    
    def test_resolve_function_string_import_error(self):
        """Test resolving function string with import error."""
        resolver = FunctionResolver()
        
        with patch('importlib.import_module', side_effect=ImportError("No module")):
            with pytest.raises(ValueError, match="Cannot import"):
                resolver.resolve_function("nonexistent.function")
    
    def test_resolve_function_string_simple_name_from_main(self):
        """Test resolving simple function name from __main__."""
        resolver = FunctionResolver()
        
        mock_func = Mock()
        mock_main = Mock()
        mock_main.test_func = mock_func
        
        with patch('sys.modules', {"__main__": mock_main}):
            result = resolver.resolve_function("test_func")
            assert result == mock_func
    
    def test_resolve_function_string_simple_name_not_found(self):
        """Test resolving simple function name that's not found."""
        resolver = FunctionResolver()
        
        # Create a mock main module that doesn't have the function
        mock_main = Mock(spec=[])  # Empty spec prevents automatic attribute creation
        with patch('sys.modules', {"__main__": mock_main}):
            with pytest.raises(ValueError, match="Simple function name 'nonexistent' not found"):
                resolver.resolve_function("nonexistent")