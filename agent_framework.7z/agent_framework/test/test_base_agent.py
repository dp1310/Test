"""Tests for base agent functionality."""

import pytest
import asyncio
from typing import Dict, Any, List, Callable
from unittest.mock import Mock, patch, MagicMock

from agent_sdk.agent.base_agent import BaseAgent
from agent_sdk.core.stages import Stage
from agent_sdk.core.context import Context


class MockAgent(BaseAgent):
    """Mock agent for testing base functionality."""
    
    _execution_type = "mock"
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.execute_calls = []
    
    def execute(self, input_data):
        self.execute_calls.append(input_data)
        return Context(data={"mock": True, "input": input_data})
    
    def get_execution_type(self):
        return "mock"


class TestBaseAgent:
    """Test BaseAgent abstract class functionality."""
    
    def test_base_agent_initialization(self):
        """Test base agent initialization with all parameters."""
        functions = [Mock(), Mock()]
        initial_context = {"key": "value"}
        concurrent = {Stage.PERCEIVE: True}
        workflow_id = "test_workflow"
        
        agent = MockAgent(
            functions=functions,
            initial_context=initial_context,
            concurrent=concurrent,
            workflow_id=workflow_id
        )
        
        assert agent._functions == functions
        assert agent._initial_context == initial_context
        assert agent._concurrent == concurrent
        assert agent._workflow_id == workflow_id
    
    def test_base_agent_initialization_defaults(self):
        """Test base agent initialization with default values."""
        agent = MockAgent()
        
        assert agent._functions == []
        assert agent._initial_context == {}
        assert agent._concurrent == {}
        # Workflow ID should be auto-generated if not provided
        assert agent._workflow_id is not None
        assert isinstance(agent._workflow_id, str)
        assert agent._workflow_id.startswith("mock_")
    
    def test_validate_functions_with_stage_decorator(self):
        """Test function validation with proper stage decorators."""
        mock_func = Mock()
        mock_func.__name__ = "test_func"
        mock_func._agent_stage = Stage.PERCEIVE
        
        with patch('agent_sdk.agent.base_agent.logger') as mock_logger:
            agent = MockAgent(functions=[mock_func])
            # Should not log warning for properly decorated function
            mock_logger.warning.assert_not_called()
    
    def test_validate_functions_without_stage_decorator(self):
        """Test function validation without stage decorators."""
        mock_func = Mock(spec=[])  # Empty spec prevents automatic attribute creation
        mock_func.__name__ = "test_func"
        # No _agent_stage attribute
        
        with patch('agent_sdk.agent.base_agent.logger') as mock_logger:
            agent = MockAgent(functions=[mock_func])
            mock_logger.warning.assert_called_with("Function test_func missing stage decorator")
    
    def test_clone_agent(self):
        """Test agent cloning (prototype pattern)."""
        functions = [Mock(), Mock()]
        initial_context = {"key": "value"}
        concurrent = {Stage.PERCEIVE: True}
        workflow_id = "original"
        
        original = MockAgent(
            functions=functions,
            initial_context=initial_context,
            concurrent=concurrent,
            workflow_id=workflow_id
        )
        
        cloned = original.clone()
        
        # Should be different instances
        assert cloned is not original
        assert cloned._functions is not original._functions
        assert cloned._initial_context is not original._initial_context
        assert cloned._concurrent is not original._concurrent
        
        # Should have same structure and values (but deep copied objects)
        assert len(cloned._functions) == len(original._functions)
        assert cloned._initial_context == original._initial_context
        assert cloned._concurrent == original._concurrent
        assert cloned._workflow_id == original._workflow_id
        
        # Should be same class
        assert type(cloned) == type(original)
    
    def test_add_function_fluent_interface(self):
        """Test adding function with fluent interface."""
        agent = MockAgent()
        mock_func = Mock()
        mock_func.__name__ = "test_func"
        mock_func._agent_stage = Stage.PERCEIVE
        
        result = agent.add_function(mock_func)
        
        # Should return self for chaining
        assert result is agent
        assert mock_func in agent._functions
    
    def test_add_function_without_decorator_warning(self):
        """Test adding function without stage decorator logs warning."""
        agent = MockAgent()
        mock_func = Mock(spec=[])  # Empty spec prevents automatic attribute creation
        mock_func.__name__ = "test_func"
        # No _agent_stage attribute
        
        with patch('agent_sdk.agent.base_agent.logger') as mock_logger:
            agent.add_function(mock_func)
            mock_logger.warning.assert_called_with("Function test_func missing stage decorator")
    
    def test_add_functions_multiple(self):
        """Test adding multiple functions."""
        agent = MockAgent()
        func1 = Mock()
        func1.__name__ = "func1"
        func1._agent_stage = Stage.PERCEIVE
        
        func2 = Mock()
        func2.__name__ = "func2"
        func2._agent_stage = Stage.REASON
        
        result = agent.add_functions([func1, func2])
        
        assert result is agent
        assert func1 in agent._functions
        assert func2 in agent._functions
        assert len(agent._functions) == 2
    
    def test_set_initial_context(self):
        """Test setting initial context."""
        agent = MockAgent()
        context = {"key": "value", "number": 42}
        
        result = agent.set_initial_context(context)
        
        assert result is agent
        assert agent._initial_context == context
    
    def test_update_initial_context(self):
        """Test updating initial context."""
        agent = MockAgent(initial_context={"existing": "value"})
        update = {"new": "data", "existing": "updated"}
        
        result = agent.update_initial_context(update)
        
        assert result is agent
        assert agent._initial_context["existing"] == "updated"
        assert agent._initial_context["new"] == "data"
    
    def test_set_concurrent(self):
        """Test setting concurrent configuration."""
        agent = MockAgent()
        concurrent = {Stage.PERCEIVE: True, Stage.REASON: False}
        
        result = agent.set_concurrent(concurrent)
        
        assert result is agent
        assert agent._concurrent == concurrent
    
    def test_set_stage_concurrent(self):
        """Test setting concurrent for specific stage."""
        agent = MockAgent()
        
        result = agent.set_stage_concurrent(Stage.PERCEIVE, True)
        
        assert result is agent
        assert agent._concurrent[Stage.PERCEIVE] is True
    
    def test_set_workflow_id(self):
        """Test setting workflow ID."""
        agent = MockAgent()
        workflow_id = "test_workflow_123"
        
        result = agent.set_workflow_id(workflow_id)
        
        assert result is agent
        assert agent._workflow_id == workflow_id
    
    def test_properties(self):
        """Test agent properties return copies."""
        functions = [Mock(), Mock()]
        initial_context = {"key": "value"}
        concurrent = {Stage.PERCEIVE: True}
        workflow_id = "test"
        
        agent = MockAgent(
            functions=functions,
            initial_context=initial_context,
            concurrent=concurrent,
            workflow_id=workflow_id
        )
        
        # Properties should return copies, not references
        assert agent.functions == functions
        assert agent.functions is not agent._functions
        
        assert agent.initial_context == initial_context
        assert agent.initial_context is not agent._initial_context
        
        assert agent.concurrent == concurrent
        assert agent.concurrent is not agent._concurrent
        
        assert agent.workflow_id == workflow_id
    
    def test_fluent_interface_chaining(self):
        """Test fluent interface method chaining."""
        agent = MockAgent()
        mock_func = Mock()
        mock_func.__name__ = "test_func"
        mock_func._agent_stage = Stage.PERCEIVE
        
        result = (agent
                 .add_function(mock_func)
                 .set_initial_context({"key": "value"})
                 .set_stage_concurrent(Stage.PERCEIVE, True)
                 .set_workflow_id("chained_test"))
        
        assert result is agent
        assert mock_func in agent._functions
        assert agent._initial_context == {"key": "value"}
        assert agent._concurrent[Stage.PERCEIVE] is True
        assert agent._workflow_id == "chained_test"
    
    def test_repr(self):
        """Test string representation of agent."""
        functions = [Mock(), Mock()]
        concurrent = {Stage.PERCEIVE: True}
        workflow_id = "test"
        
        agent = MockAgent(
            functions=functions,
            concurrent=concurrent,
            workflow_id=workflow_id
        )
        
        repr_str = repr(agent)
        assert "MockAgent" in repr_str
        assert "functions=2" in repr_str
        # Stage enum representation might vary, just check for the key parts
        assert "concurrent=" in repr_str
        assert "PERCEIVE" in repr_str
        assert "True" in repr_str
        assert "workflow_id=test" in repr_str


class TestDynamicConfiguration:
    """Test dynamic configuration parsing."""
    
    def test_parse_dynamic_config_no_overrides(self):
        """Test parsing input data without dynamic configuration."""
        agent = MockAgent()
        
        # Non-dict input
        result = agent._parse_dynamic_config("simple_input")
        assert result == ("simple_input", None, None)
        
        # Dict without override keys
        input_data = {"text": "test", "value": 42}
        result = agent._parse_dynamic_config(input_data)
        assert result == (input_data, None, None)
    
    def test_parse_dynamic_config_with_functions_override(self):
        """Test parsing input data with functions override."""
        agent = MockAgent()
        
        mock_func = Mock()
        mock_func.__name__ = "test_func"
        
        input_data = {
            "text": "test",
            "functions": [mock_func],
            "other": "data"
        }
        
        with patch.object(agent, '_parse_functions', return_value=[mock_func]) as mock_parse:
            actual_input, functions, concurrent = agent._parse_dynamic_config(input_data)
            
            assert actual_input == {"text": "test", "other": "data"}
            assert functions == [mock_func]
            assert concurrent is None
            mock_parse.assert_called_once_with([mock_func])
    
    def test_parse_dynamic_config_with_concurrent_override(self):
        """Test parsing input data with concurrent override."""
        agent = MockAgent()
        
        input_data = {
            "text": "test",
            "concurrent": {"perceive": True},
            "other": "data"
        }
        
        with patch.object(agent, '_parse_concurrent', return_value={Stage.PERCEIVE: True}) as mock_parse:
            actual_input, functions, concurrent = agent._parse_dynamic_config(input_data)
            
            assert actual_input == {"text": "test", "other": "data"}
            assert functions is None
            assert concurrent == {Stage.PERCEIVE: True}
            mock_parse.assert_called_once_with({"perceive": True})
    
    def test_parse_functions_with_callables(self):
        """Test parsing functions that are already callables."""
        agent = MockAgent()
        
        func1 = Mock()
        func2 = Mock()
        functions_config = [func1, func2]
        
        result = agent._parse_functions(functions_config)
        
        assert result == [func1, func2]
    
    def test_parse_functions_with_strings(self):
        """Test parsing functions from string references."""
        agent = MockAgent()
        
        with patch.object(agent, '_resolve_function_string') as mock_resolve:
            mock_func = Mock()
            mock_resolve.return_value = mock_func
            
            functions_config = ["module.function"]
            result = agent._parse_functions(functions_config)
            
            assert result == [mock_func]
            mock_resolve.assert_called_once_with("module.function")
    
    def test_parse_functions_invalid_type(self):
        """Test parsing functions with invalid types."""
        agent = MockAgent()
        
        with pytest.raises(ValueError, match="Functions must be provided as a list"):
            agent._parse_functions("not_a_list")
        
        with pytest.raises(ValueError, match="Function must be callable or string"):
            agent._parse_functions([123])
    
    def test_parse_functions_string_resolution_failure(self):
        """Test parsing functions when string resolution fails."""
        agent = MockAgent()
        
        with patch.object(agent, '_resolve_function_string', side_effect=ValueError("Cannot resolve")):
            with pytest.raises(ValueError, match="Cannot resolve function 'invalid.function'"):
                agent._parse_functions(["invalid.function"])
    
    def test_resolve_function_string_module_dot_function(self):
        """Test resolving function string with module.function format."""
        agent = MockAgent()
        
        mock_func = Mock()
        mock_module = Mock()
        mock_module.test_function = mock_func
        
        with patch('importlib.import_module', return_value=mock_module):
            result = agent._resolve_function_string("test_module.test_function")
            assert result == mock_func
    
    def test_resolve_function_string_not_callable(self):
        """Test resolving function string that's not callable."""
        agent = MockAgent()
        
        mock_module = Mock()
        mock_module.not_callable = "not_a_function"
        
        with patch('importlib.import_module', return_value=mock_module):
            with pytest.raises(ValueError, match="'test_module.not_callable' is not callable"):
                agent._resolve_function_string("test_module.not_callable")
    
    def test_resolve_function_string_import_error(self):
        """Test resolving function string with import error."""
        agent = MockAgent()
        
        with patch('importlib.import_module', side_effect=ImportError("No module")):
            with pytest.raises(ValueError, match="Cannot import"):
                agent._resolve_function_string("nonexistent.function")
    
    def test_resolve_function_string_simple_name_from_main(self):
        """Test resolving simple function name from __main__."""
        agent = MockAgent()
        
        mock_func = Mock()
        mock_main = Mock()
        mock_main.test_func = mock_func
        
        with patch('sys.modules', {"__main__": mock_main}):
            result = agent._resolve_function_string("test_func")
            assert result == mock_func
    
    def test_resolve_function_string_simple_name_not_found(self):
        """Test resolving simple function name that's not found."""
        agent = MockAgent()
        
        # Create a mock main module that doesn't have the function
        mock_main = Mock(spec=[])  # Empty spec prevents automatic attribute creation
        with patch('sys.modules', {"__main__": mock_main}):
            with pytest.raises(ValueError, match="Simple function name 'nonexistent' not found"):
                agent._resolve_function_string("nonexistent")
    
    def test_parse_concurrent_with_stage_enums(self):
        """Test parsing concurrent config with Stage enums."""
        agent = MockAgent()
        
        concurrent_config = {Stage.PERCEIVE: True, Stage.REASON: False}
        result = agent._parse_concurrent(concurrent_config)
        
        assert result == concurrent_config
    
    def test_parse_concurrent_with_strings(self):
        """Test parsing concurrent config with string stage names."""
        agent = MockAgent()
        
        concurrent_config = {"perceive": True, "reason": False}
        result = agent._parse_concurrent(concurrent_config)
        
        expected = {Stage.PERCEIVE: True, Stage.REASON: False}
        assert result == expected
    
    def test_parse_concurrent_invalid_stage_name(self):
        """Test parsing concurrent config with invalid stage name."""
        agent = MockAgent()
        
        concurrent_config = {"invalid_stage": True}
        
        with pytest.raises(ValueError, match="Invalid stage name: invalid_stage"):
            agent._parse_concurrent(concurrent_config)
    
    def test_parse_concurrent_invalid_type(self):
        """Test parsing concurrent config with invalid type."""
        agent = MockAgent()
        
        with pytest.raises(ValueError, match="Concurrent configuration must be a dictionary"):
            agent._parse_concurrent("not_a_dict")
        
        with pytest.raises(ValueError, match="Stage key must be Stage enum or string"):
            agent._parse_concurrent({123: True})


class TestAbstractMethods:
    """Test that abstract methods are properly defined."""
    
    def test_cannot_instantiate_base_agent(self):
        """Test that BaseAgent cannot be instantiated directly."""
        with pytest.raises(TypeError):
            BaseAgent()
    
    def test_mock_agent_implements_abstract_methods(self):
        """Test that MockAgent properly implements abstract methods."""
        agent = MockAgent()
        
        # Should be able to call abstract methods
        result = agent.execute("test")
        assert isinstance(result, Context)
        
        execution_type = agent.get_execution_type()
        assert execution_type == "mock"


class TestEdgeCases:
    """Test edge cases and error conditions."""
    
    def test_empty_functions_list(self):
        """Test agent with empty functions list."""
        agent = MockAgent(functions=[])
        assert agent._functions == []
        assert len(agent.functions) == 0
    
    def test_none_values_in_initialization(self):
        """Test agent initialization with None values."""
        agent = MockAgent(
            functions=None,
            initial_context=None,
            concurrent=None,
            workflow_id=None
        )
        
        assert agent._functions == []
        assert agent._initial_context == {}
        assert agent._concurrent == {}
        # Workflow ID should be auto-generated even when None is passed
        assert agent._workflow_id is not None
        assert isinstance(agent._workflow_id, str)
        assert agent._workflow_id.startswith("mock_")
    
    def test_deep_copy_behavior(self):
        """Test that clone creates deep copies of mutable objects."""
        nested_context = {"nested": {"key": "value"}}
        nested_concurrent = {Stage.PERCEIVE: True}
        
        original = MockAgent(
            initial_context=nested_context,
            concurrent=nested_concurrent
        )
        
        cloned = original.clone()
        
        # Modify original nested objects
        nested_context["nested"]["key"] = "modified"
        nested_concurrent[Stage.REASON] = True
        
        # Cloned should be unaffected
        assert cloned._initial_context["nested"]["key"] == "value"
        assert Stage.REASON not in cloned._concurrent
    
    def test_function_validation_with_none_name(self):
        """Test function validation when function has no __name__."""
        mock_func = Mock(spec=[])  # Empty spec prevents automatic attribute creation
        del mock_func.__name__  # Remove __name__ attribute
        
        with patch('agent_sdk.agent.base_agent.logger') as mock_logger:
            agent = MockAgent(functions=[mock_func])
            # Should handle missing __name__ gracefully
            mock_logger.warning.assert_called()