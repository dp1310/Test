"""Tests for PrefectExecutor class."""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock
from typing import Dict, Any

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from agent_sdk.core.execution.prefect_executor import PrefectExecutor
from agent_sdk.core.stages import Stage
from agent_sdk.core.state import StageState
from prefect import task


class TestPrefectExecutor:
    """Test PrefectExecutor functionality."""
    
    def test_execute_sequential(self):
        """Test sequential execution of Prefect tasks."""
        # Create mock tasks
        @task
        def task1(ctx):
            return {"result": "task1"}
        
        @task
        def task2(ctx):
            return {"result": "task2"}
        
        tasks = [task1, task2]
        ctx = {"input": "test"}
        
        with patch.object(task1, 'submit') as mock_submit1, \
             patch.object(task2, 'submit') as mock_submit2:
            
            # Mock futures
            mock_future1 = Mock()
            mock_future1.result.return_value = {"result": "task1"}
            mock_future2 = Mock()
            mock_future2.result.return_value = {"result": "task2"}
            
            mock_submit1.return_value = mock_future1
            mock_submit2.return_value = mock_future2
            
            results = PrefectExecutor.execute_sequential(tasks, ctx)
            
            assert len(results) == 2
            assert results[0] == {"result": "task1"}
            assert results[1] == {"result": "task2"}
            
            mock_submit1.assert_called_once_with(ctx)
            mock_submit2.assert_called_once_with(ctx)
    
    def test_execute_concurrent(self):
        """Test concurrent execution of Prefect tasks."""
        # Create mock tasks
        @task
        def task1(ctx):
            return {"result": "task1"}
        
        @task
        def task2(ctx):
            return {"result": "task2"}
        
        tasks = [task1, task2]
        ctx = {"input": "test"}
        
        with patch.object(task1, 'submit') as mock_submit1, \
             patch.object(task2, 'submit') as mock_submit2:
            
            # Mock futures
            mock_future1 = Mock()
            mock_future1.result.return_value = {"result": "task1"}
            mock_future2 = Mock()
            mock_future2.result.return_value = {"result": "task2"}
            
            mock_submit1.return_value = mock_future1
            mock_submit2.return_value = mock_future2
            
            results = PrefectExecutor.execute_concurrent(tasks, ctx)
            
            assert len(results) == 2
            assert results[0] == {"result": "task1"}
            assert results[1] == {"result": "task2"}
            
            mock_submit1.assert_called_once_with(ctx)
            mock_submit2.assert_called_once_with(ctx)
    
    def test_execute_sequential_monitored(self):
        """Test sequential execution with state monitoring."""
        # Create mock task
        @task
        def test_task(ctx):
            return {"result": "success"}
        
        tasks = [test_task]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch.object(test_task, 'submit') as mock_submit, \
             patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager, \
             patch('agent_sdk.core.execution.prefect_executor.stage_execution_context') as mock_context:
            
            # Mock future
            mock_future = Mock()
            mock_future.result.return_value = {"result": "success"}
            mock_submit.return_value = mock_future
            
            # Mock execution context
            mock_execution = Mock()
            mock_context.return_value.__enter__.return_value = mock_execution
            mock_context.return_value.__exit__.return_value = None
            
            results = PrefectExecutor.execute_sequential_monitored(tasks, ctx, stage, workflow_id)
            
            assert len(results) == 1
            assert results[0] == {"result": "success"}
            assert mock_execution.result == {"result": "success"}
            
            mock_submit.assert_called_once_with(ctx)
            mock_context.assert_called_once_with(stage, 'test_task', workflow_id)
    
    def test_execute_sequential_monitored_with_error(self):
        """Test sequential execution with error handling."""
        # Create mock task that raises an error
        @task
        def failing_task(ctx):
            raise ValueError("Task failed")
        
        tasks = [failing_task]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch.object(failing_task, 'submit') as mock_submit, \
             patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager, \
             patch('agent_sdk.core.execution.prefect_executor.stage_execution_context') as mock_context:
            
            # Mock future that raises an error
            mock_future = Mock()
            mock_future.result.side_effect = ValueError("Task failed")
            mock_submit.return_value = mock_future
            
            # Mock execution context
            mock_execution = Mock()
            mock_context.return_value.__enter__.return_value = mock_execution
            mock_context.return_value.__exit__.return_value = None
            
            with pytest.raises(ValueError, match="Task failed"):
                PrefectExecutor.execute_sequential_monitored(tasks, ctx, stage, workflow_id)
    
    def test_execute_concurrent_monitored(self):
        """Test concurrent execution with state monitoring."""
        # Create mock tasks
        @task
        def task1(ctx):
            return {"result": "task1"}
        
        @task
        def task2(ctx):
            return {"result": "task2"}
        
        tasks = [task1, task2]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch.object(task1, 'submit') as mock_submit1, \
             patch.object(task2, 'submit') as mock_submit2, \
             patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager:
            
            # Mock state manager
            mock_manager = Mock()
            mock_get_manager.return_value = mock_manager
            
            # Mock executions
            mock_execution1 = Mock()
            mock_execution1.is_finished = False
            mock_execution2 = Mock()
            mock_execution2.is_finished = False
            
            mock_manager.create_execution.side_effect = [mock_execution1, mock_execution2]
            
            # Mock futures
            mock_future1 = Mock()
            mock_future1.result.return_value = {"result": "task1"}
            mock_future2 = Mock()
            mock_future2.result.return_value = {"result": "task2"}
            
            mock_submit1.return_value = mock_future1
            mock_submit2.return_value = mock_future2
            
            results = PrefectExecutor.execute_concurrent_monitored(tasks, ctx, stage, workflow_id)
            
            assert len(results) == 2
            assert results[0] == {"result": "task1"}
            assert results[1] == {"result": "task2"}
            
            # Verify state updates
            assert mock_manager.update_state.call_count >= 4  # Started, Running for each task
            assert mock_execution1.result == {"result": "task1"}
            assert mock_execution2.result == {"result": "task2"}
    
    def test_execute_concurrent_monitored_with_error(self):
        """Test concurrent execution with error handling."""
        # Create mock task that fails
        @task
        def failing_task(ctx):
            raise ValueError("Task failed")
        
        tasks = [failing_task]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch.object(failing_task, 'submit') as mock_submit, \
             patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager:
            
            # Mock state manager
            mock_manager = Mock()
            mock_get_manager.return_value = mock_manager
            
            # Mock execution
            mock_execution = Mock()
            mock_execution.is_finished = False
            mock_manager.create_execution.return_value = mock_execution
            
            # Mock future that raises an error
            mock_future = Mock()
            mock_future.result.side_effect = ValueError("Task failed")
            mock_submit.return_value = mock_future
            
            with pytest.raises(ValueError, match="Task failed"):
                PrefectExecutor.execute_concurrent_monitored(tasks, ctx, stage, workflow_id)
            
            # Verify error state was set
            mock_manager.update_state.assert_called()
    
    @pytest.mark.asyncio
    async def test_execute_async_tasks(self):
        """Test async task execution."""
        # Create mock async task
        async def async_func(ctx):
            return {"result": "async"}
        
        # Create mock sync task
        def sync_func(ctx):
            return {"result": "sync"}
        
        # Mock Prefect tasks
        async_task = Mock()
        async_task.name = "async_task"
        async_task.fn = async_func
        async_task.isasync = True
        
        sync_task = Mock()
        sync_task.name = "sync_task"
        sync_task.fn = sync_func
        sync_task.isasync = False
        
        # Mock sync task submission
        mock_future = Mock()
        mock_future.result.return_value = {"result": "sync"}
        sync_task.submit.return_value = mock_future
        
        tasks = [async_task, sync_task]
        ctx = {"input": "test"}
        
        results = await PrefectExecutor.execute_async_tasks(tasks, ctx)
        
        assert len(results) == 2
        assert results[0] == {"result": "async"}
        assert results[1] == {"result": "sync"}
        
        sync_task.submit.assert_called_once_with(ctx)
    
    @pytest.mark.asyncio
    async def test_execute_concurrent_async_tasks(self):
        """Test concurrent async task execution."""
        # Create mock async functions
        async def async_func1(ctx):
            await asyncio.sleep(0.01)  # Small delay
            return {"result": "async1"}
        
        async def async_func2(ctx):
            await asyncio.sleep(0.01)  # Small delay
            return {"result": "async2"}
        
        # Mock Prefect tasks
        async_task1 = Mock()
        async_task1.name = "async_task1"
        async_task1.fn = async_func1
        async_task1.isasync = True
        
        async_task2 = Mock()
        async_task2.name = "async_task2"
        async_task2.fn = async_func2
        async_task2.isasync = True
        
        tasks = [async_task1, async_task2]
        ctx = {"input": "test"}
        
        results = await PrefectExecutor.execute_concurrent_async_tasks(tasks, ctx)
        
        assert len(results) == 2
        assert results[0] == {"result": "async1"}
        assert results[1] == {"result": "async2"}
    
    @pytest.mark.asyncio
    async def test_execute_async_tasks_monitored(self):
        """Test async task execution with monitoring."""
        # Create mock async function
        async def async_func(ctx):
            return {"result": "async"}
        
        # Mock Prefect task
        async_task = Mock()
        async_task.name = "async_task"
        async_task.fn = async_func
        async_task.isasync = True
        
        tasks = [async_task]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager, \
             patch('agent_sdk.core.execution.prefect_executor.stage_execution_context') as mock_context:
            
            # Mock execution context
            mock_execution = Mock()
            mock_context.return_value.__enter__.return_value = mock_execution
            mock_context.return_value.__exit__.return_value = None
            
            results = await PrefectExecutor.execute_async_tasks_monitored(tasks, ctx, stage, workflow_id)
            
            assert len(results) == 1
            assert results[0] == {"result": "async"}
            assert mock_execution.result == {"result": "async"}
    
    @pytest.mark.asyncio
    async def test_execute_concurrent_async_tasks_monitored(self):
        """Test concurrent async task execution with monitoring."""
        # Create mock async functions
        async def async_func1(ctx):
            return {"result": "async1"}
        
        async def async_func2(ctx):
            return {"result": "async2"}
        
        # Mock Prefect tasks
        async_task1 = Mock()
        async_task1.name = "async_task1"
        async_task1.fn = async_func1
        async_task1.isasync = True
        
        async_task2 = Mock()
        async_task2.name = "async_task2"
        async_task2.fn = async_func2
        async_task2.isasync = True
        
        tasks = [async_task1, async_task2]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager:
            
            # Mock state manager
            mock_manager = Mock()
            mock_get_manager.return_value = mock_manager
            
            # Mock executions
            mock_execution1 = Mock()
            mock_execution2 = Mock()
            mock_manager.create_execution.side_effect = [mock_execution1, mock_execution2]
            
            results = await PrefectExecutor.execute_concurrent_async_tasks_monitored(tasks, ctx, stage, workflow_id)
            
            assert len(results) == 2
            assert results[0] == {"result": "async1"}
            assert results[1] == {"result": "async2"}
            
            # Verify state updates
            assert mock_manager.update_state.call_count >= 4  # Started, Running, Completed for each
            assert mock_execution1.result == {"result": "async1"}
            assert mock_execution2.result == {"result": "async2"}
    
    @pytest.mark.asyncio
    async def test_execute_concurrent_async_tasks_monitored_with_error(self):
        """Test concurrent async task execution with error handling."""
        # Create mock async function that fails
        async def failing_async_func(ctx):
            raise ValueError("Async task failed")
        
        # Mock Prefect task
        failing_task = Mock()
        failing_task.name = "failing_task"
        failing_task.fn = failing_async_func
        failing_task.isasync = True
        
        tasks = [failing_task]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager:
            
            # Mock state manager
            mock_manager = Mock()
            mock_get_manager.return_value = mock_manager
            
            # Mock execution
            mock_execution = Mock()
            mock_manager.create_execution.return_value = mock_execution
            
            with pytest.raises(ValueError, match="Async task failed"):
                await PrefectExecutor.execute_concurrent_async_tasks_monitored(tasks, ctx, stage, workflow_id)
            
            # Verify error state was set
            mock_manager.update_state.assert_called()


class TestPrefectExecutorEdgeCases:
    """Test edge cases for PrefectExecutor."""
    
    def test_task_name_extraction(self):
        """Test task name extraction from different task types."""
        # Test with task that has name attribute
        task_with_name = Mock()
        task_with_name.name = "custom_name"
        
        # Test with function that has __name__ attribute
        def test_function(ctx):
            return {"result": "test"}
        
        # Test name extraction logic
        name1 = getattr(task_with_name, 'name', getattr(task_with_name, '__name__', 'unknown'))
        name2 = getattr(test_function, 'name', getattr(test_function, '__name__', 'unknown'))
        
        assert name1 == "custom_name"
        assert name2 == "test_function"
    
    @pytest.mark.asyncio
    async def test_async_task_detection(self):
        """Test async task detection logic."""
        # Test coroutine function detection
        async def async_func(ctx):
            return {"result": "async"}
        
        def sync_func(ctx):
            return {"result": "sync"}
        
        # Test with isasync attribute
        task_with_isasync = Mock()
        task_with_isasync.isasync = True
        task_with_isasync.fn = sync_func  # Even if fn is sync, isasync takes precedence
        
        # Test with coroutine function
        task_with_coroutine = Mock()
        task_with_coroutine.isasync = False
        task_with_coroutine.fn = async_func
        
        # Test sync task
        sync_task = Mock()
        sync_task.isasync = False
        sync_task.fn = sync_func
        
        # Test the detection logic
        assert getattr(task_with_isasync, 'isasync', False) or asyncio.iscoroutinefunction(task_with_isasync.fn)
        assert getattr(task_with_coroutine, 'isasync', False) or asyncio.iscoroutinefunction(task_with_coroutine.fn)
        assert not (getattr(sync_task, 'isasync', False) or asyncio.iscoroutinefunction(sync_task.fn))

    @pytest.mark.asyncio
    async def test_mixed_sync_async_tasks(self):
        """Test mixed sync and async tasks in concurrent execution."""
        # Create mixed tasks
        async def async_func(ctx):
            return {"result": "async"}
        
        def sync_func(ctx):
            return {"result": "sync"}
        
        # Mock tasks
        async_task = Mock()
        async_task.name = "async_task"
        async_task.fn = async_func
        async_task.isasync = True
        
        sync_task = Mock()
        sync_task.name = "sync_task"
        sync_task.fn = sync_func
        sync_task.isasync = False
        
        # Mock sync task submission
        mock_future = Mock()
        mock_future.result.return_value = {"result": "sync"}
        sync_task.submit.return_value = mock_future
        
        tasks = [async_task, sync_task]
        ctx = {"input": "test"}
        
        results = await PrefectExecutor.execute_concurrent_async_tasks(tasks, ctx)
        
        assert len(results) == 2
        assert results[0] == {"result": "async"}
        assert results[1] == {"result": "sync"}

    @pytest.mark.asyncio
    async def test_async_tasks_monitored_with_error(self):
        """Test async tasks monitored execution with error."""
        # Create mock async function that fails
        async def failing_async_func(ctx):
            raise ValueError("Async task failed")
        
        # Mock Prefect task
        failing_task = Mock()
        failing_task.name = "failing_task"
        failing_task.fn = failing_async_func
        failing_task.isasync = True
        
        tasks = [failing_task]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager, \
             patch('agent_sdk.core.execution.prefect_executor.stage_execution_context') as mock_context:
            
            # Mock execution context
            mock_execution = Mock()
            mock_context.return_value.__enter__.return_value = mock_execution
            mock_context.return_value.__exit__.return_value = None
            
            with pytest.raises(ValueError, match="Async task failed"):
                await PrefectExecutor.execute_async_tasks_monitored(tasks, ctx, stage, workflow_id)

    @pytest.mark.asyncio
    async def test_sync_task_in_async_execution(self):
        """Test sync task execution in async context."""
        # Create sync function
        def sync_func(ctx):
            return {"result": "sync"}
        
        # Mock sync task
        sync_task = Mock()
        sync_task.name = "sync_task"
        sync_task.fn = sync_func
        sync_task.isasync = False
        
        # Mock task submission
        mock_future = Mock()
        mock_future.result.return_value = {"result": "sync"}
        sync_task.submit.return_value = mock_future
        
        tasks = [sync_task]
        ctx = {"input": "test"}
        stage = Stage.PERCEIVE
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.prefect_executor.get_state_manager') as mock_get_manager, \
             patch('agent_sdk.core.execution.prefect_executor.stage_execution_context') as mock_context:
            
            # Mock execution context
            mock_execution = Mock()
            mock_context.return_value.__enter__.return_value = mock_execution
            mock_context.return_value.__exit__.return_value = None
            
            results = await PrefectExecutor.execute_async_tasks_monitored(tasks, ctx, stage, workflow_id)
            
            assert len(results) == 1
            assert results[0] == {"result": "sync"}
            assert mock_execution.result == {"result": "sync"}
            sync_task.submit.assert_called_once_with(ctx)