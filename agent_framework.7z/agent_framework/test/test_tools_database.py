"""Tests for database tools module."""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from contextlib import asynccontextmanager
from typing import Dict, Any, List
import json

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from agent_sdk.tools.database import (
    BaseDatabaseTool, PostgreSQLTool, MongoDBTool, Neo4jTool
)
from agent_sdk.tools.base import ToolResult, ToolStatus, ToolError


class TestBaseDatabaseTool:
    """Test BaseDatabaseTool functionality."""
    
    def test_base_database_tool_initialization(self):
        """Test BaseDatabaseTool initialization."""
        # BaseDatabaseTool is abstract, so we need to create a concrete implementation
        class ConcreteDatabaseTool(BaseDatabaseTool):
            async def execute(self, **kwargs):
                return ToolResult(self.name, ToolStatus.SUCCESS, {})
        
        config = {'host': 'localhost', 'port': 5432}
        tool = ConcreteDatabaseTool("test_db", config)
        
        assert tool.name == "test_db"
        assert tool.config == config
        assert tool.connection is None
    
    @pytest.mark.asyncio
    async def test_connect_method(self):
        """Test connect method (should be overridden)."""
        class ConcreteDatabaseTool(BaseDatabaseTool):
            async def execute(self, **kwargs):
                return ToolResult(self.name, ToolStatus.SUCCESS, {})
        
        tool = ConcreteDatabaseTool("test", {})
        # Base implementation should do nothing
        await tool.connect()
        assert tool.connection is None
    
    @pytest.mark.asyncio
    async def test_disconnect_method(self):
        """Test disconnect method (should be overridden)."""
        class ConcreteDatabaseTool(BaseDatabaseTool):
            async def execute(self, **kwargs):
                return ToolResult(self.name, ToolStatus.SUCCESS, {})
        
        tool = ConcreteDatabaseTool("test", {})
        # Base implementation should do nothing
        await tool.disconnect()
        assert tool.connection is None
    
    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """Test async context manager functionality."""
        class ConcreteDatabaseTool(BaseDatabaseTool):
            async def execute(self, **kwargs):
                return ToolResult(self.name, ToolStatus.SUCCESS, {})
        
        tool = ConcreteDatabaseTool("test", {})
        
        with patch.object(tool, 'connect') as mock_connect:
            with patch.object(tool, 'disconnect') as mock_disconnect:
                async with tool:
                    mock_connect.assert_called_once()
                    pass
                mock_disconnect.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_async_context_manager_with_exception(self):
        """Test async context manager with exception."""
        class ConcreteDatabaseTool(BaseDatabaseTool):
            async def execute(self, **kwargs):
                return ToolResult(self.name, ToolStatus.SUCCESS, {})
        
        tool = ConcreteDatabaseTool("test", {})
        
        with patch.object(tool, 'connect') as mock_connect:
            with patch.object(tool, 'disconnect') as mock_disconnect:
                try:
                    async with tool:
                        raise ValueError("Test error")
                except ValueError:
                    pass
                
                mock_connect.assert_called_once()
                mock_disconnect.assert_called_once()


class TestPostgreSQLTool:
    """Test PostgreSQLTool functionality."""
    
    def test_postgresql_tool_initialization(self):
        """Test PostgreSQLTool initialization."""
        config = {
            'url': 'postgresql://user:pass@localhost:5432/db',
            'host': 'localhost',
            'port': 5432,
            'database': 'testdb',
            'username': 'testuser',
            'password': 'testpass',
            'pool_size': 10
        }
        
        tool = PostgreSQLTool("postgres", config)
        
        assert tool.name == "postgres"
        assert tool.url == 'postgresql://user:pass@localhost:5432/db'
        assert tool.host == 'localhost'
        assert tool.port == 5432
        assert tool.database == 'testdb'
        assert tool.username == 'testuser'
        assert tool.password == 'testpass'
        assert tool.pool_size == 10
    
    def test_postgresql_tool_default_values(self):
        """Test PostgreSQLTool with default values."""
        tool = PostgreSQLTool("postgres", {})
        
        assert tool.host == 'localhost'
        assert tool.port == 5432
        assert tool.pool_size == 5
    
    def test_validate_config_with_url(self):
        """Test configuration validation with URL."""
        tool = PostgreSQLTool("test", {'url': 'postgresql://localhost/db'})
        assert tool.validate_config() is True
    
    def test_validate_config_with_components(self):
        """Test configuration validation with individual components."""
        config = {
            'host': 'localhost',
            'database': 'testdb',
            'username': 'user',
            'password': 'pass'
        }
        tool = PostgreSQLTool("test", config)
        assert tool.validate_config() is True
    
    def test_validate_config_missing_required(self):
        """Test configuration validation with missing required fields."""
        tool = PostgreSQLTool("test", {'host': 'localhost'})
        assert tool.validate_config() is False
    
    @pytest.mark.asyncio
    async def test_connect_with_url(self):
        """Test connecting with URL."""
        tool = PostgreSQLTool("test", {'url': 'postgresql://localhost/db'})
        
        with patch('asyncpg.create_pool') as mock_create_pool:
            mock_pool = AsyncMock()
            mock_create_pool.return_value = mock_pool
            # Make the mock awaitable
            async def async_create_pool(*args, **kwargs):
                return mock_pool
            mock_create_pool.side_effect = async_create_pool
            
            await tool.connect()
            
            mock_create_pool.assert_called_once_with(
                'postgresql://localhost/db',
                min_size=1,
                max_size=5
            )
            assert tool.connection == mock_pool
    
    @pytest.mark.asyncio
    async def test_connect_with_components(self):
        """Test connecting with individual components."""
        config = {
            'host': 'localhost',
            'port': 5432,
            'database': 'testdb',
            'username': 'user',
            'password': 'pass',
            'pool_size': 10
        }
        tool = PostgreSQLTool("test", config)
        
        with patch('asyncpg.create_pool') as mock_create_pool:
            mock_pool = AsyncMock()
            # Make the mock awaitable
            async def async_create_pool(*args, **kwargs):
                return mock_pool
            mock_create_pool.side_effect = async_create_pool
            
            await tool.connect()
            
            mock_create_pool.assert_called_once_with(
                host='localhost',
                port=5432,
                database='testdb',
                user='user',
                password='pass',
                min_size=1,
                max_size=10
            )
    
    @pytest.mark.asyncio
    async def test_disconnect(self):
        """Test disconnecting from database."""
        tool = PostgreSQLTool("test", {'url': 'postgresql://localhost/db'})
        
        mock_pool = AsyncMock()
        tool.pool = mock_pool
        tool.connection = mock_pool
        
        await tool.disconnect()
        
        mock_pool.close.assert_called_once()
        mock_pool.wait_closed.assert_called_once()
        assert tool.connection is None
    
    @pytest.mark.asyncio
    async def test_execute_query_fetch_all(self):
        """Test executing query with fetch='all'."""
        tool = PostgreSQLTool("test", {'url': 'postgresql://localhost/db'})
        
        mock_connection = AsyncMock()
        mock_pool = AsyncMock()
        
        # Create async context manager using asynccontextmanager
        @asynccontextmanager
        async def mock_acquire():
            yield mock_connection
        
        mock_pool.acquire = mock_acquire
        
        mock_connection.fetch.return_value = [
            {'id': 1, 'name': 'Alice'},
            {'id': 2, 'name': 'Bob'}
        ]
        tool.pool = mock_pool
        tool.connection = mock_pool
        
        result = await tool.execute(
            query="SELECT * FROM users",
            fetch="all"
        )
        
        assert result.status == ToolStatus.SUCCESS
        assert len(result.data['rows']) == 2
        assert result.data['rows'][0] == {'id': 1, 'name': 'Alice'}
        mock_connection.fetch.assert_called_once_with("SELECT * FROM users")
    
    @pytest.mark.asyncio
    async def test_execute_query_fetch_one(self):
        """Test executing query with fetch='one'."""
        tool = PostgreSQLTool("test", {'url': 'postgresql://localhost/db'})
        
        mock_connection = AsyncMock()
        mock_pool = AsyncMock()
        
        # Create async context manager using asynccontextmanager
        @asynccontextmanager
        async def mock_acquire():
            yield mock_connection
        
        mock_pool.acquire = mock_acquire
        
        mock_connection.fetchrow.return_value = {'id': 1, 'name': 'Alice'}
        tool.pool = mock_pool
        tool.connection = mock_pool
        
        result = await tool.execute(
            query="SELECT * FROM users WHERE id = $1",
            params=[1],
            fetch="one"
        )
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data['row'] == {'id': 1, 'name': 'Alice'}
        mock_connection.fetchrow.assert_called_once_with("SELECT * FROM users WHERE id = $1", 1)
    
    @pytest.mark.asyncio
    async def test_execute_query_no_connection(self):
        """Test executing query without connection."""
        tool = PostgreSQLTool("test", {'url': 'postgresql://localhost/db'})
        
        result = await tool.execute(query="SELECT 1")
        
        assert result.status == ToolStatus.ERROR
        assert "not connected" in str(result.error).lower()
    
    @pytest.mark.asyncio
    async def test_execute_query_with_exception(self):
        """Test executing query with database exception."""
        tool = PostgreSQLTool("test", {'url': 'postgresql://localhost/db'})
        
        mock_connection = AsyncMock()
        mock_pool = AsyncMock()
        
        # Create async context manager using asynccontextmanager
        @asynccontextmanager
        async def mock_acquire():
            yield mock_connection
        
        mock_pool.acquire = mock_acquire
        
        mock_connection.fetch.side_effect = Exception("Database error")
        tool.pool = mock_pool
        tool.connection = mock_pool
        
        result = await tool.execute(query="INVALID SQL")
        
        assert result.status == ToolStatus.ERROR
        assert "Database error" in str(result.error)
    
    def test_get_schema(self):
        """Test getting PostgreSQL tool schema."""
        tool = PostgreSQLTool("test", {})
        schema = tool.get_schema()
        
        assert schema['name'] == 'test'
        assert 'description' in schema
        assert 'parameters' in schema
        assert 'query' in schema['parameters']


class TestMongoDBTool:
    """Test MongoDBTool functionality."""
    
    def test_mongodb_tool_initialization(self):
        """Test MongoDBTool initialization."""
        config = {
            'url': 'mongodb://localhost:27017/testdb',
            'host': 'localhost',
            'port': 27017,
            'database': 'testdb',
            'username': 'user',
            'password': 'pass'
        }
        
        tool = MongoDBTool("mongo", config)
        
        assert tool.name == "mongo"
        assert tool.url == 'mongodb://localhost:27017/testdb'
        assert tool.host == 'localhost'
        assert tool.port == 27017
        assert tool.database == 'testdb'
        assert tool.username == 'user'
        assert tool.password == 'pass'
    
    def test_mongodb_tool_default_values(self):
        """Test MongoDBTool with default values."""
        tool = MongoDBTool("mongo", {})
        
        assert tool.host == 'localhost'
        assert tool.port == 27017
    
    def test_validate_config_with_url(self):
        """Test configuration validation with URL."""
        tool = MongoDBTool("test", {'url': 'mongodb://localhost/db'})
        assert tool.validate_config() is True
    
    def test_validate_config_with_components(self):
        """Test configuration validation with components."""
        config = {'host': 'localhost', 'database': 'testdb'}
        tool = MongoDBTool("test", config)
        assert tool.validate_config() is True
    
    def test_validate_config_missing_required(self):
        """Test configuration validation with missing database."""
        tool = MongoDBTool("test", {'host': 'localhost'})
        assert tool.validate_config() is False
    
    @pytest.mark.asyncio
    async def test_connect(self):
        """Test connecting to MongoDB."""
        tool = MongoDBTool("test", {'url': 'mongodb://localhost/testdb'})
        
        with patch('motor.motor_asyncio.AsyncIOMotorClient') as mock_client_class:
            mock_client = AsyncMock()
            mock_db = AsyncMock()
            mock_client_class.return_value = mock_client
            mock_client.__getitem__.return_value = mock_db
            
            await tool.connect()
            
            mock_client_class.assert_called_once_with('mongodb://localhost/testdb')
            assert tool.connection == mock_client
            assert tool.db == mock_db
    
    @pytest.mark.asyncio
    async def test_disconnect(self):
        """Test disconnecting from MongoDB."""
        tool = MongoDBTool("test", {'url': 'mongodb://localhost/testdb'})
        
        mock_client = AsyncMock()
        tool.client = mock_client
        tool.connection = mock_client
        
        await tool.disconnect()
        
        mock_client.close.assert_called_once()
        assert tool.connection is None
        assert tool.db is None
    
    @pytest.mark.asyncio
    async def test_execute_find_operation(self):
        """Test executing find operation."""
        tool = MongoDBTool("test", {'url': 'mongodb://localhost/testdb'})
        
        mock_collection = Mock()  # Use regular Mock, not AsyncMock
        mock_db = AsyncMock()
        mock_db.__getitem__.return_value = mock_collection
        
        # Mock the find cursor and to_list method properly
        mock_cursor = Mock()
        async def mock_to_list(length=None):
            return [
                {'_id': '1', 'name': 'Alice'},
                {'_id': '2', 'name': 'Bob'}
            ]
        mock_cursor.to_list = mock_to_list
        mock_collection.find.return_value = mock_cursor
        
        tool.db = mock_db
        tool.connection = AsyncMock()  # Set connection to indicate connected state
        
        result = await tool.execute(
            operation='find',
            collection='users',
            query={'active': True}
        )
        
        assert result.status == ToolStatus.SUCCESS
        assert len(result.data['documents']) == 2
        mock_collection.find.assert_called_once_with({'active': True})
    
    @pytest.mark.asyncio
    async def test_execute_insert_one_operation(self):
        """Test executing insert_one operation."""
        tool = MongoDBTool("test", {'url': 'mongodb://localhost/testdb'})
        
        mock_collection = AsyncMock()
        mock_db = AsyncMock()
        mock_db.__getitem__.return_value = mock_collection
        mock_collection.insert_one.return_value.inserted_id = 'new_id'
        tool.db = mock_db
        tool.connection = AsyncMock()  # Set connection to indicate connected state
        
        result = await tool.execute(
            operation='insert_one',
            collection='users',
            document={'name': 'Charlie', 'age': 30}
        )
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data['inserted_id'] == 'new_id'
        mock_collection.insert_one.assert_called_once_with({'name': 'Charlie', 'age': 30})
    
    @pytest.mark.asyncio
    async def test_execute_update_one_operation(self):
        """Test executing update_one operation."""
        tool = MongoDBTool("test", {'url': 'mongodb://localhost/testdb'})
        
        mock_collection = AsyncMock()
        mock_db = AsyncMock()
        mock_db.__getitem__.return_value = mock_collection
        mock_result = AsyncMock()
        mock_result.modified_count = 1
        mock_collection.update_one.return_value = mock_result
        tool.db = mock_db
        tool.connection = AsyncMock()  # Set connection to indicate connected state
        
        result = await tool.execute(
            operation='update_one',
            collection='users',
            query={'_id': '1'},
            document={'$set': {'age': 31}}
        )
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data['modified_count'] == 1
        mock_collection.update_one.assert_called_once_with(
            {'_id': '1'},
            {'$set': {'age': 31}}
        )
    
    @pytest.mark.asyncio
    async def test_execute_delete_one_operation(self):
        """Test executing delete_one operation."""
        tool = MongoDBTool("test", {'url': 'mongodb://localhost/testdb'})
        
        mock_collection = AsyncMock()
        mock_db = AsyncMock()
        mock_db.__getitem__.return_value = mock_collection
        mock_result = AsyncMock()
        mock_result.deleted_count = 1
        mock_collection.delete_one.return_value = mock_result
        tool.db = mock_db
        tool.connection = AsyncMock()  # Set connection to indicate connected state
        
        result = await tool.execute(
            operation='delete_one',
            collection='users',
            query={'_id': '1'}
        )
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data['deleted_count'] == 1
        mock_collection.delete_one.assert_called_once_with({'_id': '1'})
    
    @pytest.mark.asyncio
    async def test_execute_unsupported_operation(self):
        """Test executing unsupported operation."""
        tool = MongoDBTool("test", {'url': 'mongodb://localhost/testdb'})
        tool.db = AsyncMock()
        tool.connection = AsyncMock()  # Set connection to indicate connected state
        
        result = await tool.execute(
            operation='unsupported',
            collection='users'
        )
        
        assert result.status == ToolStatus.ERROR
        assert "Unsupported operation" in str(result.error)


class TestNeo4jTool:
    """Test Neo4jTool functionality."""
    
    def test_neo4j_tool_initialization(self):
        """Test Neo4jTool initialization."""
        config = {
            'uri': 'bolt://localhost:7687',
            'username': 'neo4j',
            'password': 'password',
            'database': 'neo4j'
        }
        
        tool = Neo4jTool("neo4j", config)
        
        assert tool.name == "neo4j"
        assert tool.uri == 'bolt://localhost:7687'
        assert tool.username == 'neo4j'
        assert tool.password == 'password'
        assert tool.database == 'neo4j'
    
    def test_neo4j_tool_default_values(self):
        """Test Neo4jTool with default values."""
        tool = Neo4jTool("neo4j", {})
        
        assert tool.uri == 'bolt://localhost:7687'
        assert tool.username == 'neo4j'
        assert tool.database == 'neo4j'
    
    def test_validate_config_valid(self):
        """Test configuration validation with valid config."""
        config = {
            'uri': 'bolt://localhost:7687',
            'username': 'neo4j',
            'password': 'password'
        }
        tool = Neo4jTool("test", config)
        assert tool.validate_config() is True
    
    def test_validate_config_missing_password(self):
        """Test configuration validation with missing password."""
        config = {
            'uri': 'bolt://localhost:7687',
            'username': 'neo4j'
        }
        tool = Neo4jTool("test", config)
        assert tool.validate_config() is False
    
    @pytest.mark.asyncio
    async def test_connect(self):
        """Test connecting to Neo4j."""
        tool = Neo4jTool("test", {
            'uri': 'bolt://localhost:7687',
            'username': 'neo4j',
            'password': 'password'
        })
        
        with patch('neo4j.AsyncGraphDatabase.driver') as mock_driver:
            mock_driver_instance = AsyncMock()
            mock_driver.return_value = mock_driver_instance
            
            await tool.connect()
            
            mock_driver.assert_called_once_with(
                'bolt://localhost:7687',
                auth=('neo4j', 'password')
            )
            assert tool.connection == mock_driver_instance
    
    @pytest.mark.asyncio
    async def test_disconnect(self):
        """Test disconnecting from Neo4j."""
        tool = Neo4jTool("test", {})
        
        mock_driver = AsyncMock()
        tool.driver = mock_driver
        tool.connection = mock_driver
        
        await tool.disconnect()
        
        mock_driver.close.assert_called_once()
        assert tool.connection is None
    
    @pytest.mark.asyncio
    async def test_execute_query(self):
        """Test executing Cypher query."""
        tool = Neo4jTool("test", {
            'uri': 'bolt://localhost:7687',
            'username': 'neo4j',
            'password': 'password'
        })
        
        mock_session = AsyncMock()
        mock_driver = AsyncMock()
        
        # Create async context manager using asynccontextmanager
        @asynccontextmanager
        async def mock_session_context(database=None):
            yield mock_session
        
        mock_driver.session = mock_session_context
        
        mock_result = AsyncMock()
        mock_result.data.return_value = [
            {'n.name': 'Alice', 'n.age': 30},
            {'n.name': 'Bob', 'n.age': 25}
        ]
        mock_session.run.return_value = mock_result
        
        tool.driver = mock_driver
        tool.connection = mock_driver
        
        result = await tool.execute(
            query="MATCH (n:Person) RETURN n.name, n.age",
            params={'min_age': 18}
        )
        
        assert result.status == ToolStatus.SUCCESS
        assert len(result.data['records']) == 2
        mock_session.run.assert_called_once_with(
            "MATCH (n:Person) RETURN n.name, n.age",
            {'min_age': 18}
        )
    
    @pytest.mark.asyncio
    async def test_execute_query_no_connection(self):
        """Test executing query without connection."""
        tool = Neo4jTool("test", {})
        
        result = await tool.execute(query="MATCH (n) RETURN n")
        
        assert result.status == ToolStatus.ERROR
        assert "not connected" in str(result.error).lower()
    
    @pytest.mark.asyncio
    async def test_execute_query_with_exception(self):
        """Test executing query with Neo4j exception."""
        tool = Neo4jTool("test", {})
        
        mock_session = AsyncMock()
        mock_driver = AsyncMock()
        
        # Create async context manager using asynccontextmanager
        @asynccontextmanager
        async def mock_session_context(database=None):
            yield mock_session
        
        mock_driver.session = mock_session_context
        mock_session.run.side_effect = Exception("Neo4j error")
        
        tool.driver = mock_driver
        tool.connection = mock_driver
        
        result = await tool.execute(query="INVALID CYPHER")
        
        assert result.status == ToolStatus.ERROR
        assert "Neo4j error" in str(result.error)


class TestDatabaseToolsEdgeCases:
    """Test edge cases for database tools."""
    
    @pytest.mark.asyncio
    async def test_postgresql_tool_connection_error(self):
        """Test PostgreSQL connection error handling."""
        tool = PostgreSQLTool("test", {'url': 'postgresql://invalid:5432/db'})
        
        with patch('asyncpg.create_pool') as mock_create_pool:
            mock_create_pool.side_effect = Exception("Connection failed")
            
            try:
                await tool.connect()
                assert False, "Expected ToolError to be raised"
            except ToolError as e:
                assert "Connection failed" in str(e)
                assert tool.connection is None
    
    @pytest.mark.asyncio
    async def test_mongodb_tool_connection_error(self):
        """Test MongoDB connection error handling."""
        tool = MongoDBTool("test", {'url': 'mongodb://invalid:27017/db'})
        
        with patch('motor.motor_asyncio.AsyncIOMotorClient') as mock_client:
            mock_client.side_effect = Exception("Connection failed")
            
            try:
                await tool.connect()
                assert False, "Expected ToolError to be raised"
            except ToolError as e:
                assert "Connection failed" in str(e)
                assert tool.connection is None
    
    @pytest.mark.asyncio
    async def test_neo4j_tool_connection_error(self):
        """Test Neo4j connection error handling."""
        tool = Neo4jTool("test", {
            'uri': 'bolt://invalid:7687',
            'username': 'neo4j',
            'password': 'password'
        })
        
        with patch('neo4j.AsyncGraphDatabase.driver') as mock_driver:
            mock_driver.side_effect = Exception("Connection failed")
            
            try:
                await tool.connect()
                assert False, "Expected ToolError to be raised"
            except ToolError as e:
                assert "Connection failed" in str(e)
                assert tool.connection is None
    
    def test_database_tools_inheritance(self):
        """Test that database tools properly inherit from BaseDatabaseTool."""
        postgres_tool = PostgreSQLTool("postgres", {})
        mongo_tool = MongoDBTool("mongo", {})
        neo4j_tool = Neo4jTool("neo4j", {})
        
        # All should inherit from BaseDatabaseTool
        assert isinstance(postgres_tool, BaseDatabaseTool)
        assert isinstance(mongo_tool, BaseDatabaseTool)
        assert isinstance(neo4j_tool, BaseDatabaseTool)
        
        # All should have required methods
        for tool in [postgres_tool, mongo_tool, neo4j_tool]:
            assert hasattr(tool, 'connect')
            assert hasattr(tool, 'disconnect')
            assert hasattr(tool, 'execute')
            assert hasattr(tool, 'validate_config')
            assert hasattr(tool, 'get_schema')