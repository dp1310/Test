"""Comprehensive tests for agent implementations."""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from typing import Dict, Any, List

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from agent_sdk.agent.simple_sync_agent import SimpleSyncAgent
from agent_sdk.agent.simple_async_agent import SimpleAsyncAgent
from agent_sdk.agent.prefect_sync_agent import PrefectSyncAgent
from agent_sdk.agent.prefect_async_agent import PrefectAsyncAgent
from agent_sdk.core.stages import Stage, perceive, reason, plan, act
from agent_sdk.core.context import Context


class TestSimpleSyncAgentComprehensive:
    """Comprehensive tests for SimpleSyncAgent."""
    
    def test_simple_sync_agent_basic_execution(self):
        """Test basic execution flow."""
        @perceive
        def perceive_func(ctx): return {"perceived": "data"}
        
        @reason
        def reason_func(ctx): return {"reasoned": ctx.get("perceived")}
        
        agent = SimpleSyncAgent(
            functions=[perceive_func, reason_func],
            workflow_id="test_sync"
        )
        
        result = agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        # Input data is wrapped in "input" key by the spine
        assert result.get("input") == {"input": "test"}
        assert result.get("perceived") == "data"
        assert result.get("reasoned") == "data"
    
    def test_simple_sync_agent_with_initial_context(self):
        """Test execution with initial context."""
        @perceive
        def perceive_func(ctx): 
            return {"perceived": ctx.get("config_value")}
        
        agent = SimpleSyncAgent(
            functions=[perceive_func],
            initial_context={"config_value": "from_config"}
        )
        
        result = agent.execute({"input": "test"})
        
        assert result.get("config_value") == "from_config"
        assert result.get("perceived") == "from_config"
    
    def test_simple_sync_agent_concurrent_config_ignored(self):
        """Test that concurrent config is passed to spine but ignored in sync mode."""
        @perceive
        def perceive_func(ctx): return {"perceived": True}
        
        agent = SimpleSyncAgent(
            functions=[perceive_func],
            concurrent={Stage.PERCEIVE: True}  # Should be passed but ignored in sync mode
        )
        
        # Execute and check that it runs (sync mode will log warning about concurrent)
        result = agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        assert result.get("perceived") is True
    
    def test_simple_sync_agent_dynamic_functions(self):
        """Test dynamic function override."""
        @perceive
        def original_func(ctx): return {"original": True}
        
        @perceive
        def override_func(ctx): return {"override": True}
        
        agent = SimpleSyncAgent(functions=[original_func])
        
        # Test with dynamic function override
        input_data = {
            "input": "test",
            "_agent_config": {
                "functions": [override_func]
            }
        }
        
        result = agent.execute(input_data)
        
        # When dynamic functions are used, they should override the original functions
        assert result.get("override") is True
        assert "original" not in result.data
    
    def test_simple_sync_agent_error_handling(self):
        """Test error handling in sync agent."""
        @perceive
        def failing_func(ctx):
            raise ValueError("Test error")
        
        agent = SimpleSyncAgent(functions=[failing_func])
        
        with pytest.raises(ValueError, match="Test error"):
            agent.execute({"input": "test"})
    
    def test_simple_sync_agent_string_representation(self):
        """Test string representation."""
        agent = SimpleSyncAgent(functions=[Mock(), Mock(), Mock()])
        
        str_repr = str(agent)
        assert "SimpleSyncAgent" in str_repr
        assert "functions=3" in str_repr
    
    def test_simple_sync_agent_execution_type(self):
        """Test execution type identifier."""
        agent = SimpleSyncAgent()
        assert agent.get_execution_type() == "simple_sync"


class TestSimpleAsyncAgentComprehensive:
    """Comprehensive tests for SimpleAsyncAgent."""
    
    @pytest.mark.asyncio
    async def test_simple_async_agent_basic_execution(self):
        """Test basic async execution flow."""
        @perceive
        async def async_perceive(ctx): 
            await asyncio.sleep(0.01)
            return {"perceived": "async_data"}
        
        @reason
        def sync_reason(ctx): 
            return {"reasoned": ctx.get("perceived")}
        
        agent = SimpleAsyncAgent(
            functions=[async_perceive, sync_reason],
            workflow_id="test_async"
        )
        
        result = await agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        assert result.get("perceived") == "async_data"
        assert result.get("reasoned") == "async_data"
    
    @pytest.mark.asyncio
    async def test_simple_async_agent_concurrent_execution(self):
        """Test concurrent execution in async agent."""
        @perceive
        async def perceive1(ctx): 
            await asyncio.sleep(0.01)
            return {"perceive1": "done"}
        
        @perceive
        async def perceive2(ctx): 
            await asyncio.sleep(0.01)
            return {"perceive2": "done"}
        
        agent = SimpleAsyncAgent(
            functions=[perceive1, perceive2],
            concurrent={Stage.PERCEIVE: True}
        )
        
        result = await agent.execute({"input": "test"})
        
        assert result.get("perceive1") == "done"
        assert result.get("perceive2") == "done"
    
    @pytest.mark.asyncio
    async def test_simple_async_agent_mixed_sync_async(self):
        """Test mixed sync and async functions."""
        @perceive
        async def async_func(ctx): 
            await asyncio.sleep(0.01)
            return {"async_result": True}
        
        @reason
        def sync_func(ctx): 
            return {"sync_result": True}
        
        agent = SimpleAsyncAgent(functions=[async_func, sync_func])
        
        result = await agent.execute({"input": "test"})
        
        assert result.get("async_result") is True
        assert result.get("sync_result") is True
    
    @pytest.mark.asyncio
    async def test_simple_async_agent_dynamic_concurrent_config(self):
        """Test dynamic concurrent configuration override."""
        @perceive
        async def perceive_func(ctx): 
            await asyncio.sleep(0.01)
            return {"perceived": True}
        
        agent = SimpleAsyncAgent(
            functions=[perceive_func],
            concurrent={Stage.PERCEIVE: False}  # Default to sequential
        )
        
        # Override to concurrent via input data
        input_data = {
            "input": "test",
            "_agent_config": {
                "concurrent": {Stage.PERCEIVE: True}
            }
        }
        
        result = await agent.execute(input_data)
        
        assert result.get("perceived") is True
    
    @pytest.mark.asyncio
    async def test_simple_async_agent_error_handling(self):
        """Test error handling in async agent."""
        @perceive
        async def failing_async_func(ctx):
            await asyncio.sleep(0.01)
            raise RuntimeError("Async error")
        
        agent = SimpleAsyncAgent(functions=[failing_async_func])
        
        with pytest.raises(RuntimeError, match="Async error"):
            await agent.execute({"input": "test"})
    
    def test_simple_async_agent_execution_type(self):
        """Test execution type identifier."""
        agent = SimpleAsyncAgent()
        assert agent.get_execution_type() == "simple_async"


class TestPrefectSyncAgentComprehensive:
    """Comprehensive tests for PrefectSyncAgent."""
    
    def test_prefect_sync_agent_basic_execution(self):
        """Test basic Prefect sync execution."""
        @perceive
        def perceive_func(ctx): return {"perceived": "prefect_data"}
        
        agent = PrefectSyncAgent(
            functions=[perceive_func],
            workflow_id="test_prefect_sync"
        )
        
        result = agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        assert result.get("perceived") == "prefect_data"
    
    def test_prefect_sync_agent_with_concurrent_config(self):
        """Test Prefect sync agent with concurrent configuration."""
        @perceive
        def perceive1(ctx): return {"perceive1": True}
        
        @perceive
        def perceive2(ctx): return {"perceive2": True}
        
        agent = PrefectSyncAgent(
            functions=[perceive1, perceive2],
            concurrent={Stage.PERCEIVE: True}
        )
        
        result = agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        # Both functions should have executed
        assert result.get("perceive1") is True
        assert result.get("perceive2") is True
    
    def test_prefect_sync_agent_dynamic_configuration(self):
        """Test dynamic configuration in Prefect sync agent."""
        @perceive
        def original_func(ctx): return {"original": True}
        
        @perceive
        def override_func(ctx): return {"override": True}
        
        agent = PrefectSyncAgent(functions=[original_func])
        
        input_data = {
            "input": "test",
            "_agent_config": {
                "functions": [override_func],
                "concurrent": {Stage.PERCEIVE: True}
            }
        }
        
        result = agent.execute(input_data)
        
        assert isinstance(result, Context)
        # Dynamic function should override the original
        assert result.get("override") is True
        assert "original" not in result.data
    
    def test_prefect_sync_agent_execution_type(self):
        """Test execution type identifier."""
        agent = PrefectSyncAgent()
        assert agent.get_execution_type() == "prefect_sync"
    
    def test_prefect_sync_agent_string_representation(self):
        """Test string representation."""
        agent = PrefectSyncAgent(functions=[Mock(), Mock()])
        
        str_repr = str(agent)
        assert "PrefectSyncAgent" in str_repr
        assert "functions=2" in str_repr


class TestPrefectAsyncAgentComprehensive:
    """Comprehensive tests for PrefectAsyncAgent."""
    
    @pytest.mark.asyncio
    async def test_prefect_async_agent_basic_execution(self):
        """Test basic Prefect async execution."""
        @perceive
        async def async_perceive(ctx): 
            return {"perceived": "async_prefect_data"}
        
        agent = PrefectAsyncAgent(
            functions=[async_perceive],
            workflow_id="test_prefect_async"
        )
        
        result = await agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        assert result.get("perceived") == "async_prefect_data"
    
    @pytest.mark.asyncio
    async def test_prefect_async_agent_mixed_functions(self):
        """Test Prefect async agent with mixed sync/async functions."""
        @perceive
        async def async_func(ctx): 
            return {"async_result": True}
        
        @reason
        def sync_func(ctx): 
            return {"sync_result": True}
        
        agent = PrefectAsyncAgent(functions=[async_func, sync_func])
        
        with patch('agent_sdk.core.spine.agentic_spine_async_prefect') as mock_spine:
            mock_spine.return_value = Context({
                "async_result": True,
                "sync_result": True
            })
            
            result = await agent.execute({"input": "test"})
            
            assert result.get("async_result") is True
            assert result.get("sync_result") is True
    
    @pytest.mark.asyncio
    async def test_prefect_async_agent_concurrent_stages(self):
        """Test concurrent stage execution in Prefect async agent."""
        @reason
        async def reason1(ctx): return {"reason1": True}
        
        @reason
        async def reason2(ctx): return {"reason2": True}
        
        agent = PrefectAsyncAgent(
            functions=[reason1, reason2],
            concurrent={Stage.REASON: True}
        )
        
        result = await agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        # Both functions should have executed
        assert result.get("reason1") is True
        assert result.get("reason2") is True
    
    @pytest.mark.asyncio
    async def test_prefect_async_agent_dynamic_override(self):
        """Test dynamic function and config override."""
        @perceive
        def original_func(ctx): return {"original": True}
        
        @perceive
        async def override_func(ctx): 
            return {"override": True}
        
        agent = PrefectAsyncAgent(functions=[original_func])
        
        input_data = {
            "input": "test",
            "_agent_config": {
                "functions": [override_func],
                "concurrent": {Stage.PERCEIVE: True}
            }
        }
        
        result = await agent.execute(input_data)
        
        assert isinstance(result, Context)
        # Dynamic function should override the original
        assert result.get("override") is True
        assert "original" not in result.data
    
    @pytest.mark.asyncio
    async def test_prefect_async_agent_logging(self):
        """Test logging in Prefect async agent."""
        @perceive
        def perceive_func(ctx): return {"perceived": True}
        
        agent = PrefectAsyncAgent(functions=[perceive_func])
        
        with patch('agent_sdk.core.spine.agentic_spine_async_prefect') as mock_spine:
            mock_spine.return_value = Context({"perceived": True})
            
            with patch('agent_sdk.agent.prefect_async_agent.logger') as mock_logger:
                result = await agent.execute({"input": "test"})
                
                # Verify logging calls
                mock_logger.info.assert_called()
                log_calls = [call[0][0] for call in mock_logger.info.call_args_list]
                assert any("Executing Prefect async workflow" in call for call in log_calls)
    
    def test_prefect_async_agent_execution_type(self):
        """Test execution type identifier."""
        agent = PrefectAsyncAgent()
        assert agent.get_execution_type() == "prefect_async"


class TestAgentComparison:
    """Test comparison between different agent types."""
    
    def test_all_agents_inherit_from_base(self):
        """Test that all agents inherit from BaseAgent."""
        from agent_sdk.agent.base_agent import BaseAgent
        
        agents = [
            SimpleSyncAgent(),
            SimpleAsyncAgent(),
            PrefectSyncAgent(),
            PrefectAsyncAgent()
        ]
        
        for agent in agents:
            assert isinstance(agent, BaseAgent)
            assert hasattr(agent, 'execute')
            assert hasattr(agent, 'get_execution_type')
            assert hasattr(agent, 'functions')
            assert hasattr(agent, 'initial_context')
            assert hasattr(agent, 'concurrent')
            assert hasattr(agent, 'workflow_id')
    
    def test_agent_execution_types_unique(self):
        """Test that each agent type has a unique execution type."""
        agents = [
            SimpleSyncAgent(),
            SimpleAsyncAgent(),
            PrefectSyncAgent(),
            PrefectAsyncAgent()
        ]
        
        execution_types = [agent.get_execution_type() for agent in agents]
        
        # All execution types should be unique
        assert len(execution_types) == len(set(execution_types))
        
        # Verify specific types
        assert "simple_sync" in execution_types
        assert "simple_async" in execution_types
        assert "prefect_sync" in execution_types
        assert "prefect_async" in execution_types
    
    def test_agent_configuration_consistency(self):
        """Test that all agents handle configuration consistently."""
        @perceive
        def test_func(ctx): return {"test": True}
        
        config = {
            "functions": [test_func],
            "initial_context": {"config": "value"},
            "concurrent": {Stage.PERCEIVE: True},
            "workflow_id": "test_workflow"
        }
        
        agents = [
            SimpleSyncAgent(**config),
            SimpleAsyncAgent(**config),
            PrefectSyncAgent(**config),
            PrefectAsyncAgent(**config)
        ]
        
        for agent in agents:
            assert len(agent.functions) == 1
            assert agent.initial_context["config"] == "value"
            assert agent.concurrent[Stage.PERCEIVE] is True
            assert agent.workflow_id == "test_workflow"


class TestAgentEdgeCases:
    """Test edge cases for agent implementations."""
    
    def test_agent_with_no_functions(self):
        """Test agent execution with no functions."""
        agent = SimpleSyncAgent(functions=[])
        
        result = agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        # Input data is wrapped in "input" key by the spine
        assert result.get("input") == {"input": "test"}
    
    @pytest.mark.asyncio
    async def test_async_agent_with_no_functions(self):
        """Test async agent execution with no functions."""
        agent = SimpleAsyncAgent(functions=[])
        
        result = await agent.execute({"input": "test"})
        
        assert isinstance(result, Context)
        # Input data is wrapped in "input" key by the spine
        assert result.get("input") == {"input": "test"}
    
    def test_agent_with_none_input(self):
        """Test agent execution with None input."""
        @perceive
        def perceive_func(ctx): 
            return {"input_was_none": ctx.get("input") is None}
        
        agent = SimpleSyncAgent(functions=[perceive_func])
        
        result = agent.execute(None)
        
        assert result.get("input_was_none") is True
    
    def test_agent_workflow_id_default(self):
        """Test agent with default workflow ID."""
        agent = SimpleSyncAgent()
        
        # Should have a default workflow ID
        assert agent.workflow_id is not None
        assert isinstance(agent.workflow_id, str)
        assert agent.workflow_id.startswith("simple_sync_")
    
    def test_agent_concurrent_config_default(self):
        """Test agent with default concurrent configuration."""
        agent = SimpleSyncAgent()
        
        # Should have default concurrent config (all False)
        assert isinstance(agent.concurrent, dict)
        for stage in Stage:
            assert agent.concurrent.get(stage, False) is False