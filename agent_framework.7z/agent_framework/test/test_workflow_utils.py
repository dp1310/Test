"""Comprehensive tests for workflow_utils module."""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from typing import Dict, Any, List
import uuid

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from agent_sdk.core.execution.workflow_utils import (
    generate_workflow_id,
    initialize_context,
    execute_workflow_stages,
    execute_async_workflow_stages,
    handle_workflow_execution,
    handle_async_workflow_execution,
    execute_prefect_stage,
    execute_async_prefect_stage
)
from agent_sdk.core.stages import Stage, perceive, reason, plan, act, review, learn
from agent_sdk.core.context import Context


class TestGenerateWorkflowId:
    """Test workflow ID generation."""
    
    def test_generate_workflow_id_format(self):
        """Test that workflow ID has correct format."""
        workflow_id = generate_workflow_id("test")
        
        assert workflow_id.startswith("test_")
        assert len(workflow_id) == len("test_") + 8  # prefix + 8 hex chars
    
    def test_generate_workflow_id_uniqueness(self):
        """Test that generated IDs are unique."""
        id1 = generate_workflow_id("test")
        id2 = generate_workflow_id("test")
        
        assert id1 != id2
    
    def test_generate_workflow_id_different_prefixes(self):
        """Test workflow ID generation with different prefixes."""
        id1 = generate_workflow_id("sync")
        id2 = generate_workflow_id("async")
        
        assert id1.startswith("sync_")
        assert id2.startswith("async_")


class TestInitializeContext:
    """Test context initialization."""
    
    def test_initialize_context_basic(self):
        """Test basic context initialization."""
        result = initialize_context("test_input")
        
        assert result == {"input": "test_input"}
    
    def test_initialize_context_with_dict_input(self):
        """Test context initialization with dict input."""
        input_data = {"key": "value"}
        result = initialize_context(input_data)
        
        assert result == {"input": {"key": "value"}}
    
    def test_initialize_context_with_initial_context(self):
        """Test context initialization with initial context."""
        result = initialize_context("test_input", {"config": "value"})
        
        assert result == {"input": "test_input", "config": "value"}
    
    def test_initialize_context_with_none_initial_context(self):
        """Test context initialization with None initial context."""
        result = initialize_context("test_input", None)
        
        assert result == {"input": "test_input"}
    
    def test_initialize_context_preserves_initial_context(self):
        """Test that initial context is preserved."""
        initial = {"key1": "value1", "key2": "value2"}
        result = initialize_context("test_input", initial)
        
        assert result["input"] == "test_input"
        assert result["key1"] == "value1"
        assert result["key2"] == "value2"


class TestExecuteWorkflowStages:
    """Test workflow stage execution."""
    
    def test_execute_workflow_stages_all_stages(self):
        """Test execution of all 6 stages."""
        stage_map = {
            Stage.PERCEIVE: [lambda ctx: {"perceived": True}],
            Stage.REASON: [lambda ctx: {"reasoned": True}],
            Stage.PLAN: [lambda ctx: {"planned": True}],
            Stage.ACT: [lambda ctx: {"acted": True}],
            Stage.REVIEW: [lambda ctx: {"reviewed": True}],
            Stage.LEARN: [lambda ctx: {"learned": True}]
        }
        
        ctx_data = {"input": "test"}
        concurrent_settings = {}
        workflow_id = "test_workflow"
        
        call_count = {"count": 0}
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            call_count["count"] += 1
            return ctx
        
        result = execute_workflow_stages(
            stage_map, ctx_data, concurrent_settings, workflow_id, mock_executor
        )
        
        # Should execute all 6 stages
        assert call_count["count"] == 6
    
    def test_execute_workflow_stages_partial_stages(self):
        """Test execution with only some stages defined."""
        stage_map = {
            Stage.PERCEIVE: [lambda ctx: {"perceived": True}],
            Stage.ACT: [lambda ctx: {"acted": True}],
            Stage.LEARN: [lambda ctx: {"learned": True}]
        }
        
        ctx_data = {"input": "test"}
        concurrent_settings = {}
        workflow_id = "test_workflow"
        
        executed_stages = []
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            executed_stages.append(stage)
            return ctx
        
        result = execute_workflow_stages(
            stage_map, ctx_data, concurrent_settings, workflow_id, mock_executor
        )
        
        # Should only execute stages that have functions
        assert len(executed_stages) == 3
        assert Stage.PERCEIVE in executed_stages
        assert Stage.ACT in executed_stages
        assert Stage.LEARN in executed_stages
    
    def test_execute_workflow_stages_empty_stage_map(self):
        """Test execution with empty stage map."""
        stage_map = {}
        ctx_data = {"input": "test"}
        concurrent_settings = {}
        workflow_id = "test_workflow"
        
        call_count = {"count": 0}
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            call_count["count"] += 1
            return ctx
        
        result = execute_workflow_stages(
            stage_map, ctx_data, concurrent_settings, workflow_id, mock_executor
        )
        
        # Should not execute any stages
        assert call_count["count"] == 0
        assert result == ctx_data
    
    def test_execute_workflow_stages_context_flow(self):
        """Test that context flows through stages correctly."""
        stage_map = {
            Stage.PERCEIVE: [lambda ctx: ctx],
            Stage.REASON: [lambda ctx: ctx],
            Stage.REVIEW: [lambda ctx: ctx]
        }
        
        ctx_data = {"input": "test", "value": 1}
        concurrent_settings = {}
        workflow_id = "test_workflow"
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            # Modify context to track flow
            if isinstance(ctx, dict):
                ctx["value"] = ctx.get("value", 0) + 1
            return ctx
        
        result = execute_workflow_stages(
            stage_map, ctx_data, concurrent_settings, workflow_id, mock_executor
        )
        
        # Value should be incremented for each stage
        assert result["value"] == 4  # 1 + 3 stages
    
    def test_execute_workflow_stages_concurrent_settings(self):
        """Test that concurrent settings are passed correctly."""
        stage_map = {
            Stage.PERCEIVE: [lambda ctx: ctx],
            Stage.REVIEW: [lambda ctx: ctx]
        }
        
        ctx_data = {"input": "test"}
        concurrent_settings = {
            Stage.PERCEIVE: True,
            Stage.REVIEW: False
        }
        workflow_id = "test_workflow"
        
        received_settings = {}
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            received_settings[stage] = concurrent
            return ctx
        
        execute_workflow_stages(
            stage_map, ctx_data, concurrent_settings, workflow_id, mock_executor
        )
        
        assert received_settings[Stage.PERCEIVE] is True
        assert received_settings[Stage.REVIEW] is False


class TestExecuteAsyncWorkflowStages:
    """Test async workflow stage execution."""
    
    @pytest.mark.asyncio
    async def test_execute_async_workflow_stages_all_stages(self):
        """Test async execution of all 6 stages."""
        stage_map = {
            Stage.PERCEIVE: [lambda ctx: {"perceived": True}],
            Stage.REASON: [lambda ctx: {"reasoned": True}],
            Stage.PLAN: [lambda ctx: {"planned": True}],
            Stage.ACT: [lambda ctx: {"acted": True}],
            Stage.REVIEW: [lambda ctx: {"reviewed": True}],
            Stage.LEARN: [lambda ctx: {"learned": True}]
        }
        
        ctx = Context({"input": "test"})
        concurrent_settings = {}
        workflow_id = "test_workflow"
        
        call_count = {"count": 0}
        
        async def mock_executor(functions, ctx, concurrent, stage, wf_id):
            call_count["count"] += 1
            return ctx
        
        result = await execute_async_workflow_stages(
            stage_map, ctx, concurrent_settings, workflow_id, mock_executor
        )
        
        # Should execute all 6 stages
        assert call_count["count"] == 6
    
    @pytest.mark.asyncio
    async def test_execute_async_workflow_stages_context_flow(self):
        """Test that context flows through async stages correctly."""
        stage_map = {
            Stage.PERCEIVE: [lambda ctx: ctx],
            Stage.ACT: [lambda ctx: ctx],
            Stage.LEARN: [lambda ctx: ctx]
        }
        
        ctx = Context({"input": "test", "counter": 0})
        concurrent_settings = {}
        workflow_id = "test_workflow"
        
        async def mock_executor(functions, ctx, concurrent, stage, wf_id):
            # Increment counter
            new_data = ctx.data.copy()
            new_data["counter"] = new_data.get("counter", 0) + 1
            return Context(data=new_data)
        
        result = await execute_async_workflow_stages(
            stage_map, ctx, concurrent_settings, workflow_id, mock_executor
        )
        
        # Counter should be incremented for each stage
        assert result.get("counter") == 3



class TestHandleWorkflowExecution:
    """Test workflow execution handling."""
    
    def test_handle_workflow_execution_success(self):
        """Test successful workflow execution."""
        workflow_id = "test_workflow"
        
        def execution_func():
            return {"result": "success"}
        
        with patch('agent_sdk.core.execution.workflow_utils.get_state_manager') as mock_state:
            mock_manager = Mock()
            mock_state.return_value = mock_manager
            
            result = handle_workflow_execution(workflow_id, execution_func)
            
            assert result == {"result": "success"}
            mock_manager.start_workflow.assert_called_once_with(workflow_id)
            mock_manager.complete_workflow.assert_called_once_with(workflow_id)
            mock_manager.error_workflow.assert_not_called()
    
    def test_handle_workflow_execution_with_exception(self):
        """Test workflow execution with exception."""
        workflow_id = "test_workflow"
        
        def execution_func():
            raise ValueError("Test error")
        
        with patch('agent_sdk.core.execution.workflow_utils.get_state_manager') as mock_state:
            mock_manager = Mock()
            mock_state.return_value = mock_manager
            
            with pytest.raises(ValueError, match="Test error"):
                handle_workflow_execution(workflow_id, execution_func)
            
            mock_manager.start_workflow.assert_called_once_with(workflow_id)
            mock_manager.complete_workflow.assert_not_called()
            mock_manager.error_workflow.assert_called_once()
    
    def test_handle_workflow_execution_with_args(self):
        """Test workflow execution with arguments."""
        workflow_id = "test_workflow"
        
        def execution_func(arg1, arg2, kwarg1=None):
            return {"arg1": arg1, "arg2": arg2, "kwarg1": kwarg1}
        
        with patch('agent_sdk.core.execution.workflow_utils.get_state_manager') as mock_state:
            mock_manager = Mock()
            mock_state.return_value = mock_manager
            
            result = handle_workflow_execution(
                workflow_id, execution_func, "value1", "value2", kwarg1="kwvalue"
            )
            
            assert result == {"arg1": "value1", "arg2": "value2", "kwarg1": "kwvalue"}


class TestHandleAsyncWorkflowExecution:
    """Test async workflow execution handling."""
    
    @pytest.mark.asyncio
    async def test_handle_async_workflow_execution_success(self):
        """Test successful async workflow execution."""
        workflow_id = "test_workflow"
        
        async def execution_func():
            await asyncio.sleep(0.01)
            return {"result": "async_success"}
        
        with patch('agent_sdk.core.execution.workflow_utils.get_state_manager') as mock_state:
            mock_manager = Mock()
            mock_state.return_value = mock_manager
            
            result = await handle_async_workflow_execution(workflow_id, execution_func)
            
            assert result == {"result": "async_success"}
            mock_manager.start_workflow.assert_called_once_with(workflow_id)
            mock_manager.complete_workflow.assert_called_once_with(workflow_id)
    
    @pytest.mark.asyncio
    async def test_handle_async_workflow_execution_with_exception(self):
        """Test async workflow execution with exception."""
        workflow_id = "test_workflow"
        
        async def execution_func():
            await asyncio.sleep(0.01)
            raise RuntimeError("Async test error")
        
        with patch('agent_sdk.core.execution.workflow_utils.get_state_manager') as mock_state:
            mock_manager = Mock()
            mock_state.return_value = mock_manager
            
            with pytest.raises(RuntimeError, match="Async test error"):
                await handle_async_workflow_execution(workflow_id, execution_func)
            
            mock_manager.start_workflow.assert_called_once_with(workflow_id)
            mock_manager.complete_workflow.assert_not_called()
            mock_manager.error_workflow.assert_called_once()


class TestExecutePrefectStage:
    """Test Prefect stage execution."""
    
    def test_execute_prefect_stage_sequential(self):
        """Test sequential Prefect stage execution."""
        def func1(ctx): return {"result1": "value1"}
        def func2(ctx): return {"result2": "value2"}
        
        stage_functions = [func1, func2]
        ctx_dict = {"input": "test"}
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.workflow_utils.PrefectExecutor') as mock_executor:
            mock_executor.execute_sequential_monitored.return_value = [
                {"result1": "value1"},
                {"result2": "value2"}
            ]
            
            result = execute_prefect_stage(
                stage_functions, ctx_dict, False, Stage.PERCEIVE, workflow_id
            )
            
            assert result["input"] == "test"
            assert result["result1"] == "value1"
            assert result["result2"] == "value2"
            mock_executor.execute_sequential_monitored.assert_called_once()
    
    def test_execute_prefect_stage_concurrent(self):
        """Test concurrent Prefect stage execution."""
        def func1(ctx): return {"result1": "value1"}
        def func2(ctx): return {"result2": "value2"}
        
        stage_functions = [func1, func2]
        ctx_dict = {"input": "test"}
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.workflow_utils.PrefectExecutor') as mock_executor:
            mock_executor.execute_concurrent_monitored.return_value = [
                {"result1": "value1"},
                {"result2": "value2"}
            ]
            
            result = execute_prefect_stage(
                stage_functions, ctx_dict, True, Stage.REVIEW, workflow_id
            )
            
            assert result["input"] == "test"
            assert result["result1"] == "value1"
            assert result["result2"] == "value2"
            mock_executor.execute_concurrent_monitored.assert_called_once()


class TestExecuteAsyncPrefectStage:
    """Test async Prefect stage execution."""
    
    @pytest.mark.asyncio
    async def test_execute_async_prefect_stage_sequential(self):
        """Test sequential async Prefect stage execution."""
        async def func1(ctx): return {"result1": "async_value1"}
        async def func2(ctx): return {"result2": "async_value2"}
        
        stage_functions = [func1, func2]
        ctx_dict = {"input": "test"}
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.workflow_utils.PrefectExecutor') as mock_executor_class:
            # Create an async mock that returns the expected value
            async_mock = AsyncMock(return_value=[
                {"result1": "async_value1"},
                {"result2": "async_value2"}
            ])
            mock_executor_class.execute_async_tasks_monitored = async_mock
            
            result = await execute_async_prefect_stage(
                stage_functions, ctx_dict, False, Stage.LEARN, workflow_id
            )
            
            assert result["input"] == "test"
            assert result["result1"] == "async_value1"
            assert result["result2"] == "async_value2"
    
    @pytest.mark.asyncio
    async def test_execute_async_prefect_stage_concurrent(self):
        """Test concurrent async Prefect stage execution."""
        async def func1(ctx): return {"result1": "async_value1"}
        async def func2(ctx): return {"result2": "async_value2"}
        
        stage_functions = [func1, func2]
        ctx_dict = {"input": "test"}
        workflow_id = "test_workflow"
        
        with patch('agent_sdk.core.execution.workflow_utils.PrefectExecutor') as mock_executor_class:
            # Create an async mock that returns the expected value
            async_mock = AsyncMock(return_value=[
                {"result1": "async_value1"},
                {"result2": "async_value2"}
            ])
            mock_executor_class.execute_concurrent_async_tasks_monitored = async_mock
            
            result = await execute_async_prefect_stage(
                stage_functions, ctx_dict, True, Stage.REVIEW, workflow_id
            )
            
            assert result["input"] == "test"
            assert result["result1"] == "async_value1"
            assert result["result2"] == "async_value2"
            async_mock.assert_called_once()


class TestStageOrder:
    """Test that stages execute in correct order."""
    
    def test_stage_execution_order(self):
        """Test that all 6 stages execute in correct order."""
        execution_order = []
        
        stage_map = {
            Stage.LEARN: [lambda ctx: ctx],
            Stage.PERCEIVE: [lambda ctx: ctx],
            Stage.REVIEW: [lambda ctx: ctx],
            Stage.ACT: [lambda ctx: ctx],
            Stage.REASON: [lambda ctx: ctx],
            Stage.PLAN: [lambda ctx: ctx]
        }
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            execution_order.append(stage)
            return ctx
        
        execute_workflow_stages(
            stage_map, {"input": "test"}, {}, "test_workflow", mock_executor
        )
        
        # Verify correct order
        expected_order = [
            Stage.PERCEIVE,
            Stage.REASON,
            Stage.PLAN,
            Stage.ACT,
            Stage.REVIEW,
            Stage.LEARN
        ]
        
        assert execution_order == expected_order
    
    @pytest.mark.asyncio
    async def test_async_stage_execution_order(self):
        """Test that async stages execute in correct order."""
        execution_order = []
        
        stage_map = {
            Stage.LEARN: [lambda ctx: ctx],
            Stage.PERCEIVE: [lambda ctx: ctx],
            Stage.REVIEW: [lambda ctx: ctx],
            Stage.ACT: [lambda ctx: ctx],
            Stage.REASON: [lambda ctx: ctx],
            Stage.PLAN: [lambda ctx: ctx]
        }
        
        async def mock_executor(functions, ctx, concurrent, stage, wf_id):
            execution_order.append(stage)
            return ctx
        
        await execute_async_workflow_stages(
            stage_map, Context({"input": "test"}), {}, "test_workflow", mock_executor
        )
        
        # Verify correct order
        expected_order = [
            Stage.PERCEIVE,
            Stage.REASON,
            Stage.PLAN,
            Stage.ACT,
            Stage.REVIEW,
            Stage.LEARN
        ]
        
        assert execution_order == expected_order


class TestReviewLearnStages:
    """Test REVIEW and LEARN stages specifically."""
    
    def test_review_stage_execution(self):
        """Test REVIEW stage execution."""
        @review
        def review_func(ctx):
            return {"review_result": "passed"}
        
        stage_map = {Stage.REVIEW: [review_func]}
        
        executed = {"review": False}
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            if stage == Stage.REVIEW:
                executed["review"] = True
            return ctx
        
        execute_workflow_stages(
            stage_map, {"input": "test"}, {}, "test_workflow", mock_executor
        )
        
        assert executed["review"] is True
    
    def test_learn_stage_execution(self):
        """Test LEARN stage execution."""
        @learn
        def learn_func(ctx):
            return {"learned": "pattern"}
        
        stage_map = {Stage.LEARN: [learn_func]}
        
        executed = {"learn": False}
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            if stage == Stage.LEARN:
                executed["learn"] = True
            return ctx
        
        execute_workflow_stages(
            stage_map, {"input": "test"}, {}, "test_workflow", mock_executor
        )
        
        assert executed["learn"] is True
    
    def test_review_learn_together(self):
        """Test REVIEW and LEARN stages working together."""
        @review
        def review_func(ctx):
            return {"quality_score": 0.85}
        
        @learn
        def learn_func(ctx):
            quality = ctx.get("quality_score", 0.0)
            return {"learned_from_quality": quality > 0.8}
        
        stage_map = {
            Stage.REVIEW: [review_func],
            Stage.LEARN: [learn_func]
        }
        
        results = []
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            if stage == Stage.REVIEW:
                ctx["quality_score"] = 0.85
            elif stage == Stage.LEARN:
                ctx["learned_from_quality"] = ctx.get("quality_score", 0.0) > 0.8
            results.append(stage)
            return ctx
        
        final_ctx = execute_workflow_stages(
            stage_map, {"input": "test"}, {}, "test_workflow", mock_executor
        )
        
        # REVIEW should execute before LEARN
        assert results.index(Stage.REVIEW) < results.index(Stage.LEARN)
    
    @pytest.mark.asyncio
    async def test_async_review_learn_stages(self):
        """Test async REVIEW and LEARN stages."""
        @review
        async def async_review(ctx):
            await asyncio.sleep(0.01)
            return {"review_status": "completed"}
        
        @learn
        async def async_learn(ctx):
            await asyncio.sleep(0.01)
            return {"learning_status": "completed"}
        
        stage_map = {
            Stage.REVIEW: [async_review],
            Stage.LEARN: [async_learn]
        }
        
        executed_stages = []
        
        async def mock_executor(functions, ctx, concurrent, stage, wf_id):
            executed_stages.append(stage)
            return ctx
        
        await execute_async_workflow_stages(
            stage_map, Context({"input": "test"}), {}, "test_workflow", mock_executor
        )
        
        assert Stage.REVIEW in executed_stages
        assert Stage.LEARN in executed_stages
        assert executed_stages.index(Stage.REVIEW) < executed_stages.index(Stage.LEARN)


class TestEdgeCases:
    """Test edge cases and error conditions."""
    
    def test_empty_functions_list(self):
        """Test execution with empty functions list."""
        stage_map = {Stage.PERCEIVE: []}
        
        call_count = {"count": 0}
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            call_count["count"] += 1
            return ctx
        
        result = execute_workflow_stages(
            stage_map, {"input": "test"}, {}, "test_workflow", mock_executor
        )
        
        # Empty function list means stage is skipped
        assert call_count["count"] == 0
    
    def test_none_context(self):
        """Test handling of None context values."""
        ctx_dict = {"input": None, "value": None}
        
        result = initialize_context(None, ctx_dict)
        
        assert result["input"] is None
        assert result["value"] is None
    
    def test_workflow_id_in_executor_calls(self):
        """Test that workflow_id is passed to executor."""
        stage_map = {Stage.PERCEIVE: [lambda ctx: ctx]}
        workflow_id = "specific_workflow_123"
        
        received_ids = []
        
        def mock_executor(functions, ctx, concurrent, stage, wf_id):
            received_ids.append(wf_id)
            return ctx
        
        execute_workflow_stages(
            stage_map, {"input": "test"}, {}, workflow_id, mock_executor
        )
        
        assert all(wf_id == workflow_id for wf_id in received_ids)


class TestIntegration:
    """Integration tests combining multiple components."""
    
    def test_full_workflow_all_stages(self):
        """Test full workflow with all 6 stages."""
        @perceive
        def perceive_func(ctx): return {"perceived": True}
        
        @reason
        def reason_func(ctx): return {"reasoned": True}
        
        @plan
        def plan_func(ctx): return {"planned": True}
        
        @act
        def act_func(ctx): return {"acted": True}
        
        @review
        def review_func(ctx): return {"reviewed": True}
        
        @learn
        def learn_func(ctx): return {"learned": True}
        
        from agent_sdk.core.execution.function_utils import collect_functions
        
        functions = [perceive_func, reason_func, plan_func, act_func, review_func, learn_func]
        stage_map = collect_functions(functions)
        
        # Verify all stages are present
        assert Stage.PERCEIVE in stage_map
        assert Stage.REASON in stage_map
        assert Stage.PLAN in stage_map
        assert Stage.ACT in stage_map
        assert Stage.REVIEW in stage_map
        assert Stage.LEARN in stage_map
