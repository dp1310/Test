"""Tests for tools base classes and functionality."""

import pytest
import asyncio
import time
from typing import Dict, Any
from unittest.mock import Mock, patch, AsyncMock

from agent_sdk.tools.base import (
    ToolStatus, ToolResult, ToolError, Tool, ToolRegistry, get_tool_registry
)


class TestToolStatus:
    """Test ToolStatus enumeration."""
    
    def test_tool_status_values(self):
        """Test that all expected tool statuses exist."""
        assert ToolStatus.PENDING
        assert ToolStatus.RUNNING
        assert ToolStatus.SUCCESS
        assert ToolStatus.ERROR
        assert ToolStatus.TIMEOUT
        assert ToolStatus.CANCELLED
        
        # Test string values
        assert ToolStatus.PENDING.value == "pending"
        assert ToolStatus.RUNNING.value == "running"
        assert ToolStatus.SUCCESS.value == "success"
        assert ToolStatus.ERROR.value == "error"
        assert ToolStatus.TIMEOUT.value == "timeout"
        assert ToolStatus.CANCELLED.value == "cancelled"


class TestToolResult:
    """Test ToolResult dataclass."""
    
    def test_tool_result_creation(self):
        """Test creating ToolResult instance."""
        result = ToolResult(
            tool_name="test_tool",
            status=ToolStatus.SUCCESS,
            data={"key": "value"},
            execution_time=1.5
        )
        
        assert result.tool_name == "test_tool"
        assert result.status == ToolStatus.SUCCESS
        assert result.data == {"key": "value"}
        assert result.error is None
        assert result.execution_time == 1.5
        assert result.metadata == {}
    
    def test_tool_result_is_success(self):
        """Test is_success property."""
        success_result = ToolResult("tool", ToolStatus.SUCCESS)
        assert success_result.is_success is True
        
        error_result = ToolResult("tool", ToolStatus.ERROR)
        assert error_result.is_success is False
        
        pending_result = ToolResult("tool", ToolStatus.PENDING)
        assert pending_result.is_success is False
    
    def test_tool_result_is_error(self):
        """Test is_error property."""
        error_result = ToolResult("tool", ToolStatus.ERROR)
        assert error_result.is_error is True
        
        success_result = ToolResult("tool", ToolStatus.SUCCESS)
        assert success_result.is_error is False
        
        timeout_result = ToolResult("tool", ToolStatus.TIMEOUT)
        assert timeout_result.is_error is False
    
    def test_tool_result_to_dict(self):
        """Test converting ToolResult to dictionary."""
        error = ValueError("Test error")
        result = ToolResult(
            tool_name="test_tool",
            status=ToolStatus.ERROR,
            data={"result": "data"},
            error=error,
            execution_time=2.5,
            metadata={"key": "value"}
        )
        
        result_dict = result.to_dict()
        
        assert result_dict["tool_name"] == "test_tool"
        assert result_dict["status"] == "error"
        assert result_dict["data"] == {"result": "data"}
        assert result_dict["error"] == "Test error"
        assert result_dict["execution_time"] == 2.5
        assert result_dict["metadata"] == {"key": "value"}
    
    def test_tool_result_to_dict_no_error(self):
        """Test to_dict with no error."""
        result = ToolResult("tool", ToolStatus.SUCCESS, data="success")
        result_dict = result.to_dict()
        
        assert result_dict["error"] is None


class TestToolError:
    """Test ToolError exception class."""
    
    def test_tool_error_creation(self):
        """Test creating ToolError."""
        error = ToolError("Test message")
        
        assert str(error) == "Test message"
        assert error.tool_name is None
        assert error.original_error is None
    
    def test_tool_error_with_tool_name(self):
        """Test ToolError with tool name."""
        error = ToolError("Test message", tool_name="test_tool")
        
        assert str(error) == "Test message"
        assert error.tool_name == "test_tool"
        assert error.original_error is None
    
    def test_tool_error_with_original_error(self):
        """Test ToolError with original error."""
        original = ValueError("Original error")
        error = ToolError("Wrapper message", tool_name="test_tool", original_error=original)
        
        assert str(error) == "Wrapper message"
        assert error.tool_name == "test_tool"
        assert error.original_error == original
    
    def test_tool_error_inheritance(self):
        """Test that ToolError inherits from Exception."""
        error = ToolError("Test")
        assert isinstance(error, Exception)
        
        # Should be raisable
        with pytest.raises(ToolError, match="Test"):
            raise error


class MockTool(Tool):
    """Mock tool for testing."""
    
    def __init__(self, name: str, config: Dict[str, Any] = None, should_fail: bool = False):
        super().__init__(name, config)
        self.should_fail = should_fail
        self.execute_calls = []
    
    async def execute(self, **kwargs) -> ToolResult:
        self.execute_calls.append(kwargs)
        
        if self.should_fail:
            raise ValueError("Mock tool failure")
        
        return ToolResult(
            tool_name=self.name,
            status=ToolStatus.SUCCESS,
            data={"mock": True, "kwargs": kwargs}
        )


class TestTool:
    """Test Tool base class."""
    
    def test_tool_creation(self):
        """Test creating Tool instance."""
        config = {
            "enabled": True,
            "timeout": 60,
            "retry_count": 5,
            "retry_delay": 2.0
        }
        
        tool = MockTool("test_tool", config)
        
        assert tool.name == "test_tool"
        assert tool.config == config
        assert tool.enabled is True
        assert tool.timeout == 60
        assert tool.retry_count == 5
        assert tool.retry_delay == 2.0
    
    def test_tool_default_config(self):
        """Test Tool with default configuration."""
        tool = MockTool("test_tool")
        
        assert tool.name == "test_tool"
        assert tool.config == {}
        assert tool.enabled is True  # Default
        assert tool.timeout == 30.0  # Default
        assert tool.retry_count == 3  # Default
        assert tool.retry_delay == 1.0  # Default
    
    @pytest.mark.asyncio
    async def test_tool_execute_success(self):
        """Test successful tool execution."""
        tool = MockTool("test_tool")
        
        result = await tool.execute(param1="value1", param2="value2")
        
        assert result.tool_name == "test_tool"
        assert result.status == ToolStatus.SUCCESS
        assert result.data["mock"] is True
        assert result.data["kwargs"] == {"param1": "value1", "param2": "value2"}
        assert len(tool.execute_calls) == 1
    
    def test_tool_execute_sync(self):
        """Test synchronous tool execution wrapper."""
        tool = MockTool("test_tool")
        
        result = tool.execute_sync(param="value")
        
        assert result.tool_name == "test_tool"
        assert result.status == ToolStatus.SUCCESS
        assert result.data["kwargs"] == {"param": "value"}
    
    @pytest.mark.asyncio
    async def test_tool_execute_with_retry_success(self):
        """Test _execute_with_retry with successful execution."""
        tool = MockTool("test_tool")
        
        result = await tool._execute_with_retry(test_param="test_value")
        
        assert result.status == ToolStatus.SUCCESS
        assert result.execution_time > 0
        assert len(tool.execute_calls) == 1
    
    @pytest.mark.asyncio
    async def test_tool_execute_with_retry_failure(self):
        """Test _execute_with_retry with failure and retries."""
        tool = MockTool("test_tool", config={"retry_count": 2, "retry_delay": 0.01}, should_fail=True)
        
        result = await tool._execute_with_retry(test_param="test_value")
        
        assert result.status == ToolStatus.ERROR
        assert result.error is not None
        assert isinstance(result.error, ToolError)
        assert "failed after retries" in str(result.error)
        assert len(tool.execute_calls) == 3  # Initial + 2 retries
    
    @pytest.mark.asyncio
    async def test_tool_execute_with_timeout(self):
        """Test tool execution with timeout."""
        class SlowTool(Tool):
            async def execute(self, **kwargs) -> ToolResult:
                await asyncio.sleep(2.0)  # Longer than timeout
                return ToolResult(self.name, ToolStatus.SUCCESS)
        
        tool = SlowTool("slow_tool", config={"timeout": 0.1})
        
        result = await tool._execute_with_retry()
        
        assert result.status == ToolStatus.TIMEOUT
        assert result.error is not None
        assert "timed out" in str(result.error)
        assert result.execution_time == pytest.approx(0.1, rel=0.1)
    
    def test_tool_validate_config(self):
        """Test tool configuration validation."""
        tool = MockTool("test_tool")
        
        # Default implementation should return True
        assert tool.validate_config() is True
    
    def test_tool_get_schema(self):
        """Test tool schema generation."""
        tool = MockTool("test_tool")
        
        schema = tool.get_schema()
        
        assert schema["name"] == "test_tool"
        assert "description" in schema
        assert "parameters" in schema
        assert "required" in schema
        assert "examples" in schema


class TestToolRegistry:
    """Test ToolRegistry class."""
    
    def test_tool_registry_creation(self):
        """Test creating ToolRegistry."""
        registry = ToolRegistry()
        
        assert registry._tools == {}
        assert registry._categories == {}
    
    def test_tool_registry_register_tool(self):
        """Test registering a tool."""
        registry = ToolRegistry()
        tool = MockTool("test_tool")
        
        registry.register(tool, "test_category")
        
        assert "test_tool" in registry._tools
        assert registry._tools["test_tool"] == tool
        assert "test_category" in registry._categories
        assert "test_tool" in registry._categories["test_category"]
    
    def test_tool_registry_register_disabled_tool(self):
        """Test registering a disabled tool."""
        registry = ToolRegistry()
        tool = MockTool("disabled_tool", config={"enabled": False})
        
        with patch('agent_sdk.tools.base.logger') as mock_logger:
            registry.register(tool, "test_category")
            mock_logger.info.assert_called_with("Tool disabled_tool is disabled, skipping registration")
        
        assert "disabled_tool" not in registry._tools
        assert "test_category" not in registry._categories
    
    def test_tool_registry_register_invalid_config_tool(self):
        """Test registering a tool with invalid configuration."""
        class InvalidTool(MockTool):
            def validate_config(self) -> bool:
                return False
        
        registry = ToolRegistry()
        tool = InvalidTool("invalid_tool")
        
        with patch('agent_sdk.tools.base.logger') as mock_logger:
            registry.register(tool, "test_category")
            mock_logger.error.assert_called_with("Tool invalid_tool has invalid configuration, skipping registration")
        
        assert "invalid_tool" not in registry._tools
    
    def test_tool_registry_unregister_tool(self):
        """Test unregistering a tool."""
        registry = ToolRegistry()
        tool = MockTool("test_tool")
        
        # Register first
        registry.register(tool, "test_category")
        assert "test_tool" in registry._tools
        
        # Then unregister
        registry.unregister("test_tool")
        
        assert "test_tool" not in registry._tools
        assert "test_tool" not in registry._categories["test_category"]
    
    def test_tool_registry_unregister_nonexistent_tool(self):
        """Test unregistering a non-existent tool."""
        registry = ToolRegistry()
        
        # Should not raise an exception
        registry.unregister("nonexistent_tool")
    
    def test_tool_registry_get_tool(self):
        """Test getting a tool from registry."""
        registry = ToolRegistry()
        tool = MockTool("test_tool")
        
        registry.register(tool, "test_category")
        
        retrieved_tool = registry.get_tool("test_tool")
        assert retrieved_tool == tool
        
        missing_tool = registry.get_tool("missing_tool")
        assert missing_tool is None
    
    def test_tool_registry_list_tools(self):
        """Test listing tools."""
        registry = ToolRegistry()
        tool1 = MockTool("tool1")
        tool2 = MockTool("tool2")
        tool3 = MockTool("tool3")
        
        registry.register(tool1, "category1")
        registry.register(tool2, "category1")
        registry.register(tool3, "category2")
        
        # List all tools
        all_tools = registry.list_tools()
        assert set(all_tools) == {"tool1", "tool2", "tool3"}
        
        # List tools by category
        category1_tools = registry.list_tools("category1")
        assert set(category1_tools) == {"tool1", "tool2"}
        
        category2_tools = registry.list_tools("category2")
        assert set(category2_tools) == {"tool3"}
        
        # List tools from non-existent category
        empty_tools = registry.list_tools("nonexistent")
        assert empty_tools == []
    
    def test_tool_registry_list_categories(self):
        """Test listing categories."""
        registry = ToolRegistry()
        tool1 = MockTool("tool1")
        tool2 = MockTool("tool2")
        
        registry.register(tool1, "category1")
        registry.register(tool2, "category2")
        
        categories = registry.list_categories()
        assert set(categories) == {"category1", "category2"}
    
    def test_tool_registry_get_tools_by_category(self):
        """Test getting tools by category."""
        registry = ToolRegistry()
        tool1 = MockTool("tool1")
        tool2 = MockTool("tool2")
        tool3 = MockTool("tool3")
        
        registry.register(tool1, "category1")
        registry.register(tool2, "category1")
        registry.register(tool3, "category2")
        
        category1_tools = registry.get_tools_by_category("category1")
        assert len(category1_tools) == 2
        assert tool1 in category1_tools
        assert tool2 in category1_tools
        
        category2_tools = registry.get_tools_by_category("category2")
        assert len(category2_tools) == 1
        assert tool3 in category2_tools
        
        empty_tools = registry.get_tools_by_category("nonexistent")
        assert empty_tools == []
    
    @pytest.mark.asyncio
    async def test_tool_registry_execute_tool(self):
        """Test executing a tool through registry."""
        registry = ToolRegistry()
        tool = MockTool("test_tool")
        
        registry.register(tool, "test_category")
        
        result = await registry.execute_tool("test_tool", param1="value1")
        
        assert result.status == ToolStatus.SUCCESS
        assert result.tool_name == "test_tool"
        assert len(tool.execute_calls) == 1
        assert tool.execute_calls[0] == {"param1": "value1"}
    
    @pytest.mark.asyncio
    async def test_tool_registry_execute_nonexistent_tool(self):
        """Test executing a non-existent tool."""
        registry = ToolRegistry()
        
        result = await registry.execute_tool("nonexistent_tool", param="value")
        
        assert result.status == ToolStatus.ERROR
        assert result.tool_name == "nonexistent_tool"
        assert isinstance(result.error, ToolError)
        assert "not found" in str(result.error)
    
    def test_tool_registry_get_schema(self):
        """Test getting registry schema."""
        registry = ToolRegistry()
        tool1 = MockTool("tool1")
        tool2 = MockTool("tool2")
        
        registry.register(tool1, "category1")
        registry.register(tool2, "category2")
        
        schema = registry.get_schema()
        
        assert "tools" in schema
        assert "categories" in schema
        assert "tool1" in schema["tools"]
        assert "tool2" in schema["tools"]
        assert schema["categories"]["category1"] == ["tool1"]
        assert schema["categories"]["category2"] == ["tool2"]


class TestGlobalToolRegistry:
    """Test global tool registry functionality."""
    
    def test_get_tool_registry_singleton(self):
        """Test that get_tool_registry returns singleton."""
        registry1 = get_tool_registry()
        registry2 = get_tool_registry()
        
        assert registry1 is registry2
        assert isinstance(registry1, ToolRegistry)
    
    def test_global_registry_persistence(self):
        """Test that global registry persists across calls."""
        registry = get_tool_registry()
        tool = MockTool("persistent_tool")
        
        registry.register(tool, "test_category")
        
        # Get registry again and check tool is still there
        registry2 = get_tool_registry()
        retrieved_tool = registry2.get_tool("persistent_tool")
        
        assert retrieved_tool == tool
        
        # Clean up
        registry.unregister("persistent_tool")


class TestToolEdgeCases:
    """Test edge cases for tool functionality."""
    
    @pytest.mark.asyncio
    async def test_tool_execute_with_no_params(self):
        """Test tool execution with no parameters."""
        tool = MockTool("test_tool")
        
        result = await tool.execute()
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data["kwargs"] == {}
    
    @pytest.mark.asyncio
    async def test_tool_execute_with_complex_params(self):
        """Test tool execution with complex parameters."""
        tool = MockTool("test_tool")
        
        complex_param = {
            "nested": {"key": "value"},
            "list": [1, 2, 3],
            "tuple": (4, 5, 6)
        }
        
        result = await tool.execute(complex=complex_param)
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data["kwargs"]["complex"] == complex_param
    
    def test_tool_with_custom_config_values(self):
        """Test tool with custom configuration values."""
        config = {
            "custom_key": "custom_value",
            "number": 42,
            "boolean": True,
            "list": [1, 2, 3]
        }
        
        tool = MockTool("custom_tool", config)
        
        assert tool.config["custom_key"] == "custom_value"
        assert tool.config["number"] == 42
        assert tool.config["boolean"] is True
        assert tool.config["list"] == [1, 2, 3]
    
    @pytest.mark.asyncio
    async def test_tool_retry_with_intermittent_failure(self):
        """Test tool retry with intermittent failures."""
        class IntermittentTool(Tool):
            def __init__(self, name, config=None):
                super().__init__(name, config)
                self.attempt_count = 0
            
            async def execute(self, **kwargs) -> ToolResult:
                self.attempt_count += 1
                if self.attempt_count < 3:  # Fail first 2 attempts
                    raise ValueError(f"Attempt {self.attempt_count} failed")
                
                return ToolResult(self.name, ToolStatus.SUCCESS, data={"attempts": self.attempt_count})
        
        tool = IntermittentTool("intermittent_tool", config={"retry_count": 3, "retry_delay": 0.01})
        
        result = await tool._execute_with_retry()
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data["attempts"] == 3
        assert tool.attempt_count == 3
    
    def test_tool_registry_multiple_categories(self):
        """Test registering same tool in multiple categories."""
        registry = ToolRegistry()
        tool = MockTool("multi_category_tool")
        
        # Register in first category
        registry.register(tool, "category1")
        
        # Register same tool in second category
        registry.register(tool, "category2")
        
        # Tool should appear in both categories
        assert "multi_category_tool" in registry.list_tools("category1")
        assert "multi_category_tool" in registry.list_tools("category2")
        
        # But should only exist once in the tools registry
        all_tools = registry.list_tools()
        assert all_tools.count("multi_category_tool") == 1
    
    def test_tool_registry_empty_category_name(self):
        """Test registering tool with empty category name."""
        registry = ToolRegistry()
        tool = MockTool("empty_category_tool")
        
        registry.register(tool, "")
        
        assert "empty_category_tool" in registry._tools
        assert "" in registry._categories
        assert "empty_category_tool" in registry._categories[""]