"""Tests for tools hooks system."""

import pytest
import asyncio
from typing import Dict, Any
from unittest.mock import Mock, patch, AsyncMock, MagicMock

from agent_sdk.tools.hooks import (
    ToolContext, tool_hook, execute_tool, get_available_tools, get_tool_schema,
    _ensure_tools_loaded, _register_basic_tools, _register_tools_from_config,
    _create_tool, _create_llm_tool, _create_database_tool, _create_api_tool, _create_utility_tool
)
from agent_sdk.tools.base import ToolResult, ToolStatus, ToolRegistry, Tool


class MockTool(Tool):
    """Mock tool for testing."""
    
    def __init__(self, name: str, config: Dict[str, Any] = None):
        super().__init__(name, config or {})
        self.execute_called = False
        self.execute_params = None
    
    async def execute(self, **kwargs) -> ToolResult:
        """Mock execute method."""
        self.execute_called = True
        self.execute_params = kwargs
        return ToolResult(
            tool_name=self.name,
            status=ToolStatus.SUCCESS,
            data={"mock": "result", "params": kwargs}
        )
    
    def get_schema(self) -> Dict[str, Any]:
        """Mock schema method."""
        return {
            "name": self.name,
            "type": "mock",
            "parameters": {
                "test_param": {"type": "string", "description": "Test parameter"}
            }
        }


class MockConfig:
    """Mock configuration object."""
    
    def __init__(self, name: str, tool_type: str, enabled: bool = True, category: str = "test"):
        self.name = name
        self.type = tool_type
        self.enabled = enabled
        self.category = category
        self.config = {"test": "config"}


class TestToolContext:
    """Test ToolContext functionality."""
    
    def test_tool_context_initialization(self):
        """Test ToolContext initialization."""
        # Test with default registry
        context = ToolContext()
        assert context.registry is not None
        assert isinstance(context._cache, dict)
        
        # Test with custom registry
        custom_registry = ToolRegistry()
        context = ToolContext(custom_registry)
        assert context.registry is custom_registry
    
    @pytest.mark.asyncio
    async def test_execute_tool(self):
        """Test tool execution through context."""
        registry = ToolRegistry()
        mock_tool = MockTool("test_tool")
        registry.register(mock_tool, "test")
        
        context = ToolContext(registry)
        result = await context.execute("test_tool", param1="value1", param2="value2")
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data["mock"] == "result"
        assert result.data["params"]["param1"] == "value1"
        assert mock_tool.execute_called
    
    def test_execute_sync(self):
        """Test synchronous tool execution."""
        registry = ToolRegistry()
        mock_tool = MockTool("test_tool")
        registry.register(mock_tool, "test")
        
        context = ToolContext(registry)
        result = context.execute_sync("test_tool", param1="value1")
        
        assert result.status == ToolStatus.SUCCESS
        assert result.data["params"]["param1"] == "value1"
        assert mock_tool.execute_called
    
    def test_get_available_tools(self):
        """Test getting available tools."""
        registry = ToolRegistry()
        mock_tool1 = MockTool("tool1")
        mock_tool2 = MockTool("tool2")
        registry.register(mock_tool1, "category1")
        registry.register(mock_tool2, "category2")
        
        context = ToolContext(registry)
        
        # Test all tools
        all_tools = context.get_available_tools()
        assert "tool1" in all_tools
        assert "tool2" in all_tools
        
        # Test category filter
        cat1_tools = context.get_available_tools("category1")
        assert "tool1" in cat1_tools
        assert "tool2" not in cat1_tools
    
    def test_get_tool_schema(self):
        """Test getting tool schema."""
        registry = ToolRegistry()
        mock_tool = MockTool("test_tool")
        registry.register(mock_tool, "test")
        
        context = ToolContext(registry)
        
        # Test specific tool schema
        schema = context.get_tool_schema("test_tool")
        assert schema["name"] == "test_tool"
        assert schema["type"] == "mock"
        
        # Test all schemas
        all_schemas = context.get_tool_schema()
        assert isinstance(all_schemas, dict)
    
    def test_cache_operations(self):
        """Test cache operations."""
        context = ToolContext()
        
        # Test set and get
        context.cache_set("key1", "value1")
        assert context.cache_get("key1") == "value1"
        
        # Test default value
        assert context.cache_get("nonexistent", "default") == "default"
        
        # Test clear
        context.cache_clear()
        assert context.cache_get("key1") is None


class TestToolHookDecorator:
    """Test tool_hook decorator functionality."""
    
    @pytest.mark.asyncio
    async def test_async_function_decoration(self):
        """Test decorating async functions."""
        @tool_hook(auto_load=False)
        async def test_func(param1, tools=None):
            assert tools is not None
            assert isinstance(tools, ToolContext)
            return {"param1": param1, "tools_available": len(tools.get_available_tools())}
        
        result = await test_func("test_value")
        assert result["param1"] == "test_value"
        assert "tools_available" in result
    
    def test_sync_function_decoration(self):
        """Test decorating sync functions."""
        @tool_hook(auto_load=False)
        def test_func(param1, tools=None):
            assert tools is not None
            assert isinstance(tools, ToolContext)
            return {"param1": param1, "tools_available": len(tools.get_available_tools())}
        
        result = test_func("test_value")
        assert result["param1"] == "test_value"
        assert "tools_available" in result
    
    @pytest.mark.asyncio
    async def test_decorator_with_auto_load(self):
        """Test decorator with auto_load enabled."""
        with patch('agent_sdk.tools.hooks._ensure_tools_loaded') as mock_ensure:
            mock_ensure.return_value = None
            
            @tool_hook(auto_load=True)
            async def test_func(tools=None):
                return "success"
            
            result = await test_func()
            assert result == "success"
            mock_ensure.assert_called_once()
    
    def test_decorator_without_parentheses(self):
        """Test decorator used without parentheses."""
        with patch('agent_sdk.tools.hooks.load_tools_config') as mock_load_config:
            mock_load_config.return_value = {}
            with patch('agent_sdk.tools.hooks._register_basic_tools') as mock_register_basic:
                with patch('agent_sdk.tools.hooks._register_tools_from_config') as mock_register_config:
                    @tool_hook
                    def test_func(tools=None):
                        return "success"
                    
                    result = test_func()
                    assert result == "success"


class TestToolRegistration:
    """Test tool registration functions."""
    
    @pytest.mark.asyncio
    async def test_ensure_tools_loaded_empty_registry(self):
        """Test _ensure_tools_loaded with empty registry."""
        with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
            mock_registry = Mock()
            mock_registry.list_tools.return_value = []
            mock_get_registry.return_value = mock_registry
            
            with patch('agent_sdk.tools.hooks.load_tools_config') as mock_load_config:
                mock_load_config.return_value = {}
                
                with patch('agent_sdk.tools.hooks._register_basic_tools') as mock_register_basic:
                    with patch('agent_sdk.tools.hooks._register_tools_from_config') as mock_register_config:
                        await _ensure_tools_loaded()
                        
                        mock_load_config.assert_called_once()
                        mock_register_basic.assert_called_once()
                        mock_register_config.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_ensure_tools_loaded_with_existing_tools(self):
        """Test _ensure_tools_loaded with existing tools."""
        with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
            mock_registry = Mock()
            mock_registry.list_tools.return_value = ["existing_tool"]
            mock_get_registry.return_value = mock_registry
            
            with patch('agent_sdk.tools.hooks._register_basic_tools') as mock_register_basic:
                await _ensure_tools_loaded()
                mock_register_basic.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_register_basic_tools(self):
        """Test _register_basic_tools function."""
        with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
            mock_registry = Mock()
            mock_get_registry.return_value = mock_registry
            
            with patch('agent_sdk.tools.utils.FileTool') as mock_file_tool:
                with patch('agent_sdk.tools.api.HTTPTool') as mock_http_tool:
                    mock_file_instance = Mock()
                    mock_http_instance = Mock()
                    mock_file_tool.return_value = mock_file_instance
                    mock_http_tool.return_value = mock_http_instance
                    
                    await _register_basic_tools()
                    
                    assert mock_registry.register.call_count == 2
                    mock_registry.register.assert_any_call(mock_file_instance, 'utility')
                    mock_registry.register.assert_any_call(mock_http_instance, 'api')
    
    @pytest.mark.asyncio
    async def test_register_tools_from_config(self):
        """Test _register_tools_from_config function."""
        config1 = MockConfig("tool1", "llm", enabled=True)
        config2 = MockConfig("tool2", "database", enabled=False)
        configs = {"tool1": config1, "tool2": config2}
        
        with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
            mock_registry = Mock()
            mock_get_registry.return_value = mock_registry
            
            with patch('agent_sdk.tools.hooks._create_tool') as mock_create_tool:
                mock_tool = Mock()
                mock_create_tool.return_value = mock_tool
                
                await _register_tools_from_config(configs)
                
                # Only enabled tool should be processed
                mock_create_tool.assert_called_once_with(config1)
                mock_registry.register.assert_called_once_with(mock_tool, config1.category)


class TestToolCreation:
    """Test tool creation functions."""
    
    @pytest.mark.asyncio
    async def test_create_tool_llm(self):
        """Test _create_tool for LLM tools."""
        config = MockConfig("test_llm", "llm")
        
        with patch('agent_sdk.tools.hooks._create_llm_tool') as mock_create_llm:
            mock_tool = Mock()
            mock_create_llm.return_value = mock_tool
            
            result = await _create_tool(config)
            
            assert result == mock_tool
            mock_create_llm.assert_called_once_with(config)
    
    @pytest.mark.asyncio
    async def test_create_tool_database(self):
        """Test _create_tool for database tools."""
        config = MockConfig("test_db", "database")
        
        with patch('agent_sdk.tools.hooks._create_database_tool') as mock_create_db:
            mock_tool = Mock()
            mock_create_db.return_value = mock_tool
            
            result = await _create_tool(config)
            
            assert result == mock_tool
            mock_create_db.assert_called_once_with(config)
    
    @pytest.mark.asyncio
    async def test_create_tool_api(self):
        """Test _create_tool for API tools."""
        config = MockConfig("test_api", "api")
        
        with patch('agent_sdk.tools.hooks._create_api_tool') as mock_create_api:
            mock_tool = Mock()
            mock_create_api.return_value = mock_tool
            
            result = await _create_tool(config)
            
            assert result == mock_tool
            mock_create_api.assert_called_once_with(config)
    
    @pytest.mark.asyncio
    async def test_create_tool_utility(self):
        """Test _create_tool for utility tools."""
        config = MockConfig("test_util", "utility")
        
        with patch('agent_sdk.tools.hooks._create_utility_tool') as mock_create_util:
            mock_tool = Mock()
            mock_create_util.return_value = mock_tool
            
            result = await _create_tool(config)
            
            assert result == mock_tool
            mock_create_util.assert_called_once_with(config)
    
    @pytest.mark.asyncio
    async def test_create_tool_unknown_type(self):
        """Test _create_tool with unknown tool type."""
        config = MockConfig("test_unknown", "unknown_type")
        
        result = await _create_tool(config)
        assert result is None
    
    @pytest.mark.asyncio
    async def test_create_tool_exception(self):
        """Test _create_tool with exception during creation."""
        config = MockConfig("test_error", "llm")
        
        with patch('agent_sdk.tools.hooks._create_llm_tool') as mock_create_llm:
            mock_create_llm.side_effect = Exception("Creation failed")
            
            result = await _create_tool(config)
            assert result is None
    
    @pytest.mark.asyncio
    async def test_create_llm_tool_openai(self):
        """Test _create_llm_tool for OpenAI."""
        config = MockConfig("openai_tool", "llm")
        
        with patch('agent_sdk.tools.llm.OpenAITool') as mock_openai:
            mock_tool = Mock()
            mock_openai.return_value = mock_tool
            
            result = await _create_llm_tool(config)
            
            assert result == mock_tool
            mock_openai.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_llm_tool_gemini(self):
        """Test _create_llm_tool for Gemini."""
        config = MockConfig("gemini_tool", "llm")
        
        with patch('agent_sdk.tools.llm.GeminiTool') as mock_gemini:
            mock_tool = Mock()
            mock_gemini.return_value = mock_tool
            
            result = await _create_llm_tool(config)
            
            assert result == mock_tool
            mock_gemini.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_llm_tool_mistral(self):
        """Test _create_llm_tool for Mistral."""
        config = MockConfig("mistral_tool", "llm")
        
        with patch('agent_sdk.tools.llm.MistralTool') as mock_mistral:
            mock_tool = Mock()
            mock_mistral.return_value = mock_tool
            
            result = await _create_llm_tool(config)
            
            assert result == mock_tool
            mock_mistral.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_llm_tool_anthropic(self):
        """Test _create_llm_tool for Anthropic."""
        config = MockConfig("anthropic_tool", "llm")
        
        with patch('agent_sdk.tools.llm.AnthropicTool') as mock_anthropic:
            mock_tool = Mock()
            mock_anthropic.return_value = mock_tool
            
            result = await _create_llm_tool(config)
            
            assert result == mock_tool
            mock_anthropic.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_llm_tool_claude(self):
        """Test _create_llm_tool for Claude."""
        config = MockConfig("claude_tool", "llm")
        
        with patch('agent_sdk.tools.llm.AnthropicTool') as mock_anthropic:
            mock_tool = Mock()
            mock_anthropic.return_value = mock_tool
            
            result = await _create_llm_tool(config)
            
            assert result == mock_tool
            mock_anthropic.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_llm_tool_gpt(self):
        """Test _create_llm_tool for GPT."""
        config = MockConfig("gpt_tool", "llm")
        
        with patch('agent_sdk.tools.llm.OpenAITool') as mock_openai:
            mock_tool = Mock()
            mock_openai.return_value = mock_tool
            
            result = await _create_llm_tool(config)
            
            assert result == mock_tool
            mock_openai.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_llm_tool_unknown(self):
        """Test _create_llm_tool for unknown LLM."""
        config = MockConfig("unknown_llm", "llm")
        
        result = await _create_llm_tool(config)
        assert result is None
    
    @pytest.mark.asyncio
    async def test_create_database_tool_postgresql(self):
        """Test _create_database_tool for PostgreSQL."""
        config = MockConfig("postgresql_tool", "database")
        
        with patch('agent_sdk.tools.database.PostgreSQLTool') as mock_postgres:
            mock_tool = Mock()
            mock_postgres.return_value = mock_tool
            
            result = await _create_database_tool(config)
            
            assert result == mock_tool
            mock_postgres.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_database_tool_postgres(self):
        """Test _create_database_tool for Postgres."""
        config = MockConfig("postgres_tool", "database")
        
        with patch('agent_sdk.tools.database.PostgreSQLTool') as mock_postgres:
            mock_tool = Mock()
            mock_postgres.return_value = mock_tool
            
            result = await _create_database_tool(config)
            
            assert result == mock_tool
            mock_postgres.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_database_tool_neo4j(self):
        """Test _create_database_tool for Neo4j."""
        config = MockConfig("neo4j_tool", "database")
        
        with patch('agent_sdk.tools.database.Neo4jTool') as mock_neo4j:
            mock_tool = Mock()
            mock_neo4j.return_value = mock_tool
            
            result = await _create_database_tool(config)
            
            assert result == mock_tool
            mock_neo4j.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_database_tool_mongo(self):
        """Test _create_database_tool for MongoDB."""
        config = MockConfig("mongo_tool", "database")
        
        with patch('agent_sdk.tools.database.MongoDBTool') as mock_mongo:
            mock_tool = Mock()
            mock_mongo.return_value = mock_tool
            
            result = await _create_database_tool(config)
            
            assert result == mock_tool
            mock_mongo.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_database_tool_unknown(self):
        """Test _create_database_tool for unknown database."""
        config = MockConfig("unknown_db", "database")
        
        result = await _create_database_tool(config)
        assert result is None
    
    @pytest.mark.asyncio
    async def test_create_api_tool_rest(self):
        """Test _create_api_tool for REST API."""
        config = MockConfig("rest_api", "api")
        config.config = {"rest_api": True}
        
        with patch('agent_sdk.tools.api.RestAPITool') as mock_rest:
            mock_tool = Mock()
            mock_rest.return_value = mock_tool
            
            result = await _create_api_tool(config)
            
            assert result == mock_tool
            mock_rest.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_api_tool_http(self):
        """Test _create_api_tool for HTTP."""
        config = MockConfig("http_api", "api")
        
        with patch('agent_sdk.tools.api.HTTPTool') as mock_http:
            mock_tool = Mock()
            mock_http.return_value = mock_tool
            
            result = await _create_api_tool(config)
            
            assert result == mock_tool
            mock_http.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_utility_tool_file(self):
        """Test _create_utility_tool for file tool."""
        config = MockConfig("file_tool", "utility")
        
        with patch('agent_sdk.tools.utils.FileTool') as mock_file:
            mock_tool = Mock()
            mock_file.return_value = mock_tool
            
            result = await _create_utility_tool(config)
            
            assert result == mock_tool
            mock_file.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_utility_tool_email(self):
        """Test _create_utility_tool for email tool."""
        config = MockConfig("email_tool", "utility")
        
        with patch('agent_sdk.tools.utils.EmailTool') as mock_email:
            mock_tool = Mock()
            mock_email.return_value = mock_tool
            
            result = await _create_utility_tool(config)
            
            assert result == mock_tool
            mock_email.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_utility_tool_slack(self):
        """Test _create_utility_tool for Slack tool."""
        config = MockConfig("slack_tool", "utility")
        
        with patch('agent_sdk.tools.utils.SlackTool') as mock_slack:
            mock_tool = Mock()
            mock_slack.return_value = mock_tool
            
            result = await _create_utility_tool(config)
            
            assert result == mock_tool
            mock_slack.assert_called_once_with(config.name, config.config)
    
    @pytest.mark.asyncio
    async def test_create_utility_tool_unknown(self):
        """Test _create_utility_tool for unknown utility."""
        config = MockConfig("unknown_util", "utility")
        
        result = await _create_utility_tool(config)
        assert result is None


class TestConvenienceFunctions:
    """Test convenience functions."""
    
    @pytest.mark.asyncio
    async def test_execute_tool_function(self):
        """Test execute_tool convenience function."""
        with patch('agent_sdk.tools.hooks._ensure_tools_loaded') as mock_ensure:
            with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
                mock_registry = AsyncMock()
                mock_result = ToolResult("test", ToolStatus.SUCCESS, {"result": "data"})
                mock_registry.execute_tool.return_value = mock_result
                mock_get_registry.return_value = mock_registry
                
                result = await execute_tool("test_tool", param1="value1")
                
                mock_ensure.assert_called_once()
                mock_registry.execute_tool.assert_called_once_with("test_tool", param1="value1")
                assert result == mock_result
    
    def test_get_available_tools_function(self):
        """Test get_available_tools convenience function."""
        with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
            mock_registry = Mock()
            mock_registry.list_tools.return_value = ["tool1", "tool2"]
            mock_get_registry.return_value = mock_registry
            
            result = get_available_tools()
            
            mock_registry.list_tools.assert_called_once_with(None)
            assert result == ["tool1", "tool2"]
            
            # Test with category
            result = get_available_tools("test_category")
            mock_registry.list_tools.assert_called_with("test_category")
    
    def test_get_tool_schema_function(self):
        """Test get_tool_schema convenience function."""
        with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
            mock_registry = Mock()
            mock_tool = Mock()
            mock_tool.get_schema.return_value = {"name": "test_tool"}
            mock_registry.get_tool.return_value = mock_tool
            mock_registry.get_schema.return_value = {"all": "schemas"}
            mock_get_registry.return_value = mock_registry
            
            # Test specific tool
            result = get_tool_schema("test_tool")
            mock_registry.get_tool.assert_called_once_with("test_tool")
            assert result == {"name": "test_tool"}
            
            # Test all schemas
            result = get_tool_schema()
            mock_registry.get_schema.assert_called_once()
            assert result == {"all": "schemas"}
            
            # Test non-existent tool
            mock_registry.get_tool.return_value = None
            result = get_tool_schema("nonexistent")
            assert result == {}


class TestEdgeCases:
    """Test edge cases and error conditions."""
    
    def test_tool_context_execute_sync_new_loop(self):
        """Test execute_sync when no event loop exists."""
        registry = ToolRegistry()
        mock_tool = MockTool("test_tool")
        registry.register(mock_tool, "test")
        
        context = ToolContext(registry)
        
        # Mock RuntimeError when getting event loop
        with patch('asyncio.get_event_loop', side_effect=RuntimeError("No event loop")):
            with patch('asyncio.new_event_loop') as mock_new_loop:
                with patch('asyncio.set_event_loop') as mock_set_loop:
                    mock_loop = Mock()
                    mock_loop.run_until_complete.return_value = ToolResult("test", ToolStatus.SUCCESS, {})
                    mock_new_loop.return_value = mock_loop
                    
                    result = context.execute_sync("test_tool")
                    
                    mock_new_loop.assert_called_once()
                    mock_set_loop.assert_called_once_with(mock_loop)
                    assert result.status == ToolStatus.SUCCESS
    
    def test_sync_wrapper_new_loop(self):
        """Test sync wrapper when no event loop exists."""
        with patch('asyncio.get_event_loop', side_effect=RuntimeError("No event loop")):
            with patch('asyncio.new_event_loop') as mock_new_loop:
                with patch('asyncio.set_event_loop') as mock_set_loop:
                    with patch('agent_sdk.tools.hooks._ensure_tools_loaded') as mock_ensure:
                        mock_loop = Mock()
                        mock_loop.run_until_complete.return_value = None
                        mock_new_loop.return_value = mock_loop
                        
                        @tool_hook(auto_load=True)
                        def test_func(tools=None):
                            return "success"
                        
                        result = test_func()
                        
                        mock_new_loop.assert_called_once()
                        mock_set_loop.assert_called_once_with(mock_loop)
                        assert result == "success"
    
    @pytest.mark.asyncio
    async def test_register_tools_from_config_with_exception(self):
        """Test _register_tools_from_config with tool creation exception."""
        config = MockConfig("failing_tool", "llm", enabled=True)
        configs = {"failing_tool": config}
        
        with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
            mock_registry = Mock()
            mock_get_registry.return_value = mock_registry
            
            with patch('agent_sdk.tools.hooks._create_tool') as mock_create_tool:
                mock_create_tool.side_effect = Exception("Tool creation failed")
                
                # Should not raise exception, just log error
                await _register_tools_from_config(configs)
                
                mock_create_tool.assert_called_once_with(config)
                mock_registry.register.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_register_tools_from_config_with_none_tool(self):
        """Test _register_tools_from_config when tool creation returns None."""
        config = MockConfig("none_tool", "llm", enabled=True)
        configs = {"none_tool": config}
        
        with patch('agent_sdk.tools.hooks.get_tool_registry') as mock_get_registry:
            mock_registry = Mock()
            mock_get_registry.return_value = mock_registry
            
            with patch('agent_sdk.tools.hooks._create_tool') as mock_create_tool:
                mock_create_tool.return_value = None
                
                await _register_tools_from_config(configs)
                
                mock_create_tool.assert_called_once_with(config)
                mock_registry.register.assert_not_called()


class TestIntegration:
    """Integration tests for the hooks system."""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self):
        """Test complete workflow from decoration to execution."""
        # Create a mock registry with a tool
        registry = ToolRegistry()
        mock_tool = MockTool("integration_tool")
        registry.register(mock_tool, "test")
        
        with patch('agent_sdk.tools.hooks.get_tool_registry', return_value=registry):
            @tool_hook(auto_load=False)
            async def integration_task(data, tools=None):
                # Use the tool
                result = await tools.execute("integration_tool", input_data=data)
                return {
                    "processed": True,
                    "tool_result": result.data,
                    "available_tools": tools.get_available_tools()
                }
            
            # Execute the decorated function
            result = await integration_task("test_data")
            
            # Verify results
            assert result["processed"] is True
            assert result["tool_result"]["mock"] == "result"
            assert result["tool_result"]["params"]["input_data"] == "test_data"
            assert "integration_tool" in result["available_tools"]
            assert mock_tool.execute_called
    
    def test_sync_integration_workflow(self):
        """Test complete sync workflow."""
        registry = ToolRegistry()
        mock_tool = MockTool("sync_tool")
        registry.register(mock_tool, "test")
        
        with patch('agent_sdk.tools.hooks.get_tool_registry', return_value=registry):
            @tool_hook(auto_load=False)
            def sync_task(data, tools=None):
                # Use the tool synchronously
                result = tools.execute_sync("sync_tool", input_data=data)
                return {
                    "processed": True,
                    "tool_result": result.data,
                    "schema": tools.get_tool_schema("sync_tool")
                }
            
            # Execute the decorated function
            result = sync_task("sync_data")
            
            # Verify results
            assert result["processed"] is True
            assert result["tool_result"]["params"]["input_data"] == "sync_data"
            assert result["schema"]["name"] == "sync_tool"
            assert mock_tool.execute_called