# Import Reference Guide

Quick reference for all correct imports in the Agent SDK.

## Core Framework

```python
# Stage decorators
from agent_sdk import perceive, reason, plan, act, review, learn

# Execution engines
from agent_sdk import (
    agentic_spine,              # Prefect sync
    agentic_spine_simple,       # Simple sync
    agentic_spine_async,        # Simple async
    agentic_spine_async_prefect # Prefect async
)

# Context management
from agent_sdk import Context, merge_context, Stage

# Custom decorators
from agent_sdk.core.decorators import stage_decorator, async_stage
from agent_sdk.core.stages import Stage
```

## State Monitoring

```python
# Monitoring and state management
from agent_sdk.core.state import (
    configure_monitoring,
    get_workflow_status,
    get_metrics,
    StageState,
    StageExecution,
    StageStateObserver,
    LoggingObserver,
    MetricsObserver,
    get_state_manager
)
```

## Tools System

```python
# Tool hooks and execution
from agent_sdk.tools import tool_hook, get_available_tools, execute_tool

# Base tool classes
from agent_sdk.tools import (
    Tool,
    ToolResult,
    ToolStatus,
    ToolError,
    ToolRegistry,
    get_tool_registry
)

# Configuration
from agent_sdk.tools import ToolConfig, load_tools_config

# LLM Tools
from agent_sdk.tools import (
    OpenAITool,
    GeminiTool,
    MistralTool,
    AnthropicTool
)

# Database Tools
from agent_sdk.tools import (
    PostgreSQLTool,
    Neo4jTool,
    MongoDBTool
)

# API Tools
from agent_sdk.tools import HTTPTool, RestAPITool

# Utility Tools
from agent_sdk.tools import FileTool, EmailTool, SlackTool
```

## Agent Framework

```python
# Agent factory functions
from agent_sdk.agent import (
    create_agent,
    create_simple_sync_agent,
    create_simple_async_agent,
    create_prefect_sync_agent,
    create_prefect_async_agent
)

# Agent classes
from agent_sdk.agent import (
    BaseAgent,
    SimpleSyncAgent,
    SimpleAsyncAgent,
    PrefectSyncAgent,
    PrefectAsyncAgent,
    AgentFactory,
    AgentType
)

# For custom agent extensions
from agent_sdk.agent.base_agent import BaseAgent
```

## Demo Examples

```python
# Demo implementations (when package is installed)
from demo import PaymentProcessor, AsyncPaymentProcessor
```

## Prefect Integration

```python
# When using Prefect tasks
from prefect import task, flow
from prefect.cache_policies import NONE as NO_CACHE

# Example usage
@perceive
@task(name="my_task", cache_policy=NO_CACHE)
def my_function(ctx: dict) -> dict:
    return {"result": "data"}
```

## Common Patterns

### Pattern 1: Simple Workflow
```python
from agent_sdk import perceive, reason, agentic_spine_simple

@perceive
def analyze(ctx):
    return {"analyzed": True}

@reason
def decide(ctx):
    return {"decision": "proceed"}

result = agentic_spine_simple(
    input_data={"input": "data"},
    functions=[analyze, decide]
)
```

### Pattern 2: Async Workflow
```python
from agent_sdk import perceive, reason, agentic_spine_async
import asyncio

@perceive
async def async_analyze(ctx):
    await asyncio.sleep(0.1)
    return {"analyzed": True}

@reason
async def async_decide(ctx):
    return {"decision": "proceed"}

result = await agentic_spine_async(
    input_data={"input": "data"},
    functions=[async_analyze, async_decide]
)
```

### Pattern 3: Prefect Workflow
```python
from agent_sdk import perceive, reason, agentic_spine, Stage
from prefect import task

@perceive
@task(name="analyze")
def analyze(ctx):
    return {"analyzed": True}

@reason
@task(name="decide")
def decide(ctx):
    return {"decision": "proceed"}

result = agentic_spine(
    input_data={"input": "data"},
    functions=[analyze, decide],
    concurrent={Stage.PERCEIVE: True}
)
```

### Pattern 4: Tools Integration
```python
from agent_sdk import perceive, agentic_spine_async
from agent_sdk.tools import tool_hook

@perceive
@tool_hook
async def analyze_with_tools(ctx, tools):
    # Use LLM
    result = await tools.execute('openai',
        prompt="Analyze this",
        max_tokens=100
    )
    return {"analysis": result.data}

result = await agentic_spine_async(
    input_data={"input": "data"},
    functions=[analyze_with_tools]
)
```

### Pattern 5: Custom Tools
```python
from agent_sdk.tools import Tool, ToolResult, ToolStatus, get_tool_registry

class MyTool(Tool):
    async def execute(self, **kwargs) -> ToolResult:
        # Your logic here
        return ToolResult(
            tool_name=self.name,
            status=ToolStatus.SUCCESS,
            data={"result": "success"}
        )

# Register
registry = get_tool_registry()
registry.register(MyTool("my_tool"), "custom")
```

### Pattern 6: Agent Factory
```python
from agent_sdk.agent import create_simple_sync_agent
from agent_sdk import perceive

@perceive
def my_func(ctx):
    return {"data": "processed"}

agent = create_simple_sync_agent(
    functions=[my_func],
    workflow_id="my_workflow"
)

result = agent.execute({"input": "data"})
```

## Notes

- All imports are from `agent_sdk` or its submodules
- Tools are organized in subdirectories: `llm/`, `database/`, `api/`, `utils/`
- Agent classes are in `agent_sdk.agent`
- State management is in `agent_sdk.core.state`
- Demo examples require package installation: `pip install -e .`
