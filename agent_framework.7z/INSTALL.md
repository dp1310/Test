# Installation Guide

## Quick Start

### Basic Installation

```bash
# Clone the repository
git clone <repository-url>
cd agent_framework

# Install core framework
pip install -e .
```

### Installation Options

#### 1. Core Framework Only
```bash
pip install -e .
```
Includes: Basic agentic workflows, Prefect integration, dynamic configuration, logging, HTTP client

#### 2. With Development Tools
```bash
pip install -e ".[dev]"
```
Includes: Core + testing framework, code formatting, type checking, development utilities

#### 3. With All Tools
```bash
pip install -e ".[all]"
```
Includes: Everything (core + LLMs + databases + APIs + notifications + dev tools)

#### 4. Selective Installation
```bash
# Just LLM tools
pip install -e ".[llm]"

# Just database tools  
pip install -e ".[database]"

# Just API tools
pip install -e ".[api]"

# Just notifications
pip install -e ".[notifications]"

# Custom combination
pip install -e ".[llm,database,dev]"
```

### Alternative: Requirements Files

You can also install using requirements files:

```bash
# Production only
pip install -r requirements.txt

# Development setup
pip install -r requirements-dev.txt

# Testing setup
pip install -r requirements-test.txt
```

## Available Optional Dependencies

### 🤖 LLM Tools (`[llm]`)
- **OpenAI**: GPT-3.5, GPT-4, GPT-4o with streaming support
- **Google Gemini**: Gemini Pro with multimodal capabilities
- **Anthropic**: Claude 3 (Haiku, Sonnet, Opus) with large context
- **Mistral AI**: Mistral models with function calling

### 💾 Database Tools (`[database]`)
- **PostgreSQL**: Async connection pooling with asyncpg and psycopg2
- **Neo4j**: Graph database with Cypher queries
- **MongoDB**: Document operations with Motor (async) and PyMongo

### 🌐 API Tools (`[api]`)
- **HTTP Client**: Full HTTP methods with httpx
- **File Operations**: Async file handling with aiofiles

### 📢 Notification Tools (`[notifications]`)
- **Email**: SMTP with HTML support via aiosmtplib
- **Slack**: Webhook and Bot API integration

### 🛠️ Development Tools (`[dev]`)
- **Testing**: pytest, pytest-asyncio, pytest-cov, pytest-mock, pytest-xdist
- **Code Quality**: black, flake8, mypy, isort
- **Git Hooks**: pre-commit
- **Development**: ipython, jupyter
- **Test Utilities**: factory-boy, faker, freezegun, responses
- **Type Stubs**: types-PyYAML, types-requests

## Configuration

### 1. Environment Variables

Create a `.env` file:

```bash
# Copy example file
cp .env.example .env

# Edit with your API keys
nano .env
```

Example `.env`:
```bash
# LLM API Keys
OPENAI_API_KEY=your_openai_key_here
GOOGLE_API_KEY=your_gemini_key_here
ANTHROPIC_API_KEY=your_anthropic_key_here
MISTRAL_API_KEY=your_mistral_key_here

# Database URLs
POSTGRES_URL=postgresql://user:pass@host:port/db
NEO4J_URI=bolt://localhost:7687
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your_password
MONGODB_URI=mongodb://localhost:27017/db

# Notification Services
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...
SLACK_BOT_TOKEN=xoxb-your-bot-token
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password
```

### 2. Tools Configuration

The framework will automatically create `config/tools.yaml` on first run, or you can create it manually:

```yaml
tools:
  # LLM Tools
  openai:
    type: llm
    enabled: true
    config:
      api_key: ${OPENAI_API_KEY}
      model: gpt-4o-mini
      max_tokens: 1000
      temperature: 0.7
  
  gemini:
    type: llm
    enabled: true
    config:
      api_key: ${GOOGLE_API_KEY}
      model: gemini-pro
      max_tokens: 1000
  
  # Database Tools
  postgresql:
    type: database
    enabled: true
    config:
      url: ${POSTGRES_URL}
      pool_size: 10
  
  mongodb:
    type: database
    enabled: true
    config:
      uri: ${MONGODB_URI}
      database: agent_db
  
  # Notification Tools
  slack:
    type: notification
    enabled: true
    config:
      webhook_url: ${SLACK_WEBHOOK_URL}
      # or use bot_token: ${SLACK_BOT_TOKEN}
      default_channel: "#general"
```

## Verification

### Test Installation

```bash
# Test core framework
python -c "from agent_sdk import perceive, reason, plan, act; print('✅ Core framework installed')"

# Test tools system (if installed)
python -c "from agent_sdk.tools import tool_hook; print('✅ Tools system installed')"

# Test specific tools (if dependencies installed)
python -c "from agent_sdk.tools import OpenAITool; print('✅ OpenAI tool available')"
python -c "from agent_sdk.tools import PostgreSQLTool; print('✅ PostgreSQL tool available')"

# Run verification script
python examples/verify_setup.py

# Run simple example
python examples/simple_string_usage.py
```

### Run Tests

```bash
# Install with dev dependencies first
pip install -e ".[dev]"

# Run all tests
pytest

# Run with coverage
pytest --cov=agent_sdk --cov-report=html

# Run specific test categories
pytest -m "not tools"        # Skip tools tests
pytest -m "not llm"          # Skip LLM tests  
pytest -m "not database"     # Skip database tests
pytest -m "not integration"  # Skip integration tests

# Run tests in parallel
pytest -n auto

# Run with verbose output
pytest -v
```

## Troubleshooting

### Common Issues

#### 1. Import Errors
```bash
# Make sure you're in the right directory
cd agent_framework

# Install in editable mode
pip install -e .
```

#### 2. Missing Dependencies
```bash
# Install specific tool dependencies
pip install -e ".[llm]"           # For LLM tools
pip install -e ".[database]"      # For database tools
pip install -e ".[api]"           # For API tools
pip install -e ".[notifications]" # For notification tools

# Or install from requirements files
pip install -r requirements.txt     # Core dependencies
pip install -r requirements-dev.txt # Development dependencies
```

#### 3. Environment Variables Not Loading
```bash
# Check .env file exists
ls -la .env

# Test loading
python -c "from dotenv import load_dotenv; load_dotenv(); import os; print('OPENAI_API_KEY:', bool(os.getenv('OPENAI_API_KEY')))"

# Check if python-dotenv is installed
python -c "import dotenv; print('✅ python-dotenv installed')"
```

#### 4. Tools Configuration Issues
```bash
# Check config directory
ls -la config/

# Validate YAML syntax
python -c "import yaml; yaml.safe_load(open('config/tools.yaml'))"
```

### Getting Help

1. **Check Examples**: Look at `examples/` directory for working code
2. **Read Documentation**: See README.md for comprehensive guide
3. **Run Tests**: Use `pytest -v` to see detailed test output
4. **Check Logs**: Enable debug logging in your code

### Development Setup

```bash
# Full development setup
git clone <repository-url>
cd agent_framework

# Install with all dependencies
pip install -e ".[all]"

# Install pre-commit hooks
pre-commit install

# Run tests to verify setup
pytest

# Format code
black .

# Type check
mypy agent_sdk/
```

## Next Steps

1. **Read the README**: Comprehensive guide with examples
2. **Try Examples**: Start with `examples/simple_string_usage.py`
3. **Configure Tools**: Set up API keys for the tools you need
4. **Build Your First Agent**: Follow the quick start guide

Happy building! 🚀