"""Simple test to verify agent implementations work."""

import sys
import os
import asyncio
sys.path.append(os.path.dirname(__file__))

from agent_sdk.agent import (
    create_simple_sync_agent, 
    create_prefect_sync_agent,
    create_simple_async_agent,
    create_prefect_async_agent
)
from agent_sdk.core.stages import perceive, reason, plan, act, Stage
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging to see output
setup_logging(level="INFO")
logger = get_logger(__name__)


@perceive
def test_perceive(context):
    return {"perceived": "test_data"}


@reason
def test_reason(context):
    return {"reasoning": "test_analysis"}


@plan
def test_plan(context):
    return {"plan": "test_plan"}


@act
def test_act(context):
    return {"action": "test_result"}


# Async versions for async agent testing
@perceive
async def test_perceive_async(context):
    await asyncio.sleep(0.01)  # Simulate async work
    return {"perceived": "async_test_data"}


@reason
async def test_reason_async(context):
    await asyncio.sleep(0.01)  # Simulate async work
    return {"reasoning": "async_test_analysis"}


@plan
async def test_plan_async(context):
    await asyncio.sleep(0.01)  # Simulate async work
    return {"plan": "async_test_plan"}


@act
async def test_act_async(context):
    await asyncio.sleep(0.01)  # Simulate async work
    return {"action": "async_test_result"}


def test_simple_sync_agent():
    """Test simple sync agent."""
    logger.info("Testing Simple Sync Agent...")
    
    agent = create_simple_sync_agent(
        functions=[test_perceive, test_reason, test_plan, test_act],
        workflow_id="test_simple_sync"
    )
    
    result = agent.execute("test_input")
    logger.info(f"Simple sync result: {result.data}")
    logger.info(f"Agent type: {agent.get_execution_type()}")
    return True


def test_prefect_sync_agent():
    """Test Prefect sync agent."""
    logger.info("Testing Prefect Sync Agent...")
    
    agent = create_prefect_sync_agent(
        functions=[test_perceive, test_reason, test_plan, test_act],
        workflow_id="test_prefect_sync"
    )
    
    result = agent.execute("test_input")
    logger.info(f"Prefect sync result: {result.data}")
    logger.info(f"Agent type: {agent.get_execution_type()}")
    return True


def test_agent_cloning():
    """Test agent cloning functionality."""
    logger.info("Testing Agent Cloning...")
    
    original = create_simple_sync_agent(
        functions=[test_perceive, test_reason],
        initial_context={"original": True}
    )
    
    cloned = (original.clone()
              .add_function(test_plan)
              .add_function(test_act)
              .update_initial_context({"cloned": True}))
    
    logger.info(f"Original functions: {len(original.functions)}")
    logger.info(f"Cloned functions: {len(cloned.functions)}")
    
    original_result = original.execute("test")
    cloned_result = cloned.execute("test")
    
    logger.info(f"Original context keys: {list(original_result.data.keys())}")
    logger.info(f"Cloned context keys: {list(cloned_result.data.keys())}")
    return True


async def test_simple_async_agent():
    """Test simple async agent."""
    logger.info("Testing Simple Async Agent...")
    
    agent = create_simple_async_agent(
        functions=[test_perceive_async, test_reason_async, test_plan_async, test_act_async],
        concurrent={Stage.PERCEIVE: True, Stage.REASON: True},
        workflow_id="test_simple_async"
    )
    
    result = await agent.execute("async_test_input")
    logger.info(f"Simple async result: {result.data}")
    logger.info(f"Agent type: {agent.get_execution_type()}")
    return True


async def test_prefect_async_agent():
    """Test Prefect async agent."""
    logger.info("Testing Prefect Async Agent...")
    
    agent = create_prefect_async_agent(
        functions=[test_perceive_async, test_reason, test_plan_async, test_act],
        concurrent={Stage.PERCEIVE: True, Stage.PLAN: True},
        workflow_id="test_prefect_async"
    )
    
    result = await agent.execute("prefect_async_test_input")
    logger.info(f"Prefect async result: {result.data}")
    logger.info(f"Agent type: {agent.get_execution_type()}")
    return True


async def test_mixed_sync_async():
    """Test agent with mixed sync/async functions."""
    logger.info("Testing Mixed Sync/Async Functions...")
    
    agent = create_simple_async_agent(
        functions=[test_perceive_async, test_reason, test_plan_async, test_act],
        workflow_id="test_mixed"
    )
    
    result = await agent.execute("mixed_test_input")
    logger.info(f"Mixed result: {result.data}")
    return True


async def run_async_tests():
    """Run all async tests."""
    await test_simple_async_agent()
    logger.info("")
    await test_prefect_async_agent()
    logger.info("")
    await test_mixed_sync_async()


async def main():
    """Main test function."""
    logger.info("Running Agent Tests")
    logger.info("=" * 30)
    
    try:
        # Sync tests
        test_simple_sync_agent()
        logger.info("")
        test_prefect_sync_agent()
        logger.info("")
        test_agent_cloning()
        logger.info("")
        
        # Async tests
        await run_async_tests()
        
        logger.info("\nAll tests passed!")
    except Exception as e:
        logger.error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())