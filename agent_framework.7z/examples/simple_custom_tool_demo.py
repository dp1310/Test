#!/usr/bin/env python3
"""
Simple Custom Tool Demo

This example shows the essential steps to create and use custom tools:

1. Create a custom tool by extending the Tool base class
2. Register it with the tool registry
3. Use @tool_hook decorator to access it in workflows
4. Execute the tool within agentic functions

This is a minimal, focused example perfect for learning the basics.
"""

import sys
import os
import asyncio
import time
import random
from typing import Dict, Any

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import perceive, reason, act, agentic_spine_async, Context, get_logger, setup_logging
from agent_sdk.tools import Tool, ToolResult, ToolError, tool_hook
from agent_sdk.tools.base import ToolStatus, get_tool_registry

# Setup logging
setup_logging(level="INFO")

logger = get_logger(__name__)


# ============================================================================
# STEP 1: CREATE CUSTOM TOOL
# ============================================================================

class SimpleDataTool(Tool):
    """A simple custom tool that generates and processes data."""
    
    def __init__(self, name: str, config: Dict[str, Any] = None):
        super().__init__(name, config or {})
        self.data_source = config.get('data_source', 'random') if config else 'random'
    
    async def execute(self, operation: str, count: int = 5, **kwargs) -> ToolResult:
        """
        Execute data operations.
        
        Args:
            operation: Type of operation ('generate', 'analyze', 'transform')
            count: Number of data points to work with
            
        Returns:
            ToolResult with processed data
        """
        try:
            # Simulate processing time
            await asyncio.sleep(0.1)
            
            if operation == "generate":
                data = [random.randint(1, 100) for _ in range(count)]
                result = {
                    "operation": operation,
                    "data": data,
                    "count": len(data),
                    "source": self.data_source
                }
            
            elif operation == "analyze":
                # Generate sample data to analyze
                data = [random.randint(1, 100) for _ in range(count)]
                result = {
                    "operation": operation,
                    "data": data,
                    "average": sum(data) / len(data),
                    "min": min(data),
                    "max": max(data),
                    "count": len(data)
                }
            
            elif operation == "transform":
                # Generate and transform data
                data = [random.randint(1, 100) for _ in range(count)]
                transformed = [x * 2 for x in data]
                result = {
                    "operation": operation,
                    "original_data": data,
                    "transformed_data": transformed,
                    "transformation": "multiply by 2",
                    "count": len(data)
                }
            
            else:
                raise ValueError(f"Unknown operation: {operation}")
            
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.SUCCESS,
                data=result
            )
            
        except Exception as e:
            return ToolResult(
                tool_name=self.name,
                status=ToolStatus.ERROR,
                error=ToolError(f"SimpleDataTool error: {e}", self.name, e)
            )
    
    def get_schema(self) -> Dict[str, Any]:
        """Get tool schema for documentation."""
        return {
            "name": self.name,
            "description": "Simple tool for data generation and processing",
            "parameters": {
                "operation": {
                    "type": "string",
                    "description": "Operation to perform",
                    "enum": ["generate", "analyze", "transform"],
                    "required": True
                },
                "count": {
                    "type": "integer",
                    "description": "Number of data points",
                    "default": 5,
                    "minimum": 1,
                    "maximum": 100
                }
            },
            "examples": [
                {"operation": "generate", "count": 10},
                {"operation": "analyze", "count": 20},
                {"operation": "transform", "count": 5}
            ]
        }


# ============================================================================
# STEP 2: REGISTER CUSTOM TOOL
# ============================================================================

def setup_custom_tool():
    """Register our custom tool with the tool registry."""
    logger.info("🔧 Setting up custom tool...")
    
    # Get the global tool registry
    registry = get_tool_registry()
    
    # Create our custom tool instance
    data_tool = SimpleDataTool("simple_data_processor", {
        "data_source": "demo_generator"
    })
    
    # Register it with a category
    registry.register(data_tool, "utility")
    
    logger.info("✅ Custom tool registered!")
    logger.info(f"   Available tools: {registry.list_tools()}")


# ============================================================================
# STEP 3: USE TOOL IN AGENTIC WORKFLOW WITH @tool_hook
# ============================================================================

@perceive
@tool_hook  # This decorator injects 'tools' parameter automatically
async def collect_data(ctx: Context, tools) -> Dict[str, Any]:
    """Collect data using our custom tool."""
    logger.info("📥 Collecting data with custom tool...")
    
    # Get input parameters
    data_count = ctx.get("input", {}).get("count", 10)
    
    # Use our custom tool to generate data
    result = await tools.execute(
        'simple_data_processor',  # Tool name we registered
        operation='generate',
        count=data_count
    )
    
    if result.is_success:
        data = result.data
        logger.info(f"✅ Generated {len(data['data'])} data points: {data['data'][:5]}...")
        
        return {
            "raw_data": data['data'],
            "data_count": len(data['data']),
            "collection_success": True
        }
    else:
        logger.error(f"❌ Data collection failed: {result.error}")
        return {
            "raw_data": [],
            "data_count": 0,
            "collection_success": False
        }


@reason
@tool_hook
async def analyze_data(ctx: Context, tools) -> Dict[str, Any]:
    """Analyze the collected data using our custom tool."""
    logger.info("🧠 Analyzing data with custom tool...")
    
    data_count = ctx.get("data_count", 5)
    
    # Use our custom tool to analyze data
    result = await tools.execute(
        'simple_data_processor',
        operation='analyze',
        count=data_count
    )
    
    if result.is_success:
        analysis = result.data
        logger.info(f"✅ Analysis complete - Average: {analysis['average']:.2f}")
        
        return {
            "analysis_results": analysis,
            "insights": f"Data ranges from {analysis['min']} to {analysis['max']} with average {analysis['average']:.2f}",
            "analysis_success": True
        }
    else:
        logger.error(f"❌ Analysis failed: {result.error}")
        return {
            "analysis_results": {},
            "insights": "Analysis failed",
            "analysis_success": False
        }


@act
@tool_hook
async def transform_and_report(ctx: Context, tools) -> Dict[str, Any]:
    """Transform data and create final report using our custom tool."""
    logger.info("⚡ Transforming data and creating report...")
    
    data_count = ctx.get("data_count", 5)
    analysis_success = ctx.get("analysis_success", False)
    
    # Use our custom tool to transform data
    result = await tools.execute(
        'simple_data_processor',
        operation='transform',
        count=data_count
    )
    
    if result.is_success:
        transformation = result.data
        
        # Create final report
        report = {
            "original_data": transformation['original_data'],
            "transformed_data": transformation['transformed_data'],
            "transformation_applied": transformation['transformation'],
            "data_points_processed": transformation['count'],
            "analysis_was_successful": analysis_success,
            "processing_complete": True,
            "timestamp": time.time()
        }
        
        logger.info(f"✅ Transformation complete - Processed {transformation['count']} points")
        logger.info(f"   Original: {transformation['original_data'][:3]}...")
        logger.info(f"   Transformed: {transformation['transformed_data'][:3]}...")
        
        return report
    else:
        logger.error(f"❌ Transformation failed: {result.error}")
        return {
            "processing_complete": False,
            "error": str(result.error)
        }


# ============================================================================
# STEP 4: DEMONSTRATION
# ============================================================================

async def demo_direct_tool_usage():
    """Show how to use the custom tool directly."""
    logger.info("\n🎯 DEMO: Direct Custom Tool Usage")
    logger.info("-" * 40)
    
    registry = get_tool_registry()
    
    # Test each operation directly
    operations = ["generate", "analyze", "transform"]
    
    for operation in operations:
        logger.info(f"Testing {operation} operation...")
        
        result = await registry.execute_tool(
            'simple_data_processor',
            operation=operation,
            count=5
        )
        
        if result.is_success:
            data = result.data
            logger.info(f"✅ {operation.capitalize()} successful!")
            
            if operation == "generate":
                logger.info(f"   Generated data: {data['data']}")
            elif operation == "analyze":
                logger.info(f"   Average: {data['average']:.2f}, Range: {data['min']}-{data['max']}")
            elif operation == "transform":
                logger.info(f"   Original: {data['original_data'][:3]}...")
                logger.info(f"   Transformed: {data['transformed_data'][:3]}...")
        else:
            logger.error(f"❌ {operation.capitalize()} failed: {result.error}")


async def demo_workflow_with_custom_tool():
    """Show how to use the custom tool in an agentic workflow."""
    logger.info("\n🎯 DEMO: Custom Tool in Agentic Workflow")
    logger.info("-" * 40)
    
    start_time = time.time()
    
    # Run the complete workflow
    result = await agentic_spine_async(
        input_data={
            "count": 8  # Number of data points to process
        },
        functions=[
            collect_data,           # Uses custom tool to generate data
            analyze_data,           # Uses custom tool to analyze data
            transform_and_report    # Uses custom tool to transform data
        ],
        workflow_id="custom_tool_demo_workflow"
    )
    
    end_time = time.time()
    
    # Show results
    logger.info("✅ Workflow completed!")
    logger.info(f"   Duration: {end_time - start_time:.3f}s")
    logger.info(f"   Data points processed: {result.data.get('data_points_processed', 0)}")
    logger.info(f"   Processing successful: {result.data.get('processing_complete', False)}")
    
    if result.data.get('processing_complete'):
        original = result.data.get('original_data', [])
        transformed = result.data.get('transformed_data', [])
        logger.info(f"   Sample original data: {original[:3]}...")
        logger.info(f"   Sample transformed data: {transformed[:3]}...")
    
    return result


async def demo_tool_schema():
    """Show the tool's schema and capabilities."""
    logger.info("\n📋 DEMO: Custom Tool Schema")
    logger.info("-" * 40)
    
    registry = get_tool_registry()
    tool = registry.get_tool('simple_data_processor')
    
    if tool:
        schema = tool.get_schema()
        logger.info(f"Tool Name: {schema['name']}")
        logger.info(f"Description: {schema['description']}")
        logger.info(f"Operations: {schema['parameters']['operation']['enum']}")
        logger.info(f"Examples: {len(schema['examples'])} provided")


async def main():
    """Main demonstration function."""
    logger.info("Simple Custom Tool Demo")
    logger.info("=" * 40)
    
    # Step 1: Setup our custom tool
    setup_custom_tool()
    
    # Step 2: Show direct usage
    await demo_direct_tool_usage()
    
    # Step 3: Show workflow usage
    await demo_workflow_with_custom_tool()
    
    # Step 4: Show schema
    await demo_tool_schema()
    
    logger.info("\n=== Simple Custom Tool Demo Complete ===")


if __name__ == "__main__":
    asyncio.run(main())