"""Quick test of custom agent functionality."""

import sys
import os
sys.path.append(os.path.dirname(__file__))

from examples.custom_agent_example import EnhancedPrefectAgent
from agent_sdk.core.stages import perceive, reason
from agent_sdk.agent import PrefectSyncAgent
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging to see output
setup_logging(level="INFO")
logger = get_logger(__name__)


@perceive
def quick_perceive(context):
    return {"perceived": "quick_data"}


@reason
def quick_reason(context):
    return {"reasoning": "quick_analysis"}


def test_custom_agent_basics():
    """Test basic custom agent functionality."""
    logger.info("Testing Custom Agent Basics...")
    
    # Create enhanced agent
    agent = EnhancedPrefectAgent(
        functions=[quick_perceive, quick_reason],
        enable_metrics=True,
        max_execution_time=10.0,
        workflow_id="quick_test"
    )
    
    # Verify it's properly configured
    logger.info(f"Agent type: {agent.get_execution_type()}")
    logger.info(f"Agent string: {agent}")
    
    # Verify inheritance
    assert isinstance(agent, PrefectSyncAgent)
    assert hasattr(agent, 'get_execution_metrics')
    assert hasattr(agent, 'set_max_execution_time')
    
    # Test fluent interface
    agent2 = (EnhancedPrefectAgent()
              .add_function(quick_perceive)
              .enable_metrics(True)
              .set_max_execution_time(5.0))
    
    logger.info(f"Fluent agent: {agent2}")
    
    # Test cloning
    cloned = agent.clone()
    assert isinstance(cloned, EnhancedPrefectAgent)
    assert len(cloned.functions) == len(agent.functions)
    
    logger.info("Custom agent basics test passed!")
    return True


if __name__ == "__main__":
    logger.info("Quick Custom Agent Test")
    logger.info("=" * 25)
    
    try:
        test_custom_agent_basics()
        logger.info("\nQuick test passed!")
    except Exception as e:
        logger.error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()