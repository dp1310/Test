#!/usr/bin/env python3
"""
Simple and focused demo of custom decorators usage.

This example demonstrates the key concepts with clear, easy-to-understand examples:
1. stage_decorator() - Flexible decorator for both sync and async
2. async_stage() - Type-safe async-only decorator
3. Practical usage patterns and best practices
"""

import sys
import os
import asyncio
import time

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import agentic_spine_async, Context, get_logger, setup_logging
from agent_sdk.core.decorators import stage_decorator, async_stage
from agent_sdk.core.stages import Stage

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# =============================================================================
# 1. STAGE_DECORATOR - Flexible sync/async decorator
# =============================================================================

# Create custom decorators using the stage_decorator factory
# These automatically detect whether your function is sync or async
data_loader = stage_decorator(Stage.PERCEIVE)
analyzer = stage_decorator(Stage.REASON)
executor = stage_decorator(Stage.ACT)

@data_loader
def load_data_sync(ctx):
    """
    SYNC function using stage_decorator.
    
    ✅ Automatically detected as sync
    ✅ Adds logging: "Executing PERCEIVE stage: load_data_sync"
    ✅ Sets metadata: _agent_stage=PERCEIVE, _is_async=False
    """
    logger.info("📥 Loading data synchronously...")
    text = ctx.get("input", {}).get("text", "")
    
    return {
        "text": text,
        "word_count": len(text.split()),
        "load_method": "sync",
        "load_time": time.time()
    }

@data_loader
async def load_data_async(ctx):
    """
    ASYNC function using the SAME stage_decorator.
    
    ✅ Automatically detected as async
    ✅ Adds logging: "Executing async PERCEIVE stage: load_data_async"
    ✅ Sets metadata: _agent_stage=PERCEIVE, _is_async=True
    """
    logger.info("📥 Loading data asynchronously...")
    
    # Simulate async I/O (database, API call, etc.)
    await asyncio.sleep(0.1)
    
    text = ctx.get("input", {}).get("text", "")
    
    return {
        "text": text,
        "word_count": len(text.split()),
        "sentiment": "positive" if "good" in text.lower() else "neutral",
        "load_method": "async",
        "load_time": time.time()
    }

@analyzer
def analyze_sync(ctx):
    """SYNC analysis function - fast, simple processing."""
    logger.info("🔍 Analyzing data synchronously...")
    
    word_count = ctx.get("word_count", 0)
    
    return {
        "analysis": "simple" if word_count < 10 else "complex",
        "score": min(word_count / 10, 1.0),
        "method": "sync_analysis"
    }

@analyzer
async def analyze_async(ctx):
    """ASYNC analysis function - complex, ML-based processing."""
    logger.info("🔍 Analyzing data asynchronously with ML...")
    
    # Simulate ML model inference
    await asyncio.sleep(0.2)
    
    word_count = ctx.get("word_count", 0)
    sentiment = ctx.get("sentiment", "neutral")
    
    return {
        "analysis": "ml_based",
        "complexity": "high" if word_count > 15 else "medium" if word_count > 5 else "low",
        "sentiment_confirmed": sentiment,
        "confidence": 0.95,
        "method": "async_ml_analysis"
    }


# =============================================================================
# 2. ASYNC_STAGE - Type-safe async-only decorator
# =============================================================================

# Create async-only decorators - these REQUIRE async functions
async_planner = async_stage(Stage.PLAN)
async_executor = async_stage(Stage.ACT)

@async_planner
async def create_plan(ctx):
    """
    ASYNC-ONLY planning function using async_stage.
    
    ✅ ENFORCES async - would raise ValueError if this was sync
    ✅ Type safety for async-heavy workflows
    ✅ Perfect for I/O-heavy operations like database queries
    """
    logger.info("📋 Creating execution plan asynchronously...")
    
    # Simulate async planning operations
    await asyncio.sleep(0.1)
    
    analysis = ctx.get("analysis", "simple")
    complexity = ctx.get("complexity", "low")
    
    if complexity == "high":
        plan = ["deep_analysis", "expert_review", "detailed_report"]
    elif complexity == "medium":
        plan = ["standard_analysis", "basic_report"]
    else:
        plan = ["quick_check", "summary"]
    
    return {
        "plan": plan,
        "estimated_time": len(plan) * 0.5,
        "planning_method": "async_strategic"
    }

@async_executor
async def execute_plan(ctx):
    """
    ASYNC-ONLY execution function.
    
    ✅ Guaranteed to be async - provides consistency
    ✅ Perfect for concurrent execution of multiple tasks
    """
    logger.info("⚡ Executing plan asynchronously...")
    
    plan = ctx.get("plan", [])
    
    # Execute all plan items concurrently
    async def execute_item(item):
        await asyncio.sleep(0.05)  # Simulate async work
        logger.info(f"✓ Executed: {item}")
        return f"completed_{item}"
    
    # Run all executions concurrently
    results = await asyncio.gather(*[execute_item(item) for item in plan])
    
    return {
        "executed_items": results,
        "total_executed": len(results),
        "execution_method": "async_concurrent",
        "success": True
    }


# =============================================================================
# 3. ERROR HANDLING DEMO
# =============================================================================

def demo_error_handling():
    """Show what happens when you misuse decorators."""
    logger.info("🚨 Demonstrating error handling...")
    
    try:
        # This will FAIL because async_stage requires async functions
        @async_stage(Stage.REASON)
        def sync_function_with_async_decorator(ctx):
            return {"this": "will_not_work"}
        
        logger.error("❌ This should not be reached!")
        
    except ValueError as e:
        logger.info(f"✅ Caught expected error: {e}")
        logger.info("✅ async_stage properly enforces async-only functions")


# =============================================================================
# 4. METADATA INSPECTION
# =============================================================================

def inspect_function_metadata():
    """Show the metadata that decorators add to functions."""
    logger.info("🔍 Inspecting function metadata...")
    
    functions = [
        ("load_data_sync", load_data_sync),
        ("load_data_async", load_data_async),
        ("analyze_sync", analyze_sync),
        ("analyze_async", analyze_async),
        ("create_plan", create_plan),
        ("execute_plan", execute_plan)
    ]
    
    for name, func in functions:
        stage = getattr(func, '_agent_stage', None)
        is_async = getattr(func, '_is_async', None)
        stage_name = stage.name if stage else "Unknown"
        
        logger.info(f"📊 {name}: Stage={stage_name}, Async={is_async}")


# =============================================================================
# 5. WORKFLOW DEMONSTRATIONS
# =============================================================================

async def demo_sync_workflow():
    """Demonstrate a workflow using sync functions."""
    logger.info("\n🔄 SYNC WORKFLOW DEMO")
    logger.info("-" * 40)
    
    result = await agentic_spine_async(
        input_data={"text": "This is a simple sync processing example"},
        functions=[
            load_data_sync,  # Sync data loading
            analyze_sync     # Sync analysis
        ]
    )
    
    logger.info(f"✅ Sync workflow completed: {result.data.get('method')}")
    return result

async def demo_async_workflow():
    """Demonstrate a workflow using async functions."""
    logger.info("\n🔄 ASYNC WORKFLOW DEMO")
    logger.info("-" * 40)
    
    result = await agentic_spine_async(
        input_data={"text": "This is a good example for async ML processing"},
        functions=[
            load_data_async,  # Async data loading
            analyze_async,    # Async ML analysis
            create_plan,      # Async planning
            execute_plan      # Async execution
        ]
    )
    
    logger.info(f"✅ Async workflow completed: {result.data.get('success')}")
    return result

async def demo_mixed_workflow():
    """Demonstrate mixing sync and async functions."""
    logger.info("\n🔄 MIXED WORKFLOW DEMO")
    logger.info("-" * 40)
    
    result = await agentic_spine_async(
        input_data={"text": "Mixed sync and async processing example"},
        functions=[
            load_data_sync,   # Sync loading (fast)
            analyze_async,    # Async analysis (thorough)
            create_plan       # Async planning (strategic)
        ]
    )
    
    logger.info(f"✅ Mixed workflow completed: {result.data.get('planning_method')}")
    return result


# =============================================================================
# 6. MAIN DEMO
# =============================================================================

async def main():
    """Run the complete decorator demonstration."""
    logger.info("🚀 CUSTOM DECORATORS DEMO")
    logger.info("=" * 50)
    
    # 1. Show error handling
    demo_error_handling()
    
    # 2. Inspect metadata
    inspect_function_metadata()
    
    # 3. Run workflow demos
    sync_result = await demo_sync_workflow()
    async_result = await demo_async_workflow()
    mixed_result = await demo_mixed_workflow()
    
    # 4. Summary
    logger.info("\n" + "=" * 50)
    logger.info("🎉 DEMO SUMMARY")
    logger.info("=" * 50)
    
    logger.info("✅ stage_decorator() Features:")
    logger.info("   • Automatically detects sync vs async functions")
    logger.info("   • Flexible - works with both function types")
    logger.info("   • Perfect for gradual migration to async")
    logger.info("   • Adds proper logging and metadata")
    
    logger.info("\n✅ async_stage() Features:")
    logger.info("   • Enforces async-only functions (type safety)")
    logger.info("   • Perfect for async-heavy workflows")
    logger.info("   • Prevents accidental sync function usage")
    logger.info("   • Consistent async execution patterns")
    
    logger.info("\n📊 Workflow Results:")
    logger.info(f"   • Sync workflow: {sync_result.data.get('method', 'completed')}")
    logger.info(f"   • Async workflow: {'success' if async_result.data.get('success') else 'failed'}")
    logger.info(f"   • Mixed workflow: {mixed_result.data.get('planning_method', 'completed')}")
    
    logger.info("\n🎯 Best Practices:")
    logger.info("   • Use stage_decorator() for flexibility")
    logger.info("   • Use async_stage() for type safety")
    logger.info("   • Mix sync/async based on specific needs")
    logger.info("   • Always handle decorator errors properly")
    logger.info("   • Inspect metadata to verify correct setup")


if __name__ == "__main__":
    asyncio.run(main())