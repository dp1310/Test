"""Simplified async agent example without Prefect server overhead."""

import sys
import os
import time
import asyncio
from typing import Any, Dict, List, Callable, Optional

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from agent_sdk.agent import SimpleAsyncAgent
from agent_sdk.core.stages import perceive, reason, plan, act, Stage
from agent_sdk.core.context import Context
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging to see output
setup_logging(level="INFO")
logger = get_logger(__name__)


class EnhancedSimpleAsyncAgent(SimpleAsyncAgent):
    """
    Custom async agent extending SimpleAsyncAgent for faster demonstration.
    
    This agent adds:
    - Execution timing and metrics
    - Custom validation
    - Enhanced logging
    - Pre/post execution hooks
    - Async-specific optimizations
    """
    
    def __init__(
        self,
        functions: Optional[List[Callable]] = None,
        initial_context: Optional[Dict[str, Any]] = None,
        concurrent: Optional[Dict[Stage, bool]] = None,
        workflow_id: Optional[str] = None,
        enable_metrics: bool = True,
        max_execution_time: Optional[float] = None,
        enable_async_optimizations: bool = True
    ):
        """Initialize enhanced simple async agent."""
        super().__init__(functions, initial_context, concurrent, workflow_id)
        self._enable_metrics = enable_metrics
        self._max_execution_time = max_execution_time
        self._enable_async_optimizations = enable_async_optimizations
        self._execution_metrics = {}
        
        # Add custom validation
        self._validate_custom_configuration()
    
    def _validate_custom_configuration(self) -> None:
        """Validate custom agent configuration."""
        if self._max_execution_time is not None and self._max_execution_time <= 0:
            raise ValueError("max_execution_time must be positive")
        
        # Validate that we have functions for all stages if metrics are enabled
        if self._enable_metrics and self._functions:
            stages_present = set()
            for fn in self._functions:
                stage = getattr(fn, "_agent_stage", None)
                if stage:
                    stages_present.add(stage)
            
            logger.info(f"Simple async agent configured with stages: {[s.name for s in stages_present]}")
    
    async def _pre_execution_hook(self, input_data: Any) -> None:
        """Hook called before execution starts."""
        logger.info(f"Enhanced simple async agent starting execution with input: {type(input_data).__name__}")
        
        if self._enable_metrics:
            self._execution_metrics = {
                "start_time": time.time(),
                "input_type": type(input_data).__name__,
                "function_count": len(self._functions),
                "stages": [],
                "async_optimizations": self._enable_async_optimizations
            }
    
    async def _post_execution_hook(self, result: Context) -> None:
        """Hook called after execution completes."""
        if self._enable_metrics:
            end_time = time.time()
            execution_time = end_time - self._execution_metrics["start_time"]
            
            self._execution_metrics.update({
                "end_time": end_time,
                "execution_time": execution_time,
                "result_keys": list(result.data.keys()),
                "success": True
            })
            
            logger.info(f"Enhanced simple async agent execution completed in {execution_time:.3f}s")
            
            # Check execution time limit
            if (self._max_execution_time is not None and 
                execution_time > self._max_execution_time):
                logger.warning(
                    f"Simple async execution time {execution_time:.3f}s exceeded limit "
                    f"{self._max_execution_time}s"
                )
    
    async def execute(self, input_data: Any) -> Context:
        """Execute the agentic workflow asynchronously with enhanced features."""
        # Pre-execution hook
        await self._pre_execution_hook(input_data)
        
        try:
            # Apply timeout if specified
            if self._max_execution_time is not None:
                result = await asyncio.wait_for(
                    super().execute(input_data),
                    timeout=self._max_execution_time
                )
            else:
                result = await super().execute(input_data)
            
            # Post-execution hook
            await self._post_execution_hook(result)
            
            return result
            
        except asyncio.TimeoutError:
            error_msg = f"Simple async execution exceeded timeout of {self._max_execution_time}s"
            if self._enable_metrics:
                self._execution_metrics["success"] = False
                self._execution_metrics["error"] = error_msg
            
            logger.error(f"Enhanced simple async agent execution timed out: {error_msg}")
            raise TimeoutError(error_msg)
            
        except Exception as e:
            if self._enable_metrics:
                self._execution_metrics["success"] = False
                self._execution_metrics["error"] = str(e)
            
            logger.error(f"Enhanced simple async agent execution failed: {e}")
            raise
    
    def get_execution_metrics(self) -> Dict[str, Any]:
        """Get execution metrics from the last run."""
        return self._execution_metrics.copy()
    
    def get_execution_type(self) -> str:
        """Get the execution type identifier."""
        return "enhanced_simple_async"
    
    async def execute_batch(self, input_batch: List[Any]) -> List[Context]:
        """Execute multiple workflows concurrently."""
        logger.info(f"Executing batch of {len(input_batch)} workflows concurrently")
        
        if self._enable_async_optimizations:
            # Execute all workflows concurrently
            tasks = [self.execute(input_data) for input_data in input_batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Handle any exceptions
            final_results = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error(f"Batch execution {i} failed: {result}")
                    raise result
                final_results.append(result)
            
            return final_results
        else:
            # Execute sequentially
            results = []
            for input_data in input_batch:
                result = await self.execute(input_data)
                results.append(result)
            return results
    
    def __str__(self) -> str:
        """String representation."""
        return (
            f"EnhancedSimpleAsyncAgent("
            f"functions={len(self._functions)}, "
            f"metrics={self._enable_metrics}, "
            f"max_time={self._max_execution_time}, "
            f"async_opts={self._enable_async_optimizations})"
        )


# Example async stage functions for demonstration
@perceive
async def simple_async_perceive(context: Dict[str, Any]) -> Dict[str, Any]:
    """Simple async perceive stage with detailed logging."""
    input_data = context.get("input", {})
    logger.info(f"Simple async perceiving: {input_data}")
    
    # Simulate async I/O operation
    await asyncio.sleep(0.05)
    
    return {
        "perceived_data": f"simple_async_processed_{input_data}",
        "perception_timestamp": time.time(),
        "perception_quality": "high",
        "async_processing": True
    }


@reason
async def simple_async_reason(context: Dict[str, Any]) -> Dict[str, Any]:
    """Simple async reason stage with analysis metrics."""
    perceived = context.get("perceived_data", "")
    quality = context.get("perception_quality", "unknown")
    
    logger.info(f"Simple async reasoning on: {perceived} (quality: {quality})")
    
    # Simulate async reasoning with concurrent operations
    analysis_task = asyncio.create_task(asyncio.sleep(0.03))
    confidence_task = asyncio.create_task(asyncio.sleep(0.02))
    
    await asyncio.gather(analysis_task, confidence_task)
    
    confidence = 0.95 if quality == "high" else 0.7
    
    return {
        "analysis": f"simple_async_analyzed_{perceived}",
        "confidence": confidence,
        "reasoning_method": "simple_async_algorithm",
        "analysis_timestamp": time.time(),
        "concurrent_processing": True
    }


@plan
async def simple_async_plan(context: Dict[str, Any]) -> Dict[str, Any]:
    """Simple async plan stage with strategy selection."""
    analysis = context.get("analysis", "")
    confidence = context.get("confidence", 0.5)
    
    logger.info(f"Simple async planning based on: {analysis} (confidence: {confidence})")
    
    # Simulate async planning
    await asyncio.sleep(0.02)
    
    # Choose strategy based on confidence
    strategy = "aggressive" if confidence > 0.8 else "conservative"
    
    return {
        "plan": f"simple_async_plan_for_{analysis}",
        "strategy": strategy,
        "plan_confidence": confidence,
        "plan_timestamp": time.time()
    }


@act
async def simple_async_act(context: Dict[str, Any]) -> Dict[str, Any]:
    """Simple async act stage with execution tracking."""
    plan = context.get("plan", "")
    strategy = context.get("strategy", "default")
    
    logger.info(f"Simple async executing: {plan} (strategy: {strategy})")
    
    # Simulate async execution
    execution_time = 0.04 if strategy == "aggressive" else 0.02
    await asyncio.sleep(execution_time)
    
    return {
        "result": f"simple_async_executed_{plan}",
        "execution_strategy": strategy,
        "execution_duration": execution_time,
        "execution_timestamp": time.time(),
        "success": True
    }


async def demonstrate_simple_async_agent():
    """Demonstrate the simple enhanced async agent."""
    logger.info("\n=== Simple Enhanced Async Agent Demo ===")
    
    # Create enhanced simple async agent
    agent = EnhancedSimpleAsyncAgent(
        functions=[simple_async_perceive, simple_async_reason, simple_async_plan, simple_async_act],
        initial_context={"mode": "simple_async_enhanced", "version": "1.0"},
        concurrent={Stage.REASON: True, Stage.PLAN: True},
        workflow_id="simple_async_demo",
        enable_metrics=True,
        max_execution_time=5.0,
        enable_async_optimizations=True
    )
    
    logger.info(f"Created simple async agent: {agent}")
    logger.info(f"Agent type: {agent.get_execution_type()}")
    
    # Execute workflow
    result = await agent.execute("simple_async_test_input")
    
    logger.info(f"\nSimple async execution result keys: {list(result.data.keys())}")
    logger.info(f"Final result: {result.data.get('result')}")
    logger.info(f"Strategy used: {result.data.get('execution_strategy')}")
    logger.info(f"Success: {result.data.get('success')}")
    logger.info(f"Async processing: {result.data.get('async_processing')}")
    
    # Show metrics
    metrics = agent.get_execution_metrics()
    logger.info(f"\nSimple Async Execution Metrics:")
    logger.info(f"  Execution time: {metrics.get('execution_time', 0):.3f}s")
    logger.info(f"  Function count: {metrics.get('function_count')}")
    logger.info(f"  Success: {metrics.get('success')}")
    logger.info(f"  Async optimizations: {metrics.get('async_optimizations')}")


async def demonstrate_batch_execution():
    """Demonstrate batch execution with simple async agent."""
    logger.info("\n=== Simple Async Batch Execution Demo ===")
    
    agent = EnhancedSimpleAsyncAgent(
        functions=[simple_async_perceive, simple_async_reason],
        enable_metrics=True,
        enable_async_optimizations=True,
        workflow_id="simple_batch_demo"
    )
    
    # Execute batch of workflows
    batch_inputs = [f"batch_input_{i}" for i in range(3)]
    start_time = time.time()
    
    results = await agent.execute_batch(batch_inputs)
    
    batch_time = time.time() - start_time
    logger.info(f"Simple batch execution completed in {batch_time:.3f}s")
    logger.info(f"Processed {len(results)} workflows concurrently")
    
    for i, result in enumerate(results):
        logger.info(f"  Batch {i}: {result.data.get('perceived_data')}")


async def demonstrate_timeout_handling():
    """Demonstrate timeout handling in simple async agent."""
    logger.info("\n=== Simple Async Timeout Handling Demo ===")
    
    @perceive
    async def slow_perceive(context: Dict[str, Any]) -> Dict[str, Any]:
        """A slow perceive function that will timeout."""
        await asyncio.sleep(2.0)  # Longer than timeout
        return {"data": "slow_result"}
    
    # Create agent with short timeout
    agent = EnhancedSimpleAsyncAgent(
        functions=[slow_perceive],
        enable_metrics=True,
        max_execution_time=1.0,  # Short timeout
        workflow_id="simple_timeout_demo"
    )
    
    try:
        result = await agent.execute("timeout_input")
    except TimeoutError as e:
        logger.info(f"Caught expected timeout: {e}")
        
        # Check metrics recorded the timeout
        metrics = agent.get_execution_metrics()
        logger.info(f"Timeout recorded in metrics: {not metrics.get('success', True)}")
        logger.info(f"Error message: {metrics.get('error')}")


async def main():
    """Main simple async demonstration function."""
    logger.info("Simple Custom Async Agent Framework Demonstration")
    logger.info("=" * 55)
    
    await demonstrate_simple_async_agent()
    await demonstrate_batch_execution()
    await demonstrate_timeout_handling()
    
    logger.info("\n=== Simple Custom Async Agent Demo Complete ===")


if __name__ == "__main__":
    asyncio.run(main())