"""Demo of async Prefect integration."""

import sys
import os
import asyncio
import time

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, plan, act, Stage,
    agentic_spine_async_prefect,  # New async Prefect version
    agentic_spine_async,          # Simple async version
    Context, get_logger, setup_logging
)
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


async def demo_async_prefect():
    """Demo the async Prefect version."""
    logger.info("🔧 ASYNC PREFECT DEMO")
    logger.info("=" * 40)
    
    @perceive
    @task(name="async_perceive_1", cache_policy=NO_CACHE)
    async def async_perceive_1(ctx: dict) -> dict:
        """Async Prefect task for perception."""
        text = ctx.get("input", {}).get("text", "")
        logger.info(f"[ASYNC PREFECT TASK 1] Processing: {text[:30]}...")
        await asyncio.sleep(0.1)  # Simulate async work
        logger.info("[ASYNC PREFECT TASK 1] Completed")
        return {"task_1": "completed", "word_count": len(text.split())}
    
    @perceive
    @task(name="async_perceive_2", cache_policy=NO_CACHE)
    async def async_perceive_2(ctx: dict) -> dict:
        """Another async Prefect task for perception."""
        text = ctx.get("input", {}).get("text", "")
        logger.info(f"[ASYNC PREFECT TASK 2] Analyzing sentiment...")
        await asyncio.sleep(0.05)  # Simulate async work
        
        sentiment = "positive" if "good" in text.lower() else "neutral"
        logger.info(f"[ASYNC PREFECT TASK 2] Sentiment: {sentiment}")
        return {"task_2": "completed", "sentiment": sentiment}
    
    @reason
    @task(name="async_reason", cache_policy=NO_CACHE)
    async def async_reason(ctx: dict) -> dict:
        """Async reasoning task."""
        word_count = ctx.get("word_count", 0)
        sentiment = ctx.get("sentiment", "neutral")
        
        logger.info(f"[ASYNC PREFECT REASON] word_count={word_count}, sentiment={sentiment}")
        await asyncio.sleep(0.02)
        
        priority = "high" if word_count > 10 or sentiment == "positive" else "normal"
        return {"priority": priority, "reasoning_done": True}
    
    @plan
    @task(name="async_plan", cache_policy=NO_CACHE)
    async def async_plan(ctx: dict) -> dict:
        """Async planning task."""
        priority = ctx.get("priority", "normal")
        logger.info(f"[ASYNC PREFECT PLAN] Creating plan for priority: {priority}")
        await asyncio.sleep(0.03)
        
        actions = ["celebrate", "share"] if priority == "high" else ["process", "store"]
        return {"actions": actions, "plan_ready": True}
    
    @act
    @task(name="async_act", cache_policy=NO_CACHE)
    async def async_act(ctx: dict) -> dict:
        """Async action execution."""
        actions = ctx.get("actions", [])
        logger.info(f"[ASYNC PREFECT ACT] Executing {len(actions)} actions")
        
        executed = []
        for action in actions:
            await asyncio.sleep(0.01)  # Simulate async execution
            executed.append(f"✓ {action}")
            logger.info(f"[ASYNC PREFECT ACT] Executed: {action}")
        
        return {"executed": executed, "all_done": True}
    
    # Test async Prefect execution
    logger.info("Starting async Prefect workflow...")
    start_time = time.time()
    
    result = await agentic_spine_async_prefect(
        input_data={"text": "This is a good message with many words for testing"},
        functions=[async_perceive_1, async_perceive_2, async_reason, async_plan, async_act],
        concurrent={
            Stage.PERCEIVE: True,  # Run perception tasks concurrently
            Stage.REASON: False,   # Sequential reasoning
            Stage.PLAN: False,     # Sequential planning
            Stage.ACT: False       # Sequential actions
        }
    )
    
    end_time = time.time()
    
    logger.info(f"Async Prefect completed in {end_time - start_time:.3f} seconds")
    logger.info(f"Priority: {result.get('priority')}")
    logger.info(f"Sentiment: {result.get('sentiment')}")
    logger.info(f"Executed: {result.get('executed')}")
    logger.info(f"All tasks completed: {result.get('all_done')}")
    
    return result, end_time - start_time


async def demo_comparison():
    """Compare async simple vs async Prefect."""
    logger.info("\n🔍 ASYNC COMPARISON")
    logger.info("=" * 40)
    
    # Simple async functions
    @perceive
    async def simple_perceive(ctx: Context) -> dict:
        text = ctx.get("input", {}).get("text", "")
        logger.info("[SIMPLE ASYNC] Processing...")
        await asyncio.sleep(0.1)
        return {"simple_processed": True, "word_count": len(text.split())}
    
    @reason
    async def simple_reason(ctx: Context) -> dict:
        logger.info("[SIMPLE ASYNC] Reasoning...")
        await asyncio.sleep(0.02)
        return {"simple_decision": "approve"}
    
    # Test simple async
    logger.info("Testing simple async version...")
    start_time = time.time()
    
    simple_result = await agentic_spine_async(
        input_data={"text": "Test message for comparison"},
        functions=[simple_perceive, simple_reason]
    )
    
    simple_time = time.time() - start_time
    logger.info(f"Simple async completed in {simple_time:.3f} seconds")
    
    # Prefect async functions
    @perceive
    @task(name="prefect_perceive", cache_policy=NO_CACHE)
    async def prefect_perceive(ctx: dict) -> dict:
        text = ctx.get("input", {}).get("text", "")
        logger.info("[PREFECT ASYNC] Processing...")
        await asyncio.sleep(0.1)
        return {"prefect_processed": True, "word_count": len(text.split())}
    
    @reason
    @task(name="prefect_reason", cache_policy=NO_CACHE)
    async def prefect_reason(ctx: dict) -> dict:
        logger.info("[PREFECT ASYNC] Reasoning...")
        await asyncio.sleep(0.02)
        return {"prefect_decision": "approve"}
    
    # Test Prefect async
    logger.info("Testing Prefect async version...")
    start_time = time.time()
    
    prefect_result = await agentic_spine_async_prefect(
        input_data={"text": "Test message for comparison"},
        functions=[prefect_perceive, prefect_reason]
    )
    
    prefect_time = time.time() - start_time
    logger.info(f"Prefect async completed in {prefect_time:.3f} seconds")
    
    # Comparison
    logger.info("\n📊 COMPARISON RESULTS:")
    logger.info(f"Simple async time: {simple_time:.3f}s")
    logger.info(f"Prefect async time: {prefect_time:.3f}s")
    logger.info(f"Simple result: {simple_result.get('simple_decision')}")
    logger.info(f"Prefect result: {prefect_result.get('prefect_decision')}")
    
    return simple_time, prefect_time


async def main():
    """Run all async demos."""
    logger.info("🚀 ASYNC PREFECT INTEGRATION DEMO")
    logger.info("=" * 50)
    
    # Demo 1: Async Prefect workflow
    prefect_result, prefect_time = await demo_async_prefect()
    
    # Demo 2: Comparison
    simple_time, prefect_async_time = await demo_comparison()
    
    # Summary
    logger.info("\n" + "=" * 50)
    logger.info("🎉 ASYNC DEMO SUMMARY")
    logger.info("=" * 50)
    logger.info("✅ Async Prefect integration working")
    logger.info("✅ Concurrent async task execution")
    logger.info("✅ Mixed async/sync task support")
    logger.info("✅ Full Prefect orchestration with async")
    
    logger.info("\n📋 Available Async Options:")
    logger.info("   • agentic_spine_async() - Simple async execution")
    logger.info("   • agentic_spine_async_prefect() - Prefect async execution")
    logger.info("   • Both support concurrent={Stage.X: True}")
    logger.info("   • Both support mixed async/sync functions")
    
    logger.info(f"\n⚡ Performance:")
    logger.info(f"   • Complex async Prefect workflow: {prefect_time:.3f}s")
    logger.info(f"   • Simple async workflow: {simple_time:.3f}s")
    logger.info(f"   • Prefect async workflow: {prefect_async_time:.3f}s")


if __name__ == "__main__":
    asyncio.run(main())