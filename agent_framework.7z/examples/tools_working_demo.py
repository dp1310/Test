#!/usr/bin/env python3
"""
Working demo of the tools system with file operations.

This example demonstrates the tools system working with actual file operations
and shows how tools integrate seamlessly with agentic workflows.
"""

import sys
import os
import asyncio
import time
from typing import Dict, Any

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    agentic_spine_async, perceive, reason, plan, act,
    Context, Stage, get_logger, setup_logging
)
from agent_sdk.tools import (
    tool_hook, get_available_tools, execute_tool,
    load_tools_config
)

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


@perceive
@tool_hook
async def collect_system_info(ctx: Context, tools) -> Dict[str, Any]:
    """Collect system information using tools."""
    logger.info("📊 Collecting system information...")
    
    # Get available tools
    available_tools = tools.get_available_tools()
    logger.info(f"Available tools: {available_tools}")
    
    # Create a system info report
    system_info = {
        "timestamp": time.time(),
        "available_tools": available_tools,
        "tool_categories": {}
    }
    
    # Get tools by category
    for category in ['llm', 'database', 'api', 'utility']:
        category_tools = tools.get_available_tools(category)
        system_info["tool_categories"][category] = category_tools
    
    return {
        "system_info": system_info,
        "collection_complete": True
    }


@reason
@tool_hook
async def analyze_tool_availability(ctx: Context, tools) -> Dict[str, Any]:
    """Analyze which tools are available and create recommendations."""
    logger.info("🔍 Analyzing tool availability...")
    
    system_info = ctx.get("system_info", {})
    available_tools = system_info.get("available_tools", [])
    
    # Analyze tool availability
    analysis = {
        "total_tools": len(available_tools),
        "has_file_tools": 'file_manager' in available_tools,
        "has_http_tools": 'http_client' in available_tools,
        "has_llm_tools": any('llm' in str(tool) for tool in available_tools),
        "recommendations": []
    }
    
    # Generate recommendations
    if analysis["has_file_tools"]:
        analysis["recommendations"].append("File operations available")
    if analysis["has_http_tools"]:
        analysis["recommendations"].append("HTTP requests available")
    if not analysis["has_llm_tools"]:
        analysis["recommendations"].append("Consider adding LLM API keys for AI features")
    
    return {
        "analysis": analysis,
        "analysis_complete": True
    }


@plan
@tool_hook
async def create_demo_plan(ctx: Context, tools) -> Dict[str, Any]:
    """Create a plan for demonstrating available tools."""
    logger.info("📋 Creating demonstration plan...")
    
    analysis = ctx.get("analysis", {})
    
    # Create plan based on available tools
    plan = {
        "actions": [],
        "estimated_duration": 0
    }
    
    if analysis.get("has_file_tools"):
        plan["actions"].extend([
            "create_demo_file",
            "read_demo_file",
            "list_files"
        ])
        plan["estimated_duration"] += 3
    
    if analysis.get("has_http_tools"):
        plan["actions"].append("test_http_request")
        plan["estimated_duration"] += 2
    
    plan["actions"].append("generate_report")
    plan["estimated_duration"] += 1
    
    return {
        "plan": plan,
        "plan_ready": True
    }


@act
@tool_hook
async def execute_demo_plan(ctx: Context, tools) -> Dict[str, Any]:
    """Execute the demonstration plan using available tools."""
    logger.info("⚡ Executing demonstration plan...")
    
    plan = ctx.get("plan", {})
    actions = plan.get("actions", [])
    results = []
    
    for action in actions:
        logger.info(f"Executing: {action}")
        
        if action == "create_demo_file":
            result = await tools.execute(
                'file_manager',
                operation='write',
                file_path='demo_output.txt',
                content=f'Tools Demo Output\nGenerated at: {time.ctime()}\n\nThis file was created by the tools system!'
            )
            if result.is_success:
                results.append(f"✅ {action}: File created successfully")
            else:
                results.append(f"❌ {action}: {result.error}")
        
        elif action == "read_demo_file":
            result = await tools.execute(
                'file_manager',
                operation='read',
                file_path='demo_output.txt'
            )
            if result.is_success:
                content = result.data.get('content', '')
                results.append(f"✅ {action}: Read {len(content)} characters")
            else:
                results.append(f"❌ {action}: {result.error}")
        
        elif action == "list_files":
            result = await tools.execute(
                'file_manager',
                operation='list',
                file_path='.'
            )
            if result.is_success:
                file_count = result.data.get('count', 0)
                results.append(f"✅ {action}: Found {file_count} files")
            else:
                results.append(f"❌ {action}: {result.error}")
        
        elif action == "test_http_request":
            result = await tools.execute(
                'http_client',
                method='GET',
                url='https://httpbin.org/json'
            )
            if result.is_success:
                status = result.data.get('status_code', 0)
                results.append(f"✅ {action}: HTTP {status}")
            else:
                results.append(f"❌ {action}: {result.error}")
        
        elif action == "generate_report":
            # Generate final report
            report_content = f"""
Tools System Demonstration Report
================================

Generated: {time.ctime()}

Executed Actions:
{chr(10).join(f'- {r}' for r in results)}

System Info:
- Available Tools: {len(ctx.get('system_info', {}).get('available_tools', []))}
- File Operations: {'✅' if ctx.get('analysis', {}).get('has_file_tools') else '❌'}
- HTTP Operations: {'✅' if ctx.get('analysis', {}).get('has_http_tools') else '❌'}

This report demonstrates the tools system working with agentic workflows!
"""
            
            result = await tools.execute(
                'file_manager',
                operation='write',
                file_path='tools_demo_report.txt',
                content=report_content
            )
            
            if result.is_success:
                results.append(f"✅ {action}: Report generated")
            else:
                results.append(f"❌ {action}: {result.error}")
    
    return {
        "results": results,
        "total_actions": len(actions),
        "execution_complete": True,
        "success": all("✅" in r for r in results)
    }


async def main():
    """Run the working tools demonstration."""
    logger.info("🚀 TOOLS SYSTEM WORKING DEMO")
    logger.info("=" * 50)
    
    # Run the workflow
    result = await agentic_spine_async(
        input_data={"demo_type": "working_tools"},
        functions=[
            collect_system_info,
            analyze_tool_availability,
            create_demo_plan,
            execute_demo_plan
        ],
        workflow_id="working_tools_demo"
    )
    
    # Display results
    logger.info("\n" + "=" * 50)
    logger.info("🎉 DEMO RESULTS")
    logger.info("=" * 50)
    
    system_info = result.data.get("system_info", {})
    analysis = result.data.get("analysis", {})
    results = result.data.get("results", [])
    
    logger.info(f"✅ Available Tools: {len(system_info.get('available_tools', []))}")
    logger.info(f"✅ Total Actions: {result.data.get('total_actions', 0)}")
    logger.info(f"✅ Success Rate: {len([r for r in results if '✅' in r])}/{len(results)}")
    
    logger.info("\n📋 Action Results:")
    for result_item in results:
        logger.info(f"   {result_item}")
    
    logger.info("\n💡 Recommendations:")
    for rec in analysis.get("recommendations", []):
        logger.info(f"   • {rec}")
    
    logger.info("\n📁 Generated Files:")
    logger.info("   • demo_output.txt - Basic demo file")
    logger.info("   • tools_demo_report.txt - Comprehensive report")
    
    logger.info("\n🎯 Key Features Demonstrated:")
    logger.info("   • @tool_hook decorator integration")
    logger.info("   • File operations with error handling")
    logger.info("   • HTTP requests (if available)")
    logger.info("   • Dynamic tool discovery")
    logger.info("   • Fallback strategies")
    logger.info("   • Report generation")


if __name__ == "__main__":
    asyncio.run(main())