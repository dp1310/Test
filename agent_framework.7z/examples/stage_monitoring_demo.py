#!/usr/bin/env python3
"""
Comprehensive demo of stage state monitoring system.

This example demonstrates:
1. Real-time stage state tracking (PENDING, STARTED, RUNNING, COMPLETED, ERROR)
2. Custom observers for monitoring and metrics collection
3. Workflow-level monitoring and reporting
4. Integration with all execution modes
5. Performance metrics and error tracking
"""

import sys
import os
import asyncio
import time
import json
from typing import Dict, Any, List

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    agentic_spine_async, agentic_spine_async_prefect, agentic_spine,
    perceive, reason, plan, act, Context, Stage, get_logger, setup_logging
)
from agent_sdk.core.state import (
    StageStateObserver, StageExecution, StageState, get_state_manager,
    configure_monitoring, get_workflow_status, get_metrics, LoggingObserver, MetricsObserver
)
from agent_sdk.core.decorators import stage_decorator, async_stage
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# =============================================================================
# 1. CUSTOM OBSERVERS FOR MONITORING
# =============================================================================

class DashboardObserver(StageStateObserver):
    """Custom observer that simulates a monitoring dashboard."""
    
    def __init__(self):
        self.dashboard_data = {
            "active_workflows": {},
            "stage_history": [],
            "alerts": []
        }
    
    def on_stage_state_changed(self, execution: StageExecution) -> None:
        """Update dashboard with stage state changes."""
        # Add to history
        self.dashboard_data["stage_history"].append({
            "timestamp": time.time(),
            "stage": execution.stage.name,
            "state": execution.state.value,
            "function": execution.function_name,
            "execution_id": execution.execution_id,
            "duration": execution.duration
        })
        
        # Generate alerts for errors
        if execution.state == StageState.ERROR:
            alert = {
                "timestamp": time.time(),
                "type": "ERROR",
                "message": f"Stage {execution.stage.name} failed: {execution.error}",
                "execution_id": execution.execution_id
            }
            self.dashboard_data["alerts"].append(alert)
            logger.warning(f"🚨 ALERT: {alert['message']}")
        
        # Track long-running stages
        if execution.state == StageState.RUNNING and execution.duration and execution.duration > 5.0:
            alert = {
                "timestamp": time.time(),
                "type": "PERFORMANCE",
                "message": f"Stage {execution.stage.name} running for {execution.duration:.1f}s",
                "execution_id": execution.execution_id
            }
            self.dashboard_data["alerts"].append(alert)
            logger.warning(f"⏰ PERFORMANCE ALERT: {alert['message']}")
    
    def on_workflow_started(self, workflow_id: str) -> None:
        """Track workflow start."""
        self.dashboard_data["active_workflows"][workflow_id] = {
            "start_time": time.time(),
            "status": "running",
            "stages_completed": 0,
            "stages_failed": 0
        }
        logger.info(f"📊 DASHBOARD: Workflow {workflow_id} started")
    
    def on_workflow_completed(self, workflow_id: str, executions: List[StageExecution]) -> None:
        """Track workflow completion."""
        if workflow_id in self.dashboard_data["active_workflows"]:
            workflow_data = self.dashboard_data["active_workflows"][workflow_id]
            workflow_data["status"] = "completed"
            workflow_data["end_time"] = time.time()
            workflow_data["total_duration"] = workflow_data["end_time"] - workflow_data["start_time"]
            workflow_data["stages_completed"] = sum(1 for e in executions if e.state == StageState.COMPLETED)
            workflow_data["stages_failed"] = sum(1 for e in executions if e.state == StageState.ERROR)
        
        logger.info(f"📊 DASHBOARD: Workflow {workflow_id} completed")
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get current dashboard data."""
        return self.dashboard_data
    
    def get_recent_activity(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent stage activity."""
        return self.dashboard_data["stage_history"][-limit:]
    
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """Get active alerts."""
        # Return alerts from last 5 minutes
        current_time = time.time()
        return [
            alert for alert in self.dashboard_data["alerts"]
            if current_time - alert["timestamp"] < 300  # 5 minutes
        ]


class WebhookObserver(StageStateObserver):
    """Observer that simulates sending webhooks for external monitoring."""
    
    def __init__(self, webhook_url: str = "https://api.example.com/webhooks"):
        self.webhook_url = webhook_url
        self.webhook_queue = []
    
    def on_stage_state_changed(self, execution: StageExecution) -> None:
        """Queue webhook for stage state change."""
        webhook_data = {
            "event": "stage_state_changed",
            "timestamp": time.time(),
            "data": execution.to_dict()
        }
        self.webhook_queue.append(webhook_data)
        
        # Simulate sending webhook (in real implementation, this would be async HTTP call)
        logger.info(f"🔗 WEBHOOK: Queued stage state change for {execution.stage.name}")
    
    def on_workflow_completed(self, workflow_id: str, executions: List[StageExecution]) -> None:
        """Queue webhook for workflow completion."""
        webhook_data = {
            "event": "workflow_completed",
            "timestamp": time.time(),
            "data": {
                "workflow_id": workflow_id,
                "total_stages": len(executions),
                "completed": sum(1 for e in executions if e.state == StageState.COMPLETED),
                "failed": sum(1 for e in executions if e.state == StageState.ERROR),
                "total_duration": sum(e.duration or 0 for e in executions if e.duration)
            }
        }
        self.webhook_queue.append(webhook_data)
        logger.info(f"🔗 WEBHOOK: Queued workflow completion for {workflow_id}")
    
    def get_queued_webhooks(self) -> List[Dict[str, Any]]:
        """Get queued webhooks (for testing)."""
        return self.webhook_queue


# =============================================================================
# 2. DEMO FUNCTIONS WITH DIFFERENT BEHAVIORS
# =============================================================================

# Create custom decorators
data_processor = stage_decorator(Stage.PERCEIVE)
analyzer = stage_decorator(Stage.REASON)
planner = async_stage(Stage.PLAN)
executor = stage_decorator(Stage.ACT)

@data_processor
def fast_data_load(ctx):
    """Fast data loading function."""
    logger.info("⚡ Fast data loading...")
    time.sleep(0.1)  # Simulate quick processing
    text = ctx.get("input", {}).get("text", "")
    return {"text": text, "word_count": len(text.split()), "method": "fast"}

@data_processor
async def slow_data_load(ctx):
    """Slow data loading function."""
    logger.info("🐌 Slow data loading...")
    await asyncio.sleep(1.0)  # Simulate slow processing
    text = ctx.get("input", {}).get("text", "")
    return {"text": text, "word_count": len(text.split()), "method": "slow", "detailed": True}

@analyzer
def quick_analysis(ctx):
    """Quick analysis function."""
    logger.info("🔍 Quick analysis...")
    time.sleep(0.2)
    word_count = ctx.get("word_count", 0)
    return {"analysis": "simple", "complexity": "low" if word_count < 10 else "high"}

@analyzer
async def deep_analysis(ctx):
    """Deep analysis function."""
    logger.info("🧠 Deep analysis...")
    await asyncio.sleep(0.8)  # Simulate ML processing
    word_count = ctx.get("word_count", 0)
    sentiment = "positive" if "good" in ctx.get("text", "").lower() else "neutral"
    return {
        "analysis": "deep",
        "complexity": "high" if word_count > 15 else "medium" if word_count > 5 else "low",
        "sentiment": sentiment,
        "confidence": 0.95
    }

@analyzer
def error_analysis(ctx):
    """Analysis function that always fails."""
    logger.info("💥 Error analysis...")
    time.sleep(0.1)
    raise ValueError("Simulated analysis error for testing")

@planner
async def strategic_planning(ctx):
    """Strategic planning function."""
    logger.info("📋 Strategic planning...")
    await asyncio.sleep(0.5)
    
    complexity = ctx.get("complexity", "low")
    analysis_type = ctx.get("analysis", "simple")
    
    if complexity == "high" and analysis_type == "deep":
        plan = ["detailed_review", "expert_consultation", "comprehensive_report"]
    elif complexity == "medium":
        plan = ["standard_review", "basic_report"]
    else:
        plan = ["quick_check", "summary"]
    
    return {"plan": plan, "estimated_time": len(plan) * 0.3}

@executor
async def execute_actions(ctx):
    """Execute planned actions."""
    logger.info("⚡ Executing actions...")
    
    plan = ctx.get("plan", ["default_action"])
    executed = []
    
    for action in plan:
        await asyncio.sleep(0.1)  # Simulate action execution
        executed.append(f"✓ {action}")
        logger.info(f"   Executed: {action}")
    
    return {"executed": executed, "total_actions": len(executed), "success": True}


# =============================================================================
# 3. MONITORING CONFIGURATION
# =============================================================================

def setup_comprehensive_monitoring():
    """Set up comprehensive monitoring with multiple observers."""
    logger.info("🔧 Setting up comprehensive monitoring...")
    
    # Create custom observers
    dashboard_observer = DashboardObserver()
    webhook_observer = WebhookObserver()
    
    # Configure monitoring with all observers
    state_manager = configure_monitoring(
        enable_logging=True,
        enable_metrics=True,
        custom_observers=[dashboard_observer, webhook_observer]
    )
    
    logger.info("✅ Monitoring configured with:")
    logger.info("   • Logging Observer - Real-time log output")
    logger.info("   • Metrics Observer - Performance statistics")
    logger.info("   • Dashboard Observer - Simulated monitoring dashboard")
    logger.info("   • Webhook Observer - External system notifications")
    
    return state_manager, dashboard_observer, webhook_observer


# =============================================================================
# 4. WORKFLOW DEMONSTRATIONS
# =============================================================================

async def demo_successful_workflow():
    """Demonstrate a successful workflow with monitoring."""
    logger.info("\n🎯 DEMO: Successful Workflow")
    logger.info("-" * 50)
    
    workflow_id = "successful_workflow_001"
    
    result = await agentic_spine_async(
        input_data={"text": "This is a good example for comprehensive analysis"},
        functions=[fast_data_load, deep_analysis, strategic_planning, execute_actions],
        workflow_id=workflow_id
    )
    
    # Get workflow status
    status = get_workflow_status(workflow_id)
    logger.info(f"📊 Workflow Status: {status['status']}")
    logger.info(f"📊 Completed Stages: {status['completed']}/{status['total_stages']}")
    logger.info(f"📊 Total Duration: {status['total_duration']:.3f}s")
    
    return result, status

async def demo_workflow_with_errors():
    """Demonstrate a workflow with errors for monitoring."""
    logger.info("\n💥 DEMO: Workflow with Errors")
    logger.info("-" * 50)
    
    workflow_id = "error_workflow_001"
    
    try:
        result = await agentic_spine_async(
            input_data={"text": "This will trigger an error"},
            functions=[fast_data_load, error_analysis, strategic_planning],
            workflow_id=workflow_id
        )
    except Exception as e:
        logger.info(f"Expected error caught: {e}")
    
    # Get workflow status
    status = get_workflow_status(workflow_id)
    logger.info(f"📊 Workflow Status: {status['status']}")
    logger.info(f"📊 Errors: {status['errors']}")
    
    return status

async def demo_concurrent_workflow():
    """Demonstrate concurrent execution with monitoring."""
    logger.info("\n🔀 DEMO: Concurrent Workflow")
    logger.info("-" * 50)
    
    workflow_id = "concurrent_workflow_001"
    
    # Create multiple perception tasks for concurrent execution
    @data_processor
    async def perception_task_1(ctx):
        logger.info("🔄 Perception Task 1...")
        await asyncio.sleep(0.3)
        return {"task_1": "completed", "data_1": "processed"}
    
    @data_processor
    async def perception_task_2(ctx):
        logger.info("🔄 Perception Task 2...")
        await asyncio.sleep(0.2)
        return {"task_2": "completed", "data_2": "processed"}
    
    result = await agentic_spine_async(
        input_data={"text": "Concurrent processing example"},
        functions=[perception_task_1, perception_task_2, quick_analysis],
        concurrent={Stage.PERCEIVE: True},  # Enable concurrent execution
        workflow_id=workflow_id
    )
    
    status = get_workflow_status(workflow_id)
    logger.info(f"📊 Concurrent Workflow Status: {status['status']}")
    
    return result, status

async def demo_prefect_async_monitoring():
    """Demonstrate Prefect async execution with monitoring."""
    logger.info("\n🚀 DEMO: Prefect Async with Monitoring")
    logger.info("-" * 50)
    
    workflow_id = "prefect_async_workflow_001"
    
    # Create Prefect tasks
    @task(name="prefect_data_load", cache_policy=NO_CACHE)
    async def prefect_data_load(ctx: dict) -> dict:
        logger.info("🔄 Prefect async data loading...")
        await asyncio.sleep(0.4)
        text = ctx.get("input", {}).get("text", "")
        return {"text": text, "word_count": len(text.split()), "method": "prefect_async"}
    
    @task(name="prefect_analysis", cache_policy=NO_CACHE)
    async def prefect_analysis(ctx: dict) -> dict:
        logger.info("🧠 Prefect async analysis...")
        await asyncio.sleep(0.3)
        word_count = ctx.get("word_count", 0)
        return {"analysis": "prefect_deep", "score": word_count * 0.1}
    
    # Add stage decorators
    prefect_data_load = data_processor(prefect_data_load)
    prefect_analysis = analyzer(prefect_analysis)
    
    result = await agentic_spine_async_prefect(
        input_data={"text": "Prefect async monitoring example"},
        functions=[prefect_data_load, prefect_analysis],
        workflow_id=workflow_id
    )
    
    status = get_workflow_status(workflow_id)
    logger.info(f"📊 Prefect Async Status: {status['status']}")
    
    return result, status


# =============================================================================
# 5. MONITORING DASHBOARD SIMULATION
# =============================================================================

def display_monitoring_dashboard(dashboard_observer: DashboardObserver, metrics_data: Dict[str, Any]):
    """Display a simulated monitoring dashboard."""
    logger.info("\n" + "=" * 60)
    logger.info("📊 MONITORING DASHBOARD")
    logger.info("=" * 60)
    
    # Active workflows
    dashboard_data = dashboard_observer.get_dashboard_data()
    active_workflows = dashboard_data["active_workflows"]
    
    logger.info(f"🔄 Active Workflows: {len(active_workflows)}")
    for workflow_id, data in active_workflows.items():
        status_emoji = "✅" if data["status"] == "completed" else "🔄" if data["status"] == "running" else "❌"
        duration = data.get("total_duration", time.time() - data["start_time"])
        logger.info(f"   {status_emoji} {workflow_id}: {data['status']} ({duration:.2f}s)")
    
    # Recent activity
    logger.info(f"\n📈 Recent Activity:")
    recent_activity = dashboard_observer.get_recent_activity(5)
    for activity in recent_activity:
        state_emoji = {
            "started": "🚀",
            "running": "⚡",
            "completed": "✅",
            "error": "❌"
        }.get(activity["state"], "❓")
        logger.info(f"   {state_emoji} {activity['stage']}.{activity['function']} - {activity['state']}")
    
    # Alerts
    alerts = dashboard_observer.get_active_alerts()
    if alerts:
        logger.info(f"\n🚨 Active Alerts ({len(alerts)}):")
        for alert in alerts[-3:]:  # Show last 3 alerts
            alert_emoji = "🚨" if alert["type"] == "ERROR" else "⏰"
            logger.info(f"   {alert_emoji} {alert['message']}")
    else:
        logger.info(f"\n✅ No Active Alerts")
    
    # Metrics summary
    logger.info(f"\n📊 Performance Metrics:")
    logger.info(f"   • Total Executions: {metrics_data.get('total_executions', 0)}")
    logger.info(f"   • Success Rate: {metrics_data.get('success_rate', 0):.1f}%")
    logger.info(f"   • Total Duration: {metrics_data.get('total_duration', 0):.3f}s")
    logger.info(f"   • Failed Executions: {metrics_data.get('failed_executions', 0)}")
    
    # Stage performance
    avg_durations = metrics_data.get('average_durations', {})
    if avg_durations:
        logger.info(f"\n⏱️ Average Stage Durations:")
        for stage, duration in avg_durations.items():
            logger.info(f"   • {stage}: {duration:.3f}s")


# =============================================================================
# 6. MAIN DEMONSTRATION
# =============================================================================

async def main():
    """Run comprehensive stage monitoring demonstration."""
    logger.info("🚀 STAGE MONITORING SYSTEM DEMO")
    logger.info("=" * 60)
    
    # Setup monitoring
    state_manager, dashboard_observer, webhook_observer = setup_comprehensive_monitoring()
    
    # Run different workflow scenarios
    logger.info("\n🎬 Running workflow demonstrations...")
    
    # 1. Successful workflow
    success_result, success_status = await demo_successful_workflow()
    
    # 2. Workflow with errors
    error_status = await demo_workflow_with_errors()
    
    # 3. Concurrent workflow
    concurrent_result, concurrent_status = await demo_concurrent_workflow()
    
    # 4. Prefect async workflow
    prefect_result, prefect_status = await demo_prefect_async_monitoring()
    
    # Get final metrics
    metrics_data = get_metrics()
    
    # Display monitoring dashboard
    display_monitoring_dashboard(dashboard_observer, metrics_data)
    
    # Show webhook queue
    webhooks = webhook_observer.get_queued_webhooks()
    logger.info(f"\n🔗 Queued Webhooks: {len(webhooks)}")
    for webhook in webhooks[-3:]:  # Show last 3
        logger.info(f"   📤 {webhook['event']} - {webhook['data'].get('workflow_id', 'N/A')}")
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("🎉 MONITORING DEMO SUMMARY")
    logger.info("=" * 60)
    logger.info("✅ Stage State Tracking:")
    logger.info("   • PENDING → STARTED → RUNNING → COMPLETED/ERROR")
    logger.info("   • Real-time state transitions with timestamps")
    logger.info("   • Error capture and reporting")
    
    logger.info("\n✅ Multiple Observer Types:")
    logger.info("   • LoggingObserver - Console output with emojis")
    logger.info("   • MetricsObserver - Performance statistics")
    logger.info("   • DashboardObserver - Monitoring dashboard simulation")
    logger.info("   • WebhookObserver - External system notifications")
    
    logger.info("\n✅ Workflow-Level Monitoring:")
    logger.info("   • Workflow start/completion tracking")
    logger.info("   • Stage execution summaries")
    logger.info("   • Performance metrics and alerts")
    
    logger.info("\n✅ Integration with All Execution Modes:")
    logger.info("   • Simple async execution")
    logger.info("   • Prefect async execution")
    logger.info("   • Concurrent stage execution")
    logger.info("   • Error handling and recovery")
    
    logger.info(f"\n📊 Final Statistics:")
    logger.info(f"   • Workflows Executed: 4")
    logger.info(f"   • Total Stage Executions: {metrics_data.get('total_executions', 0)}")
    logger.info(f"   • Success Rate: {metrics_data.get('success_rate', 0):.1f}%")
    logger.info(f"   • Webhooks Generated: {len(webhooks)}")


if __name__ == "__main__":
    asyncio.run(main())