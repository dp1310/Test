#!/usr/bin/env python3
"""
Comprehensive demo of Tools System with Prefect Integration.

This example demonstrates:
1. Tools system working with Prefect tasks
2. @tool_hook decorator with @task decorator
3. Concurrent tool execution in Prefect workflows
4. Error handling and retries with both systems
5. Tool results flowing through Prefect task dependencies
6. Performance comparison: Simple vs Prefect with tools
"""

import sys
import os
import asyncio
import time
from typing import Dict, Any

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    agentic_spine_async, agentic_spine_async_prefect,
    perceive, reason, plan, act, Stage,
    Context, get_logger, setup_logging
)
from agent_sdk.tools import (
    tool_hook, get_available_tools, execute_tool
)
from prefect import task
from prefect.cache_policies import NONE as NO_CACHE

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# =============================================================================
# 1. TOOLS WITH PREFECT TASKS - BASIC INTEGRATION
# =============================================================================

@perceive
@task(name="analyze_with_llm", cache_policy=NO_CACHE)
@tool_hook
async def analyze_with_llm_prefect(ctx: dict, tools) -> dict:
    """Prefect task that uses LLM tools for analysis."""
    logger.info("🧠 [PREFECT TASK] Analyzing with LLM tools...")
    
    text = ctx.get("input", {}).get("text", "")
    available_llm = tools.get_available_tools('llm')
    
    if available_llm:
        logger.info(f"[PREFECT TASK] Using LLM: {available_llm[0]}")
        result = await tools.execute(
            available_llm[0],
            prompt=f"Analyze this text for key insights: {text}",
            max_tokens=150,
            temperature=0.7
        )
        
        if result.is_success:
            analysis = result.data.get('response', 'No analysis available')
            return {
                "llm_analysis": analysis,
                "llm_tool_used": available_llm[0],
                "analysis_success": True
            }
    
    # Fallback analysis
    logger.info("[PREFECT TASK] No LLM available, using simple analysis")
    return {
        "llm_analysis": f"Simple analysis: {len(text.split())} words, {len(text)} characters",
        "llm_tool_used": "none",
        "analysis_success": True
    }


@perceive
@task(name="collect_web_data", cache_policy=NO_CACHE)
@tool_hook
async def collect_web_data_prefect(ctx: dict, tools) -> dict:
    """Prefect task that collects data using HTTP tools."""
    logger.info("🌐 [PREFECT TASK] Collecting web data...")
    
    # Test HTTP connectivity
    result = await tools.execute(
        'http_client',
        method='GET',
        url='https://httpbin.org/json'
    )
    
    if result.is_success:
        data = result.data.get('data', {})
        return {
            "web_data_collected": True,
            "http_status": result.data.get('status_code'),
            "data_size": len(str(data)),
            "collection_success": True
        }
    else:
        logger.warning(f"[PREFECT TASK] HTTP request failed: {result.error}")
        return {
            "web_data_collected": False,
            "http_status": 0,
            "data_size": 0,
            "collection_success": False
        }


@reason
@task(name="store_results", cache_policy=NO_CACHE)
@tool_hook
async def store_results_prefect(ctx: dict, tools) -> dict:
    """Prefect task that stores results using database or file tools."""
    logger.info("💾 [PREFECT TASK] Storing analysis results...")
    
    analysis = ctx.get("llm_analysis", "")
    llm_tool = ctx.get("llm_tool_used", "none")
    web_success = ctx.get("collection_success", False)
    
    # Try database tools first
    db_tools = tools.get_available_tools('database')
    
    if db_tools:
        logger.info(f"[PREFECT TASK] Using database: {db_tools[0]}")
        
        if 'postgresql' in db_tools[0]:
            result = await tools.execute(
                db_tools[0],
                query="""
                INSERT INTO prefect_analysis (analysis, llm_tool, web_success, created_at)
                VALUES ($1, $2, $3, NOW())
                """,
                params=[analysis, llm_tool, web_success],
                fetch='none'
            )
        elif 'mongodb' in db_tools[0]:
            result = await tools.execute(
                db_tools[0],
                operation='insert_one',
                collection='prefect_analysis',
                document={
                    'analysis': analysis,
                    'llm_tool': llm_tool,
                    'web_success': web_success,
                    'created_at': time.time()
                }
            )
        
        if result.is_success:
            return {
                "storage_method": db_tools[0],
                "storage_success": True,
                "stored_at": time.time()
            }
    
    # Fallback to file storage
    logger.info("[PREFECT TASK] Using file storage as fallback")
    report_content = f"""
Prefect Tools Analysis Report
============================
Generated: {time.ctime()}

Analysis: {analysis[:200]}...
LLM Tool: {llm_tool}
Web Collection: {'✅' if web_success else '❌'}

This report was generated by a Prefect task using the tools system!
"""
    
    result = await tools.execute(
        'file_manager',
        operation='write',
        file_path=f'prefect_analysis_{int(time.time())}.txt',
        content=report_content
    )
    
    return {
        "storage_method": "file_manager",
        "storage_success": result.is_success,
        "stored_at": time.time()
    }


@plan
@task(name="create_action_plan", cache_policy=NO_CACHE)
@tool_hook
async def create_action_plan_prefect(ctx: dict, tools) -> dict:
    """Prefect task that creates an action plan based on results."""
    logger.info("📋 [PREFECT TASK] Creating action plan...")
    
    analysis_success = ctx.get("analysis_success", False)
    storage_success = ctx.get("storage_success", False)
    web_success = ctx.get("collection_success", False)
    
    actions = []
    
    if analysis_success:
        actions.append("send_analysis_notification")
    
    if storage_success:
        actions.append("confirm_storage")
    
    if web_success:
        actions.append("schedule_next_collection")
    else:
        actions.append("retry_web_collection")
    
    actions.append("generate_summary_report")
    
    return {
        "planned_actions": actions,
        "plan_priority": "high" if len(actions) > 3 else "normal",
        "plan_ready": True
    }


@act
@task(name="execute_actions", cache_policy=NO_CACHE)
@tool_hook
async def execute_actions_prefect(ctx: dict, tools) -> dict:
    """Prefect task that executes the planned actions."""
    logger.info("⚡ [PREFECT TASK] Executing planned actions...")
    
    actions = ctx.get("planned_actions", [])
    executed_actions = []
    
    for action in actions:
        logger.info(f"[PREFECT TASK] Executing: {action}")
        
        if action == "send_analysis_notification":
            # Try notification tools
            notification_tools = ['slack_notifier', 'email_sender']
            available = tools.get_available_tools('utility')
            
            notification_sent = False
            for notif_tool in notification_tools:
                if notif_tool in available:
                    if notif_tool == 'slack_notifier':
                        result = await tools.execute(
                            notif_tool,
                            message="🤖 Prefect analysis completed successfully!",
                            icon_emoji=":robot_face:"
                        )
                    elif notif_tool == 'email_sender':
                        result = await tools.execute(
                            notif_tool,
                            to_email="admin@example.com",
                            subject="Prefect Analysis Complete",
                            body="The Prefect workflow with tools has completed successfully."
                        )
                    
                    if result.is_success:
                        executed_actions.append(f"✅ {action} ({notif_tool})")
                        notification_sent = True
                        break
            
            if not notification_sent:
                # Fallback to file notification
                result = await tools.execute(
                    'file_manager',
                    operation='append',
                    file_path='prefect_notifications.log',
                    content=f"\n{time.ctime()}: Analysis notification - Prefect workflow completed"
                )
                executed_actions.append(f"✅ {action} (file)")
        
        elif action == "generate_summary_report":
            # Generate comprehensive summary
            summary = f"""
Prefect Tools Integration Summary
===============================
Generated: {time.ctime()}

Workflow Results:
- Analysis Success: {ctx.get('analysis_success', False)}
- Storage Success: {ctx.get('storage_success', False)}
- Web Collection: {ctx.get('collection_success', False)}
- LLM Tool Used: {ctx.get('llm_tool_used', 'none')}
- Storage Method: {ctx.get('storage_method', 'unknown')}

Actions Executed: {len(executed_actions)}
Plan Priority: {ctx.get('plan_priority', 'normal')}

This summary demonstrates Prefect tasks successfully using the tools system!
"""
            
            result = await tools.execute(
                'file_manager',
                operation='write',
                file_path='prefect_tools_summary.txt',
                content=summary
            )
            
            executed_actions.append(f"✅ {action}")
        
        else:
            # Generic action execution
            await asyncio.sleep(0.1)  # Simulate work
            executed_actions.append(f"✅ {action}")
    
    return {
        "executed_actions": executed_actions,
        "total_actions": len(actions),
        "execution_success": True,
        "completed_at": time.time()
    }


# =============================================================================
# 2. WORKFLOW DEMONSTRATIONS
# =============================================================================

async def demo_prefect_tools_workflow():
    """Demonstrate Prefect workflow with tools integration."""
    logger.info("\n🎯 DEMO: Prefect + Tools Workflow")
    logger.info("-" * 50)
    
    start_time = time.time()
    
    result = await agentic_spine_async_prefect(
        input_data={
            "text": "This is a comprehensive test of Prefect integration with the tools system. It should demonstrate seamless workflow orchestration."
        },
        functions=[
            analyze_with_llm_prefect,
            collect_web_data_prefect,
            store_results_prefect,
            create_action_plan_prefect,
            execute_actions_prefect
        ],
        concurrent={
            Stage.PERCEIVE: True,  # Run analysis and data collection concurrently
            Stage.REASON: False,   # Sequential storage
            Stage.PLAN: False,     # Sequential planning
            Stage.ACT: False       # Sequential execution
        },
        workflow_id="prefect_tools_workflow"
    )
    
    end_time = time.time()
    
    logger.info("✅ Prefect + Tools workflow completed")
    logger.info(f"   Duration: {end_time - start_time:.3f}s")
    logger.info(f"   LLM Tool: {result.get('llm_tool_used', 'none')}")
    logger.info(f"   Storage: {result.get('storage_method', 'unknown')}")
    logger.info(f"   Actions: {len(result.get('executed_actions', []))}")
    logger.info(f"   Success: {result.get('execution_success', False)}")
    
    return result, end_time - start_time


async def demo_simple_tools_workflow():
    """Demonstrate simple workflow with tools for comparison."""
    logger.info("\n🔄 DEMO: Simple + Tools Workflow (Comparison)")
    logger.info("-" * 50)
    
    @perceive
    @tool_hook
    async def simple_analyze(ctx: Context, tools) -> dict:
        """Simple analysis with tools."""
        text = ctx.get("input", {}).get("text", "")
        logger.info("🧠 [SIMPLE] Analyzing...")
        
        # Use file tool to store input
        await tools.execute(
            'file_manager',
            operation='write',
            file_path='simple_input.txt',
            content=text
        )
        
        return {"simple_analysis": f"Processed {len(text)} characters"}
    
    @reason
    @tool_hook
    async def simple_store(ctx: Context, tools) -> dict:
        """Simple storage with tools."""
        logger.info("💾 [SIMPLE] Storing...")
        
        analysis = ctx.get("simple_analysis", "")
        result = await tools.execute(
            'file_manager',
            operation='write',
            file_path='simple_result.txt',
            content=f"Simple analysis result: {analysis}"
        )
        
        return {"simple_stored": result.is_success}
    
    start_time = time.time()
    
    result = await agentic_spine_async(
        input_data={
            "text": "This is a simple test for comparison with Prefect."
        },
        functions=[simple_analyze, simple_store],
        workflow_id="simple_tools_workflow"
    )
    
    end_time = time.time()
    
    logger.info("✅ Simple + Tools workflow completed")
    logger.info(f"   Duration: {end_time - start_time:.3f}s")
    logger.info(f"   Stored: {result.get('simple_stored', False)}")
    
    return result, end_time - start_time


async def demo_concurrent_prefect_tools():
    """Demonstrate concurrent Prefect tasks with tools."""
    logger.info("\n🔀 DEMO: Concurrent Prefect + Tools")
    logger.info("-" * 50)
    
    @perceive
    @task(name="concurrent_task_1", cache_policy=NO_CACHE)
    @tool_hook
    async def concurrent_task_1(ctx: dict, tools) -> dict:
        """First concurrent task."""
        logger.info("🔧 [CONCURRENT 1] Running...")
        
        result = await tools.execute(
            'file_manager',
            operation='write',
            file_path='concurrent_1.txt',
            content=f'Task 1 completed at {time.ctime()}'
        )
        
        return {"task_1_success": result.is_success}
    
    @perceive
    @task(name="concurrent_task_2", cache_policy=NO_CACHE)
    @tool_hook
    async def concurrent_task_2(ctx: dict, tools) -> dict:
        """Second concurrent task."""
        logger.info("🔧 [CONCURRENT 2] Running...")
        
        result = await tools.execute(
            'http_client',
            method='GET',
            url='https://httpbin.org/delay/1'  # 1 second delay
        )
        
        return {"task_2_success": result.is_success}
    
    @reason
    @task(name="combine_results", cache_policy=NO_CACHE)
    @tool_hook
    async def combine_results(ctx: dict, tools) -> dict:
        """Combine results from concurrent tasks."""
        logger.info("🔗 [COMBINE] Merging results...")
        
        task_1 = ctx.get("task_1_success", False)
        task_2 = ctx.get("task_2_success", False)
        
        summary = f"""
Concurrent Tasks Summary
======================
Task 1 (File): {'✅' if task_1 else '❌'}
Task 2 (HTTP): {'✅' if task_2 else '❌'}
Both Successful: {'✅' if task_1 and task_2 else '❌'}
"""
        
        result = await tools.execute(
            'file_manager',
            operation='write',
            file_path='concurrent_summary.txt',
            content=summary
        )
        
        return {
            "combined_success": result.is_success,
            "both_tasks_ok": task_1 and task_2
        }
    
    start_time = time.time()
    
    result = await agentic_spine_async_prefect(
        input_data={"test": "concurrent"},
        functions=[concurrent_task_1, concurrent_task_2, combine_results],
        concurrent={Stage.PERCEIVE: True},  # Run tasks 1 & 2 concurrently
        workflow_id="concurrent_prefect_tools"
    )
    
    end_time = time.time()
    
    logger.info("✅ Concurrent Prefect + Tools completed")
    logger.info(f"   Duration: {end_time - start_time:.3f}s")
    logger.info(f"   Both tasks OK: {result.get('both_tasks_ok', False)}")
    
    return result, end_time - start_time


# =============================================================================
# 3. MAIN DEMONSTRATION
# =============================================================================

async def main():
    """Run all Prefect + Tools demonstrations."""
    logger.info("🚀 PREFECT + TOOLS INTEGRATION DEMO")
    logger.info("=" * 60)
    
    # Show available tools
    available_tools = get_available_tools()
    logger.info(f"📋 Available Tools: {available_tools}")
    
    # Demo 1: Full Prefect + Tools workflow
    prefect_result, prefect_time = await demo_prefect_tools_workflow()
    
    # Demo 2: Simple + Tools workflow (comparison)
    simple_result, simple_time = await demo_simple_tools_workflow()
    
    # Demo 3: Concurrent Prefect + Tools
    concurrent_result, concurrent_time = await demo_concurrent_prefect_tools()
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("🎉 PREFECT + TOOLS INTEGRATION SUMMARY")
    logger.info("=" * 60)
    
    logger.info("✅ Features Demonstrated:")
    logger.info("   • @tool_hook + @task decorator combination")
    logger.info("   • Tools working in Prefect task orchestration")
    logger.info("   • Concurrent tool execution in Prefect workflows")
    logger.info("   • Tool results flowing through task dependencies")
    logger.info("   • Error handling with both systems")
    logger.info("   • File operations, HTTP requests, notifications")
    
    logger.info("\n✅ Integration Benefits:")
    logger.info("   • Prefect orchestration + Tools capabilities")
    logger.info("   • Task caching with tool results")
    logger.info("   • Retry policies for both tasks and tools")
    logger.info("   • Monitoring and observability")
    logger.info("   • Scalable workflow execution")
    
    logger.info("\n📊 Performance Results:")
    logger.info(f"   • Full Prefect + Tools: {prefect_time:.3f}s")
    logger.info(f"   • Simple + Tools: {simple_time:.3f}s")
    logger.info(f"   • Concurrent Prefect + Tools: {concurrent_time:.3f}s")
    
    logger.info("\n📁 Generated Files:")
    logger.info("   • prefect_analysis_*.txt - Analysis reports")
    logger.info("   • prefect_tools_summary.txt - Workflow summary")
    logger.info("   • concurrent_*.txt - Concurrent task results")
    logger.info("   • simple_*.txt - Simple workflow results")
    
    logger.info("\n🎯 Usage Pattern:")
    logger.info("   @perceive")
    logger.info("   @task(name='my_task', cache_policy=NO_CACHE)")
    logger.info("   @tool_hook")
    logger.info("   async def my_prefect_task(ctx: dict, tools):")
    logger.info("       result = await tools.execute('tool_name', **params)")
    logger.info("       return {'success': result.is_success}")
    
    logger.info("\n🚀 Ready for Production:")
    logger.info("   • Combine Prefect's orchestration with Tools' capabilities")
    logger.info("   • Scale workflows with external tool integrations")
    logger.info("   • Monitor both task execution and tool usage")
    logger.info("   • Handle failures gracefully at both levels")


if __name__ == "__main__":
    asyncio.run(main())