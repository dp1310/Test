"""Example demonstrating agent usage patterns."""

import asyncio
from typing import Dict, Any

from agent_sdk.agent import (
    create_simple_sync_agent,
    create_simple_async_agent,
    create_prefect_sync_agent,
    create_prefect_async_agent,
    AgentFactory,
    AgentType
)
from agent_sdk.core.stages import perceive, reason, plan, act, Stage
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging to see output
setup_logging(level="INFO")
logger = get_logger(__name__)


# Example stage functions
@perceive
def gather_data(context: Dict[str, Any]) -> Dict[str, Any]:
    """Perceive stage: gather input data."""
    input_data = context.get("input", {})
    logger.info(f"Gathering data: {input_data}")
    return {"perceived_data": f"processed_{input_data}"}


@reason
def analyze_data(context: Dict[str, Any]) -> Dict[str, Any]:
    """Reason stage: analyze the perceived data."""
    perceived = context.get("perceived_data", "")
    logger.info(f"Analyzing: {perceived}")
    return {"analysis": f"analyzed_{perceived}"}


@plan
def create_plan(context: Dict[str, Any]) -> Dict[str, Any]:
    """Plan stage: create execution plan."""
    analysis = context.get("analysis", "")
    logger.info(f"Planning based on: {analysis}")
    return {"plan": f"plan_for_{analysis}"}


@act
def execute_plan(context: Dict[str, Any]) -> Dict[str, Any]:
    """Act stage: execute the plan."""
    plan = context.get("plan", "")
    logger.info(f"Executing: {plan}")
    return {"result": f"executed_{plan}"}


# Async versions for demonstration
@perceive
async def gather_data_async(context: Dict[str, Any]) -> Dict[str, Any]:
    """Async perceive stage."""
    await asyncio.sleep(0.1)  # Simulate async work
    input_data = context.get("input", {})
    logger.info(f"Async gathering data: {input_data}")
    return {"perceived_data": f"async_processed_{input_data}"}


@reason
async def analyze_data_async(context: Dict[str, Any]) -> Dict[str, Any]:
    """Async reason stage."""
    await asyncio.sleep(0.1)  # Simulate async work
    perceived = context.get("perceived_data", "")
    logger.info(f"Async analyzing: {perceived}")
    return {"analysis": f"async_analyzed_{perceived}"}


def demonstrate_simple_sync_agent():
    """Demonstrate simple synchronous agent usage."""
    logger.info("\n=== Simple Sync Agent ===")
    
    # Create agent using factory function
    agent = create_simple_sync_agent(
        functions=[gather_data, analyze_data, create_plan, execute_plan],
        initial_context={"config": "sync_mode"},
        workflow_id="simple_sync_demo"
    )
    
    # Execute workflow
    result = agent.execute("test_input")
    logger.info(f"Result: {result.data}")
    
    # Demonstrate fluent interface
    agent2 = (create_simple_sync_agent()
              .add_function(gather_data)
              .add_function(analyze_data)
              .set_initial_context({"mode": "fluent"})
              .set_workflow_id("fluent_demo"))
    
    result2 = agent2.execute("fluent_input")
    logger.info(f"Fluent result: {result2.data}")


async def demonstrate_simple_async_agent():
    """Demonstrate simple asynchronous agent usage."""
    logger.info("\n=== Simple Async Agent ===")
    
    # Create agent with async functions
    agent = create_simple_async_agent(
        functions=[gather_data_async, analyze_data_async, create_plan, execute_plan],
        concurrent={Stage.PERCEIVE: True, Stage.REASON: True},
        workflow_id="simple_async_demo"
    )
    
    # Execute workflow asynchronously
    result = await agent.execute("async_test_input")
    logger.info(f"Async result: {result.data}")


def demonstrate_prefect_sync_agent():
    """Demonstrate Prefect synchronous agent usage."""
    logger.info("\n=== Prefect Sync Agent ===")
    
    # Create agent using factory class
    agent = AgentFactory.create_agent(
        AgentType.PREFECT_SYNC,
        functions=[gather_data, analyze_data, create_plan, execute_plan],
        initial_context={"orchestrator": "prefect"},
        workflow_id="prefect_sync_demo"
    )
    
    # Execute workflow
    result = agent.execute("prefect_input")
    logger.info(f"Prefect result: {result.data}")


async def demonstrate_prefect_async_agent():
    """Demonstrate Prefect asynchronous agent usage."""
    logger.info("\n=== Prefect Async Agent ===")
    
    # Create agent with mixed sync/async functions
    agent = create_prefect_async_agent(
        functions=[gather_data_async, analyze_data, create_plan, execute_plan],
        concurrent={Stage.REASON: True, Stage.PLAN: True},
        workflow_id="prefect_async_demo"
    )
    
    # Execute workflow asynchronously
    result = await agent.execute("prefect_async_input")
    logger.info(f"Prefect async result: {result.data}")


def demonstrate_agent_cloning():
    """Demonstrate agent cloning (prototype pattern)."""
    logger.info("\n=== Agent Cloning ===")
    
    # Create base agent
    base_agent = create_simple_sync_agent(
        functions=[gather_data, analyze_data],
        initial_context={"base": "config"},
        workflow_id="base_agent"
    )
    
    # Clone and modify
    cloned_agent = (base_agent.clone()
                   .add_function(create_plan)
                   .add_function(execute_plan)
                   .update_initial_context({"cloned": True})
                   .set_workflow_id("cloned_agent"))
    
    # Execute both
    base_result = base_agent.execute("base_input")
    cloned_result = cloned_agent.execute("cloned_input")
    
    logger.info(f"Base agent functions: {len(base_agent.functions)}")
    logger.info(f"Cloned agent functions: {len(cloned_agent.functions)}")
    logger.info(f"Base result: {base_result.data}")
    logger.info(f"Cloned result: {cloned_result.data}")


def demonstrate_agent_comparison():
    """Demonstrate different agent types with same workflow."""
    logger.info("\n=== Agent Type Comparison ===")
    
    functions = [gather_data, analyze_data, create_plan, execute_plan]
    input_data = "comparison_test"
    
    # Create different agent types
    agents = {
        "Simple Sync": create_simple_sync_agent(functions=functions),
        "Prefect Sync": create_prefect_sync_agent(functions=functions),
    }
    
    # Execute with each agent type
    for name, agent in agents.items():
        logger.info(f"\n{name} Agent:")
        logger.info(f"  Type: {agent.get_execution_type()}")
        result = agent.execute(input_data)
        logger.info(f"  Result keys: {list(result.data.keys())}")


async def main():
    """Main demonstration function."""
    logger.info("Agent Framework Demonstration")
    logger.info("=" * 40)
    
    # Demonstrate different agent types
    demonstrate_simple_sync_agent()
    await demonstrate_simple_async_agent()
    demonstrate_prefect_sync_agent()
    await demonstrate_prefect_async_agent()
    
    # Demonstrate patterns
    demonstrate_agent_cloning()
    demonstrate_agent_comparison()
    
    logger.info("\n=== Available Agent Types ===")
    logger.info(f"Available types: {AgentFactory.get_available_types()}")


if __name__ == "__main__":
    asyncio.run(main())