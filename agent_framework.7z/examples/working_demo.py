"""Working demo of the agent SDK with both sync and async examples."""

import sys
import os
import asyncio

# Add the agent_framework directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from agent_sdk import (
    perceive, reason, plan, act, Stage,
    agentic_spine, agentic_spine_async, 
    Context, get_logger, setup_logging
)

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


def sync_demo():
    """Simple synchronous demo."""
    logger.info("=== Synchronous Demo ===")
    
    @perceive
    def extract_info(ctx: Context) -> dict:
        text = ctx.get("input", {}).get("text", "")
        return {
            "word_count": len(text.split()),
            "has_urgent": "urgent" in text.lower()
        }
    
    @reason
    def analyze(ctx: Context) -> dict:
        urgent = ctx.get("has_urgent", False)
        word_count = ctx.get("word_count", 0)
        
        priority = "high" if urgent else "normal"
        complexity = "high" if word_count > 10 else "low"
        
        return {"priority": priority, "complexity": complexity}
    
    @plan
    def make_plan(ctx: Context) -> dict:
        priority = ctx.get("priority", "normal")
        actions = ["immediate_action"] if priority == "high" else ["standard_action"]
        return {"actions": actions}
    
    @act
    def execute(ctx: Context) -> dict:
        actions = ctx.get("actions", [])
        return {"completed": [f"✓ {action}" for action in actions]}
    
    # Test the workflow
    result = agentic_spine(
        input_data={"text": "This is an urgent message that needs immediate attention"},
        functions=[extract_info, analyze, make_plan, execute]
    )
    
    logger.info(f"Priority: {result.get('priority')}")
    logger.info(f"Completed: {result.get('completed')}")
    return result


async def async_demo():
    """Simple asynchronous demo."""
    logger.info("\n=== Asynchronous Demo ===")
    
    @perceive
    async def async_extract(ctx: Context) -> dict:
        text = ctx.get("input", {}).get("text", "")
        logger.info(f"[ASYNC PERCEIVE] Processing text: {text[:30]}...")
        await asyncio.sleep(0.1)  # Simulate async work
        logger.info("[ASYNC PERCEIVE] Async processing completed")
        
        return {
            "char_count": len(text),
            "has_question": "?" in text,
            "async_processed": True
        }
    
    @reason
    def sync_analyze(ctx: Context) -> dict:
        char_count = ctx.get("char_count", 0)
        has_question = ctx.get("has_question", False)
        async_processed = ctx.get("async_processed", False)
        
        logger.info(f"[SYNC REASON] char_count={char_count}, has_question={has_question}, async_processed={async_processed}")
        
        needs_response = has_question or char_count > 50
        return {"needs_response": needs_response}
    
    @plan
    async def async_plan(ctx: Context) -> dict:
        needs_response = ctx.get("needs_response", False)
        logger.info(f"[ASYNC PLAN] Planning for needs_response={needs_response}")
        await asyncio.sleep(0.05)  # Simulate async planning
        
        if needs_response:
            steps = ["prepare_response", "send_response"]
        else:
            steps = ["log_message"]
        
        logger.info(f"[ASYNC PLAN] Created plan: {steps}")
        return {"steps": steps, "plan_created": True}
    
    @act
    def execute_steps(ctx: Context) -> dict:
        steps = ctx.get("steps", [])
        plan_created = ctx.get("plan_created", False)
        logger.info(f"[SYNC ACT] Executing steps: {steps}, plan_created={plan_created}")
        
        executed = [f"Done: {step}" for step in steps]
        return {"executed": executed}
    
    # Debug: Check if functions are async
    logger.info("Function types:")
    logger.info(f"  async_extract is coroutine: {asyncio.iscoroutinefunction(async_extract)}")
    logger.info(f"  sync_analyze is coroutine: {asyncio.iscoroutinefunction(sync_analyze)}")
    logger.info(f"  async_plan is coroutine: {asyncio.iscoroutinefunction(async_plan)}")
    logger.info(f"  execute_steps is coroutine: {asyncio.iscoroutinefunction(execute_steps)}")
    
    # Test the async workflow
    result = await agentic_spine_async(
        input_data={"text": "Can you help me with this question?"},
        functions=[async_extract, sync_analyze, async_plan, execute_steps]
    )
    
    logger.info(f"Needs response: {result.get('needs_response')}")
    logger.info(f"Executed: {result.get('executed')}")
    logger.info(f"Async processed: {result.get('async_processed')}")
    logger.info(f"Plan created: {result.get('plan_created')}")
    return result


async def main():
    """Run both demos."""
    # Sync demo
    sync_result = sync_demo()
    
    # Async demo
    async_result = await async_demo()
    
    logger.info("\n=== Demo Summary ===")
    logger.info(f"Sync demo priority: {sync_result.get('priority')}")
    logger.info(f"Async demo needs response: {async_result.get('needs_response')}")
    logger.info("All demos completed successfully!")


if __name__ == "__main__":
    asyncio.run(main())