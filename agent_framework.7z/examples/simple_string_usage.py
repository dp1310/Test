"""Simple example showing the exact usage pattern requested."""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from agent_sdk.agent import create_simple_sync_agent
from agent_sdk.core.stages import perceive, reason, plan, act
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging
setup_logging(level="INFO")
logger = get_logger(__name__)


# Define functions in a separate "module" (this file acts as mymodule)
@perceive
def perceive_func(context):
    """Example perceive function."""
    input_data = context.get("input", "")
    logger.info(f"Perceiving: {input_data}")
    return {"perceived": f"perceived_{input_data}"}


@reason
def reason_func(context):
    """Example reason function."""
    perceived = context.get("perceived", "")
    logger.info(f"Reasoning: {perceived}")
    return {"reasoning": f"reasoned_{perceived}"}


def main():
    """Demonstrate the exact usage pattern requested."""
    logger.info("Simple String Function Usage Example")
    logger.info("=" * 40)
    
    # Create agent
    agent = create_simple_sync_agent(
        functions=[perceive_func],  # Initial function
        workflow_id="string_usage_demo"
    )
    
    # BEFORE: This was already supported
    logger.info("\n✅ BEFORE (already supported):")
    dynamic_input_before = {
        "input": "test",
        "functions": [perceive_func, reason_func]  # Callable functions
    }
    
    result_before = agent.execute(dynamic_input_before)
    logger.info(f"Result: {result_before.data.get('reasoning')}")
    
    # AFTER: This is now also supported
    logger.info("\n✅ AFTER (newly supported):")
    current_module = __name__  # This would be "mymodule" in your case
    dynamic_input_after = {
        "input": "test", 
        "functions": [
            f"{current_module}.perceive_func",  # String reference
            f"{current_module}.reason_func"     # String reference
        ]
    }
    
    result_after = agent.execute(dynamic_input_after)
    logger.info(f"Result: {result_after.data.get('reasoning')}")
    
    logger.info("\n🎉 Both formats work identically!")
    logger.info("You can now use string references like 'mymodule.perceive_func'")


if __name__ == "__main__":
    main()