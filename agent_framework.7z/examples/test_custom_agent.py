"""Test the custom enhanced agent implementation."""

import sys
import os
sys.path.append(os.path.dirname(__file__))

from examples.custom_agent_example import EnhancedPrefectAgent, enhanced_perceive, enhanced_reason, enhanced_plan, enhanced_act
from agent_sdk.core.stages import Stage
from agent_sdk.utils.logging import get_logger, setup_logging

# Setup logging to see output
setup_logging(level="INFO")
logger = get_logger(__name__)


def test_enhanced_agent():
    """Test the enhanced agent functionality."""
    logger.info("Testing Enhanced Prefect Agent...")
    
    # Create enhanced agent
    agent = EnhancedPrefectAgent(
        functions=[enhanced_perceive, enhanced_reason, enhanced_plan, enhanced_act],
        initial_context={"test": True},
        concurrent={Stage.REASON: True},
        workflow_id="test_enhanced",
        enable_metrics=True,
        max_execution_time=5.0
    )
    
    logger.info(f"Agent: {agent}")
    logger.info(f"Agent type: {agent.get_execution_type()}")
    
    # Execute workflow
    result = agent.execute("test_enhanced_input")
    
    # Check results
    logger.info(f"Result keys: {list(result.data.keys())}")
    logger.info(f"Success: {result.data.get('success')}")
    logger.info(f"Strategy: {result.data.get('execution_strategy')}")
    
    # Check metrics
    metrics = agent.get_execution_metrics()
    logger.info(f"Execution time: {metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Function count: {metrics.get('function_count')}")
    logger.info(f"Success: {metrics.get('success')}")
    
    # Verify enhanced features
    assert result.data.get('success') is True
    assert 'perception_quality' in result.data
    assert 'confidence' in result.data
    assert 'strategy' in result.data
    assert 'execution_duration' in result.data
    
    logger.info("Enhanced agent test passed!")
    return True


def test_fluent_interface():
    """Test the fluent interface of enhanced agent."""
    logger.info("\nTesting Enhanced Agent Fluent Interface...")
    
    # Create agent using fluent interface
    agent = (EnhancedPrefectAgent()
             .add_function(enhanced_perceive)
             .add_function(enhanced_reason)
             .enable_metrics(True)
             .set_max_execution_time(3.0)
             .set_initial_context({"fluent_test": True})
             .set_workflow_id("fluent_test"))
    
    logger.info(f"Fluent agent: {agent}")
    
    # Execute
    result = agent.execute("fluent_test_input")
    metrics = agent.get_execution_metrics()
    
    logger.info(f"Fluent execution time: {metrics.get('execution_time', 0):.3f}s")
    logger.info(f"Fluent success: {metrics.get('success')}")
    
    # Verify fluent configuration worked
    assert metrics.get('success') is True
    assert result.data.get('fluent_test') is True
    
    logger.info("Fluent interface test passed!")
    return True


def test_agent_inheritance():
    """Test that enhanced agent properly inherits from PrefectSyncAgent."""
    logger.info("\nTesting Agent Inheritance...")
    
    from agent_sdk.agent import PrefectSyncAgent
    
    agent = EnhancedPrefectAgent(
        functions=[enhanced_perceive, enhanced_reason],
        workflow_id="inheritance_test"
    )
    
    # Verify inheritance
    assert isinstance(agent, PrefectSyncAgent)
    assert hasattr(agent, 'execute')
    assert hasattr(agent, 'get_execution_type')
    assert hasattr(agent, 'clone')
    
    # Verify enhanced features
    assert hasattr(agent, 'get_execution_metrics')
    assert hasattr(agent, 'set_max_execution_time')
    assert hasattr(agent, 'enable_metrics')
    
    logger.info("Agent inheritance test passed!")
    return True


if __name__ == "__main__":
    logger.info("Running Custom Agent Tests")
    logger.info("=" * 35)
    
    try:
        test_enhanced_agent()
        test_fluent_interface()
        test_agent_inheritance()
        logger.info("\nAll custom agent tests passed!")
    except Exception as e:
        logger.error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()