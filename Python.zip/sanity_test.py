#!/usr/bin/env python3
"""
Sanity test for the async pipeline executor with colorful logging.
Tests all major features including async execution, emoji logging, and error handling.
"""

import asyncio
import sys
import time
from pipeline_executor.application.math_controller import MathPipelineController, EnhancedMathPipelineController
from pipeline_executor.framework.colored_logging import setup_colored_logging, EmojiLogger
from pipeline_executor.framework.models import RetryConfig

logger = EmojiLogger(__name__)

async def test_basic_operations():
    """Test basic mathematical operations."""
    logger.info("🧪 Testing basic operations...")
    
    controller = MathPipelineController(timeout=5, debug=False)
    
    try:
        result = await controller.execute("2+3, 5*7, 10-4")
        
        assert result.summary.total_operations == 3
        assert result.summary.successful_operations == 3
        assert result.summary.failed_operations == 0
        
        logger.info("✅ Basic operations test passed!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Basic operations test failed: {e}")
        return False
    finally:
        await controller.cleanup()

async def test_error_handling():
    """Test error handling with division by zero."""
    logger.info("🧪 Testing error handling...")
    
    controller = MathPipelineController(timeout=5, debug=False)
    
    try:
        result = await controller.execute("2+3, 10/0, 5*2")
        
        assert result.summary.total_operations == 3
        assert result.summary.successful_operations == 2
        assert result.summary.failed_operations == 1
        
        logger.info("✅ Error handling test passed!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error handling test failed: {e}")
        return False
    finally:
        await controller.cleanup()

async def test_function_calls():
    """Test function call operations."""
    logger.info("🧪 Testing function calls...")
    
    controller = MathPipelineController(timeout=5, debug=False)
    
    try:
        result = await controller.execute("add(5,6), pow(2,3), mul(4,7)")
        
        assert result.summary.total_operations == 3
        assert result.summary.successful_operations == 3
        assert result.summary.failed_operations == 0
        
        # Check specific results
        results_dict = {r.original_expression: r.result for r in result.summary.results if r.result is not None}
        assert results_dict.get("add(5,6)") == 11.0
        assert results_dict.get("pow(2,3)") == 8.0
        assert results_dict.get("mul(4,7)") == 28.0
        
        logger.info("✅ Function calls test passed!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Function calls test failed: {e}")
        return False
    finally:
        await controller.cleanup()

async def test_power_operations():
    """Test power operations."""
    logger.info("🧪 Testing power operations...")
    
    controller = MathPipelineController(timeout=5, debug=False)
    
    try:
        result = await controller.execute("2^3, 5^2, 10^0")
        
        assert result.summary.total_operations == 3
        assert result.summary.successful_operations == 3
        assert result.summary.failed_operations == 0
        
        # Check specific results
        results_dict = {r.original_expression: r.result for r in result.summary.results if r.result is not None}
        assert results_dict.get("2^3") == 8.0
        assert results_dict.get("5^2") == 25.0
        assert results_dict.get("10^0") == 1.0
        
        logger.info("✅ Power operations test passed!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Power operations test failed: {e}")
        return False
    finally:
        await controller.cleanup()

async def test_enhanced_controller():
    """Test enhanced controller with detailed review."""
    logger.info("🧪 Testing enhanced controller...")
    
    controller = EnhancedMathPipelineController(
        timeout=5, 
        debug=False, 
        enable_detailed_review=True
    )
    
    try:
        result = await controller.execute("1+1, 2*2, 3^2")
        
        assert result.summary.total_operations == 3
        assert result.summary.successful_operations == 3
        assert result.summary.failed_operations == 0
        
        logger.info("✅ Enhanced controller test passed!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Enhanced controller test failed: {e}")
        return False
    finally:
        await controller.cleanup()

async def test_timeout_handling():
    """Test timeout handling."""
    logger.info("🧪 Testing timeout handling...")
    
    # Use a very short timeout to test timeout behavior
    controller = MathPipelineController(timeout=1, debug=False)
    
    try:
        # This should complete within timeout
        result = await controller.execute("1+1, 2+2")
        
        assert result.summary.total_operations == 2
        assert result.summary.successful_operations == 2
        
        logger.info("✅ Timeout handling test passed!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Timeout handling test failed: {e}")
        return False
    finally:
        await controller.cleanup()

async def test_concurrent_execution():
    """Test concurrent execution performance."""
    logger.info("🧪 Testing concurrent execution performance...")
    
    controller = MathPipelineController(timeout=10, debug=False)
    
    try:
        # Test with many operations to see concurrent benefits
        expressions = [f"{i}+{i+1}" for i in range(1, 21)]  # 20 operations
        expression_str = ", ".join(expressions)
        
        start_time = time.time()
        result = await controller.execute(expression_str)
        execution_time = time.time() - start_time
        
        assert result.summary.total_operations == 20
        assert result.summary.successful_operations == 20
        assert result.summary.failed_operations == 0
        
        # Should complete relatively quickly due to concurrency
        assert execution_time < 5.0, f"Execution took too long: {execution_time}s"
        
        logger.info(f"✅ Concurrent execution test passed! ({execution_time:.3f}s for 20 operations)")
        return True
        
    except Exception as e:
        logger.error(f"❌ Concurrent execution test failed: {e}")
        return False
    finally:
        await controller.cleanup()

async def run_all_tests():
    """Run all sanity tests."""
    logger.info("🚀 Starting sanity tests for async pipeline executor...")
    
    tests = [
        test_basic_operations,
        test_error_handling,
        test_function_calls,
        test_power_operations,
        test_enhanced_controller,
        test_timeout_handling,
        test_concurrent_execution
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if await test():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            logger.error(f"❌ Test {test.__name__} crashed: {e}")
            failed += 1
        
        # Small delay between tests
        await asyncio.sleep(0.1)
    
    logger.info("=" * 60)
    logger.info(f"🏁 Sanity test results: {passed} passed, {failed} failed")
    
    if failed == 0:
        logger.info("🎉 All tests passed! The async pipeline executor is working correctly.")
        return True
    else:
        logger.error(f"💥 {failed} tests failed. Please check the implementation.")
        return False

async def main():
    """Main test runner."""
    # Set up colorful logging
    setup_colored_logging(debug=False, quiet=False)
    
    success = await run_all_tests()
    return 0 if success else 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)