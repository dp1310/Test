#!/usr/bin/env python3
"""
Pipeline Executor Agent - Main application entry point.

This module provides the main application interface for the async pipeline executor.
It implements a complete non-blocking pipeline that processes mathematical expressions
through six distinct stages: perceive → plan → reason → act → review → learn.

The application features:
- Full async/await support for non-blocking execution
- Colorful emoji logging for enhanced user experience
- Concurrent execution of mathematical operations
- Comprehensive error handling and retry mechanisms
- Performance monitoring and learning capabilities
- Multiple output formats (text and JSON)

Example usage:
    python agent.py --exp "2+3, add(5,6), 2^8" --timeout 5 --debug
    python agent.py --exp "1+1, 2*2" --output-format json --quiet
"""

import sys
import json
import time
import asyncio
from typing import Dict, Any

from pipeline_executor.cli import CLIArgumentParser, ConfigurationValidator, setup_logging, validate_expression_syntax
from pipeline_executor.application.math_controller import MathPipelineController, EnhancedMathPipelineController
from pipeline_executor.framework.utils import MemoryManager
from pipeline_executor.framework.models import ExecutionStatus


class PipelineExecutorApp:
    """
    Main application class for the async pipeline executor.
    
    This class orchestrates the entire application lifecycle:
    1. Command-line argument parsing and validation
    2. Logging configuration with colorful emojis
    3. Pipeline controller initialization
    4. Async pipeline execution
    5. Results formatting and output
    6. Resource cleanup
    
    The application supports both text and JSON output formats,
    with comprehensive error handling and graceful shutdown.
    """
    
    def __init__(self):
        """
        Initialize the pipeline executor application.
        
        Sets up the command-line parser and configuration validator
        for processing user input and ensuring valid configuration.
        """
        self.cli_parser = CLIArgumentParser()
        self.config_validator = ConfigurationValidator()
    
    def run(self, args=None) -> int:
        """
        Run the async pipeline executor application.
        
        This is the main entry point that:
        1. Parses and validates command-line arguments
        2. Sets up colorful emoji logging
        3. Validates configuration and expression syntax
        4. Executes the async pipeline
        5. Outputs results in the requested format
        6. Returns appropriate exit code
        
        Args:
            args: Optional command-line arguments (uses sys.argv if None)
            
        Returns:
            Exit code: 0 for success, non-zero for various error conditions
        """
        try:
            # Parse command-line arguments
            config = self.cli_parser.parse_args(args)
            
            # Set up logging
            setup_logging(config['debug'], config.get('quiet', False))
            
            # Validate configuration
            if not self.config_validator.validate_config(config):
                print("Configuration validation failed", file=sys.stderr)
                return 1
            
            # Validate expression syntax
            if not validate_expression_syntax(config['expression']):
                print("Invalid expression syntax", file=sys.stderr)
                return 1
            
            # Execute pipeline asynchronously
            result = asyncio.run(self._execute_pipeline(config))
            
            # Output results
            self._output_results(result, config)
            
            # Determine exit code based on results
            return self._get_exit_code(result)
            
        except KeyboardInterrupt:
            print("\n🛑 Operation cancelled by user", file=sys.stderr)
            return 130
        except Exception as e:
            print(f"❌ Unexpected error: {e}", file=sys.stderr)
            if config.get('debug', False):
                import traceback
                traceback.print_exc()
            return 1
    
    async def _execute_pipeline(self, config: Dict[str, Any]):
        """
        Execute the pipeline with given configuration.
        
        This method:
        1. Creates memory manager for resource tracking
        2. Initializes the appropriate pipeline controller (basic or enhanced)
        3. Executes the pipeline asynchronously
        4. Measures execution time and adds metadata
        5. Ensures proper cleanup of resources
        
        Args:
            config: Configuration dictionary containing all pipeline settings
            
        Returns:
            PipelineResult with execution results and metadata
        """
        # Create memory manager for resource tracking
        memory_manager = MemoryManager(max_memory_mb=config['max_memory_mb'])
        
        # Create async pipeline controller based on configuration
        # Enhanced controller provides detailed performance analysis
        if config.get('detailed_review', False):
            controller = EnhancedMathPipelineController(
                timeout=config['timeout'],
                debug=config['debug'],
                retry_config=config['retry_config'],
                enable_detailed_review=True
            )
        else:
            # Standard controller for normal operation
            controller = MathPipelineController(
                timeout=config['timeout'],
                debug=config['debug'],
                retry_config=config['retry_config']
            )
        
        try:
            # Execute pipeline asynchronously with timing
            start_time = time.time()
            result = await controller.execute(config['expression'])
            execution_time = time.time() - start_time
            
            # Add execution metadata for analysis and debugging
            result.execution_metadata = {
                'total_execution_time': execution_time,
                'pipeline_config': {
                    'timeout': config['timeout'],
                    'debug': config['debug'],
                    'max_memory_mb': config['max_memory_mb']
                }
            }
            
            return result
            
        finally:
            # Clean up resources asynchronously
            await controller.cleanup()
            memory_manager.cleanup()
    
    def _output_results(self, result, config: Dict[str, Any]):
        """
        Output results in the specified format.
        
        Supports two output formats:
        - text: Human-readable format with colorful emojis
        - json: Machine-readable JSON format
        
        Args:
            result: Pipeline execution result
            config: Configuration dictionary containing output preferences
        """
        if config['output_format'] == 'json':
            self._output_json(result)
        else:
            self._output_text(result, config)
    
    def _output_text(self, result, config: Dict[str, Any]):
        """
        Output results in human-readable text format with colorful emojis.
        
        The text output includes:
        - Summary statistics with color-coded success rates
        - Individual operation results with tool-specific emojis
        - Performance recommendations with helpful icons
        - Error patterns and historical statistics (if available)
        
        Args:
            result: Pipeline execution result
            config: Configuration dictionary
        """
        print("=" * 60)
        print("PIPELINE EXECUTION RESULTS")
        print("=" * 60)
        
        # Summary statistics with colorful emojis
        summary = result.summary
        success_rate = (summary.successful_operations / summary.total_operations * 100) if summary.total_operations > 0 else 0
        
        print(f"📊 Total Operations: {summary.total_operations}")
        print(f"🟢 Successful: {summary.successful_operations}")
        print(f"🔴 Failed: {summary.failed_operations}")
        
        # Color-coded success rate
        if success_rate >= 90:
            rate_emoji = "🎉"  # Excellent
        elif success_rate >= 75:
            rate_emoji = "✅"  # Good
        elif success_rate >= 50:
            rate_emoji = "⚠️"   # Warning
        else:
            rate_emoji = "❌"  # Poor
            
        print(f"{rate_emoji} Success Rate: {success_rate:.1f}%")
        print(f"⏱️  Average Execution Time: {summary.average_execution_time:.3f}s")
        
        if hasattr(result, 'execution_metadata'):
            print(f"🚀 Total Pipeline Time: {result.execution_metadata['total_execution_time']:.3f}s")
        
        print()
        
        # Individual results
        print("INDIVIDUAL RESULTS:")
        print("-" * 40)
        
        for i, exec_result in enumerate(summary.results, 1):
            # Use colorful emojis for status
            if exec_result.status == ExecutionStatus.SUCCESS:
                status_symbol = "🟢 ✅"  # Green circle + checkmark
            else:
                status_symbol = "🔴 ❌"  # Red circle + X mark
                
            print(f"{i:2d}. {status_symbol} {exec_result.original_expression}")
            
            if exec_result.status == ExecutionStatus.SUCCESS:
                # Add tool-specific emojis
                tool_emoji = {
                    'CALC': '🧮',
                    'POWER': '⚡',
                    'SAFE_DEV': '🔧'
                }.get(exec_result.tool_used.name, '🛠️')
                
                print(f"     📊 Result: {exec_result.result}")
                print(f"     ⏱️  Time: {exec_result.execution_time:.3f}s")
                print(f"     {tool_emoji} Tool: {exec_result.tool_used.name}")
            else:
                print(f"     💥 Error: {exec_result.error_message}")
                print(f"     ⏱️  Time: {exec_result.execution_time:.3f}s")
            print()
        
        # Learning insights with emojis
        insights = result.insights
        if insights.performance_recommendations:
            print("💡 PERFORMANCE RECOMMENDATIONS:")
            print("-" * 40)
            for i, rec in enumerate(insights.performance_recommendations, 1):
                print(f"💡 {i}. {rec}")
            print()
        
        # Error patterns with emojis (if any)
        if insights.error_patterns:
            print("🚨 ERROR PATTERNS:")
            print("-" * 40)
            for error_type, count in insights.error_patterns.items():
                print(f"  ❌ {error_type}: {count} occurrence(s)")
            print()
        
        # Historical statistics with emojis (if available)
        if config.get('detailed_review', False) and hasattr(result, 'historical_stats'):
            print("📈 HISTORICAL STATISTICS:")
            print("-" * 40)
            stats = result.historical_stats
            print(f"📊 Total Historical Executions: {stats.get('total_executions', 0)}")
            print(f"📈 Historical Success Rate: {stats.get('historical_success_rate', 0):.1f}%")
            print()
    
    def _output_json(self, result):
        """
        Output results in machine-readable JSON format.
        
        The JSON output includes:
        - Summary statistics and metrics
        - Individual operation results with full details
        - Learning insights and recommendations
        - Execution metadata for analysis
        
        Args:
            result: Pipeline execution result
        """
        # Convert result to JSON-serializable format
        json_result = {
            'summary': {
                'total_operations': result.summary.total_operations,
                'successful_operations': result.summary.successful_operations,
                'failed_operations': result.summary.failed_operations,
                'success_rate': (result.summary.successful_operations / result.summary.total_operations * 100) 
                               if result.summary.total_operations > 0 else 0,
                'average_execution_time': result.summary.average_execution_time
            },
            'results': [
                {
                    'expression': r.original_expression,
                    'result': r.result,
                    'status': r.status.name,
                    'execution_time': r.execution_time,
                    'tool_used': r.tool_used.name,
                    'error_message': r.error_message
                }
                for r in result.summary.results
            ],
            'insights': {
                'total_executions': result.insights.total_executions,
                'success_rate': result.insights.success_rate,
                'average_time': result.insights.average_time,
                'error_patterns': result.insights.error_patterns,
                'performance_recommendations': result.insights.performance_recommendations
            }
        }
        
        # Add execution metadata if available
        if hasattr(result, 'execution_metadata'):
            json_result['execution_metadata'] = result.execution_metadata
        
        print(json.dumps(json_result, indent=2))
    
    def _get_exit_code(self, result) -> int:
        """
        Determine appropriate exit code based on execution results.
        
        Exit codes:
        - 0: Success (all or some operations succeeded)
        - 2: No operations processed
        - 3: All operations failed
        
        Args:
            result: Pipeline execution result
            
        Returns:
            Exit code for the application
        """
        if result.summary.total_operations == 0:
            return 2  # No operations processed
        
        if result.summary.failed_operations == 0:
            return 0  # All operations successful
        
        if result.summary.successful_operations == 0:
            return 3  # All operations failed
        
        return 0  # Mixed results, but some succeeded


def main():
    """
    Main entry point for the pipeline executor application.
    
    Creates the application instance and runs it with command-line arguments.
    The exit code is used to indicate success or failure to the operating system.
    """
    app = PipelineExecutorApp()
    exit_code = app.run()
    sys.exit(exit_code)


if __name__ == '__main__':
    main()