"""Command-line interface for the pipeline executor."""

import argparse
import sys
import logging
from typing import Dict, Any
from pipeline_executor.framework.models import RetryConfig

logger = logging.getLogger(__name__)


class CLIArgumentParser:
    """Command-line argument parser with validation."""
    
    def __init__(self):
        self.parser = self._create_parser()
    
    def _create_parser(self) -> argparse.ArgumentParser:
        """Create argument parser with all options."""
        parser = argparse.ArgumentParser(
            description='Pipeline Executor - A minimal non-FSM pipeline demonstrating callables+futures',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  python agent.py --exp "2+3, 10-7, 6*9"
  python agent.py --exp "add(5,6), pow(2,3)" --timeout 10 --debug
  python agent.py --exp "2+3, 10/0, 2^8, add(1,2)" --timeout 5 --debug
            """
        )
        
        # Required arguments
        parser.add_argument(
            '--exp',
            type=str,
            required=True,
            help='Mathematical expressions to evaluate (comma-separated)'
        )
        
        # Optional arguments
        parser.add_argument(
            '--timeout',
            type=int,
            default=5,
            help='Timeout in seconds for operations (default: 5)'
        )
        
        parser.add_argument(
            '--debug',
            action='store_true',
            help='Enable debug mode with detailed logging'
        )
        
        parser.add_argument(
            '--retry-attempts',
            type=int,
            default=3,
            help='Maximum retry attempts for failed operations (default: 3)'
        )
        
        parser.add_argument(
            '--retry-backoff',
            type=float,
            default=1.5,
            help='Backoff factor for retry delays (default: 1.5)'
        )
        
        parser.add_argument(
            '--max-memory',
            type=int,
            default=100,
            help='Maximum memory usage in MB (default: 100)'
        )
        
        parser.add_argument(
            '--output-format',
            choices=['text', 'json'],
            default='text',
            help='Output format (default: text)'
        )
        
        parser.add_argument(
            '--detailed-review',
            action='store_true',
            help='Enable detailed result review and analysis'
        )
        
        parser.add_argument(
            '--quiet',
            action='store_true',
            help='Suppress non-essential output'
        )
        
        return parser
    
    def parse_args(self, args=None) -> Dict[str, Any]:
        """Parse command-line arguments and validate them."""
        parsed_args = self.parser.parse_args(args)
        
        # Validate arguments
        self._validate_args(parsed_args)
        
        # Convert to configuration dictionary
        config = self._args_to_config(parsed_args)
        
        return config
    
    def _validate_args(self, args):
        """Validate parsed arguments."""
        # Validate timeout
        if args.timeout <= 0:
            self.parser.error("Timeout must be positive")
        
        if args.timeout > 300:  # 5 minutes max
            self.parser.error("Timeout cannot exceed 300 seconds")
        
        # Validate retry attempts
        if args.retry_attempts < 1:
            self.parser.error("Retry attempts must be at least 1")
        
        if args.retry_attempts > 10:
            self.parser.error("Retry attempts cannot exceed 10")
        
        # Validate backoff factor
        if args.retry_backoff < 1.0:
            self.parser.error("Retry backoff factor must be at least 1.0")
        
        # Validate memory limit
        if args.max_memory < 10:
            self.parser.error("Maximum memory must be at least 10 MB")
        
        if args.max_memory > 1000:
            self.parser.error("Maximum memory cannot exceed 1000 MB")
        
        # Validate expression string
        if not args.exp.strip():
            self.parser.error("Expression string cannot be empty")
        
        # Check for conflicting options
        if args.quiet and args.debug:
            self.parser.error("Cannot use --quiet and --debug together")
    
    def _args_to_config(self, args) -> Dict[str, Any]:
        """Convert parsed arguments to configuration dictionary."""
        config = {
            'expression': args.exp,
            'timeout': args.timeout,
            'debug': args.debug,
            'retry_config': RetryConfig(
                max_attempts=args.retry_attempts,
                backoff_factor=args.retry_backoff
            ),
            'max_memory_mb': args.max_memory,
            'output_format': args.output_format,
            'detailed_review': args.detailed_review,
            'quiet': args.quiet
        }
        
        return config
    
    def print_help(self):
        """Print help message."""
        self.parser.print_help()


class ConfigurationValidator:
    """Validator for pipeline configuration."""
    
    @staticmethod
    def validate_config(config: Dict[str, Any]) -> bool:
        """Validate pipeline configuration."""
        required_keys = ['expression', 'timeout', 'debug', 'retry_config']
        
        # Check required keys
        for key in required_keys:
            if key not in config:
                logger.error(f"Missing required configuration key: {key}")
                return False
        
        # Validate expression
        if not isinstance(config['expression'], str) or not config['expression'].strip():
            logger.error("Expression must be a non-empty string")
            return False
        
        # Validate timeout
        if not isinstance(config['timeout'], int) or config['timeout'] <= 0:
            logger.error("Timeout must be a positive integer")
            return False
        
        # Validate retry config
        retry_config = config['retry_config']
        if not isinstance(retry_config, RetryConfig):
            logger.error("Retry config must be a RetryConfig instance")
            return False
        
        if retry_config.max_attempts < 1:
            logger.error("Retry attempts must be at least 1")
            return False
        
        if retry_config.backoff_factor < 1.0:
            logger.error("Backoff factor must be at least 1.0")
            return False
        
        logger.debug("Configuration validation passed")
        return True
    
    @staticmethod
    def get_default_config() -> Dict[str, Any]:
        """Get default configuration."""
        return {
            'expression': '',
            'timeout': 5,
            'debug': False,
            'retry_config': RetryConfig(),
            'max_memory_mb': 100,
            'output_format': 'text',
            'detailed_review': False,
            'quiet': False
        }


def setup_logging(debug: bool = False, quiet: bool = False):
    """Set up enhanced logging configuration with colors and emojis."""
    from pipeline_executor.framework.colored_logging import setup_colored_logging
    setup_colored_logging(debug, quiet)


def validate_expression_syntax(expression: str) -> bool:
    """Basic validation of expression syntax."""
    if not expression or not expression.strip():
        return False
    
    # Check for basic syntax issues
    expression = expression.strip()
    
    # Check for empty expressions after splitting
    parts = [part.strip() for part in expression.split(',')]
    if not all(parts):
        return False
    
    # Check for obviously malformed patterns
    malformed_patterns = [
        '++', '--', '**/', '//', '%%', '^^',
        '()', '(,)', ',,', 
    ]
    
    for pattern in malformed_patterns:
        if pattern in expression:
            logger.warning(f"Potentially malformed pattern detected: {pattern}")
    
    return True