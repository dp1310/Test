"""Enhanced logging with colors and emojis."""

import logging
import sys
from typing import Dict, Any


class ColoredFormatter(logging.Formatter):
    """Custom formatter with colors and emojis for different log levels."""
    
    # ANSI color codes
    COLORS = {
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR': '\033[31m',     # Red
        'CRITICAL': '\033[35m',  # Magenta
        'RESET': '\033[0m'       # Reset
    }
    
    # Emojis for different log levels
    EMOJIS = {
        'DEBUG': '🔍',
        'INFO': '✅',
        'WARNING': '⚠️',
        'ERROR': '❌',
        'CRITICAL': '💥'
    }
    
    # Component-specific emojis
    COMPONENT_EMOJIS = {
        'perceive': '👁️',
        'plan': '📋',
        'reason': '🧠',
        'act': '⚡',
        'review': '📊',
        'learn': '🎓',
        'calc': '🧮',
        'power': '💪',
        'function': '🔧',
        'memory': '💾',
        'retry': '🔄',
        'timeout': '⏰',
        'success': '🎉',
        'failed': '💔',
        'pipeline': '🚀'
    }
    
    def format(self, record):
        # Get color for log level
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        emoji = self.EMOJIS.get(record.levelname, '📝')
        
        # Add component-specific emoji based on message content
        component_emoji = self._get_component_emoji(record.getMessage().lower())
        
        # Format the message with colors and emojis
        log_message = super().format(record)
        
        # Add emojis and colors
        formatted_message = f"{color}{emoji} {component_emoji} {log_message}{self.COLORS['RESET']}"
        
        return formatted_message
    
    def _get_component_emoji(self, message: str) -> str:
        """Get component-specific emoji based on message content."""
        for keyword, emoji in self.COMPONENT_EMOJIS.items():
            if keyword in message:
                return emoji
        return ''


def setup_colored_logging(debug: bool = False, quiet: bool = False):
    """Set up enhanced logging with colors and emojis."""
    if quiet:
        level = logging.WARNING
    elif debug:
        level = logging.DEBUG
    else:
        level = logging.INFO
    
    # Create colored formatter
    formatter = ColoredFormatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S'
    )
    
    # Configure console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.handlers.clear()
    root_logger.addHandler(console_handler)
    
    # Suppress some noisy loggers in non-debug mode
    if not debug:
        logging.getLogger('concurrent.futures').setLevel(logging.WARNING)
        logging.getLogger('urllib3').setLevel(logging.WARNING)
    
    # Log the setup with emojis
    logger = logging.getLogger(__name__)
    logger.info(f"🎨 Colorful logging configured (level: {logging.getLevelName(level)})")


class EmojiLogger:
    """Enhanced logger with emoji support for different operations."""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
    
    # Standard logging methods
    def debug(self, message: str):
        """Log debug message."""
        self.logger.debug(message)
    
    def info(self, message: str):
        """Log info message."""
        self.logger.info(message)
    
    def warning(self, message: str):
        """Log warning message."""
        self.logger.warning(message)
    
    def error(self, message: str):
        """Log error message."""
        self.logger.error(message)
    
    def critical(self, message: str):
        """Log critical message."""
        self.logger.critical(message)
    
    def perceive_start(self, input_data: str):
        """Log start of perceive stage."""
        self.logger.info(f"👁️ Starting perception of input: {input_data[:50]}...")
    
    def perceive_complete(self, valid_count: int, invalid_count: int):
        """Log completion of perceive stage."""
        self.logger.info(f"👁️ Perception complete: {valid_count} valid, {invalid_count} invalid expressions")
    
    def plan_start(self, expression_count: int):
        """Log start of planning stage."""
        self.logger.info(f"📋 Planning {expression_count} expressions into callables")
    
    def plan_complete(self, callable_count: int):
        """Log completion of planning stage."""
        self.logger.info(f"📋 Planning complete: {callable_count} callables created")
    
    def reason_start(self, callable_count: int, timeout: int):
        """Log start of reasoning stage."""
        self.logger.info(f"🧠 Reasoning about {callable_count} callables with {timeout}s timeout")
    
    def reason_complete(self, worker_count: int):
        """Log completion of reasoning stage."""
        self.logger.info(f"🧠 Reasoning complete: strategy with {worker_count} workers")
    
    def act_start(self, worker_count: int, timeout: int):
        """Log start of acting stage."""
        self.logger.info(f"⚡ Acting with {worker_count} workers and {timeout}s timeout")
    
    def act_complete(self, result_count: int):
        """Log completion of acting stage."""
        self.logger.info(f"⚡ Acting complete: {result_count} results collected")
    
    def operation_success(self, expression: str, result: Any, tool: str):
        """Log successful operation."""
        self.logger.info(f"🎉 Success: {expression} = {result} ({tool})")
    
    def operation_failed(self, expression: str, error: str):
        """Log failed operation."""
        self.logger.warning(f"💔 Failed: {expression} - {error}")
    
    def review_complete(self, success_rate: float, avg_time: float):
        """Log review completion."""
        self.logger.info(f"📊 Review complete: {success_rate:.1f}% success rate, {avg_time:.3f}s avg time")
    
    def learn_complete(self, success_rate: float, recommendation_count: int):
        """Log learning completion."""
        self.logger.info(f"🎓 Learning complete: {success_rate:.1f}% success rate, {recommendation_count} recommendations")
    
    def pipeline_start(self, input_data: str):
        """Log pipeline start."""
        self.logger.info(f"🚀 Pipeline starting with input: {input_data[:100]}...")
    
    def pipeline_complete(self, execution_time: float):
        """Log pipeline completion."""
        self.logger.info(f"🚀 Pipeline completed successfully in {execution_time:.3f}s")
    
    def memory_acquired(self, size_mb: int, allocation_id: str):
        """Log memory acquisition."""
        self.logger.debug(f"💾 Acquired {size_mb}MB memory for {allocation_id}")
    
    def memory_released(self, size_mb: int, allocation_id: str):
        """Log memory release."""
        self.logger.debug(f"💾 Released {size_mb}MB memory for {allocation_id}")
    
    def retry_attempt(self, expression: str, attempt: int, max_attempts: int):
        """Log retry attempt."""
        self.logger.debug(f"🔄 Retrying {expression} (attempt {attempt}/{max_attempts})")
    
    def timeout_warning(self, operation: str, timeout: int):
        """Log timeout warning."""
        self.logger.warning(f"⏰ Timeout warning for {operation} (limit: {timeout}s)")
    
    def cleanup_start(self):
        """Log cleanup start."""
        self.logger.info(f"🧹 Starting resource cleanup")
    
    def cleanup_complete(self):
        """Log cleanup completion."""
        self.logger.info(f"🧹 Resource cleanup completed")