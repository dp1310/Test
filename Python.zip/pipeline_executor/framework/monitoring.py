"""Performance monitoring and metrics collection."""

import time
import logging
from typing import Dict, Any, List, Optional
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pipeline_executor.framework.models import ExecutionStatus, ToolType

logger = logging.getLogger(__name__)


@dataclass
class MetricPoint:
    """A single metric measurement point."""
    timestamp: float
    value: float
    tags: Dict[str, str] = field(default_factory=dict)


@dataclass
class PerformanceMetrics:
    """Performance metrics for pipeline execution."""
    stage_times: Dict[str, float] = field(default_factory=dict)
    tool_performance: Dict[ToolType, List[float]] = field(default_factory=lambda: defaultdict(list))
    memory_usage: Dict[str, float] = field(default_factory=dict)
    error_counts: Dict[str, int] = field(default_factory=lambda: defaultdict(int))
    success_rates: Dict[str, float] = field(default_factory=dict)
    throughput_metrics: Dict[str, float] = field(default_factory=dict)


class MetricsCollector:
    """Collector for pipeline performance metrics."""
    
    def __init__(self, max_history_size: int = 1000):
        self.max_history_size = max_history_size
        self._metrics_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=max_history_size))
        self._current_metrics = PerformanceMetrics()
        self._start_times: Dict[str, float] = {}
        
        logger.debug(f"MetricsCollector initialized with history size: {max_history_size}")
    
    def start_timer(self, metric_name: str, tags: Dict[str, str] = None):
        """Start timing a metric."""
        self._start_times[metric_name] = time.time()
        logger.debug(f"Started timer for: {metric_name}")
    
    def end_timer(self, metric_name: str, tags: Dict[str, str] = None) -> float:
        """End timing a metric and record the duration."""
        if metric_name not in self._start_times:
            logger.warning(f"Timer not started for metric: {metric_name}")
            return 0.0
        
        duration = time.time() - self._start_times[metric_name]
        del self._start_times[metric_name]
        
        # Record the metric
        self.record_metric(metric_name, duration, tags)
        
        logger.debug(f"Recorded timer for {metric_name}: {duration:.3f}s")
        return duration
    
    def record_metric(self, metric_name: str, value: float, tags: Dict[str, str] = None):
        """Record a metric value."""
        metric_point = MetricPoint(
            timestamp=time.time(),
            value=value,
            tags=tags or {}
        )
        
        self._metrics_history[metric_name].append(metric_point)
        logger.debug(f"Recorded metric {metric_name}: {value}")
    
    def record_stage_time(self, stage_name: str, duration: float):
        """Record execution time for a pipeline stage."""
        self._current_metrics.stage_times[stage_name] = duration
        self.record_metric(f"stage_time_{stage_name}", duration, {"type": "stage_time"})
    
    def record_tool_performance(self, tool_type: ToolType, execution_time: float, status: ExecutionStatus):
        """Record tool performance metrics."""
        self._current_metrics.tool_performance[tool_type].append(execution_time)
        
        tags = {
            "tool_type": tool_type.name,
            "status": status.name
        }
        
        self.record_metric("tool_execution_time", execution_time, tags)
        
        # Record success/failure
        if status == ExecutionStatus.SUCCESS:
            self.record_metric("tool_success", 1, tags)
        else:
            self.record_metric("tool_failure", 1, tags)
            self._current_metrics.error_counts[f"{tool_type.name}_{status.name}"] += 1
    
    def record_memory_usage(self, usage_mb: float, allocation_type: str = "general"):
        """Record memory usage metrics."""
        self._current_metrics.memory_usage[allocation_type] = usage_mb
        self.record_metric("memory_usage", usage_mb, {"allocation_type": allocation_type})
    
    def record_throughput(self, operations_per_second: float, operation_type: str = "general"):
        """Record throughput metrics."""
        self._current_metrics.throughput_metrics[operation_type] = operations_per_second
        self.record_metric("throughput", operations_per_second, {"operation_type": operation_type})
    
    def get_current_metrics(self) -> PerformanceMetrics:
        """Get current performance metrics."""
        return self._current_metrics
    
    def get_metric_history(self, metric_name: str, limit: Optional[int] = None) -> List[MetricPoint]:
        """Get historical data for a specific metric."""
        history = list(self._metrics_history[metric_name])
        
        if limit:
            history = history[-limit:]
        
        return history
    
    def get_metric_statistics(self, metric_name: str) -> Dict[str, float]:
        """Get statistical summary for a metric."""
        history = self._metrics_history[metric_name]
        
        if not history:
            return {}
        
        values = [point.value for point in history]
        
        return {
            'count': len(values),
            'min': min(values),
            'max': max(values),
            'avg': sum(values) / len(values),
            'latest': values[-1] if values else 0
        }
    
    def get_all_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of all collected metrics."""
        summary = {
            'current_metrics': {
                'stage_times': dict(self._current_metrics.stage_times),
                'memory_usage': dict(self._current_metrics.memory_usage),
                'error_counts': dict(self._current_metrics.error_counts),
                'throughput_metrics': dict(self._current_metrics.throughput_metrics)
            },
            'metric_statistics': {}
        }
        
        # Add statistics for each metric
        for metric_name in self._metrics_history:
            summary['metric_statistics'][metric_name] = self.get_metric_statistics(metric_name)
        
        # Add tool performance summary
        tool_summary = {}
        for tool_type, times in self._current_metrics.tool_performance.items():
            if times:
                tool_summary[tool_type.name] = {
                    'count': len(times),
                    'avg_time': sum(times) / len(times),
                    'min_time': min(times),
                    'max_time': max(times)
                }
        
        summary['tool_performance'] = tool_summary
        
        return summary
    
    def reset_metrics(self):
        """Reset all metrics."""
        self._metrics_history.clear()
        self._current_metrics = PerformanceMetrics()
        self._start_times.clear()
        logger.info("All metrics reset")


class PerformanceMonitor:
    """Monitor for tracking pipeline performance and identifying bottlenecks."""
    
    def __init__(self, metrics_collector: MetricsCollector = None):
        self.metrics_collector = metrics_collector or MetricsCollector()
        self._performance_thresholds = {
            'stage_time_warning': 2.0,  # seconds
            'stage_time_critical': 5.0,  # seconds
            'memory_usage_warning': 80.0,  # MB
            'memory_usage_critical': 150.0,  # MB
            'error_rate_warning': 10.0,  # percentage
            'error_rate_critical': 25.0   # percentage
        }
        
        logger.debug("PerformanceMonitor initialized")
    
    def analyze_performance(self) -> Dict[str, Any]:
        """Analyze current performance and identify issues."""
        metrics_summary = self.metrics_collector.get_all_metrics_summary()
        analysis = {
            'bottlenecks': [],
            'warnings': [],
            'recommendations': [],
            'overall_health': 'good'
        }
        
        # Analyze stage times
        stage_times = metrics_summary['current_metrics']['stage_times']
        self._analyze_stage_performance(stage_times, analysis)
        
        # Analyze memory usage
        memory_usage = metrics_summary['current_metrics']['memory_usage']
        self._analyze_memory_usage(memory_usage, analysis)
        
        # Analyze error rates
        error_counts = metrics_summary['current_metrics']['error_counts']
        self._analyze_error_rates(error_counts, analysis)
        
        # Analyze tool performance
        tool_performance = metrics_summary['tool_performance']
        self._analyze_tool_performance(tool_performance, analysis)
        
        # Determine overall health
        if analysis['bottlenecks'] or any('critical' in w for w in analysis['warnings']):
            analysis['overall_health'] = 'critical'
        elif analysis['warnings']:
            analysis['overall_health'] = 'warning'
        
        return analysis
    
    def _analyze_stage_performance(self, stage_times: Dict[str, float], analysis: Dict[str, Any]):
        """Analyze pipeline stage performance."""
        for stage, time_taken in stage_times.items():
            if time_taken > self._performance_thresholds['stage_time_critical']:
                analysis['bottlenecks'].append(f"Stage '{stage}' is critically slow: {time_taken:.3f}s")
                analysis['recommendations'].append(f"Optimize {stage} stage performance")
            elif time_taken > self._performance_thresholds['stage_time_warning']:
                analysis['warnings'].append(f"Stage '{stage}' is slow: {time_taken:.3f}s")
        
        # Find the slowest stage
        if stage_times:
            slowest_stage = max(stage_times, key=stage_times.get)
            slowest_time = stage_times[slowest_stage]
            analysis['bottlenecks'].append(f"Slowest stage: {slowest_stage} ({slowest_time:.3f}s)")
    
    def _analyze_memory_usage(self, memory_usage: Dict[str, float], analysis: Dict[str, Any]):
        """Analyze memory usage patterns."""
        for allocation_type, usage_mb in memory_usage.items():
            if usage_mb > self._performance_thresholds['memory_usage_critical']:
                analysis['warnings'].append(f"Critical memory usage in {allocation_type}: {usage_mb:.1f}MB")
                analysis['recommendations'].append(f"Reduce memory usage in {allocation_type}")
            elif usage_mb > self._performance_thresholds['memory_usage_warning']:
                analysis['warnings'].append(f"High memory usage in {allocation_type}: {usage_mb:.1f}MB")
    
    def _analyze_error_rates(self, error_counts: Dict[str, int], analysis: Dict[str, Any]):
        """Analyze error rate patterns."""
        total_errors = sum(error_counts.values())
        
        if total_errors > 0:
            # Find most common error
            most_common_error = max(error_counts, key=error_counts.get)
            error_count = error_counts[most_common_error]
            
            analysis['warnings'].append(f"Most common error: {most_common_error} ({error_count} occurrences)")
            analysis['recommendations'].append(f"Address {most_common_error} errors")
    
    def _analyze_tool_performance(self, tool_performance: Dict[str, Dict[str, float]], analysis: Dict[str, Any]):
        """Analyze tool performance patterns."""
        for tool_name, perf_data in tool_performance.items():
            avg_time = perf_data.get('avg_time', 0)
            max_time = perf_data.get('max_time', 0)
            
            if max_time > self._performance_thresholds['stage_time_critical']:
                analysis['bottlenecks'].append(f"Tool {tool_name} has slow operations (max: {max_time:.3f}s)")
            
            if avg_time > 1.0:  # More than 1 second average
                analysis['recommendations'].append(f"Consider optimizing {tool_name} tool performance")
    
    def get_performance_report(self) -> str:
        """Generate a human-readable performance report."""
        analysis = self.analyze_performance()
        metrics_summary = self.metrics_collector.get_all_metrics_summary()
        
        report = []
        report.append("PERFORMANCE ANALYSIS REPORT")
        report.append("=" * 50)
        report.append(f"Overall Health: {analysis['overall_health'].upper()}")
        report.append("")
        
        # Stage performance
        stage_times = metrics_summary['current_metrics']['stage_times']
        if stage_times:
            report.append("Stage Performance:")
            for stage, time_taken in sorted(stage_times.items()):
                report.append(f"  {stage}: {time_taken:.3f}s")
            report.append("")
        
        # Tool performance
        tool_performance = metrics_summary['tool_performance']
        if tool_performance:
            report.append("Tool Performance:")
            for tool_name, perf_data in tool_performance.items():
                report.append(f"  {tool_name}: avg={perf_data['avg_time']:.3f}s, "
                             f"count={perf_data['count']}")
            report.append("")
        
        # Bottlenecks
        if analysis['bottlenecks']:
            report.append("Bottlenecks:")
            for bottleneck in analysis['bottlenecks']:
                report.append(f"  • {bottleneck}")
            report.append("")
        
        # Warnings
        if analysis['warnings']:
            report.append("Warnings:")
            for warning in analysis['warnings']:
                report.append(f"  ⚠ {warning}")
            report.append("")
        
        # Recommendations
        if analysis['recommendations']:
            report.append("Recommendations:")
            for rec in analysis['recommendations']:
                report.append(f"  → {rec}")
            report.append("")
        
        return "\n".join(report)
    
    def set_performance_thresholds(self, thresholds: Dict[str, float]):
        """Update performance thresholds."""
        self._performance_thresholds.update(thresholds)
        logger.info(f"Updated performance thresholds: {thresholds}")