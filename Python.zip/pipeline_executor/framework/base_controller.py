"""
Base controller for pipeline execution with full async/await support.

This module provides the abstract base class for all pipeline controllers,
defining the standard pipeline execution flow and interface.
"""

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from typing import Any

from .models import PipelineContext, PipelineResult
from .colored_logging import EmojiLogger

logger = EmojiLogger(__name__)


class BasePipelineController(ABC):
    """
    Abstract base class for pipeline controllers with full async/await support.
    
    This class defines the standard pipeline execution flow:
    perceive → plan → reason → act → review → learn
    
    All methods use async/await for non-blocking execution and maximum performance.
    Subclasses must implement all abstract stage methods.
    """
    
    def __init__(self, timeout: int = 5, debug: bool = False):
        """
        Initialize the base pipeline controller.
        
        Args:
            timeout: Maximum execution time in seconds for the entire pipeline
            debug: Enable debug logging for detailed execution information
        """
        self.timeout = timeout
        self.debug = debug
        logger.logger.info(f"🚀 Pipeline controller initialized (timeout={timeout}s, debug={debug})")
    
    async def execute(self, input_data: str) -> PipelineResult:
        """
        Execute the complete pipeline with all stages.
        
        This is the main entry point that orchestrates the entire pipeline execution:
        1. Creates pipeline context
        2. Executes all stages sequentially (but each stage can be internally concurrent)
        3. Returns the final result
        
        Args:
            input_data: Raw input string to process (e.g., mathematical expressions)
            
        Returns:
            PipelineResult containing summary and insights
            
        Raises:
            asyncio.TimeoutError: If execution exceeds the configured timeout
            Exception: Any other error during pipeline execution
        """
        logger.pipeline_start(input_data)
        start_time = time.time()
        
        try:
            # Create pipeline context with input data and configuration
            context = PipelineContext(
                input_data=input_data,
                timeout=self.timeout,
                debug=self.debug
            )
            
            logger.logger.debug(f"🚀 Created pipeline context: {context}")
            
            # Execute all pipeline stages in sequence
            # Each stage can internally use concurrency for better performance
            context = await self._perceive_stage(context)
            context = await self._plan_stage(context)
            context = await self._reason_stage(context)
            context = await self._act_stage(context)
            context = await self._review_stage(context)
            context = await self._learn_stage(context)
            
            # Calculate total execution time and log completion
            execution_time = time.time() - start_time
            logger.pipeline_complete(execution_time)
            
            return context.result
            
        except asyncio.TimeoutError:
            logger.timeout_warning("pipeline execution", self.timeout)
            raise
        except Exception as e:
            logger.logger.error(f"❌ Pipeline execution failed: {e}")
            raise
    
    @abstractmethod
    async def _perceive_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Perceive stage - parse and understand input data.
        
        This stage should:
        - Parse the input data into structured format
        - Validate the parsed data
        - Filter out invalid entries
        - Prepare data for the planning stage
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with perceived data
        """
        pass
    
    @abstractmethod
    async def _plan_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Plan stage - create execution plan.
        
        This stage should:
        - Analyze the perceived data
        - Determine appropriate tools/methods for execution
        - Create callable functions or execution plans
        - Optimize the execution strategy
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with execution plan
        """
        pass
    
    @abstractmethod
    async def _reason_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Reason stage - determine execution strategy.
        
        This stage should:
        - Analyze computational requirements
        - Determine resource allocation (workers, memory, etc.)
        - Create optimal execution strategy
        - Consider performance constraints
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with execution strategy
        """
        pass
    
    @abstractmethod
    async def _act_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Act stage - execute the plan.
        
        This stage should:
        - Execute all planned operations
        - Handle concurrent execution
        - Manage timeouts and errors
        - Collect execution results
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with execution results
        """
        pass
    
    @abstractmethod
    async def _review_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Review stage - analyze results.
        
        This stage should:
        - Analyze execution results
        - Calculate performance metrics
        - Identify patterns and issues
        - Summarize outcomes
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with review summary
        """
        pass
    
    @abstractmethod
    async def _learn_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Learn stage - extract insights.
        
        This stage should:
        - Analyze historical performance
        - Generate recommendations
        - Update learning models
        - Persist insights for future use
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with learning insights
        """
        pass
    
    async def cleanup(self):
        """
        Cleanup of pipeline resources.
        
        This method should be called after pipeline execution to clean up:
        - Memory allocations
        - File handles
        - Network connections
        - Temporary resources
        
        Subclasses can override this for specific cleanup requirements.
        """
        logger.cleanup_start()
        # Base implementation does nothing - subclasses override for specific cleanup
        logger.cleanup_complete()