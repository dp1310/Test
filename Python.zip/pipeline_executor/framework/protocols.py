"""Protocol definitions for pipeline stages and components."""

from typing import Protocol, List, Any
from .models import (
    ParsedExpression, RoutedCallable, ExecutionStrategy, 
    ExecutionResult, ReviewSummary, LearningInsights, ToolType
)


class PerceiverProtocol(Protocol):
    """Protocol for expression perceivers."""
    
    def perceive(self, input_string: str) -> List[ParsedExpression]:
        """Parse input string into structured expressions."""
        ...


class PlannerProtocol(Protocol):
    """Protocol for operation planners."""
    
    def plan(self, expressions: List[ParsedExpression]) -> List[RoutedCallable]:
        """Create routed callables from parsed expressions."""
        ...


class ReasonerProtocol(Protocol):
    """Protocol for execution reasoners."""
    
    def reason(self, callables: List[RoutedCallable], timeout: int) -> ExecutionStrategy:
        """Determine execution strategy for callables."""
        ...


class ActorProtocol(Protocol):
    """Protocol for operation actors."""
    
    def act(self, strategy: ExecutionStrategy) -> List[ExecutionResult]:
        """Execute operations according to strategy."""
        ...


class ReviewerProtocol(Protocol):
    """Protocol for result reviewers."""
    
    def review(self, results: List[ExecutionResult]) -> ReviewSummary:
        """Summarize execution results."""
        ...


class LearnerProtocol(Protocol):
    """Protocol for learning components."""
    
    def learn(self, summary: ReviewSummary) -> LearningInsights:
        """Extract insights from execution summary."""
        ...


class ToolProtocol(Protocol):
    """Protocol for execution tools."""
    
    def execute(self, operation: str, *args) -> Any:
        """Execute an operation with given arguments."""
        ...


class ToolFactoryProtocol(Protocol):
    """Protocol for tool factories."""
    
    def create_tool(self, tool_type: ToolType) -> ToolProtocol:
        """Create a tool instance for the given type."""
        ...


class PerceiverFactoryProtocol(Protocol):
    """Protocol for perceiver factories."""
    
    def create_perceivers(self) -> List[PerceiverProtocol]:
        """Create perceiver instances."""
        ...