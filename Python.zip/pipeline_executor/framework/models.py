"""Core data models and enums for the pipeline framework."""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Callable, Tuple, Type
from concurrent.futures import Future


class ToolType(Enum):
    """Types of tools available for operation execution."""
    CALC = auto()
    POWER = auto()
    SAFE_DEV = auto()


class ExecutionStatus(Enum):
    """Status of operation execution."""
    SUCCESS = auto()
    ERROR = auto()
    TIMEOUT = auto()


class OperationType(Enum):
    """Types of operations that can be parsed."""
    ARITHMETIC = auto()
    POWER = auto()
    FUNCTION = auto()


class ExecutorType(Enum):
    """Types of executors for concurrent execution."""
    THREAD = auto()
    PROCESS = auto()


@dataclass
class ParsedExpression:
    """Represents a parsed mathematical expression."""
    original: str
    operation_type: OperationType
    operands: List[float]
    function_name: Optional[str] = None
    is_valid: bool = True
    error_message: Optional[str] = None


@dataclass
class RoutedCallable:
    """A callable function routed to a specific tool."""
    callable_func: Callable[[], Any]
    tool_type: ToolType
    original_expression: str
    expected_result_type: type = float


@dataclass
class ExecutorConfig:
    """Configuration for an executor."""
    executor_type: ExecutorType
    worker_count: int
    timeout: int


@dataclass
class RetryConfig:
    """Configuration for retry mechanism."""
    max_attempts: int = 3
    backoff_factor: float = 1.5
    retry_exceptions: Tuple[Type[Exception], ...] = (TimeoutError, ConnectionError)


@dataclass
class ExecutionStrategy:
    """Strategy for executing callables with specific executors."""
    executor_configs: Dict[ToolType, ExecutorConfig]
    timeout: int
    retry_config: RetryConfig
    total_workers: int
    
    def get_callables_for_tool(self, tool_type: ToolType) -> List[RoutedCallable]:
        """Get callables for a specific tool type."""
        # This will be populated by the actor during execution
        return getattr(self, f'_{tool_type.name.lower()}_callables', [])


@dataclass
class ExecutionResult:
    """Result of executing a callable."""
    original_expression: str
    result: Optional[Any]
    execution_time: float
    status: ExecutionStatus
    error_message: Optional[str] = None
    tool_used: ToolType = ToolType.CALC


@dataclass
class ReviewSummary:
    """Summary of execution results."""
    total_operations: int
    successful_operations: int
    failed_operations: int
    average_execution_time: float
    results: List[ExecutionResult]


@dataclass
class LearningInsights:
    """Insights learned from execution."""
    total_executions: int
    success_rate: float
    average_time: float
    error_patterns: Dict[str, int]
    performance_recommendations: List[str]


@dataclass
class PipelineResult:
    """Final result of pipeline execution."""
    summary: ReviewSummary
    insights: LearningInsights


@dataclass
class PipelineContext:
    """Context object that flows through pipeline stages."""
    input_data: str
    timeout: int
    debug: bool
    stage_results: Dict[str, Any] = field(default_factory=dict)
    errors: List[Exception] = field(default_factory=list)
    metrics: Dict[str, float] = field(default_factory=dict)
    result: Optional[PipelineResult] = None