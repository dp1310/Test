"""Cross-cutting concern decorators for the pipeline framework."""

import time
import gc
import logging
from functools import wraps
from typing import Callable, Any, Tuple, Type

# Try to import psutil, fall back to basic implementation if not available
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

logger = logging.getLogger(__name__)


def retry(max_attempts: int = 3, backoff_factor: float = 1.5, 
          retry_exceptions: Tuple[Type[Exception], ...] = (TimeoutError, ConnectionError)):
    """Decorator for automatic retry with exponential backoff."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except retry_exceptions as e:
                    last_exception = e
                    if attempt < max_attempts - 1:
                        sleep_time = backoff_factor ** attempt
                        time.sleep(sleep_time)
                        logger.debug(f"Retrying {func.__name__} (attempt {attempt + 2}/{max_attempts}) after {sleep_time:.2f}s")
                    continue
                except Exception as e:
                    # Non-retryable exception
                    raise e
            raise last_exception
        return wrapper
    return decorator


def timing(stage_name: str):
    """Decorator to measure execution time."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                execution_time = time.time() - start_time
                logger.info(f"{stage_name} completed in {execution_time:.3f}s")
                return result
            except Exception as e:
                execution_time = time.time() - start_time
                logger.error(f"{stage_name} failed after {execution_time:.3f}s: {e}")
                raise
        return wrapper
    return decorator


def memory_managed(max_memory_mb: int = 10):
    """Decorator for memory usage monitoring."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if PSUTIL_AVAILABLE:
                process = psutil.Process()
                initial_memory = process.memory_info().rss / 1024 / 1024
            else:
                initial_memory = 0
            
            try:
                result = func(*args, **kwargs)
                
                if PSUTIL_AVAILABLE:
                    final_memory = process.memory_info().rss / 1024 / 1024
                    memory_used = final_memory - initial_memory
                    
                    if memory_used > max_memory_mb:
                        logger.warning(f"High memory usage in {func.__name__}: {memory_used:.2f}MB")
                
                return result
            except Exception as e:
                gc.collect()  # Force garbage collection on error
                raise
        return wrapper
    return decorator


def error_boundary(error_handler: Callable[[Exception], Any] = None):
    """Decorator for graceful error handling."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if error_handler:
                    return error_handler(e)
                logger.error(f"Error in {func.__name__}: {e}")
                raise
        return wrapper
    return decorator


def cache_result(ttl_seconds: int = 300):
    """Decorator for result caching with TTL."""
    cache = {}
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key from function name and arguments
            key = f"{func.__name__}:{hash(str(args) + str(sorted(kwargs.items())))}"
            current_time = time.time()
            
            if key in cache:
                result, timestamp = cache[key]
                if current_time - timestamp < ttl_seconds:
                    logger.debug(f"Cache hit for {func.__name__}")
                    return result
            
            result = func(*args, **kwargs)
            cache[key] = (result, current_time)
            logger.debug(f"Cache miss for {func.__name__}, result cached")
            return result
        return wrapper
    return decorator