"""Resource management and cleanup utilities."""

import gc
import logging
import threading
import weakref
from typing import Dict, Any, List, Optional, Set
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class ResourceTracker:
    """Track and manage system resources."""
    
    def __init__(self):
        self._tracked_resources: Dict[str, weakref.WeakSet] = {}
        self._resource_counts: Dict[str, int] = {}
        self._lock = threading.Lock()
        
        logger.debug("ResourceTracker initialized")
    
    def register_resource(self, resource: Any, resource_type: str):
        """Register a resource for tracking."""
        with self._lock:
            if resource_type not in self._tracked_resources:
                self._tracked_resources[resource_type] = weakref.WeakSet()
                self._resource_counts[resource_type] = 0
            
            self._tracked_resources[resource_type].add(resource)
            self._resource_counts[resource_type] += 1
            
            logger.debug(f"Registered {resource_type} resource (total: {self._resource_counts[resource_type]})")
    
    def unregister_resource(self, resource: Any, resource_type: str):
        """Unregister a resource."""
        with self._lock:
            if resource_type in self._tracked_resources:
                try:
                    self._tracked_resources[resource_type].discard(resource)
                    self._resource_counts[resource_type] = max(0, self._resource_counts[resource_type] - 1)
                    logger.debug(f"Unregistered {resource_type} resource (remaining: {self._resource_counts[resource_type]})")
                except KeyError:
                    pass
    
    def get_resource_count(self, resource_type: str) -> int:
        """Get count of tracked resources by type."""
        return self._resource_counts.get(resource_type, 0)
    
    def get_all_resource_counts(self) -> Dict[str, int]:
        """Get counts of all tracked resource types."""
        with self._lock:
            return dict(self._resource_counts)
    
    def cleanup_dead_references(self):
        """Clean up dead weak references."""
        with self._lock:
            for resource_type, weak_set in self._tracked_resources.items():
                # WeakSet automatically removes dead references
                actual_count = len(weak_set)
                if actual_count != self._resource_counts[resource_type]:
                    logger.debug(f"Cleaned up dead references for {resource_type}: "
                               f"{self._resource_counts[resource_type]} -> {actual_count}")
                    self._resource_counts[resource_type] = actual_count


class ExecutorManager:
    """Manage executor lifecycle and cleanup."""
    
    def __init__(self, resource_tracker: ResourceTracker = None):
        self._executors: Dict[str, Any] = {}
        self._executor_configs: Dict[str, Dict[str, Any]] = {}
        self._resource_tracker = resource_tracker or ResourceTracker()
        self._lock = threading.Lock()
        
        logger.debug("ExecutorManager initialized")
    
    def get_or_create_executor(self, executor_id: str, executor_type: str, 
                              max_workers: int, **kwargs) -> Any:
        """Get existing executor or create new one."""
        with self._lock:
            if executor_id in self._executors:
                logger.debug(f"Reusing existing executor: {executor_id}")
                return self._executors[executor_id]
            
            # Create new executor
            if executor_type == 'thread':
                executor = ThreadPoolExecutor(max_workers=max_workers, **kwargs)
            elif executor_type == 'process':
                executor = ProcessPoolExecutor(max_workers=max_workers, **kwargs)
            else:
                raise ValueError(f"Unknown executor type: {executor_type}")
            
            self._executors[executor_id] = executor
            self._executor_configs[executor_id] = {
                'type': executor_type,
                'max_workers': max_workers,
                'kwargs': kwargs
            }
            
            # Track the resource
            self._resource_tracker.register_resource(executor, f"{executor_type}_executor")
            
            logger.info(f"Created {executor_type} executor '{executor_id}' with {max_workers} workers")
            return executor
    
    def shutdown_executor(self, executor_id: str, wait: bool = True):
        """Shutdown a specific executor."""
        with self._lock:
            if executor_id in self._executors:
                executor = self._executors[executor_id]
                config = self._executor_configs[executor_id]
                
                try:
                    executor.shutdown(wait=wait)
                    logger.info(f"Shut down executor '{executor_id}' ({config['type']})")
                except Exception as e:
                    logger.error(f"Error shutting down executor '{executor_id}': {e}")
                finally:
                    # Untrack the resource
                    self._resource_tracker.unregister_resource(executor, f"{config['type']}_executor")
                    
                    del self._executors[executor_id]
                    del self._executor_configs[executor_id]
    
    def shutdown_all_executors(self, wait: bool = True):
        """Shutdown all managed executors."""
        executor_ids = list(self._executors.keys())
        
        for executor_id in executor_ids:
            self.shutdown_executor(executor_id, wait=wait)
        
        logger.info(f"Shut down all {len(executor_ids)} executors")
    
    def get_executor_stats(self) -> Dict[str, Any]:
        """Get statistics about managed executors."""
        with self._lock:
            stats = {
                'total_executors': len(self._executors),
                'executors_by_type': {},
                'executor_details': {}
            }
            
            for executor_id, config in self._executor_configs.items():
                executor_type = config['type']
                
                # Count by type
                if executor_type not in stats['executors_by_type']:
                    stats['executors_by_type'][executor_type] = 0
                stats['executors_by_type'][executor_type] += 1
                
                # Detailed info
                stats['executor_details'][executor_id] = {
                    'type': executor_type,
                    'max_workers': config['max_workers'],
                    'active': executor_id in self._executors
                }
            
            return stats


class GarbageCollectionManager:
    """Manage garbage collection optimization."""
    
    def __init__(self):
        self._gc_stats = {
            'collections_triggered': 0,
            'objects_collected': 0,
            'memory_freed_mb': 0.0
        }
        
        logger.debug("GarbageCollectionManager initialized")
    
    def force_collection(self) -> Dict[str, Any]:
        """Force garbage collection and return statistics."""
        # Get memory before collection
        try:
            import psutil
            process = psutil.Process()
            memory_before = process.memory_info().rss / 1024 / 1024
        except ImportError:
            memory_before = 0
        
        # Force collection
        collected = gc.collect()
        
        # Get memory after collection
        try:
            memory_after = process.memory_info().rss / 1024 / 1024
            memory_freed = max(0, memory_before - memory_after)
        except (ImportError, NameError):
            memory_freed = 0
        
        # Update stats
        self._gc_stats['collections_triggered'] += 1
        self._gc_stats['objects_collected'] += collected
        self._gc_stats['memory_freed_mb'] += memory_freed
        
        result = {
            'objects_collected': collected,
            'memory_freed_mb': memory_freed,
            'memory_before_mb': memory_before,
            'memory_after_mb': memory_after if 'memory_after' in locals() else 0
        }
        
        logger.info(f"Garbage collection: {collected} objects collected, {memory_freed:.2f}MB freed")
        return result
    
    def get_gc_stats(self) -> Dict[str, Any]:
        """Get garbage collection statistics."""
        return dict(self._gc_stats)
    
    def optimize_gc_thresholds(self):
        """Optimize garbage collection thresholds for better performance."""
        # Get current thresholds
        current_thresholds = gc.get_threshold()
        
        # Set more aggressive thresholds for better memory management
        # These values can be tuned based on application characteristics
        new_thresholds = (700, 10, 10)  # Default is usually (700, 10, 10)
        
        gc.set_threshold(*new_thresholds)
        
        logger.info(f"GC thresholds updated: {current_thresholds} -> {new_thresholds}")


class ResourceManager:
    """Comprehensive resource manager for the pipeline."""
    
    def __init__(self):
        self.resource_tracker = ResourceTracker()
        self.executor_manager = ExecutorManager(self.resource_tracker)
        self.gc_manager = GarbageCollectionManager()
        self._cleanup_callbacks: List[callable] = []
        
        # Optimize GC thresholds
        self.gc_manager.optimize_gc_thresholds()
        
        logger.info("ResourceManager initialized with all components")
    
    def register_cleanup_callback(self, callback: callable):
        """Register a callback to be called during cleanup."""
        self._cleanup_callbacks.append(callback)
        logger.debug(f"Registered cleanup callback: {callback.__name__}")
    
    @contextmanager
    def managed_resource(self, resource: Any, resource_type: str, cleanup_func: callable = None):
        """Context manager for automatic resource cleanup."""
        self.resource_tracker.register_resource(resource, resource_type)
        
        try:
            yield resource
        finally:
            if cleanup_func:
                try:
                    cleanup_func(resource)
                except Exception as e:
                    logger.error(f"Error in cleanup function for {resource_type}: {e}")
            
            self.resource_tracker.unregister_resource(resource, resource_type)
    
    def cleanup_all_resources(self, force_gc: bool = True):
        """Clean up all managed resources."""
        logger.info("Starting comprehensive resource cleanup")
        
        # Execute cleanup callbacks
        for callback in self._cleanup_callbacks:
            try:
                callback()
                logger.debug(f"Executed cleanup callback: {callback.__name__}")
            except Exception as e:
                logger.error(f"Error in cleanup callback {callback.__name__}: {e}")
        
        # Shutdown all executors
        self.executor_manager.shutdown_all_executors(wait=True)
        
        # Clean up dead references
        self.resource_tracker.cleanup_dead_references()
        
        # Force garbage collection if requested
        if force_gc:
            gc_result = self.gc_manager.force_collection()
            logger.info(f"Forced GC collected {gc_result['objects_collected']} objects")
        
        logger.info("Resource cleanup completed")
    
    def get_resource_summary(self) -> Dict[str, Any]:
        """Get comprehensive resource usage summary."""
        return {
            'tracked_resources': self.resource_tracker.get_all_resource_counts(),
            'executor_stats': self.executor_manager.get_executor_stats(),
            'gc_stats': self.gc_manager.get_gc_stats(),
            'cleanup_callbacks': len(self._cleanup_callbacks)
        }
    
    def optimize_performance(self):
        """Apply performance optimizations."""
        logger.info("Applying performance optimizations")
        
        # Optimize GC thresholds
        self.gc_manager.optimize_gc_thresholds()
        
        # Clean up dead references
        self.resource_tracker.cleanup_dead_references()
        
        # Force a garbage collection to start fresh
        self.gc_manager.force_collection()
        
        logger.info("Performance optimizations applied")


# Global resource manager instance
_global_resource_manager: Optional[ResourceManager] = None


def get_global_resource_manager() -> ResourceManager:
    """Get the global resource manager instance."""
    global _global_resource_manager
    
    if _global_resource_manager is None:
        _global_resource_manager = ResourceManager()
    
    return _global_resource_manager


def cleanup_global_resources():
    """Clean up global resources."""
    global _global_resource_manager
    
    if _global_resource_manager is not None:
        _global_resource_manager.cleanup_all_resources()
        _global_resource_manager = None
        logger.info("Global resources cleaned up")