"""Functional utility functions and memory management."""

import logging
from typing import Any, Type, Dict, Optional, Callable
from collections import defaultdict

logger = logging.getLogger(__name__)


class ObjectPool:
    """Simple object pool for resource reuse."""
    
    def __init__(self):
        self._pools: Dict[Type, list] = defaultdict(list)
    
    def get(self, obj_type: Type) -> Any:
        """Get an object from the pool or create a new one."""
        pool = self._pools[obj_type]
        if pool:
            obj = pool.pop()
            logger.debug(f"Reused {obj_type.__name__} from pool")
            return obj
        else:
            obj = obj_type()
            logger.debug(f"Created new {obj_type.__name__}")
            return obj
    
    def put(self, obj: Any):
        """Return an object to the pool."""
        obj_type = type(obj)
        self._pools[obj_type].append(obj)
        logger.debug(f"Returned {obj_type.__name__} to pool")
    
    def clear(self):
        """Clear all pools."""
        self._pools.clear()
        logger.debug("Cleared all object pools")


class MemoryManager:
    """Memory manager with object pooling and usage tracking."""
    
    def __init__(self, max_memory_mb: int = 100):
        self._max_memory_mb = max_memory_mb
        self._current_usage = 0
        self._memory_pool = ObjectPool()
        self._allocations: Dict[str, int] = {}
    
    def acquire_memory(self, size_mb: int, allocation_id: str = "default") -> bool:
        """Attempt to acquire memory allocation."""
        if self._current_usage + size_mb <= self._max_memory_mb:
            self._current_usage += size_mb
            self._allocations[allocation_id] = self._allocations.get(allocation_id, 0) + size_mb
            logger.debug(f"Acquired {size_mb}MB memory for {allocation_id}")
            return True
        else:
            logger.warning(f"Memory allocation failed: {size_mb}MB requested, {self._max_memory_mb - self._current_usage}MB available")
            return False
    
    def release_memory(self, size_mb: int, allocation_id: str = "default"):
        """Release memory allocation."""
        self._current_usage = max(0, self._current_usage - size_mb)
        if allocation_id in self._allocations:
            self._allocations[allocation_id] = max(0, self._allocations[allocation_id] - size_mb)
            if self._allocations[allocation_id] == 0:
                del self._allocations[allocation_id]
        logger.debug(f"Released {size_mb}MB memory for {allocation_id}")
    
    def get_pooled_object(self, obj_type: Type) -> Any:
        """Get an object from the pool."""
        return self._memory_pool.get(obj_type)
    
    def return_pooled_object(self, obj: Any):
        """Return an object to the pool."""
        self._memory_pool.put(obj)
    
    def get_memory_usage(self) -> Dict[str, Any]:
        """Get current memory usage statistics."""
        return {
            'current_usage_mb': self._current_usage,
            'max_memory_mb': self._max_memory_mb,
            'utilization_percent': (self._current_usage / self._max_memory_mb) * 100,
            'allocations': dict(self._allocations)
        }
    
    def cleanup(self):
        """Clean up memory manager resources."""
        self._memory_pool.clear()
        self._allocations.clear()
        self._current_usage = 0
        logger.info("Memory manager cleaned up")


# Functional utility functions
def safe_divide(left: float, right: float) -> float:
    """Safely divide two numbers, returning inf for division by zero."""
    return left / right if right != 0 else float('inf')


def safe_modulo(left: float, right: float) -> float:
    """Safely compute modulo, returning nan for modulo by zero."""
    return left % right if right != 0 else float('nan')


def is_valid_number(value: Any) -> bool:
    """Check if a value is a valid number."""
    try:
        float(value)
        return True
    except (ValueError, TypeError):
        return False


def clamp(value: float, min_val: float, max_val: float) -> float:
    """Clamp a value between min and max bounds."""
    return max(min_val, min(value, max_val))


def compose(*functions):
    """Compose multiple functions into a single function."""
    from functools import reduce
    return lambda x: reduce(lambda acc, f: f(acc), functions, x)


def curry(func: Callable) -> Callable:
    """Simple currying implementation."""
    def curried(*args, **kwargs):
        if len(args) + len(kwargs) >= func.__code__.co_argcount:
            return func(*args, **kwargs)
        return lambda *more_args, **more_kwargs: curried(*(args + more_args), **{**kwargs, **more_kwargs})
    return curried


# Predicate functions for functional programming
def is_arithmetic_operation(op: str) -> bool:
    """Check if operation is arithmetic."""
    return op in {'+', '-', '*', '/', '%'}


def is_power_operation(op: str) -> bool:
    """Check if operation is power-related."""
    return op in {'^', '**'}


def is_function_call(expr: str) -> bool:
    """Check if expression is a function call."""
    return '(' in expr and ')' in expr and any(c.isalpha() for c in expr)


def is_cpu_intensive_operation(op: str) -> bool:
    """Check if operation is CPU intensive."""
    return op in {'^', '**', 'pow'}


# Error handling utilities
def create_error_handler(default_value: Any = None, log_errors: bool = True) -> Callable:
    """Create a generic error handler function."""
    def error_handler(exception: Exception) -> Any:
        if log_errors:
            logger.error(f"Handled error: {exception}")
        return default_value
    return error_handler


def with_fallback(primary_func: Callable, fallback_func: Callable) -> Callable:
    """Create a function that falls back to another if the primary fails."""
    def wrapper(*args, **kwargs):
        try:
            return primary_func(*args, **kwargs)
        except Exception as e:
            logger.debug(f"Primary function failed: {e}, using fallback")
            return fallback_func(*args, **kwargs)
    return wrapper