"""
Pipeline Executor - A minimal non-FSM pipeline demonstrating callables+futures with fan-out/in patterns.
"""

__version__ = "1.0.0"
__author__ = "Pipeline Executor Team"