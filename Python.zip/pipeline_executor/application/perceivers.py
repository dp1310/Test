"""Perceiver implementations for parsing mathematical expressions."""

import re
import logging
from typing import List
from pipeline_executor.framework.models import ParsedExpression, OperationType
from pipeline_executor.framework.decorators import timing, cache_result
from pipeline_executor.framework.utils import is_valid_number

logger = logging.getLogger(__name__)


class RegexPerceiver:
    """Regex-based perceiver for mathematical expressions."""
    
    def __init__(self):
        # Compile regex patterns for better performance
        self._arithmetic_pattern = re.compile(r'(\d+(?:\.\d+)?)\s*([+\-*/%])\s*(\d+(?:\.\d+)?)')
        self._power_pattern = re.compile(r'(\d+(?:\.\d+)?)\s*(\^|\*\*)\s*(\d+(?:\.\d+)?)')
        self._function_pattern = re.compile(r'([a-zA-Z]+)\s*\(\s*(\d+(?:\.\d+)?(?:\s*,\s*\d+(?:\.\d+)?)*)\s*\)')
        self._malformed_pattern = re.compile(r'\d+[+\-*/%^]{2,}\d+|[+\-*/%^]{2,}|\d+[+\-*/%^]$|^[+\-*/%^]\d+')
        
        logger.debug("RegexPerceiver initialized with compiled patterns")
    
    @timing("regex_perceive")
    def perceive(self, input_string: str) -> List[ParsedExpression]:
        """Parse input string using regex patterns."""
        logger.debug(f"RegexPerceiver processing: {input_string}")
        
        expressions = []
        
        # Split input by commas but be careful with function calls
        raw_expressions = self._smart_split(input_string)
        
        for expr in raw_expressions:
            if not expr:
                continue
                
            parsed_expr = self._parse_single_expression(expr)
            expressions.append(parsed_expr)
        
        logger.info(f"RegexPerceiver found {len(expressions)} expressions")
        return expressions
    
    def _parse_single_expression(self, expr: str) -> ParsedExpression:
        """Parse a single expression using regex patterns."""
        expr = expr.strip()
        
        # Check for malformed expressions first
        if self._malformed_pattern.search(expr):
            logger.warning(f"Malformed expression detected: {expr}")
            return ParsedExpression(
                original=expr,
                operation_type=OperationType.ARITHMETIC,
                operands=[],
                is_valid=False,
                error_message=f"Malformed expression: {expr}"
            )
        
        # Try to match function calls
        func_match = self._function_pattern.match(expr)
        if func_match:
            return self._parse_function_call(expr, func_match)
        
        # Try to match power operations
        power_match = self._power_pattern.search(expr)
        if power_match:
            return self._parse_power_operation(expr, power_match)
        
        # Try to match arithmetic operations
        arith_match = self._arithmetic_pattern.search(expr)
        if arith_match:
            return self._parse_arithmetic_operation(expr, arith_match)
        
        # If no pattern matches, it's invalid
        logger.warning(f"No pattern matched for expression: {expr}")
        return ParsedExpression(
            original=expr,
            operation_type=OperationType.ARITHMETIC,
            operands=[],
            is_valid=False,
            error_message=f"Unrecognized expression format: {expr}"
        )
    
    def _parse_function_call(self, expr: str, match) -> ParsedExpression:
        """Parse function call expression."""
        function_name = match.group(1)
        args_str = match.group(2)
        
        # Parse arguments
        args = []
        for arg in args_str.split(','):
            arg = arg.strip()
            if is_valid_number(arg):
                args.append(float(arg))
            else:
                return ParsedExpression(
                    original=expr,
                    operation_type=OperationType.FUNCTION,
                    operands=[],
                    function_name=function_name,
                    is_valid=False,
                    error_message=f"Invalid argument in function call: {arg}"
                )
        
        return ParsedExpression(
            original=expr,
            operation_type=OperationType.FUNCTION,
            operands=args,
            function_name=function_name,
            is_valid=True
        )
    
    def _parse_power_operation(self, expr: str, match) -> ParsedExpression:
        """Parse power operation expression."""
        left = float(match.group(1))
        operator = match.group(2)
        right = float(match.group(3))
        
        return ParsedExpression(
            original=expr,
            operation_type=OperationType.POWER,
            operands=[left, right],
            is_valid=True
        )
    
    def _parse_arithmetic_operation(self, expr: str, match) -> ParsedExpression:
        """Parse arithmetic operation expression."""
        left = float(match.group(1))
        operator = match.group(2)
        right = float(match.group(3))
        
        return ParsedExpression(
            original=expr,
            operation_type=OperationType.ARITHMETIC,
            operands=[left, right],
            is_valid=True
        )
    
    def _smart_split(self, input_string: str) -> List[str]:
        """Smart split that handles function calls with parentheses."""
        expressions = []
        current_expr = ""
        paren_count = 0
        
        for char in input_string:
            if char == '(':
                paren_count += 1
                current_expr += char
            elif char == ')':
                paren_count -= 1
                current_expr += char
            elif char == ',' and paren_count == 0:
                if current_expr.strip():
                    expressions.append(current_expr.strip())
                current_expr = ""
            else:
                current_expr += char
        
        # Add the last expression
        if current_expr.strip():
            expressions.append(current_expr.strip())
        
        return expressions


class FunctionPerceiver:
    """Function-style perceiver using algorithmic parsing."""
    
    def __init__(self):
        self._operators = {'+', '-', '*', '/', '%', '^', '**'}
        self._functions = {'add', 'sub', 'mul', 'div', 'pow', 'mod'}
        logger.debug("FunctionPerceiver initialized")
    
    @timing("function_perceive")
    def perceive(self, input_string: str) -> List[ParsedExpression]:
        """Parse input string using algorithmic approach."""
        logger.debug(f"FunctionPerceiver processing: {input_string}")
        
        expressions = []
        
        # Split input by commas but be careful with function calls
        raw_expressions = self._smart_split(input_string)
        
        for expr in raw_expressions:
            if not expr:
                continue
                
            parsed_expr = self._parse_with_tokenization(expr)
            expressions.append(parsed_expr)
        
        logger.info(f"FunctionPerceiver found {len(expressions)} expressions")
        return expressions
    
    def _parse_with_tokenization(self, expr: str) -> ParsedExpression:
        """Parse expression using tokenization approach."""
        expr = expr.strip()
        tokens = self._tokenize(expr)
        
        if not tokens:
            return ParsedExpression(
                original=expr,
                operation_type=OperationType.ARITHMETIC,
                operands=[],
                is_valid=False,
                error_message="Empty expression"
            )
        
        # Check for function call pattern
        if len(tokens) >= 4 and tokens[1] == '(' and tokens[-1] == ')':
            return self._parse_function_tokens(expr, tokens)
        
        # Check for binary operation pattern
        if len(tokens) == 3:
            return self._parse_binary_operation_tokens(expr, tokens)
        
        # Invalid token pattern
        return ParsedExpression(
            original=expr,
            operation_type=OperationType.ARITHMETIC,
            operands=[],
            is_valid=False,
            error_message=f"Invalid token pattern: {tokens}"
        )
    
    def _tokenize(self, expr: str) -> List[str]:
        """Tokenize expression into components."""
        tokens = []
        current_token = ""
        
        i = 0
        while i < len(expr):
            char = expr[i]
            
            if char.isspace():
                if current_token:
                    tokens.append(current_token)
                    current_token = ""
            elif char in '(),':
                if current_token:
                    tokens.append(current_token)
                    current_token = ""
                tokens.append(char)
            elif char == '*' and i + 1 < len(expr) and expr[i + 1] == '*':
                if current_token:
                    tokens.append(current_token)
                    current_token = ""
                tokens.append('**')
                i += 1  # Skip next character
            elif char in self._operators:
                if current_token:
                    tokens.append(current_token)
                    current_token = ""
                tokens.append(char)
            else:
                current_token += char
            
            i += 1
        
        if current_token:
            tokens.append(current_token)
        
        return tokens
    
    def _parse_function_tokens(self, expr: str, tokens: List[str]) -> ParsedExpression:
        """Parse function call from tokens."""
        function_name = tokens[0]
        
        if function_name.lower() not in self._functions:
            return ParsedExpression(
                original=expr,
                operation_type=OperationType.FUNCTION,
                operands=[],
                function_name=function_name,
                is_valid=False,
                error_message=f"Unknown function: {function_name}"
            )
        
        # Extract arguments between parentheses
        arg_tokens = tokens[2:-1]  # Skip function name, '(', and ')'
        args = []
        
        current_arg = ""
        for token in arg_tokens:
            if token == ',':
                if current_arg and is_valid_number(current_arg):
                    args.append(float(current_arg))
                    current_arg = ""
                else:
                    return ParsedExpression(
                        original=expr,
                        operation_type=OperationType.FUNCTION,
                        operands=[],
                        function_name=function_name,
                        is_valid=False,
                        error_message=f"Invalid argument: {current_arg}"
                    )
            else:
                current_arg += token
        
        # Add the last argument
        if current_arg and is_valid_number(current_arg):
            args.append(float(current_arg))
        elif current_arg:
            return ParsedExpression(
                original=expr,
                operation_type=OperationType.FUNCTION,
                operands=[],
                function_name=function_name,
                is_valid=False,
                error_message=f"Invalid argument: {current_arg}"
            )
        
        return ParsedExpression(
            original=expr,
            operation_type=OperationType.FUNCTION,
            operands=args,
            function_name=function_name,
            is_valid=True
        )
    
    def _parse_binary_operation_tokens(self, expr: str, tokens: List[str]) -> ParsedExpression:
        """Parse binary operation from tokens."""
        left_str, operator, right_str = tokens
        
        # Validate operands
        if not is_valid_number(left_str) or not is_valid_number(right_str):
            return ParsedExpression(
                original=expr,
                operation_type=OperationType.ARITHMETIC,
                operands=[],
                is_valid=False,
                error_message=f"Invalid operands: {left_str}, {right_str}"
            )
        
        left = float(left_str)
        right = float(right_str)
        
        # Determine operation type
        if operator in {'^', '**'}:
            operation_type = OperationType.POWER
        else:
            operation_type = OperationType.ARITHMETIC
        
        return ParsedExpression(
            original=expr,
            operation_type=operation_type,
            operands=[left, right],
            is_valid=True
        )
    
    def _smart_split(self, input_string: str) -> List[str]:
        """Smart split that handles function calls with parentheses."""
        expressions = []
        current_expr = ""
        paren_count = 0
        
        for char in input_string:
            if char == '(':
                paren_count += 1
                current_expr += char
            elif char == ')':
                paren_count -= 1
                current_expr += char
            elif char == ',' and paren_count == 0:
                if current_expr.strip():
                    expressions.append(current_expr.strip())
                current_expr = ""
            else:
                current_expr += char
        
        # Add the last expression
        if current_expr.strip():
            expressions.append(current_expr.strip())
        
        return expressions