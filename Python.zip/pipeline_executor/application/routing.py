"""Routing strategy implementations using functional approach."""

import logging
from abc import ABC, abstractmethod
from typing import List, Tuple, Callable
from pipeline_executor.framework.models import ParsedExpression, OperationType, ToolType

logger = logging.getLogger(__name__)


class RoutingStrategy(ABC):
    """Abstract routing strategy for tool selection."""
    
    @abstractmethod
    def route(self, expression: ParsedExpression) -> ToolType:
        """Route expression to appropriate tool type."""
        pass


class DefaultRoutingStrategy(RoutingStrategy):
    """Default routing strategy using predicate-based functional approach."""
    
    def __init__(self):
        # Functional routing: predicates and mappings
        self._routing_rules: List[Tuple[Callable[[ParsedExpression], bool], ToolType]] = [
            (lambda expr: expr.operation_type == OperationType.FUNCTION, ToolType.SAFE_DEV),
            (lambda expr: expr.operation_type == OperationType.POWER, ToolType.POWER),
            (lambda expr: expr.operation_type == OperationType.ARITHMETIC, ToolType.CALC)
        ]
        
        logger.debug("DefaultRoutingStrategy initialized with functional rules")
    
    def route(self, expression: ParsedExpression) -> ToolType:
        """Route expression using functional predicate matching."""
        logger.debug(f"Routing expression: {expression.original}")
        
        # Functional routing: find first matching predicate
        for predicate, tool_type in self._routing_rules:
            if predicate(expression):
                logger.debug(f"Routed to {tool_type.name} tool")
                return tool_type
        
        # Default fallback
        logger.debug("Using default CALC tool")
        return ToolType.CALC


class CustomRoutingStrategy(RoutingStrategy):
    """Custom routing strategy with additional logic."""
    
    def __init__(self):
        # More sophisticated routing rules
        self._function_tool_mapping = {
            'add': ToolType.SAFE_DEV,
            'sub': ToolType.SAFE_DEV,
            'mul': ToolType.SAFE_DEV,
            'div': ToolType.SAFE_DEV,
            'pow': ToolType.POWER,  # Route pow function to power tool
            'mod': ToolType.CALC    # Route mod function to calc tool
        }
        
        self._operator_tool_mapping = {
            '+': ToolType.CALC,
            '-': ToolType.CALC,
            '*': ToolType.CALC,
            '/': ToolType.CALC,
            '%': ToolType.CALC,
            '^': ToolType.POWER,
            '**': ToolType.POWER
        }
        
        logger.debug("CustomRoutingStrategy initialized")
    
    def route(self, expression: ParsedExpression) -> ToolType:
        """Route expression using custom logic."""
        logger.debug(f"Custom routing expression: {expression.original}")
        
        if expression.operation_type == OperationType.FUNCTION:
            func_name = expression.function_name.lower() if expression.function_name else ''
            tool_type = self._function_tool_mapping.get(func_name, ToolType.SAFE_DEV)
            logger.debug(f"Function {func_name} routed to {tool_type.name}")
            return tool_type
        
        elif expression.operation_type == OperationType.POWER:
            logger.debug("Power operation routed to POWER tool")
            return ToolType.POWER
        
        elif expression.operation_type == OperationType.ARITHMETIC:
            # Could add more sophisticated logic here based on operands
            logger.debug("Arithmetic operation routed to CALC tool")
            return ToolType.CALC
        
        # Default fallback
        logger.debug("Using default CALC tool")
        return ToolType.CALC


class LoadBalancingRoutingStrategy(RoutingStrategy):
    """Routing strategy that considers load balancing."""
    
    def __init__(self):
        self._tool_usage_count = {
            ToolType.CALC: 0,
            ToolType.POWER: 0,
            ToolType.SAFE_DEV: 0
        }
        
        self._base_strategy = DefaultRoutingStrategy()
        logger.debug("LoadBalancingRoutingStrategy initialized")
    
    def route(self, expression: ParsedExpression) -> ToolType:
        """Route expression considering load balancing."""
        # Get the default routing decision
        default_tool = self._base_strategy.route(expression)
        
        # For now, just use the default routing but track usage
        self._tool_usage_count[default_tool] += 1
        
        logger.debug(f"Load-balanced routing to {default_tool.name} (usage: {self._tool_usage_count[default_tool]})")
        return default_tool
    
    def get_usage_stats(self) -> dict:
        """Get tool usage statistics."""
        return dict(self._tool_usage_count)
    
    def reset_stats(self):
        """Reset usage statistics."""
        for tool_type in self._tool_usage_count:
            self._tool_usage_count[tool_type] = 0
        logger.debug("Usage statistics reset")