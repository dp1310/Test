"""
Math pipeline controller implementation with full async/await support.

This module provides the main pipeline controller for mathematical expression evaluation.
It implements a complete async pipeline with stages: perceive → plan → reason → act → review → learn.

The controller uses a functional approach with concurrent execution for maximum performance
and non-blocking behavior throughout the entire pipeline.
"""

import asyncio
import logging
from itertools import chain
from typing import List, Dict, Any

from ..framework.base_controller import BasePipelineController
from ..framework.models import PipelineContext, PipelineResult, RetryConfig
from ..framework.decorators import timing, error_boundary, memory_managed
from ..framework.utils import MemoryManager
from ..framework.colored_logging import EmojiLogger
from .factories import DefaultToolFactory, DefaultPerceiverFactory
from .planner import Planner
from .reasoner import Reasoner
from .actor import Actor
from .reviewer import Reviewer, Learner

logger = EmojiLogger(__name__)


class MathPipelineController(BasePipelineController):
    """
    Fully async implementation of pipeline controller for mathematical expressions.
    
    This controller orchestrates the complete pipeline execution with the following stages:
    1. Perceive: Parse and validate input expressions
    2. Plan: Create execution plan with appropriate tools
    3. Reason: Determine optimal execution strategy
    4. Act: Execute operations concurrently
    5. Review: Analyze and summarize results
    6. Learn: Extract insights and recommendations
    
    All stages are fully async and non-blocking for maximum performance.
    """
    
    def __init__(self, 
                 timeout: int = 5, 
                 debug: bool = False,
                 perceiver_factory: DefaultPerceiverFactory = None,
                 tool_factory: DefaultToolFactory = None,
                 retry_config: RetryConfig = None):
        """
        Initialize the math pipeline controller.
        
        Args:
            timeout: Maximum execution time in seconds
            debug: Enable debug logging
            perceiver_factory: Factory for creating expression perceivers
            tool_factory: Factory for creating computational tools
            retry_config: Configuration for retry behavior
        """
        super().__init__(timeout, debug)
        
        # Initialize factories and configuration
        self._perceiver_factory = perceiver_factory or DefaultPerceiverFactory()
        self._tool_factory = tool_factory or DefaultToolFactory()
        self._retry_config = retry_config or RetryConfig()
        self._memory_manager = MemoryManager()
        
        # Create pipeline components
        self._components = self._create_components()
        
        logger.logger.info("🚀 MathPipelineController initialized with all components")
    
    def _create_components(self) -> Dict[str, Any]:
        """
        Factory method for creating pipeline components.
        
        Returns:
            Dictionary of initialized pipeline components
        """
        components = {
            'perceivers': self._perceiver_factory.create_perceivers(),
            'planner': Planner(self._tool_factory),
            'reasoner': Reasoner(self._retry_config),
            'actor': Actor(self._memory_manager),
            'reviewer': Reviewer(),
            'learner': Learner()
        }
        
        logger.logger.debug(f"🔧 Created {len(components)} pipeline components")
        return components
    
    @timing("perceive_stage")
    @error_boundary()
    async def _perceive_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Parse and understand the input data using functional approach.
        
        This stage:
        - Runs multiple perceivers concurrently
        - Validates and filters expressions
        - Deduplicates to avoid double execution
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with perceived expressions
        """
        logger.perceive_start(context.input_data)
        
        # Run perception tasks concurrently for better performance
        perception_tasks = [
            asyncio.create_task(self._run_perceiver(perceiver, context.input_data))
            for perceiver in self._components['perceivers']
        ]
        
        # Wait for all perception tasks to complete
        perception_results = await asyncio.gather(*perception_tasks)
        
        # Flatten results from all perceivers using functional approach
        all_expressions = list(chain.from_iterable(perception_results))
        
        # Filter valid expressions using functional approach
        valid_expressions = list(filter(lambda expr: expr.is_valid, all_expressions))
        invalid_expressions = list(filter(lambda expr: not expr.is_valid, all_expressions))
        
        # Deduplicate expressions by their original text to avoid double execution
        seen_expressions = set()
        deduplicated_expressions = []
        for expr in valid_expressions:
            if expr.original not in seen_expressions:
                seen_expressions.add(expr.original)
                deduplicated_expressions.append(expr)
        
        valid_expressions = deduplicated_expressions
        
        # Log results with colorful emojis
        logger.perceive_complete(len(valid_expressions), len(invalid_expressions))
        
        if invalid_expressions and context.debug:
            for expr in invalid_expressions:
                logger.logger.warning(f"⚠️ Invalid expression: {expr.original} - {expr.error_message}")
        
        # Update context with results
        context.stage_results['perceive'] = valid_expressions
        context.stage_results['invalid_expressions'] = invalid_expressions
        context.metrics['valid_expressions'] = len(valid_expressions)
        context.metrics['invalid_expressions'] = len(invalid_expressions)
        
        return context
    
    async def _run_perceiver(self, perceiver, input_data):
        """
        Run a perceiver in a non-blocking context using thread pool.
        
        Args:
            perceiver: The perceiver instance to run
            input_data: Input data to process
            
        Returns:
            List of perceived expressions
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, perceiver.perceive, input_data)
    
    @timing("plan_stage")
    @memory_managed(max_memory_mb=20)
    async def _plan_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Create execution plan from perceived data using functional approach.
        
        This stage:
        - Maps expressions to appropriate computational tools
        - Creates callable functions for execution
        - Optimizes execution plan
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with execution plan
        """
        expressions = context.stage_results['perceive']
        
        if not expressions:
            logger.logger.warning("⚠️ No valid expressions to plan")
            context.stage_results['plan'] = []
            return context
        
        logger.plan_start(len(expressions))
        
        # Run planning asynchronously to avoid blocking
        loop = asyncio.get_event_loop()
        callables = await loop.run_in_executor(None, self._components['planner'].plan, expressions)
        
        logger.plan_complete(len(callables))
        
        # Update context with planning results
        context.stage_results['plan'] = callables
        context.metrics['planned_callables'] = len(callables)
        
        return context
    
    @timing("reason_stage")
    async def _reason_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Determine execution strategy and resource allocation.
        
        This stage:
        - Analyzes computational requirements
        - Determines optimal worker allocation
        - Creates execution strategy
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with execution strategy
        """
        callables = context.stage_results['plan']
        
        if not callables:
            logger.logger.warning("⚠️ No callables to reason about")
            context.stage_results['reason'] = None
            return context
        
        logger.reason_start(len(callables), context.timeout)
        
        # Run reasoning asynchronously
        loop = asyncio.get_event_loop()
        strategy = await loop.run_in_executor(None, self._components['reasoner'].reason, callables, context.timeout)
        
        logger.reason_complete(strategy.total_workers)
        
        # Update context with reasoning results
        context.stage_results['reason'] = strategy
        context.metrics['total_workers'] = strategy.total_workers
        context.metrics['executor_configs'] = len(strategy.executor_configs)
        
        return context
    
    @timing("act_stage")
    @memory_managed(max_memory_mb=50)
    async def _act_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Execute the planned operations using concurrent execution.
        
        This stage:
        - Executes all operations concurrently
        - Handles timeouts gracefully
        - Manages memory usage
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with execution results
        """
        strategy = context.stage_results['reason']
        
        if not strategy:
            logger.logger.warning("⚠️ No execution strategy available")
            context.stage_results['act'] = []
            return context
        
        logger.act_start(strategy.total_workers, context.timeout)
        
        # Execute actions asynchronously with timeout protection
        try:
            results = await asyncio.wait_for(
                self._execute_strategy(strategy),
                timeout=context.timeout
            )
        except asyncio.TimeoutError:
            logger.timeout_warning("action execution", context.timeout)
            results = []
        
        logger.act_complete(len(results))
        
        # Update context with execution results
        context.stage_results['act'] = results
        context.metrics['execution_results'] = len(results)
        
        # Add memory usage metrics for monitoring
        memory_usage = self._components['actor'].get_memory_usage()
        context.metrics.update(memory_usage)
        
        return context
    
    async def _execute_strategy(self, strategy):
        """
        Execute strategy using thread pool.
        
        Args:
            strategy: Execution strategy to run
            
        Returns:
            List of execution results
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._components['actor'].act, strategy)
    
    @timing("review_stage")
    async def _review_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Review and summarize execution results using functional approach.
        
        This stage:
        - Analyzes execution results
        - Calculates performance metrics
        - Identifies patterns and issues
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with review summary
        """
        logger.logger.debug("🔍 Starting review stage")
        
        results = context.stage_results['act']
        
        if not results:
            logger.logger.warning("⚠️ No results to review")
            # Create empty summary for consistency
            from ..framework.models import ReviewSummary
            summary = ReviewSummary(
                total_operations=0,
                successful_operations=0,
                failed_operations=0,
                average_execution_time=0.0,
                results=[]
            )
        else:
            # Run review asynchronously
            loop = asyncio.get_event_loop()
            summary = await loop.run_in_executor(None, self._components['reviewer'].review, results)
        
        # Calculate success rate for logging
        success_rate = (summary.successful_operations / summary.total_operations * 100) if summary.total_operations > 0 else 0
        logger.review_complete(success_rate, summary.average_execution_time)
        
        # Update context with review results
        context.stage_results['review'] = summary
        context.metrics['success_rate'] = success_rate
        context.metrics['average_execution_time'] = summary.average_execution_time
        
        return context
    
    @timing("learn_stage")
    async def _learn_stage(self, context: PipelineContext) -> PipelineContext:
        """
        Extract insights and learning from execution.
        
        This stage:
        - Analyzes historical performance
        - Generates recommendations
        - Persists learning data
        
        Args:
            context: Pipeline execution context
            
        Returns:
            Updated context with learning insights
        """
        logger.logger.debug("🔍 Starting learn stage")
        
        summary = context.stage_results['review']
        
        # Run learning asynchronously
        loop = asyncio.get_event_loop()
        insights = await loop.run_in_executor(None, self._components['learner'].learn, summary)
        
        logger.learn_complete(insights.success_rate, len(insights.performance_recommendations))
        
        # Log recommendations in debug mode
        if context.debug and insights.performance_recommendations:
            logger.logger.info("💡 Performance recommendations:")
            for i, rec in enumerate(insights.performance_recommendations, 1):
                logger.logger.info(f"  {i}. {rec}")
        
        # Create final pipeline result
        context.stage_results['learn'] = insights
        context.result = PipelineResult(summary=summary, insights=insights)
        context.metrics['total_historical_executions'] = insights.total_executions
        
        return context
    
    async def get_pipeline_metrics(self) -> Dict[str, Any]:
        """
        Get comprehensive pipeline metrics.
        
        Returns:
            Dictionary containing pipeline metrics
        """
        loop = asyncio.get_event_loop()
        memory_usage = await loop.run_in_executor(None, self._memory_manager.get_memory_usage)
        
        return {
            'memory_usage': memory_usage,
            'component_count': len(self._components),
            'timeout': self.timeout,
            'debug_mode': self.debug
        }
    
    async def cleanup(self):
        """
        Clean up pipeline resources.
        
        Performs cleanup of:
        - Memory manager
        - Tool factory cache
        - Component resources
        """
        logger.cleanup_start()
        
        # Clean up memory manager asynchronously
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._memory_manager.cleanup)
        
        # Clean up tool factory cache if available
        if hasattr(self._tool_factory, 'clear_cache'):
            await loop.run_in_executor(None, self._tool_factory.clear_cache)
        
        logger.cleanup_complete()


class EnhancedMathPipelineController(MathPipelineController):
    """
    Enhanced math pipeline controller with additional features.
    
    Extends the base controller with:
    - Detailed performance analysis
    - Advanced metrics collection
    - Historical statistics tracking
    """
    
    def __init__(self, 
                 timeout: int = 5, 
                 debug: bool = False,
                 perceiver_factory: DefaultPerceiverFactory = None,
                 tool_factory: DefaultToolFactory = None,
                 retry_config: RetryConfig = None,
                 enable_detailed_review: bool = False):
        """
        Initialize the enhanced math pipeline controller.
        
        Args:
            timeout: Maximum execution time in seconds
            debug: Enable debug logging
            perceiver_factory: Factory for creating expression perceivers
            tool_factory: Factory for creating computational tools
            retry_config: Configuration for retry behavior
            enable_detailed_review: Enable detailed performance analysis
        """
        super().__init__(timeout, debug, perceiver_factory, tool_factory, retry_config)
        
        # Use enhanced components if requested
        if enable_detailed_review:
            from .reviewer import DetailedReviewer
            self._components['reviewer'] = DetailedReviewer()
            logger.logger.info("🔧 Enhanced controller initialized with detailed reviewer")
    
    async def get_detailed_metrics(self) -> Dict[str, Any]:
        """
        Get detailed pipeline metrics including historical data.
        
        Returns:
            Dictionary containing detailed metrics and historical statistics
        """
        base_metrics = await self.get_pipeline_metrics()
        
        # Add historical statistics asynchronously
        loop = asyncio.get_event_loop()
        historical_stats = await loop.run_in_executor(None, self._components['learner'].get_historical_stats)
        
        return {
            **base_metrics,
            'historical_stats': historical_stats,
            'component_types': {name: type(comp).__name__ for name, comp in self._components.items()}
        }