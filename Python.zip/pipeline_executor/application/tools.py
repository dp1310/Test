"""Tool implementations for mathematical operations."""

import logging
from functools import reduce
from operator import mul
from typing import Dict, Callable, Tuple
from pipeline_executor.framework.decorators import retry, timing, memory_managed, error_boundary, cache_result
from pipeline_executor.framework.utils import safe_divide, safe_modulo

logger = logging.getLogger(__name__)


class CalcTool:
    """Calculator tool for basic arithmetic operations using functional approach."""
    
    def __init__(self):
        # Functional approach: operations as pure functions
        self._operations: Dict[str, Callable[[float, float], float]] = {
            '+': lambda l, r: l + r,
            '-': lambda l, r: l - r,
            '*': lambda l, r: l * r,
            '/': lambda l, r: safe_divide(l, r),
            '%': lambda l, r: safe_modulo(l, r)
        }
        
        # Validation predicates
        self._validators: Dict[str, Callable[[float, float], bool]] = {
            '/': lambda l, r: r != 0,
            '%': lambda l, r: r != 0
        }
        
        logger.debug("CalcTool initialized with functional operations")
    
    @retry(max_attempts=2, retry_exceptions=(ZeroDivisionError,))
    @timing("calc_operation")
    @memory_managed(max_memory_mb=5)
    @error_boundary()
    def execute(self, operation: str, left: float, right: float) -> float:
        """Execute arithmetic operation using functional approach."""
        logger.debug(f"CalcTool executing: {left} {operation} {right}")
        
        # Functional validation
        validator = self._validators.get(operation, lambda l, r: True)
        if not validator(left, right):
            error_msg = f"Invalid operation: {left} {operation} {right}"
            logger.error(error_msg)
            raise ZeroDivisionError(error_msg)
        
        # Functional execution
        operation_func = self._operations.get(operation)
        if not operation_func:
            error_msg = f"Unknown operation: {operation}"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        result = operation_func(left, right)
        logger.debug(f"CalcTool result: {result}")
        return result


class PowerTool:
    """Power tool for exponentiation operations using functional approach."""
    
    def __init__(self):
        # Functional approach: power operations
        self._power_ops = {'^', '**'}
        self._max_exponent = 1000
        
        # Validation predicates
        self._is_valid_power = lambda base, exp: abs(exp) <= self._max_exponent
        self._power_func = lambda base, exp: base ** exp
        
        logger.debug("PowerTool initialized with functional operations")
    
    @retry(max_attempts=3, retry_exceptions=(OverflowError,))
    @timing("power_operation")
    @memory_managed(max_memory_mb=10)
    @cache_result(ttl_seconds=60)
    def execute(self, operation: str, base: float, exponent: float) -> float:
        """Execute power operation using functional approach."""
        logger.debug(f"PowerTool executing: {base} {operation} {exponent}")
        
        # Functional validation and execution
        if operation in self._power_ops and self._is_valid_power(base, exponent):
            try:
                result = self._power_func(base, exponent)
                logger.debug(f"PowerTool result: {result}")
                return result
            except OverflowError as e:
                logger.error(f"Power operation overflow: {e}")
                raise
        else:
            return self._handle_invalid_power(operation, base, exponent)
    
    def _handle_invalid_power(self, operation: str, base: float, exponent: float) -> float:
        """Handle invalid power operations."""
        if operation not in self._power_ops:
            error_msg = f"Unknown power operation: {operation}"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        if not self._is_valid_power(base, exponent):
            error_msg = f"Exponent too large: {exponent} (max: {self._max_exponent})"
            logger.error(error_msg)
            raise OverflowError(error_msg)
        
        return float('inf')


class SafeDevTool:
    """Safe development tool for function calls using functional approach."""
    
    def __init__(self):
        # Functional approach: functions as pure operations
        self._functions: Dict[str, Callable[[Tuple[float, ...]], float]] = {
            'add': lambda args: sum(args),
            'sub': lambda args: args[0] - sum(args[1:]) if args else 0,
            'mul': lambda args: reduce(mul, args, 1),
            'div': lambda args: safe_divide(args[0], args[1]) if len(args) >= 2 else float('inf'),
            'pow': lambda args: args[0] ** args[1] if len(args) >= 2 else 0,
            'mod': lambda args: safe_modulo(args[0], args[1]) if len(args) >= 2 else float('nan')
        }
        
        # Validation predicates
        self._validators: Dict[str, Callable[[Tuple[float, ...]], bool]] = {
            'div': lambda args: len(args) >= 2 and args[1] != 0,
            'pow': lambda args: len(args) >= 2,
            'mod': lambda args: len(args) >= 2 and args[1] != 0,
            'sub': lambda args: len(args) >= 1
        }
        
        logger.debug("SafeDevTool initialized with functional operations")
    
    @retry(max_attempts=2)
    @timing("function_call")
    @memory_managed(max_memory_mb=5)
    @error_boundary()
    def execute(self, function_name: str, *args) -> float:
        """Execute function call using functional approach."""
        func_name = function_name.lower()
        logger.debug(f"SafeDevTool executing: {func_name}({args})")
        
        # Functional validation
        validator = self._validators.get(func_name, lambda args: True)
        if not validator(args):
            error_msg = f"Invalid arguments for {function_name}: {args}"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        # Functional execution
        func = self._functions.get(func_name)
        if not func:
            error_msg = f"Unknown function: {function_name}"
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        result = func(args)
        logger.debug(f"SafeDevTool result: {result}")
        return result