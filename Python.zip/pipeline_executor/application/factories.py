"""Factory implementations for tools and perceivers."""

import logging
from abc import ABC, abstractmethod
from typing import Dict, List
from pipeline_executor.framework.models import ToolType
from pipeline_executor.framework.protocols import ToolProtocol, PerceiverProtocol
from pipeline_executor.application.tools import CalcTool, PowerTool, SafeDevTool
from pipeline_executor.application.perceivers import RegexPerceiver, FunctionPerceiver

logger = logging.getLogger(__name__)


class ToolFactory(ABC):
    """Abstract factory for creating tools."""
    
    @abstractmethod
    def create_tool(self, tool_type: ToolType) -> ToolProtocol:
        """Create a tool instance for the given type."""
        pass


class DefaultToolFactory(ToolFactory):
    """Default tool factory with singleton pattern for tool caching."""
    
    def __init__(self):
        self._tool_cache: Dict[ToolType, ToolProtocol] = {}
        logger.debug("DefaultToolFactory initialized")
    
    def create_tool(self, tool_type: ToolType) -> ToolProtocol:
        """Create or retrieve cached tool instance."""
        if tool_type not in self._tool_cache:
            self._tool_cache[tool_type] = self._create_new_tool(tool_type)
            logger.debug(f"Created new {tool_type.name} tool")
        else:
            logger.debug(f"Retrieved cached {tool_type.name} tool")
        
        return self._tool_cache[tool_type]
    
    def _create_new_tool(self, tool_type: ToolType) -> ToolProtocol:
        """Create a new tool instance based on type."""
        tool_mapping = {
            ToolType.CALC: CalcTool,
            ToolType.POWER: PowerTool,
            ToolType.SAFE_DEV: SafeDevTool
        }
        
        tool_class = tool_mapping.get(tool_type)
        if not tool_class:
            raise ValueError(f"Unknown tool type: {tool_type}")
        
        return tool_class()
    
    def clear_cache(self):
        """Clear the tool cache."""
        self._tool_cache.clear()
        logger.debug("Tool cache cleared")


class PerceiverFactory(ABC):
    """Abstract factory for creating perceivers."""
    
    @abstractmethod
    def create_perceivers(self) -> List[PerceiverProtocol]:
        """Create perceiver instances."""
        pass


class DefaultPerceiverFactory(PerceiverFactory):
    """Default perceiver factory."""
    
    def __init__(self):
        logger.debug("DefaultPerceiverFactory initialized")
    
    def create_perceivers(self) -> List[PerceiverProtocol]:
        """Create default perceiver instances."""
        perceivers = [
            RegexPerceiver(),
            FunctionPerceiver()
        ]
        logger.debug(f"Created {len(perceivers)} perceivers")
        return perceivers