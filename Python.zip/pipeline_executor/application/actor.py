"""Actor implementation with concurrent execution and observer pattern."""

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed, Future
from typing import List, Dict, Callable, Any
from itertools import chain
from pipeline_executor.framework.models import (
    ExecutionStrategy, ExecutionResult, ExecutionStatus, 
    ToolType, ExecutorType, RoutedCallable, RetryConfig
)
from pipeline_executor.framework.utils import MemoryManager
from pipeline_executor.framework.decorators import timing, memory_managed
from pipeline_executor.framework.colored_logging import EmojiLogger

logger = EmojiLogger(__name__)


def execute_with_retry(callable_func, retry_config, original_expression, tool_type):
    """Module-level function for retry execution (needed for ProcessPoolExecutor)."""
    start_time = time.time()
    last_exception = None
    
    for attempt in range(retry_config.max_attempts):
        try:
            result = callable_func()
            execution_time = time.time() - start_time
            
            return ExecutionResult(
                original_expression=original_expression,
                result=result,
                execution_time=execution_time,
                status=ExecutionStatus.SUCCESS,
                tool_used=tool_type
            )
            
        except retry_config.retry_exceptions as e:
            last_exception = e
            if attempt < retry_config.max_attempts - 1:
                sleep_time = retry_config.backoff_factor ** attempt
                time.sleep(sleep_time)
                logger.debug(f"Retrying {original_expression} (attempt {attempt + 2}/{retry_config.max_attempts})")
            continue
            
        except Exception as e:
            # Non-retryable exception
            execution_time = time.time() - start_time
            return ExecutionResult(
                original_expression=original_expression,
                result=None,
                execution_time=execution_time,
                status=ExecutionStatus.ERROR,
                error_message=str(e),
                tool_used=tool_type
            )
    
    # All retries exhausted
    execution_time = time.time() - start_time
    return ExecutionResult(
        original_expression=original_expression,
        result=None,
        execution_time=execution_time,
        status=ExecutionStatus.ERROR,
        error_message=f"Max retries exceeded: {last_exception}",
        tool_used=tool_type
    )


class ResultObserver(ABC):
    """Abstract observer for result processing."""
    
    @abstractmethod
    def on_result_ready(self, result: ExecutionResult):
        """Called when a result is ready."""
        pass


class LoggingObserver(ResultObserver):
    """Observer that logs results."""
    
    def on_result_ready(self, result: ExecutionResult):
        """Log the result with emojis."""
        if result.status == ExecutionStatus.SUCCESS:
            logger.operation_success(result.original_expression, result.result, result.tool_used.name)
        else:
            logger.operation_failed(result.original_expression, result.error_message)


class RetryHandler:
    """Handler for retry logic with functional wrapper approach."""
    
    def __init__(self):
        logger.debug("RetryHandler initialized")
    
    def create_retry_task(self, callable_func: Callable, retry_config: RetryConfig, 
                         original_expression: str, tool_type: ToolType) -> tuple:
        """Create a task tuple that can be serialized for ProcessPoolExecutor."""
        return (callable_func, retry_config, original_expression, tool_type)


class Actor:
    """Actor that executes operations concurrently with futures and memory management."""
    
    def __init__(self, memory_manager: MemoryManager = None):
        self._memory_manager = memory_manager or MemoryManager()
        self._observers: List[ResultObserver] = []
        self._retry_handler = RetryHandler()
        self._executors: Dict[ToolType, Any] = {}
        
        # Add default logging observer
        self.add_observer(LoggingObserver())
        
        logger.debug("Actor initialized with memory management and observers")
    
    def add_observer(self, observer: ResultObserver):
        """Add result observer."""
        self._observers.append(observer)
        logger.debug(f"Added observer: {type(observer).__name__}")
    
    @timing("acting")
    @memory_managed(max_memory_mb=50)
    def act(self, strategy: ExecutionStrategy) -> List[ExecutionResult]:
        """Execute operations according to strategy with fan-out/fan-in pattern."""
        logger.act_start(strategy.total_workers, strategy.timeout)
        
        try:
            # Fan-out: submit all tasks to appropriate executors
            futures_by_tool = self._submit_with_retry(strategy)
            
            # Fan-in: collect results with memory management
            results = self._collect_results_with_memory_management(futures_by_tool, strategy.timeout)
            
            logger.act_complete(len(results))
            return results
            
        finally:
            # Clean up executors
            self._cleanup_executors()
    
    @timing("acting_async")
    @memory_managed(max_memory_mb=50)
    async def act_async(self, strategy: ExecutionStrategy) -> List[ExecutionResult]:
        """Async version of act method."""
        logger.act_start(strategy.total_workers, strategy.timeout)
        
        try:
            # Use asyncio for concurrent execution
            tasks = []
            
            for tool_type, config in strategy.executor_configs.items():
                callables = getattr(strategy, f'_{tool_type.name.lower()}_callables', [])
                
                for callable_info in callables:
                    task = asyncio.create_task(
                        self._execute_async_task(callable_info, strategy.retry_config)
                    )
                    tasks.append(task)
            
            # Wait for all tasks to complete with timeout
            try:
                results = await asyncio.wait_for(
                    asyncio.gather(*tasks, return_exceptions=True),
                    timeout=strategy.timeout
                )
                
                # Filter out exceptions and convert to ExecutionResult
                valid_results = [r for r in results if isinstance(r, ExecutionResult)]
                
                logger.act_complete(len(valid_results))
                return valid_results
                
            except asyncio.TimeoutError:
                logger.timeout_warning("async_execution", strategy.timeout)
                # Cancel remaining tasks
                for task in tasks:
                    if not task.done():
                        task.cancel()
                
                # Return partial results
                completed_results = [
                    task.result() for task in tasks 
                    if task.done() and not task.cancelled() and isinstance(task.result(), ExecutionResult)
                ]
                return completed_results
                
        except Exception as e:
            logger.logger.error(f"❌ Async acting failed: {e}")
            return []
    
    async def _execute_async_task(self, callable_info: RoutedCallable, retry_config: RetryConfig) -> ExecutionResult:
        """Execute a single task asynchronously."""
        start_time = time.time()
        
        for attempt in range(retry_config.max_attempts):
            try:
                # Run the callable in a thread pool to avoid blocking
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, callable_info.callable_func)
                
                execution_time = time.time() - start_time
                return ExecutionResult(
                    original_expression=callable_info.original_expression,
                    result=result,
                    execution_time=execution_time,
                    status=ExecutionStatus.SUCCESS,
                    tool_used=callable_info.tool_type
                )
                
            except Exception as e:
                if attempt < retry_config.max_attempts - 1:
                    sleep_time = retry_config.backoff_factor ** attempt
                    logger.retry_attempt(callable_info.original_expression, attempt + 2, retry_config.max_attempts)
                    await asyncio.sleep(sleep_time)
                    continue
                else:
                    execution_time = time.time() - start_time
                    return ExecutionResult(
                        original_expression=callable_info.original_expression,
                        result=None,
                        execution_time=execution_time,
                        status=ExecutionStatus.ERROR,
                        error_message=str(e),
                        tool_used=callable_info.tool_type
                    )
    
    def _submit_with_retry(self, strategy: ExecutionStrategy) -> Dict[ToolType, List[Future]]:
        """Submit tasks with retry mechanism (fan-out pattern)."""
        futures_by_tool = {}
        
        for tool_type, config in strategy.executor_configs.items():
            # Create executor for this tool type
            executor = self._create_executor(config)
            self._executors[tool_type] = executor
            
            # Get callables for this tool type
            callables = getattr(strategy, f'_{tool_type.name.lower()}_callables', [])
            
            futures = []
            for callable_info in callables:
                # For ProcessPoolExecutor, we need to use the module-level function
                if config.executor_type == ExecutorType.PROCESS:
                    future = executor.submit(
                        execute_with_retry,
                        callable_info.callable_func,
                        strategy.retry_config,
                        callable_info.original_expression,
                        callable_info.tool_type
                    )
                else:
                    # For ThreadPoolExecutor, we can use a simple wrapper
                    def create_wrapper(func, retry_cfg, expr, tool):
                        def wrapper():
                            return execute_with_retry(func, retry_cfg, expr, tool)
                        return wrapper
                    
                    wrapper = create_wrapper(
                        callable_info.callable_func,
                        strategy.retry_config,
                        callable_info.original_expression,
                        callable_info.tool_type
                    )
                    future = executor.submit(wrapper)
                
                future.add_done_callback(self._create_result_callback())
                futures.append(future)
            
            futures_by_tool[tool_type] = futures
            logger.debug(f"Submitted {len(futures)} tasks to {tool_type.name} executor")
        
        return futures_by_tool
    
    def _collect_results_with_memory_management(self, 
                                               futures_by_tool: Dict[ToolType, List[Future]], 
                                               timeout: int) -> List[ExecutionResult]:
        """Collect results with memory management (fan-in pattern)."""
        # Functional approach: flatten all futures
        all_futures = list(chain.from_iterable(futures_by_tool.values()))
        
        logger.debug(f"Collecting results from {len(all_futures)} futures")
        
        # Functional result collection with memory management
        def collect_result(future: Future) -> ExecutionResult:
            allocation_id = f"result_{id(future)}"
            
            if self._memory_manager.acquire_memory(1, allocation_id):
                try:
                    result = future.result()
                    return result
                finally:
                    self._memory_manager.release_memory(1, allocation_id)
            else:
                # Memory pressure - process result immediately without storing
                result = future.result()
                self._process_result_immediately(result)
                return None
        
        try:
            # Map futures to results and filter out None values
            results = list(filter(
                lambda r: r is not None,
                map(collect_result, as_completed(all_futures, timeout=timeout))
            ))
            
            logger.debug(f"Successfully collected {len(results)} results")
            return results
            
        except TimeoutError:
            logger.warning(f"Timeout occurred after {timeout}s")
            return self._handle_timeout(all_futures)
    
    def _create_executor(self, config) -> Any:
        """Create appropriate executor based on configuration."""
        if config.executor_type == ExecutorType.THREAD:
            executor = ThreadPoolExecutor(max_workers=config.worker_count)
            logger.debug(f"Created ThreadPoolExecutor with {config.worker_count} workers")
        else:
            executor = ProcessPoolExecutor(max_workers=config.worker_count)
            logger.debug(f"Created ProcessPoolExecutor with {config.worker_count} workers")
        
        return executor
    
    def _create_result_callback(self) -> Callable[[Future], None]:
        """Create callback function for future completion."""
        def callback(future: Future):
            try:
                result = future.result()
                self._notify_observers(result)
            except Exception as e:
                logger.error(f"Error in future callback: {e}")
        
        return callback
    
    def _notify_observers(self, result: ExecutionResult):
        """Notify all observers of result."""
        for observer in self._observers:
            try:
                observer.on_result_ready(result)
            except Exception as e:
                logger.error(f"Error in observer {type(observer).__name__}: {e}")
    
    def _process_result_immediately(self, result: ExecutionResult):
        """Process result immediately without storing (for memory pressure)."""
        logger.debug(f"Processing result immediately: {result.original_expression}")
        self._notify_observers(result)
    
    def _handle_timeout(self, all_futures: List[Future]) -> List[ExecutionResult]:
        """Handle timeout scenario."""
        results = []
        
        for future in all_futures:
            if future.done():
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    logger.error(f"Error getting result from completed future: {e}")
            else:
                # Create timeout result
                timeout_result = ExecutionResult(
                    original_expression="unknown",
                    result=None,
                    execution_time=0.0,
                    status=ExecutionStatus.TIMEOUT,
                    error_message="Operation timed out"
                )
                results.append(timeout_result)
                
                # Cancel the future
                future.cancel()
        
        logger.warning(f"Handled timeout: {len(results)} results processed")
        return results
    
    def _cleanup_executors(self):
        """Clean up all executors."""
        for tool_type, executor in self._executors.items():
            try:
                executor.shutdown(wait=True)
                logger.debug(f"Shut down {tool_type.name} executor")
            except Exception as e:
                logger.error(f"Error shutting down {tool_type.name} executor: {e}")
        
        self._executors.clear()
        logger.debug("All executors cleaned up")
    
    def get_memory_usage(self) -> Dict[str, Any]:
        """Get current memory usage statistics."""
        return self._memory_manager.get_memory_usage()