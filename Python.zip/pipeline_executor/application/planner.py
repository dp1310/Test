"""Planner implementation using command pattern and functional approach."""

import logging
from typing import List, Callable, Any
from pipeline_executor.framework.models import ParsedExpression, RoutedCallable, OperationType
from pipeline_executor.framework.protocols import ToolFactoryProtocol
from pipeline_executor.framework.decorators import timing
from pipeline_executor.application.routing import DefaultRoutingStrategy

logger = logging.getLogger(__name__)


def execute_serializable_command(command, tool_factory):
    """Module-level function to execute serializable commands."""
    tool = tool_factory.create_tool(command.tool_type)
    return command.execute(tool)


class SerializableCommand:
    """Base class for serializable commands."""
    
    def __init__(self, tool_type, original_expression):
        self.tool_type = tool_type
        self.original_expression = original_expression
    
    def execute(self, tool):
        raise NotImplementedError


class FunctionCommand(SerializableCommand):
    """Serializable function command."""
    
    def __init__(self, tool_type, original_expression, function_name, args):
        super().__init__(tool_type, original_expression)
        self.function_name = function_name
        self.args = args
    
    def execute(self, tool):
        logger.debug(f"Executing function command: {self.function_name}({self.args})")
        return tool.execute(self.function_name, *self.args)


class PowerCommand(SerializableCommand):
    """Serializable power command."""
    
    def __init__(self, tool_type, original_expression, operator, base, exponent):
        super().__init__(tool_type, original_expression)
        self.operator = operator
        self.base = base
        self.exponent = exponent
    
    def execute(self, tool):
        logger.debug(f"Executing power command: {self.base} {self.operator} {self.exponent}")
        return tool.execute(self.operator, self.base, self.exponent)


class ArithmeticCommand(SerializableCommand):
    """Serializable arithmetic command."""
    
    def __init__(self, tool_type, original_expression, operator, left, right):
        super().__init__(tool_type, original_expression)
        self.operator = operator
        self.left = left
        self.right = right
    
    def execute(self, tool):
        logger.debug(f"Executing arithmetic command: {self.left} {self.operator} {self.right}")
        return tool.execute(self.operator, self.left, self.right)


class Planner:
    """Planner that creates zero-argument callables using command pattern."""
    
    def __init__(self, tool_factory: ToolFactoryProtocol):
        self._tool_factory = tool_factory
        self._routing_strategy = DefaultRoutingStrategy()
        logger.debug("Planner initialized with tool factory and routing strategy")
    
    @timing("planning")
    def plan(self, expressions: List[ParsedExpression]) -> List[RoutedCallable]:
        """Create routed callables from parsed expressions using functional mapping."""
        logger.info(f"Planning {len(expressions)} expressions")
        
        # Functional mapping from expressions to callables
        callables = list(map(self._create_routed_callable, expressions))
        
        # Filter out invalid callables
        valid_callables = list(filter(lambda c: c is not None, callables))
        
        logger.info(f"Created {len(valid_callables)} valid callables from {len(expressions)} expressions")
        return valid_callables
    
    def _create_routed_callable(self, expression: ParsedExpression) -> RoutedCallable:
        """Create a routed callable from a parsed expression."""
        if not expression.is_valid:
            logger.warning(f"Skipping invalid expression: {expression.original}")
            return None
        
        try:
            # Route to appropriate tool
            tool_type = self._routing_strategy.route(expression)
            
            # Create serializable command instead of closure
            command = self._create_serializable_command(expression, tool_type)
            
            # Store command and factory for later execution
            routed_callable = RoutedCallable(
                callable_func=lambda: execute_serializable_command(command, self._tool_factory),
                tool_type=tool_type,
                original_expression=expression.original,
                expected_result_type=float
            )
            
            # Store the command and factory as attributes for ProcessPoolExecutor
            routed_callable._command = command
            routed_callable._tool_factory = self._tool_factory
            
            logger.debug(f"Created callable for: {expression.original} -> {tool_type.name}")
            return routed_callable
            
        except Exception as e:
            logger.error(f"Failed to create callable for {expression.original}: {e}")
            return None
    
    def _create_serializable_command(self, expression: ParsedExpression, tool_type) -> SerializableCommand:
        """Create a serializable command for the expression."""
        
        if expression.operation_type == OperationType.FUNCTION:
            return FunctionCommand(
                tool_type=tool_type,
                original_expression=expression.original,
                function_name=expression.function_name,
                args=tuple(expression.operands)
            )
        elif expression.operation_type == OperationType.POWER:
            if len(expression.operands) != 2:
                raise ValueError(f"Power operation requires exactly 2 operands, got {len(expression.operands)}")
            
            base, exponent = expression.operands
            operator = '^' if '^' in expression.original else '**'
            
            return PowerCommand(
                tool_type=tool_type,
                original_expression=expression.original,
                operator=operator,
                base=base,
                exponent=exponent
            )
        elif expression.operation_type == OperationType.ARITHMETIC:
            if len(expression.operands) != 2:
                raise ValueError(f"Arithmetic operation requires exactly 2 operands, got {len(expression.operands)}")
            
            left, right = expression.operands
            operator = self._extract_operator(expression.original)
            
            return ArithmeticCommand(
                tool_type=tool_type,
                original_expression=expression.original,
                operator=operator,
                left=left,
                right=right
            )
        else:
            raise ValueError(f"Unknown operation type: {expression.operation_type}")
    

    
    def _extract_operator(self, expression: str) -> str:
        """Extract operator from expression string."""
        operators = ['+', '-', '*', '/', '%']
        
        for op in operators:
            if op in expression:
                return op
        
        raise ValueError(f"No operator found in expression: {expression}")


class BatchPlanner(Planner):
    """Enhanced planner that can handle batch operations."""
    
    def __init__(self, tool_factory: ToolFactoryProtocol, batch_size: int = 10):
        super().__init__(tool_factory)
        self.batch_size = batch_size
        logger.debug(f"BatchPlanner initialized with batch size: {batch_size}")
    
    @timing("batch_planning")
    def plan(self, expressions: List[ParsedExpression]) -> List[RoutedCallable]:
        """Plan expressions in batches for better performance."""
        logger.info(f"Batch planning {len(expressions)} expressions in batches of {self.batch_size}")
        
        all_callables = []
        
        # Process expressions in batches
        for i in range(0, len(expressions), self.batch_size):
            batch = expressions[i:i + self.batch_size]
            logger.debug(f"Processing batch {i // self.batch_size + 1}: {len(batch)} expressions")
            
            batch_callables = super().plan(batch)
            all_callables.extend(batch_callables)
        
        logger.info(f"Batch planning completed: {len(all_callables)} callables created")
        return all_callables