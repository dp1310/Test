"""Reviewer and Learner implementations using functional approach."""

import logging
import json
import os
from typing import List, Dict, Any
from collections import Counter, defaultdict
from pipeline_executor.framework.models import ExecutionResult, ReviewSummary, LearningInsights, ExecutionStatus
from pipeline_executor.framework.decorators import timing

logger = logging.getLogger(__name__)


class Reviewer:
    """Reviewer that summarizes execution results using functional programming."""
    
    def __init__(self):
        logger.debug("Reviewer initialized")
    
    @timing("reviewing")
    def review(self, results: List[ExecutionResult]) -> ReviewSummary:
        """Summarize execution results using functional programming."""
        logger.info(f"Reviewing {len(results)} execution results")
        
        if not results:
            return ReviewSummary(
                total_operations=0,
                successful_operations=0,
                failed_operations=0,
                average_execution_time=0.0,
                results=[]
            )
        
        # Functional review: separate successful and failed results
        successful_results = list(filter(lambda r: r.status == ExecutionStatus.SUCCESS, results))
        failed_results = list(filter(lambda r: r.status != ExecutionStatus.SUCCESS, results))
        timeout_results = list(filter(lambda r: r.status == ExecutionStatus.TIMEOUT, results))
        
        # Calculate statistics using functional approach
        total_operations = len(results)
        successful_operations = len(successful_results)
        failed_operations = len(failed_results)
        timeout_operations = len(timeout_results)
        
        # Calculate average execution time
        total_time = sum(map(lambda r: r.execution_time, results))
        average_execution_time = total_time / total_operations if total_operations > 0 else 0.0
        
        summary = ReviewSummary(
            total_operations=total_operations,
            successful_operations=successful_operations,
            failed_operations=failed_operations,
            average_execution_time=average_execution_time,
            results=results
        )
        
        # Log summary statistics
        success_rate = (successful_operations / total_operations * 100) if total_operations > 0 else 0
        logger.info(f"Review summary: {success_rate:.1f}% success rate, "
                   f"{average_execution_time:.3f}s avg time, "
                   f"{timeout_operations} timeouts")
        
        return summary


class DetailedReviewer(Reviewer):
    """Enhanced reviewer with detailed analysis."""
    
    def __init__(self):
        super().__init__()
        logger.debug("DetailedReviewer initialized")
    
    @timing("detailed_reviewing")
    def review(self, results: List[ExecutionResult]) -> ReviewSummary:
        """Enhanced review with detailed analysis."""
        summary = super().review(results)
        
        # Add detailed analysis
        self._analyze_performance_patterns(results)
        self._analyze_error_patterns(results)
        self._analyze_tool_usage(results)
        
        return summary
    
    def _analyze_performance_patterns(self, results: List[ExecutionResult]):
        """Analyze performance patterns in results."""
        if not results:
            return
        
        # Group by tool type and analyze performance
        tool_performance = defaultdict(list)
        for result in results:
            if result.status == ExecutionStatus.SUCCESS:
                tool_performance[result.tool_used].append(result.execution_time)
        
        for tool_type, times in tool_performance.items():
            if times:
                avg_time = sum(times) / len(times)
                min_time = min(times)
                max_time = max(times)
                logger.info(f"{tool_type.name} performance: avg={avg_time:.3f}s, "
                           f"min={min_time:.3f}s, max={max_time:.3f}s")
    
    def _analyze_error_patterns(self, results: List[ExecutionResult]):
        """Analyze error patterns in results."""
        error_results = [r for r in results if r.status == ExecutionStatus.ERROR]
        
        if error_results:
            error_types = Counter(r.error_message.split(':')[0] if r.error_message else 'Unknown' 
                                for r in error_results)
            
            logger.info(f"Error patterns: {dict(error_types)}")
    
    def _analyze_tool_usage(self, results: List[ExecutionResult]):
        """Analyze tool usage patterns."""
        tool_usage = Counter(r.tool_used for r in results)
        logger.info(f"Tool usage: {dict((k.name, v) for k, v in tool_usage.items())}")


class Learner:
    """Learner that extracts insights and persists learning."""
    
    def __init__(self, persistence_file: str = "pipeline_insights.json"):
        self.persistence_file = persistence_file
        self._historical_data = self._load_historical_data()
        logger.debug(f"Learner initialized with persistence file: {persistence_file}")
    
    @timing("learning")
    def learn(self, summary: ReviewSummary) -> LearningInsights:
        """Extract insights from execution summary."""
        logger.info(f"Learning from {summary.total_operations} operations")
        
        # Update historical data
        self._update_historical_data(summary)
        
        # Calculate insights
        insights = self._extract_insights(summary)
        
        # Persist insights
        self._persist_insights(insights)
        
        logger.info(f"Learning completed: {insights.success_rate:.1f}% success rate, "
                   f"{len(insights.performance_recommendations)} recommendations")
        
        return insights
    
    def _extract_insights(self, summary: ReviewSummary) -> LearningInsights:
        """Extract learning insights from summary."""
        # Calculate success rate
        success_rate = (summary.successful_operations / summary.total_operations * 100) \
                      if summary.total_operations > 0 else 0.0
        
        # Analyze error patterns using functional approach
        error_results = list(filter(lambda r: r.status == ExecutionStatus.ERROR, summary.results))
        error_patterns = dict(Counter(
            r.error_message.split(':')[0] if r.error_message else 'Unknown'
            for r in error_results
        ))
        
        # Generate performance recommendations
        recommendations = self._generate_recommendations(summary)
        
        # Get historical totals
        total_executions = self._historical_data.get('total_executions', 0) + summary.total_operations
        
        insights = LearningInsights(
            total_executions=total_executions,
            success_rate=success_rate,
            average_time=summary.average_execution_time,
            error_patterns=error_patterns,
            performance_recommendations=recommendations
        )
        
        return insights
    
    def _generate_recommendations(self, summary: ReviewSummary) -> List[str]:
        """Generate performance recommendations based on results."""
        recommendations = []
        
        # Analyze timeout issues
        timeout_results = list(filter(lambda r: r.status == ExecutionStatus.TIMEOUT, summary.results))
        if timeout_results:
            timeout_rate = len(timeout_results) / summary.total_operations * 100
            recommendations.append(f"Consider increasing timeout (current timeout rate: {timeout_rate:.1f}%)")
        
        # Analyze slow operations
        if summary.average_execution_time > 1.0:
            recommendations.append("Consider optimizing slow operations or increasing parallelism")
        
        # Analyze error patterns
        error_results = list(filter(lambda r: r.status == ExecutionStatus.ERROR, summary.results))
        if error_results:
            error_rate = len(error_results) / summary.total_operations * 100
            if error_rate > 10:
                recommendations.append(f"High error rate ({error_rate:.1f}%) - review input validation")
        
        # Analyze tool distribution
        tool_usage = Counter(r.tool_used for r in summary.results)
        if len(tool_usage) == 1:
            recommendations.append("Consider load balancing across different tool types")
        
        # Performance-based recommendations
        fast_results = list(filter(lambda r: r.execution_time < 0.001, summary.results))
        if len(fast_results) > summary.total_operations * 0.8:
            recommendations.append("Most operations are very fast - consider batching for efficiency")
        
        return recommendations
    
    def _update_historical_data(self, summary: ReviewSummary):
        """Update historical performance data."""
        self._historical_data['total_executions'] = \
            self._historical_data.get('total_executions', 0) + summary.total_operations
        
        self._historical_data['total_successful'] = \
            self._historical_data.get('total_successful', 0) + summary.successful_operations
        
        # Update execution times history
        times_history = self._historical_data.get('execution_times', [])
        times_history.extend([r.execution_time for r in summary.results])
        
        # Keep only recent history (last 1000 executions)
        if len(times_history) > 1000:
            times_history = times_history[-1000:]
        
        self._historical_data['execution_times'] = times_history
        
        logger.debug(f"Updated historical data: {self._historical_data['total_executions']} total executions")
    
    def _load_historical_data(self) -> Dict[str, Any]:
        """Load historical data from persistence file."""
        if os.path.exists(self.persistence_file):
            try:
                with open(self.persistence_file, 'r') as f:
                    data = json.load(f)
                logger.debug(f"Loaded historical data: {len(data)} entries")
                return data
            except Exception as e:
                logger.warning(f"Failed to load historical data: {e}")
        
        return {}
    
    def _persist_insights(self, insights: LearningInsights):
        """Persist insights to file."""
        try:
            # Update historical data with current insights
            self._historical_data['last_success_rate'] = insights.success_rate
            self._historical_data['last_average_time'] = insights.average_time
            self._historical_data['last_recommendations'] = insights.performance_recommendations
            
            with open(self.persistence_file, 'w') as f:
                json.dump(self._historical_data, f, indent=2)
            
            logger.debug(f"Persisted insights to {self.persistence_file}")
            
        except Exception as e:
            logger.error(f"Failed to persist insights: {e}")
    
    def get_historical_stats(self) -> Dict[str, Any]:
        """Get historical statistics."""
        if not self._historical_data:
            return {}
        
        total_executions = self._historical_data.get('total_executions', 0)
        total_successful = self._historical_data.get('total_successful', 0)
        
        stats = {
            'total_executions': total_executions,
            'total_successful': total_successful,
            'historical_success_rate': (total_successful / total_executions * 100) if total_executions > 0 else 0,
            'last_success_rate': self._historical_data.get('last_success_rate', 0),
            'last_average_time': self._historical_data.get('last_average_time', 0)
        }
        
        return stats