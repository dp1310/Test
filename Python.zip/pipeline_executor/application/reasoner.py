"""Reasoner implementation with functional executor selection."""

import logging
import os
from typing import List, Dict, Callable
from collections import defaultdict
from pipeline_executor.framework.models import (
    RoutedCallable, ExecutionStrategy, ExecutorConfig, 
    RetryConfig, ToolType, ExecutorType
)
from pipeline_executor.framework.decorators import timing

logger = logging.getLogger(__name__)


class ExecutorSelectionStrategy:
    """Strategy for selecting appropriate executors using functional approach."""
    
    def __init__(self):
        # Functional approach: tool type to executor mapping
        self._executor_mapping = {
            ToolType.CALC: ExecutorType.THREAD,
            ToolType.SAFE_DEV: ExecutorType.THREAD,
            ToolType.POWER: ExecutorType.PROCESS
        }
        
        # Predicate-based selection
        self._is_cpu_intensive = lambda tool_type: tool_type == ToolType.POWER
        
        logger.debug("ExecutorSelectionStrategy initialized with functional mappings")
    
    def choose_executor(self, tool_type: ToolType) -> ExecutorType:
        """Choose executor type using functional selection."""
        # For now, use ThreadPoolExecutor for all tools to avoid serialization issues
        # In production, we could implement proper serialization for ProcessPoolExecutor
        executor_type = ExecutorType.THREAD
        
        logger.debug(f"Selected {executor_type.name} executor for {tool_type.name} tool")
        return executor_type


class Reasoner:
    """Reasoner that determines execution strategy using functional approach."""
    
    def __init__(self, retry_config: RetryConfig = None):
        self._retry_config = retry_config or RetryConfig()
        self._executor_strategy = ExecutorSelectionStrategy()
        self._cpu_count = os.cpu_count() or 4
        
        logger.debug(f"Reasoner initialized (CPU count: {self._cpu_count})")
    
    @timing("reasoning")
    def reason(self, callables: List[RoutedCallable], timeout: int) -> ExecutionStrategy:
        """Determine execution strategy for callables using functional approach."""
        logger.info(f"Reasoning about {len(callables)} callables with {timeout}s timeout")
        
        # Group callables by tool type using functional approach
        grouped_callables = self._group_by_tool_type(callables)
        
        # Create executor configurations for each tool type
        executor_configs = self._create_executor_configs(grouped_callables, timeout)
        
        # Calculate total workers
        total_workers = sum(config.worker_count for config in executor_configs.values())
        
        strategy = ExecutionStrategy(
            executor_configs=executor_configs,
            timeout=timeout,
            retry_config=self._retry_config,
            total_workers=total_workers
        )
        
        # Store callables in strategy for later retrieval
        for tool_type, tool_callables in grouped_callables.items():
            setattr(strategy, f'_{tool_type.name.lower()}_callables', tool_callables)
        
        logger.info(f"Created execution strategy with {total_workers} total workers")
        return strategy
    
    def _group_by_tool_type(self, callables: List[RoutedCallable]) -> Dict[ToolType, List[RoutedCallable]]:
        """Group callables by tool type using functional approach."""
        grouped = defaultdict(list)
        
        # Functional grouping
        for callable_item in callables:
            grouped[callable_item.tool_type].append(callable_item)
        
        logger.debug(f"Grouped callables: {dict((k.name, len(v)) for k, v in grouped.items())}")
        return dict(grouped)
    
    def _create_executor_configs(self, grouped_callables: Dict[ToolType, List[RoutedCallable]], 
                               timeout: int) -> Dict[ToolType, ExecutorConfig]:
        """Create executor configurations for each tool type."""
        configs = {}
        
        for tool_type, tool_callables in grouped_callables.items():
            executor_type = self._executor_strategy.choose_executor(tool_type)
            worker_count = self._calculate_optimal_workers(len(tool_callables), executor_type)
            
            configs[tool_type] = ExecutorConfig(
                executor_type=executor_type,
                worker_count=worker_count,
                timeout=timeout
            )
            
            logger.debug(f"Config for {tool_type.name}: {executor_type.name} with {worker_count} workers")
        
        return configs
    
    def _calculate_optimal_workers(self, task_count: int, executor_type: ExecutorType) -> int:
        """Calculate optimal number of workers based on task count and executor type."""
        if executor_type == ExecutorType.THREAD:
            # For I/O-bound tasks, can use more workers than CPU cores
            max_workers = min(task_count, self._cpu_count * 2)
        else:
            # For CPU-bound tasks, limit to CPU cores
            max_workers = min(task_count, self._cpu_count)
        
        # Ensure at least 1 worker
        optimal_workers = max(1, max_workers)
        
        logger.debug(f"Calculated {optimal_workers} workers for {task_count} tasks ({executor_type.name})")
        return optimal_workers


class AdaptiveReasoner(Reasoner):
    """Enhanced reasoner that adapts based on historical performance."""
    
    def __init__(self, retry_config: RetryConfig = None):
        super().__init__(retry_config)
        self._performance_history = defaultdict(list)
        self._adaptation_threshold = 5  # Number of executions before adapting
        
        logger.debug("AdaptiveReasoner initialized with performance tracking")
    
    def reason(self, callables: List[RoutedCallable], timeout: int) -> ExecutionStrategy:
        """Reason with adaptive optimization based on history."""
        strategy = super().reason(callables, timeout)
        
        # Apply adaptations based on performance history
        self._apply_adaptations(strategy)
        
        return strategy
    
    def _apply_adaptations(self, strategy: ExecutionStrategy):
        """Apply performance-based adaptations to the strategy."""
        for tool_type, config in strategy.executor_configs.items():
            history = self._performance_history[tool_type]
            
            if len(history) >= self._adaptation_threshold:
                avg_time = sum(history) / len(history)
                
                # If operations are consistently slow, increase workers
                if avg_time > strategy.timeout * 0.5:
                    config.worker_count = min(config.worker_count + 1, self._cpu_count * 2)
                    logger.debug(f"Increased workers for {tool_type.name} due to slow performance")
                
                # If operations are consistently fast, we could reduce workers
                elif avg_time < strategy.timeout * 0.1 and config.worker_count > 1:
                    config.worker_count = max(config.worker_count - 1, 1)
                    logger.debug(f"Reduced workers for {tool_type.name} due to fast performance")
    
    def record_performance(self, tool_type: ToolType, execution_time: float):
        """Record performance data for future adaptations."""
        history = self._performance_history[tool_type]
        history.append(execution_time)
        
        # Keep only recent history
        if len(history) > 20:
            history.pop(0)
        
        logger.debug(f"Recorded performance for {tool_type.name}: {execution_time:.3f}s")
    
    def get_performance_stats(self) -> Dict[str, Dict[str, float]]:
        """Get performance statistics for all tool types."""
        stats = {}
        
        for tool_type, history in self._performance_history.items():
            if history:
                stats[tool_type.name] = {
                    'avg_time': sum(history) / len(history),
                    'min_time': min(history),
                    'max_time': max(history),
                    'sample_count': len(history)
                }
        
        return stats