# 🚀 Async Pipeline Executor

A high-performance, fully async pipeline executor that processes mathematical expressions through a structured six-stage pipeline. Features colorful emoji logging, concurrent execution, and comprehensive performance monitoring.

## ✨ Key Features

- 🔄 **Fully Async/Await**: Non-blocking execution throughout the entire pipeline
- 🎨 **Colorful Emoji Logging**: Enhanced user experience with meaningful emojis and colors
- ⚡ **Concurrent Execution**: Parallel processing with intelligent resource management
- 🧠 **Machine Learning**: Adaptive performance optimization and recommendations
- 🛡️ **Robust Error Handling**: Comprehensive retry mechanisms and graceful failure handling
- 📊 **Performance Monitoring**: Real-time metrics and historical analysis
- 🔧 **Extensible Architecture**: Clean separation of concerns with pluggable components

## 🏗️ Pipeline Architecture

The pipeline follows a structured six-stage flow with full async support:

### 👁️ **Perceive Stage**
- Concurrent parsing using multiple strategies (regex & function-style)
- Input validation and expression normalization
- Duplicate detection and filtering

### 📋 **Plan Stage** 
- Smart routing to appropriate computational tools
- Creation of zero-argument callables for execution
- Optimization of execution plan

### 🧠 **Reason Stage**
- Intelligent resource allocation (workers, memory, executors)
- Performance-based strategy selection
- Concurrent execution planning

### ⚡ **Act Stage**
- Parallel execution using async/await patterns
- Fan-out to multiple workers, fan-in for result collection
- Real-time timeout and error handling

### 📊 **Review Stage**
- Comprehensive result analysis and metrics calculation
- Performance pattern identification
- Success/failure rate analysis

### 🎓 **Learn Stage**
- Historical performance tracking
- Adaptive recommendation generation
- Persistent insight storage for future optimization

## 🎯 Advanced Features

### 🔄 **Async Architecture**
- Full async/await support with `asyncio`
- Non-blocking execution throughout all pipeline stages
- Concurrent task execution with proper resource management
- Async resource cleanup and memory management

### 🎨 **Enhanced User Experience**
- Colorful emoji logging with context-specific icons
- Different colors for log levels (🔍 DEBUG, ✅ INFO, ⚠️ WARNING, ❌ ERROR, 💥 CRITICAL)
- Tool-specific emojis (🧮 Calculator, ⚡ Power, 🔧 Functions)
- Beautiful result formatting with status indicators

### 🧩 **Design Patterns**
- **Template Method**: Pipeline stage orchestration
- **Strategy Pattern**: Tool selection and execution strategies
- **Factory Pattern**: Component creation with caching
- **Observer Pattern**: Result callbacks and progress monitoring
- **Command Pattern**: Callable operation encapsulation
- **Decorator Pattern**: Cross-cutting concerns (timing, retry, memory)

### 🚀 **Performance Optimization**
- Intelligent worker allocation based on operation types
- Memory pooling and usage monitoring
- Adaptive retry mechanisms with exponential backoff
- Historical performance learning and optimization

## 🛠️ Computational Tools

### 🧮 **CalcTool** 
- **Operations**: `+`, `-`, `*`, `/`, `%`
- **Features**: Basic arithmetic with error handling
- **Example**: `2+3`, `10-7`, `6*9`, `10/2`, `7%3`

### ⚡ **PowerTool**
- **Operations**: `^`, `**` 
- **Features**: Exponentiation with overflow protection
- **Example**: `2^8`, `3**4`, `5^2`

### 🔧 **SafeDevTool**
- **Functions**: `add()`, `sub()`, `mul()`, `div()`, `pow()`, `mod()`
- **Features**: Case-insensitive function calls with parameter validation
- **Example**: `add(5,6)`, `ADD(1,2)`, `pow(2,3)`, `div(10,2)`

## 🚀 Quick Start

### Basic Usage
```bash
# Simple expressions with colorful output
python agent.py --exp "2+3, 5*7, add(10,20)"

# With debug logging for detailed insights
python agent.py --exp "2+3, 10/0, 2^8, add(5,6)" --timeout 5 --debug
```

### Advanced Usage
```bash
# Comprehensive test with all tools
python agent.py --exp "2+3, 10-7, 6*9, 2^8, 5%3, add(5,6), sub(10,3), mul(4,7), div(10,2), pow(2,3)" --debug

# JSON output for programmatic use
python agent.py --exp "2+3, add(5,6), pow(2,4)" --output-format json --quiet

# Enhanced analysis with detailed metrics
python agent.py --exp "1+1, 2*2, 3^2" --detailed-review --debug

# Performance testing with many operations
python agent.py --exp "1+2, 2+3, 3+4, 4+5, 5+6, 6+7, 7+8, 8+9, 9+10, 10+11" --timeout 10
```

### Error Handling Examples
```bash
# Test error handling and recovery
python agent.py --exp "2+3, 10/0, sqrt(16), 2^8" --debug

# Timeout testing
python agent.py --exp "1+1, 2+2" --timeout 1 --debug
```

## ⚙️ Command Line Options

| Option | Description | Default | Example |
|--------|-------------|---------|---------|
| `--exp` | 📝 Mathematical expressions (comma-separated) **[Required]** | - | `"2+3, add(5,6)"` |
| `--timeout` | ⏰ Timeout in seconds for operations | `5` | `--timeout 10` |
| `--debug` | 🔍 Enable debug mode with detailed logging | `False` | `--debug` |
| `--retry-attempts` | 🔄 Maximum retry attempts for failed operations | `3` | `--retry-attempts 5` |
| `--retry-backoff` | 📈 Backoff factor for retry delays | `1.5` | `--retry-backoff 2.0` |
| `--max-memory` | 💾 Maximum memory usage in MB | `100` | `--max-memory 200` |
| `--output-format` | 📊 Output format: `text` or `json` | `text` | `--output-format json` |
| `--detailed-review` | 📈 Enable detailed performance analysis | `False` | `--detailed-review` |
| `--quiet` | 🔇 Suppress non-essential output | `False` | `--quiet` |

## 📦 Installation & Setup

### Prerequisites
- Python 3.8+ (async/await support required)
- Windows, macOS, or Linux

### Installation
```bash
# Clone the repository
git clone <repository-url>
cd pipeline-executor

# Install dependencies (optional - no external dependencies required)
pip install -r requirements.txt

# Run a quick test
python agent.py --exp "2+3, add(5,6)" --debug
```

### Sanity Testing
```bash
# Run comprehensive tests
python sanity_test.py

# Expected output: All tests should pass with colorful emoji logging
```

## 🏛️ Architecture Deep Dive

### 🔧 Framework Layer
```
pipeline_executor/framework/
├── base_controller.py      # 🎯 Abstract pipeline orchestration
├── models.py              # 📊 Data models and type definitions  
├── decorators.py          # 🎨 Cross-cutting concerns (timing, retry, memory)
├── colored_logging.py     # 🌈 Enhanced logging with emojis
├── utils.py              # 🛠️ Memory management and utilities
└── protocols.py          # 📋 Type-safe contracts
```

### 🚀 Application Layer
```
pipeline_executor/application/
├── math_controller.py     # 🧮 Main pipeline implementation
├── perceivers.py         # 👁️ Input parsing strategies
├── planner.py           # 📋 Execution planning
├── reasoner.py          # 🧠 Resource allocation
├── actor.py             # ⚡ Concurrent execution
├── reviewer.py          # 📊 Result analysis
├── tools.py             # 🛠️ Computational tools
├── routing.py           # 🗺️ Tool selection logic
└── factories.py         # 🏭 Component creation
```

### 🔄 Async Flow
1. **Concurrent Parsing**: Multiple perceivers run in parallel
2. **Async Planning**: Non-blocking callable creation
3. **Smart Reasoning**: Async resource allocation
4. **Parallel Execution**: Concurrent operation processing
5. **Async Analysis**: Non-blocking result processing
6. **Learning Pipeline**: Async insight generation

## 🛡️ Error Handling & Recovery

The system provides comprehensive error handling with colorful feedback:

### 🔍 **Parse Errors**
```bash
⚠️ Invalid expression: 4*/5 - Malformed operator sequence
⚠️ Invalid expression: add() - Missing required parameters
```

### 💥 **Runtime Errors** 
```bash
❌ Failed: 10/0 - Invalid operation: division by zero
❌ Failed: sqrt(16) - Unknown function: sqrt
```

### ⏰ **Timeout Protection**
```bash
⏰ Timeout warning for action execution (limit: 5s)
🔄 Retrying operation (attempt 2/3) after 1.50s
```

### 🔄 **Retry Mechanisms**
- Exponential backoff for transient failures
- Configurable retry attempts and backoff factors
- Smart retry logic that distinguishes permanent vs temporary errors

## 📈 Performance & Monitoring

### ⚡ **Execution Performance**
- **Concurrent Processing**: 20 operations completed in ~0.025s
- **Async Architecture**: Non-blocking execution throughout
- **Smart Resource Allocation**: Dynamic worker scaling based on load
- **Memory Efficiency**: Object pooling and automatic cleanup

### 📊 **Real-time Monitoring**
```bash
🟢 ✅ 2+3 = 5.0 (🧮 CALC) - ⏱️ 0.001s
🟢 ✅ add(5,6) = 11.0 (🔧 SAFE_DEV) - ⏱️ 0.002s  
🔴 ❌ 10/0 - 💥 Division by zero - ⏱️ 1.014s
```

### 🎓 **Learning & Optimization**
- Historical performance tracking
- Adaptive recommendations based on usage patterns
- Persistent insights for continuous improvement
- Performance bottleneck identification

### 💡 **Sample Recommendations**
```bash
💡 Most operations are very fast - consider batching for efficiency
💡 High error rate (25.0%) - review input validation
💡 Consider increasing timeout for complex operations
```

## 🧪 Testing

Run the comprehensive test suite:
```bash
python sanity_test.py
```

Expected results:
- ✅ Basic operations test passed!
- ✅ Error handling test passed!  
- ✅ Function calls test passed!
- ✅ Power operations test passed!
- ✅ Enhanced controller test passed!
- ✅ Timeout handling test passed!
- ✅ Concurrent execution test passed!

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Add comprehensive tests and documentation
4. Ensure all tests pass (`python sanity_test.py`)
5. Commit your changes (`git commit -m 'Add amazing feature'`)
6. Push to the branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

**🚀 Ready to process mathematical expressions at lightning speed with beautiful, colorful feedback!** ✨